import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/curriculum.dart';
import '../../providers/auth_provider.dart';
import '../../providers/learn_progress_provider.dart';
import '../../widgets/ui/aurora_background.dart';
import '../../widgets/ui/clay_button.dart';
import '../../widgets/ui/clay_container.dart';
import '../../widgets/ui/glass_panel.dart';
import '../../widgets/ui/pressable.dart';

/// Payload the task screen pushes into [ResultScreen].
@immutable
class ResultPayload {
  final String nodeId;
  final String subjectId;
  final int scorePercent;
  final int xp;
  final int coins;
  final int akyl;
  final int correct;
  final int total;

  const ResultPayload({
    required this.nodeId,
    required this.subjectId,
    required this.scorePercent,
    required this.xp,
    required this.coins,
    required this.akyl,
    required this.correct,
    required this.total,
  });

  factory ResultPayload.fromMap(Map<String, dynamic> map) => ResultPayload(
        nodeId: map['nodeId'] as String,
        subjectId: map['subjectId'] as String,
        scorePercent: (map['scorePercent'] as num).toInt(),
        xp: (map['xp'] as num).toInt(),
        coins: (map['coins'] as num).toInt(),
        akyl: (map['akyl'] as num).toInt(),
        correct: (map['correct'] as num).toInt(),
        total: (map['total'] as num).toInt(),
      );
}

class ResultScreen extends ConsumerStatefulWidget {
  final ResultPayload payload;

  const ResultScreen({super.key, required this.payload});

  @override
  ConsumerState<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends ConsumerState<ResultScreen> {
  late final ConfettiController _confetti;

  int get _stars => NodeProgress.starsForScore(widget.payload.scorePercent);
  bool get _passed => widget.payload.scorePercent >= 60;

  @override
  void initState() {
    super.initState();
    _confetti = ConfettiController(duration: const Duration(seconds: 2));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_stars >= 1) {
        _confetti.play();
        HapticFeedback.heavyImpact();
      } else {
        HapticFeedback.lightImpact();
      }
    });
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  void _continue() {
    final subjectId = widget.payload.subjectId;
    // Return to the exact grade map the player was on, not the grade picker.
    int? grade;
    for (final n in subjectById(subjectId)?.allNodes ?? const <CurriculumNode>[]) {
      if (n.id == widget.payload.nodeId) {
        grade = n.grade;
        break;
      }
    }
    context.go(grade != null ? '/learn/$subjectId/$grade' : '/learn/$subjectId');
  }
  void _retry() =>
      context.pushReplacement('/learn/task/${widget.payload.nodeId}');

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider).asData?.value;
    final name = (user?.fullName.trim().split(' ').first ?? '').isEmpty
        ? 'батыр'
        : user!.fullName.trim().split(' ').first;
    final subject = subjectById(widget.payload.subjectId);

    return Scaffold(
      body: AuroraBackground(
        baseColor: AppColors.cosmicPurpleDark,
        blobs: const [
          AuroraBlob(
              color: AppColors.steppeGoldLight,
              size: 360,
              alignment: Alignment(-0.8, -0.85),
              opacity: 0.55),
          AuroraBlob(
              color: AppColors.cosmicPurpleLight,
              size: 320,
              alignment: Alignment(0.9, 0.6),
              opacity: 0.6),
          AuroraBlob(
              color: AppColors.eagleBlue,
              size: 340,
              alignment: Alignment(0, -0.2),
              opacity: 0.5),
        ],
        child: SafeArea(
          child: Stack(
            children: [
              Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(
                      horizontal: AppSpacing.lg, vertical: AppSpacing.lg),
                  child: Column(
                    children: [
                      GlassPanel(
                        radius: AppRadius.pill,
                        brightness: Brightness.light,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 8),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Text('🏆',
                                style: TextStyle(fontSize: 15)),
                            AppSpacing.gapH8,
                            Text(
                              _passed
                                  ? 'ТАПСЫРМА БАҒЫНДЫРЫЛДЫ!'
                                  : 'ТАҒЫ БІР ӘРЕКЕТ',
                              style: AppTypography.display(
                                size: 12,
                                weight: FontWeight.w800,
                                color: AppColors.steppeGoldDark,
                              ),
                            ),
                          ],
                        ),
                      ).animate().fadeIn(duration: 320.ms).moveY(begin: -10, end: 0),
                      AppSpacing.gapV20,
                      ClayContainer(
                        width: 118,
                        height: 118,
                        radius: 59,
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            AppColors.steppeGoldLight,
                            AppColors.steppeGold
                          ],
                        ),
                        glow: const Color(0xB3D4860A),
                        alignment: Alignment.center,
                        child: Text(_passed ? '🦅' : '🫶',
                            style: const TextStyle(fontSize: 64)),
                      )
                          .animate()
                          .scale(
                              begin: const Offset(0.3, 0.3),
                              end: const Offset(1, 1),
                              curve: Curves.elasticOut,
                              duration: 800.ms),
                      AppSpacing.gapV12,
                      Text(
                        _passed ? 'Тамаша, $name! 🎉' : 'Қам жеме, $name!',
                        textAlign: TextAlign.center,
                        style: AppTypography.displayLarge.copyWith(
                          color: Colors.white,
                          shadows: const [
                            Shadow(
                                color: Color(0x40000000),
                                offset: Offset(0, 4),
                                blurRadius: 14),
                          ],
                        ),
                      ).animate(delay: 200.ms).fadeIn(duration: 360.ms),
                      AppSpacing.gapV4,
                      Text(
                        _passed
                            ? '${subject?.name ?? 'Тапсырманы'} тағы бір қадам бағындырдың!'
                            : 'Қателесу — үйренудің бөлігі. Қайта көрейік!',
                        textAlign: TextAlign.center,
                        style: AppTypography.body.copyWith(
                          color: Colors.white.withValues(alpha: 0.9),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      AppSpacing.gapV20,
                      _ClayStars(stars: _stars),
                      AppSpacing.gapV20,
                      _RewardsCard(payload: widget.payload, passed: _passed),
                      AppSpacing.gapV20,
                      ClayButton.eagle(
                        label: 'Жалғастыру',
                        onTap: _continue,
                      ),
                      AppSpacing.gapV12,
                      Pressable(
                        onTap: _passed ? _continue : _retry,
                        child: Text(
                          _passed ? 'Картаға оралу' : 'Қайталау',
                          style: AppTypography.display(
                            size: 13,
                            weight: FontWeight.w800,
                            color: Colors.white.withValues(alpha: 0.85),
                          ),
                        ),
                      ),
                      AppSpacing.gapV12,
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.topCenter,
                child: ConfettiWidget(
                  confettiController: _confetti,
                  blastDirectionality: BlastDirectionality.explosive,
                  shouldLoop: false,
                  emissionFrequency: 0.06,
                  numberOfParticles: 24,
                  gravity: 0.25,
                  colors: const [
                    AppColors.eagleBlueLight,
                    AppColors.steppeGold,
                    AppColors.cosmicPurpleLight,
                    AppColors.jade,
                    AppColors.coral,
                    Colors.white,
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ClayStars extends StatelessWidget {
  final int stars;
  const _ClayStars({required this.stars});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(3, (i) {
        final earned = i < stars;
        final big = i == 1;
        return Padding(
          padding: EdgeInsets.symmetric(
              horizontal: 6, vertical: big ? 0 : 8),
          child: Text(
            earned ? '⭐' : '☆',
            style: TextStyle(
              fontSize: big ? 56 : 44,
              color: earned ? null : Colors.white.withValues(alpha: 0.4),
              shadows: earned
                  ? const [
                      Shadow(
                          color: Color(0x99D4860A),
                          offset: Offset(0, 7),
                          blurRadius: 12)
                    ]
                  : null,
            ),
          )
              .animate(delay: (260 * i + 350).ms)
              .scale(
                  begin: const Offset(0.2, 0.2),
                  end: const Offset(1, 1),
                  curve: Curves.elasticOut,
                  duration: 620.ms),
        );
      }),
    );
  }
}

class _RewardsCard extends StatelessWidget {
  final ResultPayload payload;
  final bool passed;
  const _RewardsCard({required this.payload, required this.passed});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      brightness: Brightness.light,
      radius: AppRadius.xl,
      padding: const EdgeInsets.all(AppSpacing.md),
      child: Column(
        children: [
          Text('Сыйлықтарың',
              style: AppTypography.display(
                  size: 15,
                  weight: FontWeight.w800,
                  color: AppColors.textPrimary)),
          AppSpacing.gapV12,
          Row(
            children: [
              Expanded(
                child: _RewardTile(
                  glyph: '⚡',
                  amount: '+${payload.akyl}',
                  label: 'Ақыл',
                  c1: AppColors.cosmicPurpleLight,
                  c2: AppColors.cosmicPurple,
                  glow: const Color(0x665840CC),
                ),
              ),
              AppSpacing.gapH12,
              Expanded(
                child: _RewardTile(
                  glyph: '🪙',
                  amount: '+${payload.coins}',
                  label: 'Тиын',
                  c1: AppColors.steppeGoldLight,
                  c2: AppColors.steppeGold,
                  glow: const Color(0x66D4860A),
                ),
              ),
              AppSpacing.gapH12,
              Expanded(
                child: _RewardTile(
                  glyph: '✨',
                  amount: '+${payload.xp}',
                  label: 'XP',
                  c1: AppColors.jadeLight,
                  c2: AppColors.jade,
                  glow: const Color(0x6600C48C),
                ),
              ),
            ],
          ),
          AppSpacing.gapV12,
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              color: AppColors.eagleBlueSurface,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Text(
              passed
                  ? '🔓 Келесі биік ашылды!'
                  : '💪 60%-дан жоғары — келесі биік ашылады',
              textAlign: TextAlign.center,
              style: AppTypography.display(
                size: 12.5,
                weight: FontWeight.w800,
                color: AppColors.eagleBlueDark,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RewardTile extends StatelessWidget {
  final String glyph;
  final String amount;
  final String label;
  final Color c1;
  final Color c2;
  final Color glow;

  const _RewardTile({
    required this.glyph,
    required this.amount,
    required this.label,
    required this.c1,
    required this.c2,
    required this.glow,
  });

  @override
  Widget build(BuildContext context) {
    return ClayContainer(
      radius: AppRadius.md,
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [c1, c2],
      ),
      glow: glow,
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
      child: Column(
        children: [
          Text(glyph, style: const TextStyle(fontSize: 24)),
          AppSpacing.gapV4,
          Text(amount,
              style: AppTypography.display(
                  size: 19, weight: FontWeight.w800, color: Colors.white)),
          Text(label,
              style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: Colors.white.withValues(alpha: 0.9))),
        ],
      ),
    );
  }
}
