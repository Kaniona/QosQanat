import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/curriculum.dart';
import '../../navigation/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../providers/learn_progress_provider.dart';
import '../../widgets/ui/aurora_background.dart';
import '../../widgets/ui/clay_container.dart';
import '../../widgets/ui/glass_panel.dart';
import '../../widgets/ui/pressable.dart';
import '../../widgets/ui/progress_ring.dart';
import 'subject_visuals.dart';

/// Step between picking a subject and entering its map: a premium grade
/// selector. Every subject's content is split into school-year modules
/// (5-сынып, 6-сынып …); the student picks the year, then dives into the
/// ascending node map for just that grade. Years unlock sequentially.
class SubjectGradesScreen extends ConsumerWidget {
  final String subjectId;

  const SubjectGradesScreen({super.key, required this.subjectId});

  ({int completed, int total}) _tally(
    WidgetRef ref,
    List<CurriculumNode> nodes,
  ) {
    final progress = ref.read(learnProgressProvider);
    final completed = nodes
        .where((n) => progress[n.id]?.isCompleted ?? false)
        .length;
    return (completed: completed, total: nodes.length);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    ref.watch(learnProgressProvider);
    final subject = subjectById(subjectId);
    if (subject == null) {
      return const Scaffold(body: Center(child: Text('Пән табылмады')));
    }

    final studentGrade = ref.watch(currentUserProvider).asData?.value?.grade ?? 7;
    final vis = SubjectVisuals.of(subject.id);
    final subjectTally = _tally(ref, subject.allNodes);

    // First incomplete, unlocked grade → the "continue" target.
    int? heroGrade;
    var prevComplete = true;
    for (final m in subject.modules) {
      final t = _tally(ref, m.nodes);
      final gated = studentGrade < m.grade;
      final unlocked = prevComplete && !gated;
      if (unlocked && t.completed < t.total) {
        heroGrade = m.grade;
        break;
      }
      prevComplete = prevComplete && t.completed == t.total;
    }

    return Scaffold(
      body: AuroraBackground(
        light: true,
        child: SafeArea(
          bottom: false,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(
                AppSpacing.md, AppSpacing.sm, AppSpacing.md, AppSpacing.xxxl),
            children: [
              _TopBar(
                subject: subject,
                tally: subjectTally,
                onBack: () => context.pop(),
              ).animate().fadeIn(duration: 280.ms).moveY(begin: 12, end: 0),
              AppSpacing.gapV20,
              Padding(
                padding: const EdgeInsets.only(left: AppSpacing.xs),
                child: Text('Сыныбыңды таңда', style: AppTypography.h3),
              ),
              AppSpacing.gapV4,
              Padding(
                padding: const EdgeInsets.only(left: AppSpacing.xs),
                child: Text(
                  'Әр сынып — жеке шытырман жол. Реті бойынша ашылады.',
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              AppSpacing.gapV16,
              ..._buildGradeCards(
                context: context,
                ref: ref,
                subject: subject,
                vis: vis,
                studentGrade: studentGrade,
                heroGrade: heroGrade,
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildGradeCards({
    required BuildContext context,
    required WidgetRef ref,
    required Subject subject,
    required SubjectVisuals vis,
    required int studentGrade,
    required int? heroGrade,
  }) {
    final cards = <Widget>[];
    var prevComplete = true;

    for (var i = 0; i < subject.modules.length; i++) {
      final module = subject.modules[i];
      final t = _tally(ref, module.nodes);
      final gated = studentGrade < module.grade;
      final unlocked = prevComplete && !gated;
      final isComplete = t.completed == t.total && t.total > 0;
      final isHero = module.grade == heroGrade;

      cards.add(
        _GradeCard(
          module: module,
          vis: vis,
          completed: t.completed,
          total: t.total,
          unlocked: unlocked,
          gated: gated,
          isComplete: isComplete,
          isHero: isHero,
          onTap: () {
            if (!unlocked) {
              _showLocked(context, gated, module.grade);
              return;
            }
            context.push('${AppRoutes.learn}/${subject.id}/${module.grade}');
          },
        )
            .animate(delay: (120 + 90 * i).ms)
            .fadeIn(duration: 320.ms)
            .moveY(begin: 18, end: 0, curve: Curves.easeOut),
      );
      cards.add(AppSpacing.gapV12);

      prevComplete = prevComplete && isComplete;
    }
    return cards;
  }

  void _showLocked(BuildContext context, bool gated, int grade) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(gated
              ? '🔒 Бұл сынып $grade-сыныптан бастап ашылады'
              : '🔒 Алдыңғы сыныпты аяқта!'),
          duration: const Duration(milliseconds: 1700),
          backgroundColor: AppColors.nightInk,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: AppRadius.radiusMd),
        ),
      );
  }
}

// ---------------------------------------------------------------------------
// Top bar — back button, subject identity, overall progress
// ---------------------------------------------------------------------------

class _TopBar extends StatelessWidget {
  final Subject subject;
  final ({int completed, int total}) tally;
  final VoidCallback onBack;

  const _TopBar(
      {required this.subject, required this.tally, required this.onBack});

  @override
  Widget build(BuildContext context) {
    final vis = SubjectVisuals.of(subject.id);
    final pct = tally.total == 0 ? 0.0 : tally.completed / tally.total;

    return GlassPanel(
      radius: AppRadius.xl,
      padding: const EdgeInsets.all(AppSpacing.md),
      child: Row(
        children: [
          Pressable(
            onTap: onBack,
            child: const Text('‹',
                style: TextStyle(
                    fontSize: 32, height: 1, color: AppColors.textPrimary)),
          ),
          AppSpacing.gapH8,
          ClayContainer(
            width: 56,
            height: 56,
            radius: AppRadius.lg,
            gradient: vis.gradient,
            glow: vis.glow,
            alignment: Alignment.center,
            child: Text(vis.emoji, style: const TextStyle(fontSize: 28)),
          ),
          AppSpacing.gapH12,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(subject.name, style: AppTypography.h3),
                AppSpacing.gapV4,
                Text(
                  '${tally.completed}/${tally.total} деңгей меңгерілді',
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          AppSpacing.gapH8,
          ProgressRing(
            value: pct,
            size: 48,
            stroke: 6,
            color: vis.accent,
            centerTextColor: AppColors.textSecondary,
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Grade card
// ---------------------------------------------------------------------------

class _GradeCard extends StatelessWidget {
  final GradeModule module;
  final SubjectVisuals vis;
  final int completed;
  final int total;
  final bool unlocked;
  final bool gated;
  final bool isComplete;
  final bool isHero;
  final VoidCallback onTap;

  const _GradeCard({
    required this.module,
    required this.vis,
    required this.completed,
    required this.total,
    required this.unlocked,
    required this.gated,
    required this.isComplete,
    required this.isHero,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final pct = total == 0 ? 0.0 : completed / total;

    // The "continue" grade gets the full subject gradient; the rest are calm
    // clay tiles so the eye lands on where to go next.
    final filled = isHero;
    final fg = filled ? Colors.white : AppColors.textPrimary;
    final subFg = filled
        ? Colors.white.withValues(alpha: 0.88)
        : AppColors.textSecondary;

    return Pressable(
      onTap: onTap,
      child: Opacity(
        opacity: unlocked ? 1 : 0.62,
        child: ClayContainer(
          radius: AppRadius.lg,
          gradient: filled ? vis.gradient : null,
          glow: filled ? vis.glow : null,
          clip: true,
          padding: const EdgeInsets.all(AppSpacing.md),
          child: Row(
            children: [
              _Leading(
                unlocked: unlocked,
                isComplete: isComplete,
                pct: pct,
                vis: vis,
                filled: filled,
              ),
              AppSpacing.gapH16,
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(module.title,
                            style: AppTypography.display(
                                size: 19,
                                weight: FontWeight.w800,
                                color: fg)),
                        AppSpacing.gapH8,
                        if (isComplete)
                          _Badge(
                            text: '✓ Аяқталды',
                            bg: filled
                                ? Colors.white.withValues(alpha: 0.22)
                                : AppColors.jade.withValues(alpha: 0.16),
                            fg: filled ? Colors.white : AppColors.jade,
                          ),
                      ],
                    ),
                    AppSpacing.gapV4,
                    Text(
                      _statusLine(),
                      style: AppTypography.caption.copyWith(
                        color: subFg,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    if (unlocked) ...[
                      AppSpacing.gapV8,
                      _MiniBar(value: pct, filled: filled, accent: vis.accent),
                    ],
                  ],
                ),
              ),
              AppSpacing.gapH8,
              Text(
                unlocked ? '›' : '🔒',
                style: TextStyle(
                    fontSize: unlocked ? 26 : 16,
                    height: 1,
                    color: unlocked
                        ? subFg
                        : AppColors.textTertiary),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _statusLine() {
    if (gated) return '${module.grade}-сыныптан ашылады';
    if (!unlocked) return 'Алдыңғы сыныпты аяқта';
    if (isComplete) return 'Барлығы $total деңгей бағындырылды';
    if (completed == 0) return '$total деңгей · бастауға дайын';
    return '$completed/$total деңгей · жалғастыр';
  }
}

class _Leading extends StatelessWidget {
  final bool unlocked;
  final bool isComplete;
  final double pct;
  final SubjectVisuals vis;
  final bool filled;

  const _Leading({
    required this.unlocked,
    required this.isComplete,
    required this.pct,
    required this.vis,
    required this.filled,
  });

  @override
  Widget build(BuildContext context) {
    if (!unlocked) {
      return Container(
        width: 56,
        height: 56,
        decoration: BoxDecoration(
          color: AppColors.textTertiary.withValues(alpha: 0.12),
          borderRadius: AppRadius.radiusLg,
        ),
        alignment: Alignment.center,
        child: const Text('🔒', style: TextStyle(fontSize: 22)),
      );
    }
    return ProgressRing(
      value: pct,
      size: 56,
      stroke: 6,
      color: filled ? Colors.white : vis.accent,
      trackColor: filled
          ? Colors.white.withValues(alpha: 0.28)
          : vis.accent.withValues(alpha: 0.16),
      center: Text(
        isComplete ? '🏆' : vis.emoji,
        style: const TextStyle(fontSize: 20),
      ),
    );
  }
}

class _MiniBar extends StatelessWidget {
  final double value;
  final bool filled;
  final Color accent;
  const _MiniBar(
      {required this.value, required this.filled, required this.accent});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(99),
      child: Stack(
        children: [
          Container(
            height: 8,
            color: filled
                ? Colors.white.withValues(alpha: 0.25)
                : accent.withValues(alpha: 0.12),
          ),
          FractionallySizedBox(
            widthFactor: value.clamp(0, 1),
            child: Container(
              height: 8,
              decoration: BoxDecoration(
                gradient: filled
                    ? const LinearGradient(colors: [
                        AppColors.steppeGoldLight,
                        AppColors.steppeGold
                      ])
                    : LinearGradient(colors: [accent, accent]),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String text;
  final Color bg;
  final Color fg;
  const _Badge({required this.text, required this.bg, required this.fg});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration:
          BoxDecoration(color: bg, borderRadius: BorderRadius.circular(999)),
      child: Text(text,
          style:
              AppTypography.display(size: 11, weight: FontWeight.w800, color: fg)),
    );
  }
}
