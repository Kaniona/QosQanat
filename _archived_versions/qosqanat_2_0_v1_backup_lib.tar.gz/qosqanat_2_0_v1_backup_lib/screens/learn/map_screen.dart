import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/curriculum.dart';
import '../../providers/learn_progress_provider.dart';
import '../../widgets/ui/glass_panel.dart';
import '../../widgets/ui/pressable.dart';
import 'subject_visuals.dart';
import 'widgets/map_background.dart';
import 'widgets/map_node.dart';
import 'widgets/map_path.dart';
import 'widgets/node_preview_sheet.dart';

/// The signature ascending learning map for a single subject. When [grade] is
/// given, only that school-year module's nodes are shown; locking still respects
/// the full subject order, so a later grade stays sealed until earlier ones are
/// finished.
class MapScreen extends ConsumerStatefulWidget {
  final String subjectId;
  final int? grade;

  const MapScreen({super.key, required this.subjectId, this.grade});

  @override
  ConsumerState<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends ConsumerState<MapScreen> {
  static const double _nodeStride = 132; // vertical spacing between centers
  static const double _topPadding = 130; // space below sticky header
  static const double _bottomPadding = 80;
  static const double _ampFraction = 0.22; // S-curve amplitude as % of width
  static const int _curvePeriod = 4; // nodes per full sine wave

  String? _shakingNodeId;

  Subject get _subject => subjectById(widget.subjectId)!;

  /// The nodes to draw: a single grade module when [MapScreen.grade] is set,
  /// otherwise the whole subject.
  List<CurriculumNode> get _nodes {
    if (widget.grade == null) return _subject.allNodes;
    return moduleForGrade(_subject, widget.grade!)?.nodes ?? const [];
  }

  /// Title shown under the subject name in the header.
  String get _scopeTitle {
    if (widget.grade == null) return '';
    return moduleForGrade(_subject, widget.grade!)?.title ?? '';
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(learnProgressProvider.notifier).ensureLoaded();
    });
  }

  /// Layout: compute the (x, y) center for each node along an S-curve. The map
  /// renders a single grade module, so no inter-module banners are needed.
  ({List<Offset> centers, double height}) _layout(double width) {
    final centers = <Offset>[];
    final amplitude = width * _ampFraction;
    final centerX = width / 2;

    double cursor = _topPadding;
    final nodes = _nodes;

    for (var i = 0; i < nodes.length; i++) {
      final phase = (2 * math.pi * i) / _curvePeriod;
      final dx = centerX + amplitude * math.sin(phase);
      centers.add(Offset(dx, cursor));
      cursor += _nodeStride;
    }

    cursor += _bottomPadding;
    return (centers: centers, height: cursor);
  }

  void _onNodeTap({
    required CurriculumNode node,
    required NodeVisualState state,
  }) {
    if (state == NodeVisualState.locked) {
      setState(() => _shakingNodeId = node.id);
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            content: const Text('🔒 Алдыңғы тапсырманы аяқта!'),
            duration: const Duration(milliseconds: 1500),
            backgroundColor: AppColors.nightInk,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: AppRadius.radiusMd),
          ),
        );
      Future<void>.delayed(const Duration(milliseconds: 600), () {
        if (mounted) setState(() => _shakingNodeId = null);
      });
      return;
    }

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius:
            BorderRadius.vertical(top: Radius.circular(AppRadius.xl)),
      ),
      builder: (_) => NodePreviewSheet(
        node: node,
        subject: _subject,
        onStart: () {
          Navigator.of(context).pop();
          context.push('/learn/task/${node.id}');
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    ref.watch(learnProgressProvider);
    final progress = ref.read(learnProgressProvider.notifier);

    // Locking/current is computed over the whole subject so grades stay gated
    // sequentially; the header counters reflect only the visible grade.
    final orderedIds =
        _subject.allNodes.map((n) => n.id).toList(growable: false);
    final scopeIds = _nodes.map((n) => n.id).toList(growable: false);
    final currentId = progress.currentNodeId(orderedIds);
    final completedCount = progress.completedCount(scopeIds);
    final total = scopeIds.length;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: LayoutBuilder(
        builder: (context, constraints) {
          final width = constraints.maxWidth;
          final layout = _layout(width);

          return Stack(
            children: [
              // Map content scroll.
              SingleChildScrollView(
                reverse: false, // top-down (header at top, latest at bottom)
                padding: EdgeInsets.zero,
                child: SizedBox(
                  width: width,
                  height: layout.height,
                  child: Stack(
                    children: [
                      MapBackground(subject: _subject, height: layout.height),
                      MapPath(
                        nodeCenters: layout.centers,
                        width: width,
                        height: layout.height,
                        accent: SubjectVisuals.of(_subject.id).accent,
                      ),
                      ..._buildNodes(
                        orderedIds: orderedIds,
                        currentId: currentId,
                        centers: layout.centers,
                        progress: progress,
                      ),
                    ],
                  ),
                ),
              ),
              // Sticky header.
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: _StickyHeader(
                  subject: _subject,
                  scopeTitle: _scopeTitle,
                  completed: completedCount,
                  total: total,
                  hearts: 5, // TODO: bind to a hearts provider in a later task
                  onBack: () => context.pop(),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<Widget> _buildNodes({
    required List<String> orderedIds,
    required String? currentId,
    required List<Offset> centers,
    required LearnProgressNotifier progress,
  }) {
    final widgets = <Widget>[];
    final nodes = _nodes;
    for (var i = 0; i < nodes.length; i++) {
      final node = nodes[i];
      final isUnlocked = progress.isUnlocked(
        orderedNodeIds: orderedIds,
        nodeId: node.id,
      );
      final isCurrent = node.id == currentId;
      final state = resolveNodeState(
        node: node,
        progress: progress.progressFor(node.id),
        isUnlocked: isUnlocked,
        isCurrent: isCurrent,
      );

      final c = centers[i];
      final isBoss = node.type.wireValue == 'boss';
      final size = isBoss ? 88.0 : 72.0;
      final halfWidth = (size + 24) / 2;
      final halfHeight = size / 2;

      Widget child = MapNode(
        node: node,
        state: state,
        accent: SubjectVisuals.of(_subject.id).accent,
        onTap: () => _onNodeTap(node: node, state: state),
      );

      if (_shakingNodeId == node.id) {
        child = child
            .animate(key: ValueKey('shake_${node.id}_${DateTime.now().microsecond}'))
            .shake(duration: 420.ms, hz: 6, rotation: 0.04);
      }

      widgets.add(Positioned(
        left: c.dx - halfWidth,
        top: c.dy - halfHeight,
        child: child,
      ));
    }
    return widgets;
  }
}

class _StickyHeader extends StatelessWidget {
  final Subject subject;
  final String scopeTitle;
  final int completed;
  final int total;
  final int hearts;
  final VoidCallback onBack;

  const _StickyHeader({
    required this.subject,
    required this.scopeTitle,
    required this.completed,
    required this.total,
    required this.hearts,
    required this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    final progress = total == 0 ? 0.0 : completed / total;
    final vis = SubjectVisuals.of(subject.id);
    final dark = Theme.of(context).brightness == Brightness.dark;
    final onGlass = dark ? AppColors.darkTextPrimary : AppColors.textPrimary;

    return Padding(
      padding: EdgeInsets.fromLTRB(
        AppSpacing.sm,
        MediaQuery.of(context).padding.top + AppSpacing.xs,
        AppSpacing.sm,
        0,
      ),
      child: GlassPanel(
        radius: AppRadius.lg,
        padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.sm, vertical: AppSpacing.sm),
        child: Row(
          children: [
            Pressable(
              onTap: onBack,
              child: Text('‹', style: TextStyle(fontSize: 30, height: 1, color: onGlass)),
            ),
            AppSpacing.gapH8,
            Text(vis.emoji, style: const TextStyle(fontSize: 26)),
            AppSpacing.gapH8,
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          subject.name,
                          overflow: TextOverflow.ellipsis,
                          style: AppTypography.display(
                              size: 15,
                              weight: FontWeight.w800,
                              color: onGlass),
                        ),
                      ),
                      if (scopeTitle.isNotEmpty) ...[
                        AppSpacing.gapH8,
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: vis.accent.withValues(alpha: 0.16),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            scopeTitle,
                            style: AppTypography.display(
                                size: 11,
                                weight: FontWeight.w800,
                                color: vis.accent),
                          ),
                        ),
                      ],
                    ],
                  ),
                  AppSpacing.gapV4,
                  ClipRRect(
                    borderRadius: BorderRadius.circular(99),
                    child: LinearProgressIndicator(
                      value: progress,
                      minHeight: 7,
                      backgroundColor:
                          onGlass.withValues(alpha: dark ? 0.14 : 0.1),
                      valueColor: AlwaysStoppedAnimation(vis.accent),
                    ),
                  ),
                ],
              ),
            ),
            AppSpacing.gapH8,
            _Hearts(count: hearts),
          ],
        ),
      ),
    );
  }
}

class _Hearts extends StatelessWidget {
  final int count;
  const _Hearts({required this.count});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 0; i < 5; i++)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 1),
            child: Opacity(
              opacity: i < count ? 1 : 0.3,
              child: const Text('❤️', style: TextStyle(fontSize: 15)),
            ),
          ),
      ],
    );
  }
}
