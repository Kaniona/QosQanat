import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';

/// A fully distinct, hand-painted backdrop per subject so every learning map
/// has its own world — not just a recolored steppe. [sceneFor] returns the
/// background [gradient] plus the [CustomPainter] that draws the themed scene.
///
/// Worlds:
///  - math        → blueprint cosmos (geometry, grids, angles, π)
///  - kazakh      → steppe heritage (yurts, mountains, oyu-ornek, sun, birds)
///  - english     → global voyage (globe, clouds, paper plane, landmarks)
///  - physics     → cosmic lab (planets, atom orbits, energy waves, E=mc²)
///  - informatics → cyber grid (circuit traces, binary rain, < /> glyphs)
class SubjectScene {
  final LinearGradient gradient;
  final CustomPainter painter;
  const SubjectScene({required this.gradient, required this.painter});
}

SubjectScene sceneFor(String subjectId) {
  switch (subjectId) {
    case 'math':
      return SubjectScene(
        gradient: const LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [Color(0xFF2746A6), AppColors.eagleBlueDark, AppColors.nightInk],
        ),
        painter: _MathScene(),
      );
    case 'kazakh':
      return SubjectScene(
        gradient: const LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [AppColors.steppeGoldLight, Color(0xFFE98A4B), AppColors.cosmicPurpleDark],
        ),
        painter: _KazakhScene(),
      );
    case 'english':
      return SubjectScene(
        gradient: const LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [Color(0xFFBFE0FF), AppColors.eagleBlueLight, AppColors.eagleBlueDark],
        ),
        painter: _EnglishScene(),
      );
    case 'physics':
      return SubjectScene(
        gradient: const LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [AppColors.coralDark, AppColors.cosmicPurpleDark, AppColors.auroraBase],
        ),
        painter: _PhysicsScene(),
      );
    case 'informatics':
    default:
      return SubjectScene(
        gradient: const LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [AppColors.cosmicPurpleDark, Color(0xFF2C2266), AppColors.night],
        ),
        painter: _InformaticsScene(),
      );
  }
}

// ---------------------------------------------------------------------------
// Shared paint helpers
// ---------------------------------------------------------------------------

void _glyph(
  Canvas canvas,
  String s,
  Offset at,
  double size,
  Color color, {
  FontWeight weight = FontWeight.w800,
}) {
  final tp = TextPainter(
    text: TextSpan(
      text: s,
      style: TextStyle(fontSize: size, color: color, fontWeight: weight, height: 1),
    ),
    textDirection: TextDirection.ltr,
  )..layout();
  tp.paint(canvas, at - Offset(tp.width / 2, tp.height / 2));
}

void _softStars(Canvas canvas, double w, double topH, int count, int seed) {
  final rng = math.Random(seed);
  final star = Paint()..color = AppColors.white.withValues(alpha: 0.8);
  for (var i = 0; i < count; i++) {
    final x = rng.nextDouble() * w;
    final y = rng.nextDouble() * topH;
    canvas.drawCircle(Offset(x, y), 0.6 + rng.nextDouble() * 1.8, star);
  }
}

// ---------------------------------------------------------------------------
// MATH — blueprint cosmos
// ---------------------------------------------------------------------------

class _MathScene extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // Faint blueprint grid over the whole canvas.
    final grid = Paint()
      ..color = AppColors.eagleBlueLight.withValues(alpha: 0.10)
      ..strokeWidth = 1;
    const cell = 34.0;
    for (double x = 0; x < w; x += cell) {
      canvas.drawLine(Offset(x, 0), Offset(x, h), grid);
    }
    for (double y = 0; y < h; y += cell) {
      canvas.drawLine(Offset(0, y), Offset(w, y), grid);
    }
    // Brighter major lines.
    final major = Paint()
      ..color = AppColors.eagleBlueLight.withValues(alpha: 0.16)
      ..strokeWidth = 1.4;
    for (double x = 0; x < w; x += cell * 4) {
      canvas.drawLine(Offset(x, 0), Offset(x, h), major);
    }

    _softStars(canvas, w, h * 0.22, 22, 7);

    final line = Paint()
      ..color = AppColors.steppeGoldLight.withValues(alpha: 0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeJoin = StrokeJoin.round
      ..strokeCap = StrokeCap.round;
    final fill = Paint()..color = AppColors.white.withValues(alpha: 0.06);
    final glyphCol = AppColors.white.withValues(alpha: 0.5);

    final rng = math.Random(101);
    // Scatter floating math figures down the left/right gutters.
    for (double y = h * 0.10; y < h - 80; y += 150) {
      final left = rng.nextBool();
      final cx = left ? w * (0.12 + rng.nextDouble() * 0.06)
                      : w * (0.82 + rng.nextDouble() * 0.06);
      final cy = y + rng.nextDouble() * 40;
      switch (rng.nextInt(6)) {
        case 0: // circle with radius
          canvas.drawCircle(Offset(cx, cy), 22, fill);
          canvas.drawCircle(Offset(cx, cy), 22, line);
          canvas.drawLine(Offset(cx, cy), Offset(cx + 22, cy), line);
          _glyph(canvas, 'r', Offset(cx + 11, cy - 9), 11, glyphCol);
        case 1: // right triangle
          final p = Path()
            ..moveTo(cx - 20, cy + 16)
            ..lineTo(cx + 20, cy + 16)
            ..lineTo(cx - 20, cy - 18)
            ..close();
          canvas.drawPath(p, fill);
          canvas.drawPath(p, line);
        case 2: // angle arc with rays
          canvas.drawLine(Offset(cx - 22, cy + 14), Offset(cx + 22, cy + 14), line);
          canvas.drawLine(Offset(cx - 22, cy + 14), Offset(cx + 16, cy - 14), line);
          canvas.drawArc(Rect.fromCircle(center: Offset(cx - 22, cy + 14), radius: 16),
              -0.6, 0.6, false, line);
          _glyph(canvas, '45°', Offset(cx - 2, cy + 6), 10, glyphCol);
        case 3: // square
          final r = Rect.fromCenter(center: Offset(cx, cy), width: 36, height: 36);
          canvas.drawRect(r, fill);
          canvas.drawRect(r, line);
        case 4: // ruler
          final r = Rect.fromCenter(center: Offset(cx, cy), width: 46, height: 16);
          canvas.drawRRect(RRect.fromRectAndRadius(r, const Radius.circular(3)), line);
          for (var t = 0; t < 5; t++) {
            final tx = r.left + 6 + t * 9;
            canvas.drawLine(Offset(tx, r.top), Offset(tx, r.top + 6), line);
          }
        case 5: // symbol
          _glyph(canvas, ['π', '√', '∑', '∞', 'x²'][rng.nextInt(5)],
              Offset(cx, cy), 26, AppColors.steppeGoldLight.withValues(alpha: 0.7));
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

// ---------------------------------------------------------------------------
// KAZAKH — steppe heritage
// ---------------------------------------------------------------------------

class _KazakhScene extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final steppeTop = h - h * 0.16;

    _softStars(canvas, w, h * 0.20, 16, 3);

    // Sun glow high up.
    final sun = Paint()
      ..shader = RadialGradient(colors: [
        AppColors.steppeGoldLight.withValues(alpha: 0.9),
        AppColors.steppeGoldLight.withValues(alpha: 0.0),
      ]).createShader(Rect.fromCircle(center: Offset(w * 0.78, h * 0.10), radius: 70));
    canvas.drawCircle(Offset(w * 0.78, h * 0.10), 70, sun);
    canvas.drawCircle(Offset(w * 0.78, h * 0.10), 26,
        Paint()..color = AppColors.steppeGoldLight.withValues(alpha: 0.95));

    _birds(canvas, w * 0.24, h * 0.16);
    _birds(canvas, w * 0.40, h * 0.12);

    // Mountains.
    final back = Paint()..color = AppColors.cosmicPurpleDark.withValues(alpha: 0.45);
    final front = Paint()..color = AppColors.nightInk.withValues(alpha: 0.5);
    canvas.drawPath(
      Path()
        ..moveTo(0, steppeTop)
        ..lineTo(0, steppeTop - 70)
        ..lineTo(w * 0.20, steppeTop - 150)
        ..lineTo(w * 0.36, steppeTop - 80)
        ..lineTo(w * 0.58, steppeTop - 170)
        ..lineTo(w * 0.80, steppeTop - 90)
        ..lineTo(w, steppeTop - 130)
        ..lineTo(w, steppeTop)
        ..close(),
      back,
    );
    canvas.drawPath(
      Path()
        ..moveTo(0, steppeTop)
        ..lineTo(0, steppeTop - 30)
        ..lineTo(w * 0.24, steppeTop - 90)
        ..lineTo(w * 0.46, steppeTop - 40)
        ..lineTo(w * 0.66, steppeTop - 104)
        ..lineTo(w * 0.88, steppeTop - 50)
        ..lineTo(w, steppeTop - 64)
        ..lineTo(w, steppeTop)
        ..close(),
      front,
    );

    // Steppe.
    canvas.drawRect(Rect.fromLTWH(0, steppeTop, w, h - steppeTop),
        Paint()..color = AppColors.steppeGoldDark.withValues(alpha: 0.7));

    _yurt(canvas, w * 0.24, steppeTop + 34, 1.0);
    _yurt(canvas, w * 0.44, steppeTop + 28, 0.76);
    _horse(canvas, w, steppeTop);

    _oyuEdges(canvas, w, h);
  }

  void _birds(Canvas canvas, double x, double y) {
    final p = Paint()
      ..color = AppColors.nightInk.withValues(alpha: 0.45)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(
      Path()
        ..moveTo(x - 8, y)
        ..quadraticBezierTo(x - 4, y - 5, x, y)
        ..quadraticBezierTo(x + 4, y - 5, x + 8, y),
      p,
    );
  }

  void _yurt(Canvas canvas, double cx, double baseY, double scale) {
    final body = Paint()..color = AppColors.white.withValues(alpha: 0.94);
    final roof = Paint()..color = AppColors.coral.withValues(alpha: 0.85);
    final trim = Paint()
      ..color = AppColors.nightInk.withValues(alpha: 0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    final bw = 46.0 * scale;
    final bh = 28.0 * scale;
    final r = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(cx, baseY - bh / 2), width: bw, height: bh),
      const Radius.circular(4),
    );
    canvas.drawRRect(r, body);
    canvas.drawRRect(r, trim);
    final roofPath = Path()
      ..moveTo(cx - bw / 2 - 3, baseY - bh)
      ..quadraticBezierTo(cx, baseY - bh - 24 * scale, cx + bw / 2 + 3, baseY - bh)
      ..close();
    canvas.drawPath(roofPath, roof);
    canvas.drawPath(roofPath, trim);
    canvas.drawRect(
      Rect.fromCenter(center: Offset(cx, baseY - 5 * scale), width: 8 * scale, height: 10 * scale),
      Paint()..color = AppColors.nightInk.withValues(alpha: 0.6),
    );
  }

  void _horse(Canvas canvas, double w, double steppeTop) {
    final p = Paint()..color = AppColors.nightInk.withValues(alpha: 0.78);
    canvas.drawPath(
      Path()
        ..moveTo(w * 0.72, steppeTop + 38)
        ..lineTo(w * 0.72, steppeTop + 22)
        ..lineTo(w * 0.79, steppeTop + 16)
        ..lineTo(w * 0.86, steppeTop + 18)
        ..lineTo(w * 0.87, steppeTop + 22)
        ..lineTo(w * 0.85, steppeTop + 38)
        ..lineTo(w * 0.84, steppeTop + 38)
        ..lineTo(w * 0.84, steppeTop + 27)
        ..lineTo(w * 0.75, steppeTop + 27)
        ..lineTo(w * 0.75, steppeTop + 38)
        ..close(),
      p,
    );
    canvas.drawCircle(Offset(w * 0.88, steppeTop + 14), 4, p);
  }

  void _oyuEdges(Canvas canvas, double w, double h) {
    final paint = Paint()
      ..color = AppColors.steppeGoldLight.withValues(alpha: 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..strokeJoin = StrokeJoin.round;
    const unit = 34.0;
    const motifX = 9.0;
    for (double y = unit / 2; y < h; y += unit) {
      canvas.drawPath(
        Path()
          ..moveTo(motifX, y - 6)
          ..quadraticBezierTo(motifX + 8, y, motifX, y + 6)
          ..moveTo(w - motifX, y - 6)
          ..quadraticBezierTo(w - motifX - 8, y, w - motifX, y + 6),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

// ---------------------------------------------------------------------------
// ENGLISH — global voyage
// ---------------------------------------------------------------------------

class _EnglishScene extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // Globe top-right.
    final gc = Offset(w * 0.76, h * 0.11);
    const gr = 48.0;
    canvas.drawCircle(gc, gr, Paint()..color = AppColors.eagleBlueLight.withValues(alpha: 0.35));
    canvas.drawCircle(gc, gr,
        Paint()..color = AppColors.white.withValues(alpha: 0.55)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2);
    final meridian = Paint()
      ..color = AppColors.white.withValues(alpha: 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3;
    for (final f in [0.45, 0.85]) {
      canvas.drawOval(Rect.fromCenter(center: gc, width: gr * 2 * f, height: gr * 2), meridian);
    }
    canvas.drawLine(Offset(gc.dx - gr, gc.dy), Offset(gc.dx + gr, gc.dy), meridian);
    canvas.drawOval(Rect.fromCenter(center: gc, width: gr * 2, height: gr * 0.9), meridian);
    // Continent blobs.
    final land = Paint()..color = AppColors.jade.withValues(alpha: 0.55);
    canvas.drawCircle(Offset(gc.dx - 14, gc.dy - 10), 10, land);
    canvas.drawCircle(Offset(gc.dx + 12, gc.dy + 8), 13, land);

    _clouds(canvas, w, h);

    // Paper plane with dotted trail (mid-map).
    final trail = Paint()
      ..color = AppColors.white.withValues(alpha: 0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    final tp = Path()
      ..moveTo(w * 0.18, h * 0.40)
      ..quadraticBezierTo(w * 0.40, h * 0.30, w * 0.60, h * 0.38);
    _dashed(canvas, tp, trail);
    _plane(canvas, Offset(w * 0.62, h * 0.385));

    // Floating chat bubbles.
    _bubble(canvas, Offset(w * 0.22, h * 0.20), 'Hi');
    _bubble(canvas, Offset(w * 0.80, h * 0.34), 'ABC');
    _bubble(canvas, Offset(w * 0.20, h * 0.58), 'Yes');

    _landmarks(canvas, w, h);
  }

  void _clouds(Canvas canvas, double w, double h) {
    final cloud = Paint()..color = AppColors.white.withValues(alpha: 0.5);
    void c(double cx, double cy, double s) {
      canvas.drawCircle(Offset(cx, cy), 16 * s, cloud);
      canvas.drawCircle(Offset(cx + 18 * s, cy + 3), 20 * s, cloud);
      canvas.drawCircle(Offset(cx - 16 * s, cy + 4), 13 * s, cloud);
      canvas.drawCircle(Offset(cx + 34 * s, cy + 5), 11 * s, cloud);
    }

    c(w * 0.30, h * 0.26, 0.9);
    c(w * 0.78, h * 0.50, 1.0);
    c(w * 0.20, h * 0.44, 0.7);
    c(w * 0.62, h * 0.68, 0.85);
  }

  void _plane(Canvas canvas, Offset at) {
    final p = Paint()..color = AppColors.white.withValues(alpha: 0.95);
    final shade = Paint()..color = AppColors.eagleBlue.withValues(alpha: 0.5);
    canvas.drawPath(
      Path()
        ..moveTo(at.dx - 12, at.dy - 8)
        ..lineTo(at.dx + 12, at.dy)
        ..lineTo(at.dx - 12, at.dy + 8)
        ..lineTo(at.dx - 6, at.dy)
        ..close(),
      p,
    );
    canvas.drawPath(
      Path()
        ..moveTo(at.dx - 6, at.dy)
        ..lineTo(at.dx + 12, at.dy)
        ..lineTo(at.dx - 12, at.dy + 8)
        ..close(),
      shade,
    );
  }

  void _bubble(Canvas canvas, Offset at, String text) {
    final bg = Paint()..color = AppColors.white.withValues(alpha: 0.9);
    final r = RRect.fromRectAndRadius(
      Rect.fromCenter(center: at, width: 46, height: 30),
      const Radius.circular(12),
    );
    canvas.drawRRect(r, bg);
    canvas.drawPath(
      Path()
        ..moveTo(at.dx - 6, at.dy + 15)
        ..lineTo(at.dx + 4, at.dy + 15)
        ..lineTo(at.dx - 2, at.dy + 23)
        ..close(),
      bg,
    );
    _glyph(canvas, text, at, 14, AppColors.eagleBlueDark);
  }

  void _landmarks(Canvas canvas, double w, double h) {
    final p = Paint()..color = AppColors.eagleBlueDark.withValues(alpha: 0.4);
    final baseY = h - h * 0.04;
    // Big Ben.
    canvas.drawRect(Rect.fromLTWH(w * 0.12, baseY - 70, 16, 70), p);
    canvas.drawPath(
      Path()
        ..moveTo(w * 0.12 - 3, baseY - 70)
        ..lineTo(w * 0.12 + 8, baseY - 86)
        ..lineTo(w * 0.12 + 19, baseY - 70)
        ..close(),
      p,
    );
    // Eiffel.
    final ex = w * 0.5;
    canvas.drawPath(
      Path()
        ..moveTo(ex - 22, baseY)
        ..lineTo(ex - 6, baseY - 80)
        ..lineTo(ex + 6, baseY - 80)
        ..lineTo(ex + 22, baseY)
        ..moveTo(ex - 14, baseY - 38)
        ..lineTo(ex + 14, baseY - 38),
      Paint()
        ..color = p.color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3,
    );
    // Pyramid.
    canvas.drawPath(
      Path()
        ..moveTo(w * 0.82, baseY)
        ..lineTo(w * 0.9, baseY - 56)
        ..lineTo(w * 0.98, baseY)
        ..close(),
      p,
    );
  }

  void _dashed(Canvas canvas, Path src, Paint paint) {
    for (final m in src.computeMetrics()) {
      var d = 0.0;
      while (d < m.length) {
        final n = (d + 7).clamp(0.0, m.length);
        canvas.drawPath(m.extractPath(d, n), paint);
        d = n + 7;
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

// ---------------------------------------------------------------------------
// PHYSICS — cosmic lab
// ---------------------------------------------------------------------------

class _PhysicsScene extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    _softStars(canvas, w, h, 60, 13);

    // Planets with glow.
    _planet(canvas, Offset(w * 0.80, h * 0.10), 30, AppColors.coral, ring: true);
    _planet(canvas, Offset(w * 0.18, h * 0.30), 16, AppColors.steppeGold);
    _planet(canvas, Offset(w * 0.86, h * 0.62), 12, AppColors.cosmicPurpleLight);

    // Atom (orbits + electrons) mid-map.
    _atom(canvas, Offset(w * 0.30, h * 0.50), 40);

    // Energy sine waves.
    final wave = Paint()
      ..color = AppColors.steppeGoldLight.withValues(alpha: 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    for (final cfg in [(h * 0.74, 14.0), (h * 0.80, 9.0)]) {
      final path = Path()..moveTo(0, cfg.$1);
      for (double x = 0; x <= w; x += 6) {
        path.lineTo(x, cfg.$1 + math.sin(x / 22) * cfg.$2);
      }
      canvas.drawPath(path, wave);
    }

    // Comet.
    final comet = Paint()
      ..color = AppColors.white.withValues(alpha: 0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(w * 0.55, h * 0.22), Offset(w * 0.68, h * 0.16), comet);
    canvas.drawCircle(Offset(w * 0.68, h * 0.16), 3,
        Paint()..color = AppColors.white.withValues(alpha: 0.95));

    _glyph(canvas, 'E=mc²', Offset(w * 0.7, h * 0.42), 20,
        AppColors.white.withValues(alpha: 0.45));
    _glyph(canvas, 'F=ma', Offset(w * 0.22, h * 0.68), 16,
        AppColors.white.withValues(alpha: 0.4));
  }

  void _planet(Canvas canvas, Offset c, double r, Color color, {bool ring = false}) {
    canvas.drawCircle(c, r * 1.8,
        Paint()
          ..shader = RadialGradient(colors: [
            color.withValues(alpha: 0.5),
            color.withValues(alpha: 0.0),
          ]).createShader(Rect.fromCircle(center: c, radius: r * 1.8)));
    canvas.drawCircle(c, r, Paint()..color = color.withValues(alpha: 0.85));
    canvas.drawCircle(Offset(c.dx - r * 0.3, c.dy - r * 0.3), r * 0.4,
        Paint()..color = AppColors.white.withValues(alpha: 0.25));
    if (ring) {
      canvas.save();
      canvas.translate(c.dx, c.dy);
      canvas.rotate(-0.4);
      canvas.drawOval(
        Rect.fromCenter(center: Offset.zero, width: r * 3.4, height: r * 1.1),
        Paint()
          ..color = AppColors.steppeGoldLight.withValues(alpha: 0.6)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3,
      );
      canvas.restore();
    }
  }

  void _atom(Canvas canvas, Offset c, double r) {
    final orbit = Paint()
      ..color = AppColors.eagleBlueLight.withValues(alpha: 0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6;
    final electron = Paint()..color = AppColors.eagleBlueLight;
    for (var i = 0; i < 3; i++) {
      canvas.save();
      canvas.translate(c.dx, c.dy);
      canvas.rotate(i * math.pi / 3);
      final rect = Rect.fromCenter(center: Offset.zero, width: r * 2, height: r * 0.7);
      canvas.drawOval(rect, orbit);
      canvas.drawCircle(Offset(r, 0), 3.5, electron);
      canvas.restore();
    }
    canvas.drawCircle(c, 6, Paint()..color = AppColors.steppeGoldLight);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

// ---------------------------------------------------------------------------
// INFORMATICS — cyber grid
// ---------------------------------------------------------------------------

class _InformaticsScene extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // Binary rain columns (faint).
    final rng = math.Random(42);
    final dim = AppColors.jadeLight.withValues(alpha: 0.16);
    for (var col = 0; col < 7; col++) {
      final x = (col + 0.5) * w / 7 + rng.nextDouble() * 10 - 5;
      final startY = rng.nextDouble() * 60;
      for (double y = startY; y < h; y += 26) {
        _glyph(canvas, rng.nextBool() ? '1' : '0', Offset(x, y), 13, dim);
      }
    }

    // Circuit traces with right-angle bends and node dots.
    final trace = Paint()
      ..color = AppColors.cosmicPurpleLight.withValues(alpha: 0.45)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8
      ..strokeJoin = StrokeJoin.round;
    final node = Paint()..color = AppColors.jadeLight.withValues(alpha: 0.85);

    final tr = math.Random(9);
    for (double y = h * 0.08; y < h - 60; y += 120) {
      final fromLeft = tr.nextBool();
      final x0 = fromLeft ? 10.0 : w - 10;
      final dir = fromLeft ? 1 : -1;
      final mid = x0 + dir * (w * (0.30 + tr.nextDouble() * 0.25));
      final y2 = y + 40 + tr.nextDouble() * 30;
      final path = Path()
        ..moveTo(x0, y)
        ..lineTo(mid, y)
        ..lineTo(mid, y2)
        ..lineTo(mid + dir * 40, y2);
      canvas.drawPath(path, trace);
      canvas.drawCircle(Offset(mid, y), 3.5, node);
      canvas.drawCircle(Offset(mid + dir * 40, y2), 3, node);
      // Glow on the start node.
      canvas.drawCircle(Offset(mid, y), 7,
          Paint()..color = AppColors.jadeLight.withValues(alpha: 0.2));
    }

    // Floating code glyphs.
    final glyphCol = AppColors.cosmicPurpleLight.withValues(alpha: 0.55);
    _glyph(canvas, '</>', Offset(w * 0.22, h * 0.16), 24, glyphCol);
    _glyph(canvas, '{ }', Offset(w * 0.80, h * 0.30), 22, glyphCol);
    _glyph(canvas, '01', Offset(w * 0.18, h * 0.46), 20, glyphCol);
    _glyph(canvas, '#', Offset(w * 0.82, h * 0.58), 24, glyphCol);
    _glyph(canvas, '< />', Offset(w * 0.26, h * 0.74), 18, glyphCol);

    // Pixel sparkles.
    final px = Paint()..color = AppColors.jadeLight.withValues(alpha: 0.5);
    final pr = math.Random(77);
    for (var i = 0; i < 16; i++) {
      final x = pr.nextDouble() * w;
      final y = pr.nextDouble() * h;
      canvas.drawRect(Rect.fromCenter(center: Offset(x, y), width: 4, height: 4), px);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}
