import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/question.dart';
import 'task_question_card.dart';

/// "Дұрыс ✓ / Қате ✗" task — two large buttons side by side.
class TrueFalseTask extends StatefulWidget {
  final Question question;
  final bool locked;
  final bool? revealedSelection;
  final void Function(bool answer, bool correct) onAnswered;

  const TrueFalseTask({
    super.key,
    required this.question,
    required this.locked,
    required this.onAnswered,
    this.revealedSelection,
  });

  @override
  State<TrueFalseTask> createState() => _TrueFalseTaskState();
}

class _TrueFalseTaskState extends State<TrueFalseTask> {
  bool? _selected;

  void _pick(bool value) {
    if (widget.locked) return;
    setState(() => _selected = value);
    widget.onAnswered(value, widget.question.isCorrectBool(value));
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final selected = widget.revealedSelection ?? _selected;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TaskQuestionCard(label: 'Дұрыс па, қате ме?', prompt: q.prompt),
        AppSpacing.gapV24,
        Row(
          children: [
            Expanded(
              child: _TfButton(
                label: 'Дұрыс',
                icon: Icons.check_rounded,
                color: AppColors.jade,
                isCorrectAnswer: q.answerIsTrue,
                isSelected: selected == true,
                locked: widget.locked,
                onTap: () => _pick(true),
              ),
            ),
            AppSpacing.gapH12,
            Expanded(
              child: _TfButton(
                label: 'Қате',
                icon: Icons.close_rounded,
                color: AppColors.coral,
                isCorrectAnswer: !q.answerIsTrue,
                isSelected: selected == false,
                locked: widget.locked,
                onTap: () => _pick(false),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _TfButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final bool isCorrectAnswer;
  final bool isSelected;
  final bool locked;
  final VoidCallback onTap;

  const _TfButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.isCorrectAnswer,
    required this.isSelected,
    required this.locked,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Color background = AppColors.surface;
    Color border = AppColors.border;
    Color content = color;

    if (locked) {
      if (isCorrectAnswer) {
        background = AppColors.jadeSurface;
        border = AppColors.jade;
        content = AppColors.jade;
      } else if (isSelected) {
        background = AppColors.coralSurface;
        border = AppColors.coral;
        content = AppColors.coral;
      }
    } else if (isSelected) {
      background = color.withValues(alpha: 0.10);
      border = color;
    }

    return Material(
      color: background,
      borderRadius: AppRadius.radiusLg,
      child: InkWell(
        onTap: onTap,
        borderRadius: AppRadius.radiusLg,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 22),
          decoration: BoxDecoration(
            borderRadius: AppRadius.radiusLg,
            border: Border.all(color: border, width: 2),
          ),
          child: Column(
            children: [
              Icon(icon, color: content, size: 36),
              AppSpacing.gapV4,
              Text(
                label,
                style: AppTypography.body.copyWith(
                  color: content,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
