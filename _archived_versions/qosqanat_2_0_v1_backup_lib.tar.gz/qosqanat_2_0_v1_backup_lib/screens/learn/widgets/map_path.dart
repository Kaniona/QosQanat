import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';

/// Smooth S-curved gradient ribbon connecting every node on the map. The
/// ribbon is tinted with the subject's [accent] so each subject's trail reads
/// as its own.
class MapPath extends StatelessWidget {
  final List<Offset> nodeCenters;
  final double width;
  final double height;
  final Color accent;

  const MapPath({
    super.key,
    required this.nodeCenters,
    required this.width,
    required this.height,
    this.accent = AppColors.steppeGold,
  });

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: CustomPaint(
        size: Size(width, height),
        painter: _MapPathPainter(nodeCenters, accent),
      ),
    );
  }
}

class _MapPathPainter extends CustomPainter {
  final List<Offset> centers;
  final Color accent;
  _MapPathPainter(this.centers, this.accent);

  @override
  void paint(Canvas canvas, Size size) {
    if (centers.length < 2) return;
    final path = Path()..moveTo(centers.first.dx, centers.first.dy);
    for (var i = 0; i < centers.length - 1; i++) {
      final p0 = centers[i];
      final p1 = centers[i + 1];
      final mid = Offset(p0.dx, (p0.dy + p1.dy) / 2);
      final c1 = Offset(p0.dx, mid.dy);
      final c2 = Offset(p1.dx, mid.dy);
      path.cubicTo(c1.dx, c1.dy, c2.dx, c2.dy, p1.dx, p1.dy);
    }

    // Outer halo (soft).
    final halo = Paint()
      ..color = AppColors.white.withValues(alpha: 0.18)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 22
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(path, halo);

    // Inner gradient stroke — tinted by the subject accent.
    final rect = path.getBounds();
    final shader = LinearGradient(
      begin: Alignment.bottomCenter,
      end: Alignment.topCenter,
      colors: [
        AppColors.white.withValues(alpha: 0.9),
        accent,
        accent,
      ],
    ).createShader(rect);
    final ribbon = Paint()
      ..shader = shader
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(path, ribbon);

    // Dashed center highlight to suggest travel.
    final dash = Paint()
      ..color = AppColors.white.withValues(alpha: 0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    _drawDashed(canvas, path, dash);
  }

  void _drawDashed(Canvas canvas, Path src, Paint paint) {
    const dashLen = 8.0;
    const gapLen = 10.0;
    for (final metric in src.computeMetrics()) {
      var distance = 0.0;
      while (distance < metric.length) {
        final next = (distance + dashLen).clamp(0.0, metric.length);
        canvas.drawPath(metric.extractPath(distance, next), paint);
        distance = next + gapLen;
      }
    }
  }

  @override
  bool shouldRepaint(covariant _MapPathPainter old) =>
      old.centers != centers || old.accent != accent;
}
