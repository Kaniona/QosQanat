import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';

/// A horizontal oyu-ornek-decorated banner separating two modules on the map.
/// Used for "5-сынып модулі аяқталды!" style headlines.
class ModuleBanner extends StatelessWidget {
  final String text;

  const ModuleBanner({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [
              AppColors.steppeGoldDark,
              AppColors.steppeGold,
              AppColors.steppeGoldDark,
            ],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: AppColors.steppeGoldLight.withValues(alpha: 0.8),
            width: 1.5,
          ),
          boxShadow: const [
            BoxShadow(
              color: AppColors.shadowMedium,
              blurRadius: 12,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const _Ornament(flip: false),
            const SizedBox(width: 12),
            Flexible(
              child: Text(
                text,
                style: AppTypography.body.copyWith(
                  color: AppColors.white,
                  fontWeight: FontWeight.w800,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(width: 12),
            const _Ornament(flip: true),
          ],
        ),
      ),
    );
  }
}

class _Ornament extends StatelessWidget {
  final bool flip;
  const _Ornament({required this.flip});

  @override
  Widget build(BuildContext context) {
    return Transform(
      transform: Matrix4.identity()..scaleByDouble(flip ? -1.0 : 1.0, 1.0, 1.0, 1.0),
      alignment: Alignment.center,
      child: CustomPaint(
        size: const Size(30, 18),
        painter: _OrnamentPainter(),
      ),
    );
  }
}

class _OrnamentPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.white.withValues(alpha: 0.95)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;
    final midY = size.height / 2;
    final path = Path()
      ..moveTo(0, midY)
      ..lineTo(size.width * 0.55, midY)
      ..moveTo(size.width * 0.55, midY)
      ..quadraticBezierTo(
        size.width * 0.65, 0, size.width * 0.85, midY,
      )
      ..quadraticBezierTo(
        size.width * 0.95, size.height, size.width, midY,
      );
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
