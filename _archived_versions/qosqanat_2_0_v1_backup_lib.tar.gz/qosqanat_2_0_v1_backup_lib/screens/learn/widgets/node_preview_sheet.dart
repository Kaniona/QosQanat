import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../data/curriculum.dart';
import '../../../models/enums.dart';

/// Bottom sheet shown when the player taps an available / current node before
/// starting it: title, type, description, rewards, question count and the
/// "Бастау →" CTA.
class NodePreviewSheet extends StatelessWidget {
  final CurriculumNode node;
  final Subject subject;
  final VoidCallback onStart;

  const NodePreviewSheet({
    super.key,
    required this.node,
    required this.subject,
    required this.onStart,
  });

  String get _typeLabel {
    switch (node.type) {
      case NodeType.lesson:
        return 'Сабақ';
      case NodeType.quiz:
        return 'Сынақ';
      case NodeType.boss:
        return 'Босс';
      case NodeType.treasure:
        return 'Қазына';
    }
  }

  String get _typeEmoji {
    switch (node.type) {
      case NodeType.lesson:
        return '📘';
      case NodeType.quiz:
        return '⚡';
      case NodeType.boss:
        return '🐉';
      case NodeType.treasure:
        return '💎';
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg,
          AppSpacing.sm,
          AppSpacing.lg,
          AppSpacing.lg,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 48,
                height: 5,
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
            ),
            AppSpacing.gapV16,
            Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    gradient: subject.cardGradient,
                    borderRadius: AppRadius.radiusMd,
                  ),
                  child: Center(
                    child: Text(
                      _typeEmoji,
                      style: const TextStyle(fontSize: 28),
                    ),
                  ),
                ),
                AppSpacing.gapH12,
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: subject.color.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          _typeLabel,
                          style: AppTypography.caption.copyWith(
                            color: subject.color,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      AppSpacing.gapV4,
                      Text(node.title, style: AppTypography.h3),
                    ],
                  ),
                ),
              ],
            ),
            AppSpacing.gapV16,
            Text(node.description, style: AppTypography.bodySecondary),
            AppSpacing.gapV20,
            Row(
              children: [
                _RewardPill(
                  icon: Icons.auto_graph_rounded,
                  color: AppColors.cosmicPurple,
                  label: '+${node.xpReward} XP',
                ),
                AppSpacing.gapH8,
                _RewardPill(
                  icon: Icons.monetization_on_rounded,
                  color: AppColors.steppeGold,
                  label: '+${node.coinReward}',
                ),
                AppSpacing.gapH8,
                _RewardPill(
                  icon: Icons.star_rounded,
                  color: AppColors.eagleBlue,
                  label: '+${node.akylReward}',
                ),
              ],
            ),
            AppSpacing.gapV12,
            Row(
              children: [
                const Icon(Icons.help_outline_rounded,
                    color: AppColors.textSecondary, size: 18),
                AppSpacing.gapH4,
                Text(
                  '${node.questions.length} сұрақ',
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
            AppSpacing.gapV20,
            SizedBox(
              width: double.infinity,
              height: 54,
              child: FilledButton(
                onPressed: onStart,
                style: FilledButton.styleFrom(
                  backgroundColor: subject.color,
                  shape: RoundedRectangleBorder(
                    borderRadius: AppRadius.radiusLg,
                  ),
                ),
                child: const Text(
                  'Бастау  →',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    color: AppColors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RewardPill extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;

  const _RewardPill({
    required this.icon,
    required this.color,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 5),
          Text(
            label,
            style: AppTypography.caption.copyWith(
              color: color,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}
