import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/question.dart';
import 'task_question_card.dart';

/// Fill-in-the-blank task: the prompt contains "___" which is replaced by the
/// selected word chip. The student taps a chip from the word bank to commit.
class FillInBlankTask extends StatefulWidget {
  final Question question;
  final bool locked;
  final String? revealedSelection;
  final void Function(String word, bool correct) onAnswered;

  const FillInBlankTask({
    super.key,
    required this.question,
    required this.locked,
    required this.onAnswered,
    this.revealedSelection,
  });

  @override
  State<FillInBlankTask> createState() => _FillInBlankTaskState();
}

class _FillInBlankTaskState extends State<FillInBlankTask> {
  String? _selected;

  void _pick(String word) {
    if (widget.locked) return;
    setState(() => _selected = word);
    widget.onAnswered(word, widget.question.isCorrectWord(word));
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final selected = widget.revealedSelection ?? _selected;
    final filled = selected == null
        ? q.prompt.replaceAll('___', '_____')
        : q.prompt.replaceAll('___', selected);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TaskQuestionCard(label: 'Бос орынды толтыр', prompt: filled),
        AppSpacing.gapV20,
        Text(
          'Сөздерден таңда:',
          style: AppTypography.caption,
        ),
        AppSpacing.gapV8,
        Wrap(
          spacing: AppSpacing.xs,
          runSpacing: AppSpacing.xs,
          children: q.wordBank.map((w) {
            final isSelected = selected == w;
            final isCorrect = w == q.blankAnswer;
            Color background = AppColors.surface;
            Color border = AppColors.border;
            Color text = AppColors.textPrimary;
            if (widget.locked) {
              if (isCorrect) {
                background = AppColors.jadeSurface;
                border = AppColors.jade;
                text = AppColors.jadeDark;
              } else if (isSelected) {
                background = AppColors.coralSurface;
                border = AppColors.coral;
                text = AppColors.coralDark;
              }
            } else if (isSelected) {
              background = AppColors.eagleBlueSurface;
              border = AppColors.eagleBlue;
              text = AppColors.eagleBlue;
            }

            return Material(
              color: background,
              borderRadius: AppRadius.radiusMd,
              child: InkWell(
                onTap: () => _pick(w),
                borderRadius: AppRadius.radiusMd,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius: AppRadius.radiusMd,
                    border: Border.all(color: border, width: 1.6),
                  ),
                  child: Text(
                    w,
                    style: AppTypography.body.copyWith(
                      color: text,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}
