import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/question.dart';
import 'task_question_card.dart';

/// 4-option multiple-choice task. The parent owns lock state via [locked] and
/// is notified with the chosen index + correctness via [onAnswered].
class MultipleChoiceTask extends StatefulWidget {
  final Question question;
  final bool locked;
  final int? revealedSelection;
  final void Function(int index, bool correct) onAnswered;

  const MultipleChoiceTask({
    super.key,
    required this.question,
    required this.locked,
    required this.onAnswered,
    this.revealedSelection,
  });

  @override
  State<MultipleChoiceTask> createState() => _MultipleChoiceTaskState();
}

class _MultipleChoiceTaskState extends State<MultipleChoiceTask> {
  int? _selected;

  void _select(int i) {
    if (widget.locked) return;
    setState(() => _selected = i);
    final correct = widget.question.isCorrectIndex(i);
    widget.onAnswered(i, correct);
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final selected = widget.revealedSelection ?? _selected;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TaskQuestionCard(label: 'Сұрақ', prompt: q.prompt),
        AppSpacing.gapV20,
        ...List.generate(q.options.length, (i) {
          final isSelected = selected == i;
          final isCorrect = i == q.correctIndex;

          Color? bg;
          Color? border;
          IconData? trailing;
          Color? trailingColor;
          if (widget.locked) {
            if (isCorrect) {
              bg = AppColors.jadeSurface;
              border = AppColors.jade;
              trailing = Icons.check_circle_rounded;
              trailingColor = AppColors.jade;
            } else if (isSelected && !isCorrect) {
              bg = AppColors.coralSurface;
              border = AppColors.coral;
              trailing = Icons.cancel_rounded;
              trailingColor = AppColors.coral;
            }
          } else if (isSelected) {
            bg = AppColors.eagleBlueSurface;
            border = AppColors.eagleBlue;
          }

          final card = _OptionCard(
            label: q.options[i],
            background: bg,
            borderColor: border,
            trailing: trailing,
            trailingColor: trailingColor,
            onTap: () => _select(i),
          );

          // A subtle "pop" highlight when revealed.
          if (widget.locked && (isCorrect || (isSelected && !isCorrect))) {
            return Padding(
              padding: const EdgeInsets.only(bottom: AppSpacing.sm),
              child: card
                  .animate()
                  .scaleXY(begin: 0.97, end: 1.0, duration: 280.ms, curve: Curves.easeOut),
            );
          }
          return Padding(
            padding: const EdgeInsets.only(bottom: AppSpacing.sm),
            child: card,
          );
        }),
      ],
    );
  }
}

class _OptionCard extends StatelessWidget {
  final String label;
  final Color? background;
  final Color? borderColor;
  final IconData? trailing;
  final Color? trailingColor;
  final VoidCallback onTap;

  const _OptionCard({
    required this.label,
    required this.onTap,
    this.background,
    this.borderColor,
    this.trailing,
    this.trailingColor,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: background ?? AppColors.surface,
      borderRadius: AppRadius.radiusLg,
      child: InkWell(
        onTap: onTap,
        borderRadius: AppRadius.radiusLg,
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.md,
            vertical: AppSpacing.md,
          ),
          decoration: BoxDecoration(
            borderRadius: AppRadius.radiusLg,
            border: Border.all(
              color: borderColor ?? AppColors.border,
              width: borderColor == null ? 1.2 : 2,
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  style: AppTypography.body.copyWith(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              if (trailing != null) ...[
                AppSpacing.gapH8,
                Icon(trailing, color: trailingColor, size: 22),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
