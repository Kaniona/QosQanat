import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_motion.dart';
import '../../../data/curriculum.dart';
import '../../../models/enums.dart';
import '../../../providers/learn_progress_provider.dart';
import '../../../widgets/ui/pressable.dart';

/// Visual state for a node on the map.
enum NodeVisualState { locked, available, current, completed, mastered }

NodeVisualState resolveNodeState({
  required CurriculumNode node,
  required NodeProgress? progress,
  required bool isUnlocked,
  required bool isCurrent,
}) {
  if (progress?.isMastered ?? false) return NodeVisualState.mastered;
  if (progress?.isCompleted ?? false) return NodeVisualState.completed;
  if (isCurrent) return NodeVisualState.current;
  if (isUnlocked) return NodeVisualState.available;
  return NodeVisualState.locked;
}

/// A round map node — the colored circle with the type emoji, hover halos for
/// the active node, the lock for locked nodes, and a small stars row for
/// mastered ones.
class MapNode extends StatelessWidget {
  final CurriculumNode node;
  final NodeVisualState state;
  final VoidCallback onTap;
  final double size;

  /// Subject accent used to tint unlocked-but-not-yet-played ("available")
  /// nodes so each subject's map reads in its own color.
  final Color accent;

  const MapNode({
    super.key,
    required this.node,
    required this.state,
    required this.onTap,
    this.size = 72,
    this.accent = AppColors.eagleBlue,
  });

  bool get _isBoss => node.type == NodeType.boss;
  double get _effectiveSize => _isBoss ? size + 16 : size;

  @override
  Widget build(BuildContext context) {
    final s = _effectiveSize;
    return SizedBox(
      width: s + 24,
      height: s +
          switch (state) {
            NodeVisualState.mastered => 28.0,
            NodeVisualState.current => 34.0,
            _ => 18.0,
          },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _circle(s),
          if (state == NodeVisualState.mastered) ...[
            const SizedBox(height: 3),
            const _StarsRow(stars: 3),
          ],
          if (state == NodeVisualState.current) ...[
            const SizedBox(height: 3),
            const _StartLabel(),
          ],
        ],
      ),
    );
  }

  Widget _circle(double s) {
    final base = _baseColors(state, _isBoss);
    final gradient = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: base.colors,
    );

    final core = Pressable(
      onTap: onTap,
      pressedScale: AppMotion.pressScaleStrong,
      child: Container(
        width: s,
        height: s,
        decoration: BoxDecoration(
          gradient: gradient,
          shape: BoxShape.circle,
          border: Border.all(color: AppColors.white, width: 3.5),
          boxShadow: [
            BoxShadow(
              color: base.colors.last.withValues(alpha: 0.45),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
            if (_isBoss)
              BoxShadow(
                color: AppColors.coral.withValues(alpha: 0.45),
                blurRadius: 30,
                spreadRadius: 2,
              ),
          ],
        ),
        child: Center(child: _icon()),
      ),
    );

    // Decorations layered around the circle.
    return SizedBox(
      width: s + 24,
      height: s + 8,
      child: Stack(
        alignment: Alignment.center,
        clipBehavior: Clip.none,
        children: [
          if (state == NodeVisualState.current) _PulseHalo(size: s),
          if (_isBoss) _BossCrown(size: s),
          if (_isBoss && state != NodeVisualState.locked) _BossAura(size: s),
          core,
          if (state == NodeVisualState.completed ||
              state == NodeVisualState.mastered)
            _CompletedBadge(size: s),
        ],
      ),
    );
  }

  Widget _icon() {
    if (state == NodeVisualState.locked) {
      return const Icon(Icons.lock_rounded, color: AppColors.white, size: 28);
    }
    final emoji = switch (node.type) {
      NodeType.lesson => '📘',
      NodeType.quiz => '⚡',
      NodeType.boss => '🐉',
      NodeType.treasure => '💎',
    };
    return Text(
      emoji,
      style: TextStyle(fontSize: _isBoss ? 38 : 30),
    );
  }

  ({List<Color> colors}) _baseColors(NodeVisualState s, bool boss) {
    switch (s) {
      case NodeVisualState.locked:
        return (colors: [AppColors.textTertiary, AppColors.borderStrong]);
      case NodeVisualState.available:
        return (
          colors: [
            Color.lerp(accent, AppColors.white, 0.32)!,
            accent,
          ],
        );
      case NodeVisualState.current:
        return (
          colors: [AppColors.steppeGoldLight, AppColors.steppeGold],
        );
      case NodeVisualState.completed:
        return (colors: [AppColors.jadeLight, AppColors.jade]);
      case NodeVisualState.mastered:
        return (colors: [AppColors.steppeGoldLight, AppColors.steppeGold]);
    }
  }
}

class _StartLabel extends StatelessWidget {
  const _StartLabel();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        color: AppColors.steppeGold,
        borderRadius: BorderRadius.circular(999),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowMedium,
            blurRadius: 6,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: const Text(
        'Бастау',
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          color: AppColors.white,
        ),
      ),
    );
  }
}

class _PulseHalo extends StatelessWidget {
  final double size;
  const _PulseHalo({required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size + 22,
      height: size + 22,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: AppColors.steppeGold.withValues(alpha: 0.25),
      ),
    )
        .animate(onPlay: (c) => c.repeat(reverse: true))
        .scaleXY(begin: 1.0, end: 1.18, duration: 1100.ms, curve: Curves.easeInOut)
        .fade(begin: 0.55, end: 0.15, duration: 1100.ms);
  }
}

class _BossCrown extends StatelessWidget {
  final double size;
  const _BossCrown({required this.size});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: -2,
      child: Text(
        '👑',
        style: TextStyle(fontSize: size * 0.32),
      ),
    );
  }
}

class _BossAura extends StatelessWidget {
  final double size;
  const _BossAura({required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size + 28,
      height: size + 28,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            AppColors.coral.withValues(alpha: 0.35),
            AppColors.coral.withValues(alpha: 0.0),
          ],
        ),
      ),
    );
  }
}

class _CompletedBadge extends StatelessWidget {
  final double size;
  const _CompletedBadge({required this.size});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      right: 6,
      bottom: -2,
      child: Container(
        width: 22,
        height: 22,
        decoration: BoxDecoration(
          color: AppColors.jade,
          shape: BoxShape.circle,
          border: Border.all(color: AppColors.white, width: 2),
        ),
        child: const Icon(Icons.check_rounded, size: 14, color: AppColors.white),
      ),
    );
  }
}

class _StarsRow extends StatelessWidget {
  final int stars;
  const _StarsRow({required this.stars});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 0; i < 3; i++)
          Icon(
            Icons.star_rounded,
            size: 14,
            color: i < stars
                ? AppColors.steppeGoldLight
                : AppColors.white.withValues(alpha: 0.35),
          ),
      ],
    );
  }
}
