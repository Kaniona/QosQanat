import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/question.dart';
import 'task_question_card.dart';

/// Two-column matching task with animated lines drawn between picked pairs.
///
/// Player taps a left chip, then a right chip; an instant line connects them.
/// When all pairs are matched the question is auto-submitted as correct iff
/// every pairing matches the source-of-truth in [Question.pairs].
class MatchPairsTask extends StatefulWidget {
  final Question question;
  final bool locked;
  final void Function(bool correct) onCompleted;

  const MatchPairsTask({
    super.key,
    required this.question,
    required this.locked,
    required this.onCompleted,
  });

  @override
  State<MatchPairsTask> createState() => _MatchPairsTaskState();
}

class _MatchPairsTaskState extends State<MatchPairsTask> {
  late final List<String> _lefts;
  late final List<String> _rights;
  late final List<GlobalKey> _leftKeys;
  late final List<GlobalKey> _rightKeys;
  final GlobalKey _stackKey = GlobalKey();

  /// leftIndex -> rightIndex.
  final Map<int, int> _pairs = {};
  int? _pendingLeft;
  bool _submitted = false;

  @override
  void initState() {
    super.initState();
    _lefts = widget.question.pairs.map((p) => p.left).toList();
    _rights = widget.question.pairs.map((p) => p.right).toList()..shuffle();
    _leftKeys = List.generate(_lefts.length, (_) => GlobalKey());
    _rightKeys = List.generate(_rights.length, (_) => GlobalKey());
  }

  void _tapLeft(int i) {
    if (widget.locked || _submitted) return;
    setState(() {
      _pairs.remove(i);
      _pendingLeft = i;
    });
  }

  void _tapRight(int i) {
    if (widget.locked || _submitted) return;
    if (_pendingLeft == null) return;
    setState(() {
      _pairs.removeWhere((_, v) => v == i);
      _pairs[_pendingLeft!] = i;
      _pendingLeft = null;
    });
    if (_pairs.length == _lefts.length) _submit();
  }

  void _submit() {
    final source = widget.question.pairs;
    var correct = true;
    for (final entry in _pairs.entries) {
      final left = _lefts[entry.key];
      final right = _rights[entry.value];
      final expected = source.firstWhere(
        (p) => p.left == left,
        orElse: () => const MatchPair('', ''),
      );
      if (expected.right != right) {
        correct = false;
        break;
      }
    }
    setState(() => _submitted = true);
    widget.onCompleted(correct);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      key: _stackKey,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TaskQuestionCard(
              label: 'Жұптарды сәйкестендір',
              prompt: widget.question.prompt,
            ),
            AppSpacing.gapV20,
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    children: List.generate(_lefts.length, (i) {
                      return _ChipTile(
                        key: _leftKeys[i],
                        label: _lefts[i],
                        active: _pendingLeft == i,
                        matched: _pairs.containsKey(i),
                        side: _ChipSide.left,
                        onTap: () => _tapLeft(i),
                      );
                    }),
                  ),
                ),
                const SizedBox(width: 64),
                Expanded(
                  child: Column(
                    children: List.generate(_rights.length, (i) {
                      return _ChipTile(
                        key: _rightKeys[i],
                        label: _rights[i],
                        active: false,
                        matched: _pairs.values.contains(i),
                        side: _ChipSide.right,
                        onTap: () => _tapRight(i),
                      );
                    }),
                  ),
                ),
              ],
            ),
          ],
        ),
        Positioned.fill(
          child: IgnorePointer(
            child: CustomPaint(
              painter: _LinesPainter(
                stackKey: _stackKey,
                leftKeys: _leftKeys,
                rightKeys: _rightKeys,
                pairs: _pairs,
                color: _submitted
                    ? (_allMatchesCorrect ? AppColors.jade : AppColors.coral)
                    : AppColors.eagleBlue,
              ),
            ),
          ),
        ),
      ],
    );
  }

  bool get _allMatchesCorrect {
    final source = widget.question.pairs;
    for (final entry in _pairs.entries) {
      final left = _lefts[entry.key];
      final right = _rights[entry.value];
      final expected = source.firstWhere(
        (p) => p.left == left,
        orElse: () => const MatchPair('', ''),
      );
      if (expected.right != right) return false;
    }
    return true;
  }
}

enum _ChipSide { left, right }

class _ChipTile extends StatelessWidget {
  final String label;
  final bool active;
  final bool matched;
  final _ChipSide side;
  final VoidCallback onTap;

  const _ChipTile({
    super.key,
    required this.label,
    required this.active,
    required this.matched,
    required this.side,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Color background = AppColors.surface;
    Color border = AppColors.border;
    if (matched) {
      background = AppColors.eagleBlueSurface;
      border = AppColors.eagleBlue;
    } else if (active) {
      background = AppColors.steppeGoldSurface;
      border = AppColors.steppeGold;
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Material(
        color: background,
        borderRadius: AppRadius.radiusMd,
        child: InkWell(
          onTap: onTap,
          borderRadius: AppRadius.radiusMd,
          child: Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 12, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: AppRadius.radiusMd,
              border: Border.all(color: border, width: 1.6),
            ),
            child: Align(
              alignment: side == _ChipSide.left
                  ? Alignment.centerLeft
                  : Alignment.centerRight,
              child: Text(
                label,
                style: AppTypography.body.copyWith(
                  fontWeight: FontWeight.w800,
                ),
                textAlign: side == _ChipSide.left
                    ? TextAlign.left
                    : TextAlign.right,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _LinesPainter extends CustomPainter {
  final GlobalKey stackKey;
  final List<GlobalKey> leftKeys;
  final List<GlobalKey> rightKeys;
  final Map<int, int> pairs;
  final Color color;

  _LinesPainter({
    required this.stackKey,
    required this.leftKeys,
    required this.rightKeys,
    required this.pairs,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final stackBox = stackKey.currentContext?.findRenderObject();
    if (stackBox is! RenderBox) return;

    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;

    for (final entry in pairs.entries) {
      final l = leftKeys[entry.key].currentContext?.findRenderObject();
      final r = rightKeys[entry.value].currentContext?.findRenderObject();
      if (l is! RenderBox || r is! RenderBox) continue;

      final lLocal = stackBox.globalToLocal(
        l.localToGlobal(Offset(l.size.width, l.size.height / 2)),
      );
      final rLocal = stackBox.globalToLocal(
        r.localToGlobal(Offset(0, r.size.height / 2)),
      );

      final path = Path()
        ..moveTo(lLocal.dx, lLocal.dy)
        ..cubicTo(
          lLocal.dx + 40, lLocal.dy,
          rLocal.dx - 40, rLocal.dy,
          rLocal.dx, rLocal.dy,
        );
      canvas.drawPath(path, paint);
      canvas.drawCircle(lLocal, 4, paint);
      canvas.drawCircle(rLocal, 4, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _LinesPainter old) =>
      old.pairs != pairs || old.color != color;
}
