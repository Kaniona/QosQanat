import 'package:flutter/material.dart';

import '../../../data/curriculum.dart';
import 'subject_scenes.dart';

/// Painted backdrop that fills the entire learning map. Each subject gets a
/// fully distinct themed world (see [sceneFor]) — math is a blueprint cosmos,
/// kazakh a steppe heritage, english a global voyage, physics a cosmic lab,
/// informatics a cyber grid — so no two subject maps look alike.
class MapBackground extends StatelessWidget {
  final Subject subject;
  final double height;

  const MapBackground({super.key, required this.subject, required this.height});

  @override
  Widget build(BuildContext context) {
    final scene = sceneFor(subject.id);
    return SizedBox(
      height: height,
      width: double.infinity,
      child: DecoratedBox(
        decoration: BoxDecoration(gradient: scene.gradient),
        child: CustomPaint(
          painter: scene.painter,
          size: Size.infinite,
        ),
      ),
    );
  }
}
