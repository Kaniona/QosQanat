import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';

/// Reusable header used by every task widget — a small "Сұрақ" label above the
/// question prompt.
class TaskQuestionCard extends StatelessWidget {
  final String label;
  final String prompt;

  const TaskQuestionCard({
    super.key,
    required this.label,
    required this.prompt,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusLg,
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: AppColors.eagleBlueSurface,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              label,
              style: AppTypography.caption.copyWith(
                color: AppColors.eagleBlue,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          AppSpacing.gapV12,
          Text(
            prompt,
            style: AppTypography.h3.copyWith(height: 1.35),
          ),
        ],
      ),
    );
  }
}
