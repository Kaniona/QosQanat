import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/curriculum.dart';
import '../../navigation/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../providers/game_provider.dart';
import '../../providers/learn_progress_provider.dart';
import '../../widgets/ui/aurora_background.dart';
import '../../widgets/ui/clay_container.dart';
import '../../widgets/ui/glass_panel.dart';
import '../../widgets/ui/pressable.dart';
import '../../widgets/ui/progress_ring.dart';
import 'subject_visuals.dart';

/// Tab 3 — "Оқу". A bento board of claymorphism subject cards over an aurora
/// backdrop: a greeting banner, a stat strip, one hero "continue" subject, and
/// a 2-up grid of the rest. Grade-gated to the student's school year.
class LearnScreen extends ConsumerStatefulWidget {
  const LearnScreen({super.key});

  @override
  ConsumerState<LearnScreen> createState() => _LearnScreenState();
}

class _LearnScreenState extends ConsumerState<LearnScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(learnProgressProvider.notifier).ensureLoaded();
    });
  }

  ({int completed, int total}) _tally(Subject subject) {
    final progress = ref.read(learnProgressProvider);
    final ids = subject.allNodes.map((n) => n.id);
    final completed =
        ids.where((id) => progress[id]?.isCompleted ?? false).length;
    return (completed: completed, total: subject.totalNodes);
  }

  @override
  Widget build(BuildContext context) {
    ref.watch(learnProgressProvider);
    final user = ref.watch(currentUserProvider).asData?.value;
    final game = ref.watch(gameProvider);

    final studentGrade = user?.grade ?? 7;
    final firstName = (user?.fullName.trim().split(' ').first ?? '').isEmpty
        ? 'оқушы'
        : user!.fullName.trim().split(' ').first;

    // The hero subject: first started-but-unfinished one, else the first.
    Subject hero = kCurriculum.first;
    for (final s in kCurriculum) {
      final t = _tally(s);
      if (t.completed > 0 && t.completed < t.total) {
        hero = s;
        break;
      }
    }
    final others = kCurriculum.where((s) => s.id != hero.id).toList();

    return Scaffold(
      body: AuroraBackground(
        light: true,
        child: SafeArea(
          bottom: false,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(
                AppSpacing.md, AppSpacing.md, AppSpacing.md, AppSpacing.xxxl),
            children: [
              _GreetingBanner(grade: studentGrade, name: firstName)
                  .animate()
                  .fadeIn(duration: 300.ms)
                  .moveY(begin: 14, end: 0, curve: Curves.easeOut),
              AppSpacing.gapV16,
              _StatStrip(
                level: game.level,
                akyl: game.akylPoints,
                streak: game.currentStreak,
              ).animate(delay: 80.ms).fadeIn(duration: 300.ms).moveY(begin: 14, end: 0),
              AppSpacing.gapV20,
              Padding(
                padding: const EdgeInsets.only(left: AppSpacing.xs),
                child: Text('Пәндер', style: AppTypography.h3),
              ),
              AppSpacing.gapV12,
              _HeroSubjectCard(
                subject: hero,
                tally: _tally(hero),
                studentGrade: studentGrade,
                onTap: () => context.push('${AppRoutes.learn}/${hero.id}'),
              ).animate(delay: 140.ms).fadeIn(duration: 340.ms).moveY(begin: 18, end: 0),
              AppSpacing.gapV12,
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: others.length,
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: AppSpacing.sm,
                  crossAxisSpacing: AppSpacing.sm,
                  childAspectRatio: 0.92,
                ),
                itemBuilder: (context, i) {
                  final s = others[i];
                  return _SmallSubjectCard(
                    subject: s,
                    tally: _tally(s),
                    studentGrade: studentGrade,
                    onTap: () => context.push('${AppRoutes.learn}/${s.id}'),
                  )
                      .animate(delay: (200 + 70 * i).ms)
                      .fadeIn(duration: 320.ms)
                      .moveY(begin: 18, end: 0, curve: Curves.easeOut);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Greeting banner
// ---------------------------------------------------------------------------

class _GreetingBanner extends StatelessWidget {
  final int grade;
  final String name;
  const _GreetingBanner({required this.grade, required this.name});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: AppRadius.xl,
      padding: const EdgeInsets.all(AppSpacing.md),
      child: Row(
        children: [
          ClayContainer(
            width: 60,
            height: 60,
            radius: 30,
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.eagleBlueLight, AppColors.eagleBlue],
            ),
            glow: const Color(0x802F4ECC),
            alignment: Alignment.center,
            child: const Text('🦅', style: TextStyle(fontSize: 30)),
          ),
          AppSpacing.gapH12,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('$grade-сынып оқушысы', style: AppTypography.h3),
                AppSpacing.gapV4,
                Text(
                  'Сәлем, $name! Бүгін нені меңгереміз? 💪',
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Stat strip
// ---------------------------------------------------------------------------

class _StatStrip extends StatelessWidget {
  final int level;
  final int akyl;
  final int streak;
  const _StatStrip(
      {required this.level, required this.akyl, required this.streak});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _StatTile(
            label: 'ЖАЛПЫ ДЕҢГЕЙ',
            value: '$level',
            color: AppColors.eagleBlue,
          ),
        ),
        AppSpacing.gapH8,
        Expanded(
          child: _StatTile(
            label: '⚡ АҚЫЛ',
            value: _fmt(akyl),
            color: AppColors.cosmicPurple,
          ),
        ),
        AppSpacing.gapH8,
        Expanded(
          child: _StatTile(
            label: '🔥 СЕРИЯ',
            value: '$streak',
            color: AppColors.sunset,
          ),
        ),
      ],
    );
  }

  static String _fmt(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write(' ');
      buf.write(s[i]);
    }
    return buf.toString();
  }
}

class _StatTile extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _StatTile(
      {required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: AppRadius.lg,
      padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.sm, vertical: AppSpacing.sm),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppTypography.caption.copyWith(
              fontSize: 10.5,
              fontWeight: FontWeight.w800,
              color: AppColors.textSecondary,
            ),
          ),
          AppSpacing.gapV4,
          Text(value,
              style: AppTypography.numberMedium.copyWith(color: color)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Subject helpers
// ---------------------------------------------------------------------------

String _gradeRange(Subject s) {
  final first = s.modules.first.grade;
  final last = s.modules.last.grade;
  return first == last ? '$first-сынып' : '$first–$last сынып';
}

bool _isGated(Subject s, int studentGrade) =>
    studentGrade < s.modules.first.grade;

// ---------------------------------------------------------------------------
// Hero subject card (big)
// ---------------------------------------------------------------------------

class _HeroSubjectCard extends StatelessWidget {
  final Subject subject;
  final ({int completed, int total}) tally;
  final int studentGrade;
  final VoidCallback onTap;

  const _HeroSubjectCard({
    required this.subject,
    required this.tally,
    required this.studentGrade,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final vis = SubjectVisuals.of(subject.id);
    final gated = _isGated(subject, studentGrade);
    final pct = tally.total == 0 ? 0.0 : tally.completed / tally.total;

    return Pressable(
      onTap: onTap,
      child: ClayContainer(
        radius: AppRadius.lg,
        gradient: vis.gradient,
        glow: vis.glow,
        clip: true,
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Stack(
          children: [
            Positioned(
              top: -30,
              right: -16,
              child: Text(vis.emoji,
                  style: TextStyle(
                      fontSize: 120,
                      color: Colors.white.withValues(alpha: 0.16))),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _Pill(
                  text: gated ? '🔒 Бұғатталған' : '⭐ Жалғастыр',
                  bg: Colors.white.withValues(alpha: 0.22),
                  fg: Colors.white,
                ),
                AppSpacing.gapV16,
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(vis.emoji,
                              style: const TextStyle(fontSize: 40)),
                          AppSpacing.gapV4,
                          Text(subject.name,
                              style: AppTypography.h2
                                  .copyWith(color: Colors.white)),
                          AppSpacing.gapV4,
                          Text(
                            '${_gradeRange(subject)} қолжетімді',
                            style: AppTypography.caption.copyWith(
                              color: Colors.white.withValues(alpha: 0.88),
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                    ProgressRing(
                      value: pct,
                      size: 72,
                      stroke: 8,
                      color: Colors.white,
                      trackColor: Colors.white.withValues(alpha: 0.28),
                      center: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('${tally.completed}/${tally.total}',
                              style: AppTypography.display(
                                  size: 14,
                                  weight: FontWeight.w800,
                                  color: Colors.white)),
                          Text('деңгей',
                              style: TextStyle(
                                  fontSize: 8,
                                  color:
                                      Colors.white.withValues(alpha: 0.8))),
                        ],
                      ),
                    ),
                  ],
                ),
                AppSpacing.gapV16,
                _MiniBar(value: pct),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniBar extends StatelessWidget {
  final double value;
  const _MiniBar({required this.value});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(99),
      child: Stack(
        children: [
          Container(height: 9, color: Colors.white.withValues(alpha: 0.25)),
          FractionallySizedBox(
            widthFactor: value.clamp(0, 1),
            child: Container(
              height: 9,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppColors.steppeGoldLight, AppColors.steppeGold],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Small subject card
// ---------------------------------------------------------------------------

class _SmallSubjectCard extends StatelessWidget {
  final Subject subject;
  final ({int completed, int total}) tally;
  final int studentGrade;
  final VoidCallback onTap;

  const _SmallSubjectCard({
    required this.subject,
    required this.tally,
    required this.studentGrade,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final vis = SubjectVisuals.of(subject.id);
    final gated = _isGated(subject, studentGrade);
    final pct = tally.total == 0 ? 0.0 : tally.completed / tally.total;

    return Pressable(
      onTap: onTap,
      child: Opacity(
        opacity: gated ? 0.7 : 1,
        child: ClayContainer(
          radius: AppRadius.lg,
          padding: const EdgeInsets.all(AppSpacing.md),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(vis.emoji, style: const TextStyle(fontSize: 32)),
              AppSpacing.gapV8,
              Text(subject.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.display(
                      size: 16,
                      weight: FontWeight.w800,
                      color: AppColors.textPrimary)),
              const SizedBox(height: 2),
              Text(
                gated ? '${subject.modules.first.grade} сыныптан' : 'қолжетімді',
                style: AppTypography.caption.copyWith(
                  fontSize: 11,
                  color: AppColors.textTertiary,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const Spacer(),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '${tally.completed}/${tally.total}',
                      style: AppTypography.display(
                          size: 13,
                          weight: FontWeight.w800,
                          color: vis.accent),
                    ),
                  ),
                  ProgressRing(
                    value: pct,
                    size: 38,
                    stroke: 5,
                    color: vis.accent,
                    centerTextColor: AppColors.textSecondary,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Pill
// ---------------------------------------------------------------------------

class _Pill extends StatelessWidget {
  final String text;
  final Color bg;
  final Color fg;
  const _Pill({required this.text, required this.bg, required this.fg});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
      decoration: BoxDecoration(
          color: bg, borderRadius: BorderRadius.circular(999)),
      child: Text(text,
          style: AppTypography.display(
              size: 13, weight: FontWeight.w800, color: fg)),
    );
  }
}
