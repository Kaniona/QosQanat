import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/curriculum.dart';
import '../../models/enums.dart';
import '../../models/question.dart';
import '../../providers/auth_provider.dart';
import '../../providers/game_provider.dart';
import '../../providers/learn_progress_provider.dart';
import '../../widgets/avatar/avatar_display.dart';
import '../../widgets/avatar/equipped_avatar.dart';
import '../../widgets/game/reward_toast.dart';
import '../../widgets/ui/aurora_background.dart';
import '../../widgets/ui/glass_panel.dart';
import '../../widgets/ui/pressable.dart';
import 'widgets/fill_in_blank_task.dart';
import 'widgets/match_pairs_task.dart';
import 'widgets/multiple_choice_task.dart';
import 'widgets/true_false_task.dart';

/// Hosts a single node's questions end-to-end: progress strip + hearts at the
/// top, the active question widget in the middle, the assistant reacting at
/// the bottom, then the auto-advance / wrong-answer feedback flow.
class TaskScreen extends ConsumerStatefulWidget {
  final String nodeId;

  const TaskScreen({super.key, required this.nodeId});

  @override
  ConsumerState<TaskScreen> createState() => _TaskScreenState();
}

class _TaskScreenState extends ConsumerState<TaskScreen> {
  int _index = 0;
  int _hearts = 5;
  int _correctCount = 0;
  bool _locked = false;
  bool? _lastWasCorrect;
  String? _lastExplanation;
  AvatarAnimation _avatarAnim = AvatarAnimation.idle;

  // Revealed-state snapshots for MC / TF / Fill so the locked state shows the
  // student's selection alongside the correct answer.
  int? _revealedMc;
  bool? _revealedTf;
  String? _revealedFill;

  final AudioPlayer _player = AudioPlayer();

  CurriculumNode? _findNode() {
    for (final s in kCurriculum) {
      for (final n in s.allNodes) {
        if (n.id == widget.nodeId) return n;
      }
    }
    return null;
  }

  Subject get _subject => subjectById(_findNode()!.subjectId)!;

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  Future<void> _playFeedback({required bool correct}) async {
    // audioplayers takes a source; we use a synthesized SystemSoundType-like
    // tone via a short asset would normally fit here, but since no audio
    // assets are bundled yet we just no-op gracefully.
    try {
      await _player.play(
        AssetSource(correct ? 'sounds/correct.mp3' : 'sounds/wrong.mp3'),
        volume: 0.6,
      );
    } catch (_) {
      // No bundled audio yet — silent fallback.
    }
  }

  void _handleAnswer({
    required bool correct,
    String? explanation,
    int? mc,
    bool? tf,
    String? fill,
  }) {
    if (_locked) return;
    final node = _findNode();
    if (node == null) return;
    final q = node.questions[_index];
    setState(() {
      _locked = true;
      _lastWasCorrect = correct;
      _lastExplanation = explanation ?? q.explanation;
      _revealedMc = mc;
      _revealedTf = tf;
      _revealedFill = fill;
      _avatarAnim =
          correct ? AvatarAnimation.celebrate : AvatarAnimation.sad;
      if (correct) {
        _correctCount += 1;
      } else {
        _hearts = (_hearts - 1).clamp(0, 5);
      }
    });

    if (correct) {
      RewardToast.show(context, kind: RewardKind.xp, amount: q.xp);
    }
    _playFeedback(correct: correct);

    // Auto-advance only on correct answers.
    if (correct) {
      Future<void>.delayed(const Duration(milliseconds: 900), _advance);
    }
  }

  void _advance() {
    if (!mounted) return;
    final node = _findNode();
    if (node == null) return;

    if (_index + 1 >= node.questions.length || _hearts == 0) {
      _finish();
      return;
    }
    setState(() {
      _index += 1;
      _locked = false;
      _lastWasCorrect = null;
      _lastExplanation = null;
      _revealedMc = null;
      _revealedTf = null;
      _revealedFill = null;
      _avatarAnim = AvatarAnimation.idle;
    });
  }

  void _finish() {
    final node = _findNode();
    if (node == null) return;
    final total = node.questions.length;
    final scorePct = (_correctCount * 100 / total).round();

    // Award rewards (scaled if hearts ran out / partial completion).
    final fraction = total == 0 ? 0.0 : _correctCount / total;
    final xp = (node.xpReward * fraction).round();
    final coins = (node.coinReward * fraction).round();
    final akyl = (node.akylReward * fraction).round();

    final game = ref.read(gameProvider.notifier);
    if (xp > 0) game.addXp(xp);
    if (coins > 0) game.addCoins(coins);
    if (akyl > 0) game.addAkylPoints(akyl);

    ref.read(learnProgressProvider.notifier).recordCompletion(
          subjectId: node.subjectId,
          moduleId: node.moduleId,
          nodeId: node.id,
          scorePercent: scorePct,
          xpEarned: xp,
          coinsEarned: coins,
          akylEarned: akyl,
        );

    context.pushReplacement(
      '/learn/result',
      extra: {
        'nodeId': node.id,
        'subjectId': node.subjectId,
        'scorePercent': scorePct,
        'xp': xp,
        'coins': coins,
        'akyl': akyl,
        'correct': _correctCount,
        'total': total,
      },
    );
  }

  void _confirmClose() {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Шыққың келеді ме?'),
        content: const Text('Прогресс сақталмайды.'),
        shape: RoundedRectangleBorder(borderRadius: AppRadius.radiusLg),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Болдырмау'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              context.pop();
            },
            style: FilledButton.styleFrom(
              backgroundColor: AppColors.coral,
            ),
            child: const Text('Шығу'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final node = _findNode();
    if (node == null) {
      return const Scaffold(body: Center(child: Text('Тапсырма табылмады')));
    }
    final q = node.questions[_index];
    final user = ref.watch(currentUserProvider).asData?.value;

    return Scaffold(
      body: AuroraBackground(
        light: true,
        child: SafeArea(
        child: Column(
          children: [
            _Header(
              total: node.questions.length,
              index: _index,
              hearts: _hearts,
              accent: _subject.color,
              onClose: _confirmClose,
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.lg,
                  AppSpacing.md,
                  AppSpacing.lg,
                  AppSpacing.xxl,
                ),
                child: _buildQuestion(q),
              ),
            ),
            if (_lastWasCorrect == false) _WrongFooter(
              explanation: _lastExplanation ?? '',
              onContinue: _advance,
            ),
            _AssistantPeek(
              user: user,
              animation: _avatarAnim,
            ),
          ],
        ),
        ),
      ),
    );
  }

  Widget _buildQuestion(Question q) {
    final key = ValueKey('q_${q.id}_$_index');
    switch (q.type) {
      case QuestionType.multipleChoice:
        return MultipleChoiceTask(
          key: key,
          question: q,
          locked: _locked,
          revealedSelection: _revealedMc,
          onAnswered: (i, correct) =>
              _handleAnswer(correct: correct, mc: i),
        );
      case QuestionType.trueFalse:
        return TrueFalseTask(
          key: key,
          question: q,
          locked: _locked,
          revealedSelection: _revealedTf,
          onAnswered: (v, correct) =>
              _handleAnswer(correct: correct, tf: v),
        );
      case QuestionType.fillBlank:
        return FillInBlankTask(
          key: key,
          question: q,
          locked: _locked,
          revealedSelection: _revealedFill,
          onAnswered: (w, correct) =>
              _handleAnswer(correct: correct, fill: w),
        );
      case QuestionType.matchPairs:
        return MatchPairsTask(
          key: key,
          question: q,
          locked: _locked,
          onCompleted: (correct) => _handleAnswer(correct: correct),
        );
    }
  }
}

class _Header extends StatelessWidget {
  final int total;
  final int index;
  final int hearts;
  final Color accent;
  final VoidCallback onClose;

  const _Header({
    required this.total,
    required this.index,
    required this.hearts,
    required this.accent,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.md, AppSpacing.sm, AppSpacing.md, 0),
      child: GlassPanel(
        radius: AppRadius.lg,
        padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.sm, vertical: 10),
        child: Row(
          children: [
            Pressable(
              onTap: onClose,
              child: const Text('✕',
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textSecondary)),
            ),
            AppSpacing.gapH12,
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(999),
                child: Stack(
                  children: [
                    Container(
                        height: 11,
                        color: AppColors.nightInk.withValues(alpha: 0.1)),
                    LayoutBuilder(
                      builder: (context, c) {
                        final frac = total == 0 ? 0.0 : index / total;
                        return Container(
                          height: 11,
                          width: c.maxWidth * frac.clamp(0, 1),
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(colors: [
                              AppColors.jadeLight,
                              AppColors.jade
                            ]),
                            boxShadow: [
                              BoxShadow(
                                  color: AppColors.jadeLight, blurRadius: 8)
                            ],
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
            AppSpacing.gapH12,
            _HeartsRow(count: hearts),
          ],
        ),
      ),
    );
  }
}

class _HeartsRow extends StatelessWidget {
  final int count;
  const _HeartsRow({required this.count});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 0; i < 3; i++)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 1),
            child: Opacity(
              opacity: i < count ? 1 : 0.3,
              child: const Text('❤️', style: TextStyle(fontSize: 16)),
            ),
          ),
      ],
    );
  }
}

class _AssistantPeek extends StatelessWidget {
  final dynamic user;
  final AvatarAnimation animation;

  const _AssistantPeek({required this.user, required this.animation});

  @override
  Widget build(BuildContext context) {
    final assistantType =
        (user?.assistantType as AssistantType?) ?? AssistantType.bektur;
    return SizedBox(
      height: 92,
      child: Stack(
        alignment: Alignment.centerLeft,
        children: [
          Positioned(
            left: AppSpacing.md,
            bottom: 0,
            child: EquippedAvatar(
              assistantType: assistantType,
              size: 84,
              animation: animation,
            ),
          ),
        ],
      ),
    );
  }
}

class _WrongFooter extends StatelessWidget {
  final String explanation;
  final VoidCallback onContinue;

  const _WrongFooter({required this.explanation, required this.onContinue});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.lg, AppSpacing.md, AppSpacing.lg, AppSpacing.md),
      decoration: const BoxDecoration(
        color: AppColors.coralSurface,
        border: Border(
          top: BorderSide(color: AppColors.coral, width: 1.4),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Icon(Icons.error_outline_rounded, color: AppColors.coralDark),
              SizedBox(width: 8),
              Text(
                'Дұрыс жауап жоғарыда',
                style: TextStyle(
                  color: AppColors.coralDark,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          if (explanation.isNotEmpty) ...[
            AppSpacing.gapV8,
            Text(
              explanation,
              style: AppTypography.bodySecondary.copyWith(
                color: AppColors.coralDark,
              ),
            ),
          ],
          AppSpacing.gapV12,
          SizedBox(
            width: double.infinity,
            height: 48,
            child: FilledButton(
              onPressed: onContinue,
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.coral,
                shape: RoundedRectangleBorder(
                  borderRadius: AppRadius.radiusMd,
                ),
              ),
              child: const Text(
                'Жалғастыру',
                style: TextStyle(
                  color: AppColors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 16,
                ),
              ),
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 220.ms).moveY(begin: 16, end: 0);
  }
}
