import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// Per-subject visual identity for the 2026 learning section — the emoji glyph
/// and the claymorphism gradient/glow used on bento cards and map accents.
/// Keyed by [Subject.id]; falls back to the Eagle palette for unknown ids.
class SubjectVisuals {
  final String emoji;
  final Color c1;
  final Color c2;
  final Color glow;
  final Color accent;

  const SubjectVisuals({
    required this.emoji,
    required this.c1,
    required this.c2,
    required this.glow,
    required this.accent,
  });

  LinearGradient get gradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [c1, c2],
      );

  static const SubjectVisuals _fallback = SubjectVisuals(
    emoji: '📘',
    c1: AppColors.eagleBlueLight,
    c2: AppColors.eagleBlueDark,
    glow: Color(0x802F4ECC),
    accent: AppColors.eagleBlue,
  );

  static const Map<String, SubjectVisuals> _byId = {
    'math': SubjectVisuals(
      emoji: '📐',
      c1: AppColors.eagleBlueLight,
      c2: AppColors.eagleBlueDark,
      glow: Color(0x802F4ECC),
      accent: AppColors.eagleBlue,
    ),
    'kazakh': SubjectVisuals(
      emoji: '🔤',
      c1: AppColors.jadeLight,
      c2: AppColors.jadeDark,
      glow: Color(0x8000C48C),
      accent: AppColors.jade,
    ),
    'english': SubjectVisuals(
      emoji: '🌍',
      c1: AppColors.steppeGoldLight,
      c2: AppColors.steppeGoldDark,
      glow: Color(0x80D4860A),
      accent: AppColors.steppeGold,
    ),
    'physics': SubjectVisuals(
      emoji: '⚛️',
      c1: AppColors.sunset,
      c2: AppColors.coral,
      glow: Color(0x80FF4757),
      accent: AppColors.coral,
    ),
    'informatics': SubjectVisuals(
      emoji: '💻',
      c1: AppColors.cosmicPurpleLight,
      c2: AppColors.cosmicPurpleDark,
      glow: Color(0x805840CC),
      accent: AppColors.cosmicPurple,
    ),
  };

  static SubjectVisuals of(String subjectId) =>
      _byId[subjectId] ?? _fallback;
}
