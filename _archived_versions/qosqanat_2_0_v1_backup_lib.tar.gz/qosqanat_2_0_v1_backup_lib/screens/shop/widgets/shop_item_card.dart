import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_elevation.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/shop_item.dart';
import '../../../widgets/ui/pressable.dart';
import 'item_preview.dart';
import 'rarity_chip.dart';

/// Card displayed in the shop grid. Renders the item preview, name, rarity
/// chip, and the contextual footer (price / "АЛЫНДЫ" / "КИГЕН ✓" / lock).
class ShopItemCard extends StatelessWidget {
  final ShopItem item;
  final bool owned;
  final bool equipped;
  final bool levelLocked;
  final int requiredLevel;
  final VoidCallback onTap;

  const ShopItemCard({
    super.key,
    required this.item,
    required this.owned,
    required this.equipped,
    required this.levelLocked,
    required this.requiredLevel,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final dim = levelLocked;
    final border = equipped
        ? const BorderSide(color: AppColors.jade, width: 2.5)
        : BorderSide(
            color: AppColors.border.withValues(alpha: 0.9),
            width: 1.2,
          );

    return Pressable(
      onTap: levelLocked ? null : onTap,
      borderRadius: AppRadius.radiusLg,
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.sm),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: AppRadius.radiusLg,
          border: Border.fromBorderSide(border),
          boxShadow:
              equipped ? AppElevation.glow(AppColors.jade, opacity: 0.3) : AppElevation.low,
        ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  Center(
                    child: ItemPreview(item: item, size: 96, dimmed: dim),
                  ),
                  Positioned(
                    top: 4,
                    left: 4,
                    child: RarityChip(rarity: item.rarity, small: true),
                  ),
                  if (item.isNew)
                    const Positioned(top: 4, right: 4, child: _NewRibbon()),
                  if (equipped)
                    const Positioned(
                      top: 4,
                      right: 4,
                      child: _EquippedBadge(),
                    ),
                ],
              ),
              AppSpacing.gapV8,
              Text(
                item.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppTypography.body.copyWith(
                  fontWeight: FontWeight.w800,
                  fontSize: 14,
                ),
              ),
              AppSpacing.gapV4,
              _Footer(
                item: item,
                owned: owned,
                equipped: equipped,
                levelLocked: levelLocked,
                requiredLevel: requiredLevel,
              ),
            ],
          ),
        ),
    );
  }
}

class _Footer extends StatelessWidget {
  final ShopItem item;
  final bool owned;
  final bool equipped;
  final bool levelLocked;
  final int requiredLevel;

  const _Footer({
    required this.item,
    required this.owned,
    required this.equipped,
    required this.levelLocked,
    required this.requiredLevel,
  });

  @override
  Widget build(BuildContext context) {
    if (equipped) {
      return _StatusPill(
        label: 'КИГЕН ✓',
        bg: AppColors.jadeSurface,
        fg: AppColors.jadeDark,
        border: AppColors.jade,
      );
    }
    if (levelLocked) {
      return _StatusPill(
        label: '$requiredLevel-деңгей',
        bg: AppColors.surfaceMuted,
        fg: AppColors.textSecondary,
        border: AppColors.border,
        icon: Icons.lock_rounded,
      );
    }
    if (owned) {
      return _StatusPill(
        label: 'АЛЫНДЫ',
        bg: AppColors.eagleBlueSurface,
        fg: AppColors.eagleBlueDark,
        border: AppColors.eagleBlue,
      );
    }
    return Row(
      children: [
        const Icon(Icons.monetization_on_rounded,
            color: AppColors.steppeGold, size: 18),
        const SizedBox(width: 4),
        Text(
          '${item.price}',
          style: AppTypography.body.copyWith(
            color: AppColors.steppeGoldDark,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _StatusPill extends StatelessWidget {
  final String label;
  final Color bg;
  final Color fg;
  final Color border;
  final IconData? icon;

  const _StatusPill({
    required this.label,
    required this.bg,
    required this.fg,
    required this.border,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: border.withValues(alpha: 0.6), width: 1.2),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: fg),
            const SizedBox(width: 3),
          ],
          Text(
            label,
            style: AppTypography.caption.copyWith(
              color: fg,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _NewRibbon extends StatelessWidget {
  const _NewRibbon();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.coral,
        borderRadius: BorderRadius.circular(4),
      ),
      child: const Text(
        'ЖАҢА',
        style: TextStyle(
          color: AppColors.white,
          fontWeight: FontWeight.w800,
          fontSize: 10,
        ),
      ),
    );
  }
}

class _EquippedBadge extends StatelessWidget {
  const _EquippedBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: const BoxDecoration(
        color: AppColors.jade,
        shape: BoxShape.circle,
      ),
      child: const Icon(Icons.check_rounded,
          color: AppColors.white, size: 14),
    );
  }
}
