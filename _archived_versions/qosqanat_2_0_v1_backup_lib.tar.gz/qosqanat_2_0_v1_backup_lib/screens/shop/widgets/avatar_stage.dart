import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../core/theme/app_colors.dart';
import '../../../models/enums.dart';
import '../../../widgets/avatar/avatar_display.dart';

/// The big preview stage shown above the shop grid — gradient backdrop, a
/// glowing pedestal, the assistant rendered with the player's currently
/// equipped items, and swipe-to-rotate gesture handling.
class AvatarStage extends StatefulWidget {
  final AssistantType assistantType;
  final Map<String, String> equipped;
  final AvatarAnimation animation;

  const AvatarStage({
    super.key,
    required this.assistantType,
    required this.equipped,
    this.animation = AvatarAnimation.idle,
  });

  @override
  State<AvatarStage> createState() => _AvatarStageState();
}

class _AvatarStageState extends State<AvatarStage> {
  double _rotationY = 0;

  void _drag(double dx) {
    setState(() {
      _rotationY = (_rotationY + dx * 0.012).clamp(-math.pi * 0.6, math.pi * 0.6);
    });
  }

  void _snapBack() {
    setState(() => _rotationY = 0);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            AppColors.cosmicPurpleSurface,
            AppColors.eagleBlueSurface,
            AppColors.steppeGoldSurface,
          ],
        ),
      ),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onHorizontalDragUpdate: (d) => _drag(d.primaryDelta ?? 0),
        onHorizontalDragEnd: (_) => _snapBack(),
        child: LayoutBuilder(
          builder: (context, c) {
            final stageH = c.maxHeight;
            return Stack(
              alignment: Alignment.bottomCenter,
              children: [
                Positioned.fill(child: _StarsBackdrop()),
                Positioned(
                  bottom: stageH * 0.08,
                  child: const _Pedestal(),
                ),
                Positioned(
                  bottom: stageH * 0.08 + 18,
                  child: TweenAnimationBuilder<double>(
                    tween: Tween(begin: _rotationY, end: _rotationY),
                    duration: const Duration(milliseconds: 220),
                    curve: Curves.easeOutBack,
                    builder: (context, value, child) {
                      return Transform(
                        alignment: Alignment.center,
                        transform: Matrix4.identity()
                          ..setEntry(3, 2, 0.001)
                          ..rotateY(value),
                        child: child,
                      );
                    },
                    child: AvatarDisplay(
                      assistantType: widget.assistantType,
                      equipped: widget.equipped,
                      animation: widget.animation,
                      size: 200,
                    ),
                  ),
                ),
                Positioned(
                  bottom: 8,
                  child: _SwipeHint(),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _StarsBackdrop extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _StarsPainter());
  }
}

class _StarsPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final rng = math.Random(11);
    final paint = Paint()..color = AppColors.white.withValues(alpha: 0.7);
    for (var i = 0; i < 24; i++) {
      final x = rng.nextDouble() * size.width;
      final y = rng.nextDouble() * size.height * 0.55;
      canvas.drawCircle(Offset(x, y), 0.7 + rng.nextDouble() * 1.6, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class _Pedestal extends StatelessWidget {
  const _Pedestal();

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 200,
          height: 18,
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            gradient: const LinearGradient(
              colors: [AppColors.steppeGoldLight, AppColors.steppeGold],
            ),
            borderRadius: BorderRadius.circular(999),
            boxShadow: [
              BoxShadow(
                color: AppColors.steppeGold.withValues(alpha: 0.6),
                blurRadius: 20,
                offset: const Offset(0, 6),
              ),
            ],
          ),
        ),
        Container(
          width: 160,
          height: 6,
          decoration: BoxDecoration(
            color: AppColors.steppeGoldDark.withValues(alpha: 0.6),
            borderRadius: BorderRadius.circular(999),
          ),
        )
            .animate(onPlay: (c) => c.repeat(reverse: true))
            .fade(begin: 0.4, end: 0.85, duration: 1200.ms),
      ],
    );
  }
}

class _SwipeHint extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.nightInk.withValues(alpha: 0.32),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: const [
          Icon(Icons.swipe_rounded, color: AppColors.white, size: 14),
          SizedBox(width: 4),
          Text(
            'Айналдыр',
            style: TextStyle(
              color: AppColors.white,
              fontWeight: FontWeight.w700,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}
