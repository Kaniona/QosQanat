import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/enums.dart';

/// Tiny gradient chip that displays the rarity of a shop item.
class RarityChip extends StatelessWidget {
  final Rarity rarity;
  final bool small;

  const RarityChip({super.key, required this.rarity, this.small = false});

  @override
  Widget build(BuildContext context) {
    final s = _styleFor(rarity);
    final size = small ? const _S(6, 9) : const _S(8, 11);
    return Container(
      padding: EdgeInsets.symmetric(horizontal: size.h, vertical: size.v),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: s.colors),
        borderRadius: BorderRadius.circular(999),
        boxShadow: [
          BoxShadow(
            color: s.colors.last.withValues(alpha: 0.4),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Text(
        s.label,
        style: AppTypography.caption.copyWith(
          color: AppColors.white,
          fontWeight: FontWeight.w800,
          fontSize: small ? 10 : 11,
          letterSpacing: 0.4,
        ),
      ),
    );
  }

  static ({List<Color> colors, String label}) _styleFor(Rarity r) {
    switch (r) {
      case Rarity.common:
        return (colors: const [AppColors.textTertiary, AppColors.borderStrong],
            label: 'ҚАРАПАЙЫМ');
      case Rarity.rare:
        return (colors: const [AppColors.eagleBlueLight, AppColors.eagleBlue],
            label: 'СИРЕК');
      case Rarity.epic:
        return (
          colors: const [AppColors.cosmicPurpleLight, AppColors.cosmicPurple],
          label: 'ЭПИКАЛЫҚ',
        );
      case Rarity.legendary:
        return (colors: const [AppColors.steppeGoldLight, AppColors.steppeGold],
            label: 'АҢЫЗ');
      case Rarity.mythic:
        return (colors: const [AppColors.coralLight, AppColors.coral],
            label: 'МИФТІК');
    }
  }
}

class _S {
  final double h;
  final double v;
  const _S(this.v, this.h);
}
