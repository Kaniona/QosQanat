import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/enums.dart';
import '../../../models/shop_item.dart';
import 'item_preview.dart';
import 'rarity_chip.dart';

/// Bottom sheet shown when the player taps a purchasable item. Mirrors the
/// "Аватарда көру" (live preview) and "Сатып алу" (buy) actions.
class PurchaseSheet extends StatelessWidget {
  final ShopItem item;
  final AssistantType assistantType;
  final bool owned;
  final bool equipped;
  final VoidCallback? onPreview;
  final VoidCallback? onPurchase;
  final VoidCallback? onEquip;

  const PurchaseSheet({
    super.key,
    required this.item,
    required this.assistantType,
    required this.owned,
    required this.equipped,
    this.onPreview,
    this.onPurchase,
    this.onEquip,
  });

  bool get _premium =>
      item.rarity == Rarity.legendary || item.rarity == Rarity.mythic;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg, AppSpacing.sm, AppSpacing.lg, AppSpacing.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 48,
                height: 5,
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
            ),
            AppSpacing.gapV16,
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ItemPreview(item: item, size: 120),
                AppSpacing.gapH16,
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      RarityChip(rarity: item.rarity),
                      AppSpacing.gapV8,
                      Text(item.name, style: AppTypography.h3),
                      AppSpacing.gapV4,
                      if (item.description != null)
                        Text(
                          item.description!,
                          style: AppTypography.bodySecondary,
                        ),
                    ],
                  ),
                ),
              ],
            ),
            if (_premium) ...[
              AppSpacing.gapV12,
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      AppColors.steppeGoldLight,
                      AppColors.steppeGold,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Icon(Icons.auto_awesome_rounded,
                        color: AppColors.white, size: 16),
                    SizedBox(width: 6),
                    Text(
                      'Премиум зат',
                      style: TextStyle(
                        color: AppColors.white,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ],
            AppSpacing.gapV20,
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: onPreview,
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: const BorderSide(
                        color: AppColors.eagleBlue,
                        width: 1.4,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: AppRadius.radiusMd,
                      ),
                    ),
                    icon: const Icon(Icons.remove_red_eye_rounded,
                        color: AppColors.eagleBlue, size: 18),
                    label: Text(
                      'Аватарда көру',
                      style: AppTypography.button.copyWith(
                        color: AppColors.eagleBlue,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            AppSpacing.gapV8,
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed:
                    equipped ? null : (owned ? onEquip : onPurchase),
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: owned
                      ? AppColors.jade
                      : AppColors.steppeGold,
                  shape: RoundedRectangleBorder(
                    borderRadius: AppRadius.radiusLg,
                  ),
                ),
                icon: Icon(
                  owned
                      ? (equipped
                          ? Icons.check_circle_rounded
                          : Icons.checkroom_rounded)
                      : Icons.monetization_on_rounded,
                  color: AppColors.white,
                ),
                label: Text(
                  equipped
                      ? 'Киілді ✓'
                      : owned
                          ? 'Кию'
                          : 'Сатып алу:  💰 ${item.price}',
                  style: AppTypography.button.copyWith(
                    color: AppColors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
