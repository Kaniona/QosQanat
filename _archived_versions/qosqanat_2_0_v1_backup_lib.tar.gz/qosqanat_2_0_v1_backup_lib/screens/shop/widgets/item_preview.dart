import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../core/theme/app_colors.dart';
import '../../../models/enums.dart';
import '../../../models/shop_item.dart';

/// Visual preview tile for a shop item — renders the item's SVG inside a
/// tinted/gradient stage matching its rarity. Legendary and mythic items get
/// animated sparkles + a premium glowing frame.
class ItemPreview extends StatelessWidget {
  final ShopItem item;
  final double size;
  final bool dimmed;

  const ItemPreview({
    super.key,
    required this.item,
    this.size = 110,
    this.dimmed = false,
  });

  bool get _premium =>
      item.rarity == Rarity.legendary || item.rarity == Rarity.mythic;

  @override
  Widget build(BuildContext context) {
    final palette = _backgroundFor(item.rarity);

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: palette,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(18),
              border: _premium
                  ? Border.all(
                      color: AppColors.steppeGoldLight,
                      width: 2.4,
                    )
                  : null,
              boxShadow: _premium
                  ? [
                      BoxShadow(
                        color: AppColors.steppeGold.withValues(alpha: 0.45),
                        blurRadius: 14,
                      ),
                    ]
                  : null,
            ),
          ),
          ColorFiltered(
            colorFilter: dimmed
                ? const ColorFilter.matrix(<double>[
                    0.33, 0.33, 0.33, 0, 0,
                    0.33, 0.33, 0.33, 0, 0,
                    0.33, 0.33, 0.33, 0, 0,
                    0, 0, 0, 1, 0,
                  ])
                : const ColorFilter.mode(Colors.transparent, BlendMode.dst),
            child: SizedBox(
              width: size,
              height: size,
              child: SvgPicture.string(
                item.assetSvg,
                fit: BoxFit.contain,
              ),
            ),
          ),
          if (_premium) _Sparkles(size: size),
        ],
      ),
    );
  }

  List<Color> _backgroundFor(Rarity r) {
    switch (r) {
      case Rarity.common:
        return [AppColors.surfaceMuted, AppColors.surface];
      case Rarity.rare:
        return [AppColors.eagleBlueSurface, AppColors.surface];
      case Rarity.epic:
        return [AppColors.cosmicPurpleSurface, AppColors.surface];
      case Rarity.legendary:
        return [AppColors.steppeGoldSurface, AppColors.steppeGoldLight];
      case Rarity.mythic:
        return [AppColors.coralSurface, AppColors.coralLight];
    }
  }
}

class _Sparkles extends StatelessWidget {
  final double size;
  const _Sparkles({required this.size});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: SizedBox(
        width: size,
        height: size,
        child: Stack(
          children: [
            _spark(left: size * 0.12, top: size * 0.18, delay: 0.ms),
            _spark(left: size * 0.78, top: size * 0.10, delay: 700.ms),
            _spark(left: size * 0.20, top: size * 0.74, delay: 350.ms),
            _spark(left: size * 0.82, top: size * 0.66, delay: 1100.ms),
          ],
        ),
      ),
    );
  }

  Widget _spark({required double left, required double top, required Duration delay}) {
    return Positioned(
      left: left,
      top: top,
      child: Icon(
        Icons.star_rounded,
        size: 14,
        color: AppColors.white.withValues(alpha: 0.9),
      )
          .animate(onPlay: (c) => c.repeat())
          .scaleXY(begin: 0.7, end: 1.2, duration: 900.ms, delay: delay)
          .fade(begin: 0.0, end: 1.0, duration: 450.ms)
          .then()
          .fade(begin: 1.0, end: 0.0, duration: 450.ms)
          .scaleXY(begin: 1.2, end: 0.7, duration: 450.ms),
    );
  }
}
