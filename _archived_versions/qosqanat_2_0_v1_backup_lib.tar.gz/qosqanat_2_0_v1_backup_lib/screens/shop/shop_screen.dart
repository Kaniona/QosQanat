import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/shop_items.dart';
import '../../models/enums.dart';
import '../../models/shop_item.dart';
import '../../providers/auth_provider.dart';
import '../../providers/game_provider.dart';
import '../../providers/shop_provider.dart';
import '../../widgets/avatar/avatar_display.dart';
import 'widgets/avatar_stage.dart';
import 'widgets/purchase_sheet.dart';
import 'widgets/shop_item_card.dart';

class _ShopTab {
  final ItemCategory category;
  final String label;
  final IconData icon;
  const _ShopTab(this.category, this.label, this.icon);
}

const _tabs = <_ShopTab>[
  _ShopTab(ItemCategory.top, 'Жоғарғы', Icons.checkroom_rounded),
  _ShopTab(ItemCategory.bottom, 'Төменгі', Icons.dry_cleaning_rounded),
  _ShopTab(ItemCategory.hat, 'Бас киім', Icons.emoji_events_rounded),
  _ShopTab(ItemCategory.accessory, 'Аксессуар', Icons.diamond_rounded),
  _ShopTab(ItemCategory.pet, 'Питомец', Icons.pets_rounded),
];

class ShopScreen extends ConsumerStatefulWidget {
  const ShopScreen({super.key});

  @override
  ConsumerState<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends ConsumerState<ShopScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  AvatarAnimation _avatarAnim = AvatarAnimation.idle;

  /// Slot/item override while previewing an unpurchased item.
  ({String slot, String svg})? _previewOverride;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabs.length, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(shopProvider.notifier).ensureLoaded();
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _showOverlayToast(String message,
      {required Color background, IconData icon = Icons.check_circle_rounded}) {
    final overlay = Overlay.of(context);
    late OverlayEntry entry;
    entry = OverlayEntry(builder: (_) {
      return Positioned(
        top: MediaQuery.of(context).padding.top + 78,
        left: 0,
        right: 0,
        child: IgnorePointer(
          child: Center(
            child: Material(
              color: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: background,
                  borderRadius: BorderRadius.circular(999),
                  boxShadow: const [
                    BoxShadow(
                      color: AppColors.shadowMedium,
                      blurRadius: 12,
                      offset: Offset(0, 6),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(icon, color: AppColors.white, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      message,
                      style: AppTypography.body.copyWith(
                        color: AppColors.white,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              )
                  .animate()
                  .fadeIn(duration: 180.ms)
                  .moveY(begin: -10, end: 0, duration: 200.ms)
                  .then(delay: 1400.ms)
                  .fadeOut(duration: 240.ms),
            ),
          ),
        ),
      );
    });
    overlay.insert(entry);
    Future<void>.delayed(const Duration(milliseconds: 1900),
        () => entry.remove());
  }

  void _onItemTap(ShopItem item) {
    final shop = ref.read(shopProvider);
    final user = ref.read(currentUserProvider).asData?.value;
    final owned = shop.isOwned(item.id);
    final equipped = shop.isEquipped(item.id);

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius:
            BorderRadius.vertical(top: Radius.circular(AppRadius.xl)),
      ),
      builder: (_) => PurchaseSheet(
        item: item,
        assistantType: user?.assistantType ?? AssistantType.bektur,
        owned: owned,
        equipped: equipped,
        onPreview: () {
          Navigator.pop(context);
          setState(() {
            _previewOverride =
                (slot: item.slot, svg: item.assetSvg);
          });
          _showOverlayToast(
            'Аватарда көрсетілуде',
            background: AppColors.eagleBlue,
            icon: Icons.remove_red_eye_rounded,
          );
          Future<void>.delayed(const Duration(seconds: 3), () {
            if (mounted) setState(() => _previewOverride = null);
          });
        },
        onPurchase: () => _purchase(item),
        onEquip: () => _equip(item),
      ),
    );
  }

  void _purchase(ShopItem item) {
    Navigator.pop(context);
    final game = ref.read(gameProvider.notifier);
    final spent = game.spendCoins(item.price);
    if (!spent) {
      _showOverlayToast(
        '💰 Монета жетімсіз! Тапсырма орында',
        background: AppColors.coral,
        icon: Icons.error_outline_rounded,
      );
      return;
    }
    final shop = ref.read(shopProvider.notifier);
    shop.recordPurchase(item);
    shop.equip(item);
    setState(() {
      _previewOverride = null;
      _avatarAnim = AvatarAnimation.celebrate;
    });
    _showOverlayToast(
      'Алынды! ✓',
      background: AppColors.jade,
      icon: Icons.check_circle_rounded,
    );
    Future<void>.delayed(const Duration(milliseconds: 1500), () {
      if (mounted) setState(() => _avatarAnim = AvatarAnimation.idle);
    });
  }

  void _equip(ShopItem item) {
    Navigator.pop(context);
    ref.read(shopProvider.notifier).equip(item);
    setState(() {
      _previewOverride = null;
      _avatarAnim = AvatarAnimation.celebrate;
    });
    _showOverlayToast(
      'Киілді ✓',
      background: AppColors.jade,
      icon: Icons.check_circle_rounded,
    );
    Future<void>.delayed(const Duration(milliseconds: 1200), () {
      if (mounted) setState(() => _avatarAnim = AvatarAnimation.idle);
    });
  }

  /// Effective equipped map for the stage — merges the saved state with any
  /// in-flight "Аватарда көру" preview override.
  Map<String, String> _stageEquipped(Map<String, String> base) {
    if (_previewOverride == null) return base;
    return {...base, _previewOverride!.slot: _previewOverride!.svg};
  }

  @override
  Widget build(BuildContext context) {
    final game = ref.watch(gameProvider);
    final shop = ref.watch(shopProvider);
    final equippedSvg = ref.watch(equippedSvgProvider);
    final user = ref.watch(currentUserProvider).asData?.value;
    final assistantType = user?.assistantType ?? AssistantType.bektur;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            _Header(coins: game.coins),
            // Avatar stage ~40% of viewport height.
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.40,
              child: AvatarStage(
                assistantType: assistantType,
                equipped: _stageEquipped(equippedSvg),
                animation: _avatarAnim,
              ),
            ),
            _TabsBar(
              controller: _tabController,
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  for (final tab in _tabs)
                    _CategoryGrid(
                      items: kShopCatalog
                          .where((i) => i.category == tab.category)
                          .toList(),
                      shop: shop,
                      level: game.level,
                      onItemTap: _onItemTap,
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final int coins;
  const _Header({required this.coins});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg, AppSpacing.sm, AppSpacing.lg, AppSpacing.sm),
      child: Row(
        children: [
          const Text('🛍️', style: TextStyle(fontSize: 28)),
          const SizedBox(width: 8),
          Text('Дүкен', style: AppTypography.h2),
          const Spacer(),
          _CoinPill(coins: coins),
        ],
      ),
    );
  }
}

class _CoinPill extends StatelessWidget {
  final int coins;
  const _CoinPill({required this.coins});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        gradient: AppColors.goldSoar,
        borderRadius: BorderRadius.circular(999),
        boxShadow: [
          BoxShadow(
            color: AppColors.steppeGold.withValues(alpha: 0.45),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.monetization_on_rounded,
              color: AppColors.white, size: 20),
          const SizedBox(width: 6),
          Text(
            '$coins',
            style: AppTypography.h3.copyWith(
              color: AppColors.white,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _TabsBar extends StatelessWidget {
  final TabController controller;

  const _TabsBar({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.background,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      child: TabBar(
        controller: controller,
        isScrollable: true,
        tabAlignment: TabAlignment.start,
        indicator: BoxDecoration(
          gradient: AppColors.eagle,
          borderRadius: BorderRadius.circular(999),
        ),
        indicatorPadding: EdgeInsets.zero,
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        splashFactory: NoSplash.splashFactory,
        labelColor: AppColors.white,
        unselectedLabelColor: AppColors.textSecondary,
        labelStyle: AppTypography.body.copyWith(fontWeight: FontWeight.w800),
        tabs: [
          for (final tab in _tabs)
            Tab(
              height: 40,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(tab.icon, size: 16),
                    const SizedBox(width: 6),
                    Text(tab.label),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _CategoryGrid extends StatelessWidget {
  final List<ShopItem> items;
  final ShopState shop;
  final int level;
  final ValueChanged<ShopItem> onItemTap;

  const _CategoryGrid({
    required this.items,
    required this.shop,
    required this.level,
    required this.onItemTap,
  });

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return const Center(
        child: Text('Бұл санатта зат жоқ', style: TextStyle(
          color: AppColors.textSecondary,
        )),
      );
    }
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.md, AppSpacing.sm, AppSpacing.md, AppSpacing.xxl),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: AppSpacing.md,
        crossAxisSpacing: AppSpacing.md,
        childAspectRatio: 0.78,
      ),
      itemCount: items.length,
      itemBuilder: (context, i) {
        final item = items[i];
        final owned = shop.isOwned(item.id);
        final equipped = shop.isEquipped(item.id);
        final levelLocked = level < item.levelRequirement;
        return ShopItemCard(
          item: item,
          owned: owned,
          equipped: equipped,
          levelLocked: levelLocked,
          requiredLevel: item.levelRequirement,
          onTap: () => onItemTap(item),
        ).animate(delay: (i * 30).ms).fadeIn(duration: 220.ms).moveY(
              begin: 14,
              end: 0,
              curve: Curves.easeOut,
              duration: 260.ms,
            );
      },
    );
  }
}
