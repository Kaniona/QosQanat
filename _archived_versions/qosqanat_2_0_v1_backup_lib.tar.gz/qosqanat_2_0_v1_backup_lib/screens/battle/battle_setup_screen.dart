import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/curriculum.dart';
import '../../models/enums.dart';
import '../../providers/auth_provider.dart';
import '../../providers/social_provider.dart';
import '../../services/api_service.dart';
import '../../widgets/avatar/equipped_avatar.dart';

const _allowedQuestionCounts = [15, 20, 25, 40, 50];

/// Configure the upcoming battle: lock the opponent shown vs. the player,
/// pick how many questions and which subject, then fire "⚔️ Батл бастау!".
class BattleSetupScreen extends ConsumerStatefulWidget {
  final FriendUser opponent;
  const BattleSetupScreen({super.key, required this.opponent});

  @override
  ConsumerState<BattleSetupScreen> createState() =>
      _BattleSetupScreenState();
}

class _BattleSetupScreenState extends ConsumerState<BattleSetupScreen> {
  int _questionCount = 20;
  String? _subjectId; // null = "Аралас"
  bool _creating = false;

  Future<void> _start() async {
    setState(() => _creating = true);
    try {
      final battle = await ref.read(apiServiceProvider).createBattle(
            opponentId: widget.opponent.userId,
            questionCount: _questionCount,
            subjectId: _subjectId,
          );
      if (!mounted) return;
      context.pushReplacement('/battle/waiting', extra: {
        'battleId': battle.id,
        'opponent': widget.opponent,
      });
    } catch (e) {
      if (mounted) {
        setState(() => _creating = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Қате: $e'),
          backgroundColor: AppColors.coral,
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = ref.watch(currentUserProvider).asData?.value;
    final assistant = me?.assistantType ?? AssistantType.bektur;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Батл дайындау'),
        backgroundColor: AppColors.background,
        elevation: 0,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.lg, vertical: AppSpacing.md),
          children: [
            _VsCard(
              meName: me?.fullName ?? 'Сен',
              meAssistant: assistant,
              opponent: widget.opponent,
            ),
            AppSpacing.gapV24,
            const _SectionTitle(text: 'Сұрақ саны'),
            AppSpacing.gapV8,
            _QuestionCountPicker(
              value: _questionCount,
              onChange: (v) => setState(() => _questionCount = v),
            ),
            AppSpacing.gapV24,
            const _SectionTitle(text: 'Пән'),
            AppSpacing.gapV8,
            _SubjectChips(
              value: _subjectId,
              onChange: (id) => setState(() => _subjectId = id),
            ),
            AppSpacing.gapV32,
            SizedBox(
              height: 60,
              child: FilledButton(
                onPressed: _creating ? null : _start,
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.coral,
                  shape: RoundedRectangleBorder(
                    borderRadius: AppRadius.radiusLg,
                  ),
                ),
                child: _creating
                    ? const CircularProgressIndicator(color: AppColors.white)
                    : Text(
                        '⚔️ Батл бастау!',
                        style: AppTypography.button.copyWith(
                          fontSize: 18,
                          color: AppColors.white,
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _VsCard extends StatelessWidget {
  final String meName;
  final AssistantType meAssistant;
  final FriendUser opponent;

  const _VsCard({
    required this.meName,
    required this.meAssistant,
    required this.opponent,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md, vertical: AppSpacing.md),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.eagleBlue, AppColors.cosmicPurple],
        ),
        borderRadius: AppRadius.radiusLg,
        boxShadow: [
          BoxShadow(
            color: AppColors.cosmicPurple.withValues(alpha: 0.5),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: _Side(
              name: meName,
              level: 1,
              assistant: meAssistant,
            ),
          ),
          const _VsBubble(),
          Expanded(
            child: _Side(
              name: opponent.fullName,
              level: opponent.level,
              assistant: opponent.assistantType,
            ),
          ),
        ],
      ),
    );
  }
}

class _Side extends StatelessWidget {
  final String name;
  final int level;
  final AssistantType assistant;

  const _Side({
    required this.name,
    required this.level,
    required this.assistant,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        EquippedAvatar(assistantType: assistant, size: 90),
        AppSpacing.gapV4,
        Text(
          name,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: AppTypography.body.copyWith(
            color: AppColors.white,
            fontWeight: FontWeight.w800,
          ),
        ),
        AppSpacing.gapV4,
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          decoration: BoxDecoration(
            color: AppColors.white.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            'LVL $level',
            style: AppTypography.caption.copyWith(
              color: AppColors.white,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ],
    );
  }
}

class _VsBubble extends StatelessWidget {
  const _VsBubble();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 60,
      height: 60,
      decoration: BoxDecoration(
        gradient: AppColors.goldSoar,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: AppColors.steppeGold.withValues(alpha: 0.6),
            blurRadius: 16,
          ),
        ],
        border: Border.all(color: AppColors.white, width: 3),
      ),
      child: const Center(
        child: Text(
          'VS',
          style: TextStyle(
            color: AppColors.white,
            fontWeight: FontWeight.w900,
            fontSize: 18,
            letterSpacing: 1,
          ),
        ),
      ),
    )
        .animate(onPlay: (c) => c.repeat(reverse: true))
        .scaleXY(
            begin: 1.0,
            end: 1.08,
            duration: 800.ms,
            curve: Curves.easeInOut);
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle({required this.text});

  @override
  Widget build(BuildContext context) {
    return Text(text, style: AppTypography.h3);
  }
}

class _QuestionCountPicker extends StatelessWidget {
  final int value;
  final ValueChanged<int> onChange;

  const _QuestionCountPicker({
    required this.value,
    required this.onChange,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: AppSpacing.xs,
      runSpacing: AppSpacing.xs,
      children: [
        for (final n in _allowedQuestionCounts)
          Material(
            color: n == value ? AppColors.eagleBlue : AppColors.surface,
            borderRadius: BorderRadius.circular(999),
            child: InkWell(
              borderRadius: BorderRadius.circular(999),
              onTap: () => onChange(n),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 9),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color: n == value
                        ? AppColors.eagleBlue
                        : AppColors.border,
                    width: 1.4,
                  ),
                ),
                child: Text(
                  '$n',
                  style: AppTypography.body.copyWith(
                    color: n == value
                        ? AppColors.white
                        : AppColors.textPrimary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _SubjectChips extends StatelessWidget {
  final String? value;
  final ValueChanged<String?> onChange;

  const _SubjectChips({required this.value, required this.onChange});

  @override
  Widget build(BuildContext context) {
    Widget chip({required String? id, required String label, IconData? icon}) {
      final on = value == id;
      return Material(
        color: on ? AppColors.eagleBlue : AppColors.surface,
        borderRadius: BorderRadius.circular(999),
        child: InkWell(
          borderRadius: BorderRadius.circular(999),
          onTap: () => onChange(id),
          child: Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(999),
              border: Border.all(
                color: on ? AppColors.eagleBlue : AppColors.border,
                width: 1.4,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (icon != null) ...[
                  Icon(icon,
                      size: 14,
                      color:
                          on ? AppColors.white : AppColors.textSecondary),
                  const SizedBox(width: 4),
                ],
                Text(
                  label,
                  style: AppTypography.body.copyWith(
                    fontSize: 14,
                    color:
                        on ? AppColors.white : AppColors.textPrimary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Wrap(
      spacing: AppSpacing.xs,
      runSpacing: AppSpacing.xs,
      children: [
        chip(id: null, label: 'Аралас', icon: Icons.shuffle_rounded),
        for (final s in kCurriculum)
          chip(id: s.id, label: s.name, icon: s.icon),
      ],
    );
  }
}
