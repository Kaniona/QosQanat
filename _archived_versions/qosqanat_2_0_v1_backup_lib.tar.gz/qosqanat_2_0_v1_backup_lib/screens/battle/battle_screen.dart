import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/battle.dart';
import '../../models/enums.dart';
import '../../models/question.dart';
import '../../providers/auth_provider.dart';
import '../../providers/social_provider.dart';
import '../../services/api_service.dart';
import '../../widgets/avatar/avatar_display.dart';
import '../../widgets/avatar/equipped_avatar.dart';

/// Per-question time budget. Both clients run the same countdown locally;
/// score progress is synced via Postgres realtime on the `battles` row.
const _perQuestionSeconds = 10;

class BattleScreen extends ConsumerStatefulWidget {
  final String battleId;
  final FriendUser opponent;
  final bool isChallenger;

  const BattleScreen({
    super.key,
    required this.battleId,
    required this.opponent,
    required this.isChallenger,
  });

  @override
  ConsumerState<BattleScreen> createState() => _BattleScreenState();
}

class _BattleScreenState extends ConsumerState<BattleScreen> {
  List<Question> _questions = const [];
  int _index = 0;
  int _myScore = 0;
  int? _selected;
  bool _locked = false;
  bool _starBurst = false;
  Timer? _timer;
  int _remaining = _perQuestionSeconds;
  bool _finishing = false;
  bool _navigatedToResult = false;

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    final battle =
        await ref.read(apiServiceProvider).getBattle(widget.battleId);
    if (battle == null) return;
    // Fetch the wire-encoded questions stored on the battle row.
    final list =
        await ref.read(apiServiceProvider).getBattleQuestions(widget.battleId);
    if (!mounted) return;
    setState(() {
      _questions = [
        for (final m in list) ApiService.questionFromWire(m),
      ];
    });
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startTimer() {
    _timer?.cancel();
    setState(() => _remaining = _perQuestionSeconds);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() => _remaining -= 1);
      if (_remaining <= 0) {
        t.cancel();
        if (!_locked) _autoAdvance(timedOut: true);
      }
    });
  }

  Future<void> _select(int i) async {
    if (_locked || _index >= _questions.length) return;
    final q = _questions[_index];
    final correct = q.isCorrectIndex(i);
    setState(() {
      _selected = i;
      _locked = true;
      if (correct) {
        _myScore += 1;
        _starBurst = true;
      }
    });
    _timer?.cancel();
    if (correct) {
      unawaited(ref.read(apiServiceProvider).submitBattleAnswer(
            battleId: widget.battleId,
            isChallenger: widget.isChallenger,
            isCorrect: true,
          ));
    }
    Future<void>.delayed(const Duration(milliseconds: 900), () {
      if (!mounted) return;
      setState(() => _starBurst = false);
      _advance();
    });
  }

  void _autoAdvance({required bool timedOut}) {
    setState(() => _locked = true);
    Future<void>.delayed(const Duration(milliseconds: 600), () {
      if (!mounted) return;
      _advance();
    });
  }

  Future<void> _advance() async {
    if (_index + 1 >= _questions.length) {
      await _finish();
      return;
    }
    setState(() {
      _index += 1;
      _selected = null;
      _locked = false;
    });
    _startTimer();
  }

  Future<void> _finish() async {
    if (_finishing) return;
    setState(() => _finishing = true);
    try {
      await ref.read(apiServiceProvider).markBattleFinished(
            battleId: widget.battleId,
            isChallenger: widget.isChallenger,
          );
    } catch (_) {}
    // The result navigation happens from the stream listener below when both
    // sides are finished.
  }

  void _maybeNavigateToResult(Battle battle) {
    if (_navigatedToResult) return;
    if (battle.status != BattleStatus.finished) return;
    _navigatedToResult = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.pushReplacement('/battle/result', extra: {
        'battleId': widget.battleId,
        'opponent': widget.opponent,
        'isChallenger': widget.isChallenger,
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final me = ref.watch(currentUserProvider).asData?.value;
    final battleAsync = ref.watch(battleStreamProvider(widget.battleId));
    final battle = battleAsync.asData?.value;
    if (battle != null) _maybeNavigateToResult(battle);

    final opponentScore = battle == null
        ? 0
        : widget.isChallenger
            ? (battle.opponent?.score ?? 0)
            : battle.host.score;

    final assistantType = me?.assistantType ?? AssistantType.bektur;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: _questions.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  _TopScoreBar(
                    opponentName: widget.opponent.fullName,
                    opponentAssistant: widget.opponent.assistantType,
                    opponentScore: opponentScore,
                    myScore: _myScore,
                  ),
                  _CountdownBar(
                    remaining: _remaining,
                    total: _perQuestionSeconds,
                  ),
                  _QuestionHeader(
                    index: _index,
                    total: _questions.length,
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(
                          horizontal: AppSpacing.lg,
                          vertical: AppSpacing.md),
                      child: _QuestionBody(
                        question: _questions[_index],
                        selected: _selected,
                        locked: _locked,
                        onSelect: _select,
                      ),
                    ),
                  ),
                  if (_finishing) _FinishingPanel(),
                  _BottomMe(
                    name: me?.fullName ?? 'Сен',
                    assistantType: assistantType,
                    myScore: _myScore,
                    starBurst: _starBurst,
                  ),
                ],
              ),
      ),
    );
  }
}

class _TopScoreBar extends StatelessWidget {
  final String opponentName;
  final AssistantType opponentAssistant;
  final int opponentScore;
  final int myScore;

  const _TopScoreBar({
    required this.opponentName,
    required this.opponentAssistant,
    required this.opponentScore,
    required this.myScore,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
          AppSpacing.md, AppSpacing.xs, AppSpacing.md, AppSpacing.xs),
      decoration: const BoxDecoration(
        color: AppColors.nightInk,
      ),
      child: Row(
        children: [
          ClipOval(
            child: SizedBox(
              width: 38,
              height: 38,
              child: EquippedAvatar(
                assistantType: opponentAssistant,
                size: 38,
              ),
            ),
          ),
          AppSpacing.gapH8,
          Expanded(
            child: Text(
              opponentName,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTypography.body.copyWith(
                color: AppColors.white,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          _ScorePair(
            opponent: opponentScore,
            me: myScore,
          ),
        ],
      ),
    );
  }
}

class _ScorePair extends StatelessWidget {
  final int opponent;
  final int me;
  const _ScorePair({required this.opponent, required this.me});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.white.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        children: [
          Text('$opponent',
              style: const TextStyle(
                color: AppColors.coralLight,
                fontWeight: FontWeight.w800,
                fontSize: 18,
              )),
          const Text(' : ',
              style: TextStyle(
                color: AppColors.white,
                fontWeight: FontWeight.w800,
                fontSize: 18,
              )),
          Text('$me',
              style: const TextStyle(
                color: AppColors.jadeLight,
                fontWeight: FontWeight.w800,
                fontSize: 18,
              )),
        ],
      ),
    );
  }
}

class _CountdownBar extends StatelessWidget {
  final int remaining;
  final int total;
  const _CountdownBar({required this.remaining, required this.total});

  Color get _color {
    if (remaining > 5) return AppColors.jade;
    if (remaining > 3) return AppColors.steppeGold;
    return AppColors.coral;
  }

  String get _label {
    final clamped = remaining.clamp(0, 99);
    return '0:${clamped.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final t = (remaining.clamp(0, total)) / total;
    return Container(
      padding: const EdgeInsets.fromLTRB(
          AppSpacing.md, AppSpacing.xs, AppSpacing.md, 0),
      color: AppColors.nightInk,
      child: Column(
        children: [
          Row(
            children: [
              Text(
                _label,
                style: TextStyle(
                  color: _color,
                  fontWeight: FontWeight.w900,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Container(
            height: 8,
            decoration: BoxDecoration(
              color: AppColors.white.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Align(
              alignment: Alignment.centerLeft,
              child: FractionallySizedBox(
                widthFactor: t,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  decoration: BoxDecoration(
                    color: _color,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.xs),
        ],
      ),
    );
  }
}

class _QuestionHeader extends StatelessWidget {
  final int index;
  final int total;
  const _QuestionHeader({required this.index, required this.total});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
          AppSpacing.md, AppSpacing.sm, AppSpacing.md, 0),
      child: Row(
        children: [
          Text(
            'Сұрақ ${index + 1}/$total',
            style: AppTypography.caption.copyWith(
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _QuestionBody extends StatelessWidget {
  final Question question;
  final int? selected;
  final bool locked;
  final ValueChanged<int> onSelect;

  const _QuestionBody({
    required this.question,
    required this.selected,
    required this.locked,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      key: ValueKey('battle_q_${question.id}'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.all(AppSpacing.md),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: AppRadius.radiusLg,
            border: Border.all(color: AppColors.border),
          ),
          child: Text(question.prompt, style: AppTypography.h3),
        ),
        AppSpacing.gapV16,
        for (var i = 0; i < question.options.length; i++)
          _AnswerCard(
            label: question.options[i],
            state: _stateFor(i),
            onTap: () => onSelect(i),
          ),
      ],
    );
  }

  _OptionState _stateFor(int i) {
    if (!locked) {
      return selected == i ? _OptionState.picked : _OptionState.neutral;
    }
    final isCorrect = i == question.correctIndex;
    if (isCorrect) return _OptionState.correct;
    if (selected == i) return _OptionState.wrong;
    return _OptionState.neutral;
  }
}

enum _OptionState { neutral, picked, correct, wrong }

class _AnswerCard extends StatelessWidget {
  final String label;
  final _OptionState state;
  final VoidCallback onTap;

  const _AnswerCard({
    required this.label,
    required this.state,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final (bg, border, fg, icon) = switch (state) {
      _OptionState.neutral => (
          AppColors.surface,
          AppColors.border,
          AppColors.textPrimary,
          null,
        ),
      _OptionState.picked => (
          AppColors.eagleBlueSurface,
          AppColors.eagleBlue,
          AppColors.eagleBlue,
          null,
        ),
      _OptionState.correct => (
          AppColors.jadeSurface,
          AppColors.jade,
          AppColors.jadeDark,
          Icons.check_circle_rounded,
        ),
      _OptionState.wrong => (
          AppColors.coralSurface,
          AppColors.coral,
          AppColors.coralDark,
          Icons.cancel_rounded,
        ),
    };
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
      child: Material(
        color: bg,
        borderRadius: AppRadius.radiusLg,
        child: InkWell(
          onTap: state == _OptionState.neutral ? onTap : null,
          borderRadius: AppRadius.radiusLg,
          child: Container(
            padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.md, vertical: AppSpacing.md),
            decoration: BoxDecoration(
              border: Border.all(
                color: border,
                width: state == _OptionState.neutral ? 1.2 : 2,
              ),
              borderRadius: AppRadius.radiusLg,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    label,
                    style: AppTypography.body.copyWith(
                      color: fg,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                if (icon != null) Icon(icon, color: fg),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _BottomMe extends StatelessWidget {
  final String name;
  final AssistantType assistantType;
  final int myScore;
  final bool starBurst;

  const _BottomMe({
    required this.name,
    required this.assistantType,
    required this.myScore,
    required this.starBurst,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
          AppSpacing.md, AppSpacing.sm, AppSpacing.md, AppSpacing.md),
      decoration: const BoxDecoration(
        color: AppColors.surfaceMuted,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: Row(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              EquippedAvatar(
                assistantType: assistantType,
                size: 64,
                animation: starBurst
                    ? AvatarAnimation.celebrate
                    : AvatarAnimation.idle,
              ),
              if (starBurst) _StarBurst(),
            ],
          ),
          AppSpacing.gapH12,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: AppTypography.body.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  starBurst ? 'Жарайсың!' : 'Сенің кезегің',
                  style: AppTypography.caption.copyWith(
                    color: starBurst
                        ? AppColors.jade
                        : AppColors.textSecondary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.jadeSurface,
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: AppColors.jade),
            ),
            child: Row(
              children: [
                const Icon(Icons.star_rounded,
                    color: AppColors.jade, size: 18),
                const SizedBox(width: 4),
                Text(
                  '$myScore',
                  style: AppTypography.body.copyWith(
                    color: AppColors.jadeDark,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StarBurst extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: -10,
      left: -10,
      child: SizedBox(
        width: 84,
        height: 84,
        child: Stack(
          children: const [
            _Spark(angleDeg: 0),
            _Spark(angleDeg: 60),
            _Spark(angleDeg: 120),
            _Spark(angleDeg: 180),
            _Spark(angleDeg: 240),
            _Spark(angleDeg: 300),
          ],
        ),
      ),
    );
  }
}

class _Spark extends StatelessWidget {
  final double angleDeg;
  const _Spark({required this.angleDeg});

  @override
  Widget build(BuildContext context) {
    final rad = angleDeg * 3.14159 / 180;
    return Center(
      child: Transform.translate(
        offset: Offset(28 * (rad.isFinite ? 1 : 0), 0),
        child: Transform.rotate(
          angle: rad,
          child: const Icon(
            Icons.star_rounded,
            color: AppColors.steppeGold,
            size: 18,
          )
              .animate()
              .scale(
                  begin: const Offset(0, 0),
                  end: const Offset(1, 1),
                  duration: 350.ms,
                  curve: Curves.easeOutBack)
              .fadeIn(duration: 250.ms)
              .then()
              .fadeOut(duration: 350.ms),
        ),
      ),
    );
  }
}

class _FinishingPanel extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm),
      color: AppColors.eagleBlueSurface,
      child: Center(
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              width: 16,
              height: 16,
              child: CircularProgressIndicator(strokeWidth: 2.4),
            ),
            const SizedBox(width: 10),
            Text(
              'Қарсыластың аяқтауын күтудеміз...',
              style: AppTypography.body.copyWith(
                color: AppColors.eagleBlueDark,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
