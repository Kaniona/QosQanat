import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../navigation/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../providers/game_provider.dart';
import '../../providers/social_provider.dart';
import '../../services/api_service.dart';
import '../../services/offline_service.dart';
import '../../widgets/avatar/avatar_display.dart';
import '../../widgets/avatar/equipped_avatar.dart';

class BattleResultScreen extends ConsumerStatefulWidget {
  final String battleId;
  final FriendUser opponent;
  final bool isChallenger;

  const BattleResultScreen({
    super.key,
    required this.battleId,
    required this.opponent,
    required this.isChallenger,
  });

  @override
  ConsumerState<BattleResultScreen> createState() =>
      _BattleResultScreenState();
}

class _BattleResultScreenState extends ConsumerState<BattleResultScreen> {
  late final ConfettiController _confetti;
  bool _rewardsApplied = false;

  @override
  void initState() {
    super.initState();
    _confetti = ConfettiController(duration: const Duration(seconds: 3));
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  void _applyRewards(bool isWin) {
    if (_rewardsApplied) return;
    _rewardsApplied = true;
    final game = ref.read(gameProvider.notifier);
    if (isWin) {
      game.addCoins(50);
      game.addAkylPoints(20);
      _confetti.play();
    } else {
      // Losing still grants a small participation reward so the player keeps
      // coming back — never punish.
      game.addCoins(10);
      game.addAkylPoints(3);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = OfflineService.currentUserId;
    final battleAsync = ref.watch(battleSnapshotProvider(widget.battleId));

    return Scaffold(
      backgroundColor: AppColors.background,
      body: battleAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('$e')),
        data: (battle) {
          if (battle == null) {
            return const Center(child: Text('Шайқас табылмады'));
          }
          final myScore = widget.isChallenger
              ? battle.host.score
              : (battle.opponent?.score ?? 0);
          final oppScore = widget.isChallenger
              ? (battle.opponent?.score ?? 0)
              : battle.host.score;
          final isWin = battle.winnerId == me ||
              (battle.winnerId == null && myScore > oppScore);
          final isDraw = battle.winnerId == null && myScore == oppScore;
          WidgetsBinding.instance.addPostFrameCallback(
              (_) => _applyRewards(isWin));

          final total =
              battle.totalRounds == 0 ? 1 : battle.totalRounds;
          final accuracy = (myScore * 100 / total).round();

          return SafeArea(
            child: Stack(
              children: [
                if (isWin) const _GoldRays(),
                Positioned.fill(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(
                        horizontal: AppSpacing.lg, vertical: AppSpacing.md),
                    child: Column(
                      children: [
                        AppSpacing.gapV24,
                        _ResultTitle(isWin: isWin, isDraw: isDraw),
                        AppSpacing.gapV16,
                        _ResultAvatar(
                          isWin: isWin,
                          assistantType: ref
                                  .read(currentUserProvider)
                                  .asData
                                  ?.value
                                  ?.assistantType ??
                              AssistantType.bektur,
                        ),
                        AppSpacing.gapV20,
                        _ScoreComparison(
                          opponent: widget.opponent,
                          myScore: myScore,
                          oppScore: oppScore,
                          isWin: isWin,
                          isDraw: isDraw,
                        ),
                        AppSpacing.gapV12,
                        _AccuracyChip(percent: accuracy),
                        AppSpacing.gapV20,
                        _RewardsRow(isWin: isWin),
                        AppSpacing.gapV20,
                        _MotivationChip(isWin: isWin),
                        AppSpacing.gapV32,
                        _ActionButtons(
                          isWin: isWin,
                          onReplay: () => context
                              .pushReplacement('/battle/setup',
                                  extra: widget.opponent),
                          onHome: () => context.go(AppRoutes.home),
                        ),
                        AppSpacing.gapV24,
                      ],
                    ),
                  ),
                ),
                if (isWin)
                  Align(
                    alignment: Alignment.topCenter,
                    child: ConfettiWidget(
                      confettiController: _confetti,
                      blastDirectionality: BlastDirectionality.explosive,
                      shouldLoop: false,
                      emissionFrequency: 0.06,
                      numberOfParticles: 24,
                      gravity: 0.25,
                      colors: const [
                        AppColors.steppeGold,
                        AppColors.eagleBlue,
                        AppColors.cosmicPurple,
                        AppColors.jade,
                      ],
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _GoldRays extends StatelessWidget {
  const _GoldRays();

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            radius: 1.0,
            colors: [
              AppColors.steppeGoldSurface,
              AppColors.background,
              AppColors.background,
            ],
            stops: [0, 0.55, 1.0],
          ),
        ),
      ),
    );
  }
}

class _ResultTitle extends StatelessWidget {
  final bool isWin;
  final bool isDraw;
  const _ResultTitle({required this.isWin, required this.isDraw});

  @override
  Widget build(BuildContext context) {
    final emoji = isWin ? '🏆' : (isDraw ? '🤝' : '😔');
    final title = isWin
        ? 'ЖЕҢДІҢІЗ!'
        : (isDraw ? 'ТЕҢ КЕЛДІҢІЗ' : 'ЖЕҢІЛДІҢІЗ...');
    final color = isWin
        ? AppColors.steppeGoldDark
        : (isDraw ? AppColors.eagleBlue : AppColors.coral);
    return Column(
      children: [
        Text(emoji, style: const TextStyle(fontSize: 64))
            .animate()
            .scale(
                begin: const Offset(0.3, 0.3),
                end: const Offset(1, 1),
                curve: Curves.elasticOut,
                duration: 700.ms),
        AppSpacing.gapV4,
        Text(
          title,
          style: AppTypography.displayLarge.copyWith(
            color: color,
            letterSpacing: 1.2,
          ),
        )
            .animate()
            .fadeIn(delay: 200.ms, duration: 400.ms)
            .moveY(begin: 12, end: 0),
      ],
    );
  }
}

class _ResultAvatar extends StatelessWidget {
  final bool isWin;
  final AssistantType assistantType;

  const _ResultAvatar({required this.isWin, required this.assistantType});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 200,
      height: 200,
      child: Stack(
        alignment: Alignment.center,
        children: [
          EquippedAvatar(
            assistantType: assistantType,
            size: 160,
            animation: isWin
                ? AvatarAnimation.celebrate
                : AvatarAnimation.sad,
          ),
          if (isWin)
            const Positioned(
              top: 0,
              child: Text('🏆', style: TextStyle(fontSize: 56)),
            ),
        ],
      ),
    );
  }
}

class _ScoreComparison extends StatelessWidget {
  final FriendUser opponent;
  final int myScore;
  final int oppScore;
  final bool isWin;
  final bool isDraw;

  const _ScoreComparison({
    required this.opponent,
    required this.myScore,
    required this.oppScore,
    required this.isWin,
    required this.isDraw,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md, vertical: AppSpacing.md),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusLg,
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: _ScoreBlock(
              label: 'Сен',
              score: myScore,
              color: isWin ? AppColors.jade : AppColors.coral,
              winner: isWin,
            ),
          ),
          const Text(' : ', style: TextStyle(fontSize: 24)),
          Expanded(
            child: _ScoreBlock(
              label: opponent.fullName,
              score: oppScore,
              color: isWin
                  ? AppColors.textSecondary
                  : (isDraw ? AppColors.eagleBlue : AppColors.jade),
              winner: !isWin && !isDraw,
            ),
          ),
        ],
      ),
    );
  }
}

class _ScoreBlock extends StatelessWidget {
  final String label;
  final int score;
  final Color color;
  final bool winner;

  const _ScoreBlock({
    required this.label,
    required this.score,
    required this.color,
    required this.winner,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: AppTypography.caption.copyWith(
            color: AppColors.textSecondary,
          ),
        ),
        Text(
          '$score',
          style: AppTypography.displayLarge.copyWith(color: color),
        ),
        if (winner)
          const Icon(Icons.emoji_events_rounded,
              color: AppColors.steppeGold, size: 18),
      ],
    );
  }
}

class _AccuracyChip extends StatelessWidget {
  final int percent;
  const _AccuracyChip({required this.percent});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.eagleBlueSurface,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.eagleBlue.withValues(alpha: 0.4)),
      ),
      child: Text(
        'Дәлдік: $percent%',
        style: AppTypography.body.copyWith(
          color: AppColors.eagleBlueDark,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _RewardsRow extends StatelessWidget {
  final bool isWin;
  const _RewardsRow({required this.isWin});

  @override
  Widget build(BuildContext context) {
    final akyl = isWin ? 20 : 3;
    final coins = isWin ? 50 : 10;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _RewardPill(
          icon: Icons.star_rounded,
          color: AppColors.eagleBlue,
          label: '★ +$akyl',
        ),
        _RewardPill(
          icon: Icons.monetization_on_rounded,
          color: AppColors.steppeGold,
          label: '💰 +$coins',
        ),
      ],
    );
  }
}

class _RewardPill extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;

  const _RewardPill({
    required this.icon,
    required this.color,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color, width: 1.6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 6),
          Text(
            label,
            style: AppTypography.body.copyWith(
              color: color,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _MotivationChip extends StatelessWidget {
  final bool isWin;
  const _MotivationChip({required this.isWin});

  @override
  Widget build(BuildContext context) {
    final msg = isWin
        ? 'Жігерің мықты! Жалғастыр 🔥'
        : 'Келесіде жеңесің! 💪';
    final bg = isWin ? AppColors.jadeSurface : AppColors.eagleBlueSurface;
    final fg = isWin ? AppColors.jadeDark : AppColors.eagleBlueDark;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        msg,
        style: AppTypography.body.copyWith(
          color: fg,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _ActionButtons extends StatelessWidget {
  final bool isWin;
  final VoidCallback onReplay;
  final VoidCallback onHome;

  const _ActionButtons({
    required this.isWin,
    required this.onReplay,
    required this.onHome,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: SizedBox(
            height: 54,
            child: OutlinedButton.icon(
              onPressed: onHome,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(
                    color: AppColors.eagleBlue, width: 1.4),
                shape: RoundedRectangleBorder(
                  borderRadius: AppRadius.radiusLg,
                ),
              ),
              icon: const Icon(Icons.home_rounded,
                  color: AppColors.eagleBlue),
              label: Text(
                'Басты бетке',
                style: AppTypography.button.copyWith(
                  color: AppColors.eagleBlue,
                ),
              ),
            ),
          ),
        ),
        AppSpacing.gapH12,
        Expanded(
          flex: 2,
          child: SizedBox(
            height: 54,
            child: FilledButton.icon(
              onPressed: onReplay,
              style: FilledButton.styleFrom(
                backgroundColor:
                    isWin ? AppColors.steppeGold : AppColors.coral,
                shape: RoundedRectangleBorder(
                  borderRadius: AppRadius.radiusLg,
                ),
              ),
              icon: const Icon(Icons.replay_rounded,
                  color: AppColors.white),
              label: Text(
                isWin ? 'Қайта батл' : 'Қайта тырысу',
                style: AppTypography.button.copyWith(color: AppColors.white),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
