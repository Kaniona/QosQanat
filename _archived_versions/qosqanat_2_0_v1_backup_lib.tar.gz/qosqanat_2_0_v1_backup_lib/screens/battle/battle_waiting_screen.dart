import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../providers/auth_provider.dart';
import '../../providers/social_provider.dart';
import '../../services/api_service.dart';
import '../../widgets/avatar/equipped_avatar.dart';

/// Dramatic waiting room shown to the challenger between "Батл бастау!" and
/// the opponent accepting. Listens to the battle row via Realtime so it can
/// auto-navigate to the live battle as soon as status flips to `in_progress`.
class BattleWaitingScreen extends ConsumerStatefulWidget {
  final String battleId;
  final FriendUser opponent;
  final bool isChallenger;

  const BattleWaitingScreen({
    super.key,
    required this.battleId,
    required this.opponent,
    this.isChallenger = true,
  });

  @override
  ConsumerState<BattleWaitingScreen> createState() =>
      _BattleWaitingScreenState();
}

class _BattleWaitingScreenState
    extends ConsumerState<BattleWaitingScreen> {
  bool _navigated = false;

  void _cancel() async {
    try {
      await ref.read(apiServiceProvider).cancelBattle(widget.battleId);
    } catch (_) {}
    if (mounted) context.pop();
  }

  @override
  Widget build(BuildContext context) {
    final me = ref.watch(currentUserProvider).asData?.value;
    final battleAsync = ref.watch(battleStreamProvider(widget.battleId));

    battleAsync.whenData((battle) {
      if (_navigated) return;
      if (battle.status == BattleStatus.active &&
          ModalRoute.of(context)?.isCurrent == true) {
        _navigated = true;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          context.pushReplacement('/battle/play', extra: {
            'battleId': widget.battleId,
            'opponent': widget.opponent,
            'isChallenger': widget.isChallenger,
          });
        });
      }
      if (battle.status == BattleStatus.cancelled && !_navigated) {
        _navigated = true;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) context.pop();
        });
      }
    });

    return Scaffold(
      backgroundColor: AppColors.nightInk,
      body: SafeArea(
        child: Stack(
          children: [
            _Backdrop(),
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.lg,
                vertical: AppSpacing.lg,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      _DarkCircleButton(
                        icon: Icons.arrow_back_rounded,
                        onTap: _cancel,
                      ),
                    ],
                  ),
                  const Spacer(),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: _Fighter(
                          name: me?.fullName ?? 'Сен',
                          assistantType: me?.assistantType ?? AssistantType.bektur,
                          side: _Side.left,
                        ),
                      ),
                      _VsBubble(),
                      Expanded(
                        child: _Fighter(
                          name: widget.opponent.fullName,
                          assistantType: widget.opponent.assistantType,
                          side: _Side.right,
                        ),
                      ),
                    ],
                  ),
                  AppSpacing.gapV32,
                  Text(
                    'Қарсыласты күтудеміз...',
                    textAlign: TextAlign.center,
                    style: AppTypography.h2.copyWith(
                      color: AppColors.white,
                    ),
                  )
                      .animate(onPlay: (c) => c.repeat(reverse: true))
                      .fadeIn(begin: 0.55, duration: 900.ms),
                  AppSpacing.gapV20,
                  _RulesCard(),
                  const Spacer(),
                  SizedBox(
                    height: 54,
                    child: OutlinedButton(
                      onPressed: _cancel,
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(
                            color:
                                AppColors.white.withValues(alpha: 0.4),
                            width: 1.4),
                        shape: RoundedRectangleBorder(
                          borderRadius: AppRadius.radiusLg,
                        ),
                      ),
                      child: Text(
                        'Болдырмау',
                        style: AppTypography.button.copyWith(
                          color: AppColors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Backdrop extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          radius: 1.1,
          colors: [
            AppColors.cosmicPurpleDark,
            AppColors.nightInk,
          ],
        ),
      ),
    );
  }
}

class _DarkCircleButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _DarkCircleButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.white.withValues(alpha: 0.12),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(icon, color: AppColors.white, size: 22),
        ),
      ),
    );
  }
}

enum _Side { left, right }

class _Fighter extends StatelessWidget {
  final String name;
  final AssistantType assistantType;
  final _Side side;

  const _Fighter({
    required this.name,
    required this.assistantType,
    required this.side,
  });

  @override
  Widget build(BuildContext context) {
    final mirror = side == _Side.right;
    return Column(
      children: [
        Transform(
          alignment: Alignment.center,
          transform: Matrix4.identity()
            ..rotateY(mirror ? 3.14159 : 0),
          child: EquippedAvatar(
            assistantType: assistantType,
            size: 130,
          ),
        ),
        AppSpacing.gapV8,
        Text(
          name,
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: AppTypography.body.copyWith(
            color: AppColors.white,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _VsBubble extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 86,
      height: 86,
      decoration: BoxDecoration(
        gradient: AppColors.goldSoar,
        shape: BoxShape.circle,
        border: Border.all(color: AppColors.white, width: 4),
        boxShadow: [
          BoxShadow(
            color: AppColors.steppeGold.withValues(alpha: 0.8),
            blurRadius: 40,
            spreadRadius: 4,
          ),
        ],
      ),
      child: const Center(
        child: Text(
          'VS',
          style: TextStyle(
            color: AppColors.white,
            fontWeight: FontWeight.w900,
            fontSize: 28,
            letterSpacing: 1.5,
          ),
        ),
      ),
    )
        .animate(onPlay: (c) => c.repeat(reverse: true))
        .scaleXY(begin: 1.0, end: 1.12, duration: 900.ms,
            curve: Curves.easeInOut);
  }
}

class _RulesCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: AppColors.white.withValues(alpha: 0.08),
        borderRadius: AppRadius.radiusLg,
        border:
            Border.all(color: AppColors.white.withValues(alpha: 0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.gavel_rounded,
                  color: AppColors.steppeGoldLight, size: 18),
              const SizedBox(width: 6),
              Text(
                'Ережелер',
                style: AppTypography.body.copyWith(
                  color: AppColors.white,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          AppSpacing.gapV8,
          _rule('⏱  Әр сұраққа 10 секунд'),
          _rule('✓  Дұрыс жауап +1 ұпай'),
          _rule('⚔  Көп жинаған жеңеді'),
          _rule('🏆  Жеңімпаз: +50 💰  +20 ★'),
        ],
      ),
    );
  }

  Widget _rule(String text) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Text(
          text,
          style: AppTypography.body.copyWith(
            color: AppColors.white.withValues(alpha: 0.86),
          ),
        ),
      );
}
