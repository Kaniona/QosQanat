import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../providers/auth_provider.dart';
import '../../providers/social_provider.dart';
import '../../services/api_service.dart';
import '../../widgets/avatar/avatar_display.dart';
import '../../widgets/ui/profile_photo.dart';

const _kSchoolMinUsers = 10;

class RatingScreen extends ConsumerStatefulWidget {
  const RatingScreen({super.key});

  @override
  ConsumerState<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends ConsumerState<RatingScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  static const _scopes = [
    (RatingScope.global, '🌍 Жалпы'),
    (RatingScope.city, '🏙️ Қалам'),
    (RatingScope.school, '🏫 Мектебім'),
    (RatingScope.friends, '👥 Достарым'),
  ];

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: _scopes.length, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider).asData?.value;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                  AppSpacing.lg, AppSpacing.md, AppSpacing.lg, AppSpacing.xs),
              child: Row(
                children: [
                  const Text('🏆', style: TextStyle(fontSize: 28)),
                  AppSpacing.gapH8,
                  Text('Рейтинг', style: AppTypography.h1),
                ],
              ),
            ),
            TabBar(
              controller: _tabs,
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              labelColor: AppColors.eagleBlue,
              unselectedLabelColor: AppColors.textSecondary,
              indicatorColor: AppColors.eagleBlue,
              indicatorWeight: 3,
              labelStyle:
                  AppTypography.body.copyWith(fontWeight: FontWeight.w800),
              dividerColor: Colors.transparent,
              tabs: [for (final s in _scopes) Tab(text: s.$2)],
            ),
            Expanded(
              child: TabBarView(
                controller: _tabs,
                children: [
                  for (final s in _scopes)
                    _LeaderboardView(
                      scope: s.$1,
                      city: user?.city,
                      school: user?.school,
                      meId: user?.id,
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LeaderboardView extends ConsumerWidget {
  final RatingScope scope;
  final String? city;
  final String? school;
  final String? meId;

  const _LeaderboardView({
    required this.scope,
    required this.city,
    required this.school,
    required this.meId,
  });

  RatingRequest get _request {
    switch (scope) {
      case RatingScope.global:
        return const RatingRequest(RatingScope.global);
      case RatingScope.city:
        return RatingRequest(RatingScope.city, city);
      case RatingScope.school:
        return RatingRequest(RatingScope.school, school);
      case RatingScope.friends:
        return const RatingRequest(RatingScope.friends);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // For the school tab, gate the leaderboard behind 10 registered students.
    if (scope == RatingScope.school) {
      if (school == null || school!.isEmpty) {
        return _Empty(
          icon: Icons.school_outlined,
          title: 'Мектебің көрсетілмеген',
          subtitle: 'Профильдегі мектебіңді тол.',
        );
      }
      final count = ref.watch(schoolUserCountProvider(school!));
      return count.when(
        loading: () => const _LoadingList(),
        error: (e, _) => _Error(text: e.toString()),
        data: (n) {
          if (n < _kSchoolMinUsers) {
            return _Empty(
              icon: Icons.group_add_outlined,
              title: 'Мектеп рейтингі әзірге жабық',
              subtitle:
                  'Кемінде $_kSchoolMinUsers оқушы тіркелгенде ашылады. Қазір: $n.',
            );
          }
          return _RatingBody(request: _request, meId: meId);
        },
      );
    }
    if (scope == RatingScope.city && (city == null || city!.isEmpty)) {
      return _Empty(
        icon: Icons.location_city_outlined,
        title: 'Қалаң көрсетілмеген',
        subtitle: 'Профильде қалаңды толтыр.',
      );
    }
    return _RatingBody(request: _request, meId: meId);
  }
}

class _RatingBody extends ConsumerWidget {
  final RatingRequest request;
  final String? meId;

  const _RatingBody({required this.request, required this.meId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(leaderboardProvider(request));
    return RefreshIndicator(
      color: AppColors.eagleBlue,
      onRefresh: () async {
        ref.invalidate(leaderboardProvider(request));
        await Future<void>.delayed(const Duration(milliseconds: 50));
      },
      child: async.when(
        loading: () => const _LoadingList(),
        error: (e, _) => _Error(text: e.toString()),
        data: (entries) {
          if (entries.isEmpty) {
            return _Empty(
              icon: Icons.leaderboard_outlined,
              title: 'Әзірге тізім бос',
              subtitle: 'Сабақ оқып, ұпай жинай бер!',
            );
          }
          final topThree = entries.take(3).toList();
          final rest = entries.skip(3).toList();
          final meEntry = meId == null
              ? null
              : entries.firstWhere(
                  (e) => e.userId == meId,
                  orElse: () => _emptySelfRow(),
                );
          final meInTop = meEntry != null &&
              meEntry.rank > 0 &&
              meEntry.rank <= entries.length &&
              entries.any((e) => e.userId == meId);

          return Stack(
            children: [
              ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(
                    AppSpacing.md, AppSpacing.sm, AppSpacing.md, 100),
                children: [
                  if (topThree.isNotEmpty)
                    _Podium(entries: topThree, meId: meId),
                  AppSpacing.gapV16,
                  for (final e in rest)
                    _RankRow(entry: e, isMe: e.userId == meId),
                ],
              ),
              if (!meInTop && meEntry != null && meEntry.rank > 0)
                Positioned(
                  left: AppSpacing.md,
                  right: AppSpacing.md,
                  bottom: AppSpacing.md,
                  child: _StickyMeRow(entry: meEntry),
                ),
            ],
          );
        },
      ),
    );
  }

  static RatingEntry _emptySelfRow() => const RatingEntry(
        userId: '',
        qosqanatId: '',
        fullName: '',
        level: 1,
        akylPoints: 0,
        rank: 0,
      );
}

// =============================================================================
// Podium (top 3)
// =============================================================================

class _Podium extends StatelessWidget {
  final List<RatingEntry> entries;
  final String? meId;

  const _Podium({required this.entries, required this.meId});

  @override
  Widget build(BuildContext context) {
    final first = entries.isNotEmpty ? entries[0] : null;
    final second = entries.length > 1 ? entries[1] : null;
    final third = entries.length > 2 ? entries[2] : null;

    return Container(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.md),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: second == null
                ? const SizedBox()
                : _PodiumSlot(
                    entry: second,
                    rank: 2,
                    height: 130,
                    color: const Color(0xFFCDD3E4),
                    isMe: second.userId == meId,
                  ),
          ),
          Expanded(
            child: first == null
                ? const SizedBox()
                : _PodiumSlot(
                    entry: first,
                    rank: 1,
                    height: 180,
                    color: AppColors.steppeGold,
                    isMe: first.userId == meId,
                    withCrown: true,
                    withSparkles: true,
                  ),
          ),
          Expanded(
            child: third == null
                ? const SizedBox()
                : _PodiumSlot(
                    entry: third,
                    rank: 3,
                    height: 100,
                    color: AppColors.sunset,
                    isMe: third.userId == meId,
                  ),
          ),
        ],
      ),
    );
  }
}

class _PodiumSlot extends StatelessWidget {
  final RatingEntry entry;
  final int rank;
  final double height;
  final Color color;
  final bool isMe;
  final bool withCrown;
  final bool withSparkles;

  const _PodiumSlot({
    required this.entry,
    required this.rank,
    required this.height,
    required this.color,
    required this.isMe,
    this.withCrown = false,
    this.withSparkles = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        if (withCrown)
          const Text('👑', style: TextStyle(fontSize: 26))
              .animate(onPlay: (c) => c.repeat(reverse: true))
              .moveY(begin: 0, end: -4, duration: 900.ms),
        SizedBox(
          height: 96,
          child: Stack(
            alignment: Alignment.center,
            children: [
              if (withSparkles) _Sparkles(color: color),
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  shape: BoxShape.circle,
                  border: Border.all(color: color, width: 3.5),
                  boxShadow: [
                    BoxShadow(
                      color: color.withValues(alpha: 0.55),
                      blurRadius: 16,
                    ),
                  ],
                ),
                child: ClipOval(
                  child: _ProfileAvatar(
                    photoUrl: entry.profilePhotoUrl,
                    size: 76,
                  ),
                ),
              ),
            ],
          ),
        ),
        AppSpacing.gapV4,
        Text(
          isMe ? 'Сіз' : entry.fullName,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.center,
          style: AppTypography.caption.copyWith(
            color: isMe ? AppColors.eagleBlue : AppColors.textPrimary,
            fontWeight: FontWeight.w800,
            fontSize: 12,
          ),
        ),
        AppSpacing.gapV4,
        Container(
          width: 80,
          height: height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [color, color.withValues(alpha: 0.7)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: const BorderRadius.vertical(
              top: Radius.circular(12),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Column(
              children: [
                Text(
                  '$rank',
                  style: const TextStyle(
                    color: AppColors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 28,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppColors.white.withValues(alpha: 0.85),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.star_rounded,
                          color: AppColors.eagleBlue, size: 12),
                      const SizedBox(width: 3),
                      Text(
                        '${entry.akylPoints}',
                        style: AppTypography.caption.copyWith(
                          color: AppColors.eagleBlueDark,
                          fontWeight: FontWeight.w800,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _Sparkles extends StatelessWidget {
  final Color color;
  const _Sparkles({required this.color});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 110,
      height: 110,
      child: Stack(
        children: [
          _spark(top: 4, left: 4, delay: 0.ms),
          _spark(top: 8, right: 8, delay: 400.ms),
          _spark(bottom: 18, left: 0, delay: 800.ms),
          _spark(bottom: 22, right: 4, delay: 1200.ms),
        ],
      ),
    );
  }

  Widget _spark({
    double? top, double? left, double? right, double? bottom,
    required Duration delay,
  }) {
    return Positioned(
      top: top, left: left, right: right, bottom: bottom,
      child: Icon(Icons.star_rounded, size: 12, color: color)
          .animate(onPlay: (c) => c.repeat())
          .fadeIn(delay: delay, duration: 380.ms)
          .scaleXY(begin: 0.6, end: 1.2, duration: 400.ms)
          .then()
          .fadeOut(duration: 600.ms),
    );
  }
}

// =============================================================================
// Ranked list (4+) + sticky self row
// =============================================================================

class _RankRow extends StatelessWidget {
  final RatingEntry entry;
  final bool isMe;
  final bool sticky;

  const _RankRow({
    required this.entry,
    required this.isMe,
    this.sticky = false,
  });

  @override
  Widget build(BuildContext context) {
    final bg = isMe ? AppColors.eagleBlueSurface : AppColors.surface;
    final border = isMe ? AppColors.eagleBlue : AppColors.border;

    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.xs),
      padding: const EdgeInsets.all(AppSpacing.sm),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: AppRadius.radiusMd,
        border: Border.all(
          color: border,
          width: isMe ? 1.6 : 1,
        ),
        boxShadow: sticky
            ? const [
                BoxShadow(
                  color: AppColors.shadowMedium,
                  blurRadius: 18,
                  offset: Offset(0, -2),
                ),
              ]
            : null,
      ),
      child: Row(
        children: [
          SizedBox(
            width: 36,
            child: Text(
              entry.rank > 0 ? '${entry.rank}' : '—',
              textAlign: TextAlign.center,
              style: AppTypography.body.copyWith(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          ClipOval(
            child: _ProfileAvatar(
              photoUrl: entry.profilePhotoUrl,
              size: 42,
            ),
          ),
          AppSpacing.gapH12,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        isMe ? 'Сіз' : entry.fullName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.body.copyWith(
                          color: isMe
                              ? AppColors.eagleBlueDark
                              : AppColors.textPrimary,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    if (isMe) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppColors.eagleBlue,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: const Text(
                          'СІЗ',
                          style: TextStyle(
                            color: AppColors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 10,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                Text(
                  entry.qosqanatId,
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textTertiary,
                  ),
                ),
              ],
            ),
          ),
          _LevelBadge(level: entry.level),
          const SizedBox(width: 8),
          _AkylChip(akyl: entry.akylPoints),
          const SizedBox(width: 8),
          // Movement indicator placeholder — wired to a `delta` column once
          // the backend tracks daily snapshots. For now we show neutral.
          const _Movement(delta: 0),
        ],
      ),
    );
  }
}

class _StickyMeRow extends StatelessWidget {
  final RatingEntry entry;
  const _StickyMeRow({required this.entry});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            margin: const EdgeInsets.only(bottom: 4),
            decoration: BoxDecoration(
              color: AppColors.nightInk,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              'Сіздің орныңыз: ${entry.rank}',
              style: AppTypography.caption.copyWith(
                color: AppColors.white,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          _RankRow(entry: entry, isMe: true, sticky: true),
        ],
      ),
    );
  }
}

class _LevelBadge extends StatelessWidget {
  final int level;
  const _LevelBadge({required this.level});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
      decoration: BoxDecoration(
        gradient: AppColors.eagle,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        'LVL $level',
        style: const TextStyle(
          color: AppColors.white,
          fontWeight: FontWeight.w800,
          fontSize: 10,
        ),
      ),
    );
  }
}

class _AkylChip extends StatelessWidget {
  final int akyl;
  const _AkylChip({required this.akyl});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.star_rounded,
            color: AppColors.eagleBlue, size: 16),
        const SizedBox(width: 3),
        Text(
          '$akyl',
          style: AppTypography.body.copyWith(
            color: AppColors.eagleBlueDark,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _Movement extends StatelessWidget {
  final int delta;
  const _Movement({required this.delta});

  @override
  Widget build(BuildContext context) {
    final (icon, color, text) = delta == 0
        ? (Icons.remove_rounded, AppColors.textTertiary, '—')
        : delta > 0
            ? (Icons.arrow_drop_up_rounded, AppColors.jade, '$delta')
            : (
                Icons.arrow_drop_down_rounded,
                AppColors.coral,
                '${delta.abs()}',
              );
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: color, size: 18),
        Text(
          text,
          style: AppTypography.caption.copyWith(
            color: color,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

// =============================================================================
// Avatar / shared
// =============================================================================

class _ProfileAvatar extends StatelessWidget {
  final String? photoUrl;
  final double size;

  const _ProfileAvatar({required this.photoUrl, required this.size});

  @override
  Widget build(BuildContext context) {
    final fallback = AvatarDisplay(
      assistantType: AssistantType.bektur,
      size: size,
    );
    if (photoUrl == null || photoUrl!.isEmpty) return fallback;
    return SizedBox(
      width: size,
      height: size,
      child: ProfilePhoto(url: photoUrl, fallback: fallback),
    );
  }
}

class _LoadingList extends StatelessWidget {
  const _LoadingList();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md, vertical: AppSpacing.sm),
      children: List.generate(
        6,
        (_) => Container(
          height: 64,
          margin: const EdgeInsets.only(bottom: AppSpacing.xs),
          decoration: BoxDecoration(
            color: AppColors.surfaceMuted,
            borderRadius: AppRadius.radiusMd,
          ),
        ),
      ),
    );
  }
}

class _Error extends StatelessWidget {
  final String text;
  const _Error({required this.text});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Text(
          'Қате: $text',
          style: AppTypography.bodySecondary,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _Empty({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: AppSpacing.xxl),
          child: Column(
            children: [
              Icon(icon, size: 64, color: AppColors.textTertiary),
              AppSpacing.gapV12,
              Text(
                title,
                textAlign: TextAlign.center,
                style: AppTypography.h3
                    .copyWith(color: AppColors.textSecondary),
              ),
              AppSpacing.gapV4,
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Text(
                  subtitle,
                  textAlign: TextAlign.center,
                  style: AppTypography.bodySecondary,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
