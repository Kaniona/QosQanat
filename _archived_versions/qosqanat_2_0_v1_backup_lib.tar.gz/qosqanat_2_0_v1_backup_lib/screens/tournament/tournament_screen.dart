import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../providers/social_provider.dart';
import 'widgets/tournament_card.dart';

const _statusOrder = [
  TournamentStatus.active,
  TournamentStatus.upcoming,
  TournamentStatus.finished,
];

class TournamentScreen extends ConsumerStatefulWidget {
  const TournamentScreen({super.key});

  @override
  ConsumerState<TournamentScreen> createState() => _TournamentScreenState();
}

class _TournamentScreenState extends ConsumerState<TournamentScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: _statusOrder.length, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                  AppSpacing.lg, AppSpacing.md, AppSpacing.lg, AppSpacing.xs),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.arrow_back_rounded),
                  ),
                  const SizedBox(width: 4),
                  const Text('🏆', style: TextStyle(fontSize: 28)),
                  AppSpacing.gapH8,
                  Text('Турнир', style: AppTypography.h1),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
              child: TabBar(
                controller: _tabs,
                labelColor: AppColors.eagleBlue,
                unselectedLabelColor: AppColors.textSecondary,
                indicatorColor: AppColors.eagleBlue,
                indicatorWeight: 3,
                labelStyle: AppTypography.body.copyWith(
                  fontWeight: FontWeight.w800,
                ),
                dividerColor: Colors.transparent,
                tabs: const [
                  Tab(text: 'Белсенді'),
                  Tab(text: 'Алдағы'),
                  Tab(text: 'Аяқталған'),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: _tabs,
                children: [
                  for (final status in _statusOrder)
                    _TournamentList(status: status),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TournamentList extends ConsumerWidget {
  final TournamentStatus status;
  const _TournamentList({required this.status});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(tournamentsProvider(status));

    return async.when(
      loading: () => const _LoadingList(),
      error: (e, _) => _ErrorBlock(error: e.toString()),
      data: (list) {
        if (list.isEmpty) return _EmptyBlock(status: status);
        return RefreshIndicator(
          onRefresh: () async {
            ref.invalidate(tournamentsProvider(status));
            await Future<void>.delayed(const Duration(milliseconds: 50));
          },
          color: AppColors.eagleBlue,
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(
                AppSpacing.md, AppSpacing.sm, AppSpacing.md, AppSpacing.xxl),
            itemCount: list.length,
            itemBuilder: (context, i) {
              final t = list[i];
              return TournamentCard(
                tournament: t,
                onTap: () => context.push('/tournament/${t.id}', extra: t),
              );
            },
          ),
        );
      },
    );
  }
}

class _LoadingList extends StatelessWidget {
  const _LoadingList();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md, vertical: AppSpacing.sm),
      children: List.generate(
        3,
        (_) => Container(
          height: 200,
          margin: const EdgeInsets.only(bottom: AppSpacing.md),
          decoration: BoxDecoration(
            color: AppColors.surfaceMuted,
            borderRadius: AppRadius.radiusLg,
          ),
        ),
      ),
    );
  }
}

class _ErrorBlock extends StatelessWidget {
  final String error;
  const _ErrorBlock({required this.error});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Text(
          'Қате: $error',
          style: AppTypography.bodySecondary,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class _EmptyBlock extends StatelessWidget {
  final TournamentStatus status;
  const _EmptyBlock({required this.status});

  @override
  Widget build(BuildContext context) {
    final msg = switch (status) {
      TournamentStatus.active => 'Қазір белсенді турнир жоқ',
      TournamentStatus.upcoming => 'Жоспарланған турнир жоқ',
      TournamentStatus.finished => 'Аяқталған турнир жоқ',
      TournamentStatus.registration => 'Тіркеу ашық турнир жоқ',
    };
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: AppSpacing.xxl),
          child: Column(
            children: [
              const Icon(Icons.emoji_events_outlined,
                  size: 64, color: AppColors.textTertiary),
              AppSpacing.gapV12,
              Text(
                msg,
                style: AppTypography.h3
                    .copyWith(color: AppColors.textSecondary),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
