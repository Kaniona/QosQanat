import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../models/tournament.dart';
import '../../providers/social_provider.dart';
import '../../services/api_service.dart';
import '../../services/offline_service.dart';

class TournamentDetailScreen extends ConsumerStatefulWidget {
  final Tournament tournament;

  const TournamentDetailScreen({super.key, required this.tournament});

  @override
  ConsumerState<TournamentDetailScreen> createState() =>
      _TournamentDetailScreenState();
}

class _TournamentDetailScreenState
    extends ConsumerState<TournamentDetailScreen> {
  bool _joining = false;
  late Tournament _t;

  @override
  void initState() {
    super.initState();
    _t = widget.tournament;
  }

  Future<void> _join() async {
    setState(() => _joining = true);
    try {
      await ref.read(apiServiceProvider).joinTournament(_t.id);
      ref.invalidate(tournamentsProvider(_t.status));
      ref.invalidate(tournamentLeaderboardProvider(_t.id));
      setState(() {
        _t = _t.copyWith(
          isRegistered: true,
          participantCount: _t.participantCount + 1,
        );
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text('Турнирге қосылдыңыз ✓'),
          backgroundColor: AppColors.jade,
          behavior: SnackBarBehavior.floating,
        ));
      }
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(e.message),
          backgroundColor: AppColors.coral,
          behavior: SnackBarBehavior.floating,
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Қате: $e'),
          backgroundColor: AppColors.coral,
          behavior: SnackBarBehavior.floating,
        ));
      }
    } finally {
      if (mounted) setState(() => _joining = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final leaderboardAsync =
        ref.watch(tournamentLeaderboardProvider(_t.id));
    final myId = OfflineService.currentUserId;
    final dateFmt = DateFormat('d MMMM y', 'kk');

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          onPressed: () => context.pop(),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        title: Text('Турнир', style: AppTypography.h3),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
          children: [
            _HeaderCard(tournament: _t, dateFmt: dateFmt),
            AppSpacing.gapV20,
            _PrizePoolCard(coins: _t.prizeCoins),
            AppSpacing.gapV20,
            if (_t.status != TournamentStatus.finished)
              _ParticipateBlock(
                tournament: _t,
                joining: _joining,
                onJoin: _join,
              ),
            AppSpacing.gapV20,
            _SectionTitle(title: 'Көшбасшылар'),
            AppSpacing.gapV12,
            leaderboardAsync.when(
              loading: () => const _LoadingBlock(),
              error: (e, _) => _ErrorBlock(error: e.toString()),
              data: (entries) {
                if (entries.isEmpty) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 24),
                    child: Center(
                      child: Text(
                        'Әзірге қатысушы жоқ',
                        style: AppTypography.bodySecondary,
                      ),
                    ),
                  );
                }
                return Column(
                  children: [
                    for (final e in entries)
                      _LeaderboardRow(
                        entry: e,
                        isMe: e.userId == myId,
                      ),
                  ],
                );
              },
            ),
            AppSpacing.gapV24,
          ],
        ),
      ),
    );
  }
}

class _HeaderCard extends StatelessWidget {
  final Tournament tournament;
  final DateFormat dateFmt;

  const _HeaderCard({required this.tournament, required this.dateFmt});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.steppeGold, AppColors.steppeGoldDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: AppRadius.radiusXl,
        boxShadow: [
          BoxShadow(
            color: AppColors.steppeGold.withValues(alpha: 0.4),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('🏆', style: TextStyle(fontSize: 56)),
          AppSpacing.gapV8,
          Text(
            tournament.title,
            style: AppTypography.h1.copyWith(color: AppColors.white),
          ),
          if (tournament.description != null) ...[
            AppSpacing.gapV8,
            Text(
              tournament.description!,
              style: AppTypography.body
                  .copyWith(color: AppColors.white.withValues(alpha: 0.92)),
            ),
          ],
          AppSpacing.gapV12,
          Row(
            children: [
              const Icon(Icons.calendar_today_rounded,
                  color: AppColors.white, size: 16),
              const SizedBox(width: 6),
              Text(
                dateFmt.format(tournament.startsAt) +
                    (tournament.endsAt != null
                        ? ' — ${dateFmt.format(tournament.endsAt!)}'
                        : ''),
                style: AppTypography.caption.copyWith(
                  color: AppColors.white,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.white.withValues(alpha: 0.22),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.people_alt_rounded,
                        color: AppColors.white, size: 14),
                    const SizedBox(width: 4),
                    Text(
                      '${tournament.participantCount}',
                      style: AppTypography.caption.copyWith(
                        color: AppColors.white,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PrizePoolCard extends StatelessWidget {
  final int coins;
  const _PrizePoolCard({required this.coins});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusLg,
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: AppColors.steppeGoldSurface,
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.steppeGold, width: 2),
            ),
            child: const Center(
              child: Icon(Icons.card_giftcard_rounded,
                  color: AppColors.steppeGoldDark, size: 28),
            ),
          ),
          AppSpacing.gapH12,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Жалпы жүлде',
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
                Text(
                  '💰 $coins тиын',
                  style: AppTypography.h3.copyWith(
                    color: AppColors.steppeGoldDark,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ParticipateBlock extends StatelessWidget {
  final Tournament tournament;
  final bool joining;
  final VoidCallback onJoin;

  const _ParticipateBlock({
    required this.tournament,
    required this.joining,
    required this.onJoin,
  });

  @override
  Widget build(BuildContext context) {
    if (tournament.isRegistered) {
      return Container(
        padding: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          color: AppColors.jadeSurface,
          borderRadius: AppRadius.radiusLg,
          border: Border.all(color: AppColors.jade),
        ),
        child: Row(
          children: [
            const Icon(Icons.check_circle_rounded,
                color: AppColors.jadeDark, size: 22),
            AppSpacing.gapH8,
            Expanded(
              child: Text(
                'Сен бұл турнирге қатысып жатырсың',
                style: AppTypography.body.copyWith(
                  color: AppColors.jadeDark,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ),
      );
    }

    return SizedBox(
      width: double.infinity,
      height: 54,
      child: FilledButton.icon(
        onPressed: joining ? null : onJoin,
        style: FilledButton.styleFrom(
          backgroundColor: AppColors.steppeGold,
          shape: RoundedRectangleBorder(borderRadius: AppRadius.radiusLg),
        ),
        icon: joining
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: AppColors.white,
                  strokeWidth: 2.4,
                ),
              )
            : const Icon(Icons.emoji_events_rounded,
                color: AppColors.white),
        label: Text(
          'Қатысу',
          style: AppTypography.button.copyWith(color: AppColors.white),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Icon(Icons.leaderboard_rounded, color: AppColors.eagleBlue),
        AppSpacing.gapH8,
        Text(title, style: AppTypography.h3),
      ],
    );
  }
}

class _LeaderboardRow extends StatelessWidget {
  final LeaderboardEntry entry;
  final bool isMe;

  const _LeaderboardRow({required this.entry, required this.isMe});

  ({Color bg, Color fg}) get _rankStyle {
    if (entry.rank == 1) {
      return (bg: AppColors.steppeGold, fg: AppColors.white);
    }
    if (entry.rank == 2) {
      return (bg: const Color(0xFFCDD3E4), fg: AppColors.nightInk);
    }
    if (entry.rank == 3) {
      return (bg: AppColors.sunset, fg: AppColors.white);
    }
    return (bg: AppColors.surfaceMuted, fg: AppColors.textSecondary);
  }

  @override
  Widget build(BuildContext context) {
    final rs = _rankStyle;
    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.xs),
      padding: const EdgeInsets.all(AppSpacing.sm),
      decoration: BoxDecoration(
        color: isMe ? AppColors.eagleBlueSurface : AppColors.surface,
        borderRadius: AppRadius.radiusMd,
        border: Border.all(
          color: isMe ? AppColors.eagleBlue : AppColors.border,
          width: isMe ? 1.6 : 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: rs.bg,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                '${entry.rank}',
                style: TextStyle(
                  color: rs.fg,
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                ),
              ),
            ),
          ),
          AppSpacing.gapH12,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isMe ? 'Сен' : entry.fullName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.body.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  '${entry.qosqanatId}  •  LVL ${entry.level}',
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textTertiary,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.steppeGoldSurface,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              '${entry.score}',
              style: AppTypography.body.copyWith(
                color: AppColors.steppeGoldDark,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _LoadingBlock extends StatelessWidget {
  const _LoadingBlock();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(
        5,
        (_) => Container(
          height: 60,
          margin: const EdgeInsets.only(bottom: AppSpacing.xs),
          decoration: BoxDecoration(
            color: AppColors.surfaceMuted,
            borderRadius: AppRadius.radiusMd,
          ),
        ),
      ),
    );
  }
}

class _ErrorBlock extends StatelessWidget {
  final String error;
  const _ErrorBlock({required this.error});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Text(
          'Қате: $error',
          style: AppTypography.bodySecondary,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
