import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/enums.dart';
import '../../../models/tournament.dart';

class TournamentCard extends StatelessWidget {
  final Tournament tournament;
  final VoidCallback onTap;
  final VoidCallback? onPrimaryAction;

  const TournamentCard({
    super.key,
    required this.tournament,
    required this.onTap,
    this.onPrimaryAction,
  });

  String get _dateRange {
    final fmt = DateFormat('d MMM', 'kk');
    final a = fmt.format(tournament.startsAt);
    final b = tournament.endsAt == null ? '' : fmt.format(tournament.endsAt!);
    return b.isEmpty ? a : '$a — $b';
  }

  ({Color bg, Color fg, String label}) get _statusStyle {
    switch (tournament.status) {
      case TournamentStatus.active:
        return (bg: AppColors.jadeSurface, fg: AppColors.jadeDark, label: 'БЕЛСЕНДІ');
      case TournamentStatus.upcoming:
        return (
          bg: AppColors.eagleBlueSurface,
          fg: AppColors.eagleBlueDark,
          label: 'АЛДАҒЫ',
        );
      case TournamentStatus.registration:
        return (
          bg: AppColors.steppeGoldSurface,
          fg: AppColors.steppeGoldDark,
          label: 'ТІРКЕЛУ',
        );
      case TournamentStatus.finished:
        return (
          bg: AppColors.surfaceMuted,
          fg: AppColors.textSecondary,
          label: 'АЯҚТАЛҒАН',
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = _statusStyle;
    final isFinished = tournament.status == TournamentStatus.finished;
    return Material(
      color: AppColors.surface,
      borderRadius: AppRadius.radiusLg,
      child: InkWell(
        onTap: onTap,
        borderRadius: AppRadius.radiusLg,
        child: Container(
          margin: const EdgeInsets.only(bottom: AppSpacing.md),
          padding: const EdgeInsets.all(AppSpacing.md),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: AppRadius.radiusLg,
            border: Border.all(color: AppColors.border),
            boxShadow: const [
              BoxShadow(
                color: AppColors.shadowSoft,
                blurRadius: 12,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [
                          AppColors.steppeGoldLight,
                          AppColors.steppeGold,
                        ],
                      ),
                      borderRadius: AppRadius.radiusMd,
                    ),
                    child: const Center(
                      child: Text('🏆', style: TextStyle(fontSize: 28)),
                    ),
                  ),
                  AppSpacing.gapH12,
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tournament.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: AppTypography.body.copyWith(
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        AppSpacing.gapV4,
                        _StatusBadge(bg: s.bg, fg: s.fg, label: s.label),
                      ],
                    ),
                  ),
                ],
              ),
              AppSpacing.gapV12,
              Row(
                children: [
                  _Stat(
                    icon: Icons.calendar_today_rounded,
                    label: _dateRange,
                  ),
                  AppSpacing.gapH16,
                  _Stat(
                    icon: Icons.people_alt_rounded,
                    label: tournament.maxParticipants > 0
                        ? '${tournament.participantCount} / ${tournament.maxParticipants}'
                        : '${tournament.participantCount}',
                  ),
                ],
              ),
              AppSpacing.gapV12,
              _PrizePreview(coins: tournament.prizeCoins),
              AppSpacing.gapV12,
              SizedBox(
                width: double.infinity,
                height: 44,
                child: FilledButton(
                  onPressed: onPrimaryAction ?? onTap,
                  style: FilledButton.styleFrom(
                    backgroundColor: tournament.isRegistered || isFinished
                        ? AppColors.eagleBlue
                        : AppColors.steppeGold,
                    shape: RoundedRectangleBorder(
                      borderRadius: AppRadius.radiusMd,
                    ),
                  ),
                  child: Text(
                    isFinished
                        ? 'Көру'
                        : tournament.isRegistered
                            ? 'Көру'
                            : 'Қосылу',
                    style: AppTypography.button.copyWith(
                      color: AppColors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final Color bg;
  final Color fg;
  final String label;

  const _StatusBadge({
    required this.bg,
    required this.fg,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: AppTypography.caption.copyWith(
          color: fg,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final IconData icon;
  final String label;

  const _Stat({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: AppColors.textSecondary),
        const SizedBox(width: 4),
        Text(
          label,
          style: AppTypography.caption.copyWith(
            color: AppColors.textSecondary,
          ),
        ),
      ],
    );
  }
}

class _PrizePreview extends StatelessWidget {
  final int coins;
  const _PrizePreview({required this.coins});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.sm, vertical: AppSpacing.xs),
      decoration: BoxDecoration(
        color: AppColors.steppeGoldSurface,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.steppeGold.withValues(alpha: 0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.card_giftcard_rounded,
              color: AppColors.steppeGoldDark, size: 16),
          const SizedBox(width: 6),
          Text(
            'Жүлде:  💰 $coins',
            style: AppTypography.caption.copyWith(
              color: AppColors.steppeGoldDark,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}
