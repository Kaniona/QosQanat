import 'package:flutter/widgets.dart';

/// Global keys attached to the real widgets the first-run tutorial spotlights.
///
/// Both the [MainShell] (tab bar, drawer handle) and the Home screen (HUD, news
/// feed) attach these to their widgets so [TutorialOverlay] can resolve each
/// target's on-screen rect via its [RenderBox]. A single shell + single Home
/// instance keeps these keys unique.
class TutorialKeys {
  TutorialKeys._();

  static final GlobalKey hud = GlobalKey(debugLabel: 'tutorial.hud');
  static final GlobalKey newsFeed = GlobalKey(debugLabel: 'tutorial.news');
  static final GlobalKey learnTab = GlobalKey(debugLabel: 'tutorial.learnTab');
  static final GlobalKey shopTab = GlobalKey(debugLabel: 'tutorial.shopTab');
  static final GlobalKey drawerHandle =
      GlobalKey(debugLabel: 'tutorial.drawerHandle');
}
