import 'package:flutter/material.dart';

import '../../core/constants/onboarding_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import 'tutorial_keys.dart';

/// A single step of the spotlight tour.
class _TutorialStep {
  /// The widget to spotlight, or `null` for a centered informational card.
  final GlobalKey? target;
  final String title;
  final String body;
  final IconData icon;

  const _TutorialStep({
    required this.title,
    required this.body,
    required this.icon,
    this.target,
  });
}

/// First-run spotlight tour shown over the main shell. Dims the screen, cuts a
/// glowing hole around each highlighted element, and explains it in Kazakh.
/// Calls [onFinish] when the user completes or skips the tour.
class TutorialOverlay extends StatefulWidget {
  final VoidCallback onFinish;

  const TutorialOverlay({super.key, required this.onFinish});

  @override
  State<TutorialOverlay> createState() => _TutorialOverlayState();
}

class _TutorialOverlayState extends State<TutorialOverlay> {
  int _index = 0;

  static final List<_TutorialStep> _steps = [
    _TutorialStep(
      target: TutorialKeys.hud,
      icon: Icons.military_tech_rounded,
      title: OnboardingStrings.hudTitle,
      body: OnboardingStrings.hudBody,
    ),
    _TutorialStep(
      target: TutorialKeys.newsFeed,
      icon: Icons.campaign_rounded,
      title: OnboardingStrings.newsTitle,
      body: OnboardingStrings.newsBody,
    ),
    _TutorialStep(
      target: TutorialKeys.learnTab,
      icon: Icons.school_rounded,
      title: OnboardingStrings.learnTitle,
      body: OnboardingStrings.learnBody,
    ),
    _TutorialStep(
      target: TutorialKeys.shopTab,
      icon: Icons.storefront_rounded,
      title: OnboardingStrings.shopTitle,
      body: OnboardingStrings.shopBody,
    ),
    _TutorialStep(
      target: TutorialKeys.drawerHandle,
      icon: Icons.menu_open_rounded,
      title: OnboardingStrings.drawerTitle,
      body: OnboardingStrings.drawerBody,
    ),
    _TutorialStep(
      icon: Icons.checklist_rounded,
      title: OnboardingStrings.questsTitle,
      body: OnboardingStrings.questsBody,
    ),
    _TutorialStep(
      icon: Icons.emoji_events_rounded,
      title: OnboardingStrings.finishTitle,
      body: OnboardingStrings.finishBody,
    ),
  ];

  bool get _isLast => _index == _steps.length - 1;

  void _next() {
    if (_isLast) {
      widget.onFinish();
    } else {
      setState(() => _index++);
    }
  }

  Rect? _rectFor(GlobalKey? key) {
    if (key == null) return null;
    final ctx = key.currentContext;
    if (ctx == null) return null;
    final box = ctx.findRenderObject() as RenderBox?;
    if (box == null || !box.hasSize) return null;
    return box.localToGlobal(Offset.zero) & box.size;
  }

  @override
  Widget build(BuildContext context) {
    final step = _steps[_index];
    var hole = _rectFor(step.target);

    // The target may not be laid out on the very first frame; retry next frame.
    if (step.target != null && hole == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) setState(() {});
      });
    }

    final size = MediaQuery.of(context).size;
    // Keep the cutout within the visible area.
    final paddedHole = hole?.inflate(8);

    return Material(
      type: MaterialType.transparency,
      child: Stack(
        children: [
          // Tappable scrim with the spotlight cutout. Tapping advances.
          Positioned.fill(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: _next,
              child: CustomPaint(
                painter: _SpotlightPainter(rect: paddedHole, radius: 18),
              ),
            ),
          ),
          _card(context, hole: hole, screen: size, step: step),
        ],
      ),
    );
  }

  Widget _card(
    BuildContext context, {
    required Rect? hole,
    required Size screen,
    required _TutorialStep step,
  }) {
    // Decide whether the card sits above or below the spotlight. Centered when
    // there is no target.
    final Widget card = _TutorialCard(
      icon: step.icon,
      title: step.title,
      body: step.body,
      stepIndex: _index,
      stepCount: _steps.length,
      isLast: _isLast,
      onNext: _next,
      onSkip: widget.onFinish,
    );

    if (hole == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: card,
        ),
      );
    }

    final placeBelow = hole.center.dy < screen.height * 0.55;
    return Positioned(
      left: AppSpacing.lg,
      right: AppSpacing.lg,
      top: placeBelow ? hole.bottom + AppSpacing.lg : null,
      bottom: placeBelow ? null : screen.height - hole.top + AppSpacing.lg,
      child: card,
    );
  }
}

/// The explanatory card with icon, text, progress dots, and controls.
class _TutorialCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;
  final int stepIndex;
  final int stepCount;
  final bool isLast;
  final VoidCallback onNext;
  final VoidCallback onSkip;

  const _TutorialCard({
    required this.icon,
    required this.title,
    required this.body,
    required this.stepIndex,
    required this.stepCount,
    required this.isLast,
    required this.onNext,
    required this.onSkip,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusXl,
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowMedium,
            blurRadius: 28,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: const BoxDecoration(
                  gradient: AppColors.eagle,
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: AppColors.white, size: 22),
              ),
              AppSpacing.gapH12,
              Expanded(child: Text(title, style: AppTypography.h3)),
            ],
          ),
          AppSpacing.gapV12,
          Text(body, style: AppTypography.bodySecondary),
          AppSpacing.gapV16,
          Row(
            children: [
              _Dots(count: stepCount, active: stepIndex),
              const Spacer(),
              if (!isLast)
                TextButton(
                  onPressed: onSkip,
                  child: Text(
                    OnboardingStrings.skipButton,
                    style: AppTypography.body.copyWith(
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              AppSpacing.gapH8,
              _NextButton(
                label: isLast
                    ? OnboardingStrings.finishButton
                    : OnboardingStrings.nextButton,
                onTap: onNext,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _NextButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _NextButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: AppColors.eagle,
        borderRadius: AppRadius.radiusPill,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: AppRadius.radiusPill,
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.lg,
              vertical: AppSpacing.sm,
            ),
            child: Text(
              label,
              style: AppTypography.button.copyWith(fontSize: 15),
            ),
          ),
        ),
      ),
    );
  }
}

class _Dots extends StatelessWidget {
  final int count;
  final int active;

  const _Dots({required this.count, required this.active});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 0; i < count; i++)
          AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            margin: const EdgeInsets.only(right: 5),
            width: i == active ? 18 : 7,
            height: 7,
            decoration: BoxDecoration(
              color: i == active ? AppColors.eagleBlue : AppColors.border,
              borderRadius: AppRadius.radiusPill,
            ),
          ),
      ],
    );
  }
}

/// Paints the dark scrim with a rounded-rect hole punched around the target.
class _SpotlightPainter extends CustomPainter {
  final Rect? rect;
  final double radius;

  _SpotlightPainter({required this.rect, required this.radius});

  @override
  void paint(Canvas canvas, Size size) {
    final scrim = Paint()..color = AppColors.nightInk.withValues(alpha: 0.84);
    final full = Rect.fromLTWH(0, 0, size.width, size.height);

    if (rect == null) {
      canvas.drawRect(full, scrim);
      return;
    }

    final hole = RRect.fromRectAndRadius(rect!, Radius.circular(radius));
    final path = Path.combine(
      PathOperation.difference,
      Path()..addRect(full),
      Path()..addRRect(hole),
    );
    canvas.drawPath(path, scrim);

    // Glowing gold ring around the spotlight.
    final ring = Paint()
      ..color = AppColors.steppeGold
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5;
    canvas.drawRRect(hole, ring);
  }

  @override
  bool shouldRepaint(covariant _SpotlightPainter old) =>
      old.rect != rect || old.radius != radius;
}
