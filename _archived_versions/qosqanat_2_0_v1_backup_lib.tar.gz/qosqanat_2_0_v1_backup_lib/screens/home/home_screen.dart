import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/home_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../core/utils/date_format.dart';
import '../../models/news_item.dart';
import '../../models/user.dart';
import '../../navigation/app_routes.dart';
import '../../navigation/main_shell.dart';
import '../../providers/auth_provider.dart';
import '../../providers/game_provider.dart';
import '../../providers/news_provider.dart';
import '../../widgets/avatar/equipped_avatar.dart';
import '../../widgets/ui/aurora_background.dart';
import '../../widgets/ui/oyu_ornek_divider.dart';
import '../onboarding/tutorial_keys.dart';
import 'widgets/home_hud.dart';
import 'widgets/news_card.dart';

/// Home tab: top HUD, a time-based greeting with the companion peeking, and the
/// admin news feed (pull-to-refresh). Designed to sit inside the 5-tab shell.
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  bool _seeded = false;

  /// Seeds the game state from the loaded profile once, and runs the daily
  /// streak check.
  void _seedFromUser(AppUser user) {
    if (_seeded) return;
    _seeded = true;
    final game = ref.read(gameProvider.notifier);
    game.setGameState(user);
    game.checkStreak();
  }

  void _openNews(NewsItem item) {
    context.push(AppRoutes.newsDetail, extra: item);
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider).asData?.value;
    final game = ref.watch(gameProvider);

    // Seed game state once the profile is available (after the frame, since we
    // can't mutate a provider during build).
    if (user != null && !_seeded) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _seedFromUser(user);
      });
    }

    return Scaffold(
      body: AuroraBackground(
        light: true,
        child: SafeArea(
        child: Column(
          children: [
            KeyedSubtree(
              key: TutorialKeys.hud,
              child: HomeHud(
                level: game.level,
                akylPoints: game.akylPoints,
                coins: game.coins,
                profilePhotoUrl: user?.profilePhotoUrl,
                onProfileTap: () => MainShell.goToBranch(4),
              ),
            ),
            const OyuOrnekDivider(),
            Expanded(
              child: KeyedSubtree(
                key: TutorialKeys.newsFeed,
                child: RefreshIndicator(
                  color: AppColors.eagleBlue,
                  onRefresh: () => ref.refresh(newsProvider.future),
                  child: _NewsFeed(
                    user: user,
                    onOpenNews: _openNews,
                  ),
                ),
              ),
            ),
          ],
        ),
        ),
      ),
    );
  }
}

/// Greeting + section title + the news list, with loading/empty/error states.
class _NewsFeed extends ConsumerWidget {
  final AppUser? user;
  final ValueChanged<NewsItem> onOpenNews;

  const _NewsFeed({required this.user, required this.onOpenNews});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final newsAsync = ref.watch(newsProvider);

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.lg,
        AppSpacing.md,
        AppSpacing.lg,
        AppSpacing.xxl,
      ),
      children: [
        _Greeting(user: user),
        AppSpacing.gapV20,
        Text(HomeStrings.newsTitle, style: AppTypography.h3),
        AppSpacing.gapV16,
        newsAsync.when(
          loading: () => const _NewsLoading(),
          error: (_, _) => const _NewsMessage(
            icon: Icons.cloud_off_rounded,
            message: HomeStrings.newsError,
          ),
          data: (items) {
            if (items.isEmpty) {
              return const _NewsMessage(
                icon: Icons.feed_outlined,
                message: HomeStrings.emptyNews,
              );
            }
            return Column(
              children: [
                for (final item in items)
                  NewsCard(item: item, onTap: () => onOpenNews(item)),
              ],
            );
          },
        ),
      ],
    );
  }
}

/// Time-based greeting with the assistant peeking small at the side.
class _Greeting extends StatelessWidget {
  final AppUser? user;

  const _Greeting({required this.user});

  @override
  Widget build(BuildContext context) {
    final firstName = (user?.fullName ?? '').trim().split(' ').first;
    final greeting = kazakhGreeting();

    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                firstName.isEmpty ? '$greeting!' : '$greeting, $firstName!',
                style: AppTypography.h2,
              ),
            ],
          ),
        ),
        if (user != null)
          // Small peek so the news stays the focus. Watches equipment so the
          // greeting reflects whatever the player just bought in the Shop.
          EquippedAvatar(
            assistantType: user!.assistantType,
            size: 56,
          ),
      ],
    );
  }
}

class _NewsLoading extends StatelessWidget {
  const _NewsLoading();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(
        3,
        (_) => Container(
          height: 120,
          margin: const EdgeInsets.only(bottom: AppSpacing.md),
          decoration: BoxDecoration(
            color: AppColors.surfaceMuted,
            borderRadius: AppRadius.radiusLg,
          ),
        ),
      ),
    );
  }
}

class _NewsMessage extends StatelessWidget {
  final IconData icon;
  final String message;

  const _NewsMessage({required this.icon, required this.message});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.xxl),
      child: Column(
        children: [
          Icon(icon, size: 48, color: AppColors.textTertiary),
          AppSpacing.gapV12,
          Text(
            message,
            textAlign: TextAlign.center,
            style: AppTypography.bodySecondary,
          ),
        ],
      ),
    );
  }
}
