import 'package:flutter/material.dart';

import '../../../core/constants/home_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_elevation.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../widgets/ui/animated_number.dart';
import '../../../widgets/ui/clay_container.dart';
import '../../../widgets/ui/glass_panel.dart';
import '../../../widgets/ui/pressable.dart';
import '../../../widgets/ui/profile_photo.dart';

/// Top status bar (HUD), left → right:
/// level badge → akyl pill → coins pill → profile photo (tappable).
class HomeHud extends StatelessWidget {
  final int level;
  final int akylPoints;
  final int coins;
  final String? profilePhotoUrl;
  final VoidCallback onProfileTap;

  const HomeHud({
    super.key,
    required this.level,
    required this.akylPoints,
    required this.coins,
    required this.profilePhotoUrl,
    required this.onProfileTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.lg,
        AppSpacing.sm,
        AppSpacing.lg,
        AppSpacing.sm,
      ),
      child: Row(
        children: [
          _LevelBadge(level: level),
          AppSpacing.gapH12,
          _StatPill(
            icon: Icons.bolt_rounded,
            iconColor: AppColors.cosmicPurple,
            value: akylPoints,
          ),
          AppSpacing.gapH8,
          _StatPill(
            icon: Icons.monetization_on_rounded,
            iconColor: AppColors.steppeGold,
            value: coins,
            grouped: true,
          ),
          const Spacer(),
          _ProfilePhoto(url: profilePhotoUrl, onTap: onProfileTap),
        ],
      ),
    );
  }
}

class _LevelBadge extends StatelessWidget {
  final int level;

  const _LevelBadge({required this.level});

  @override
  Widget build(BuildContext context) {
    return ClayContainer(
      width: 48,
      height: 48,
      radius: 24,
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [AppColors.steppeGoldLight, AppColors.steppeGold],
      ),
      glow: const Color(0x80D4860A),
      alignment: Alignment.center,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedNumber(
            value: level,
            style: AppTypography.display(
              size: 17,
              weight: FontWeight.w800,
              color: AppColors.white,
            ).copyWith(height: 1),
          ),
          Text(
            HomeStrings.levelShort,
            style: TextStyle(
              fontSize: 8,
              height: 1,
              fontWeight: FontWeight.w800,
              color: AppColors.white.withValues(alpha: 0.85),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatPill extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final int value;
  final bool grouped;

  const _StatPill({
    required this.icon,
    required this.iconColor,
    required this.value,
    this.grouped = false,
  });

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: AppRadius.pill,
      brightness: Brightness.light,
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: 7),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 18, color: iconColor),
          AppSpacing.gapH4,
          AnimatedNumber(
            value: value,
            grouped: grouped,
            style: AppTypography.display(
              size: 14,
              weight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfilePhoto extends StatelessWidget {
  final String? url;
  final VoidCallback onTap;

  const _ProfilePhoto({required this.url, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final hasPhoto = url != null && url!.isNotEmpty;
    return Pressable(
      onTap: onTap,
      pressedScale: 0.9,
      child: Container(
        width: 44,
        height: 44,
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          gradient: AppColors.goldSoar,
          shape: BoxShape.circle,
          boxShadow: AppElevation.raised,
        ),
        child: ClipOval(
          child: hasPhoto
              ? ProfilePhoto(
                  url: url,
                  fallback: const _DefaultAvatar(),
                )
              : const _DefaultAvatar(),
        ),
      ),
    );
  }
}

class _DefaultAvatar extends StatelessWidget {
  const _DefaultAvatar();

  @override
  Widget build(BuildContext context) {
    return const ColoredBox(
      color: AppColors.eagleBlueSurface,
      child: Icon(Icons.person_rounded, color: AppColors.eagleBlue, size: 26),
    );
  }
}
