import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../../../core/constants/home_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/utils/date_format.dart';
import '../../../models/news_item.dart';
import '../../../widgets/ui/clay_container.dart';
import '../../../widgets/ui/pressable.dart';

/// Maps a news category to a chip color. Categories are admin-defined Kazakh
/// labels (Жаңарту / Іс-шара / Кеңес / Турнир); unknown values fall back to a
/// neutral accent.
Color _categoryColor(String? category) {
  switch (category) {
    case 'Жаңарту':
      return AppColors.eagleBlue;
    case 'Іс-шара':
      return AppColors.cosmicPurple;
    case 'Кеңес':
      return AppColors.jade;
    case 'Турнир':
      return AppColors.steppeGold;
    default:
      return AppColors.textSecondary;
  }
}

/// A single admin-posted announcement card in the Home feed.
class NewsCard extends StatelessWidget {
  final NewsItem item;
  final VoidCallback onTap;

  const NewsCard({super.key, required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.md),
      child: Pressable(
      onTap: onTap,
      borderRadius: AppRadius.radiusLg,
      child: ClayContainer(
        radius: AppRadius.lg,
        clip: true,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (item.imageUrl != null && item.imageUrl!.isNotEmpty)
              CachedNetworkImage(
                imageUrl: item.imageUrl!,
                height: 150,
                width: double.infinity,
                fit: BoxFit.cover,
                placeholder: (_, _) => const SizedBox(
                  height: 150,
                  child: ColoredBox(color: AppColors.surfaceMuted),
                ),
                errorWidget: (_, _, _) => const SizedBox.shrink(),
              ),
            Padding(
              padding: const EdgeInsets.all(AppSpacing.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (item.category != null && item.category!.isNotEmpty) ...[
                    _CategoryChip(label: item.category!),
                    AppSpacing.gapV12,
                  ],
                  Text(
                    item.title,
                    style: AppTypography.h3,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  AppSpacing.gapV8,
                  Text(
                    item.body,
                    style: AppTypography.bodySecondary,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  AppSpacing.gapV12,
                  Row(
                    children: [
                      Text(
                        kazakhDate(item.publishedAt),
                        style: AppTypography.caption,
                      ),
                      const Spacer(),
                      Text(
                        HomeStrings.readMore,
                        style: AppTypography.caption.copyWith(
                          color: AppColors.eagleBlue,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  final String label;

  const _CategoryChip({required this.label});

  @override
  Widget build(BuildContext context) {
    final color = _categoryColor(label);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: AppRadius.radiusPill,
      ),
      child: Text(
        label,
        style: AppTypography.caption.copyWith(
          color: color,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}
