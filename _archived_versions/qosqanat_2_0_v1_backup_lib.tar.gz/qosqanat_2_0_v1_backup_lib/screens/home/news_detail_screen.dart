import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../core/utils/date_format.dart';
import '../../models/news_item.dart';

/// Full-article view for a single news announcement.
class NewsDetailScreen extends StatelessWidget {
  final NewsItem item;

  const NewsDetailScreen({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final hasImage = item.imageUrl != null && item.imageUrl!.isNotEmpty;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: hasImage ? 240 : kToolbarHeight,
            backgroundColor: AppColors.surface,
            flexibleSpace: hasImage
                ? FlexibleSpaceBar(
                    background: CachedNetworkImage(
                      imageUrl: item.imageUrl!,
                      fit: BoxFit.cover,
                      placeholder: (_, _) =>
                          const ColoredBox(color: AppColors.surfaceMuted),
                      errorWidget: (_, _, _) =>
                          const ColoredBox(color: AppColors.surfaceMuted),
                    ),
                  )
                : null,
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: AppSpacing.screenPadding,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AppSpacing.gapV16,
                  if (item.category != null && item.category!.isNotEmpty) ...[
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppSpacing.sm,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.eagleBlueSurface,
                        borderRadius: AppRadius.radiusPill,
                      ),
                      child: Text(
                        item.category!,
                        style: AppTypography.caption.copyWith(
                          color: AppColors.eagleBlue,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    AppSpacing.gapV12,
                  ],
                  Text(item.title, style: AppTypography.h1),
                  AppSpacing.gapV8,
                  Row(
                    children: [
                      if (item.authorName != null) ...[
                        Text(item.authorName!, style: AppTypography.caption),
                        AppSpacing.gapH8,
                        const Text('•', style: TextStyle(color: AppColors.textTertiary)),
                        AppSpacing.gapH8,
                      ],
                      Text(kazakhDate(item.publishedAt),
                          style: AppTypography.caption),
                    ],
                  ),
                  AppSpacing.gapV20,
                  Text(item.body, style: AppTypography.bodyLarge),
                  AppSpacing.gapV32,
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
