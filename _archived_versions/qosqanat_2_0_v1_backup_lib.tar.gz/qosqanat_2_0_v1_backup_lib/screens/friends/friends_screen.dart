import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../providers/social_provider.dart';
import '../../services/api_service.dart';
import 'widgets/friend_card.dart';
import 'widgets/request_card.dart';

class FriendsScreen extends ConsumerStatefulWidget {
  const FriendsScreen({super.key});

  @override
  ConsumerState<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends ConsumerState<FriendsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  /// 'level' | 'akyl' | 'name'
  String _sort = 'akyl';

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _refreshAll() async {
    ref.invalidate(friendsProvider);
    ref.invalidate(pendingRequestsProvider);
    await Future<void>.delayed(const Duration(milliseconds: 50));
  }

  void _openBattleSetup(FriendUser friend) {
    context.push('/battle/setup', extra: friend);
  }

  void _openProfile(String userId) {
    // Viewing another student's full profile is not built yet; acknowledge the
    // tap rather than navigating into the current user's own profile tab.
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Дос профилі жақын арада қосылады'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pendingCount = ref.watch(incomingRequestCountProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _Header(),
            _TabsBar(controller: _tabs, pendingCount: pendingCount),
            Expanded(
              child: RefreshIndicator(
                onRefresh: _refreshAll,
                color: AppColors.eagleBlue,
                child: TabBarView(
                  controller: _tabs,
                  children: [
                    _FriendsTab(
                      sort: _sort,
                      onSortChange: (s) => setState(() => _sort = s),
                      onBattle: _openBattleSetup,
                      onProfile: _openProfile,
                    ),
                    const _RequestsTab(),
                    _SearchTab(onBattle: _openBattleSetup),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.lg, AppSpacing.md, AppSpacing.lg, AppSpacing.xs),
      child: Row(
        children: [
          const Text('👥', style: TextStyle(fontSize: 28)),
          AppSpacing.gapH8,
          Text('Достар', style: AppTypography.h1),
        ],
      ),
    );
  }
}

class _TabsBar extends StatelessWidget {
  final TabController controller;
  final int pendingCount;

  const _TabsBar({required this.controller, required this.pendingCount});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
      child: TabBar(
        controller: controller,
        labelColor: AppColors.eagleBlue,
        unselectedLabelColor: AppColors.textSecondary,
        indicatorColor: AppColors.eagleBlue,
        indicatorWeight: 3,
        labelStyle:
            AppTypography.body.copyWith(fontWeight: FontWeight.w800),
        dividerColor: Colors.transparent,
        tabs: [
          const Tab(text: 'Достарым'),
          Tab(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Өтінімдер'),
                if (pendingCount > 0) ...[
                  const SizedBox(width: 6),
                  _BadgeDot(count: pendingCount),
                ],
              ],
            ),
          ),
          const Tab(text: 'Іздеу'),
        ],
      ),
    );
  }
}

class _BadgeDot extends StatelessWidget {
  final int count;
  const _BadgeDot({required this.count});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: const BoxDecoration(
        color: AppColors.coral,
        shape: BoxShape.circle,
      ),
      child: Text(
        '$count',
        style: const TextStyle(
          color: AppColors.white,
          fontWeight: FontWeight.w800,
          fontSize: 11,
        ),
      ),
    );
  }
}

// =============================================================================
// Friends tab
// =============================================================================

class _FriendsTab extends ConsumerWidget {
  final String sort;
  final ValueChanged<String> onSortChange;
  final ValueChanged<FriendUser> onBattle;
  final ValueChanged<String> onProfile;

  const _FriendsTab({
    required this.sort,
    required this.onSortChange,
    required this.onBattle,
    required this.onProfile,
  });

  List<FriendUser> _sorted(List<FriendUser> friends) {
    final list = [...friends];
    switch (sort) {
      case 'level':
        list.sort((a, b) => b.level.compareTo(a.level));
      case 'name':
        list.sort((a, b) => a.fullName.compareTo(b.fullName));
      default:
        list.sort((a, b) => b.akylPoints.compareTo(a.akylPoints));
    }
    return list;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final friends = ref.watch(friendsProvider);

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.md, AppSpacing.sm, AppSpacing.md, AppSpacing.xxl),
      children: [
        _SortBar(sort: sort, onChange: onSortChange),
        AppSpacing.gapV12,
        friends.when(
          loading: () => const _LoadingList(),
          error: (e, _) => _ErrorBlock(error: e.toString()),
          data: (list) {
            if (list.isEmpty) return const _EmptyFriends();
            final sorted = _sorted(list);
            return Column(
              children: [
                for (final f in sorted)
                  FriendCard(
                    friend: f,
                    onBattle: () => onBattle(f),
                    onProfile: () => onProfile(f.userId),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _SortBar extends StatelessWidget {
  final String sort;
  final ValueChanged<String> onChange;

  const _SortBar({required this.sort, required this.onChange});

  @override
  Widget build(BuildContext context) {
    Widget chip(String key, String label, IconData icon) {
      final on = sort == key;
      return Padding(
        padding: const EdgeInsets.only(right: 8),
        child: Material(
          color: on ? AppColors.eagleBlue : AppColors.surfaceMuted,
          borderRadius: BorderRadius.circular(999),
          child: InkWell(
            borderRadius: BorderRadius.circular(999),
            onTap: () => onChange(key),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon,
                      size: 14,
                      color:
                          on ? AppColors.white : AppColors.textSecondary),
                  const SizedBox(width: 4),
                  Text(
                    label,
                    style: AppTypography.caption.copyWith(
                      color:
                          on ? AppColors.white : AppColors.textSecondary,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          chip('akyl', 'Ақыл', Icons.star_rounded),
          chip('level', 'Деңгей', Icons.shield_moon_rounded),
          chip('name', 'Аты-жөні', Icons.sort_by_alpha_rounded),
        ],
      ),
    );
  }
}

class _EmptyFriends extends StatelessWidget {
  const _EmptyFriends();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.xxl),
      child: Column(
        children: [
          const Icon(Icons.group_outlined,
              size: 64, color: AppColors.textTertiary),
          AppSpacing.gapV12,
          Text(
            'Достарың әзірге жоқ',
            style: AppTypography.h3.copyWith(color: AppColors.textSecondary),
          ),
          AppSpacing.gapV4,
          Text(
            '"Іздеу" қойындысынан QQ-ID арқылы дос қос',
            style: AppTypography.bodySecondary,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// Requests tab
// =============================================================================

class _RequestsTab extends ConsumerWidget {
  const _RequestsTab();

  Future<void> _accept(WidgetRef ref, String id, BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await ref.read(apiServiceProvider).acceptFriendRequest(id);
      ref.invalidate(pendingRequestsProvider);
      ref.invalidate(friendsProvider);
    } catch (e) {
      _showOn(messenger, e.toString(), AppColors.coral);
    }
  }

  Future<void> _decline(WidgetRef ref, String id, BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await ref.read(apiServiceProvider).declineFriendRequest(id);
      ref.invalidate(pendingRequestsProvider);
    } catch (e) {
      _showOn(messenger, e.toString(), AppColors.coral);
    }
  }

  static void _showOn(
      ScaffoldMessengerState messenger, String msg, Color bg) {
    messenger.showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: bg,
      behavior: SnackBarBehavior.floating,
    ));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final pending = ref.watch(pendingRequestsProvider);
    return pending.when(
      loading: () => const _LoadingList(),
      error: (e, _) => _ErrorBlock(error: e.toString()),
      data: (list) {
        if (list.isEmpty) {
          return ListView(
            padding: const EdgeInsets.symmetric(vertical: AppSpacing.xxl),
            children: [
              Column(
                children: [
                  const Icon(Icons.mark_email_read_outlined,
                      size: 64, color: AppColors.textTertiary),
                  AppSpacing.gapV12,
                  Text(
                    'Жаңа өтінім жоқ',
                    style: AppTypography.h3
                        .copyWith(color: AppColors.textSecondary),
                  ),
                ],
              ),
            ],
          );
        }
        final incoming = list
            .where((r) => r.direction == RequestDirection.incoming)
            .toList();
        final outgoing = list
            .where((r) => r.direction == RequestDirection.outgoing)
            .toList();

        return ListView(
          padding: const EdgeInsets.fromLTRB(
              AppSpacing.md, AppSpacing.sm, AppSpacing.md, AppSpacing.xxl),
          children: [
            if (incoming.isNotEmpty) ...[
              _SectionTitle(text: 'Кіріс өтінімдер'),
              AppSpacing.gapV8,
              for (final r in incoming)
                RequestCard(
                  request: r,
                  onAccept: () => _accept(ref, r.friendshipId, context),
                  onDecline: () => _decline(ref, r.friendshipId, context),
                ),
              AppSpacing.gapV16,
            ],
            if (outgoing.isNotEmpty) ...[
              _SectionTitle(text: 'Шығыс өтінімдер'),
              AppSpacing.gapV8,
              for (final r in outgoing)
                RequestCard(
                  request: r,
                  onCancel: () => _decline(ref, r.friendshipId, context),
                ),
            ],
          ],
        );
      },
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle({required this.text});

  @override
  Widget build(BuildContext context) {
    return Text(text,
        style: AppTypography.caption.copyWith(
          color: AppColors.textSecondary,
          letterSpacing: 0.5,
        ));
  }
}

// =============================================================================
// Search tab
// =============================================================================

class _SearchTab extends ConsumerStatefulWidget {
  final ValueChanged<FriendUser> onBattle;
  const _SearchTab({required this.onBattle});

  @override
  ConsumerState<_SearchTab> createState() => _SearchTabState();
}

class _SearchTabState extends ConsumerState<_SearchTab> {
  final _controller = TextEditingController();
  FriendUser? _result;
  bool _loading = false;
  String? _error;
  bool _searched = false;
  bool _requestSent = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final q = _controller.text.trim();
    if (q.isEmpty) return;
    setState(() {
      _loading = true;
      _error = null;
      _searched = true;
      _requestSent = false;
    });
    try {
      final user =
          await ref.read(apiServiceProvider).searchUserByQosqanatId(q);
      setState(() {
        _result = user;
      });
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _addFriend(FriendUser user) async {
    setState(() => _error = null);
    try {
      await ref.read(apiServiceProvider).sendFriendRequest(user.userId);
      setState(() => _requestSent = true);
      ref.invalidate(pendingRequestsProvider);
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(
          AppSpacing.md, AppSpacing.sm, AppSpacing.md, AppSpacing.xxl),
      children: [
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _controller,
                textCapitalization: TextCapitalization.characters,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(
                      RegExp(r'[A-Za-z0-9\-]')),
                  LengthLimitingTextInputFormatter(14),
                  TextInputFormatter.withFunction(
                    (oldValue, newValue) => TextEditingValue(
                      text: newValue.text.toUpperCase(),
                      selection: newValue.selection,
                    ),
                  ),
                ],
                decoration: InputDecoration(
                  hintText: 'QQ-XXXXXXXXX',
                  hintStyle: AppTypography.body.copyWith(
                    color: AppColors.textTertiary,
                  ),
                  prefixIcon: const Icon(Icons.search_rounded),
                  filled: true,
                  fillColor: AppColors.surface,
                  border: OutlineInputBorder(
                    borderRadius: AppRadius.radiusLg,
                    borderSide:
                        const BorderSide(color: AppColors.border),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: AppRadius.radiusLg,
                    borderSide:
                        const BorderSide(color: AppColors.border),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: AppRadius.radiusLg,
                    borderSide: const BorderSide(
                        color: AppColors.eagleBlue, width: 1.6),
                  ),
                ),
                onSubmitted: (_) => _search(),
              ),
            ),
            AppSpacing.gapH8,
            SizedBox(
              height: 50,
              child: FilledButton(
                onPressed: _loading ? null : _search,
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.eagleBlue,
                  shape: RoundedRectangleBorder(
                    borderRadius: AppRadius.radiusLg,
                  ),
                ),
                child: _loading
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          color: AppColors.white,
                          strokeWidth: 2.4,
                        ),
                      )
                    : const Text(
                        'Іздеу',
                        style: TextStyle(
                          color: AppColors.white,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
              ),
            ),
          ],
        ),
        AppSpacing.gapV16,
        if (_searched && _result == null && !_loading)
          const _SearchEmpty(),
        if (_result != null)
          _SearchResultCard(
            user: _result!,
            requestSent: _requestSent,
            onAdd: () => _addFriend(_result!),
            onBattle: () => widget.onBattle(_result!),
          ),
        if (_error != null) ...[
          AppSpacing.gapV12,
          Container(
            padding: const EdgeInsets.all(AppSpacing.sm),
            decoration: BoxDecoration(
              color: AppColors.coralSurface,
              borderRadius: AppRadius.radiusMd,
              border: Border.all(color: AppColors.coral),
            ),
            child: Row(
              children: [
                const Icon(Icons.error_outline_rounded,
                    color: AppColors.coralDark, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _error!,
                    style: AppTypography.body
                        .copyWith(color: AppColors.coralDark),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

class _SearchEmpty extends StatelessWidget {
  const _SearchEmpty();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.lg),
      child: Column(
        children: [
          const Icon(Icons.search_off_rounded,
              size: 56, color: AppColors.textTertiary),
          AppSpacing.gapV8,
          Text(
            'Бұл QQ-ID-мен оқушы табылмады',
            style: AppTypography.body.copyWith(
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _SearchResultCard extends StatelessWidget {
  final FriendUser user;
  final bool requestSent;
  final VoidCallback onAdd;
  final VoidCallback onBattle;

  const _SearchResultCard({
    required this.user,
    required this.requestSent,
    required this.onAdd,
    required this.onBattle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusLg,
        border: Border.all(color: AppColors.eagleBlue, width: 1.5),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowSoft,
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          FriendCard(
            friend: user,
            onBattle: onBattle,
            onProfile: () {},
          ),
          AppSpacing.gapV8,
          SizedBox(
            width: double.infinity,
            height: 50,
            child: FilledButton.icon(
              onPressed: requestSent ? null : onAdd,
              style: FilledButton.styleFrom(
                backgroundColor:
                    requestSent ? AppColors.jade : AppColors.eagleBlue,
                shape: RoundedRectangleBorder(
                  borderRadius: AppRadius.radiusMd,
                ),
              ),
              icon: Icon(
                requestSent ? Icons.check_rounded : Icons.person_add_rounded,
                color: AppColors.white,
              ),
              label: Text(
                requestSent ? 'Сұраныс жіберілді' : 'Дос қос +',
                style: AppTypography.button.copyWith(color: AppColors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// Shared loading/error blocks
// =============================================================================

class _LoadingList extends StatelessWidget {
  const _LoadingList();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(
        4,
        (_) => Container(
          height: 72,
          margin: const EdgeInsets.only(bottom: AppSpacing.sm),
          decoration: BoxDecoration(
            color: AppColors.surfaceMuted,
            borderRadius: AppRadius.radiusLg,
          ),
        ),
      ),
    );
  }
}

class _ErrorBlock extends StatelessWidget {
  final String error;
  const _ErrorBlock({required this.error});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.xl),
      child: Center(
        child: Text(
          'Қате: $error',
          style: AppTypography.bodySecondary,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
