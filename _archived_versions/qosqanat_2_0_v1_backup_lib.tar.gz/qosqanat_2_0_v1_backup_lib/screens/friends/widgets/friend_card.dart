import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../services/api_service.dart';
import '../../../widgets/avatar/avatar_display.dart';

/// Row card used in the "Достарым" tab: avatar with online dot, name + QQ-ID,
/// level badge, akyl points, "⚔️ Батл" and profile buttons.
class FriendCard extends StatelessWidget {
  final FriendUser friend;
  final VoidCallback onBattle;
  final VoidCallback onProfile;

  const FriendCard({
    super.key,
    required this.friend,
    required this.onBattle,
    required this.onProfile,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
      padding: const EdgeInsets.all(AppSpacing.sm),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusLg,
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowSoft,
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          _AvatarWithDot(
            assistantType: friend.assistantType,
            isOnline: friend.isOnline,
          ),
          AppSpacing.gapH12,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        friend.fullName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.body.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    AppSpacing.gapH8,
                    _LevelBadge(level: friend.level),
                  ],
                ),
                AppSpacing.gapV4,
                Row(
                  children: [
                    Text(
                      friend.qosqanatId,
                      style: AppTypography.caption.copyWith(
                        color: AppColors.textTertiary,
                      ),
                    ),
                    AppSpacing.gapH8,
                    const Icon(Icons.star_rounded,
                        color: AppColors.eagleBlue, size: 14),
                    Text(
                      ' ${friend.akylPoints}',
                      style: AppTypography.caption.copyWith(
                        color: AppColors.eagleBlue,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          AppSpacing.gapH8,
          _IconActionButton(
            icon: Icons.person_outline_rounded,
            color: AppColors.textSecondary,
            onTap: onProfile,
          ),
          AppSpacing.gapH4,
          _BattleButton(onTap: onBattle),
        ],
      ),
    );
  }
}

class _AvatarWithDot extends StatelessWidget {
  final dynamic assistantType;
  final bool isOnline;

  const _AvatarWithDot({
    required this.assistantType,
    required this.isOnline,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 60,
      height: 60,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            decoration: const BoxDecoration(
              color: AppColors.surfaceMuted,
              shape: BoxShape.circle,
            ),
            child: ClipOval(
              child: AvatarDisplay(
                assistantType: assistantType,
                size: 60,
              ),
            ),
          ),
          if (isOnline)
            Positioned(
              right: 0,
              bottom: 4,
              child: Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: AppColors.jade,
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.surface, width: 2),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _LevelBadge extends StatelessWidget {
  final int level;
  const _LevelBadge({required this.level});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        gradient: AppColors.eagle,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        'LVL $level',
        style: AppTypography.caption.copyWith(
          color: AppColors.white,
          fontWeight: FontWeight.w800,
          fontSize: 10,
        ),
      ),
    );
  }
}

class _IconActionButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _IconActionButton({
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surfaceMuted,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 40,
          height: 40,
          child: Icon(icon, color: color, size: 20),
        ),
      ),
    );
  }
}

class _BattleButton extends StatelessWidget {
  final VoidCallback onTap;
  const _BattleButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: AppRadius.radiusMd,
        child: Ink(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppColors.coralLight, AppColors.coral],
            ),
            borderRadius: AppRadius.radiusMd,
            boxShadow: [
              BoxShadow(
                color: AppColors.coral.withValues(alpha: 0.45),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Text('⚔️', style: TextStyle(fontSize: 14)),
              SizedBox(width: 4),
              Text(
                'Батл',
                style: TextStyle(
                  color: AppColors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
