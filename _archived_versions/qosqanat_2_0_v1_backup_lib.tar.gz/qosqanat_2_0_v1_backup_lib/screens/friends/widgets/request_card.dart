import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../services/api_service.dart';
import '../../../widgets/avatar/avatar_display.dart';

/// One incoming / outgoing friend-request row.
class RequestCard extends StatelessWidget {
  final PendingRequest request;
  final VoidCallback? onAccept;
  final VoidCallback? onDecline;
  final VoidCallback? onCancel;

  const RequestCard({
    super.key,
    required this.request,
    this.onAccept,
    this.onDecline,
    this.onCancel,
  });

  bool get _incoming => request.direction == RequestDirection.incoming;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
      padding: const EdgeInsets.all(AppSpacing.sm),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusLg,
        border: Border.all(
          color: _incoming ? AppColors.eagleBlue : AppColors.border,
          width: _incoming ? 1.5 : 1,
        ),
      ),
      child: Row(
        children: [
          ClipOval(
            child: AvatarDisplay(
              assistantType: request.other.assistantType,
              size: 52,
            ),
          ),
          AppSpacing.gapH12,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  request.other.fullName,
                  style: AppTypography.body.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  request.other.qosqanatId,
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textTertiary,
                  ),
                ),
              ],
            ),
          ),
          AppSpacing.gapH8,
          _incoming
              ? Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _SmallButton(
                      label: 'Қабылдау',
                      bg: AppColors.jade,
                      onTap: onAccept,
                    ),
                    AppSpacing.gapH4,
                    _SmallButton(
                      label: 'Бас тарту',
                      bg: AppColors.surfaceMuted,
                      fg: AppColors.textPrimary,
                      onTap: onDecline,
                    ),
                  ],
                )
              : _OutgoingPill(onCancel: onCancel),
        ],
      ),
    );
  }
}

class _SmallButton extends StatelessWidget {
  final String label;
  final Color bg;
  final Color fg;
  final VoidCallback? onTap;

  const _SmallButton({
    required this.label,
    required this.bg,
    this.fg = AppColors.white,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: bg,
      borderRadius: AppRadius.radiusMd,
      child: InkWell(
        onTap: onTap,
        borderRadius: AppRadius.radiusMd,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: Text(
            label,
            style: AppTypography.caption.copyWith(
              color: fg,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ),
    );
  }
}

class _OutgoingPill extends StatelessWidget {
  final VoidCallback? onCancel;
  const _OutgoingPill({this.onCancel});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onCancel,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: AppColors.steppeGoldSurface,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: AppColors.steppeGold.withValues(alpha: 0.4)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.schedule_rounded,
                color: AppColors.steppeGoldDark, size: 14),
            const SizedBox(width: 4),
            Text(
              'Күтілуде...',
              style: AppTypography.caption.copyWith(
                color: AppColors.steppeGoldDark,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
