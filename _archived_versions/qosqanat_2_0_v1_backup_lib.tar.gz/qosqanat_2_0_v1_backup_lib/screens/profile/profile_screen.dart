import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/achievements.dart';
import '../../data/levels.dart';
import '../../models/user.dart';
import '../../navigation/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../providers/game_provider.dart';
import '../../providers/social_provider.dart';
import '../../services/api_service.dart';
import 'widgets/activity_heatmap.dart';
import 'widgets/profile_hero.dart';

/// Scrollable trophy room: hero, stats grid, achievements, activity heatmap,
/// recent battles, sign-out button.
class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  bool _uploadingPhoto = false;

  Future<void> _pickPhoto() async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius:
            BorderRadius.vertical(top: Radius.circular(AppRadius.xl)),
      ),
      builder: (_) => SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            Container(
              width: 48,
              height: 5,
              decoration: BoxDecoration(
                color: AppColors.border,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
              child: Text('Суретті өзгерту', style: AppTypography.h3),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: const Icon(Icons.photo_camera_rounded,
                  color: AppColors.eagleBlue),
              title: const Text('Камерадан суретке түсу'),
              onTap: () => Navigator.pop(context, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_rounded,
                  color: AppColors.eagleBlue),
              title: const Text('Галереядан таңдау'),
              onTap: () => Navigator.pop(context, ImageSource.gallery),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (source == null) return;

    final picker = ImagePicker();
    final XFile? file = await picker.pickImage(
      source: source,
      maxWidth: 1024,
      maxHeight: 1024,
      imageQuality: 88,
    );
    if (file == null) return;

    setState(() => _uploadingPhoto = true);
    try {
      final bytes = await File(file.path).readAsBytes();
      await ref.read(apiServiceProvider).uploadProfilePhoto(
            bytes: bytes,
            filenameWithExt: file.name,
          );
      // Refresh the user profile so the hero picks up the new URL.
      ref.invalidate(currentUserProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text('Сурет жаңартылды ✓'),
          backgroundColor: AppColors.jade,
          behavior: SnackBarBehavior.floating,
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Қате: $e'),
          backgroundColor: AppColors.coral,
          behavior: SnackBarBehavior.floating,
        ));
      }
    } finally {
      if (mounted) setState(() => _uploadingPhoto = false);
    }
  }

  Future<void> _copyId(String id) async {
    if (id.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: id));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Көшірілді!'),
        backgroundColor: AppColors.jade,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(milliseconds: 1200),
      ));
    }
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.radiusLg),
        title: const Text('Шығу'),
        content: const Text('Аккаунттан шығасыз ба?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Болдырмау'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.coral),
            child: const Text('Шығу'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await ref.read(authControllerProvider.notifier).signOut();
    if (mounted) context.go(AppRoutes.welcome);
  }

  @override
  Widget build(BuildContext context) {
    final userAsync = ref.watch(currentUserProvider);
    final game = ref.watch(gameProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: userAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Қате: $e')),
        data: (user) {
          if (user == null) {
            return const Center(child: Text('Қолданушы табылмады'));
          }
          return _ProfileBody(
            user: user,
            uploadingPhoto: _uploadingPhoto,
            xpProgress: levelProgress(game.xp),
            xpLabel: '${xpIntoCurrentLevel(game.xp)} / '
                '${xpSpanForLevel(game.level)} XP',
            onEditPhoto: _pickPhoto,
            onOpenSettings: () => context.push(AppRoutes.settings),
            onCopyId: () => _copyId(user.qosqanatId),
            onLogout: _logout,
            game: game,
          );
        },
      ),
    );
  }
}

class _ProfileBody extends ConsumerWidget {
  final AppUser user;
  final bool uploadingPhoto;
  final double xpProgress;
  final String xpLabel;
  final VoidCallback onEditPhoto;
  final VoidCallback onOpenSettings;
  final VoidCallback onCopyId;
  final VoidCallback onLogout;
  final dynamic game; // GameState — kept dynamic to avoid leaky imports

  const _ProfileBody({
    required this.user,
    required this.uploadingPhoto,
    required this.xpProgress,
    required this.xpLabel,
    required this.onEditPhoto,
    required this.onOpenSettings,
    required this.onCopyId,
    required this.onLogout,
    required this.game,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final since =
        DateTime.now().toUtc().subtract(const Duration(days: 7 * 17));
    final heatmap = ref.watch(activityHeatmapProvider(since));
    final unlocked = ref.watch(unlockedAchievementsProvider);
    final friends = ref.watch(friendsProvider);
    final battles = ref.watch(recentBattlesProvider);

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        ProfileHero(
          user: user,
          uploadingPhoto: uploadingPhoto,
          xpProgress: xpProgress,
          xpLabel: xpLabel,
          onEditPhoto: onEditPhoto,
          onOpenSettings: onOpenSettings,
          onCopyId: onCopyId,
        ),
        AppSpacing.gapV20,
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _StatsGrid(
                akyl: game.akylPoints as int,
                coins: game.coins as int,
                friendsCount: friends.asData?.value.length ?? 0,
                longestStreak: game.longestStreak as int,
                tasksCompleted: user.totalTasksCompleted,
                battlesWon: user.totalBattlesWon,
              ),
              AppSpacing.gapV20,
              _AchievementsBlock(
                unlockedIds: unlocked.asData?.value ?? const {},
              ),
              AppSpacing.gapV20,
              heatmap.when(
                loading: () => const _LoadingBox(height: 160),
                error: (_, _) => const _LoadingBox(height: 160),
                data: (counts) => ActivityHeatmap(counts: counts),
              ),
              AppSpacing.gapV20,
              _RecentBattlesBlock(async: battles),
              AppSpacing.gapV24,
              SizedBox(
                height: 54,
                child: FilledButton.icon(
                  onPressed: onLogout,
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.coral,
                    shape: RoundedRectangleBorder(
                      borderRadius: AppRadius.radiusLg,
                    ),
                  ),
                  icon: const Icon(Icons.logout_rounded,
                      color: AppColors.white),
                  label: Text(
                    'Шығу',
                    style: AppTypography.button.copyWith(
                      color: AppColors.white,
                    ),
                  ),
                ),
              ),
              AppSpacing.gapV24,
            ],
          ),
        ),
      ],
    );
  }
}

// =============================================================================
// Stats grid
// =============================================================================

class _StatsGrid extends StatelessWidget {
  final int akyl;
  final int coins;
  final int friendsCount;
  final int longestStreak;
  final int tasksCompleted;
  final int battlesWon;

  const _StatsGrid({
    required this.akyl,
    required this.coins,
    required this.friendsCount,
    required this.longestStreak,
    required this.tasksCompleted,
    required this.battlesWon,
  });

  @override
  Widget build(BuildContext context) {
    final tiles = <_StatTile>[
      _StatTile(
        icon: '★',
        title: 'Ақыл ұпайы',
        value: '$akyl',
        color: AppColors.eagleBlue,
      ),
      _StatTile(
        icon: '💰',
        title: 'Монета',
        value: '$coins',
        color: AppColors.steppeGoldDark,
      ),
      _StatTile(
        icon: '👥',
        title: 'Достар',
        value: '$friendsCount',
        color: AppColors.cosmicPurple,
      ),
      _StatTile(
        icon: '🔥',
        title: 'Ұзақ streak',
        value: '$longestStreak',
        color: AppColors.coral,
      ),
      _StatTile(
        icon: '✓',
        title: 'Орындалған',
        value: '$tasksCompleted',
        color: AppColors.jade,
      ),
      _StatTile(
        icon: '⚔️',
        title: 'Батл',
        value: '$battlesWon',
        color: AppColors.sunset,
      ),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: AppSpacing.sm,
        crossAxisSpacing: AppSpacing.sm,
        childAspectRatio: 1.8,
      ),
      itemCount: tiles.length,
      itemBuilder: (_, i) => tiles[i],
    );
  }
}

class _StatTile extends StatelessWidget {
  final String icon;
  final String title;
  final String value;
  final Color color;

  const _StatTile({
    required this.icon,
    required this.title,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.sm),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusLg,
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowSoft,
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(icon, style: const TextStyle(fontSize: 18)),
            ),
          ),
          AppSpacing.gapH8,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
                Text(
                  value,
                  style: AppTypography.h3.copyWith(color: color),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// Achievements
// =============================================================================

class _AchievementsBlock extends StatelessWidget {
  final Set<String> unlockedIds;

  const _AchievementsBlock({required this.unlockedIds});

  @override
  Widget build(BuildContext context) {
    final total = kAchievements.length;
    final unlocked = unlockedIds.length;
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusLg,
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('🏅', style: TextStyle(fontSize: 20)),
              AppSpacing.gapH8,
              Text('Жетістіктер', style: AppTypography.h3),
              const Spacer(),
              Text(
                '$unlocked / $total ашылды',
                style: AppTypography.caption.copyWith(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          AppSpacing.gapV12,
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: AppSpacing.xs,
              crossAxisSpacing: AppSpacing.xs,
              childAspectRatio: 0.95,
            ),
            itemCount: kAchievements.length,
            itemBuilder: (_, i) {
              final a = kAchievements[i];
              return _AchievementTile(
                template: a,
                unlocked: unlockedIds.contains(a.id),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _AchievementTile extends StatelessWidget {
  final AchievementTemplate template;
  final bool unlocked;

  const _AchievementTile({
    required this.template,
    required this.unlocked,
  });

  @override
  Widget build(BuildContext context) {
    final emoji = unlocked ? template.emoji : '?';
    final body = Container(
      padding: const EdgeInsets.all(AppSpacing.xs),
      decoration: BoxDecoration(
        color: unlocked
            ? AppColors.steppeGoldSurface
            : AppColors.surfaceMuted,
        borderRadius: AppRadius.radiusSm,
        border: Border.all(
          color: unlocked
              ? AppColors.steppeGold.withValues(alpha: 0.6)
              : AppColors.border,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 30)),
          const SizedBox(height: 4),
          Text(
            unlocked ? template.title : '???',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: AppTypography.caption.copyWith(
              color: unlocked
                  ? AppColors.steppeGoldDark
                  : AppColors.textTertiary,
              fontWeight: FontWeight.w800,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
    if (unlocked) return body;
    return ColorFiltered(
      colorFilter: const ColorFilter.matrix(<double>[
        0.33, 0.33, 0.33, 0, 0,
        0.33, 0.33, 0.33, 0, 0,
        0.33, 0.33, 0.33, 0, 0,
        0, 0, 0, 1, 0,
      ]),
      child: body,
    );
  }
}

// =============================================================================
// Recent battles
// =============================================================================

class _RecentBattlesBlock extends StatelessWidget {
  final AsyncValue<List<RecentBattleSummary>> async;

  const _RecentBattlesBlock({required this.async});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusLg,
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('⚔️', style: TextStyle(fontSize: 18)),
              AppSpacing.gapH8,
              Text('Соңғы шайқастар', style: AppTypography.h3),
            ],
          ),
          AppSpacing.gapV8,
          async.when(
            loading: () => const _LoadingBox(height: 200),
            error: (_, _) => _Empty(text: 'Дерек жүктелмеді'),
            data: (list) {
              if (list.isEmpty) {
                return _Empty(text: 'Шайқас әлі болған жоқ');
              }
              return Column(
                children: [for (final b in list) _RecentRow(b: b)],
              );
            },
          ),
        ],
      ),
    );
  }
}

class _RecentRow extends StatelessWidget {
  final RecentBattleSummary b;
  const _RecentRow({required this.b});

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('d MMM', 'kk');
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: b.won ? AppColors.jade : AppColors.coral,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                b.won ? 'W' : 'L',
                style: const TextStyle(
                  color: AppColors.white,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          AppSpacing.gapH12,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  b.opponentName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.body.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  df.format(b.endedAt),
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textTertiary,
                  ),
                ),
              ],
            ),
          ),
          Text(
            '${b.myScore} : ${b.opponentScore}',
            style: AppTypography.body.copyWith(
              fontWeight: FontWeight.w800,
              color: b.won ? AppColors.jadeDark : AppColors.coralDark,
            ),
          ),
        ],
      ),
    );
  }
}

class _LoadingBox extends StatelessWidget {
  final double height;
  const _LoadingBox({required this.height});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: AppColors.surfaceMuted,
        borderRadius: AppRadius.radiusLg,
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  final String text;
  const _Empty({required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.md),
      child: Center(
        child: Text(text, style: AppTypography.bodySecondary),
      ),
    );
  }
}
