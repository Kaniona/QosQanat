import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';

/// GitHub-style contribution heatmap: ~17 weeks (≈4 months) of weekday cells,
/// shaded light→deep Jade based on the activity count for that day.
class ActivityHeatmap extends StatelessWidget {
  final Map<DateTime, int> counts;
  final int weeksToShow;

  const ActivityHeatmap({
    super.key,
    required this.counts,
    this.weeksToShow = 17,
  });

  static const _weekdayLabels = ['Дс', 'Сс', 'Ср', 'Бс', 'Жм', 'Сб', 'Жс'];

  @override
  Widget build(BuildContext context) {
    final today = _utcDate(DateTime.now().toUtc());
    // Start so we have `weeksToShow` full weeks ending today. The first
    // displayed column is the Monday on or before (today - (weeksToShow-1)*7).
    final endMonday = _mondayOnOrBefore(today);
    final startMonday =
        endMonday.subtract(Duration(days: 7 * (weeksToShow - 1)));

    final maxCount =
        counts.values.fold<int>(0, (a, b) => b > a ? b : a);

    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusLg,
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('📅', style: TextStyle(fontSize: 18)),
              AppSpacing.gapH8,
              Text('Белсенділік', style: AppTypography.h3),
              const Spacer(),
              Text(
                '${counts.length} күн',
                style: AppTypography.caption.copyWith(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          AppSpacing.gapV12,
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            reverse: true,
            child: _Grid(
              startMonday: startMonday,
              today: today,
              counts: counts,
              maxCount: maxCount,
              weeks: weeksToShow,
            ),
          ),
          AppSpacing.gapV8,
          _Legend(),
        ],
      ),
    );
  }

  static DateTime _utcDate(DateTime d) =>
      DateTime.utc(d.year, d.month, d.day);

  static DateTime _mondayOnOrBefore(DateTime d) {
    final diff = (d.weekday - DateTime.monday) % 7;
    return d.subtract(Duration(days: diff));
  }
}

class _Grid extends StatelessWidget {
  final DateTime startMonday;
  final DateTime today;
  final Map<DateTime, int> counts;
  final int maxCount;
  final int weeks;

  const _Grid({
    required this.startMonday,
    required this.today,
    required this.counts,
    required this.maxCount,
    required this.weeks,
  });

  @override
  Widget build(BuildContext context) {
    const cell = 13.0;
    const gap = 3.0;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Weekday labels column (right-to-left in scroll for reading).
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            for (var i = 0; i < 7; i++)
              Container(
                height: cell,
                margin: const EdgeInsets.only(bottom: gap, right: 6),
                child: Text(
                  ActivityHeatmap._weekdayLabels[i],
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textTertiary,
                    fontSize: 9,
                  ),
                ),
              ),
          ],
        ),
        for (var w = 0; w < weeks; w++)
          Padding(
            padding: const EdgeInsets.only(right: gap),
            child: Column(
              children: [
                for (var d = 0; d < 7; d++)
                  Padding(
                    padding: const EdgeInsets.only(bottom: gap),
                    child: _Cell(
                      day: startMonday.add(Duration(days: w * 7 + d)),
                      today: today,
                      counts: counts,
                      maxCount: maxCount,
                      size: cell,
                    ),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}

class _Cell extends StatelessWidget {
  final DateTime day;
  final DateTime today;
  final Map<DateTime, int> counts;
  final int maxCount;
  final double size;

  const _Cell({
    required this.day,
    required this.today,
    required this.counts,
    required this.maxCount,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    final inFuture = day.isAfter(today);
    final count = counts[day] ?? 0;
    final color = inFuture
        ? Colors.transparent
        : _colorForCount(count, maxCount);
    final border = inFuture
        ? null
        : Border.all(
            color: AppColors.border.withValues(alpha: 0.5),
            width: 0.5,
          );

    return Tooltip(
      message: _tooltipFor(day, count),
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(3),
          border: border,
        ),
      ),
    );
  }

  String _tooltipFor(DateTime day, int count) =>
      '${day.day}/${day.month}: $count тапсырма';

  Color _colorForCount(int count, int max) {
    if (count == 0) return AppColors.surfaceMuted;
    if (max == 0) return AppColors.jadeLight;
    final t = (count / max).clamp(0.2, 1.0);
    if (t < 0.34) return AppColors.jade.withValues(alpha: 0.25);
    if (t < 0.67) return AppColors.jade.withValues(alpha: 0.55);
    return AppColors.jade;
  }
}

class _Legend extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Widget swatch(Color c) => Container(
          width: 12,
          height: 12,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            color: c,
            borderRadius: BorderRadius.circular(3),
          ),
        );

    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Text(
          'Аз',
          style: AppTypography.caption.copyWith(
            color: AppColors.textTertiary,
          ),
        ),
        const SizedBox(width: 4),
        swatch(AppColors.surfaceMuted),
        swatch(AppColors.jade.withValues(alpha: 0.25)),
        swatch(AppColors.jade.withValues(alpha: 0.55)),
        swatch(AppColors.jade),
        const SizedBox(width: 4),
        Text(
          'Көп',
          style: AppTypography.caption.copyWith(
            color: AppColors.textTertiary,
          ),
        ),
      ],
    );
  }
}
