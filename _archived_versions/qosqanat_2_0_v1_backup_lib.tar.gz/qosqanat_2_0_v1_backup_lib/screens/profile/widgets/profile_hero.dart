import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/enums.dart';
import '../../../models/user.dart';
import '../../../widgets/avatar/equipped_avatar.dart';

/// Hero block at the top of the profile screen — full-body assistant (with
/// equipped items), profile photo with edit overlay, settings gear, and the
/// QQ-ID + level/XP pill row.
class ProfileHero extends StatelessWidget {
  final AppUser user;
  final bool uploadingPhoto;
  final VoidCallback onEditPhoto;
  final VoidCallback onOpenSettings;
  final VoidCallback onCopyId;
  final double xpProgress; // 0..1
  final String xpLabel;

  const ProfileHero({
    super.key,
    required this.user,
    required this.onEditPhoto,
    required this.onOpenSettings,
    required this.onCopyId,
    required this.xpProgress,
    required this.xpLabel,
    this.uploadingPhoto = false,
  });

  LinearGradient get _gradient {
    // Each assistant gets a themed gradient.
    if (user.assistantType == AssistantType.nazym) {
      return const LinearGradient(
        colors: [AppColors.nazymRose, AppColors.cosmicPurple],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
    }
    return const LinearGradient(
      colors: [AppColors.eagleBlue, AppColors.cosmicPurple],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg, AppSpacing.md, AppSpacing.lg, AppSpacing.xl),
      decoration: BoxDecoration(
        gradient: _gradient,
        borderRadius: const BorderRadius.vertical(
          bottom: Radius.circular(AppRadius.xl),
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.cosmicPurple.withValues(alpha: 0.35),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Spacer(),
              _CircleButton(
                icon: Icons.settings_rounded,
                onTap: onOpenSettings,
              ),
            ],
          ),
          // Stage with assistant + profile photo badge.
          SizedBox(
            height: 220,
            child: Stack(
              alignment: Alignment.center,
              children: [
                EquippedAvatar(
                  assistantType: user.assistantType,
                  size: 200,
                ),
                Positioned(
                  bottom: 8,
                  right: 10,
                  child: _PhotoBadge(
                    url: user.profilePhotoUrl,
                    onTap: onEditPhoto,
                    uploading: uploadingPhoto,
                  ),
                ),
              ],
            ),
          ),
          AppSpacing.gapV8,
          Text(
            user.fullName.isEmpty ? 'Оқушы' : user.fullName,
            textAlign: TextAlign.center,
            style: AppTypography.displayLarge.copyWith(
              color: AppColors.white,
              fontSize: 28,
            ),
          ),
          AppSpacing.gapV8,
          _QosqanatPill(qqId: user.qosqanatId, onCopy: onCopyId),
          AppSpacing.gapV12,
          _LevelXpBar(
            level: user.level,
            progress: xpProgress,
            label: xpLabel,
          ),
        ],
      ),
    );
  }
}

class _CircleButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _CircleButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.white.withValues(alpha: 0.18),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(icon, color: AppColors.white, size: 22),
        ),
      ),
    );
  }
}

class _PhotoBadge extends StatelessWidget {
  final String? url;
  final bool uploading;
  final VoidCallback onTap;

  const _PhotoBadge({
    required this.url,
    required this.uploading,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          width: 84,
          height: 84,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.surface,
            border: Border.all(color: AppColors.white, width: 4),
            boxShadow: const [
              BoxShadow(
                color: AppColors.shadowMedium,
                blurRadius: 12,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: ClipOval(
            child: _PhotoOrPlaceholder(url: url),
          ),
        ),
        if (uploading)
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.nightInk.withValues(alpha: 0.55),
              ),
              child: const Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    color: AppColors.white,
                    strokeWidth: 2.6,
                  ),
                ),
              ),
            ),
          ),
        Positioned(
          right: 0,
          bottom: 0,
          child: GestureDetector(
            onTap: uploading ? null : onTap,
            child: Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: AppColors.steppeGold,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.white, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: AppColors.shadowSoft,
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: const Icon(
                Icons.photo_camera_rounded,
                color: AppColors.white,
                size: 14,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _PhotoOrPlaceholder extends StatelessWidget {
  final String? url;
  const _PhotoOrPlaceholder({required this.url});

  @override
  Widget build(BuildContext context) {
    final value = url;
    if (value == null || value.isEmpty) {
      return _placeholder();
    }
    // Offline mode stores a local file path; the live backend stores an http
    // URL. Render whichever applies.
    final isRemote = value.startsWith('http');
    if (isRemote) {
      return Image.network(
        value,
        fit: BoxFit.cover,
        errorBuilder: (_, _, _) => _placeholder(),
      );
    }
    return Image.file(
      File(value),
      fit: BoxFit.cover,
      errorBuilder: (_, _, _) => _placeholder(),
    );
  }

  Widget _placeholder() {
    return Container(
      color: AppColors.surfaceMuted,
      alignment: Alignment.center,
      child: const Icon(Icons.person_rounded,
          size: 40, color: AppColors.textTertiary),
    );
  }
}

class _QosqanatPill extends StatelessWidget {
  final String qqId;
  final VoidCallback onCopy;

  const _QosqanatPill({required this.qqId, required this.onCopy});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onCopy,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: AppColors.white.withValues(alpha: 0.18),
          borderRadius: BorderRadius.circular(999),
          border:
              Border.all(color: AppColors.white.withValues(alpha: 0.3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              qqId.isEmpty ? 'QQ-?????????' : qqId,
              style: AppTypography.body.copyWith(
                color: AppColors.white,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(width: 6),
            const Icon(Icons.copy_rounded,
                color: AppColors.white, size: 14),
          ],
        ),
      )
          .animate(onPlay: (c) => c.repeat(reverse: true))
          .fadeIn(begin: 0.86, duration: 1300.ms),
    );
  }
}

class _LevelXpBar extends StatelessWidget {
  final int level;
  final double progress;
  final String label;

  const _LevelXpBar({
    required this.level,
    required this.progress,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            gradient: AppColors.goldSoar,
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            'LVL $level',
            style: AppTypography.caption.copyWith(
              color: AppColors.white,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        AppSpacing.gapH8,
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: SizedBox(
              height: 10,
              child: Stack(
                children: [
                  Container(
                    color: AppColors.white.withValues(alpha: 0.22),
                  ),
                  FractionallySizedBox(
                    widthFactor: progress.clamp(0.0, 1.0),
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [
                            AppColors.steppeGoldLight,
                            AppColors.steppeGold,
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        AppSpacing.gapH8,
        Text(
          label,
          style: AppTypography.caption.copyWith(
            color: AppColors.white.withValues(alpha: 0.92),
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}
