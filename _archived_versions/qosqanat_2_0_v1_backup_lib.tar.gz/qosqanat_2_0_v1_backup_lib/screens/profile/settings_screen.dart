import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_config.dart';
import '../../core/constants/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../navigation/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../providers/settings_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  Future<void> _logout(BuildContext context, WidgetRef ref) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.radiusLg),
        title: const Text('Шығу'),
        content: const Text('Аккаунттан шығасыз ба?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Болдырмау'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.coral),
            child: const Text('Шығу'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    if (!context.mounted) return;
    await ref.read(authControllerProvider.notifier).signOut();
    if (context.mounted) context.go(AppRoutes.welcome);
  }

  Future<void> _pickReminderTime(BuildContext context, WidgetRef ref) async {
    final s = ref.read(settingsProvider);
    final picked = await showTimePicker(
      context: context,
      initialTime:
          TimeOfDay(hour: s.streakReminderHour, minute: s.streakReminderMinute),
    );
    if (picked == null) return;
    ref.read(settingsProvider.notifier).setStreakReminderTime(
          hour: picked.hour,
          minute: picked.minute,
        );
  }

  void _aboutDialog(BuildContext context) {
    showAboutDialog(
      context: context,
      applicationName: AppStrings.appName,
      applicationVersion: AppConfig.appVersion,
      applicationLegalese: 'Қыран қанат — оқу әлемі',
      children: const [
        Padding(
          padding: EdgeInsets.only(top: 16),
          child: Text(
            'QosQanat — қазақ мектеп оқушыларына арналған геймификацияланған '
            'білім беру қосымшасы.',
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final user = ref.watch(currentUserProvider).asData?.value;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.pop(),
        ),
        title: Text('Баптаулар', style: AppTypography.h3),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.md, vertical: AppSpacing.sm),
        children: [
          _SectionTitle(text: 'ЖАЛПЫ'),
          _LanguageRow(
            current: settings.language,
            onChange: (v) =>
                ref.read(settingsProvider.notifier).setLanguage(v),
          ),
          _ToggleRow(
            icon: Icons.volume_up_rounded,
            title: 'Дыбыс',
            value: settings.soundEnabled,
            onChanged: (v) =>
                ref.read(settingsProvider.notifier).setSound(v),
          ),
          _ToggleRow(
            icon: Icons.vibration_rounded,
            title: 'Дірілдеу',
            value: settings.vibrationEnabled,
            onChanged: (v) =>
                ref.read(settingsProvider.notifier).setVibration(v),
          ),
          _ToggleRow(
            icon: Icons.animation_rounded,
            title: 'Анимациялар',
            value: settings.animationsEnabled,
            onChanged: (v) =>
                ref.read(settingsProvider.notifier).setAnimations(v),
          ),
          AppSpacing.gapV16,
          _SectionTitle(text: 'ХАБАРЛАМАЛАР'),
          _ToggleRow(
            icon: Icons.notifications_rounded,
            title: 'Push хабарламалар',
            value: settings.notificationsEnabled,
            onChanged: (v) =>
                ref.read(settingsProvider.notifier).setNotifications(v),
          ),
          _ToggleRow(
            icon: Icons.local_fire_department_rounded,
            title: 'Streak еске салу',
            value: settings.streakReminderEnabled,
            onChanged: (v) => ref
                .read(settingsProvider.notifier)
                .setStreakReminderEnabled(v),
          ),
          if (settings.streakReminderEnabled)
            _ActionRow(
              icon: Icons.alarm_rounded,
              title: 'Еске салу уақыты',
              valueLabel:
                  _formatTime(settings.streakReminderHour, settings.streakReminderMinute),
              onTap: () => _pickReminderTime(context, ref),
            ),
          AppSpacing.gapV16,
          _SectionTitle(text: 'АККАУНТ'),
          _ActionRow(
            icon: Icons.person_rounded,
            title: 'Профильді өзгерту',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: const Text('Жақын арада қосылады'),
                behavior: SnackBarBehavior.floating,
              ));
            },
          ),
          _ActionRow(
            icon: Icons.face_rounded,
            title: 'Серікті ауыстыру',
            valueLabel: '30 күнде бір рет',
            onTap: () {
              showDialog<void>(
                context: context,
                builder: (_) => AlertDialog(
                  backgroundColor: AppColors.surface,
                  shape: RoundedRectangleBorder(
                    borderRadius: AppRadius.radiusLg,
                  ),
                  title: const Text('Серікті ауыстыру'),
                  content: const Text(
                    'Серіктесіңді ауыстыру әр 30 күнде рұқсат етіледі. '
                    'Жалғастырғың келе ме?',
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Жабу'),
                    ),
                    FilledButton(
                      onPressed: () {
                        Navigator.pop(context);
                        context.push(AppRoutes.assistantSelection);
                      },
                      style: FilledButton.styleFrom(
                        backgroundColor: AppColors.eagleBlue,
                      ),
                      child: const Text('Жалғастыру'),
                    ),
                  ],
                ),
              );
            },
          ),
          _ActionRow(
            icon: Icons.badge_rounded,
            title: 'QQ-ID',
            valueLabel: user?.qosqanatId ?? '—',
          ),
          AppSpacing.gapV16,
          _SectionTitle(text: 'ТУРАЛЫ'),
          _ActionRow(
            icon: Icons.info_outline_rounded,
            title: 'Нұсқа',
            valueLabel: AppConfig.appVersion,
          ),
          _ActionRow(
            icon: Icons.gavel_rounded,
            title: 'Ережелер',
            onTap: () => _aboutDialog(context),
          ),
          _ActionRow(
            icon: Icons.shield_rounded,
            title: 'Құпиялылық',
            onTap: () => _aboutDialog(context),
          ),
          _ActionRow(
            icon: Icons.support_agent_rounded,
            title: 'Қолдау',
            onTap: () => _aboutDialog(context),
          ),
          AppSpacing.gapV24,
          SizedBox(
            height: 54,
            child: FilledButton.icon(
              onPressed: () => _logout(context, ref),
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.coral,
                shape: RoundedRectangleBorder(
                  borderRadius: AppRadius.radiusLg,
                ),
              ),
              icon: const Icon(Icons.logout_rounded, color: AppColors.white),
              label: Text(
                'Шығу',
                style: AppTypography.button.copyWith(color: AppColors.white),
              ),
            ),
          ),
          AppSpacing.gapV24,
        ],
      ),
    );
  }

  static String _formatTime(int h, int m) =>
      '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}';
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle({required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
          AppSpacing.xs, AppSpacing.md, 0, AppSpacing.xs),
      child: Text(
        text,
        style: AppTypography.caption.copyWith(
          color: AppColors.textSecondary,
          letterSpacing: 1.2,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _ToggleRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _ToggleRow({
    required this.icon,
    required this.title,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 1),
      padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusMd,
        border: Border.all(color: AppColors.border),
      ),
      child: SwitchListTile(
        contentPadding: EdgeInsets.zero,
        secondary: Icon(icon, color: AppColors.eagleBlue),
        title: Text(title, style: AppTypography.body),
        value: value,
        activeThumbColor: AppColors.jade,
        onChanged: onChanged,
      ),
    );
  }
}

class _ActionRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? valueLabel;
  final VoidCallback? onTap;

  const _ActionRow({
    required this.icon,
    required this.title,
    this.valueLabel,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 1),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusMd,
        border: Border.all(color: AppColors.border),
      ),
      child: ListTile(
        shape: RoundedRectangleBorder(borderRadius: AppRadius.radiusMd),
        leading: Icon(icon, color: AppColors.eagleBlue),
        title: Text(title, style: AppTypography.body),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (valueLabel != null)
              Text(
                valueLabel!,
                style: AppTypography.body.copyWith(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w700,
                ),
              ),
            if (onTap != null) ...[
              const SizedBox(width: 4),
              const Icon(Icons.chevron_right_rounded,
                  color: AppColors.textTertiary),
            ],
          ],
        ),
        onTap: onTap,
      ),
    );
  }
}

class _LanguageRow extends StatelessWidget {
  final AppLanguage current;
  final ValueChanged<AppLanguage> onChange;

  const _LanguageRow({required this.current, required this.onChange});

  @override
  Widget build(BuildContext context) {
    Widget pill(AppLanguage value, String label) {
      final on = value == current;
      return Expanded(
        child: Material(
          color: on ? AppColors.eagleBlue : AppColors.surface,
          borderRadius: BorderRadius.circular(999),
          child: InkWell(
            borderRadius: BorderRadius.circular(999),
            onTap: () => onChange(value),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 9),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(999),
                border: Border.all(
                  color: on ? AppColors.eagleBlue : AppColors.border,
                ),
              ),
              child: Center(
                child: Text(
                  label,
                  style: AppTypography.body.copyWith(
                    color: on ? AppColors.white : AppColors.textPrimary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 1),
      padding: const EdgeInsets.all(AppSpacing.sm),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusMd,
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          const Icon(Icons.language_rounded, color: AppColors.eagleBlue),
          AppSpacing.gapH8,
          Text('Тіл', style: AppTypography.body),
          AppSpacing.gapH16,
          pill(AppLanguage.kk, 'ҚАЗ'),
          const SizedBox(width: 6),
          pill(AppLanguage.ru, 'РУС'),
        ],
      ),
    );
  }
}
