import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_strings.dart';
import '../../core/constants/auth_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../navigation/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/ui/eagle_emblem.dart';
import '../../widgets/ui/starry_background.dart';

/// Splash screen: shows the brand for 2.5s, then routes to Home (if a session
/// exists) or Welcome.
class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    await Future<void>.delayed(const Duration(milliseconds: 2500));
    if (!mounted) return;

    final loggedIn = ref.read(authServiceProvider).isAuthenticated;
    context.go(loggedIn ? AppRoutes.home : AppRoutes.welcome);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StarryBackground(
        child: SafeArea(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const EagleEmblem(size: 120, onDark: true)
                    .animate()
                    .scale(duration: 600.ms, curve: Curves.easeOutBack)
                    .fadeIn(duration: 600.ms),
                AppSpacing.gapV24,
                Text(
                  AppStrings.appName,
                  style: AppTypography.displayHuge
                      .copyWith(color: AppColors.textOnDark),
                ).animate().fadeIn(delay: 300.ms, duration: 600.ms),
                AppSpacing.gapV8,
                Text(
                  AuthStrings.splashTagline,
                  style: AppTypography.bodyLarge.copyWith(
                    color: AppColors.textOnDark.withValues(alpha: 0.85),
                  ),
                ).animate().fadeIn(delay: 600.ms, duration: 600.ms),
                AppSpacing.gapV32,
                const SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    valueColor: AlwaysStoppedAnimation(AppColors.steppeGold),
                  ),
                ).animate().fadeIn(delay: 900.ms),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
