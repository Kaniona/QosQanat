import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_strings.dart';
import '../../core/constants/auth_strings.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../navigation/app_routes.dart';
import '../../widgets/avatar/avatar_display.dart';
import '../../widgets/ui/eagle_emblem.dart';
import '../../widgets/ui/language_toggle.dart';
import '../../widgets/ui/primary_button.dart';

/// Welcome screen: brand emblem, the two companions, and the entry CTAs.
class WelcomeScreen extends ConsumerStatefulWidget {
  const WelcomeScreen({super.key});

  @override
  ConsumerState<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends ConsumerState<WelcomeScreen> {
  bool _isKazakh = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: AppSpacing.screenPadding,
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: const EdgeInsets.only(top: AppSpacing.sm),
                  child: LanguageToggle(
                    isKazakh: _isKazakh,
                    onChanged: (v) => setState(() => _isKazakh = v),
                  ),
                ),
              ),
              const Spacer(),
              const EagleEmblem(size: 96)
                  .animate()
                  .scale(duration: 500.ms, curve: Curves.easeOutBack),
              AppSpacing.gapV24,
              // The two companions side by side.
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const AvatarDisplay(
                    assistantType: AssistantType.bektur,
                    size: 96,
                  ).animate().fadeIn(delay: 200.ms).slideX(begin: -0.3),
                  AppSpacing.gapH16,
                  const AvatarDisplay(
                    assistantType: AssistantType.nazym,
                    size: 96,
                  ).animate().fadeIn(delay: 350.ms).slideX(begin: 0.3),
                ],
              ),
              AppSpacing.gapV32,
              Text(
                AuthStrings.welcomeTitle,
                textAlign: TextAlign.center,
                style: AppTypography.h1,
              ),
              AppSpacing.gapV12,
              Text(
                AuthStrings.welcomeSubtitle,
                textAlign: TextAlign.center,
                style: AppTypography.bodySecondary,
              ),
              const Spacer(),
              PrimaryButton(
                label: AppStrings.register,
                icon: Icons.rocket_launch_rounded,
                onPressed: () => context.push(AppRoutes.register),
              ),
              AppSpacing.gapV12,
              SecondaryButton(
                label: AppStrings.login,
                onPressed: () => context.push(AppRoutes.login),
              ),
              AppSpacing.gapV24,
            ],
          ),
        ),
      ),
    );
  }
}
