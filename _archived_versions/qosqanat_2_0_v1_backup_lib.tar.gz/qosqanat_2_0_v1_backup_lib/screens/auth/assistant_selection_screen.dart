import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_config.dart';
import '../../core/constants/auth_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../navigation/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/avatar/avatar_selector.dart';
import '../../widgets/ui/primary_button.dart';
import '../../widgets/ui/starry_background.dart';

class AssistantSelectionScreen extends ConsumerStatefulWidget {
  const AssistantSelectionScreen({super.key});

  @override
  ConsumerState<AssistantSelectionScreen> createState() =>
      _AssistantSelectionScreenState();
}

class _AssistantSelectionScreenState
    extends ConsumerState<AssistantSelectionScreen> {
  AssistantType? _selected;

  Future<void> _confirm() async {
    if (_selected == null) return;
    final ok = await ref.read(authControllerProvider.notifier).chooseAssistant(
          assistant: _selected!,
          giftCoins: AppConfig.welcomeGiftCoins,
        );
    if (!mounted) return;
    if (ok) {
      await _showGiftModal();
      if (mounted) context.go(AppRoutes.home);
    }
  }

  Future<void> _showGiftModal() {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      barrierColor: AppColors.nightInk.withValues(alpha: 0.7),
      builder: (context) => const _WelcomeGiftDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final action = ref.watch(authControllerProvider);

    return Scaffold(
      body: StarryBackground(
        child: SafeArea(
          child: Padding(
            padding: AppSpacing.screenPadding,
            child: Column(
              children: [
                AppSpacing.gapV24,
                Text(
                  AuthStrings.assistantTitle,
                  textAlign: TextAlign.center,
                  style: AppTypography.h1.copyWith(color: AppColors.textOnDark),
                ),
                AppSpacing.gapV12,
                Text(
                  AuthStrings.assistantSubtitle,
                  textAlign: TextAlign.center,
                  style: AppTypography.body.copyWith(
                    color: AppColors.textOnDark.withValues(alpha: 0.8),
                  ),
                ),
                AppSpacing.gapV32,
                Expanded(
                  child: Center(
                    child: SingleChildScrollView(
                      child: AvatarSelector(
                        selected: _selected,
                        onSelect: (type) => setState(() => _selected = type),
                      ),
                    ),
                  ),
                ),
                AppSpacing.gapV24,
                PrimaryButton(
                  label: AuthStrings.assistantConfirm,
                  gradient: AppColors.goldSoar,
                  isLoading: action.isLoading,
                  onPressed: _selected != null ? _confirm : null,
                ),
                AppSpacing.gapV24,
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Welcome gift modal: "Саған 100 монета сыйладым!" with a coin flourish.
class _WelcomeGiftDialog extends StatelessWidget {
  const _WelcomeGiftDialog();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: AppRadius.radiusXl),
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 88,
              height: 88,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                gradient: AppColors.goldSoar,
                shape: BoxShape.circle,
              ),
              child: const Text('💰', style: TextStyle(fontSize: 44)),
            )
                .animate()
                .scale(duration: 500.ms, curve: Curves.easeOutBack)
                .then()
                .shake(hz: 3, rotation: 0.05),
            AppSpacing.gapV20,
            Text(
              AuthStrings.giftTitle,
              textAlign: TextAlign.center,
              style: AppTypography.h2,
            ),
            AppSpacing.gapV8,
            Text(
              AuthStrings.giftBody,
              textAlign: TextAlign.center,
              style: AppTypography.bodySecondary,
            ),
            AppSpacing.gapV12,
            Text(
              '+${AppConfig.welcomeGiftCoins}',
              style: AppTypography.numberDisplay
                  .copyWith(color: AppColors.steppeGold),
            ).animate().fadeIn(delay: 300.ms).slideY(begin: 0.3),
            AppSpacing.gapV24,
            PrimaryButton(
              label: AuthStrings.giftButton,
              gradient: AppColors.goldSoar,
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        ),
      ),
    );
  }
}
