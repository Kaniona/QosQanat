import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_strings.dart';
import '../../core/constants/auth_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../navigation/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../providers/registration_provider.dart';
import '../../widgets/ui/primary_button.dart';
import '../../widgets/ui/step_dots.dart';
import 'register_steps/register_step_about.dart';
import 'register_steps/register_step_password.dart';
import 'register_steps/register_step_school.dart';
import 'register_steps/register_step_summary.dart';

/// 4-step registration wizard with a step-dot indicator and per-step gating.
class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  static const _stepCount = 4;
  final _pageController = PageController();
  final _step1FormKey = GlobalKey<FormState>();
  int _index = 0;

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _goTo(int index) {
    setState(() => _index = index);
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  void _onBack() {
    ref.read(authControllerProvider.notifier).clearError();
    if (_index == 0) {
      context.pop();
    } else {
      _goTo(_index - 1);
    }
  }

  Future<void> _onNext() async {
    FocusScope.of(context).unfocus();
    final data = ref.read(registrationProvider);

    switch (_index) {
      case 0:
        if (!(_step1FormKey.currentState?.validate() ?? false)) return;
        _goTo(1);
      case 1:
        if (data.isStep2Valid) _goTo(2);
      case 2:
        if (data.isStep3Valid) _goTo(3);
      case 3:
        await _submit();
    }
  }

  Future<void> _submit() async {
    final data = ref.read(registrationProvider);
    final ok = await ref.read(authControllerProvider.notifier).register(
          phoneE164: data.phoneE164,
          password: data.password,
          fullName: data.fullName.trim(),
          iin: data.iin.trim(),
          city: data.city!,
          school: data.school.trim(),
          grade: data.grade!,
        );

    if (!mounted) return;
    if (ok) {
      ref.read(registrationProvider.notifier).reset();
      context.go(AppRoutes.assistantSelection);
    }
  }

  /// Whether the current step's Next/Register button is enabled.
  bool _canAdvance(RegistrationData data) {
    switch (_index) {
      case 0:
        return true; // validated via Form on press
      case 1:
        return data.isStep2Valid;
      case 2:
        return data.isStep3Valid;
      case 3:
        return data.isStep4Valid;
      default:
        return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = ref.watch(registrationProvider);
    final action = ref.watch(authControllerProvider);
    final isLast = _index == _stepCount - 1;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: _onBack,
        ),
        title: StepDots(count: _stepCount, activeIndex: _index),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _StepScroll(child: RegisterStepAbout(formKey: _step1FormKey)),
                  const _StepScroll(child: RegisterStepPassword()),
                  const _StepScroll(child: RegisterStepSchool()),
                  const _StepScroll(child: RegisterStepSummary()),
                ],
              ),
            ),
            if (action.error != null)
              Padding(
                padding: AppSpacing.screenPadding,
                child: Text(
                  action.error!,
                  textAlign: TextAlign.center,
                  style: AppTypography.caption.copyWith(color: AppColors.coral),
                ),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.lg,
                AppSpacing.md,
                AppSpacing.lg,
                AppSpacing.xl,
              ),
              child: PrimaryButton(
                label: isLast ? AuthStrings.registerButton : AppStrings.next,
                icon: isLast ? Icons.check_rounded : null,
                isLoading: action.isLoading,
                onPressed: _canAdvance(data) ? _onNext : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Scrollable padded wrapper for a wizard step.
class _StepScroll extends StatelessWidget {
  final Widget child;

  const _StepScroll({required this.child});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.lg,
        AppSpacing.lg,
        AppSpacing.lg,
        AppSpacing.xxl,
      ),
      child: child,
    );
  }
}
