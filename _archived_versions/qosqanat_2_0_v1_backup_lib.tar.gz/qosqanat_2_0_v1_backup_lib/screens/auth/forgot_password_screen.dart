import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/auth_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../core/utils/password_strength.dart';
import '../../core/utils/phone_formatter.dart';
import '../../core/utils/validators.dart';
import '../../navigation/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/ui/app_text_field.dart';
import '../../widgets/ui/password_field.dart';
import '../../widgets/ui/password_strength_meter.dart';
import '../../widgets/ui/primary_button.dart';

/// Password recovery: phone → OTP → new password → success.
class ForgotPasswordScreen extends ConsumerStatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  ConsumerState<ForgotPasswordScreen> createState() =>
      _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends ConsumerState<ForgotPasswordScreen> {
  final _pageController = PageController();
  final _phoneController = TextEditingController();
  final _otpController = TextEditingController();
  final _passwordController = TextEditingController();

  final _phoneFormKey = GlobalKey<FormState>();
  final _otpFormKey = GlobalKey<FormState>();

  int _stage = 0;
  String _password = '';

  @override
  void dispose() {
    _pageController.dispose();
    _phoneController.dispose();
    _otpController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  String get _phoneE164 => KzPhoneInputFormatter.toE164(_phoneController.text);

  void _goTo(int stage) {
    setState(() => _stage = stage);
    _pageController.animateToPage(
      stage,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  void _onBack() {
    ref.read(authControllerProvider.notifier).clearError();
    if (_stage == 0 || _stage == 3) {
      context.pop();
    } else {
      _goTo(_stage - 1);
    }
  }

  Future<void> _sendCode() async {
    FocusScope.of(context).unfocus();
    if (!(_phoneFormKey.currentState?.validate() ?? false)) return;
    final ok =
        await ref.read(authControllerProvider.notifier).sendRecoveryCode(_phoneE164);
    if (ok && mounted) _goTo(1);
  }

  Future<void> _verifyCode() async {
    FocusScope.of(context).unfocus();
    if (!(_otpFormKey.currentState?.validate() ?? false)) return;
    final ok = await ref.read(authControllerProvider.notifier).verifyRecoveryCode(
          phoneE164: _phoneE164,
          token: _otpController.text.trim(),
        );
    if (ok && mounted) _goTo(2);
  }

  Future<void> _savePassword() async {
    FocusScope.of(context).unfocus();
    final report = PasswordReport.evaluate(_password);
    if (!report.isValid) return;
    final ok = await ref
        .read(authControllerProvider.notifier)
        .updatePassword(_password);
    if (ok && mounted) _goTo(3);
  }

  @override
  Widget build(BuildContext context) {
    final action = ref.watch(authControllerProvider);

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: _onBack,
        ),
      ),
      body: SafeArea(
        child: PageView(
          controller: _pageController,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            _phoneStage(action),
            _otpStage(action),
            _newPasswordStage(action),
            _successStage(),
          ],
        ),
      ),
    );
  }

  // --- Stage 1: phone ---------------------------------------------------------
  Widget _phoneStage(AuthActionState action) {
    return _StageScaffold(
      icon: Icons.lock_reset_rounded,
      title: AuthStrings.forgotTitle,
      subtitle: AuthStrings.forgotPhonePrompt,
      body: Form(
        key: _phoneFormKey,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        child: AppTextField(
          label: AuthStrings.phoneLabel,
          hint: AuthStrings.phoneHint,
          controller: _phoneController,
          keyboardType: TextInputType.phone,
          prefixIcon: Icons.phone_outlined,
          inputFormatters: [KzPhoneInputFormatter()],
          validator: Validators.phone,
        ),
      ),
      button: PrimaryButton(
        label: AuthStrings.sendCode,
        isLoading: action.isLoading,
        onPressed: _sendCode,
      ),
      error: action.error,
    );
  }

  // --- Stage 2: OTP -----------------------------------------------------------
  Widget _otpStage(AuthActionState action) {
    return _StageScaffold(
      icon: Icons.sms_outlined,
      title: AuthStrings.otpTitle,
      subtitle: AuthStrings.otpPrompt,
      body: Column(
        children: [
          Form(
            key: _otpFormKey,
            autovalidateMode: AutovalidateMode.onUserInteraction,
            child: AppTextField(
              label: AuthStrings.otpTitle,
              hint: '____',
              controller: _otpController,
              keyboardType: TextInputType.number,
              maxLength: 4,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              prefixIcon: Icons.pin_outlined,
              validator: Validators.otp,
            ),
          ),
          AppSpacing.gapV12,
          TextButton(
            onPressed: action.isLoading ? null : _sendCode,
            child: const Text(AuthStrings.resendCode),
          ),
        ],
      ),
      button: PrimaryButton(
        label: AuthStrings.verifyCode,
        isLoading: action.isLoading,
        onPressed: _verifyCode,
      ),
      error: action.error,
    );
  }

  // --- Stage 3: new password --------------------------------------------------
  Widget _newPasswordStage(AuthActionState action) {
    final report = PasswordReport.evaluate(_password);
    return _StageScaffold(
      icon: Icons.password_rounded,
      title: AuthStrings.newPasswordTitle,
      subtitle: AuthStrings.newPasswordPrompt,
      body: Column(
        children: [
          PasswordField(
            label: AuthStrings.passwordLabel,
            hint: AuthStrings.passwordHint,
            controller: _passwordController,
            onChanged: (v) => setState(() => _password = v),
          ),
          AppSpacing.gapV16,
          PasswordStrengthMeter(report: report),
        ],
      ),
      button: PrimaryButton(
        label: AuthStrings.savePassword,
        isLoading: action.isLoading,
        onPressed: report.isValid ? _savePassword : null,
      ),
      error: action.error,
    );
  }

  // --- Stage 4: success -------------------------------------------------------
  Widget _successStage() {
    return _StageScaffold(
      icon: Icons.check_circle_rounded,
      iconColor: AppColors.jade,
      title: AuthStrings.resetSuccessTitle,
      subtitle: AuthStrings.resetSuccessBody,
      body: const SizedBox.shrink(),
      button: PrimaryButton(
        label: AuthStrings.backToLogin,
        onPressed: () => context.go(AppRoutes.login),
      ),
    );
  }
}

/// Shared layout for a recovery stage: icon, title, subtitle, body, button.
class _StageScaffold extends StatelessWidget {
  final IconData icon;
  final Color? iconColor;
  final String title;
  final String subtitle;
  final Widget body;
  final Widget button;
  final String? error;

  const _StageScaffold({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.body,
    required this.button,
    this.iconColor,
    this.error,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: AppSpacing.screenPadding,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          AppSpacing.gapV24,
          Container(
            width: 72,
            height: 72,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: (iconColor ?? AppColors.eagleBlue).withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, size: 36, color: iconColor ?? AppColors.eagleBlue),
          ),
          AppSpacing.gapV24,
          Text(title, textAlign: TextAlign.center, style: AppTypography.h1),
          AppSpacing.gapV12,
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: AppTypography.bodySecondary,
          ),
          AppSpacing.gapV32,
          body,
          if (error != null) ...[
            AppSpacing.gapV16,
            Text(
              error!,
              textAlign: TextAlign.center,
              style: AppTypography.caption.copyWith(color: AppColors.coral),
            ),
          ],
          const Spacer(),
          button,
          AppSpacing.gapV24,
        ],
      ),
    );
  }
}
