import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/auth_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../providers/registration_provider.dart';
import '../../../widgets/ui/password_field.dart';
import '../../../widgets/ui/password_strength_meter.dart';

/// Step 2 — "Құпиясөз жаса": password + live strength meter + confirm match.
class RegisterStepPassword extends ConsumerStatefulWidget {
  const RegisterStepPassword({super.key});

  @override
  ConsumerState<RegisterStepPassword> createState() =>
      _RegisterStepPasswordState();
}

class _RegisterStepPasswordState extends ConsumerState<RegisterStepPassword> {
  late final TextEditingController _password;
  late final TextEditingController _confirm;

  @override
  void initState() {
    super.initState();
    final data = ref.read(registrationProvider);
    _password = TextEditingController(text: data.password);
    _confirm = TextEditingController(text: data.confirmPassword);
  }

  @override
  void dispose() {
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = ref.read(registrationProvider.notifier);
    final data = ref.watch(registrationProvider);
    final hasConfirm = data.confirmPassword.isNotEmpty;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(AuthStrings.step2Title, style: AppTypography.h2),
        AppSpacing.gapV24,
        PasswordField(
          label: AuthStrings.passwordLabel,
          hint: AuthStrings.passwordHint,
          controller: _password,
          onChanged: controller.setPassword,
          textInputAction: TextInputAction.next,
        ),
        AppSpacing.gapV16,
        PasswordStrengthMeter(report: data.passwordReport),
        AppSpacing.gapV24,
        PasswordField(
          label: AuthStrings.confirmPasswordLabel,
          hint: AuthStrings.confirmPasswordHint,
          controller: _confirm,
          onChanged: controller.setConfirmPassword,
          textInputAction: TextInputAction.done,
        ),
        if (hasConfirm) ...[
          AppSpacing.gapV12,
          _MatchIndicator(matches: data.passwordsMatch),
        ],
      ],
    );
  }
}

class _MatchIndicator extends StatelessWidget {
  final bool matches;

  const _MatchIndicator({required this.matches});

  @override
  Widget build(BuildContext context) {
    final color = matches ? AppColors.jade : AppColors.coral;
    return Row(
      children: [
        Icon(
          matches ? Icons.check_circle_rounded : Icons.cancel_rounded,
          size: 18,
          color: color,
        ),
        AppSpacing.gapH8,
        Text(
          matches
              ? AuthStrings.passwordsMatch
              : AuthStrings.passwordsNoMatch,
          style: AppTypography.caption.copyWith(color: color),
        ),
      ],
    );
  }
}
