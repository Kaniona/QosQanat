import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_strings.dart';
import '../../../core/constants/auth_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../providers/registration_provider.dart';

/// Step 4 — "Барлығы дұрыс па?": summary card + agreement checkboxes.
class RegisterStepSummary extends ConsumerWidget {
  const RegisterStepSummary({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final data = ref.watch(registrationProvider);
    final controller = ref.read(registrationProvider.notifier);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(AuthStrings.step4Title, style: AppTypography.h2),
        AppSpacing.gapV8,
        Text(AuthStrings.summarySubtitle, style: AppTypography.bodySecondary),
        AppSpacing.gapV24,
        Container(
          padding: const EdgeInsets.all(AppSpacing.lg),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: AppRadius.radiusLg,
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: [
              _SummaryRow(
                icon: Icons.person_outline_rounded,
                label: AppStrings.fullName,
                value: data.fullName,
              ),
              _SummaryRow(
                icon: Icons.phone_outlined,
                label: AppStrings.phone,
                value: _maskPhone(data.phone),
              ),
              _SummaryRow(
                icon: Icons.badge_outlined,
                label: AppStrings.iin,
                value: _maskIin(data.iin),
              ),
              _SummaryRow(
                icon: Icons.location_city_outlined,
                label: AppStrings.city,
                value: data.city ?? '—',
              ),
              _SummaryRow(
                icon: Icons.school_outlined,
                label: AppStrings.school,
                value: data.school,
              ),
              _SummaryRow(
                icon: Icons.workspace_premium_outlined,
                label: AppStrings.grade,
                value: data.grade != null ? '${data.grade}-сынып' : '—',
              ),
              _SummaryRow(
                icon: Icons.lock_outline_rounded,
                label: AuthStrings.passwordLabel,
                value: '•' * data.password.length,
                isLast: true,
              ),
            ],
          ),
        ),
        AppSpacing.gapV24,
        _AgreementCheckbox(
          value: data.agreedTerms,
          label: AuthStrings.agreementTerms,
          onChanged: controller.setAgreedTerms,
        ),
        AppSpacing.gapV12,
        _AgreementCheckbox(
          value: data.agreedPrivacy,
          label: AuthStrings.agreementPrivacy,
          onChanged: controller.setAgreedPrivacy,
        ),
      ],
    );
  }

  String _maskPhone(String formatted) {
    if (formatted.length < 4) return formatted;
    final visible = formatted.substring(0, formatted.length - 4);
    return '$visible**-**';
  }

  String _maskIin(String iin) {
    if (iin.length < 4) return iin;
    return '${iin.substring(0, 4)}••••${iin.substring(iin.length - 2)}';
  }
}

class _SummaryRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final bool isLast;

  const _SummaryRow({
    required this.icon,
    required this.label,
    required this.value,
    this.isLast = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: isLast ? 0 : AppSpacing.md),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.textTertiary),
          AppSpacing.gapH12,
          Text(label, style: AppTypography.caption),
          const Spacer(),
          Flexible(
            child: Text(
              value.isEmpty ? '—' : value,
              textAlign: TextAlign.right,
              overflow: TextOverflow.ellipsis,
              style: AppTypography.body.copyWith(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

class _AgreementCheckbox extends StatelessWidget {
  final bool value;
  final String label;
  final ValueChanged<bool> onChanged;

  const _AgreementCheckbox({
    required this.value,
    required this.label,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onChanged(!value),
      behavior: HitTestBehavior.opaque,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: value ? AppColors.eagleBlue : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: value ? AppColors.eagleBlue : AppColors.borderStrong,
                width: 2,
              ),
            ),
            child: value
                ? const Icon(Icons.check_rounded,
                    size: 16, color: AppColors.textOnDark)
                : null,
          ),
          AppSpacing.gapH12,
          Expanded(
            child: Text(label, style: AppTypography.body),
          ),
        ],
      ),
    );
  }
}
