import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/auth_strings.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/utils/phone_formatter.dart';
import '../../../core/utils/validators.dart';
import '../../../providers/registration_provider.dart';
import '../../../widgets/ui/app_text_field.dart';

/// Step 1 — "Өзің туралы айт": name, phone, IIN.
class RegisterStepAbout extends ConsumerStatefulWidget {
  final GlobalKey<FormState> formKey;

  const RegisterStepAbout({super.key, required this.formKey});

  @override
  ConsumerState<RegisterStepAbout> createState() => _RegisterStepAboutState();
}

class _RegisterStepAboutState extends ConsumerState<RegisterStepAbout> {
  late final TextEditingController _name;
  late final TextEditingController _phone;
  late final TextEditingController _iin;

  @override
  void initState() {
    super.initState();
    final data = ref.read(registrationProvider);
    _name = TextEditingController(text: data.fullName);
    _phone = TextEditingController(text: data.phone);
    _iin = TextEditingController(text: data.iin);
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _iin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = ref.read(registrationProvider.notifier);

    return Form(
      key: widget.formKey,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(AuthStrings.step1Title, style: AppTypography.h2),
          AppSpacing.gapV24,
          AppTextField(
            label: AuthStrings.fullNameLabel,
            hint: AuthStrings.fullNameHint,
            controller: _name,
            prefixIcon: Icons.person_outline_rounded,
            textCapitalizationWords: true,
            validator: Validators.fullName,
            onChanged: controller.setFullName,
            textInputAction: TextInputAction.next,
          ),
          AppSpacing.gapV16,
          AppTextField(
            label: AuthStrings.phoneLabel,
            hint: AuthStrings.phoneHint,
            controller: _phone,
            keyboardType: TextInputType.phone,
            prefixIcon: Icons.phone_outlined,
            inputFormatters: [KzPhoneInputFormatter()],
            validator: Validators.phone,
            onChanged: controller.setPhone,
            textInputAction: TextInputAction.next,
          ),
          AppSpacing.gapV16,
          AppTextField(
            label: AuthStrings.iinLabel,
            hint: AuthStrings.iinHint,
            helperText: AuthStrings.iinHelper,
            controller: _iin,
            keyboardType: TextInputType.number,
            prefixIcon: Icons.badge_outlined,
            maxLength: 12,
            validator: Validators.iin,
            onChanged: controller.setIin,
            textInputAction: TextInputAction.done,
          ),
        ],
      ),
    );
  }
}
