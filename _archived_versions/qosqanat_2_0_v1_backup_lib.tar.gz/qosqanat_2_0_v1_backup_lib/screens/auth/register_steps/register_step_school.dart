import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_config.dart';
import '../../../core/constants/auth_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../providers/registration_provider.dart';
import '../../../widgets/ui/app_text_field.dart';

/// Step 3 — "Мектебің туралы": city dropdown, school, grade selector.
class RegisterStepSchool extends ConsumerStatefulWidget {
  const RegisterStepSchool({super.key});

  @override
  ConsumerState<RegisterStepSchool> createState() =>
      _RegisterStepSchoolState();
}

class _RegisterStepSchoolState extends ConsumerState<RegisterStepSchool> {
  late final TextEditingController _school;

  @override
  void initState() {
    super.initState();
    _school = TextEditingController(text: ref.read(registrationProvider).school);
  }

  @override
  void dispose() {
    _school.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = ref.read(registrationProvider.notifier);
    final data = ref.watch(registrationProvider);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(AuthStrings.step3Title, style: AppTypography.h2),
        AppSpacing.gapV24,

        // City dropdown
        Text(AuthStrings.cityLabel, style: AppTypography.caption),
        AppSpacing.gapV8,
        DropdownButtonFormField<String>(
          initialValue: data.city,
          isExpanded: true,
          decoration: const InputDecoration(
            hintText: AuthStrings.cityHint,
            prefixIcon: Icon(Icons.location_city_outlined,
                color: AppColors.textTertiary),
          ),
          items: AppConfig.cities
              .map((c) => DropdownMenuItem(value: c, child: Text(c)))
              .toList(),
          onChanged: controller.setCity,
        ),
        AppSpacing.gapV16,

        // School
        AppTextField(
          label: AuthStrings.schoolLabel,
          hint: AuthStrings.schoolHint,
          controller: _school,
          prefixIcon: Icons.school_outlined,
          onChanged: controller.setSchool,
        ),
        AppSpacing.gapV24,

        // Grade selector
        Text(AuthStrings.gradeLabel, style: AppTypography.caption),
        AppSpacing.gapV12,
        Wrap(
          spacing: AppSpacing.sm,
          runSpacing: AppSpacing.sm,
          children: AppConfig.grades.map((g) {
            final selected = data.grade == g;
            return _GradeChip(
              grade: g,
              selected: selected,
              onTap: () => controller.setGrade(g),
            );
          }).toList(),
        ),
      ],
    );
  }
}

class _GradeChip extends StatelessWidget {
  final int grade;
  final bool selected;
  final VoidCallback onTap;

  const _GradeChip({
    required this.grade,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedScale(
        scale: selected ? 1.12 : 1.0,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: 52,
          height: 52,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: selected ? AppColors.goldSoar : null,
            color: selected ? null : AppColors.surfaceMuted,
            borderRadius: AppRadius.radiusMd,
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: AppColors.steppeGold.withValues(alpha: 0.4),
                      blurRadius: 12,
                      offset: const Offset(0, 6),
                    ),
                  ]
                : null,
          ),
          child: Text(
            '$grade',
            style: AppTypography.h3.copyWith(
              color: selected ? AppColors.nightInk : AppColors.textSecondary,
            ),
          ),
        ),
      ),
    );
  }
}
