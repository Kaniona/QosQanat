import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/auth_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../core/utils/phone_formatter.dart';
import '../../core/utils/validators.dart';
import '../../navigation/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/ui/app_text_field.dart';
import '../../widgets/ui/eagle_emblem.dart';
import '../../widgets/ui/password_field.dart';
import '../../widgets/ui/primary_button.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void dispose() {
    _phoneController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    ref.read(authControllerProvider.notifier).clearError();
    if (!_formKey.currentState!.validate()) return;

    final ok = await ref.read(authControllerProvider.notifier).signIn(
          phoneE164: KzPhoneInputFormatter.toE164(_phoneController.text),
          password: _passwordController.text,
        );

    if (ok && mounted) context.go(AppRoutes.home);
  }

  @override
  Widget build(BuildContext context) {
    final action = ref.watch(authControllerProvider);

    return Scaffold(
      appBar: AppBar(leading: const BackButton()),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: AppSpacing.screenPadding,
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                AppSpacing.gapV16,
                const Center(child: EagleEmblem(size: 80)),
                AppSpacing.gapV24,
                Text(
                  AuthStrings.loginTitle,
                  textAlign: TextAlign.center,
                  style: AppTypography.h2,
                ),
                AppSpacing.gapV32,
                AppTextField(
                  label: AuthStrings.phoneLabel,
                  hint: AuthStrings.phoneHint,
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  prefixIcon: Icons.phone_outlined,
                  inputFormatters: [KzPhoneInputFormatter()],
                  validator: Validators.phone,
                  textInputAction: TextInputAction.next,
                ),
                AppSpacing.gapV16,
                PasswordField(
                  label: AuthStrings.passwordLabel,
                  hint: AuthStrings.passwordHint,
                  controller: _passwordController,
                  validator: Validators.password,
                  textInputAction: TextInputAction.done,
                ),
                AppSpacing.gapV12,
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () => context.push(AppRoutes.forgotPassword),
                    child: const Text(AuthStrings.forgotPassword),
                  ),
                ),
                if (action.error != null) ...[
                  AppSpacing.gapV8,
                  _ErrorBanner(message: AuthStrings.loginError),
                ],
                AppSpacing.gapV24,
                PrimaryButton(
                  label: AuthStrings.loginButton,
                  isLoading: action.isLoading,
                  onPressed: _submit,
                ),
                AppSpacing.gapV20,
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(AuthStrings.noAccount,
                        style: AppTypography.bodySecondary),
                    GestureDetector(
                      onTap: () => context.pushReplacement(AppRoutes.register),
                      child: Text(
                        AuthStrings.registerLink,
                        style: AppTypography.body.copyWith(
                          color: AppColors.eagleBlue,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
                AppSpacing.gapV24,
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ErrorBanner extends StatelessWidget {
  final String message;

  const _ErrorBanner({required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: AppSpacing.cardPadding,
      decoration: BoxDecoration(
        color: AppColors.coralSurface,
        borderRadius: AppRadius.radiusMd,
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline_rounded, color: AppColors.coral),
          AppSpacing.gapH12,
          Expanded(
            child: Text(
              message,
              style: AppTypography.body.copyWith(color: AppColors.coralDark),
            ),
          ),
        ],
      ),
    );
  }
}
