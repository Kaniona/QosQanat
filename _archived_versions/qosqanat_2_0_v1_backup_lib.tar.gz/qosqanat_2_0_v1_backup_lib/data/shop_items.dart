/// QosQanat shop catalog — 50+ cosmetic items across five categories.
///
/// Each item's `assetSvg` is rendered into the avatar at the matching slot via
/// [AvatarBase.equipped], so adding a new item here makes it shoppable AND
/// equippable everywhere (home HUD, task screens, profile, friends list…)
/// without touching any widget code.
library;

import '../models/enums.dart';
import '../models/shop_item.dart';
import '../widgets/avatar/avatar_base.dart';

// =============================================================================
// SVG helpers
// =============================================================================

String _wrap(String inner) =>
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 240">$inner</svg>';

/// Generic hoodie-style top in [color] with optional [stripe] accent.
String _hoodieSvg(String color, {String? stripe, String? hood, String? logo}) {
  return _wrap('''
    <path d="M60 120 Q100 104 140 120 L140 178 Q100 190 60 178 Z" fill="$color"/>
    <circle cx="58" cy="132" r="17" fill="$color"/>
    <circle cx="142" cy="132" r="17" fill="$color"/>
    <path d="M70 118 Q100 96 130 118 Q124 110 100 108 Q76 110 70 118 Z"
          fill="${hood ?? color}"/>
    ${stripe != null ? '<rect x="76" y="158" width="48" height="3" fill="$stripe"/>' : ''}
    ${logo != null ? '<text x="100" y="156" text-anchor="middle" font-size="14" fill="$logo" font-weight="800" font-family="sans-serif">QQ</text>' : ''}
  ''');
}

String _jacketSvg(String body, String trim, {String? collar}) {
  return _wrap('''
    <path d="M60 120 Q100 104 140 120 L140 178 Q100 190 60 178 Z" fill="$body"/>
    <circle cx="58" cy="132" r="17" fill="$body"/>
    <circle cx="142" cy="132" r="17" fill="$body"/>
    <rect x="98" y="118" width="4" height="64" fill="$trim"/>
    <path d="M88 114 L100 124 L112 114 L108 108 L92 108 Z" fill="${collar ?? trim}"/>
  ''');
}

String _bottomSvg(String color, {String? trim}) {
  return _wrap('''
    <rect x="68" y="168" width="64" height="26" rx="12" fill="$color"/>
    <rect x="80" y="186" width="18" height="38" rx="8" fill="$color"/>
    <rect x="102" y="186" width="18" height="38" rx="8" fill="$color"/>
    ${trim != null ? '<rect x="68" y="186" width="64" height="3" fill="$trim"/>' : ''}
  ''');
}

String _capSvg(String color, {String? logo}) {
  return _wrap('''
    <path d="M62 56 Q100 36 138 56 L138 70 L62 70 Z" fill="$color"/>
    <ellipse cx="100" cy="72" rx="46" ry="6" fill="$color"/>
    <path d="M138 64 Q166 66 168 80 L154 80 Q150 70 138 72 Z" fill="$color"/>
    ${logo != null ? '<circle cx="100" cy="54" r="6" fill="$logo"/>' : ''}
  ''');
}

String _takiyaSvg(String color, String trim) {
  return _wrap('''
    <ellipse cx="100" cy="28" rx="38" ry="14" fill="$color"/>
    <ellipse cx="100" cy="20" rx="34" ry="14" fill="$color"/>
    <ellipse cx="100" cy="14" rx="28" ry="12" fill="$color"/>
    <ellipse cx="100" cy="28" rx="38" ry="6" fill="$trim"/>
    <circle cx="100" cy="6" r="5" fill="$trim"/>
  ''');
}

String _crownSvg(String gold, String gem) {
  return _wrap('''
    <path d="M60 40 L72 14 L84 36 L100 8 L116 36 L128 14 L140 40 L138 56 L62 56 Z"
          fill="$gold"/>
    <rect x="60" y="50" width="80" height="10" fill="$gold"/>
    <circle cx="100" cy="22" r="4" fill="$gem"/>
    <circle cx="76" cy="40" r="3" fill="$gem"/>
    <circle cx="124" cy="40" r="3" fill="$gem"/>
  ''');
}

String _glassesSvg(String frame, {String? lens}) {
  return _wrap('''
    <rect x="58" y="58" width="32" height="18" rx="5" fill="${lens ?? '#FFFFFF'}"
          stroke="$frame" stroke-width="3"/>
    <rect x="110" y="58" width="32" height="18" rx="5" fill="${lens ?? '#FFFFFF'}"
          stroke="$frame" stroke-width="3"/>
    <line x1="90" y1="66" x2="110" y2="66" stroke="$frame" stroke-width="3"/>
  ''');
}

String _chainSvg(String metal, String gem) {
  return _wrap('''
    <path d="M70 108 Q100 132 130 108" stroke="$metal" stroke-width="3"
          fill="none" stroke-linecap="round"/>
    <circle cx="100" cy="124" r="6" fill="$gem" stroke="$metal" stroke-width="1.5"/>
  ''');
}

String _backpackSvg(String body, String strap) {
  return _wrap('''
    <rect x="48" y="120" width="14" height="50" rx="6" fill="$strap"/>
    <rect x="138" y="120" width="14" height="50" rx="6" fill="$strap"/>
    <rect x="50" y="118" width="100" height="60" rx="14" fill="$body"
          transform="translate(50 0)"/>
    <rect x="124" y="138" width="34" height="22" rx="6" fill="$strap"
          fill-opacity="0.7"/>
  ''');
}

String _petSvg(String color, String accent, {String? face, double cx = 32}) {
  // Pet is drawn near the bottom-left next to the character.
  return _wrap('''
    <ellipse cx="$cx" cy="218" rx="18" ry="5" fill="#1A1A4E" fill-opacity="0.2"/>
    <ellipse cx="$cx" cy="200" rx="20" ry="16" fill="$color"/>
    <circle cx="$cx" cy="178" r="14" fill="$color"/>
    <polygon points="${cx - 10},168 ${cx - 4},172 ${cx - 8},162"
             fill="$accent"/>
    <polygon points="${cx + 10},168 ${cx + 4},172 ${cx + 8},162"
             fill="$accent"/>
    <circle cx="${cx - 4}" cy="178" r="1.6" fill="#1A1A4E"/>
    <circle cx="${cx + 4}" cy="178" r="1.6" fill="#1A1A4E"/>
    ${face ?? ''}
  ''');
}

String _eagleSvg() => _wrap('''
    <ellipse cx="32" cy="220" rx="20" ry="5" fill="#1A1A4E" fill-opacity="0.2"/>
    <path d="M14 198 Q32 178 50 198 L50 212 Q32 220 14 212 Z" fill="#5A3A1A"/>
    <path d="M8 200 Q22 188 32 198 Z" fill="#F5A623"/>
    <path d="M56 200 Q42 188 32 198 Z" fill="#F5A623"/>
    <circle cx="32" cy="186" r="10" fill="#FFC459"/>
    <polygon points="36,186 44,188 36,192" fill="#F5A623"/>
    <circle cx="36" cy="184" r="1.5" fill="#1A1A4E"/>
  ''');

String _dragonSvg() => _wrap('''
    <ellipse cx="36" cy="220" rx="22" ry="5" fill="#1A1A4E" fill-opacity="0.2"/>
    <path d="M14 198 Q36 178 58 198 Q60 218 36 218 Q12 218 14 198 Z" fill="#7B61FF"/>
    <path d="M22 188 L34 176 L40 188 Z" fill="#A593FF"/>
    <path d="M40 188 L48 174 L54 190 Z" fill="#A593FF"/>
    <circle cx="36" cy="190" r="13" fill="#A593FF"/>
    <circle cx="32" cy="188" r="2" fill="#1A1A4E"/>
    <circle cx="42" cy="188" r="2" fill="#1A1A4E"/>
    <path d="M30 196 Q36 200 42 196" stroke="#FF4757" stroke-width="2"
          fill="none" stroke-linecap="round"/>
  ''');

String _robotPetSvg() => _wrap('''
    <ellipse cx="34" cy="220" rx="20" ry="5" fill="#1A1A4E" fill-opacity="0.2"/>
    <rect x="16" y="186" width="36" height="32" rx="6" fill="#9AA0BD"/>
    <rect x="22" y="174" width="24" height="18" rx="5" fill="#CDD3E4"/>
    <circle cx="28" cy="184" r="2" fill="#00C48C"/>
    <circle cx="40" cy="184" r="2" fill="#00C48C"/>
    <rect x="14" y="194" width="6" height="14" rx="2" fill="#4A6CF7"/>
    <rect x="48" y="194" width="6" height="14" rx="2" fill="#4A6CF7"/>
    <line x1="34" y1="166" x2="34" y2="174" stroke="#1A1A4E" stroke-width="1.5"/>
    <circle cx="34" cy="164" r="2" fill="#F5A623"/>
  ''');

String _astronautSvg() => _wrap('''
    <path d="M58 118 Q100 104 142 118 L144 184 Q100 192 56 184 Z" fill="#F2F4FA"/>
    <circle cx="58" cy="132" r="17" fill="#F2F4FA"/>
    <circle cx="142" cy="132" r="17" fill="#F2F4FA"/>
    <rect x="86" y="124" width="28" height="14" rx="3" fill="#4A6CF7"/>
    <rect x="86" y="124" width="28" height="14" rx="3" fill="#7B96FF"
          fill-opacity="0.4"/>
    <circle cx="138" cy="120" r="6" fill="#FF4757"/>
    <circle cx="62" cy="120" r="6" fill="#00C48C"/>
    <rect x="80" y="158" width="40" height="6" rx="2" fill="#CDD3E4"/>
  ''');

String _robotArmorSvg() => _wrap('''
    <path d="M60 118 Q100 104 140 118 L140 182 Q100 192 60 182 Z" fill="#5A5E80"/>
    <circle cx="58" cy="132" r="17" fill="#5A5E80"/>
    <circle cx="142" cy="132" r="17" fill="#5A5E80"/>
    <rect x="78" y="124" width="44" height="36" fill="#9AA0BD"/>
    <circle cx="100" cy="140" r="10" fill="#7B61FF"/>
    <circle cx="100" cy="140" r="5" fill="#A593FF"/>
    <rect x="78" y="166" width="44" height="3" fill="#1A1A4E"/>
    <rect x="78" y="174" width="44" height="3" fill="#1A1A4E"/>
  ''');

String _chapanSvg(String body, String trim) => _wrap('''
    <path d="M52 118 Q100 102 148 118 L148 198 Q100 210 52 198 Z" fill="$body"/>
    <circle cx="52" cy="132" r="18" fill="$body"/>
    <circle cx="148" cy="132" r="18" fill="$body"/>
    <rect x="98" y="118" width="4" height="84" fill="$trim"/>
    <path d="M60 118 Q100 124 140 118 L140 130 Q100 136 60 130 Z" fill="$trim"/>
  ''');

String _sportsTopSvg() => _wrap('''
    <path d="M60 120 Q100 104 140 120 L140 178 Q100 190 60 178 Z" fill="#FAFBFF"/>
    <circle cx="58" cy="132" r="17" fill="#FAFBFF"/>
    <circle cx="142" cy="132" r="17" fill="#FAFBFF"/>
    <path d="M60 120 L70 140 L60 160 Z" fill="#4A6CF7"/>
    <path d="M140 120 L130 140 L140 160 Z" fill="#FF4757"/>
    <text x="100" y="158" text-anchor="middle" font-size="14" fill="#1A1A4E"
          font-weight="800" font-family="sans-serif">KZ</text>
  ''');

String _schoolJacketSvg() => _wrap('''
    <path d="M60 120 Q100 104 140 120 L140 178 Q100 190 60 178 Z" fill="#2F4ECC"/>
    <circle cx="58" cy="132" r="17" fill="#2F4ECC"/>
    <circle cx="142" cy="132" r="17" fill="#2F4ECC"/>
    <path d="M88 114 L100 124 L112 114 L100 108 Z" fill="#F5A623"/>
    <rect x="80" y="148" width="14" height="14" fill="#F5A623"/>
    <text x="87" y="160" text-anchor="middle" font-size="10" fill="#1A1A4E"
          font-weight="800" font-family="sans-serif">Q</text>
  ''');

// =============================================================================
// Catalog
// =============================================================================

const _bottomSlot = AvatarSlot.bottom;
const _topSlot = AvatarSlot.top;
const _hatSlot = AvatarSlot.hat;
const _faceSlot = AvatarSlot.faceAccessory;
const _neckSlot = AvatarSlot.neck;
const _petSlot = AvatarSlot.pet;

final List<ShopItem> kShopCatalog = [
  // =========================================================================
  // TOPS (Жоғарғы)
  // =========================================================================
  ShopItem(
    id: 'top_school_jacket',
    name: 'Мектеп жакеті',
    description: 'QosQanat ресми мектеп жакеті — әр оқушыда бар.',
    category: ItemCategory.top,
    rarity: Rarity.common,
    price: 0,
    levelRequirement: 1,
    slot: _topSlot,
    assetSvg: _schoolJacketSvg(),
  ),
  ShopItem(
    id: 'top_hoodie_red',
    name: 'Қызыл худи',
    description: 'Жылы әрі жайлы қызыл капюшонды свитшот.',
    category: ItemCategory.top,
    rarity: Rarity.common,
    price: 120,
    slot: _topSlot,
    assetSvg: _hoodieSvg('#FF4757', stripe: '#FFFFFF'),
  ),
  ShopItem(
    id: 'top_hoodie_blue',
    name: 'Көк худи',
    description: 'Күнделікті киімге қолайлы — мектепке де, далаға да.',
    category: ItemCategory.top,
    rarity: Rarity.common,
    price: 120,
    slot: _topSlot,
    assetSvg: _hoodieSvg('#4A6CF7', stripe: '#FFFFFF'),
  ),
  ShopItem(
    id: 'top_hoodie_green',
    name: 'Жасыл худи',
    description: 'Дала түсінде — қыранға да, табиғатқа да жарасады.',
    category: ItemCategory.top,
    rarity: Rarity.common,
    price: 120,
    slot: _topSlot,
    assetSvg: _hoodieSvg('#00C48C', stripe: '#FFFFFF'),
  ),
  ShopItem(
    id: 'top_hoodie_purple',
    name: 'Күлгін худи',
    description: 'Космос реңі — XP-ға арналған.',
    category: ItemCategory.top,
    rarity: Rarity.rare,
    price: 220,
    slot: _topSlot,
    assetSvg: _hoodieSvg('#7B61FF', stripe: '#FFC459', logo: '#FFFFFF'),
  ),
  ShopItem(
    id: 'top_leather_jacket',
    name: 'Былғары жакет',
    description: 'Стильді былғары жакет — байыпты әрі суық.',
    category: ItemCategory.top,
    rarity: Rarity.rare,
    price: 280,
    levelRequirement: 5,
    slot: _topSlot,
    assetSvg: _jacketSvg('#1A1A4E', '#5A5E80'),
  ),
  ShopItem(
    id: 'top_chapan_gold',
    name: 'Алтын шапан',
    description: 'Ұлттық шапан — мерекелік сәттерге арналған.',
    category: ItemCategory.top,
    rarity: Rarity.rare,
    price: 320,
    levelRequirement: 5,
    slot: _topSlot,
    assetSvg: _chapanSvg('#D4860A', '#FFC459'),
  ),
  ShopItem(
    id: 'top_chapan_blue',
    name: 'Көк шапан',
    description: 'Көк-ою өрнегімен ұлттық шапан.',
    category: ItemCategory.top,
    rarity: Rarity.rare,
    price: 320,
    levelRequirement: 5,
    slot: _topSlot,
    assetSvg: _chapanSvg('#2F4ECC', '#F5A623'),
  ),
  ShopItem(
    id: 'top_sport_sweatshirt',
    name: 'Спорт свитшот',
    description: 'Қазақстан ұлттық құрама командасының тренировкалық киімі.',
    category: ItemCategory.top,
    rarity: Rarity.rare,
    price: 200,
    levelRequirement: 3,
    slot: _topSlot,
    assetSvg: _sportsTopSvg(),
  ),
  ShopItem(
    id: 'top_astronaut',
    name: 'Астронавт костюмі',
    description: 'Аспанға ұмтыласың ба? Бұл костюм бәріне дайын.',
    category: ItemCategory.top,
    rarity: Rarity.epic,
    price: 850,
    levelRequirement: 10,
    slot: _topSlot,
    assetSvg: _astronautSvg(),
  ),
  ShopItem(
    id: 'top_robot_armor',
    name: 'Робот сауыты',
    description: 'Болашақ соғыскерінің металл сауыты — энергиямен жанады.',
    category: ItemCategory.top,
    rarity: Rarity.legendary,
    price: 1800,
    levelRequirement: 15,
    slot: _topSlot,
    assetSvg: _robotArmorSvg(),
  ),

  // =========================================================================
  // BOTTOMS (Төменгі)
  // =========================================================================
  ShopItem(
    id: 'bottom_jeans_blue',
    name: 'Көк джинсы',
    description: 'Классикалық көк джинсы — қай киімге де келеді.',
    category: ItemCategory.bottom,
    rarity: Rarity.common,
    price: 100,
    slot: _bottomSlot,
    assetSvg: _bottomSvg('#4A6CF7'),
  ),
  ShopItem(
    id: 'bottom_jeans_black',
    name: 'Қара джинсы',
    description: 'Қара джинсы — стильге де, мектепке де.',
    category: ItemCategory.bottom,
    rarity: Rarity.common,
    price: 100,
    slot: _bottomSlot,
    assetSvg: _bottomSvg('#1A1A4E'),
  ),
  ShopItem(
    id: 'bottom_pants_school',
    name: 'Мектеп шалбары',
    description: 'Сұр түсті, ұқыпты мектеп шалбары.',
    category: ItemCategory.bottom,
    rarity: Rarity.common,
    price: 0,
    slot: _bottomSlot,
    assetSvg: _bottomSvg('#5A5E80'),
  ),
  ShopItem(
    id: 'bottom_sport_pants',
    name: 'Спорт шалбары',
    description: 'Спорттың жаны — жайлы әрі жеңіл.',
    category: ItemCategory.bottom,
    rarity: Rarity.common,
    price: 120,
    slot: _bottomSlot,
    assetSvg: _bottomSvg('#1A1A4E', trim: '#FFFFFF'),
  ),
  ShopItem(
    id: 'bottom_camo_pants',
    name: 'Камуфляж шалбар',
    description: 'Дала түсінде — батыр киімі.',
    category: ItemCategory.bottom,
    rarity: Rarity.rare,
    price: 220,
    levelRequirement: 4,
    slot: _bottomSlot,
    assetSvg: _bottomSvg('#3E5A2D', trim: '#5A7A3A'),
  ),
  ShopItem(
    id: 'bottom_gold_pants',
    name: 'Алтын шалбар',
    description: 'Көзге түсу үшін жасалған сирек шалбар.',
    category: ItemCategory.bottom,
    rarity: Rarity.rare,
    price: 280,
    levelRequirement: 6,
    slot: _bottomSlot,
    assetSvg: _bottomSvg('#D4860A', trim: '#FFC459'),
  ),
  ShopItem(
    id: 'bottom_space_pants',
    name: 'Ғарыш шалбары',
    description: 'Жұлдыздармен жанған шалбар.',
    category: ItemCategory.bottom,
    rarity: Rarity.epic,
    price: 600,
    levelRequirement: 10,
    slot: _bottomSlot,
    assetSvg: _bottomSvg('#5840CC', trim: '#FFFFFF'),
  ),

  // =========================================================================
  // HATS (Бас киім)
  // =========================================================================
  ShopItem(
    id: 'hat_baseball_blue',
    name: 'Көк бейсболка',
    description: 'Күн көзінен қорғайтын күнделікті кепка.',
    category: ItemCategory.hat,
    rarity: Rarity.common,
    price: 80,
    slot: _hatSlot,
    assetSvg: _capSvg('#4A6CF7', logo: '#FFFFFF'),
  ),
  ShopItem(
    id: 'hat_baseball_red',
    name: 'Қызыл бейсболка',
    description: 'От реңіндегі кепка — қызу жанкүйер үшін.',
    category: ItemCategory.hat,
    rarity: Rarity.common,
    price: 80,
    slot: _hatSlot,
    assetSvg: _capSvg('#FF4757', logo: '#FFFFFF'),
  ),
  ShopItem(
    id: 'hat_baseball_black',
    name: 'Қара бейсболка',
    description: 'Стильді қара кепка — бәріне жарасады.',
    category: ItemCategory.hat,
    rarity: Rarity.common,
    price: 80,
    slot: _hatSlot,
    assetSvg: _capSvg('#1A1A4E', logo: '#F5A623'),
  ),
  ShopItem(
    id: 'hat_takiya_white',
    name: 'Ақ тақия',
    description: 'Ою-өрнекті ұлттық ақ тақия.',
    category: ItemCategory.hat,
    rarity: Rarity.rare,
    price: 240,
    levelRequirement: 3,
    slot: _hatSlot,
    assetSvg: _takiyaSvg('#FFFFFF', '#D4860A'),
  ),
  ShopItem(
    id: 'hat_takiya_red',
    name: 'Қызыл тақия',
    description: 'Қызыл ұлттық тақия — алтынмен әрленген.',
    category: ItemCategory.hat,
    rarity: Rarity.rare,
    price: 240,
    levelRequirement: 3,
    slot: _hatSlot,
    assetSvg: _takiyaSvg('#D32F3D', '#F5A623'),
  ),
  ShopItem(
    id: 'hat_takiya_blue',
    name: 'Көк тақия',
    description: 'Аспан түсіндегі ұлттық тақия.',
    category: ItemCategory.hat,
    rarity: Rarity.rare,
    price: 240,
    levelRequirement: 3,
    slot: _hatSlot,
    assetSvg: _takiyaSvg('#2F4ECC', '#F5A623'),
  ),
  ShopItem(
    id: 'hat_winter_beanie',
    name: 'Қысқы шапка',
    description: 'Жылы қысқы шапка — суыққа төтеп береді.',
    category: ItemCategory.hat,
    rarity: Rarity.common,
    price: 120,
    slot: _hatSlot,
    assetSvg: _wrap('''
      <ellipse cx="100" cy="44" rx="40" ry="22" fill="#5A5E80"/>
      <rect x="62" y="40" width="76" height="12" fill="#9AA0BD"/>
      <circle cx="100" cy="14" r="9" fill="#FFC459"/>
    '''),
  ),
  ShopItem(
    id: 'hat_chef',
    name: 'Аспаз қалпағы',
    description: 'Ұзын ақ аспаз қалпағы — асхана үшін!',
    category: ItemCategory.hat,
    rarity: Rarity.rare,
    price: 260,
    levelRequirement: 4,
    slot: _hatSlot,
    assetSvg: _wrap('''
      <path d="M64 50 Q60 14 100 10 Q140 14 136 50 Z" fill="#FFFFFF"/>
      <rect x="64" y="46" width="72" height="14" fill="#FAFBFF"/>
    '''),
  ),
  ShopItem(
    id: 'hat_crown',
    name: 'Патша тәжі',
    description: 'Хан-сұлтанның тәжі — ең мықты оқушы тағады.',
    category: ItemCategory.hat,
    rarity: Rarity.legendary,
    price: 2000,
    levelRequirement: 20,
    slot: _hatSlot,
    assetSvg: _crownSvg('#F5A623', '#FF4757'),
  ),
  ShopItem(
    id: 'hat_witch',
    name: 'Сиқыршы қалпағы',
    description: 'Жасырын сиқыршының күлгін қалпағы.',
    category: ItemCategory.hat,
    rarity: Rarity.epic,
    price: 700,
    levelRequirement: 8,
    slot: _hatSlot,
    assetSvg: _wrap('''
      <polygon points="100,6 70,52 130,52" fill="#5840CC"/>
      <ellipse cx="100" cy="52" rx="42" ry="6" fill="#1A1A4E"/>
      <circle cx="86" cy="40" r="3" fill="#FFC459"/>
      <circle cx="110" cy="34" r="2" fill="#FFC459"/>
    '''),
  ),

  // =========================================================================
  // ACCESSORIES (Аксессуар)
  // =========================================================================
  ShopItem(
    id: 'acc_gold_chain',
    name: 'Алтын тізбек',
    description: 'Жылтыр алтын тізбек — стиль қосады.',
    category: ItemCategory.accessory,
    rarity: Rarity.rare,
    price: 320,
    levelRequirement: 4,
    slot: _neckSlot,
    assetSvg: _chainSvg('#F5A623', '#FFC459'),
  ),
  ShopItem(
    id: 'acc_silver_chain',
    name: 'Күміс тізбек',
    description: 'Күміс тізбек — жұмсақ жылтырлы.',
    category: ItemCategory.accessory,
    rarity: Rarity.common,
    price: 140,
    slot: _neckSlot,
    assetSvg: _chainSvg('#CDD3E4', '#FFFFFF'),
  ),
  ShopItem(
    id: 'acc_backpack',
    name: 'Рюкзак',
    description: 'Көк рюкзак — кітабыңды тасу үшін.',
    category: ItemCategory.accessory,
    rarity: Rarity.common,
    price: 100,
    slot: _neckSlot,
    assetSvg: _backpackSvg('#4A6CF7', '#2F4ECC'),
  ),
  ShopItem(
    id: 'acc_vr_glasses',
    name: 'VR көзілдірік',
    description: 'Виртуалды әлемнің кілті — болашақ технология.',
    category: ItemCategory.accessory,
    rarity: Rarity.epic,
    price: 900,
    levelRequirement: 12,
    slot: _faceSlot,
    assetSvg: _wrap('''
      <rect x="52" y="56" width="96" height="24" rx="8" fill="#1A1A4E"/>
      <rect x="58" y="60" width="36" height="16" rx="4" fill="#7B61FF"/>
      <rect x="106" y="60" width="36" height="16" rx="4" fill="#7B61FF"/>
      <circle cx="76" cy="68" r="3" fill="#00C48C"/>
      <circle cx="124" cy="68" r="3" fill="#00C48C"/>
    '''),
  ),
  ShopItem(
    id: 'acc_sunglasses',
    name: 'Күн көзілдірігі',
    description: 'Қара күн көзілдірігі — жаз күні үшін.',
    category: ItemCategory.accessory,
    rarity: Rarity.common,
    price: 90,
    slot: _faceSlot,
    assetSvg: _glassesSvg('#1A1A4E', lens: '#5A5E80'),
  ),
  ShopItem(
    id: 'acc_round_glasses',
    name: 'Дөңгелек көзілдірік',
    description: 'Ғалым үшін жасалған дөңгелек көзілдірік.',
    category: ItemCategory.accessory,
    rarity: Rarity.common,
    price: 110,
    slot: _faceSlot,
    assetSvg: _wrap('''
      <circle cx="74" cy="68" r="12" fill="none" stroke="#1A1A4E" stroke-width="3"/>
      <circle cx="126" cy="68" r="12" fill="none" stroke="#1A1A4E" stroke-width="3"/>
      <line x1="86" y1="68" x2="114" y2="68" stroke="#1A1A4E" stroke-width="3"/>
    '''),
  ),
  ShopItem(
    id: 'acc_headphones',
    name: 'Құлаққап',
    description: 'Музыка тыңдау үшін стильді құлаққап.',
    category: ItemCategory.accessory,
    rarity: Rarity.rare,
    price: 260,
    levelRequirement: 4,
    slot: _hatSlot,
    assetSvg: _wrap('''
      <path d="M58 60 Q60 30 100 28 Q140 30 142 60" stroke="#1A1A4E"
            stroke-width="6" fill="none" stroke-linecap="round"/>
      <rect x="48" y="58" width="22" height="30" rx="6" fill="#FF4757"/>
      <rect x="130" y="58" width="22" height="30" rx="6" fill="#FF4757"/>
    '''),
  ),
  ShopItem(
    id: 'acc_wings',
    name: 'Періште қанаты',
    description: 'Ақ қанаттар — рухтың жоғары ұшуы.',
    category: ItemCategory.accessory,
    rarity: Rarity.legendary,
    price: 1500,
    levelRequirement: 18,
    slot: _neckSlot,
    assetSvg: _wrap('''
      <path d="M50 130 Q14 100 8 160 Q24 160 50 150 Z" fill="#FFFFFF"
            stroke="#CDD3E4" stroke-width="1"/>
      <path d="M150 130 Q186 100 192 160 Q176 160 150 150 Z" fill="#FFFFFF"
            stroke="#CDD3E4" stroke-width="1"/>
    '''),
  ),
  ShopItem(
    id: 'acc_scarf',
    name: 'Қызыл орамал',
    description: 'Жылы қызыл орамал — қыс үшін.',
    category: ItemCategory.accessory,
    rarity: Rarity.common,
    price: 70,
    slot: _neckSlot,
    assetSvg: _wrap('''
      <path d="M72 116 Q100 124 128 116 L130 134 Q100 142 70 134 Z"
            fill="#FF4757"/>
      <rect x="120" y="130" width="14" height="34" rx="4" fill="#FF4757"/>
    '''),
  ),

  // =========================================================================
  // PETS (Питомец)
  // =========================================================================
  ShopItem(
    id: 'pet_white_cat',
    name: 'Ақ мысық',
    description: 'Жайдары ақ мысық — сабақ кезінде көңіл көтереді.',
    category: ItemCategory.pet,
    rarity: Rarity.common,
    price: 200,
    levelRequirement: 2,
    slot: _petSlot,
    assetSvg: _petSvg('#FFFFFF', '#FFFFFF',
        face:
            '<path d="M28 184 Q32 188 36 184" stroke="#FF8FB1" stroke-width="1.5" fill="none"/>'),
  ),
  ShopItem(
    id: 'pet_black_cat',
    name: 'Қара мысық',
    description: 'Жасырын қара мысық — түнгі сапардың серігі.',
    category: ItemCategory.pet,
    rarity: Rarity.common,
    price: 200,
    levelRequirement: 2,
    slot: _petSlot,
    assetSvg: _petSvg('#1A1A4E', '#33384D',
        face:
            '<circle cx="28" cy="178" r="1.6" fill="#FFC459"/><circle cx="36" cy="178" r="1.6" fill="#FFC459"/>'),
  ),
  ShopItem(
    id: 'pet_orange_cat',
    name: 'Сары мысық',
    description: 'Жылы реңді сары мысық.',
    category: ItemCategory.pet,
    rarity: Rarity.common,
    price: 200,
    levelRequirement: 2,
    slot: _petSlot,
    assetSvg: _petSvg('#FF8C42', '#D4860A'),
  ),
  ShopItem(
    id: 'pet_wolf_pup',
    name: 'Қасқыр күшігі',
    description: 'Кішкентай қасқыр — батыл әрі адал.',
    category: ItemCategory.pet,
    rarity: Rarity.rare,
    price: 500,
    levelRequirement: 6,
    slot: _petSlot,
    assetSvg: _petSvg('#5A5E80', '#1A1A4E',
        face:
            '<path d="M28 186 Q32 190 36 186" stroke="#FFFFFF" stroke-width="1.5" fill="none"/>'),
  ),
  ShopItem(
    id: 'pet_leopard_cub',
    name: 'Барс балапаны',
    description: 'Қар барысы — Қазақстанның мақтанышы.',
    category: ItemCategory.pet,
    rarity: Rarity.rare,
    price: 650,
    levelRequirement: 7,
    slot: _petSlot,
    assetSvg: _petSvg('#FFC459', '#D4860A',
        face:
            '<circle cx="28" cy="194" r="1.4" fill="#1A1A4E"/><circle cx="38" cy="196" r="1.2" fill="#1A1A4E"/><circle cx="30" cy="200" r="1" fill="#1A1A4E"/>'),
  ),
  ShopItem(
    id: 'pet_eagle',
    name: 'Бүркіт',
    description: 'Қыран бүркіт — QosQanat сенімінің таңбасы.',
    category: ItemCategory.pet,
    rarity: Rarity.epic,
    price: 1200,
    levelRequirement: 10,
    slot: _petSlot,
    assetSvg: _eagleSvg(),
  ),
  ShopItem(
    id: 'pet_robot',
    name: 'Робот достас',
    description: 'Энергия зарядталған кішкентай робот серік.',
    category: ItemCategory.pet,
    rarity: Rarity.epic,
    price: 1400,
    levelRequirement: 12,
    slot: _petSlot,
    assetSvg: _robotPetSvg(),
  ),
  ShopItem(
    id: 'pet_dragon_baby',
    name: 'Айдаһар балапаны',
    description: 'Күлгін от тыныстайтын ертегі айдаһарының балапаны.',
    category: ItemCategory.pet,
    rarity: Rarity.legendary,
    price: 2500,
    levelRequirement: 18,
    slot: _petSlot,
    assetSvg: _dragonSvg(),
  ),
  ShopItem(
    id: 'pet_phoenix',
    name: 'Феникс',
    description: 'Қайта оянатын от құсы — мифтегі мақтаныш.',
    category: ItemCategory.pet,
    rarity: Rarity.mythic,
    price: 4500,
    levelRequirement: 25,
    slot: _petSlot,
    assetSvg: _wrap('''
      <ellipse cx="34" cy="220" rx="22" ry="5" fill="#1A1A4E" fill-opacity="0.2"/>
      <path d="M14 198 Q34 174 54 198 Q34 200 14 198 Z" fill="#FF4757"/>
      <path d="M22 186 L34 168 L46 186 Z" fill="#F5A623"/>
      <circle cx="34" cy="192" r="12" fill="#FF8C42"/>
      <polygon points="38,192 46,194 38,196" fill="#F5A623"/>
      <circle cx="38" cy="190" r="1.6" fill="#1A1A4E"/>
      <path d="M44 200 Q58 196 60 210" stroke="#FF4757" stroke-width="2"
            fill="none" stroke-linecap="round"/>
    '''),
  ),
];

/// Convenience lookup by id.
ShopItem? shopItemById(String id) {
  for (final s in kShopCatalog) {
    if (s.id == id) return s;
  }
  return null;
}
