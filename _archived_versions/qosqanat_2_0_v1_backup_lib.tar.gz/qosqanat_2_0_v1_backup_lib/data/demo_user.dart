import '../models/enums.dart';
import '../models/user.dart';

/// Hardcoded account used when [AppConfig.demoMode] is on, so the app can be
/// explored without a working Supabase backend (no register/login needed).
///
/// Switch `AppConfig.demoMode` back to `false` once the Supabase schema and
/// phone auth are provisioned; the normal auth flow then resumes untouched.
final AppUser kDemoUser = AppUser(
  id: '00000000-0000-0000-0000-000000000001',
  qosqanatId: 'QQ-DEMO0001',
  fullName: 'Ақылбеков Нұртөре',
  phone: '+77713399824',
  iin: '090413554102',
  city: 'Қызылорда',
  school: '135 орта мектеп',
  grade: 11,
  assistantType: AssistantType.bektur,
  level: 6,
  xp: 800,
  coins: 500,
  akylPoints: 200,
  currentStreak: 3,
  longestStreak: 7,
  totalTasksCompleted: 24,
  totalBattlesWon: 5,
  createdAt: DateTime(2026, 1, 1),
);
