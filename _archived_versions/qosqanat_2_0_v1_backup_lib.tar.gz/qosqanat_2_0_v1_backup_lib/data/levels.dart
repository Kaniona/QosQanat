/// Leveling system for QosQanat 2.0 (levels 1–100).
///
/// XP curve: the cumulative total XP needed to *reach* level n is
///   xpRequired(n) = (n-1)*100 + (n-1)^2 * 10
/// Reaching a level grants `level * 20` coins. Titles are assigned by range.
library;

/// Immutable description of a level.
class LevelInfo {
  /// 1–100.
  final int level;

  /// Kazakh rank title for this level.
  final String title;

  /// Cumulative total XP required to reach this level.
  final int totalXpRequired;

  /// Coins granted when this level is reached.
  final int coinReward;

  const LevelInfo({
    required this.level,
    required this.title,
    required this.totalXpRequired,
    required this.coinReward,
  });
}

const int kMinLevel = 1;
const int kMaxLevel = 100;

/// Cumulative total XP required to reach [level].
int xpRequiredForLevel(int level) {
  final n = level.clamp(kMinLevel, kMaxLevel);
  final m = n - 1;
  return m * 100 + m * m * 10;
}

/// Coins granted upon reaching [level].
int coinRewardForLevel(int level) => level.clamp(kMinLevel, kMaxLevel) * 20;

/// Kazakh rank title for [level].
String titleForLevel(int level) {
  final n = level.clamp(kMinLevel, kMaxLevel);
  if (n >= 100) return 'QosQanat Чемпионы';
  if (n >= 91) return 'Легенда';
  if (n >= 76) return 'Ұлы оқушы';
  if (n >= 61) return 'Данышпан';
  if (n >= 51) return 'Ғалым шәкірт';
  if (n >= 41) return 'Білімнің шебері';
  if (n >= 31) return 'Озық оқушы';
  if (n >= 21) return 'Данышпан шәкірт';
  if (n >= 16) return 'Білімдар';
  if (n >= 11) return 'Ақылды оқушы';
  if (n >= 6) return 'Білімгер';
  return 'Жас оқушы';
}

/// Full [LevelInfo] for [level].
LevelInfo getLevelInfo(int level) {
  final n = level.clamp(kMinLevel, kMaxLevel);
  return LevelInfo(
    level: n,
    title: titleForLevel(n),
    totalXpRequired: xpRequiredForLevel(n),
    coinReward: coinRewardForLevel(n),
  );
}

/// The level corresponding to a given [totalXp] (1–100).
int calculateLevel(int totalXp) {
  if (totalXp <= 0) return kMinLevel;
  for (var n = kMaxLevel; n >= kMinLevel; n--) {
    if (totalXp >= xpRequiredForLevel(n)) return n;
  }
  return kMinLevel;
}

/// XP accumulated within the current level (0 at a level boundary).
int xpIntoCurrentLevel(int totalXp) {
  final level = calculateLevel(totalXp);
  return totalXp - xpRequiredForLevel(level);
}

/// Total XP span of [level] (from this level to the next). 0 at max level.
int xpSpanForLevel(int level) {
  if (level >= kMaxLevel) return 0;
  return xpRequiredForLevel(level + 1) - xpRequiredForLevel(level);
}

/// Remaining XP needed to reach the next level. 0 at max level.
int xpToNextLevel(int totalXp) {
  final level = calculateLevel(totalXp);
  if (level >= kMaxLevel) return 0;
  return xpRequiredForLevel(level + 1) - totalXp;
}

/// Progress through the current level, 0.0–1.0 (1.0 at max level).
double levelProgress(int totalXp) {
  final level = calculateLevel(totalXp);
  final span = xpSpanForLevel(level);
  if (span <= 0) return 1.0;
  return (xpIntoCurrentLevel(totalXp) / span).clamp(0.0, 1.0);
}
