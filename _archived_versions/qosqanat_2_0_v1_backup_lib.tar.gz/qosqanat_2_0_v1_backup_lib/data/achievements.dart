/// Achievement catalog for QosQanat 2.0 (34 achievements across 6 categories).
library;

import '../models/enums.dart';

/// Grouping for achievements, used for filtering and section headers.
enum AchievementCategory {
  learning,
  battle,
  collection,
  friends,
  streak,
  special;

  String get label {
    switch (this) {
      case AchievementCategory.learning:
        return 'Оқу';
      case AchievementCategory.battle:
        return 'Шайқас';
      case AchievementCategory.collection:
        return 'Коллекция';
      case AchievementCategory.friends:
        return 'Достар';
      case AchievementCategory.streak:
        return 'Серия';
      case AchievementCategory.special:
        return 'Ерекше';
    }
  }
}

/// Static definition of an achievement. Per-user unlock state lives in the
/// `user_achievements` table and the [Achievement] model.
class AchievementTemplate {
  final String id;
  final String title;
  final String description;
  final String emoji;
  final AchievementCategory category;
  final Rarity rarity;

  /// Progress target that unlocks the achievement.
  final int target;
  final int coinReward;

  const AchievementTemplate({
    required this.id,
    required this.title,
    required this.description,
    required this.emoji,
    required this.category,
    required this.rarity,
    required this.target,
    required this.coinReward,
  });
}

/// The full achievement catalog.
const List<AchievementTemplate> kAchievements = [
  // --- Learning -------------------------------------------------------------
  AchievementTemplate(
    id: 'first_lesson',
    title: 'Алғашқы қадам',
    description: 'Алғашқы сабақты аяқта',
    emoji: '📚',
    category: AchievementCategory.learning,
    rarity: Rarity.common,
    target: 1,
    coinReward: 50,
  ),
  AchievementTemplate(
    id: 'ten_tasks',
    title: 'Еңбекқор',
    description: '10 тапсырма орында',
    emoji: '✏️',
    category: AchievementCategory.learning,
    rarity: Rarity.common,
    target: 10,
    coinReward: 80,
  ),
  AchievementTemplate(
    id: 'fifty_tasks',
    title: 'Білім құмар',
    description: '50 тапсырма орында',
    emoji: '📖',
    category: AchievementCategory.learning,
    rarity: Rarity.rare,
    target: 50,
    coinReward: 200,
  ),
  AchievementTemplate(
    id: 'hundred_tasks',
    title: 'Жүздік',
    description: '100 тапсырма орында',
    emoji: '🎓',
    category: AchievementCategory.learning,
    rarity: Rarity.epic,
    target: 100,
    coinReward: 400,
  ),
  AchievementTemplate(
    id: 'perfect_ten',
    title: 'Мінсіздік',
    description: '10 тапсырманы 100%-бен аяқта',
    emoji: '💯',
    category: AchievementCategory.learning,
    rarity: Rarity.rare,
    target: 10,
    coinReward: 250,
  ),
  AchievementTemplate(
    id: 'subject_master',
    title: 'Пән шебері',
    description: 'Бір пәнді толық аяқта',
    emoji: '🏅',
    category: AchievementCategory.learning,
    rarity: Rarity.epic,
    target: 1,
    coinReward: 500,
  ),
  AchievementTemplate(
    id: 'reach_level_10',
    title: 'Оныншы деңгей',
    description: '10-деңгейге жет',
    emoji: '⭐',
    category: AchievementCategory.learning,
    rarity: Rarity.common,
    target: 10,
    coinReward: 100,
  ),
  AchievementTemplate(
    id: 'reach_level_50',
    title: 'Жарты жол',
    description: '50-деңгейге жет',
    emoji: '🌟',
    category: AchievementCategory.learning,
    rarity: Rarity.epic,
    target: 50,
    coinReward: 600,
  ),
  AchievementTemplate(
    id: 'reach_level_100',
    title: 'Ең биік шың',
    description: '100-деңгейге жет',
    emoji: '👑',
    category: AchievementCategory.learning,
    rarity: Rarity.mythic,
    target: 100,
    coinReward: 2000,
  ),

  // --- Battle ---------------------------------------------------------------
  AchievementTemplate(
    id: 'first_battle',
    title: 'Жауынгер',
    description: 'Алғашқы шайқасқа қатыс',
    emoji: '⚔️',
    category: AchievementCategory.battle,
    rarity: Rarity.common,
    target: 1,
    coinReward: 50,
  ),
  AchievementTemplate(
    id: 'first_win',
    title: 'Жеңімпаз',
    description: 'Алғашқы жеңіске жет',
    emoji: '🥇',
    category: AchievementCategory.battle,
    rarity: Rarity.common,
    target: 1,
    coinReward: 80,
  ),
  AchievementTemplate(
    id: 'ten_wins',
    title: 'Айбынды',
    description: '10 шайқаста жең',
    emoji: '🛡️',
    category: AchievementCategory.battle,
    rarity: Rarity.rare,
    target: 10,
    coinReward: 250,
  ),
  AchievementTemplate(
    id: 'fifty_wins',
    title: 'Шайқас шебері',
    description: '50 шайқаста жең',
    emoji: '🏆',
    category: AchievementCategory.battle,
    rarity: Rarity.epic,
    target: 50,
    coinReward: 600,
  ),
  AchievementTemplate(
    id: 'win_streak_5',
    title: 'Тоқтаусыз',
    description: 'Қатарынан 5 рет жең',
    emoji: '🔥',
    category: AchievementCategory.battle,
    rarity: Rarity.rare,
    target: 5,
    coinReward: 300,
  ),
  AchievementTemplate(
    id: 'flawless_battle',
    title: 'Мінсіз жеңіс',
    description: 'Қатесіз шайқаста жең',
    emoji: '✨',
    category: AchievementCategory.battle,
    rarity: Rarity.epic,
    target: 1,
    coinReward: 400,
  ),

  // --- Collection -----------------------------------------------------------
  AchievementTemplate(
    id: 'first_item',
    title: 'Сәнқой',
    description: 'Алғашқы затты сатып ал',
    emoji: '🛍️',
    category: AchievementCategory.collection,
    rarity: Rarity.common,
    target: 1,
    coinReward: 40,
  ),
  AchievementTemplate(
    id: 'ten_items',
    title: 'Коллекционер',
    description: '10 зат жина',
    emoji: '🎁',
    category: AchievementCategory.collection,
    rarity: Rarity.rare,
    target: 10,
    coinReward: 200,
  ),
  AchievementTemplate(
    id: 'legendary_item',
    title: 'Аңызға айналған',
    description: 'Легендарлы зат сатып ал',
    emoji: '💎',
    category: AchievementCategory.collection,
    rarity: Rarity.epic,
    target: 1,
    coinReward: 500,
  ),
  AchievementTemplate(
    id: 'full_outfit',
    title: 'Толық киім',
    description: 'Барлық киім слотын толтыр',
    emoji: '👕',
    category: AchievementCategory.collection,
    rarity: Rarity.rare,
    target: 1,
    coinReward: 250,
  ),
  AchievementTemplate(
    id: 'pet_owner',
    title: 'Жаныңда серік',
    description: 'Алғашқы үй жануарын ал',
    emoji: '🐾',
    category: AchievementCategory.collection,
    rarity: Rarity.common,
    target: 1,
    coinReward: 100,
  ),

  // --- Friends --------------------------------------------------------------
  AchievementTemplate(
    id: 'first_friend',
    title: 'Достасу',
    description: 'Алғашқы досыңды қос',
    emoji: '🤝',
    category: AchievementCategory.friends,
    rarity: Rarity.common,
    target: 1,
    coinReward: 50,
  ),
  AchievementTemplate(
    id: 'five_friends',
    title: 'Көпшіл',
    description: '5 дос жина',
    emoji: '👥',
    category: AchievementCategory.friends,
    rarity: Rarity.rare,
    target: 5,
    coinReward: 150,
  ),
  AchievementTemplate(
    id: 'twenty_friends',
    title: 'Танымал',
    description: '20 дос жина',
    emoji: '🌐',
    category: AchievementCategory.friends,
    rarity: Rarity.epic,
    target: 20,
    coinReward: 400,
  ),
  AchievementTemplate(
    id: 'friend_battle',
    title: 'Достық шайқас',
    description: 'Досыңмен шайқас',
    emoji: '🤼',
    category: AchievementCategory.friends,
    rarity: Rarity.common,
    target: 1,
    coinReward: 60,
  ),

  // --- Streak ---------------------------------------------------------------
  AchievementTemplate(
    id: 'streak_3',
    title: 'Бастама',
    description: '3 күн қатарынан оқы',
    emoji: '📅',
    category: AchievementCategory.streak,
    rarity: Rarity.common,
    target: 3,
    coinReward: 60,
  ),
  AchievementTemplate(
    id: 'streak_7',
    title: 'Апталық',
    description: '7 күн қатарынан оқы',
    emoji: '🗓️',
    category: AchievementCategory.streak,
    rarity: Rarity.rare,
    target: 7,
    coinReward: 200,
  ),
  AchievementTemplate(
    id: 'streak_30',
    title: 'Темірдей тәртіп',
    description: '30 күн қатарынан оқы',
    emoji: '💪',
    category: AchievementCategory.streak,
    rarity: Rarity.epic,
    target: 30,
    coinReward: 700,
  ),
  AchievementTemplate(
    id: 'streak_100',
    title: 'Жүз күн',
    description: '100 күн қатарынан оқы',
    emoji: '🏔️',
    category: AchievementCategory.streak,
    rarity: Rarity.mythic,
    target: 100,
    coinReward: 2500,
  ),

  // --- Special --------------------------------------------------------------
  AchievementTemplate(
    id: 'first_assistant',
    title: 'Серік таңдау',
    description: 'Серігіңді таңда',
    emoji: '🐣',
    category: AchievementCategory.special,
    rarity: Rarity.common,
    target: 1,
    coinReward: 30,
  ),
  AchievementTemplate(
    id: 'early_bird',
    title: 'Ерте тұрған',
    description: 'Таңғы 6–9 аралығында оқы',
    emoji: '🌅',
    category: AchievementCategory.special,
    rarity: Rarity.rare,
    target: 1,
    coinReward: 150,
  ),
  AchievementTemplate(
    id: 'night_owl',
    title: 'Түнгі үкі',
    description: 'Түнгі 22:00-ден кейін оқы',
    emoji: '🦉',
    category: AchievementCategory.special,
    rarity: Rarity.rare,
    target: 1,
    coinReward: 150,
  ),
  AchievementTemplate(
    id: 'birthday',
    title: 'Туған күн',
    description: 'Туған күніңде кір',
    emoji: '🎂',
    category: AchievementCategory.special,
    rarity: Rarity.epic,
    target: 1,
    coinReward: 500,
  ),
  AchievementTemplate(
    id: 'hundred_akyl',
    title: 'Ақылды',
    description: '100 ақыл ұпай жина',
    emoji: '🧠',
    category: AchievementCategory.special,
    rarity: Rarity.common,
    target: 100,
    coinReward: 100,
  ),
  AchievementTemplate(
    id: 'thousand_coins',
    title: 'Байлық',
    description: '1000 тиын жина',
    emoji: '💰',
    category: AchievementCategory.special,
    rarity: Rarity.rare,
    target: 1000,
    coinReward: 100,
  ),
];

/// Achievements belonging to [category].
List<AchievementTemplate> achievementsByCategory(AchievementCategory category) =>
    kAchievements.where((a) => a.category == category).toList();
