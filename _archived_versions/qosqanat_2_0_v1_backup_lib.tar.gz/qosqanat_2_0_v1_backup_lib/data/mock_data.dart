import 'dart:math' as math;

import '../services/offline_service.dart';
import 'achievements.dart';
import 'curriculum.dart';

/// Comprehensive mock dataset for **offline test mode**. [seedMockData] writes
/// everything into Hive once (guarded by [OfflineService.isSeeded]) so every
/// screen has realistic data without a backend.
///
/// All per-user collections (friends, battles, progress, inventory, equipped
/// items, unlocked achievements) are attached to [kPrimaryUserId] — the account
/// loaded by the offline "login" flow. A freshly *registered* user starts with
/// a clean slate, which is exactly what we want for end-to-end testing.

/// Stable id of the headline mock account (the one offline login signs in as).
const String kPrimaryUserId = 'qq-user-0001';

/// QQ-ID the spec asks the primary user to carry.
const String kPrimaryQosqanatId = 'QQ-A1B2C3D4';

// =============================================================================
// Seed entry-point
// =============================================================================

Future<void> seedMockData({bool force = false}) async {
  await OfflineService.init();
  if (OfflineService.isSeeded && !force) return;

  final users = OfflineService.box(OfflineService.usersBox);
  final news = OfflineService.box(OfflineService.newsBox);
  final quests = OfflineService.box(OfflineService.questsBox);
  final friends = OfflineService.box(OfflineService.friendsBox);
  final battles = OfflineService.box(OfflineService.battlesBox);
  final tasks = OfflineService.box(OfflineService.tasksBox);
  final achievements = OfflineService.box(OfflineService.achievementsBox);
  final inventory = OfflineService.box(OfflineService.inventoryBox);
  final equipment = OfflineService.box(OfflineService.equipmentBox);
  final tournaments = OfflineService.box(OfflineService.tournamentsBox);
  final tournamentParticipants =
      OfflineService.box(OfflineService.tournamentParticipantsBox);

  if (force) {
    await Future.wait([
      users.clear(),
      news.clear(),
      quests.clear(),
      friends.clear(),
      battles.clear(),
      tasks.clear(),
      achievements.clear(),
      inventory.clear(),
      equipment.clear(),
      tournaments.clear(),
      tournamentParticipants.clear(),
    ]);
  }

  // Users -----------------------------------------------------------------
  for (final u in _mockUsers()) {
    await users.put(u['id'], u);
  }

  // News ------------------------------------------------------------------
  for (final n in _mockNews()) {
    await news.put(n['id'], n);
  }

  // Daily quests ----------------------------------------------------------
  await quests.put('daily', _mockQuests());

  // Friendships (primary user) -------------------------------------------
  for (final f in _mockFriendships()) {
    await friends.put(f['id'], f);
  }

  // Battle history (primary user) ----------------------------------------
  for (final b in _mockBattleHistory()) {
    await battles.put(b['id'], b);
  }

  // Task progress (primary user) -----------------------------------------
  await tasks.put(kPrimaryUserId, _mockTaskProgress());

  // Unlocked achievements (primary user) ---------------------------------
  await achievements.put(kPrimaryUserId, _mockUnlockedAchievements());

  // Inventory + equipment (primary user) ---------------------------------
  await inventory.put(kPrimaryUserId, _mockInventory());
  await equipment.put(kPrimaryUserId, _mockEquipment());

  // Tournaments -----------------------------------------------------------
  for (final t in _mockTournaments()) {
    await tournaments.put(t['id'], t);
  }
  final parts = _mockTournamentParticipants();
  for (final entry in parts.entries) {
    await tournamentParticipants.put(entry.key, entry.value);
  }

  OfflineService.markSeeded();
}

// =============================================================================
// Users — 1 primary + 21 others for a lively leaderboard
// =============================================================================

const List<String> _cities = [
  'Астана', 'Алматы', 'Шымкент', 'Қарағанды', 'Қызылорда',
  'Ақтөбе', 'Тараз', 'Павлодар', 'Атырау', 'Көкшетау',
];

const List<String> _firstNames = [
  'Әлихан', 'Аружан', 'Бекзат', 'Дана', 'Ерасыл', 'Жансая', 'Нұрислам',
  'Аяулым', 'Сұлтан', 'Мадина', 'Темірлан', 'Айгерім', 'Дамир', 'Камила',
  'Әмір', 'Зере', 'Алдияр', 'Ділназ', 'Нұрсұлтан', 'Інжу', 'Арман', 'Гүлназ',
];

const List<String> _lastNames = [
  'Серіков', 'Қайратқызы', 'Маратұлы', 'Болатова', 'Асқарұлы', 'Ерболқызы',
  'Тоқтарұлы', 'Сапарова', 'Дәулетұлы', 'Нұрланқызы', 'Жомартұлы', 'Қанатова',
  'Ілияс', 'Рахатқызы', 'Бекболат', 'Ермекова', 'Талғатұлы', 'Сейітова',
  'Абайұлы', 'Мұратқызы', 'Қуанышұлы', 'Жасұланқызы',
];

const List<String> _schools = [
  '№135 орта мектеп', 'Назарбаев Зияткерлік мектебі', '№5 гимназия',
  '№42 лицей', 'БІЛ', '№7 орта мектеп', '№28 мектеп-лицей', '№3 гимназия',
];

List<Map<String, dynamic>> _mockUsers() {
  final rng = math.Random(7);
  final now = DateTime(2026, 6, 7);
  final list = <Map<String, dynamic>>[];

  // Primary account (spec values) ---------------------------------------
  list.add(_user(
    id: kPrimaryUserId,
    qq: kPrimaryQosqanatId,
    fullName: 'Әлихан Серіков',
    phone: '+77771234567',
    iin: '090413554102',
    city: 'Қызылорда',
    school: '№135 орта мектеп',
    grade: 11,
    assistant: 'bektur',
    level: 12,
    xp: 3400,
    coins: 1250,
    akyl: 890,
    streak: 7,
    longestStreak: 14,
    tasksDone: 48,
    battlesWon: 9,
    createdAt: DateTime(2026, 1, 5),
  ));

  // Other students -------------------------------------------------------
  for (var i = 1; i < 22; i++) {
    final level = 3 + rng.nextInt(28); // 3–30
    final akyl = 80 + rng.nextInt(1900);
    list.add(_user(
      id: 'qq-user-${(i + 1).toString().padLeft(4, '0')}',
      qq: 'QQ-${_randId(rng)}',
      fullName: '${_firstNames[i % _firstNames.length]} '
          '${_lastNames[i % _lastNames.length]}',
      phone: '+7770${(1000000 + rng.nextInt(8999999))}',
      iin: '0${rng.nextInt(9)}0${rng.nextInt(9)}${100000 + rng.nextInt(899999)}',
      city: _cities[i % _cities.length],
      school: _schools[i % _schools.length],
      grade: 5 + rng.nextInt(7),
      assistant: i.isEven ? 'nazym' : 'bektur',
      level: level,
      xp: level * 280 + rng.nextInt(260),
      coins: 100 + rng.nextInt(2400),
      akyl: akyl,
      streak: rng.nextInt(20),
      longestStreak: 5 + rng.nextInt(40),
      tasksDone: 10 + rng.nextInt(200),
      battlesWon: rng.nextInt(60),
      createdAt: now.subtract(Duration(days: 20 + rng.nextInt(300))),
    ));
  }
  return list;
}

Map<String, dynamic> _user({
  required String id,
  required String qq,
  required String fullName,
  required String phone,
  required String iin,
  required String city,
  required String school,
  required int grade,
  required String assistant,
  required int level,
  required int xp,
  required int coins,
  required int akyl,
  required int streak,
  required int longestStreak,
  required int tasksDone,
  required int battlesWon,
  required DateTime createdAt,
}) {
  return {
    'id': id,
    'qosqanat_id': qq,
    'full_name': fullName,
    'phone': phone,
    'iin': iin,
    'city': city,
    'school': school,
    'grade': grade,
    'assistant_type': assistant,
    'profile_photo_url': null,
    'level': level,
    'xp': xp,
    'coins': coins,
    'akyl_points': akyl,
    'current_streak': streak,
    'longest_streak': longestStreak,
    'total_tasks_completed': tasksDone,
    'total_battles_won': battlesWon,
    'created_at': createdAt.toIso8601String(),
  };
}

String _randId(math.Random rng) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return List.generate(8, (_) => chars[rng.nextInt(chars.length)]).join();
}

// =============================================================================
// News — 6 announcements across the four categories
// =============================================================================

List<Map<String, dynamic>> _mockNews() {
  final now = DateTime(2026, 6, 7, 9);
  Map<String, dynamic> n(
    String id,
    String title,
    String body,
    String category,
    int daysAgo, {
    bool pinned = false,
  }) =>
      {
        'id': id,
        'title': title,
        'body': body,
        'cover_image_url': null,
        'category': category,
        'author_name': 'QosQanat командасы',
        'is_pinned': pinned,
        'published_at':
            now.subtract(Duration(days: daysAgo)).toIso8601String(),
      };

  return [
    n(
      'news_1',
      '🏆 Жазғы Ұлы Турнир басталды!',
      'Барлық пәндер бойынша жазғы турнирге тіркелу ашық. Жеңімпаздарды '
          '10 000 монета мен арнайы аңызға айналған киімдер күтеді. '
          'Турнир бөліміне өтіп, қатысуға асық!',
      'Турнир',
      0,
      pinned: true,
    ),
    n(
      'news_2',
      '✨ Жаңарту: жаңа Информатика модулі қосылды',
      'Енді Python-мен танысу мен жасанды интеллект тақырыптары қолжетімді. '
          '6-сынып модулінде 16 жаңа сабақ сені күтеді!',
      'Жаңарту',
      1,
    ),
    n(
      'news_3',
      '🎉 Білім марафоны — қос XP апталығы',
      'Осы аптада әр орындалған тапсырма үшін XP екі есе беріледі. '
          'Деңгейіңді көтеріп, дүкеннен жаңа киім ал!',
      'Іс-шара',
      2,
    ),
    n(
      'news_4',
      '💡 Кеңес: streak-ті қалай сақтап қалуға болады',
      'Күн сайын кемінде бір тапсырма орында — сонда streak үзілмейді. '
          '7 күндік streak үшін бонус монета аласың!',
      'Кеңес',
      3,
    ),
    n(
      'news_5',
      '⚔️ Достармен Ақыл-сайыс режимі жаңартылды',
      'Енді 50 сұраққа дейін батл өткізуге болады әрі пәнді өзің таңдайсың. '
          'Досыңды шақырып, біліміңді сына!',
      'Жаңарту',
      5,
    ),
    n(
      'news_6',
      '🦅 QosQanat 2.0 — мыңдаған оқушы бізбен бірге!',
      'Қазақстанның түкпір-түкпірінен оқушылар бізге қосылуда. '
          'Рейтингтен өз орныңды тауып, шыңға ұмтыл!',
      'Іс-шара',
      7,
    ),
  ];
}

// =============================================================================
// Daily quests — 10 with Kazakh titles, targets, rewards
// =============================================================================

List<Map<String, dynamic>> _mockQuests() {
  Map<String, dynamic> q(String id, String title, int target, int progress,
          int coins, int xp, String icon) =>
      {
        'id': id,
        'title': title,
        'target': target,
        'progress': progress,
        'coin_reward': coins,
        'xp_reward': xp,
        'icon': icon,
      };

  return [
    q('quest_1', '3 тапсырма орында', 3, 1, 30, 60, '✅'),
    q('quest_2', '1 батлда жең', 1, 0, 50, 40, '⚔️'),
    q('quest_3', '50 XP жина', 50, 20, 25, 0, '⭐'),
    q('quest_4', 'Streak-ті сақта', 1, 1, 20, 10, '🔥'),
    q('quest_5', 'Математикадан сабақ өт', 2, 0, 20, 30, '➗'),
    q('quest_6', 'Досыңды шақыр', 1, 0, 40, 0, '👥'),
    q('quest_7', 'Дүкеннен бұйым ал', 1, 0, 0, 20, '🛍️'),
    q('quest_8', 'Қазақ тілінен 1 квиз', 1, 0, 25, 35, '📖'),
    q('quest_9', '100% дәлдікке жет', 1, 0, 60, 50, '🎯'),
    q('quest_10', 'Профильді толтыр', 1, 1, 15, 0, '🦅'),
  ];
}

// =============================================================================
// Friendships for the primary user (accepted + pending both directions)
// =============================================================================

List<Map<String, dynamic>> _mockFriendships() {
  final now = DateTime(2026, 6, 7);
  final list = <Map<String, dynamic>>[];

  Map<String, dynamic> fr(
    String id,
    String other,
    String status,
    String initiatedBy,
    int daysAgo,
  ) {
    // friendships use canonical (a < b) ordering on the user ids.
    final a = kPrimaryUserId.compareTo(other) < 0 ? kPrimaryUserId : other;
    final b = kPrimaryUserId.compareTo(other) < 0 ? other : kPrimaryUserId;
    return {
      'id': id,
      'user_a_id': a,
      'user_b_id': b,
      'initiated_by': initiatedBy,
      'status': status,
      'created_at': now.subtract(Duration(days: daysAgo)).toIso8601String(),
      'accepted_at': status == 'accepted'
          ? now.subtract(Duration(days: daysAgo - 1)).toIso8601String()
          : null,
    };
  }

  // 6 accepted friends
  for (var i = 2; i <= 7; i++) {
    final other = 'qq-user-${i.toString().padLeft(4, '0')}';
    list.add(fr('fr_$i', other, 'accepted', kPrimaryUserId, 10 + i));
  }
  // 2 incoming pending (they asked us)
  list.add(fr('fr_in_1', 'qq-user-0008', 'pending', 'qq-user-0008', 2));
  list.add(fr('fr_in_2', 'qq-user-0009', 'pending', 'qq-user-0009', 1));
  // 2 outgoing pending (we asked them)
  list.add(fr('fr_out_1', 'qq-user-0010', 'pending', kPrimaryUserId, 3));
  list.add(fr('fr_out_2', 'qq-user-0011', 'pending', kPrimaryUserId, 1));

  return list;
}

// =============================================================================
// Battle history for the primary user — 3 wins, 2 losses
// =============================================================================

List<Map<String, dynamic>> _mockBattleHistory() {
  final now = DateTime(2026, 6, 7);
  final list = <Map<String, dynamic>>[];

  Map<String, dynamic> battle(
    String id,
    String opponent,
    int myScore,
    int oppScore,
    int daysAgo,
  ) {
    final won = myScore > oppScore;
    final ended = now.subtract(Duration(days: daysAgo));
    return {
      'id': id,
      'challenger_id': kPrimaryUserId,
      'opponent_id': opponent,
      'challenger_score': myScore,
      'opponent_score': oppScore,
      'question_count': 20,
      'subject_filter': null,
      'status': 'completed',
      'winner_id': myScore == oppScore
          ? null
          : (won ? kPrimaryUserId : opponent),
      'questions_data': const [],
      'created_at': ended.subtract(const Duration(minutes: 6)).toIso8601String(),
      'started_at': ended.subtract(const Duration(minutes: 5)).toIso8601String(),
      'ended_at': ended.toIso8601String(),
    };
  }

  list.add(battle('bh_1', 'qq-user-0002', 17, 12, 1));
  list.add(battle('bh_2', 'qq-user-0003', 14, 9, 2));
  list.add(battle('bh_3', 'qq-user-0004', 11, 15, 4));
  list.add(battle('bh_5', 'qq-user-0006', 18, 16, 7));
  list.add(battle('bh_4', 'qq-user-0005', 8, 13, 6));
  return list;
}

// =============================================================================
// Task progress — ~30% of each subject completed, a few mastered
// =============================================================================

List<Map<String, dynamic>> _mockTaskProgress() {
  final now = DateTime(2026, 6, 7);
  final rows = <Map<String, dynamic>>[];
  final rng = math.Random(11);

  for (final subject in kCurriculum) {
    final nodes = subject.allNodes;
    final completeCount = (nodes.length * 0.30).round();
    for (var i = 0; i < completeCount; i++) {
      final node = nodes[i];
      // Most are simply completed; the first few are mastered (90%+).
      final mastered = i < (completeCount ~/ 3);
      final score = mastered ? 90 + rng.nextInt(11) : 60 + rng.nextInt(28);
      rows.add({
        'node_id': node.id,
        'subject_id': subject.id,
        'module_id': node.moduleId,
        'status': mastered ? 'mastered' : 'completed',
        'best_score': score,
        'attempts': 1 + rng.nextInt(2),
        'xp_earned': node.xpReward,
        'coins_earned': node.coinReward,
        'akyl_earned': node.akylReward,
        'completed_at':
            now.subtract(Duration(days: rng.nextInt(20))).toIso8601String(),
      });
    }
  }
  return rows;
}

// =============================================================================
// Achievements — 12 unlocked of 34
// =============================================================================

List<String> _mockUnlockedAchievements() {
  const unlocked = [
    'first_lesson',
    'ten_tasks',
    'fifty_tasks',
    'perfect_ten',
    'reach_level_10',
    'first_battle',
    'first_win',
    'ten_wins',
    'first_item',
    'first_friend',
    'five_friends',
    'streak_7',
  ];
  // Keep only ids that exist in the catalog (defensive).
  final valid = kAchievements.map((a) => a.id).toSet();
  return [for (final id in unlocked) if (valid.contains(id)) id];
}

// =============================================================================
// Inventory + equipment — Bektur wearing a few items
// =============================================================================

List<String> _mockInventory() => const [
      'top_school_jacket',
      'bottom_pants_school',
      'top_hoodie_blue',
      'top_chapan_gold',
      'bottom_jeans_blue',
      'hat_takiya_white',
      'hat_baseball_blue',
      'acc_sunglasses',
      'acc_headphones',
      'pet_white_cat',
      'pet_eagle',
    ];

Map<String, String> _mockEquipment() => const {
      'top': 'top_chapan_gold',
      'bottom': 'bottom_jeans_blue',
      'hat': 'hat_takiya_white',
      'pet': 'pet_eagle',
    };

// =============================================================================
// Tournaments — active, upcoming, completed
// =============================================================================

List<Map<String, dynamic>> _mockTournaments() {
  final now = DateTime(2026, 6, 7);
  Map<String, dynamic> t(
    String id,
    String title,
    String description,
    String status,
    int maxParticipants,
    int prizeCoins,
    int entryAkyl,
    DateTime start,
    DateTime? end,
  ) =>
      {
        'id': id,
        'title': title,
        'description': description,
        'status': status,
        'max_participants': maxParticipants,
        'prize_pool': {'coins': prizeCoins, 'entry_akyl': entryAkyl},
        'start_date': start.toIso8601String(),
        'end_date': end?.toIso8601String(),
      };

  return [
    t(
      'tour_active',
      '🏆 Жазғы Ұлы Турнир',
      'Барлық пәндер бойынша ашық турнир. Ең көп Ақыл ұпайын жинаған '
          'оқушы жеңеді!',
      'active',
      200,
      10000,
      50,
      now.subtract(const Duration(days: 2)),
      now.add(const Duration(days: 5)),
    ),
    t(
      'tour_upcoming',
      '➗ Математика чемпионаты',
      'Тек математика сүйер оқушыларға арналған апталық сайыс.',
      'upcoming',
      100,
      5000,
      30,
      now.add(const Duration(days: 4)),
      now.add(const Duration(days: 11)),
    ),
    t(
      'tour_done',
      '📖 Көктемгі Қазақ тілі марафоны',
      'Көктемде өткен тіл марафоны аяқталды. Нәтижелермен таныс!',
      'completed',
      150,
      4000,
      20,
      now.subtract(const Duration(days: 30)),
      now.subtract(const Duration(days: 23)),
    ),
  ];
}

Map<String, List<String>> _mockTournamentParticipants() {
  // Primary user is registered in the active + completed events.
  final everyone = [
    for (var i = 1; i <= 22; i++) 'qq-user-${i.toString().padLeft(4, '0')}',
  ];
  return {
    'tour_active': everyone.take(18).toList(),
    'tour_upcoming': everyone.skip(2).take(7).toList(),
    'tour_done': everyone.take(14).toList(),
  };
}
