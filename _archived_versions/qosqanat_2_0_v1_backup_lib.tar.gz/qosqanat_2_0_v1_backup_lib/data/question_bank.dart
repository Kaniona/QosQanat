/// Large, procedurally-built question banks — 1000+ genuinely correct
/// questions per subject. Numeric/computational items (math, physics,
/// informatics, number-spelling) have their answers computed so they are
/// always correct; language items draw from curated Kazakh/English word lists.
///
/// Each subject exposes a `final List<Question>` built once at startup. The
/// curriculum slices a unique window of these per map node, so nodes stop
/// repeating the same handful of questions.
library;

import '../models/question.dart';

// =============================================================================
// Builders / helpers
// =============================================================================

/// Multiple-choice from a known-correct string and candidate distractors.
/// Always yields exactly 4 distinct options; the correct slot is rotated by
/// [seed] so the answer isn't always in the same position.
Question _mcStr(
  String id,
  String prompt,
  String correct,
  List<String> distractors,
  int seed, {
  String explanation = '',
}) {
  final wrong = <String>[];
  for (final d in distractors) {
    if (d != correct && !wrong.contains(d)) wrong.add(d);
    if (wrong.length == 3) break;
  }
  var i = 0;
  while (wrong.length < 3) {
    final f = '$correct·${i++}';
    if (!wrong.contains(f)) wrong.add(f);
  }
  final all = [correct, wrong[0], wrong[1], wrong[2]];
  final idx = seed % 4;
  final rotated = [for (var j = 0; j < 4; j++) all[(j + idx) % 4]];
  return Question.mc(
    id: id,
    prompt: prompt,
    options: rotated,
    correctIndex: (4 - idx) % 4,
    explanation: explanation,
  );
}

/// Multiple-choice for an integer answer, with nearby-number distractors.
Question _mcInt(
  String id,
  String prompt,
  int ans, {
  String explanation = '',
  int minOpt = 0,
}) {
  final cand = [ans + 1, ans - 1, ans + 2, ans - 2, ans + 3, ans + 10, ans - 10, ans * 2];
  final wrong = <int>[];
  for (final c in cand) {
    if (c != ans && c >= minOpt && !wrong.contains(c)) wrong.add(c);
    if (wrong.length == 3) break;
  }
  var f = ans + 11;
  while (wrong.length < 3) {
    if (f != ans && f >= minOpt && !wrong.contains(f)) wrong.add(f);
    f++;
  }
  return _mcStr(id, prompt, '$ans', [for (final w in wrong) '$w'], ans.abs(),
      explanation: explanation);
}

// =============================================================================
// MATH  (~1100)
// =============================================================================

List<Question> _buildMath() {
  final q = <Question>[];
  var n = 0;
  String id() => 'mat_${n++}';

  // Addition
  for (var k = 0; k < 160; k++) {
    final a = 11 + (k % 80);
    final b = 13 + (k * 7) % 70;
    q.add(_mcInt(id(), '$a + $b = ?', a + b));
  }
  // Subtraction (a > b)
  for (var k = 0; k < 150; k++) {
    final a = 45 + (k % 55);
    final b = 5 + (k * 3) % 38;
    q.add(_mcInt(id(), '$a − $b = ?', a - b, minOpt: 0));
  }
  // Multiplication
  for (var k = 0; k < 170; k++) {
    final a = 2 + (k % 17);
    final b = 2 + (k * 4) % 11;
    q.add(_mcInt(id(), '$a × $b = ?', a * b, minOpt: 0));
  }
  // Division (exact)
  for (var k = 0; k < 150; k++) {
    final d = 2 + (k % 11);
    final qt = 2 + (k * 3) % 14;
    q.add(_mcInt(id(), '${d * qt} ÷ $d = ?', qt, minOpt: 0));
  }
  // Percent (base is a multiple of 20)
  for (var k = 0; k < 100; k++) {
    final base = 20 * (1 + (k % 30));
    final pct = const [5, 10, 25, 50][k % 4];
    q.add(_mcInt(id(), '$base санының $pct%-ы нешеге тең?', base * pct ~/ 100,
        minOpt: 0));
  }
  // Fraction add (same denominator)
  for (var k = 0; k < 80; k++) {
    final d = 5 + (k % 7);
    final a = 1 + (k % 2);
    final b = 1 + (k * 2) % 2;
    final s = a + b;
    q.add(_mcStr(id(), '$a/$d + $b/$d = ?', '$s/$d',
        ['${s + 1}/$d', '$s/${d + 1}', '${s - 1}/$d', '$s/${d * 2}'], k));
  }
  // Compare fractions (same denominator) — true/false
  for (var k = 0; k < 60; k++) {
    final d = 4 + (k % 8);
    final a = 1 + (k % (d - 1));
    final b = 1 + (k * 3) % (d - 1);
    q.add(Question.tf(
      id: id(),
      prompt: '$a/$d бөлшегі $b/$d бөлшегінен үлкен.',
      answerIsTrue: a > b,
    ));
  }
  // Rectangle perimeter
  for (var k = 0; k < 70; k++) {
    final a = 3 + (k % 20);
    final b = 4 + (k * 2) % 18;
    q.add(_mcInt(id(), 'Қабырғалары $a см және $b см тіктөртбұрыштың периметрі (см)?',
        2 * (a + b), minOpt: 0));
  }
  // Rectangle area
  for (var k = 0; k < 70; k++) {
    final a = 3 + (k % 18);
    final b = 2 + (k * 3) % 16;
    q.add(_mcInt(id(), 'Қабырғалары $a см және $b см тіктөртбұрыштың ауданы (см²)?',
        a * b, minOpt: 0));
  }
  // Even / odd
  for (var k = 0; k < 40; k++) {
    final v = 10 + k * 2 + (k % 2);
    q.add(Question.tf(id: id(), prompt: '$v — жұп сан.', answerIsTrue: v.isEven));
  }
  // Rounding to nearest ten
  for (var k = 0; k < 60; k++) {
    final v = 12 + k * 3;
    final r = ((v + 5) ~/ 10) * 10;
    q.add(_mcInt(id(), '$v санын ондыққа дейін дөңгелекте.', r, minOpt: 0));
  }
  return q;
}

// =============================================================================
// PHYSICS  (~1050)
// =============================================================================

const _physicsFacts = <Question>[
  Question.tf(id: 'phf_1', prompt: 'Дыбыс вакуумде таралмайды.', answerIsTrue: true),
  Question.tf(id: 'phf_2', prompt: 'Жарық дыбыстан жылдам тарайды.', answerIsTrue: true),
  Question.tf(id: 'phf_3', prompt: 'Су 0 °C-та қайнайды.', answerIsTrue: false, explanation: 'Су 100 °C-та қайнайды.'),
  Question.tf(id: 'phf_4', prompt: 'Массаны таразымен өлшейді.', answerIsTrue: true),
  Question.tf(id: 'phf_5', prompt: 'Күштің бірлігі — Ньютон.', answerIsTrue: true),
  Question.tf(id: 'phf_6', prompt: 'Жылдамдықтың бірлігі — килограмм.', answerIsTrue: false, explanation: 'Жылдамдық м/с-пен өлшенеді.'),
  Question.tf(id: 'phf_7', prompt: 'Гравитация — денелердің бір-бірін тарту құбылысы.', answerIsTrue: true),
  Question.tf(id: 'phf_8', prompt: 'Үйкеліс күші қозғалысқа кедергі жасайды.', answerIsTrue: true),
  Question.tf(id: 'phf_9', prompt: 'Мұз судан тығыз.', answerIsTrue: false, explanation: 'Мұз судан жеңіл, сондықтан жүзеді.'),
  Question.tf(id: 'phf_10', prompt: 'Электр тогын амперметрмен өлшейді.', answerIsTrue: true),
  Question.tf(id: 'phf_11', prompt: 'Температураны термометрмен өлшейді.', answerIsTrue: true),
  Question.tf(id: 'phf_12', prompt: 'Энергия жоқтан пайда болады.', answerIsTrue: false, explanation: 'Энергия сақталады, жоқтан пайда болмайды.'),
  Question.tf(id: 'phf_13', prompt: 'Магнит темірді тартады.', answerIsTrue: true),
  Question.tf(id: 'phf_14', prompt: 'Қуаттың бірлігі — Ватт.', answerIsTrue: true),
  Question.tf(id: 'phf_15', prompt: 'Жұмыстың бірлігі — Джоуль.', answerIsTrue: true),
  Question.tf(id: 'phf_16', prompt: 'Қысымның бірлігі — Паскаль.', answerIsTrue: true),
  Question.tf(id: 'phf_17', prompt: 'Жылу суық денеден ыстық денеге өздігінен өтеді.', answerIsTrue: false, explanation: 'Жылу ыстықтан суыққа өтеді.'),
  Question.tf(id: 'phf_18', prompt: 'Линза жарықты сындырады.', answerIsTrue: true),
  Question.tf(id: 'phf_19', prompt: 'Дыбыс — толқын.', answerIsTrue: true),
  Question.tf(id: 'phf_20', prompt: 'Қозғалмайтын дене инерцияда болады.', answerIsTrue: true),
  Question.tf(id: 'phf_21', prompt: 'Жердің тарту үдеуі шамамен 10 м/с².', answerIsTrue: true),
  Question.tf(id: 'phf_22', prompt: 'Көлемді сызғышпен өлшейді.', answerIsTrue: false, explanation: 'Көлемді мензуркамен немесе есеппен табады.'),
  Question.tf(id: 'phf_23', prompt: 'Электр заряды оң және теріс болады.', answerIsTrue: true),
  Question.tf(id: 'phf_24', prompt: 'Бірдей зарядтар бірін-бірі тартады.', answerIsTrue: false, explanation: 'Бірдей зарядтар тебіледі.'),
  Question.tf(id: 'phf_25', prompt: 'Қатты дененің пішіні тұрақты.', answerIsTrue: true),
  Question.tf(id: 'phf_26', prompt: 'Газ берілген ыдыстың бүкіл көлемін алады.', answerIsTrue: true),
  Question.tf(id: 'phf_27', prompt: 'Айна жарықты шағылыстырады.', answerIsTrue: true),
  Question.tf(id: 'phf_28', prompt: 'Уақыттың бірлігі — метр.', answerIsTrue: false, explanation: 'Уақыт секундпен өлшенеді.'),
  Question.tf(id: 'phf_29', prompt: 'Жылдамдық = жол ÷ уақыт.', answerIsTrue: true),
  Question.tf(id: 'phf_30', prompt: 'Тығыздық = масса ÷ көлем.', answerIsTrue: true),
];

List<Question> _buildPhysics() {
  final q = <Question>[];
  var n = 0;
  String id() => 'phy_${n++}';

  // F = m·a
  for (var k = 0; k < 150; k++) {
    final m = 2 + (k % 18);
    final a = 2 + (k * 3) % 9;
    q.add(_mcInt(id(), 'Массасы $m кг дене $a м/с² үдеумен қозғалады. Күш (Н)?',
        m * a, minOpt: 0));
  }
  // v = s / t
  for (var k = 0; k < 150; k++) {
    final t = 2 + (k % 9);
    final v = 3 + (k * 2) % 18;
    q.add(_mcInt(id(), 'Дене $t секундта ${v * t} м жол жүрді. Жылдамдығы (м/с)?',
        v, minOpt: 0));
  }
  // ρ = m / V
  for (var k = 0; k < 130; k++) {
    final vol = 2 + (k % 9);
    final rho = 2 + (k * 3) % 8;
    q.add(_mcInt(id(), 'Массасы ${vol * rho} кг, көлемі $vol м³ дененің тығыздығы (кг/м³)?',
        rho, minOpt: 0));
  }
  // P = F / S
  for (var k = 0; k < 120; k++) {
    final s = 2 + (k % 6);
    final p = 5 + (k * 2) % 20;
    q.add(_mcInt(id(), 'Ауданы $s м² бетке ${p * s} Н күш әсер етеді. Қысым (Па)?',
        p, minOpt: 0));
  }
  // A = F · s
  for (var k = 0; k < 120; k++) {
    final f = 5 + (k % 20);
    final s = 2 + (k * 2) % 15;
    q.add(_mcInt(id(), '$f Н күш денені $s м жылжытты. Жұмыс (Дж)?', f * s,
        minOpt: 0));
  }
  // P = m·g  (g = 10)
  for (var k = 0; k < 120; k++) {
    final m = 1 + (k % 40);
    q.add(_mcInt(id(), 'Массасы $m кг дененің салмағы (Н, g=10)?', m * 10,
        minOpt: 0));
  }
  // U = I·R
  for (var k = 0; k < 130; k++) {
    final i = 1 + (k % 9);
    final r = 2 + (k * 3) % 30;
    q.add(_mcInt(id(), 'Ток күші $i А, кедергі $r Ом. Кернеу (В)?', i * r,
        minOpt: 0));
  }
  // Power P = A / t
  for (var k = 0; k < 100; k++) {
    final t = 2 + (k % 8);
    final p = 5 + (k * 2) % 25;
    q.add(_mcInt(id(), '$t секундта ${p * t} Дж жұмыс істелді. Қуат (Вт)?', p,
        minOpt: 0));
  }
  // Facts
  q.addAll(_physicsFacts);
  return q;
}

// =============================================================================
// INFORMATICS  (~1020)
// =============================================================================

const _infoFacts = <Question>[
  Question.tf(id: 'inf_f1', prompt: '1 байт = 8 бит.', answerIsTrue: true),
  Question.tf(id: 'inf_f2', prompt: 'Процессор — компьютердің «миы».', answerIsTrue: true),
  Question.tf(id: 'inf_f3', prompt: 'Бір құпиясөзді барлық аккаунтқа қою қауіпсіз.', answerIsTrue: false),
  Question.tf(id: 'inf_f4', prompt: 'Python — бағдарламалау тілі.', answerIsTrue: true),
  Question.tf(id: 'inf_f5', prompt: 'RAM — жедел жады.', answerIsTrue: true),
  Question.tf(id: 'inf_f6', prompt: 'Wi-Fi — сымсыз интернет технологиясы.', answerIsTrue: true),
  Question.tf(id: 'inf_f7', prompt: 'Монитор ақпаратты енгізу құрылғысы.', answerIsTrue: false, explanation: 'Монитор — шығару құрылғысы.'),
  Question.tf(id: 'inf_f8', prompt: 'Пернетақта — енгізу құрылғысы.', answerIsTrue: true),
  Question.tf(id: 'inf_f9', prompt: 'Алгоритм — әрекеттердің реттелген тізбегі.', answerIsTrue: true),
  Question.tf(id: 'inf_f10', prompt: 'HTML — веб-беттерді белгілеу тілі.', answerIsTrue: true),
  Question.tf(id: 'inf_f11', prompt: 'Файлды сақтау үшін «Сақтау» батырмасын басады.', answerIsTrue: true),
  Question.tf(id: 'inf_f12', prompt: 'Вирус — пайдалы бағдарлама.', answerIsTrue: false),
  Question.tf(id: 'inf_f13', prompt: '1 КБ = 1024 байт.', answerIsTrue: true),
  Question.tf(id: 'inf_f14', prompt: 'CPU — орталық процессор.', answerIsTrue: true),
  Question.tf(id: 'inf_f15', prompt: 'Принтер дыбыс шығарады.', answerIsTrue: false, explanation: 'Принтер қағазға басады.'),
  Question.tf(id: 'inf_f16', prompt: 'Бұлтты сақтау деректі интернетте сақтайды.', answerIsTrue: true),
  Question.tf(id: 'inf_f17', prompt: 'Цикл — қайталанатын әрекет.', answerIsTrue: true),
  Question.tf(id: 'inf_f18', prompt: 'Курсорды тінтуір басқарады.', answerIsTrue: true),
  Question.tf(id: 'inf_f19', prompt: 'Екілік санау жүйесінде тек 0 мен 1 қолданылады.', answerIsTrue: true),
  Question.tf(id: 'inf_f20', prompt: 'AI — жасанды интеллект.', answerIsTrue: true),
];

List<Question> _buildInformatics() {
  final q = <Question>[];
  var n = 0;
  String id() => 'ifm_${n++}';

  // Bits in N bytes
  for (var k = 0; k < 150; k++) {
    final b = 1 + (k % 50);
    q.add(_mcInt(id(), '$b байт неше бит?', b * 8, minOpt: 0));
  }
  // Bytes in N KB
  for (var k = 0; k < 120; k++) {
    final kb = 1 + (k % 40);
    q.add(_mcInt(id(), '$kb КБ неше байт?', kb * 1024, minOpt: 0));
  }
  // KB in N MB
  for (var k = 0; k < 100; k++) {
    final mb = 1 + (k % 30);
    q.add(_mcInt(id(), '$mb МБ неше КБ?', mb * 1024, minOpt: 0));
  }
  // Decimal -> binary
  for (var k = 0; k < 200; k++) {
    final v = 1 + k;
    final bin = v.toRadixString(2);
    q.add(_mcStr(
      id(),
      '$v ондық санын екілік жүйеге аудар.',
      bin,
      [
        (v + 1).toRadixString(2),
        (v - 1).toRadixString(2),
        (v + 2).toRadixString(2),
      ],
      v,
    ));
  }
  // Binary -> decimal
  for (var k = 0; k < 200; k++) {
    final v = 1 + k;
    final bin = v.toRadixString(2);
    q.add(_mcInt(id(), '$bin₂ екілік санының ондық мәні?', v, minOpt: 0));
  }
  // Powers of two
  for (var k = 0; k < 80; k++) {
    final e = 1 + (k % 12);
    q.add(_mcInt(id(), '2 санының $e дәрежесі (2^$e) неге тең?', 1 << e,
        minOpt: 0));
  }
  // Boolean logic
  for (var k = 0; k < 150; k++) {
    final a = (k ~/ 2) % 2;
    final b = k % 2;
    final op = k % 3;
    final (label, res) = switch (op) {
      0 => ('AND', (a == 1 && b == 1) ? 1 : 0),
      1 => ('OR', (a == 1 || b == 1) ? 1 : 0),
      _ => ('XOR', (a != b) ? 1 : 0),
    };
    q.add(_mcStr(id(), '$a $label $b = ?', '$res', ['${1 - res}', '2', '—'], k));
  }
  // Facts
  q.addAll(_infoFacts);
  return q;
}

// =============================================================================
// Number spelling helpers (1..100)
// =============================================================================

const _enOnes = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
const _enTeens = ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
const _enTens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

String _enNum(int v) {
  if (v == 100) return 'one hundred';
  if (v < 10) return _enOnes[v];
  if (v < 20) return _enTeens[v - 10];
  final t = v ~/ 10, u = v % 10;
  return u == 0 ? _enTens[t] : '${_enTens[t]}-${_enOnes[u]}';
}

const _kzOnes = ['', 'бір', 'екі', 'үш', 'төрт', 'бес', 'алты', 'жеті', 'сегіз', 'тоғыз'];
const _kzTens = ['', 'он', 'жиырма', 'отыз', 'қырық', 'елу', 'алпыс', 'жетпіс', 'сексен', 'тоқсан'];

String _kzNum(int v) {
  if (v == 100) return 'жүз';
  if (v < 10) return _kzOnes[v];
  final t = v ~/ 10, u = v % 10;
  return u == 0 ? _kzTens[t] : '${_kzTens[t]} ${_kzOnes[u]}';
}

// =============================================================================
// ENGLISH  (~1030)
// =============================================================================

const _enPairs = <List<String>>[
  ['алма', 'apple'], ['кітап', 'book'], ['мектеп', 'school'], ['су', 'water'],
  ['ит', 'dog'], ['мысық', 'cat'], ['үй', 'house'], ['ағаш', 'tree'],
  ['күн', 'sun'], ['ай', 'moon'], ['жұлдыз', 'star'], ['гүл', 'flower'],
  ['бала', 'child'], ['ана', 'mother'], ['әке', 'father'], ['дос', 'friend'],
  ['ұстаз', 'teacher'], ['қалам', 'pen'], ['үстел', 'table'], ['орындық', 'chair'],
  ['есік', 'door'], ['терезе', 'window'], ['жол', 'road'], ['қала', 'city'],
  ['ел', 'country'], ['тау', 'mountain'], ['өзен', 'river'], ['теңіз', 'sea'],
  ['аспан', 'sky'], ['жер', 'earth'], ['от', 'fire'], ['жел', 'wind'],
  ['қар', 'snow'], ['жаңбыр', 'rain'], ['нан', 'bread'], ['сүт', 'milk'],
  ['ет', 'meat'], ['балық', 'fish'], ['жұмыртқа', 'egg'], ['май', 'butter'],
  ['алмұрт', 'pear'], ['жүзім', 'grape'], ['қарбыз', 'watermelon'], ['сәбіз', 'carrot'],
  ['пияз', 'onion'], ['картоп', 'potato'], ['ат', 'horse'], ['сиыр', 'cow'],
  ['қой', 'sheep'], ['түйе', 'camel'], ['аю', 'bear'], ['қасқыр', 'wolf'],
  ['түлкі', 'fox'], ['қоян', 'rabbit'], ['құс', 'bird'], ['ара', 'bee'],
  ['көбелек', 'butterfly'], ['жылан', 'snake'], ['піл', 'elephant'], ['арыстан', 'lion'],
  ['қол', 'hand'], ['аяқ', 'foot'], ['бас', 'head'], ['көз', 'eye'],
  ['құлақ', 'ear'], ['мұрын', 'nose'], ['ауыз', 'mouth'], ['тіс', 'tooth'],
  ['шаш', 'hair'], ['жүрек', 'heart'], ['қызыл', 'red'], ['көк', 'blue'],
  ['сары', 'yellow'], ['жасыл', 'green'], ['ақ', 'white'], ['қара', 'black'],
  ['үлкен', 'big'], ['кіші', 'small'], ['ұзын', 'long'], ['қысқа', 'short'],
  ['жылы', 'warm'], ['суық', 'cold'], ['жаңа', 'new'], ['ескі', 'old'],
  ['жақсы', 'good'], ['жаман', 'bad'], ['жылдам', 'fast'], ['баяу', 'slow'],
  ['бақытты', 'happy'], ['мұңды', 'sad'], ['аш', 'hungry'], ['шаршаған', 'tired'],
  ['жүгіру', 'run'], ['жүру', 'walk'], ['оқу', 'read'], ['жазу', 'write'],
  ['ойнау', 'play'], ['ұйықтау', 'sleep'], ['жеу', 'eat'], ['ішу', 'drink'],
  ['көру', 'see'], ['есту', 'hear'], ['сөйлеу', 'speak'], ['ән айту', 'sing'],
  ['би билеу', 'dance'], ['секіру', 'jump'], ['ұшу', 'fly'], ['жүзу', 'swim'],
  ['дүйсенбі', 'Monday'], ['сейсенбі', 'Tuesday'], ['сәрсенбі', 'Wednesday'],
  ['бейсенбі', 'Thursday'], ['жұма', 'Friday'], ['сенбі', 'Saturday'], ['жексенбі', 'Sunday'],
  ['қысы', 'winter'], ['жазы', 'summer'], ['көктем', 'spring'], ['күз', 'autumn'],
  ['таң', 'morning'], ['түс', 'noon'], ['кеш', 'evening'], ['түн', 'night'],
];

const _enOpposites = <List<String>>[
  ['big', 'small'], ['hot', 'cold'], ['good', 'bad'], ['fast', 'slow'],
  ['new', 'old'], ['long', 'short'], ['happy', 'sad'], ['open', 'closed'],
  ['up', 'down'], ['day', 'night'], ['black', 'white'], ['high', 'low'],
  ['rich', 'poor'], ['easy', 'hard'], ['full', 'empty'], ['clean', 'dirty'],
  ['young', 'old'], ['near', 'far'], ['wet', 'dry'], ['strong', 'weak'],
  ['light', 'dark'], ['first', 'last'], ['right', 'wrong'], ['true', 'false'],
];

const _enVerbs = ['play', 'read', 'write', 'run', 'eat', 'walk', 'sing', 'jump', 'swim', 'work', 'sleep', 'cook'];

List<Question> _buildEnglish() {
  final q = <Question>[];
  var n = 0;
  String id() => 'eng_${n++}';
  final allEn = [for (final p in _enPairs) p[1]];
  final allKz = [for (final p in _enPairs) p[0]];

  // Number spelling, both directions (1..100)
  for (var v = 1; v <= 100; v++) {
    q.add(_mcStr(id(), '$v санын ағылшынша қалай жазамыз?', _enNum(v),
        [_enNum(v + 1 > 100 ? v - 2 : v + 1), _enNum(v < 3 ? v + 2 : v - 1), _enNum(v < 50 ? v + 10 : v - 10)], v));
  }
  for (var v = 1; v <= 100; v++) {
    q.add(_mcInt(id(), '«${_enNum(v)}» — қай сан?', v, minOpt: 0));
  }
  // Vocab kz -> en
  for (var i = 0; i < _enPairs.length; i++) {
    final p = _enPairs[i];
    q.add(_mcStr(id(), '«${p[0]}» ағылшынша қалай?', p[1],
        [allEn[(i + 1) % allEn.length], allEn[(i + 7) % allEn.length], allEn[(i + 13) % allEn.length]], i));
  }
  // Vocab en -> kz
  for (var i = 0; i < _enPairs.length; i++) {
    final p = _enPairs[i];
    q.add(_mcStr(id(), '«${p[1]}» қазақша қалай?', p[0],
        [allKz[(i + 2) % allKz.length], allKz[(i + 9) % allKz.length], allKz[(i + 17) % allKz.length]], i + 1));
  }
  // True / false translation
  for (var i = 0; i < _enPairs.length; i++) {
    final p = _enPairs[i];
    final shown = (i % 2 == 0) ? p[0] : allKz[(i + 5) % allKz.length];
    q.add(Question.tf(
      id: id(),
      prompt: '«${p[1]}» сөзі «$shown» дегенді білдіреді.',
      answerIsTrue: shown == p[0],
    ));
  }
  // Plurals (regular + s)
  const plnouns = ['cat', 'dog', 'book', 'pen', 'table', 'star', 'bird', 'tree', 'house', 'car', 'apple', 'door', 'window', 'friend', 'flower', 'river', 'hand', 'eye', 'school', 'road'];
  for (var k = 0; k < 60; k++) {
    final w = plnouns[k % plnouns.length];
    q.add(_mcStr(id(), '«$w» сөзінің көпше түрі?', '${w}s',
        ['${w}es', w, '${w}ies'], k));
  }
  // am / is / are
  const subj = [['I', 'am'], ['He', 'is'], ['She', 'is'], ['It', 'is'], ['We', 'are'], ['You', 'are'], ['They', 'are']];
  for (var k = 0; k < 105; k++) {
    final s = subj[k % subj.length];
    const role = ['a student', 'happy', 'here', 'tall', 'ready', 'tired', 'busy'];
    q.add(_mcStr(id(), '${s[0]} ___ ${role[k % role.length]}.', s[1], ['am', 'is', 'are', 'be'], k));
  }
  // Colors
  const colors = [['қызыл', 'red'], ['көк', 'blue'], ['сары', 'yellow'], ['жасыл', 'green'], ['ақ', 'white'], ['қара', 'black'], ['қоңыр', 'brown'], ['сұр', 'grey']];
  for (var k = 0; k < 40; k++) {
    final c = colors[k % colors.length];
    q.add(_mcStr(id(), '«${c[0]}» түсі ағылшынша?', c[1],
        [for (final x in colors) x[1]]..removeWhere((e) => e == c[1]), k));
  }
  // Opposites
  for (var i = 0; i < _enOpposites.length; i++) {
    final o = _enOpposites[i];
    q.add(_mcStr(id(), 'What is the opposite of «${o[0]}»?', o[1],
        [for (final x in _enOpposites) x[1]]..removeWhere((e) => e == o[1]), i));
    q.add(_mcStr(id(), 'What is the opposite of «${o[1]}»?', o[0],
        [for (final x in _enOpposites) x[0]]..removeWhere((e) => e == o[0]), i + 1));
  }
  // Articles a / an
  for (var i = 0; i < _enPairs.length && i < 80; i++) {
    final w = _enPairs[i][1];
    final vowel = 'aeiou'.contains(w[0].toLowerCase());
    q.add(_mcStr(id(), 'Choose the article: ___ $w', vowel ? 'an' : 'a',
        ['a', 'an', 'the', 'some'], i));
  }
  // Present simple (he/she + verb + s)
  for (var k = 0; k < 100; k++) {
    final v = _enVerbs[k % _enVerbs.length];
    final subj2 = const ['He', 'She', 'It'][k % 3];
    q.add(_mcStr(id(), '$subj2 ___ every day.', '${v}s', [v, '${v}ed', '${v}ing'], k));
  }
  return q;
}

// =============================================================================
// KAZAKH  (~1040)
// =============================================================================

const _kzVowels = {'а', 'ә', 'е', 'ё', 'и', 'о', 'ө', 'у', 'ұ', 'ү', 'ы', 'і', 'э', 'ю', 'я'};

const _kazWords = <String>[
  'кітап', 'мектеп', 'бала', 'ағаш', 'дала', 'қала', 'ауыл', 'үстел', 'орындық',
  'терезе', 'есік', 'қалам', 'дәптер', 'мұғалім', 'оқушы', 'дос', 'ана', 'әке',
  'ата', 'әже', 'күн', 'түн', 'аспан', 'жұлдыз', 'бұлт', 'жаңбыр', 'қар', 'жел',
  'тау', 'өзен', 'көл', 'теңіз', 'орман', 'гүл', 'шөп', 'жапырақ', 'жеміс', 'алма',
  'алмұрт', 'қарбыз', 'жүзім', 'сәбіз', 'пияз', 'нан', 'сүт', 'ет', 'балық', 'жұмыртқа',
  'ат', 'сиыр', 'қой', 'ешкі', 'түйе', 'жылқы', 'тауық', 'үйрек', 'қаз', 'ит',
  'мысық', 'аю', 'қасқыр', 'түлкі', 'қоян', 'тиін', 'құс', 'қарға', 'торғай', 'бүркіт',
  'ара', 'көбелек', 'құмырсқа', 'жылан', 'бақа', 'балапан', 'қозы', 'бота', 'құлын', 'лақ',
  'қол', 'аяқ', 'бас', 'көз', 'құлақ', 'мұрын', 'ауыз', 'тіс', 'шаш', 'жүрек',
  'саусақ', 'тізе', 'иық', 'маңдай', 'бет', 'дауыс', 'сөз', 'тіл', 'хат', 'кесте',
  'дөңгелек', 'доп', 'ойыншық', 'сурет', 'бояу', 'қайшы', 'желім', 'сызғыш', 'өшіргіш', 'қаламсап',
  'жол', 'көпір', 'үй', 'там', 'қора', 'бау', 'бақша', 'егін', 'диқан', 'малшы',
  'дәрігер', 'ұшқыш', 'аспаз', 'әнші', 'биші', 'батыр', 'ханым', 'жыршы', 'күйші', 'ақын',
];

const _kzPos = <List<String>>[
  ['үстел', 'Зат есім'], ['кітап', 'Зат есім'], ['мектеп', 'Зат есім'], ['бала', 'Зат есім'],
  ['ағаш', 'Зат есім'], ['су', 'Зат есім'], ['тау', 'Зат есім'], ['гүл', 'Зат есім'],
  ['дала', 'Зат есім'], ['дос', 'Зат есім'], ['ана', 'Зат есім'], ['қалам', 'Зат есім'],
  ['есік', 'Зат есім'], ['жол', 'Зат есім'], ['қала', 'Зат есім'], ['нан', 'Зат есім'],
  ['ат', 'Зат есім'], ['құс', 'Зат есім'], ['аспан', 'Зат есім'], ['жұлдыз', 'Зат есім'],
  ['әдемі', 'Сын есім'], ['үлкен', 'Сын есім'], ['кіші', 'Сын есім'], ['биік', 'Сын есім'],
  ['аласа', 'Сын есім'], ['жылы', 'Сын есім'], ['суық', 'Сын есім'], ['жақсы', 'Сын есім'],
  ['жаман', 'Сын есім'], ['қызыл', 'Сын есім'], ['қара', 'Сын есім'], ['ұзын', 'Сын есім'],
  ['қысқа', 'Сын есім'], ['кең', 'Сын есім'], ['тәтті', 'Сын есім'], ['дәмді', 'Сын есім'],
  ['жүгіру', 'Етістік'], ['жазу', 'Етістік'], ['оқу', 'Етістік'], ['келу', 'Етістік'],
  ['кету', 'Етістік'], ['бару', 'Етістік'], ['отыру', 'Етістік'], ['ұйықтау', 'Етістік'],
  ['ойнау', 'Етістік'], ['жеу', 'Етістік'], ['ішу', 'Етістік'], ['көру', 'Етістік'],
  ['есту', 'Етістік'], ['сөйлеу', 'Етістік'], ['күлу', 'Етістік'], ['секіру', 'Етістік'],
  ['жүзу', 'Етістік'], ['ұшу', 'Етістік'], ['тұру', 'Етістік'], ['жылау', 'Етістік'],
  ['бір', 'Сан есім'], ['екі', 'Сан есім'], ['үш', 'Сан есім'], ['төрт', 'Сан есім'],
  ['бес', 'Сан есім'], ['алты', 'Сан есім'], ['жеті', 'Сан есім'], ['сегіз', 'Сан есім'],
  ['тоғыз', 'Сан есім'], ['он', 'Сан есім'], ['жүз', 'Сан есім'], ['мың', 'Сан есім'],
  ['мен', 'Есімдік'], ['сен', 'Есімдік'], ['ол', 'Есімдік'], ['біз', 'Есімдік'],
  ['бұл', 'Есімдік'], ['осы', 'Есімдік'], ['сол', 'Есімдік'], ['кім', 'Есімдік'],
  ['не', 'Есімдік'], ['тез', 'Үстеу'], ['жай', 'Үстеу'], ['бүгін', 'Үстеу'],
  ['ертең', 'Үстеу'], ['кеше', 'Үстеу'], ['қазір', 'Үстеу'], ['кейде', 'Үстеу'],
];

const _kzSyn = <List<String>>[
  ['батыр', 'ер'], ['қуаныш', 'шаттық'], ['үлкен', 'ірі'], ['әдемі', 'сұлу'],
  ['ақылды', 'дана'], ['жылдам', 'шапшаң'], ['достық', 'татулық'], ['жол', 'сапар'],
  ['күшті', 'мықты'], ['бай', 'дәулетті'], ['мұң', 'қайғы'], ['той', 'мереке'],
  ['ұстаз', 'мұғалім'], ['жау', 'дұшпан'], ['ел', 'халық'], ['сөз', 'лебіз'],
  ['еңбек', 'жұмыс'], ['дәрі', 'ем'], ['ниет', 'тілек'], ['мақтаныш', 'абырой'],
  ['сараң', 'сық'], ['айбынды', 'айбатты'], ['елес', 'көлеңке'], ['нұр', 'сәуле'],
];

const _kzAnt = <List<String>>[
  ['үлкен', 'кіші'], ['ыстық', 'суық'], ['ақ', 'қара'], ['биік', 'аласа'],
  ['жақсы', 'жаман'], ['ұзын', 'қысқа'], ['бай', 'кедей'], ['күндіз', 'түн'],
  ['жаз', 'қыс'], ['оң', 'сол'], ['алыс', 'жақын'], ['көп', 'аз'],
  ['ашық', 'жабық'], ['жаңа', 'ескі'], ['тез', 'баяу'], ['жоғары', 'төмен'],
  ['кең', 'тар'], ['ауыр', 'жеңіл'], ['ерте', 'кеш'], ['қатты', 'жұмсақ'],
  ['тоқ', 'аш'], ['келу', 'кету'], ['ыстық', 'мұздай'], ['батыл', 'қорқақ'],
];

const _kzLetters = ['а', 'ә', 'б', 'в', 'г', 'ғ', 'д', 'е', 'ж', 'з', 'и', 'й', 'к', 'қ', 'л', 'м', 'н', 'ң', 'о', 'ө', 'п', 'р', 'с', 'т', 'у', 'ұ', 'ү', 'ф', 'х', 'һ', 'ц', 'ч', 'ш', 'щ', 'ы', 'і', 'э', 'ю', 'я'];
const _kzHardV = {'а', 'о', 'ұ', 'ы', 'у'};
const _kzSoftV = {'ә', 'е', 'ө', 'ү', 'і', 'и'};

int _syllables(String w) =>
    w.runes.where((r) => _kzVowels.contains(String.fromCharCode(r))).length;

List<Question> _buildKazakh() {
  final q = <Question>[];
  var n = 0;
  String id() => 'kaz_${n++}';

  // Number spelling, both directions
  for (var v = 1; v <= 100; v++) {
    q.add(_mcStr(id(), '$v санын сөзбен қалай жазамыз?', _kzNum(v),
        [_kzNum(v < 99 ? v + 1 : v - 2), _kzNum(v < 3 ? v + 2 : v - 1), _kzNum(v < 50 ? v + 10 : v - 10)], v));
  }
  for (var v = 1; v <= 100; v++) {
    q.add(_mcInt(id(), '«${_kzNum(v)}» — қай сан?', v, minOpt: 0));
  }
  // Syllable count (= vowel count)
  for (var i = 0; i < _kazWords.length && i < 150; i++) {
    final w = _kazWords[i];
    q.add(_mcInt(id(), '«$w» сөзінде неше буын бар?', _syllables(w), minOpt: 1));
  }
  // Letter count
  for (var i = 0; i < _kazWords.length && i < 100; i++) {
    final w = _kazWords[i];
    q.add(_mcInt(id(), '«$w» сөзінде неше әріп бар?', w.runes.length, minOpt: 1));
  }
  // First sound vowel?
  for (var i = 0; i < _kazWords.length && i < 100; i++) {
    final w = _kazWords[i];
    final first = String.fromCharCode(w.runes.first);
    q.add(Question.tf(
      id: id(),
      prompt: '«$w» сөзі дауысты дыбыстан басталады.',
      answerIsTrue: _kzVowels.contains(first),
    ));
  }
  // Last sound vowel?
  for (var i = 0; i < _kazWords.length; i++) {
    final w = _kazWords[i];
    final last = String.fromCharCode(w.runes.last);
    q.add(Question.tf(
      id: id(),
      prompt: '«$w» сөзі дауысты дыбысқа аяқталады.',
      answerIsTrue: _kzVowels.contains(last),
    ));
  }
  // Consonant count (= letters − vowels)
  for (var i = 0; i < _kazWords.length; i++) {
    final w = _kazWords[i];
    q.add(_mcInt(id(), '«$w» сөзінде неше дауыссыз дыбыс бар?',
        w.runes.length - _syllables(w), minOpt: 0));
  }
  // Part of speech
  const cats = ['Зат есім', 'Сын есім', 'Етістік', 'Сан есім', 'Есімдік', 'Үстеу'];
  for (var i = 0; i < _kzPos.length; i++) {
    final p = _kzPos[i];
    q.add(_mcStr(id(), '«${p[0]}» — қай сөз табы?', p[1],
        [for (final c in cats) c]..removeWhere((c) => c == p[1]), i));
  }
  // Synonyms (both directions)
  for (var i = 0; i < _kzSyn.length; i++) {
    final s = _kzSyn[i];
    q.add(_mcStr(id(), '«${s[0]}» сөзінің синонимі қайсы?', s[1],
        [for (final x in _kzSyn) x[1]]..removeWhere((e) => e == s[1]), i));
    q.add(_mcStr(id(), '«${s[1]}» сөзінің синонимі қайсы?', s[0],
        [for (final x in _kzSyn) x[0]]..removeWhere((e) => e == s[0]), i + 1));
  }
  // Antonyms (both directions)
  for (var i = 0; i < _kzAnt.length; i++) {
    final a = _kzAnt[i];
    q.add(_mcStr(id(), '«${a[0]}» сөзінің антонимі қайсы?', a[1],
        [for (final x in _kzAnt) x[1]]..removeWhere((e) => e == a[1]), i));
    q.add(_mcStr(id(), '«${a[1]}» сөзінің антонимі қайсы?', a[0],
        [for (final x in _kzAnt) x[0]]..removeWhere((e) => e == a[0]), i + 1));
  }
  // Letter: vowel or consonant?
  for (var i = 0; i < _kzLetters.length; i++) {
    final l = _kzLetters[i];
    q.add(Question.tf(
      id: id(),
      prompt: '«$l» — дауысты дыбыс.',
      answerIsTrue: _kzVowels.contains(l),
    ));
  }
  // Hard / soft vowels
  for (final v in [..._kzHardV, ..._kzSoftV]) {
    q.add(_mcStr(id(), '«$v» дауыстысы қандай?', _kzHardV.contains(v) ? 'Жуан' : 'Жіңішке',
        ['Жуан', 'Жіңішке', 'Дауыссыз', 'Үнді'], v.codeUnitAt(0)));
  }
  return q;
}

// =============================================================================
// Public banks
// =============================================================================

final List<Question> mathBank = _buildMath();
final List<Question> physicsBank = _buildPhysics();
final List<Question> informaticsBank = _buildInformatics();
final List<Question> englishBank = _buildEnglish();
final List<Question> kazakhBank = _buildKazakh();
