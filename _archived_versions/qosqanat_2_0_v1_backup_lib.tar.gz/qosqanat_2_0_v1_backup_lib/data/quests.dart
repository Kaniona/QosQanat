/// Daily quest pool and streak milestones for QosQanat 2.0.
library;

/// The kind of action a quest tracks. The game engine increments quest
/// progress by matching events to a [QuestKind].
enum QuestKind {
  login,
  completeTasks,
  perfectTask,
  doBattle,
  winBattle,
  purchase,
  addFriend,
}

/// Template for a daily quest. Concrete per-day instances (with progress and
/// claim state) are stored in the `daily_quests` table as [Quest] models.
class QuestTemplate {
  final String id;
  final String title;
  final String description;
  final String emoji;
  final QuestKind kind;
  final int target;
  final int xpReward;
  final int coinReward;

  const QuestTemplate({
    required this.id,
    required this.title,
    required this.description,
    required this.emoji,
    required this.kind,
    required this.target,
    required this.xpReward,
    required this.coinReward,
  });
}

/// The full pool of daily quests.
const List<QuestTemplate> kDailyQuestPool = [
  QuestTemplate(
    id: 'daily_login',
    title: 'Күнделікті кіру',
    description: 'Қосымшаға кір',
    emoji: '🌅',
    kind: QuestKind.login,
    target: 1,
    xpReward: 10,
    coinReward: 20,
  ),
  QuestTemplate(
    id: 'one_task',
    title: 'Бір тапсырма',
    description: '1 тапсырманы орында',
    emoji: '✏️',
    kind: QuestKind.completeTasks,
    target: 1,
    xpReward: 20,
    coinReward: 15,
  ),
  QuestTemplate(
    id: 'three_tasks',
    title: 'Үш тапсырма',
    description: '3 тапсырманы орында',
    emoji: '📚',
    kind: QuestKind.completeTasks,
    target: 3,
    xpReward: 50,
    coinReward: 40,
  ),
  QuestTemplate(
    id: 'five_tasks',
    title: 'Бес тапсырма',
    description: '5 тапсырманы орында',
    emoji: '🎯',
    kind: QuestKind.completeTasks,
    target: 5,
    xpReward: 90,
    coinReward: 70,
  ),
  QuestTemplate(
    id: 'perfect_task',
    title: 'Мінсіз орындау',
    description: 'Тапсырманы 100%-бен аяқта',
    emoji: '💯',
    kind: QuestKind.perfectTask,
    target: 1,
    xpReward: 40,
    coinReward: 30,
  ),
  QuestTemplate(
    id: 'do_battle',
    title: 'Шайқасқа қатыс',
    description: 'Ақыл шайқасына қатыс',
    emoji: '⚔️',
    kind: QuestKind.doBattle,
    target: 1,
    xpReward: 30,
    coinReward: 25,
  ),
  QuestTemplate(
    id: 'win_battle',
    title: 'Жеңіске жет',
    description: 'Ақыл шайқасында жең',
    emoji: '🏆',
    kind: QuestKind.winBattle,
    target: 1,
    xpReward: 60,
    coinReward: 50,
  ),
  QuestTemplate(
    id: 'make_purchase',
    title: 'Дүкенге бар',
    description: 'Дүкеннен зат сатып ал',
    emoji: '🛍️',
    kind: QuestKind.purchase,
    target: 1,
    xpReward: 20,
    coinReward: 10,
  ),
  QuestTemplate(
    id: 'add_friend',
    title: 'Жаңа дос',
    description: 'Жаңа дос қос',
    emoji: '🤝',
    kind: QuestKind.addFriend,
    target: 1,
    xpReward: 25,
    coinReward: 20,
  ),
];

/// Streak length → coin reward granted exactly when that streak is reached.
const Map<int, int> kStreakMilestones = {
  3: 50,
  7: 150,
  14: 300,
  30: 1000,
  60: 2500,
  100: 5000,
};

/// Coin reward for hitting a streak of exactly [streak] days, or `null` if
/// [streak] is not a milestone.
int? streakMilestoneReward(int streak) => kStreakMilestones[streak];
