/// QosQanat curriculum: five subjects, each with grade modules of 15–20 nodes,
/// each node carrying 8–12 mixed-type Kazakh questions drawn from the subject's
/// real question pool.
///
/// NOTE: node questions are sampled from a per-subject pool of real questions so
/// the full ascending map is playable today. Expanding each node to a unique
/// hand-authored set is pure data entry — the engine already supports it.
library;

import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';
import '../models/enums.dart';
import '../models/question.dart';
import 'question_bank.dart';

// =============================================================================
// Models
// =============================================================================

class CurriculumNode {
  final String id;
  final String subjectId;
  final int grade;
  final String moduleId;
  final String title;
  final String description;
  final NodeType type;
  final int order; // global order within the subject
  final int xpReward;
  final int coinReward;
  final int akylReward;
  final List<Question> questions;

  const CurriculumNode({
    required this.id,
    required this.subjectId,
    required this.grade,
    required this.moduleId,
    required this.title,
    required this.description,
    required this.type,
    required this.order,
    required this.xpReward,
    required this.coinReward,
    required this.akylReward,
    required this.questions,
  });
}

class GradeModule {
  final String id;
  final int grade;
  final String title;
  final List<CurriculumNode> nodes;

  const GradeModule({
    required this.id,
    required this.grade,
    required this.title,
    required this.nodes,
  });
}

class Subject {
  final String id;
  final String name;
  final String description;
  final IconData icon;
  final Color color;
  final LinearGradient cardGradient;

  /// Bottom→top map backdrop gradient (steppe gold → subject sky → cosmic top).
  final LinearGradient mapGradient;
  final List<GradeModule> modules;

  const Subject({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    required this.color,
    required this.cardGradient,
    required this.mapGradient,
    required this.modules,
  });

  /// All nodes flattened across modules, in ascending order.
  List<CurriculumNode> get allNodes =>
      [for (final m in modules) ...m.nodes];

  int get totalNodes => allNodes.length;
}

// =============================================================================
// Module builder
// =============================================================================

NodeType _typeForIndex(int index, int count) {
  final isLast = index == count - 1;
  if (isLast) return NodeType.boss; // module finale guardian
  if ((index + 1) % 5 == 0) return NodeType.quiz;
  if (index == 3 || (index + 1) % 8 == 0) return NodeType.treasure;
  return NodeType.lesson;
}

String _descForType(NodeType type) {
  switch (type) {
    case NodeType.lesson:
      return 'Жаңа тақырыппен танысып, дағдыңды бекіт.';
    case NodeType.quiz:
      return 'Біліміңді сынап көр — жылдам сынақ!';
    case NodeType.boss:
      return 'Модуль боссы! Барлық білгеніңді көрсет.';
    case NodeType.treasure:
      return 'Жасырын қазына — бонус сыйлықтар сені күтеді.';
  }
}

List<Question> _sample(List<Question> pool, int start, int count) {
  if (pool.isEmpty) return const [];
  return [for (var i = 0; i < count; i++) pool[(start + i) % pool.length]];
}

GradeModule _buildModule({
  required String subjectId,
  required int grade,
  required String moduleTitle,
  required List<String> topics,
  required List<Question> pool,
  required int orderOffset,
}) {
  final moduleId = '${subjectId}_g$grade';
  final nodes = <CurriculumNode>[];

  for (var i = 0; i < topics.length; i++) {
    final type = _typeForIndex(i, topics.length);
    final order = orderOffset + i;
    final qCount = 8 + (i % 5); // 8–12 questions
    // Each node gets its own non-overlapping window into the large subject
    // bank, so no two nodes repeat the same set of questions.
    final questions = _sample(pool, order * 12, qCount.clamp(8, 12));

    final isBoss = type == NodeType.boss;
    final isTreasure = type == NodeType.treasure;

    nodes.add(CurriculumNode(
      id: '${moduleId}_n$i',
      subjectId: subjectId,
      grade: grade,
      moduleId: moduleId,
      title: topics[i],
      description: _descForType(type),
      type: type,
      order: order,
      xpReward: 30 + order * 2 + (isBoss ? 40 : 0),
      coinReward: 15 + order + (isTreasure ? 40 : 0) + (isBoss ? 20 : 0),
      akylReward: isBoss ? 20 : (type == NodeType.quiz ? 8 : 3),
      questions: questions,
    ));
  }

  return GradeModule(
    id: moduleId,
    grade: grade,
    title: moduleTitle,
    nodes: nodes,
  );
}

// =============================================================================
// Topic lists
// =============================================================================

const _infoG5 = [
  'Компьютермен танысу', 'Компьютердің бөліктері', 'Пернетақта', 'Тінтуір',
  'Файлдар мен бумалар', 'Мәтін теру', 'Сурет салу', 'Интернет деген не',
  'Қауіпсіз интернет', 'Құпиясөз құпиясы', 'Электрондық пошта', 'Смартфон әлемі',
  'Kaspi.kz және цифрлық қызметтер', 'Жасанды интеллект', 'Python-мен танысу',
  '5-сынып емтиханы',
];
const _infoG6 = [
  'Алгоритм деген не', 'Блок-схема', 'Қайталау циклі', 'Шарт операторы',
  'Айнымалылар', 'Python: алғашқы бағдарлама', 'Python: сандармен жұмыс',
  'Python: мәтінмен жұмыс', 'Интернет тарихы', 'Әлеуметтік желі этикеті',
  'Деректер қауіпсіздігі', 'Графика және дизайн', 'Презентация жасау',
  'Электрондық кесте', 'Робототехника негіздері', '6-сынып емтиханы',
];
const _mathG5 = [
  'Натурал сандар', 'Қосу және азайту', 'Көбейту', 'Бөлу', 'Разрядтар',
  'Жай сандар', 'Бөлгіштер мен еселіктер', 'Жай бөлшектер', 'Ондық бөлшектер',
  'Геометриялық фигуралар', 'Бұрыштар', 'Периметр', 'Аудан', 'Шамалар',
  'Есептер шығару', '5-сынып емтиханы',
];
const _mathG6 = [
  'Бөлгіштік белгілері', 'ЕҮОБ және ЕКОЕ', 'Жай бөлшектерді қосу', 'Аралас сан',
  'Қатынас', 'Пропорция', 'Пайыз', 'Теріс сандар', 'Координаталық түзу',
  'Бүтін сандарды қосу', 'Координаталық жазықтық', 'Теңдеулер', 'Диаграммалар',
  'Симметрия', 'Логикалық есептер', '6-сынып емтиханы',
];
const _engG5 = [
  'Greetings', 'The Alphabet', 'Numbers 1–10', 'Colours', 'My Family',
  'Animals', 'Food', 'School Things', 'Days of the Week', 'My Body',
  'Clothes', 'Weather', 'Hobbies', 'At Home', 'Kazakhstan & the World',
  'Unit 5 Test',
];
const _kazG5 = [
  'Әліпби', 'Дауысты дыбыстар', 'Дауыссыз дыбыстар', 'Буын', 'Үнді дыбыстар',
  'Зат есім', 'Сын есім', 'Етістік', 'Есімдік', 'Сан есім',
  'Көптік жалғау', 'Тәуелдік жалғау', 'Септік жалғаулар', 'Жұрнақ',
  'Сөйлем құрау', '5-сынып емтиханы',
];
const _kazG6 = [
  'Сөз құрамы', 'Түбір сөз', 'Туынды сөз', 'Күрделі сөз',
  'Антоним сөздер', 'Синоним сөздер', 'Омоним сөздер', 'Сын есім шырайлары',
  'Етістік шақтары', 'Бұйрық рай', 'Шартты рай', 'Үстеу',
  'Шылау', 'Сөйлем мүшелері', 'Бастауыш пен баяндауыш', 'Тыныс белгілер',
  '6-сынып емтиханы',
];
const _engG6 = [
  'Present Simple', 'Present Continuous', 'Past Simple', 'Future with going to',
  'Articles a / an / the', 'Plural nouns', 'Adjectives', 'Adverbs',
  'Prepositions of place', 'Have got / has got', 'Can / Can\'t',
  'Countable & uncountable', 'Asking questions', 'Daily routine',
  'My city', 'Famous places of Kazakhstan', 'Unit 6 Test',
];
const _phyG7 = [
  'Физика деген не', 'Денелер мен заттар', 'Зат күйлері', 'Өлшеу',
  'Масса', 'Көлем', 'Тығыздық', 'Күш', 'Гравитация',
  'Үйкеліс күші', 'Серпімділік күші', 'Қысым', 'Жылдамдық',
  'Бірқалыпты қозғалыс', 'Энергия', 'Дыбыс', '7-сынып емтиханы',
];
const _phyG8 = [
  'Жылулық құбылыстары', 'Температура', 'Жылу мөлшері', 'Балқу мен қату',
  'Булану мен конденсация', 'Электр заряды', 'Электр тоғы', 'Тізбек',
  'Ом заңы', 'Кедергі', 'Жұмыс пен қуат', 'Магнетизм',
  'Жарық құбылыстары', 'Линза', 'Айна', '8-сынып емтиханы',
];

// =============================================================================
// Curriculum
// =============================================================================

final List<Subject> kCurriculum = [
  Subject(
    id: 'math',
    name: 'Математика',
    description: 'Сандар, бөлшектер, геометрия',
    icon: Icons.calculate_rounded,
    color: AppColors.eagleBlue,
    cardGradient: AppColors.eagle,
    mapGradient: const LinearGradient(
      begin: Alignment.bottomCenter,
      end: Alignment.topCenter,
      colors: [AppColors.steppeGoldLight, AppColors.eagleBlue, AppColors.cosmicPurpleDark],
    ),
    modules: [
      _buildModule(
        subjectId: 'math',
        grade: 5,
        moduleTitle: '5-сынып',
        topics: _mathG5,
        pool: mathBank,
        orderOffset: 0,
      ),
      _buildModule(
        subjectId: 'math',
        grade: 6,
        moduleTitle: '6-сынып',
        topics: _mathG6,
        pool: mathBank,
        orderOffset: _mathG5.length,
      ),
    ],
  ),
  Subject(
    id: 'kazakh',
    name: 'Қазақ тілі',
    description: 'Дыбыстар, сөз таптары, сөйлем',
    icon: Icons.menu_book_rounded,
    color: AppColors.jade,
    cardGradient: const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [AppColors.jadeLight, AppColors.jade],
    ),
    mapGradient: const LinearGradient(
      begin: Alignment.bottomCenter,
      end: Alignment.topCenter,
      colors: [AppColors.steppeGoldLight, AppColors.jade, AppColors.cosmicPurpleDark],
    ),
    modules: [
      _buildModule(
        subjectId: 'kazakh',
        grade: 5,
        moduleTitle: '5-сынып',
        topics: _kazG5,
        pool: kazakhBank,
        orderOffset: 0,
      ),
      _buildModule(
        subjectId: 'kazakh',
        grade: 6,
        moduleTitle: '6-сынып',
        topics: _kazG6,
        pool: kazakhBank,
        orderOffset: _kazG5.length,
      ),
    ],
  ),
  Subject(
    id: 'english',
    name: 'Ағылшын тілі',
    description: 'Words, grammar, conversation',
    icon: Icons.language_rounded,
    color: AppColors.steppeGold,
    cardGradient: AppColors.goldSoar,
    mapGradient: const LinearGradient(
      begin: Alignment.bottomCenter,
      end: Alignment.topCenter,
      colors: [AppColors.steppeGoldLight, AppColors.steppeGold, AppColors.cosmicPurpleDark],
    ),
    modules: [
      _buildModule(
        subjectId: 'english',
        grade: 5,
        moduleTitle: '5-сынып',
        topics: _engG5,
        pool: englishBank,
        orderOffset: 0,
      ),
      _buildModule(
        subjectId: 'english',
        grade: 6,
        moduleTitle: '6-сынып',
        topics: _engG6,
        pool: englishBank,
        orderOffset: _engG5.length,
      ),
    ],
  ),
  Subject(
    id: 'physics',
    name: 'Физика',
    description: 'Күш, энергия, қозғалыс',
    icon: Icons.science_rounded,
    color: AppColors.coral,
    cardGradient: const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [AppColors.sunset, AppColors.coral],
    ),
    mapGradient: const LinearGradient(
      begin: Alignment.bottomCenter,
      end: Alignment.topCenter,
      colors: [AppColors.steppeGoldLight, AppColors.coral, AppColors.cosmicPurpleDark],
    ),
    modules: [
      _buildModule(
        subjectId: 'physics',
        grade: 7,
        moduleTitle: '7-сынып',
        topics: _phyG7,
        pool: physicsBank,
        orderOffset: 0,
      ),
      _buildModule(
        subjectId: 'physics',
        grade: 8,
        moduleTitle: '8-сынып',
        topics: _phyG8,
        pool: physicsBank,
        orderOffset: _phyG7.length,
      ),
    ],
  ),
  Subject(
    id: 'informatics',
    name: 'Информатика',
    description: 'Компьютер, интернет, Python, AI',
    icon: Icons.computer_rounded,
    color: AppColors.cosmicPurple,
    cardGradient: AppColors.cosmicNight,
    mapGradient: const LinearGradient(
      begin: Alignment.bottomCenter,
      end: Alignment.topCenter,
      colors: [AppColors.steppeGoldLight, AppColors.cosmicPurple, AppColors.nightInk],
    ),
    modules: [
      _buildModule(
        subjectId: 'informatics',
        grade: 5,
        moduleTitle: '5-сынып',
        topics: _infoG5,
        pool: informaticsBank,
        orderOffset: 0,
      ),
      _buildModule(
        subjectId: 'informatics',
        grade: 6,
        moduleTitle: '6-сынып',
        topics: _infoG6,
        pool: informaticsBank,
        orderOffset: _infoG5.length,
      ),
    ],
  ),
];

Subject? subjectById(String id) {
  for (final s in kCurriculum) {
    if (s.id == id) return s;
  }
  return null;
}

/// The grade module of [subject] for a given school [grade], or null if the
/// subject has no content for that grade yet.
GradeModule? moduleForGrade(Subject subject, int grade) {
  for (final m in subject.modules) {
    if (m.grade == grade) return m;
  }
  return null;
}
