/// Named route paths for go_router. Centralized to avoid stringly-typed
/// navigation scattered across the app.
class AppRoutes {
  AppRoutes._();

  static const String splash = '/';
  static const String welcome = '/welcome';
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';
  static const String assistantSelection = '/assistant-selection';
  static const String home = '/home';
  static const String newsDetail = '/news';
  static const String learn = '/learn';
  static const String shop = '/shop';
  static const String rating = '/rating';
  static const String profile = '/profile';
  static const String friends = '/friends';
  static const String battle = '/battle';
  static const String tournament = '/tournament';
  static const String settings = '/settings';
}
