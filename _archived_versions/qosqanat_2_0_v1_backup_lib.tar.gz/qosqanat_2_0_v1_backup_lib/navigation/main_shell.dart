import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../core/theme/app_colors.dart';
import '../providers/game_provider.dart';
import '../providers/onboarding_provider.dart';
import '../screens/onboarding/tutorial_keys.dart';
import '../screens/onboarding/tutorial_overlay.dart';
import '../widgets/game/level_up_modal.dart';
import '../widgets/ui/app_drawer.dart';
import '../widgets/ui/app_tab_bar.dart';

/// The persistent app shell: the five-tab bottom bar, the left side drawer, a
/// global level-up celebration listener, and the first-run tutorial.
///
/// Wraps a [StatefulNavigationShell] so each tab keeps its own navigation state
/// (IndexedStack under the hood). Tab indices: 0 Home, 1 Rating, 2 Learn,
/// 3 Shop, 4 Profile.
class MainShell extends ConsumerStatefulWidget {
  final StatefulNavigationShell navigationShell;

  const MainShell({super.key, required this.navigationShell});

  /// Active shell, so descendants (e.g. the HUD profile photo) can switch tabs
  /// without prop-drilling the [StatefulNavigationShell].
  static MainShellState? _active;

  /// Switches the visible bottom tab. Tapping the current tab pops it to root.
  static void goToBranch(int index) {
    final shell = _active?.widget.navigationShell;
    if (shell == null) return;
    shell.goBranch(index, initialLocation: index == shell.currentIndex);
  }

  @override
  ConsumerState<MainShell> createState() => MainShellState();
}

class MainShellState extends ConsumerState<MainShell> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _levelUpVisible = false;

  @override
  void initState() {
    super.initState();
    MainShell._active = this;
  }

  @override
  void dispose() {
    if (MainShell._active == this) MainShell._active = null;
    super.dispose();
  }

  void _onTap(int index) {
    widget.navigationShell.goBranch(
      index,
      initialLocation: index == widget.navigationShell.currentIndex,
    );
  }

  /// Shows the level-up modal once per event, then clears the flag.
  void _handleLevelUp(LevelUpEvent event) {
    if (_levelUpVisible) return;
    _levelUpVisible = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      await showLevelUpModal(
        context,
        newLevel: event.newLevel,
        title: event.title,
        coinReward: event.coinReward,
      );
      _levelUpVisible = false;
      ref.read(gameProvider.notifier).clearCelebrations();
    });
  }

  @override
  Widget build(BuildContext context) {
    // Global level-up celebration: any screen that adds XP triggers it here.
    ref.listen<GameState>(gameProvider, (prev, next) {
      final event = next.pendingLevelUp;
      if (event != null) _handleLevelUp(event);
    });

    final tutorialSeen = ref.watch(tutorialSeenProvider);
    final onHome = widget.navigationShell.currentIndex == 0;
    final showTutorial = !tutorialSeen && onHome;

    return Stack(
      children: [
        Scaffold(
          key: _scaffoldKey,
          backgroundColor: AppColors.background,
          drawer: const AppDrawer(),
          body: Stack(
            children: [
              widget.navigationShell,
              _DrawerEdgeHandle(
                key: TutorialKeys.drawerHandle,
                onTap: () => _scaffoldKey.currentState?.openDrawer(),
              ),
            ],
          ),
          bottomNavigationBar: AppTabBar(
            currentIndex: widget.navigationShell.currentIndex,
            onTap: _onTap,
            items: [
              const AppTabItem(icon: Icons.home_rounded, label: 'Басты бет'),
              const AppTabItem(
                icon: Icons.leaderboard_rounded,
                label: 'Рейтинг',
              ),
              AppTabItem(
                icon: Icons.school_rounded,
                label: 'Оқу',
                raised: true,
                spotlightKey: TutorialKeys.learnTab,
              ),
              AppTabItem(
                icon: Icons.storefront_rounded,
                label: 'Shop',
                spotlightKey: TutorialKeys.shopTab,
              ),
              const AppTabItem(
                icon: Icons.person_rounded,
                label: 'Профиль',
              ),
            ],
          ),
        ),
        if (showTutorial)
          Positioned.fill(
            child: TutorialOverlay(
              onFinish: () =>
                  ref.read(tutorialSeenProvider.notifier).markTutorialSeen(),
            ),
          ),
      ],
    );
  }
}

/// A subtle left-edge handle hinting at the side drawer (Турнир/Достар/
/// Баптаулар). Tapping or swiping right opens it; it also anchors the tutorial
/// spotlight for the drawer step.
class _DrawerEdgeHandle extends StatelessWidget {
  final VoidCallback onTap;

  const _DrawerEdgeHandle({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: 0,
      top: 0,
      bottom: 0,
      width: 22,
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: onTap,
        onHorizontalDragEnd: (details) {
          if ((details.primaryVelocity ?? 0) > 0) onTap();
        },
        child: Center(
          child: Container(
            width: 5,
            height: 56,
            decoration: const BoxDecoration(
              color: AppColors.border,
              borderRadius: BorderRadius.horizontal(right: Radius.circular(999)),
            ),
          ),
        ),
      ),
    );
  }
}
