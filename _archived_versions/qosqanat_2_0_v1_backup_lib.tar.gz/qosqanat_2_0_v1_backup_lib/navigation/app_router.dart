import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../models/news_item.dart';
import '../models/tournament.dart';
import '../screens/auth/assistant_selection_screen.dart';
import '../screens/auth/forgot_password_screen.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import '../screens/auth/splash_screen.dart';
import '../screens/auth/welcome_screen.dart';
import '../screens/battle/battle_result_screen.dart';
import '../screens/battle/battle_screen.dart';
import '../screens/battle/battle_setup_screen.dart';
import '../screens/battle/battle_waiting_screen.dart';
import '../screens/friends/friends_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/home/news_detail_screen.dart';
import '../screens/learn/learn_screen.dart';
import '../screens/learn/map_screen.dart';
import '../screens/learn/result_screen.dart';
import '../screens/learn/subject_grades_screen.dart';
import '../screens/learn/task_screen.dart';
import '../screens/profile/profile_screen.dart';
import '../screens/profile/settings_screen.dart';
import '../screens/rating/rating_screen.dart';
import '../screens/shop/shop_screen.dart';
import '../screens/tournament/tournament_detail_screen.dart';
import '../screens/tournament/tournament_screen.dart';
import '../core/constants/app_config.dart';
import '../services/api_service.dart';
import '../services/offline_service.dart';
import 'app_routes.dart';
import 'main_shell.dart';

/// Locations reachable without an authenticated session. Everything else
/// requires a Supabase session and redirects to [AppRoutes.welcome].
const _publicRoutes = <String>{
  AppRoutes.splash,
  AppRoutes.welcome,
  AppRoutes.login,
  AppRoutes.register,
  AppRoutes.forgotPassword,
};

final _rootNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'root');
final _homeNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'home');
final _ratingNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'rating');
final _learnNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'learn');
final _shopNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'shop');
final _profileNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'profile');

/// Application router. Boots on the splash screen, gates protected routes behind
/// auth, and hosts the five-tab [MainShell] with modal routes layered over it.
class AppRouter {
  AppRouter._();

  static final GoRouter router = GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: AppConfig.demoMode ? AppRoutes.home : AppRoutes.splash,
    refreshListenable: _GoRouterAuthRefresh(),
    redirect: (context, state) {
      // Demo mode bypasses the auth gate entirely.
      if (AppConfig.demoMode) return null;
      final loggedIn = OfflineService.isAuthenticated;
      final isPublic = _publicRoutes.contains(state.matchedLocation);
      if (!loggedIn && !isPublic) return AppRoutes.welcome;
      return null;
    },
    routes: [
      // -----------------------------------------------------------------------
      // Auth flow (root navigator)
      // -----------------------------------------------------------------------
      GoRoute(
        path: AppRoutes.splash,
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: AppRoutes.welcome,
        builder: (context, state) => const WelcomeScreen(),
      ),
      GoRoute(
        path: AppRoutes.login,
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: AppRoutes.register,
        builder: (context, state) => const RegisterScreen(),
      ),
      GoRoute(
        path: AppRoutes.forgotPassword,
        builder: (context, state) => const ForgotPasswordScreen(),
      ),
      GoRoute(
        path: AppRoutes.assistantSelection,
        builder: (context, state) => const AssistantSelectionScreen(),
      ),

      // -----------------------------------------------------------------------
      // Main shell — five bottom tabs, each with its own navigation stack.
      // -----------------------------------------------------------------------
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) =>
            MainShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(
            navigatorKey: _homeNavigatorKey,
            routes: [
              GoRoute(
                path: AppRoutes.home,
                builder: (context, state) => const HomeScreen(),
              ),
            ],
          ),
          StatefulShellBranch(
            navigatorKey: _ratingNavigatorKey,
            routes: [
              GoRoute(
                path: AppRoutes.rating,
                builder: (context, state) => const RatingScreen(),
              ),
            ],
          ),
          StatefulShellBranch(
            navigatorKey: _learnNavigatorKey,
            routes: [
              GoRoute(
                path: AppRoutes.learn,
                builder: (context, state) => const LearnScreen(),
              ),
            ],
          ),
          StatefulShellBranch(
            navigatorKey: _shopNavigatorKey,
            routes: [
              GoRoute(
                path: AppRoutes.shop,
                builder: (context, state) => const ShopScreen(),
              ),
            ],
          ),
          StatefulShellBranch(
            navigatorKey: _profileNavigatorKey,
            routes: [
              GoRoute(
                path: AppRoutes.profile,
                builder: (context, state) => const ProfileScreen(),
              ),
            ],
          ),
        ],
      ),

      // -----------------------------------------------------------------------
      // Modal / full-screen routes over the shell (root navigator)
      // -----------------------------------------------------------------------
      GoRoute(
        path: AppRoutes.newsDetail,
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) =>
            NewsDetailScreen(item: state.extra! as NewsItem),
      ),
      GoRoute(
        path: '${AppRoutes.learn}/result',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => ResultScreen(
          payload: ResultPayload.fromMap(state.extra! as Map<String, dynamic>),
        ),
      ),
      GoRoute(
        path: '${AppRoutes.learn}/task/:nodeId',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) =>
            TaskScreen(nodeId: state.pathParameters['nodeId']!),
      ),
      GoRoute(
        path: '${AppRoutes.learn}/:subjectId',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) =>
            SubjectGradesScreen(subjectId: state.pathParameters['subjectId']!),
      ),
      GoRoute(
        path: '${AppRoutes.learn}/:subjectId/:grade',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => MapScreen(
          subjectId: state.pathParameters['subjectId']!,
          grade: int.tryParse(state.pathParameters['grade'] ?? ''),
        ),
      ),
      GoRoute(
        path: '/battle/setup',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) =>
            BattleSetupScreen(opponent: state.extra! as FriendUser),
      ),
      GoRoute(
        path: '/battle/waiting',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) {
          final m = state.extra! as Map<String, dynamic>;
          return BattleWaitingScreen(
            battleId: m['battleId'] as String,
            opponent: m['opponent'] as FriendUser,
            isChallenger: (m['isChallenger'] as bool?) ?? true,
          );
        },
      ),
      GoRoute(
        path: '/battle/play',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) {
          final m = state.extra! as Map<String, dynamic>;
          return BattleScreen(
            battleId: m['battleId'] as String,
            opponent: m['opponent'] as FriendUser,
            isChallenger: m['isChallenger'] as bool,
          );
        },
      ),
      GoRoute(
        path: '/battle/result',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) {
          final m = state.extra! as Map<String, dynamic>;
          return BattleResultScreen(
            battleId: m['battleId'] as String,
            opponent: m['opponent'] as FriendUser,
            isChallenger: m['isChallenger'] as bool,
          );
        },
      ),
      GoRoute(
        path: AppRoutes.friends,
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const FriendsScreen(),
      ),
      GoRoute(
        path: AppRoutes.tournament,
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const TournamentScreen(),
      ),
      GoRoute(
        path: '${AppRoutes.tournament}/:id',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) =>
            TournamentDetailScreen(tournament: state.extra! as Tournament),
      ),
      GoRoute(
        path: AppRoutes.settings,
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const SettingsScreen(),
      ),
    ],
  );
}

/// Bridges offline auth-state changes to a [Listenable] so go_router can
/// re-evaluate its redirect when the session changes.
class _GoRouterAuthRefresh extends ChangeNotifier {
  late final StreamSubscription<void> _sub;

  _GoRouterAuthRefresh() {
    _sub = OfflineService.onAuthChanged.listen((_) {
      notifyListeners();
    });
  }

  @override
  void dispose() {
    _sub.cancel();
    super.dispose();
  }
}
