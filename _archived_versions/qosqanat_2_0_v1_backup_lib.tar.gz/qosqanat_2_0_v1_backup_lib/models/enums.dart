/// Shared enums for QosQanat 2.0 domain models.
///
/// Each enum provides JSON-safe serialization via [wireValue] and a
/// `fromWire` factory so persistence stays decoupled from enum ordering.
library;

/// The student's chosen AI study companion.
enum AssistantType {
  bektur, // 14yo boy, energetic, blue theme
  nazym; // 14yo girl, kind, rose theme

  String get wireValue => name;

  static AssistantType fromWire(String? value) {
    return AssistantType.values.firstWhere(
      (e) => e.wireValue == value,
      orElse: () => AssistantType.bektur,
    );
  }
}

/// Node types on the Duolingo-style learning map.
enum NodeType {
  lesson,
  quiz,
  boss,
  treasure;

  String get wireValue => name;

  static NodeType fromWire(String? value) {
    return NodeType.values.firstWhere(
      (e) => e.wireValue == value,
      orElse: () => NodeType.lesson,
    );
  }
}

/// Categories of purchasable shop items used to dress up the assistant.
///
/// `clothing` is retained for backwards compatibility with rows written before
/// the catalog was split into [top] / [bottom]; new items use the precise tab.
enum ItemCategory {
  clothing,
  top,
  bottom,
  hat,
  accessory,
  pet,
  background;

  String get wireValue => name;

  static ItemCategory fromWire(String? value) {
    return ItemCategory.values.firstWhere(
      (e) => e.wireValue == value,
      orElse: () => ItemCategory.clothing,
    );
  }
}

/// Rarity tiers for shop items, achievements, and rewards.
enum Rarity {
  common,
  rare,
  epic,
  legendary,
  mythic;

  String get wireValue => name;

  static Rarity fromWire(String? value) {
    return Rarity.values.firstWhere(
      (e) => e.wireValue == value,
      orElse: () => Rarity.common,
    );
  }
}

/// Progress/status of a node, quest, or battle.
enum NodeStatus {
  locked,
  available,
  inProgress,
  completed;

  String get wireValue => name;

  static NodeStatus fromWire(String? value) {
    return NodeStatus.values.firstWhere(
      (e) => e.wireValue == value,
      orElse: () => NodeStatus.locked,
    );
  }
}

/// Lifecycle state of a 1v1 Akyl battle.
///
/// Wire strings come from the Supabase `battles.status` column and use a
/// slightly different vocabulary than the Flutter enum so the SQL stays
/// expressive (`pending` vs. `accepted`, etc). The two are kept in sync via
/// [fromWire] / [wireValue] — never use [name] directly for persistence.
enum BattleStatus {
  waiting('pending'),
  active('in_progress'),
  finished('completed'),
  cancelled('cancelled');

  final String wireValue;
  const BattleStatus(this.wireValue);

  static BattleStatus fromWire(String? value) {
    if (value == null) return BattleStatus.waiting;
    // 'accepted' is a short-lived intermediate that the client treats as live.
    if (value == 'accepted') return BattleStatus.active;
    for (final e in BattleStatus.values) {
      if (e.wireValue == value) return e;
    }
    return BattleStatus.waiting;
  }
}

/// Lifecycle state of a tournament. Wire values map to the Supabase
/// `tournaments.status` column.
enum TournamentStatus {
  upcoming('upcoming'),
  registration('registration'),
  active('active'),
  finished('completed');

  final String wireValue;
  const TournamentStatus(this.wireValue);

  static TournamentStatus fromWire(String? value) {
    if (value == null) return TournamentStatus.upcoming;
    for (final e in TournamentStatus.values) {
      if (e.wireValue == value) return e;
    }
    return TournamentStatus.upcoming;
  }
}
