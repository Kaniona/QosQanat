import 'enums.dart';

/// Immutable QosQanat student profile.
///
/// Mirrors the `users` table in Supabase. Use [copyWith] for updates and
/// [fromJson]/[toJson] for (de)serialization.
class AppUser {
  final String id;
  final String qosqanatId;
  final String fullName;
  final String? phone;
  final String? iin;
  final String? city;
  final String? school;
  final int? grade;
  final AssistantType assistantType;
  final String? profilePhotoUrl;
  final int level;
  final int xp;
  final int coins;
  final int akylPoints;
  final int currentStreak;
  final int longestStreak;
  final int totalTasksCompleted;
  final int totalBattlesWon;
  final DateTime createdAt;

  const AppUser({
    required this.id,
    required this.qosqanatId,
    required this.fullName,
    this.phone,
    this.iin,
    this.city,
    this.school,
    this.grade,
    this.assistantType = AssistantType.bektur,
    this.profilePhotoUrl,
    this.level = 1,
    this.xp = 0,
    this.coins = 0,
    this.akylPoints = 0,
    this.currentStreak = 0,
    this.longestStreak = 0,
    this.totalTasksCompleted = 0,
    this.totalBattlesWon = 0,
    required this.createdAt,
  });

  factory AppUser.fromJson(Map<String, dynamic> json) {
    return AppUser(
      id: json['id'] as String,
      qosqanatId: json['qosqanat_id'] as String? ?? '',
      fullName: json['full_name'] as String? ?? '',
      phone: json['phone'] as String?,
      iin: json['iin'] as String?,
      city: json['city'] as String?,
      school: json['school'] as String?,
      grade: (json['grade'] as num?)?.toInt(),
      assistantType: AssistantType.fromWire(json['assistant_type'] as String?),
      profilePhotoUrl: json['profile_photo_url'] as String?,
      level: (json['level'] as num?)?.toInt() ?? 1,
      xp: (json['xp'] as num?)?.toInt() ?? 0,
      coins: (json['coins'] as num?)?.toInt() ?? 0,
      akylPoints: (json['akyl_points'] as num?)?.toInt() ?? 0,
      currentStreak: (json['current_streak'] as num?)?.toInt() ?? 0,
      longestStreak: (json['longest_streak'] as num?)?.toInt() ?? 0,
      totalTasksCompleted:
          (json['total_tasks_completed'] as num?)?.toInt() ?? 0,
      totalBattlesWon: (json['total_battles_won'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.tryParse(json['created_at'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'qosqanat_id': qosqanatId,
      'full_name': fullName,
      'phone': phone,
      'iin': iin,
      'city': city,
      'school': school,
      'grade': grade,
      'assistant_type': assistantType.wireValue,
      'profile_photo_url': profilePhotoUrl,
      'level': level,
      'xp': xp,
      'coins': coins,
      'akyl_points': akylPoints,
      'current_streak': currentStreak,
      'longest_streak': longestStreak,
      'total_tasks_completed': totalTasksCompleted,
      'total_battles_won': totalBattlesWon,
      'created_at': createdAt.toIso8601String(),
    };
  }

  AppUser copyWith({
    String? id,
    String? qosqanatId,
    String? fullName,
    String? phone,
    String? iin,
    String? city,
    String? school,
    int? grade,
    AssistantType? assistantType,
    String? profilePhotoUrl,
    int? level,
    int? xp,
    int? coins,
    int? akylPoints,
    int? currentStreak,
    int? longestStreak,
    int? totalTasksCompleted,
    int? totalBattlesWon,
    DateTime? createdAt,
  }) {
    return AppUser(
      id: id ?? this.id,
      qosqanatId: qosqanatId ?? this.qosqanatId,
      fullName: fullName ?? this.fullName,
      phone: phone ?? this.phone,
      iin: iin ?? this.iin,
      city: city ?? this.city,
      school: school ?? this.school,
      grade: grade ?? this.grade,
      assistantType: assistantType ?? this.assistantType,
      profilePhotoUrl: profilePhotoUrl ?? this.profilePhotoUrl,
      level: level ?? this.level,
      xp: xp ?? this.xp,
      coins: coins ?? this.coins,
      akylPoints: akylPoints ?? this.akylPoints,
      currentStreak: currentStreak ?? this.currentStreak,
      longestStreak: longestStreak ?? this.longestStreak,
      totalTasksCompleted: totalTasksCompleted ?? this.totalTasksCompleted,
      totalBattlesWon: totalBattlesWon ?? this.totalBattlesWon,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is AppUser && other.id == id);

  @override
  int get hashCode => id.hashCode;
}
