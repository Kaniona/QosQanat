/// An admin-posted announcement card shown in the Home news feed.
class NewsItem {
  final String id;
  final String title;
  final String body;
  final String? imageUrl;
  final String? category;
  final String? authorName;
  final bool isPinned;
  final DateTime publishedAt;

  const NewsItem({
    required this.id,
    required this.title,
    required this.body,
    this.imageUrl,
    this.category,
    this.authorName,
    this.isPinned = false,
    required this.publishedAt,
  });

  factory NewsItem.fromJson(Map<String, dynamic> json) {
    return NewsItem(
      id: json['id'] as String,
      title: json['title'] as String? ?? '',
      body: json['body'] as String? ?? '',
      imageUrl: json['cover_image_url'] as String? ?? json['image_url'] as String?,
      category: json['category'] as String?,
      authorName: json['author_name'] as String?,
      isPinned: json['is_pinned'] as bool? ?? false,
      publishedAt: DateTime.tryParse(json['published_at'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'body': body,
      'cover_image_url': imageUrl,
      'category': category,
      'author_name': authorName,
      'is_pinned': isPinned,
      'published_at': publishedAt.toIso8601String(),
    };
  }

  NewsItem copyWith({
    String? id,
    String? title,
    String? body,
    String? imageUrl,
    String? category,
    String? authorName,
    bool? isPinned,
    DateTime? publishedAt,
  }) {
    return NewsItem(
      id: id ?? this.id,
      title: title ?? this.title,
      body: body ?? this.body,
      imageUrl: imageUrl ?? this.imageUrl,
      category: category ?? this.category,
      authorName: authorName ?? this.authorName,
      isPinned: isPinned ?? this.isPinned,
      publishedAt: publishedAt ?? this.publishedAt,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is NewsItem && other.id == id);

  @override
  int get hashCode => id.hashCode;
}
