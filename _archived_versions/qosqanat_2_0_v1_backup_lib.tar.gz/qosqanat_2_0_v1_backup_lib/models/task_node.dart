import 'enums.dart';

/// A single node on the learning map (lesson / quiz / boss / treasure).
///
/// Nodes are grouped by subject and grade module and form the vertical
/// ascending Duolingo-style path.
class TaskNode {
  final String id;
  final String subjectId;
  final int grade;
  final String moduleId;
  final String title;
  final String? description;
  final NodeType type;
  final NodeStatus status;
  final int orderIndex;
  final int xpReward;
  final int coinReward;
  final int stars; // 0-3 earned
  final bool isLocked;

  const TaskNode({
    required this.id,
    required this.subjectId,
    required this.grade,
    required this.moduleId,
    required this.title,
    this.description,
    this.type = NodeType.lesson,
    this.status = NodeStatus.locked,
    this.orderIndex = 0,
    this.xpReward = 0,
    this.coinReward = 0,
    this.stars = 0,
    this.isLocked = true,
  });

  factory TaskNode.fromJson(Map<String, dynamic> json) {
    return TaskNode(
      id: json['id'] as String,
      subjectId: json['subject_id'] as String? ?? '',
      grade: (json['grade'] as num?)?.toInt() ?? 5,
      moduleId: json['module_id'] as String? ?? '',
      title: json['title'] as String? ?? '',
      description: json['description'] as String?,
      type: NodeType.fromWire(json['type'] as String?),
      status: NodeStatus.fromWire(json['status'] as String?),
      orderIndex: (json['order_index'] as num?)?.toInt() ?? 0,
      xpReward: (json['xp_reward'] as num?)?.toInt() ?? 0,
      coinReward: (json['coin_reward'] as num?)?.toInt() ?? 0,
      stars: (json['stars'] as num?)?.toInt() ?? 0,
      isLocked: json['is_locked'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'subject_id': subjectId,
      'grade': grade,
      'module_id': moduleId,
      'title': title,
      'description': description,
      'type': type.wireValue,
      'status': status.wireValue,
      'order_index': orderIndex,
      'xp_reward': xpReward,
      'coin_reward': coinReward,
      'stars': stars,
      'is_locked': isLocked,
    };
  }

  TaskNode copyWith({
    String? id,
    String? subjectId,
    int? grade,
    String? moduleId,
    String? title,
    String? description,
    NodeType? type,
    NodeStatus? status,
    int? orderIndex,
    int? xpReward,
    int? coinReward,
    int? stars,
    bool? isLocked,
  }) {
    return TaskNode(
      id: id ?? this.id,
      subjectId: subjectId ?? this.subjectId,
      grade: grade ?? this.grade,
      moduleId: moduleId ?? this.moduleId,
      title: title ?? this.title,
      description: description ?? this.description,
      type: type ?? this.type,
      status: status ?? this.status,
      orderIndex: orderIndex ?? this.orderIndex,
      xpReward: xpReward ?? this.xpReward,
      coinReward: coinReward ?? this.coinReward,
      stars: stars ?? this.stars,
      isLocked: isLocked ?? this.isLocked,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is TaskNode && other.id == id);

  @override
  int get hashCode => id.hashCode;
}
