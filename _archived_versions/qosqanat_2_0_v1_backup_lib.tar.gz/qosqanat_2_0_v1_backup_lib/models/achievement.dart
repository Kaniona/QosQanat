import 'enums.dart';

/// A long-term achievement (badge) the student can unlock.
class Achievement {
  final String id;
  final String title;
  final String description;
  final String iconAsset;
  final Rarity rarity;
  final int target;
  final int progress;
  final bool isUnlocked;
  final DateTime? unlockedAt;
  final int coinReward;

  const Achievement({
    required this.id,
    required this.title,
    required this.description,
    this.iconAsset = '',
    this.rarity = Rarity.common,
    this.target = 1,
    this.progress = 0,
    this.isUnlocked = false,
    this.unlockedAt,
    this.coinReward = 0,
  });

  double get progressRatio =>
      target == 0 ? 0 : (progress / target).clamp(0.0, 1.0);

  factory Achievement.fromJson(Map<String, dynamic> json) {
    return Achievement(
      id: json['id'] as String,
      title: json['title'] as String? ?? '',
      description: json['description'] as String? ?? '',
      iconAsset: json['icon_asset'] as String? ?? '',
      rarity: Rarity.fromWire(json['rarity'] as String?),
      target: (json['target'] as num?)?.toInt() ?? 1,
      progress: (json['progress'] as num?)?.toInt() ?? 0,
      isUnlocked: json['is_unlocked'] as bool? ?? false,
      unlockedAt: json['unlocked_at'] != null
          ? DateTime.tryParse(json['unlocked_at'] as String)
          : null,
      coinReward: (json['coin_reward'] as num?)?.toInt() ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'icon_asset': iconAsset,
      'rarity': rarity.wireValue,
      'target': target,
      'progress': progress,
      'is_unlocked': isUnlocked,
      'unlocked_at': unlockedAt?.toIso8601String(),
      'coin_reward': coinReward,
    };
  }

  Achievement copyWith({
    String? id,
    String? title,
    String? description,
    String? iconAsset,
    Rarity? rarity,
    int? target,
    int? progress,
    bool? isUnlocked,
    DateTime? unlockedAt,
    int? coinReward,
  }) {
    return Achievement(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      iconAsset: iconAsset ?? this.iconAsset,
      rarity: rarity ?? this.rarity,
      target: target ?? this.target,
      progress: progress ?? this.progress,
      isUnlocked: isUnlocked ?? this.isUnlocked,
      unlockedAt: unlockedAt ?? this.unlockedAt,
      coinReward: coinReward ?? this.coinReward,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is Achievement && other.id == id);

  @override
  int get hashCode => id.hashCode;
}
