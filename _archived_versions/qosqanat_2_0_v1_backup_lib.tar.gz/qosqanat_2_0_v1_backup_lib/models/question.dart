/// Question models for the learning tasks. Four mixed types are supported:
/// multiple choice, true/false, fill-in-the-blank, and match-the-pairs.
library;

enum QuestionType { multipleChoice, trueFalse, fillBlank, matchPairs }

/// A left↔right pair for [QuestionType.matchPairs].
class MatchPair {
  final String left;
  final String right;
  const MatchPair(this.left, this.right);
}

/// A single quiz question. Only the fields relevant to [type] are populated;
/// the factory constructors keep construction type-safe and readable.
class Question {
  final String id;
  final QuestionType type;
  final String prompt;
  final String explanation;
  final int xp;

  // Multiple choice
  final List<String> options;
  final int correctIndex;

  // True / false
  final bool answerIsTrue;

  // Fill in the blank ("___" marks the gap in [prompt])
  final String blankAnswer;
  final List<String> wordBank;

  // Match pairs
  final List<MatchPair> pairs;

  const Question._({
    required this.id,
    required this.type,
    required this.prompt,
    this.explanation = '',
    this.xp = 5,
    this.options = const [],
    this.correctIndex = 0,
    this.answerIsTrue = true,
    this.blankAnswer = '',
    this.wordBank = const [],
    this.pairs = const [],
  });

  const factory Question.mc({
    required String id,
    required String prompt,
    required List<String> options,
    required int correctIndex,
    String explanation,
    int xp,
  }) = Question._mc;

  const Question._mc({
    required String id,
    required String prompt,
    required List<String> options,
    required int correctIndex,
    String explanation = '',
    int xp = 5,
  }) : this._(
          id: id,
          type: QuestionType.multipleChoice,
          prompt: prompt,
          options: options,
          correctIndex: correctIndex,
          explanation: explanation,
          xp: xp,
        );

  const factory Question.tf({
    required String id,
    required String prompt,
    required bool answerIsTrue,
    String explanation,
    int xp,
  }) = Question._tf;

  const Question._tf({
    required String id,
    required String prompt,
    required bool answerIsTrue,
    String explanation = '',
    int xp = 5,
  }) : this._(
          id: id,
          type: QuestionType.trueFalse,
          prompt: prompt,
          answerIsTrue: answerIsTrue,
          explanation: explanation,
          xp: xp,
        );

  const factory Question.fill({
    required String id,
    required String prompt,
    required String blankAnswer,
    required List<String> wordBank,
    String explanation,
    int xp,
  }) = Question._fill;

  const Question._fill({
    required String id,
    required String prompt,
    required String blankAnswer,
    required List<String> wordBank,
    String explanation = '',
    int xp = 5,
  }) : this._(
          id: id,
          type: QuestionType.fillBlank,
          prompt: prompt,
          blankAnswer: blankAnswer,
          wordBank: wordBank,
          explanation: explanation,
          xp: xp,
        );

  const factory Question.match({
    required String id,
    required String prompt,
    required List<MatchPair> pairs,
    String explanation,
    int xp,
  }) = Question._match;

  const Question._match({
    required String id,
    required String prompt,
    required List<MatchPair> pairs,
    String explanation = '',
    int xp = 8,
  }) : this._(
          id: id,
          type: QuestionType.matchPairs,
          prompt: prompt,
          pairs: pairs,
          explanation: explanation,
          xp: xp,
        );

  /// Validates a multiple-choice / true-false / fill answer.
  bool isCorrectIndex(int index) => index == correctIndex;
  bool isCorrectBool(bool value) => value == answerIsTrue;
  bool isCorrectWord(String word) =>
      word.trim().toLowerCase() == blankAnswer.trim().toLowerCase();
}
