/// A daily quest the student can complete for rewards.
class Quest {
  final String id;
  final String title;
  final String? description;
  final int target; // required progress count
  final int progress; // current progress
  final int xpReward;
  final int coinReward;
  final bool isCompleted;
  final bool isClaimed;
  final DateTime? expiresAt;

  const Quest({
    required this.id,
    required this.title,
    this.description,
    this.target = 1,
    this.progress = 0,
    this.xpReward = 0,
    this.coinReward = 0,
    this.isCompleted = false,
    this.isClaimed = false,
    this.expiresAt,
  });

  /// Completion ratio in the range 0.0–1.0.
  double get progressRatio =>
      target == 0 ? 0 : (progress / target).clamp(0.0, 1.0);

  factory Quest.fromJson(Map<String, dynamic> json) {
    return Quest(
      id: json['id'] as String,
      title: json['title'] as String? ?? '',
      description: json['description'] as String?,
      target: (json['target'] as num?)?.toInt() ?? 1,
      progress: (json['progress'] as num?)?.toInt() ?? 0,
      xpReward: (json['xp_reward'] as num?)?.toInt() ?? 0,
      coinReward: (json['coin_reward'] as num?)?.toInt() ?? 0,
      isCompleted: json['is_completed'] as bool? ?? false,
      isClaimed: json['is_claimed'] as bool? ?? false,
      expiresAt: json['expires_at'] != null
          ? DateTime.tryParse(json['expires_at'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'target': target,
      'progress': progress,
      'xp_reward': xpReward,
      'coin_reward': coinReward,
      'is_completed': isCompleted,
      'is_claimed': isClaimed,
      'expires_at': expiresAt?.toIso8601String(),
    };
  }

  Quest copyWith({
    String? id,
    String? title,
    String? description,
    int? target,
    int? progress,
    int? xpReward,
    int? coinReward,
    bool? isCompleted,
    bool? isClaimed,
    DateTime? expiresAt,
  }) {
    return Quest(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      target: target ?? this.target,
      progress: progress ?? this.progress,
      xpReward: xpReward ?? this.xpReward,
      coinReward: coinReward ?? this.coinReward,
      isCompleted: isCompleted ?? this.isCompleted,
      isClaimed: isClaimed ?? this.isClaimed,
      expiresAt: expiresAt ?? this.expiresAt,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is Quest && other.id == id);

  @override
  int get hashCode => id.hashCode;
}
