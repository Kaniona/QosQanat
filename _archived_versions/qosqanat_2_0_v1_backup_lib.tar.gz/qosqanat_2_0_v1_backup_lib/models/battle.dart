import 'enums.dart';

/// A lightweight participant snapshot inside an Akyl battle.
class BattlePlayer {
  final String userId;
  final String fullName;
  final String? profilePhotoUrl;
  final int score;
  final int level;

  const BattlePlayer({
    required this.userId,
    required this.fullName,
    this.profilePhotoUrl,
    this.score = 0,
    this.level = 1,
  });

  factory BattlePlayer.fromJson(Map<String, dynamic> json) {
    return BattlePlayer(
      userId: json['user_id'] as String? ?? '',
      fullName: json['full_name'] as String? ?? '',
      profilePhotoUrl: json['profile_photo_url'] as String?,
      score: (json['score'] as num?)?.toInt() ?? 0,
      level: (json['level'] as num?)?.toInt() ?? 1,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'user_id': userId,
      'full_name': fullName,
      'profile_photo_url': profilePhotoUrl,
      'score': score,
      'level': level,
    };
  }

  BattlePlayer copyWith({
    String? userId,
    String? fullName,
    String? profilePhotoUrl,
    int? score,
    int? level,
  }) {
    return BattlePlayer(
      userId: userId ?? this.userId,
      fullName: fullName ?? this.fullName,
      profilePhotoUrl: profilePhotoUrl ?? this.profilePhotoUrl,
      score: score ?? this.score,
      level: level ?? this.level,
    );
  }
}

/// A realtime 1v1 Akyl quiz battle between two students.
class Battle {
  final String id;
  final BattlePlayer host;
  final BattlePlayer? opponent;
  final BattleStatus status;
  final String? subjectId;
  final int totalRounds;
  final int currentRound;
  final String? winnerId;
  final int akylStake;
  final DateTime createdAt;

  const Battle({
    required this.id,
    required this.host,
    this.opponent,
    this.status = BattleStatus.waiting,
    this.subjectId,
    this.totalRounds = 5,
    this.currentRound = 0,
    this.winnerId,
    this.akylStake = 0,
    required this.createdAt,
  });

  factory Battle.fromJson(Map<String, dynamic> json) {
    return Battle(
      id: json['id'] as String,
      host: BattlePlayer.fromJson(
        (json['host'] as Map<String, dynamic>?) ?? const {},
      ),
      opponent: json['opponent'] != null
          ? BattlePlayer.fromJson(json['opponent'] as Map<String, dynamic>)
          : null,
      status: BattleStatus.fromWire(json['status'] as String?),
      subjectId: json['subject_id'] as String?,
      totalRounds: (json['total_rounds'] as num?)?.toInt() ?? 5,
      currentRound: (json['current_round'] as num?)?.toInt() ?? 0,
      winnerId: json['winner_id'] as String?,
      akylStake: (json['akyl_stake'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.tryParse(json['created_at'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'host': host.toJson(),
      'opponent': opponent?.toJson(),
      'status': status.wireValue,
      'subject_id': subjectId,
      'total_rounds': totalRounds,
      'current_round': currentRound,
      'winner_id': winnerId,
      'akyl_stake': akylStake,
      'created_at': createdAt.toIso8601String(),
    };
  }

  Battle copyWith({
    String? id,
    BattlePlayer? host,
    BattlePlayer? opponent,
    BattleStatus? status,
    String? subjectId,
    int? totalRounds,
    int? currentRound,
    String? winnerId,
    int? akylStake,
    DateTime? createdAt,
  }) {
    return Battle(
      id: id ?? this.id,
      host: host ?? this.host,
      opponent: opponent ?? this.opponent,
      status: status ?? this.status,
      subjectId: subjectId ?? this.subjectId,
      totalRounds: totalRounds ?? this.totalRounds,
      currentRound: currentRound ?? this.currentRound,
      winnerId: winnerId ?? this.winnerId,
      akylStake: akylStake ?? this.akylStake,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is Battle && other.id == id);

  @override
  int get hashCode => id.hashCode;
}
