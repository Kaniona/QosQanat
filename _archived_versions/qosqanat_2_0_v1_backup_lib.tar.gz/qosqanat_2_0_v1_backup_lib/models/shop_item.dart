import 'enums.dart';

/// A purchasable cosmetic item used to dress up the assistant.
///
/// `slot` is the avatar layer this item overrides (e.g. `top`, `bottom`, `hat`,
/// `pet`, `face_accessory`, `neck`, `shoes`). `assetSvg` is an inline SVG drawn
/// into that slot at 200×240 — the avatar layers stack it on top of (or in
/// place of) the default body art, so a single item description here drives the
/// live preview, the equipped state, and every avatar elsewhere in the app.
class ShopItem {
  final String id;
  final String name;
  final String? description;
  final ItemCategory category;
  final Rarity rarity;
  final int price;
  final int levelRequirement;
  final String slot;
  final String assetSvg;
  final String assetUrl;
  final bool isOwned;
  final bool isEquipped;
  final bool isNew;

  const ShopItem({
    required this.id,
    required this.name,
    this.description,
    this.category = ItemCategory.clothing,
    this.rarity = Rarity.common,
    this.price = 0,
    this.levelRequirement = 1,
    this.slot = '',
    this.assetSvg = '',
    this.assetUrl = '',
    this.isOwned = false,
    this.isEquipped = false,
    this.isNew = false,
  });

  factory ShopItem.fromJson(Map<String, dynamic> json) {
    return ShopItem(
      id: json['id'] as String,
      name: json['name'] as String? ?? '',
      description: json['description'] as String?,
      category: ItemCategory.fromWire(json['category'] as String?),
      rarity: Rarity.fromWire(json['rarity'] as String?),
      price: (json['price'] as num?)?.toInt() ?? 0,
      levelRequirement: (json['level_requirement'] as num?)?.toInt() ?? 1,
      slot: json['slot'] as String? ?? '',
      assetSvg: json['asset_svg'] as String? ?? '',
      assetUrl: json['asset_url'] as String? ?? '',
      isOwned: json['is_owned'] as bool? ?? false,
      isEquipped: json['is_equipped'] as bool? ?? false,
      isNew: json['is_new'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'category': category.wireValue,
      'rarity': rarity.wireValue,
      'price': price,
      'level_requirement': levelRequirement,
      'slot': slot,
      'asset_svg': assetSvg,
      'asset_url': assetUrl,
      'is_owned': isOwned,
      'is_equipped': isEquipped,
      'is_new': isNew,
    };
  }

  ShopItem copyWith({
    String? id,
    String? name,
    String? description,
    ItemCategory? category,
    Rarity? rarity,
    int? price,
    int? levelRequirement,
    String? slot,
    String? assetSvg,
    String? assetUrl,
    bool? isOwned,
    bool? isEquipped,
    bool? isNew,
  }) {
    return ShopItem(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      category: category ?? this.category,
      rarity: rarity ?? this.rarity,
      price: price ?? this.price,
      levelRequirement: levelRequirement ?? this.levelRequirement,
      slot: slot ?? this.slot,
      assetSvg: assetSvg ?? this.assetSvg,
      assetUrl: assetUrl ?? this.assetUrl,
      isOwned: isOwned ?? this.isOwned,
      isEquipped: isEquipped ?? this.isEquipped,
      isNew: isNew ?? this.isNew,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is ShopItem && other.id == id);

  @override
  int get hashCode => id.hashCode;
}
