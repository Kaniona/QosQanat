import 'enums.dart';

/// A competitive tournament students can register for and compete in.
class Tournament {
  final String id;
  final String title;
  final String? description;
  final String? bannerUrl;
  final TournamentStatus status;
  final int participantCount;
  final int maxParticipants;
  final int prizeCoins;
  final int entryAkyl;
  final DateTime startsAt;
  final DateTime? endsAt;
  final bool isRegistered;

  const Tournament({
    required this.id,
    required this.title,
    this.description,
    this.bannerUrl,
    this.status = TournamentStatus.upcoming,
    this.participantCount = 0,
    this.maxParticipants = 0,
    this.prizeCoins = 0,
    this.entryAkyl = 0,
    required this.startsAt,
    this.endsAt,
    this.isRegistered = false,
  });

  factory Tournament.fromJson(Map<String, dynamic> json) {
    return Tournament(
      id: json['id'] as String,
      title: json['title'] as String? ?? '',
      description: json['description'] as String?,
      bannerUrl: json['banner_url'] as String?,
      status: TournamentStatus.fromWire(json['status'] as String?),
      participantCount: (json['participant_count'] as num?)?.toInt() ?? 0,
      maxParticipants: (json['max_participants'] as num?)?.toInt() ?? 0,
      prizeCoins: (json['prize_coins'] as num?)?.toInt() ?? 0,
      entryAkyl: (json['entry_akyl'] as num?)?.toInt() ?? 0,
      startsAt: DateTime.tryParse(json['starts_at'] as String? ?? '') ??
          DateTime.now(),
      endsAt: json['ends_at'] != null
          ? DateTime.tryParse(json['ends_at'] as String)
          : null,
      isRegistered: json['is_registered'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'banner_url': bannerUrl,
      'status': status.wireValue,
      'participant_count': participantCount,
      'max_participants': maxParticipants,
      'prize_coins': prizeCoins,
      'entry_akyl': entryAkyl,
      'starts_at': startsAt.toIso8601String(),
      'ends_at': endsAt?.toIso8601String(),
      'is_registered': isRegistered,
    };
  }

  Tournament copyWith({
    String? id,
    String? title,
    String? description,
    String? bannerUrl,
    TournamentStatus? status,
    int? participantCount,
    int? maxParticipants,
    int? prizeCoins,
    int? entryAkyl,
    DateTime? startsAt,
    DateTime? endsAt,
    bool? isRegistered,
  }) {
    return Tournament(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      bannerUrl: bannerUrl ?? this.bannerUrl,
      status: status ?? this.status,
      participantCount: participantCount ?? this.participantCount,
      maxParticipants: maxParticipants ?? this.maxParticipants,
      prizeCoins: prizeCoins ?? this.prizeCoins,
      entryAkyl: entryAkyl ?? this.entryAkyl,
      startsAt: startsAt ?? this.startsAt,
      endsAt: endsAt ?? this.endsAt,
      isRegistered: isRegistered ?? this.isRegistered,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is Tournament && other.id == id);

  @override
  int get hashCode => id.hashCode;
}
