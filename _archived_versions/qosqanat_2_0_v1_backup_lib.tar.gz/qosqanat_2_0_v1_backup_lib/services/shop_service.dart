import 'offline_service.dart';

/// Reads + writes the signed-in user's owned items (inventory) and currently
/// equipped cosmetics (slot → item) in local storage.
class ShopService {
  /// Returns the set of `item_id`s the player owns.
  Future<Set<String>> loadInventory() async {
    final id = OfflineService.currentUserId;
    if (id == null) return const {};
    final box = OfflineService.box(OfflineService.inventoryBox);
    return OfflineService.asStringList(box.get(id)).toSet();
  }

  /// Returns the player's currently equipped items as a `slot → item_id` map.
  Future<Map<String, String>> loadEquipment() async {
    final id = OfflineService.currentUserId;
    if (id == null) return const {};
    final box = OfflineService.box(OfflineService.equipmentBox);
    final raw = OfflineService.asMap(box.get(id));
    return {for (final e in raw.entries) e.key: e.value.toString()};
  }

  /// Records an inventory purchase. Idempotent.
  Future<void> insertInventory({
    required String itemId,
    required int purchasePrice,
  }) async {
    final id = OfflineService.currentUserId;
    if (id == null) return;
    final box = OfflineService.box(OfflineService.inventoryBox);
    final owned = OfflineService.asStringList(box.get(id)).toSet()..add(itemId);
    await box.put(id, owned.toList());
  }

  /// Equips [itemId] in [slot], replacing whatever was there.
  Future<void> equip({required String slot, required String itemId}) async {
    final id = OfflineService.currentUserId;
    if (id == null) return;
    final box = OfflineService.box(OfflineService.equipmentBox);
    final map = <String, String>{
      for (final e in OfflineService.asMap(box.get(id)).entries)
        e.key: e.value.toString(),
    };
    map[slot] = itemId;
    await box.put(id, map);
  }

  /// Removes whatever is currently in [slot].
  Future<void> unequip(String slot) async {
    final id = OfflineService.currentUserId;
    if (id == null) return;
    final box = OfflineService.box(OfflineService.equipmentBox);
    final map = <String, String>{
      for (final e in OfflineService.asMap(box.get(id)).entries)
        e.key: e.value.toString(),
    };
    map.remove(slot);
    await box.put(id, map);
  }
}
