import 'offline_service.dart';

/// Persists per-node learning progress to local storage, keyed by user id.
///
/// The provider owns all state; this service only reads and upserts rows.
class LearnProgressService {
  /// Fetches every saved row for the signed-in user.
  Future<List<Map<String, dynamic>>> loadAll() async {
    final id = OfflineService.currentUserId;
    if (id == null) return const [];
    final box = OfflineService.box(OfflineService.tasksBox);
    return OfflineService.asMapList(box.get(id));
  }

  /// Upserts a single completion row (unique on node_id for the user).
  Future<void> upsertCompletion({
    required String subjectId,
    required String moduleId,
    required String nodeId,
    required String status, // 'completed' | 'mastered'
    required int bestScore, // 0–100
    required int attempts,
    required int xpEarned,
    required int coinsEarned,
    required int akylEarned,
  }) async {
    final id = OfflineService.currentUserId;
    if (id == null) return;

    final box = OfflineService.box(OfflineService.tasksBox);
    final rows = OfflineService.asMapList(box.get(id));
    final row = {
      'node_id': nodeId,
      'subject_id': subjectId,
      'module_id': moduleId,
      'status': status,
      'best_score': bestScore,
      'attempts': attempts,
      'xp_earned': xpEarned,
      'coins_earned': coinsEarned,
      'akyl_earned': akylEarned,
      'completed_at': DateTime.now().toUtc().toIso8601String(),
    };

    final idx = rows.indexWhere((r) => r['node_id'] == nodeId);
    if (idx >= 0) {
      rows[idx] = row;
    } else {
      rows.add(row);
    }
    await box.put(id, rows);
  }
}
