import 'offline_service.dart';

/// Persists gamification fields to the signed-in user's record in local
/// storage. The game notifier owns all logic; this service only writes the
/// resulting numbers.
class GameService {
  /// Updates the signed-in user's game fields. Silently no-ops when signed out.
  Future<void> save({
    required int level,
    required int xp,
    required int coins,
    required int akylPoints,
    required int currentStreak,
    required int longestStreak,
    DateTime? lastLoginDate,
  }) async {
    final id = OfflineService.currentUserId;
    if (id == null) return;

    final users = OfflineService.box(OfflineService.usersBox);
    final map = OfflineService.asMap(users.get(id));
    if (map.isEmpty) return;

    map['level'] = level;
    map['xp'] = xp;
    map['coins'] = coins;
    map['akyl_points'] = akylPoints;
    map['current_streak'] = currentStreak;
    map['longest_streak'] = longestStreak;
    if (lastLoginDate != null) {
      map['last_login_date'] = _dateOnly(lastLoginDate);
    }
    await users.put(id, map);
  }

  static String _dateOnly(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';
}
