import '../models/news_item.dart';
import 'offline_service.dart';

/// Reads admin-posted announcements from local storage (seeded mock data).
class NewsService {
  /// Fetches news, pinned first, then newest by publish date.
  Future<List<NewsItem>> fetchPublished() async {
    if (!OfflineService.isReady) return const [];
    final box = OfflineService.box(OfflineService.newsBox);
    final items = [
      for (final key in box.keys)
        NewsItem.fromJson(OfflineService.asMap(box.get(key))),
    ];
    items.sort((a, b) {
      if (a.isPinned != b.isPinned) return a.isPinned ? -1 : 1;
      return b.publishedAt.compareTo(a.publishedAt);
    });
    return items;
  }
}
