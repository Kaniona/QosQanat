import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Thin wrapper around Supabase initialization and client access.
///
/// Call [SupabaseService.init] once at app startup (after dotenv has loaded),
/// then use [SupabaseService.client] everywhere else.
class SupabaseService {
  SupabaseService._();

  /// Initializes Supabase using credentials from the loaded `.env` file.
  static Future<void> init() async {
    final url = dotenv.env['SUPABASE_URL'];
    final anonKey = dotenv.env['SUPABASE_ANON_KEY'];

    if (url == null || url.isEmpty || anonKey == null || anonKey.isEmpty) {
      throw StateError(
        'SUPABASE_URL and SUPABASE_ANON_KEY must be set in the .env file.',
      );
    }

    await Supabase.initialize(url: url, anonKey: anonKey);
  }

  /// The shared Supabase client.
  static SupabaseClient get client => Supabase.instance.client;

  /// Convenience accessor for the auth namespace.
  static GoTrueClient get auth => client.auth;

  /// The currently authenticated user, or `null` if signed out.
  static User? get currentUser => client.auth.currentUser;

  /// Whether a user session is currently active.
  static bool get isAuthenticated => currentUser != null;
}
