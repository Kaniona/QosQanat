import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';

/// Local-storage backend that replaces Supabase while the app runs in **offline
/// test mode**. Every dynamic surface (users, quests, friends, battles,
/// tournaments, news, inventory, progress, settings) is read from / written to
/// Hive boxes seeded with mock data at startup.
///
/// The architecture above this layer is untouched: providers still call the
/// same service classes; those services now delegate here instead of to
/// Supabase. To restore the live backend, re-point the services at Supabase and
/// stop calling [OfflineService.init].
class OfflineService {
  OfflineService._();

  // ---------------------------------------------------------------------------
  // Box names
  // ---------------------------------------------------------------------------
  static const String usersBox = 'users';
  static const String questsBox = 'quests';
  static const String achievementsBox = 'achievements';
  static const String friendsBox = 'friends';
  static const String battlesBox = 'battles';
  static const String tasksBox = 'tasks';
  static const String newsBox = 'news';
  static const String settingsBox = 'settings';
  static const String inventoryBox = 'inventory';
  static const String equipmentBox = 'equipment';
  static const String tournamentsBox = 'tournaments';
  static const String tournamentParticipantsBox = 'tournament_participants';

  static const List<String> _allBoxes = [
    usersBox,
    questsBox,
    achievementsBox,
    friendsBox,
    battlesBox,
    tasksBox,
    newsBox,
    settingsBox,
    inventoryBox,
    equipmentBox,
    tournamentsBox,
    tournamentParticipantsBox,
  ];

  static const String _kCurrentUserId = 'current_user_id';
  static const String _kSeeded = 'seeded_v1';

  static bool _initialized = false;

  /// Initializes Hive and opens every box. Idempotent.
  static Future<void> init() async {
    if (_initialized) return;
    await Hive.initFlutter();
    for (final name in _allBoxes) {
      if (!Hive.isBoxOpen(name)) {
        await Hive.openBox(name);
      }
    }
    _initialized = true;
  }

  /// Whether [init] has completed and the boxes are open. Used by services to
  /// degrade gracefully (return empty) when storage isn't ready yet — e.g. in
  /// widget tests that don't initialize Hive.
  static bool get isReady => _initialized;

  static Box box(String name) => Hive.box(name);

  // ---------------------------------------------------------------------------
  // Auth state — a tiny offline session layer
  // ---------------------------------------------------------------------------

  /// Broadcasts an event whenever the signed-in user changes (sign in / out /
  /// register). The auth provider listens to this to reload the profile.
  static final StreamController<void> _authEvents =
      StreamController<void>.broadcast();

  /// Stream of auth-state changes (mirrors Supabase's `onAuthStateChange`).
  static Stream<void> get onAuthChanged => _authEvents.stream;

  /// [Listenable] form of the same signal, for go_router's `refreshListenable`.
  static final ValueNotifier<int> authRevision = ValueNotifier<int>(0);

  /// The id of the currently signed-in user, or `null` when signed out (or when
  /// storage isn't initialized yet).
  static String? get currentUserId {
    if (!_initialized) return null;
    final v = box(settingsBox).get(_kCurrentUserId);
    return (v is String && v.isNotEmpty) ? v : null;
  }

  static bool get isAuthenticated => currentUserId != null;

  /// Sets (or clears) the signed-in user and notifies listeners.
  static void setCurrentUser(String? id) {
    final settings = box(settingsBox);
    if (id == null) {
      settings.delete(_kCurrentUserId);
    } else {
      settings.put(_kCurrentUserId, id);
    }
    authRevision.value++;
    if (!_authEvents.isClosed) _authEvents.add(null);
  }

  // ---------------------------------------------------------------------------
  // Seeding
  // ---------------------------------------------------------------------------

  /// Whether the mock data has already been written to disk.
  static bool get isSeeded => box(settingsBox).get(_kSeeded) == true;

  static void markSeeded() => box(settingsBox).put(_kSeeded, true);

  // ---------------------------------------------------------------------------
  // JSON helpers — Hive returns `Map<dynamic, dynamic>`; normalize to typed maps
  // ---------------------------------------------------------------------------

  static Map<String, dynamic> asMap(dynamic value) {
    if (value is Map) return Map<String, dynamic>.from(value);
    return <String, dynamic>{};
  }

  static List<Map<String, dynamic>> asMapList(dynamic value) {
    if (value is List) {
      return [for (final e in value) asMap(e)];
    }
    return <Map<String, dynamic>>[];
  }

  static List<String> asStringList(dynamic value) {
    if (value is List) {
      return [for (final e in value) e.toString()];
    }
    return <String>[];
  }
}
