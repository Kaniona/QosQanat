import 'dart:math' as math;

import '../models/enums.dart';
import '../models/user.dart';
import 'offline_service.dart';

/// Raised for auth/profile failures with a Kazakh-friendly [message].
class AuthFailure implements Exception {
  final String message;
  const AuthFailure(this.message);

  @override
  String toString() => message;
}

/// Offline auth + profile operations backed by [OfflineService] (Hive). The UI
/// never talks to storage directly — it goes through providers, which call this
/// service. No passwords are validated and no network calls are made: this is a
/// stand-in for the Supabase backend while testing.
class AuthService {
  static const _giftedKey = 'assistant_gifted';

  /// Whether a user session is currently active.
  bool get isAuthenticated => OfflineService.isAuthenticated;

  /// Stream of auth-state changes (drives router refresh + profile reloads).
  Stream<void> get onAuthChanged => OfflineService.onAuthChanged;

  // ---------------------------------------------------------------------------
  // Sign in / out
  // ---------------------------------------------------------------------------

  /// Offline sign-in: any password is accepted. Loads the seeded primary mock
  /// account (or an existing account that matches the phone) and marks it as the
  /// current user.
  Future<void> signInWithPhone({
    required String phoneE164,
    required String password,
  }) async {
    if (phoneE164.trim().length < 8) {
      throw const AuthFailure('Телефон нөмірі дұрыс емес');
    }

    final users = OfflineService.box(OfflineService.usersBox);

    // Prefer an account whose phone matches; otherwise fall back to the
    // headline mock user so the app is always populated after login.
    String? matchId;
    for (final key in users.keys) {
      final m = OfflineService.asMap(users.get(key));
      if (m['phone'] == phoneE164) {
        matchId = m['id'] as String?;
        break;
      }
    }
    matchId ??= 'qq-user-0001';

    if (users.get(matchId) == null) {
      throw const AuthFailure('Қолданушы табылмады');
    }
    OfflineService.setCurrentUser(matchId);
  }

  Future<void> signOut() async {
    OfflineService.setCurrentUser(null);
  }

  // ---------------------------------------------------------------------------
  // Registration
  // ---------------------------------------------------------------------------

  /// Creates a fresh offline account from the registration data (no uniqueness
  /// checks), saves it, and signs in automatically.
  Future<AppUser> register({
    required String phoneE164,
    required String password,
    required String fullName,
    required String iin,
    required String city,
    required String school,
    required int grade,
  }) async {
    final id = 'qq-user-${DateTime.now().millisecondsSinceEpoch}';
    final user = AppUser(
      id: id,
      qosqanatId: 'QQ-${_randomId()}',
      fullName: fullName,
      phone: phoneE164,
      iin: iin,
      city: city,
      school: school,
      grade: grade,
      createdAt: DateTime.now(),
    );

    final users = OfflineService.box(OfflineService.usersBox);
    await users.put(id, user.toJson());
    OfflineService.setCurrentUser(id);
    return user;
  }

  // ---------------------------------------------------------------------------
  // Profile
  // ---------------------------------------------------------------------------

  /// Loads the signed-in user's profile, or `null` if signed out.
  Future<AppUser?> loadCurrentProfile() async {
    final id = OfflineService.currentUserId;
    if (id == null) return null;
    final raw = OfflineService.box(OfflineService.usersBox).get(id);
    if (raw == null) return null;
    return AppUser.fromJson(OfflineService.asMap(raw));
  }

  /// Persists the chosen assistant and grants the one-time welcome coin gift.
  Future<AppUser> chooseAssistant({
    required AssistantType assistant,
    required int giftCoins,
  }) async {
    final id = OfflineService.currentUserId;
    if (id == null) throw const AuthFailure('Қолданушы анықталмады');

    final users = OfflineService.box(OfflineService.usersBox);
    final map = OfflineService.asMap(users.get(id));

    final alreadyGifted = map[_giftedKey] == true;
    map['assistant_type'] = assistant.wireValue;
    if (!alreadyGifted) {
      map['coins'] = ((map['coins'] as num?)?.toInt() ?? 0) + giftCoins;
      map[_giftedKey] = true;
    }
    await users.put(id, map);
    return AppUser.fromJson(map);
  }

  // ---------------------------------------------------------------------------
  // Password recovery — no-ops in offline mode (always "succeed")
  // ---------------------------------------------------------------------------
  Future<void> sendRecoveryCode(String phoneE164) async {}

  Future<void> verifyRecoveryCode({
    required String phoneE164,
    required String token,
  }) async {}

  Future<void> updatePassword(String newPassword) async {}

  // ---------------------------------------------------------------------------

  String _randomId() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final rng = math.Random();
    return List.generate(8, (_) => chars[rng.nextInt(chars.length)]).join();
  }
}
