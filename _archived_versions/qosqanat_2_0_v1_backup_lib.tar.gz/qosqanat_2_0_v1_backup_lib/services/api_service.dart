import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:path_provider/path_provider.dart';

import '../data/curriculum.dart';
import '../models/battle.dart';
import '../models/enums.dart';
import '../models/question.dart';
import '../models/tournament.dart';
import 'offline_service.dart';

// =============================================================================
// Public DTOs used by the social/competitive UI
// =============================================================================

/// Lightweight profile returned by [ApiService.searchUserByQosqanatId] and the
/// friends list — never contains private columns like phone / iin / email.
class FriendUser {
  final String userId;
  final String qosqanatId;
  final String fullName;
  final int level;
  final int akylPoints;
  final String? profilePhotoUrl;
  final AssistantType assistantType;
  final bool isOnline;

  const FriendUser({
    required this.userId,
    required this.qosqanatId,
    required this.fullName,
    required this.level,
    this.akylPoints = 0,
    this.profilePhotoUrl,
    this.assistantType = AssistantType.bektur,
    this.isOnline = false,
  });

  factory FriendUser.fromJson(Map<String, dynamic> j) => FriendUser(
        userId: (j['user_id'] ?? j['id']) as String,
        qosqanatId: j['qosqanat_id'] as String? ?? '',
        fullName: j['full_name'] as String? ?? '',
        level: (j['level'] as num?)?.toInt() ?? 1,
        akylPoints: (j['akyl_points'] as num?)?.toInt() ?? 0,
        profilePhotoUrl: j['profile_photo_url'] as String?,
        assistantType:
            AssistantType.fromWire(j['assistant_type'] as String?),
      );
}

/// A pending friend request — both incoming (someone asked us) and outgoing
/// (we asked them, awaiting their response).
enum RequestDirection { incoming, outgoing }

class PendingRequest {
  final String friendshipId;
  final FriendUser other;
  final RequestDirection direction;

  const PendingRequest({
    required this.friendshipId,
    required this.other,
    required this.direction,
  });
}

/// One row of a global/city/school/friends leaderboard ordered by akyl points.
class RatingEntry {
  final String userId;
  final String qosqanatId;
  final String fullName;
  final String? city;
  final String? school;
  final int? grade;
  final int level;
  final int akylPoints;
  final String? profilePhotoUrl;
  final int rank;

  const RatingEntry({
    required this.userId,
    required this.qosqanatId,
    required this.fullName,
    required this.level,
    required this.akylPoints,
    required this.rank,
    this.city,
    this.school,
    this.grade,
    this.profilePhotoUrl,
  });
}

/// Compact public profile used when viewing another user.
class PublicProfile {
  final String userId;
  final String qosqanatId;
  final String fullName;
  final String? city;
  final String? school;
  final int? grade;
  final int level;
  final int xp;
  final int akylPoints;
  final int coins;
  final int currentStreak;
  final int longestStreak;
  final int totalTasksCompleted;
  final int totalBattlesWon;
  final AssistantType assistantType;
  final String? profilePhotoUrl;

  const PublicProfile({
    required this.userId,
    required this.qosqanatId,
    required this.fullName,
    required this.level,
    required this.xp,
    required this.akylPoints,
    required this.coins,
    required this.currentStreak,
    required this.longestStreak,
    required this.totalTasksCompleted,
    required this.totalBattlesWon,
    required this.assistantType,
    this.city,
    this.school,
    this.grade,
    this.profilePhotoUrl,
  });
}

/// Compact row used by "Соңғы шайқастар" on the profile screen.
class RecentBattleSummary {
  final String battleId;
  final String opponentId;
  final String opponentName;
  final String opponentQqId;
  final String? opponentPhotoUrl;
  final int myScore;
  final int opponentScore;
  final bool won;
  final DateTime endedAt;

  const RecentBattleSummary({
    required this.battleId,
    required this.opponentId,
    required this.opponentName,
    required this.opponentQqId,
    required this.myScore,
    required this.opponentScore,
    required this.won,
    required this.endedAt,
    this.opponentPhotoUrl,
  });
}

/// One row of a tournament leaderboard.
class LeaderboardEntry {
  final String userId;
  final String qosqanatId;
  final String fullName;
  final int level;
  final String? profilePhotoUrl;
  final int score;
  final int rank;

  const LeaderboardEntry({
    required this.userId,
    required this.qosqanatId,
    required this.fullName,
    required this.level,
    required this.score,
    required this.rank,
    this.profilePhotoUrl,
  });
}

// =============================================================================
// API service (offline)
// =============================================================================

class ApiException implements Exception {
  final String message;
  const ApiException(this.message);
  @override
  String toString() => 'ApiException: $message';
}

/// Offline replacement for the cross-user read/write surface: friendships,
/// battles (with a simulated opponent), tournaments, leaderboards, and the
/// profile screen's aggregate data. Everything is backed by [OfflineService]
/// (Hive) + the static [kCurriculum]; no network calls happen.
class ApiService {
  String? get _uid => OfflineService.currentUserId;

  // ---------------------------------------------------------------------------
  // Box + user helpers
  // ---------------------------------------------------------------------------

  Map<String, dynamic> _userMap(String id) =>
      OfflineService.asMap(OfflineService.box(OfflineService.usersBox).get(id));

  Iterable<Map<String, dynamic>> _allUsers() sync* {
    final box = OfflineService.box(OfflineService.usersBox);
    for (final key in box.keys) {
      yield OfflineService.asMap(box.get(key));
    }
  }

  FriendUser _friendFromUser(Map<String, dynamic> u) => FriendUser(
        userId: u['id'] as String,
        qosqanatId: u['qosqanat_id'] as String? ?? '',
        fullName: u['full_name'] as String? ?? '',
        level: (u['level'] as num?)?.toInt() ?? 1,
        akylPoints: (u['akyl_points'] as num?)?.toInt() ?? 0,
        profilePhotoUrl: u['profile_photo_url'] as String?,
        assistantType: AssistantType.fromWire(u['assistant_type'] as String?),
      );

  // =========================================================================
  // Friendships
  // =========================================================================

  Future<FriendUser?> searchUserByQosqanatId(String qid) async {
    final target = qid.trim().toUpperCase();
    if (target.isEmpty) return null;
    for (final u in _allUsers()) {
      if ((u['qosqanat_id'] as String? ?? '').toUpperCase() == target) {
        if (u['id'] == _uid) continue; // can't befriend yourself
        return _friendFromUser(u);
      }
    }
    return null;
  }

  Future<void> sendFriendRequest(String otherUserId) async {
    final me = _uid;
    if (me == null) throw const ApiException('Жүйеге кіріңіз');
    if (me == otherUserId) {
      throw const ApiException('Өзіңе сұраныс жібере алмайсың');
    }
    final box = OfflineService.box(OfflineService.friendsBox);
    for (final key in box.keys) {
      final f = OfflineService.asMap(box.get(key));
      if (_involves(f, me) && _involves(f, otherUserId)) {
        throw const ApiException('Бұл оқушыға сұраныс жіберілген');
      }
    }
    final (a, b) =
        me.compareTo(otherUserId) < 0 ? (me, otherUserId) : (otherUserId, me);
    final id = 'fr_${DateTime.now().millisecondsSinceEpoch}';
    await box.put(id, {
      'id': id,
      'user_a_id': a,
      'user_b_id': b,
      'initiated_by': me,
      'status': 'pending',
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'accepted_at': null,
    });
  }

  Future<void> acceptFriendRequest(String friendshipId) async {
    final box = OfflineService.box(OfflineService.friendsBox);
    final f = OfflineService.asMap(box.get(friendshipId));
    if (f.isEmpty) return;
    f['status'] = 'accepted';
    f['accepted_at'] = DateTime.now().toUtc().toIso8601String();
    await box.put(friendshipId, f);
  }

  Future<void> declineFriendRequest(String friendshipId) async {
    await OfflineService.box(OfflineService.friendsBox).delete(friendshipId);
  }

  Future<List<FriendUser>> getFriends() async {
    final me = _uid;
    if (me == null) return const [];
    final box = OfflineService.box(OfflineService.friendsBox);
    final result = <FriendUser>[];
    for (final key in box.keys) {
      final f = OfflineService.asMap(box.get(key));
      if (f['status'] != 'accepted' || !_involves(f, me)) continue;
      final otherId = _other(f, me);
      final u = _userMap(otherId);
      if (u.isNotEmpty) result.add(_friendFromUser(u));
    }
    return result;
  }

  Future<List<PendingRequest>> getPendingRequests() async {
    final me = _uid;
    if (me == null) return const [];
    final box = OfflineService.box(OfflineService.friendsBox);
    final result = <PendingRequest>[];
    for (final key in box.keys) {
      final f = OfflineService.asMap(box.get(key));
      if (f['status'] != 'pending' || !_involves(f, me)) continue;
      final otherId = _other(f, me);
      final u = _userMap(otherId);
      if (u.isEmpty) continue;
      result.add(PendingRequest(
        friendshipId: f['id'] as String,
        other: _friendFromUser(u),
        direction: f['initiated_by'] == me
            ? RequestDirection.outgoing
            : RequestDirection.incoming,
      ));
    }
    return result;
  }

  bool _involves(Map<String, dynamic> f, String uid) =>
      f['user_a_id'] == uid || f['user_b_id'] == uid;

  String _other(Map<String, dynamic> f, String uid) =>
      f['user_a_id'] == uid ? f['user_b_id'] as String : f['user_a_id'] as String;

  // =========================================================================
  // Battles
  // =========================================================================

  /// Picks [count] questions from the local curriculum. When [subjectId] is
  /// null, the pool is the union of every subject's questions.
  List<Map<String, dynamic>> _pickQuestions({
    String? subjectId,
    required int count,
  }) {
    final pool = <Question>[];
    for (final s in kCurriculum) {
      if (subjectId != null && s.id != subjectId) continue;
      for (final n in s.allNodes) {
        pool.addAll(n.questions);
      }
    }
    if (pool.isEmpty) return const [];
    final rng = math.Random();
    final shuffled = [...pool]..shuffle(rng);
    return [for (final q in shuffled.take(count)) _questionToWire(q)];
  }

  Map<String, dynamic> _questionToWire(Question q) => {
        'id': q.id,
        'type': q.type.name,
        'prompt': q.prompt,
        'options': q.options,
        'correct_index': q.correctIndex,
        'answer_is_true': q.answerIsTrue,
        'blank_answer': q.blankAnswer,
        'word_bank': q.wordBank,
        'explanation': q.explanation,
        'xp': q.xp,
      };

  /// Hydrates a wire-encoded question into [Question] for the battle screen.
  static Question questionFromWire(Map<String, dynamic> j) {
    final type = QuestionType.values.firstWhere(
      (e) => e.name == (j['type'] as String? ?? 'multipleChoice'),
      orElse: () => QuestionType.multipleChoice,
    );
    switch (type) {
      case QuestionType.multipleChoice:
        return Question.mc(
          id: j['id'] as String,
          prompt: j['prompt'] as String,
          options: List<String>.from(j['options'] as List? ?? const []),
          correctIndex: (j['correct_index'] as num?)?.toInt() ?? 0,
          explanation: j['explanation'] as String? ?? '',
        );
      case QuestionType.trueFalse:
        return Question.tf(
          id: j['id'] as String,
          prompt: j['prompt'] as String,
          answerIsTrue: j['answer_is_true'] as bool? ?? true,
          explanation: j['explanation'] as String? ?? '',
        );
      case QuestionType.fillBlank:
        return Question.fill(
          id: j['id'] as String,
          prompt: j['prompt'] as String,
          blankAnswer: j['blank_answer'] as String? ?? '',
          wordBank: List<String>.from(j['word_bank'] as List? ?? const []),
          explanation: j['explanation'] as String? ?? '',
        );
      case QuestionType.matchPairs:
        return Question.mc(
          id: j['id'] as String,
          prompt: j['prompt'] as String,
          options: List<String>.from(j['options'] as List? ?? const []),
          correctIndex: (j['correct_index'] as num?)?.toInt() ?? 0,
        );
    }
  }

  Map<String, dynamic> _battleRow(String id) =>
      OfflineService.asMap(OfflineService.box(OfflineService.battlesBox).get(id));

  Future<void> _saveBattle(Map<String, dynamic> row) async {
    await OfflineService.box(OfflineService.battlesBox)
        .put(row['id'], row);
  }

  /// Creates a battle invitation. Questions are sampled now so the live battle
  /// has its set ready.
  Future<Battle> createBattle({
    required String opponentId,
    required int questionCount,
    String? subjectId,
  }) async {
    final me = _uid;
    if (me == null) throw const ApiException('Жүйеге кіріңіз');
    final questions = _pickQuestions(subjectId: subjectId, count: questionCount);
    final id = 'battle_${DateTime.now().millisecondsSinceEpoch}';
    final row = {
      'id': id,
      'challenger_id': me,
      'opponent_id': opponentId,
      'challenger_score': 0,
      'opponent_score': 0,
      'question_count': questionCount,
      'subject_filter': subjectId,
      'status': 'pending',
      'questions_data': questions,
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'started_at': null,
      'ended_at': null,
      'winner_id': null,
    };
    await _saveBattle(row);
    return _hydrateBattle(row);
  }

  Future<void> acceptBattle(String battleId) async {
    final row = _battleRow(battleId);
    if (row.isEmpty) return;
    row['status'] = 'in_progress';
    row['started_at'] = DateTime.now().toUtc().toIso8601String();
    await _saveBattle(row);
  }

  Future<void> cancelBattle(String battleId) async {
    final row = _battleRow(battleId);
    if (row.isEmpty) return;
    row['status'] = 'cancelled';
    await _saveBattle(row);
  }

  Future<Battle?> getBattle(String battleId) async {
    final row = _battleRow(battleId);
    if (row.isEmpty) return null;
    return _hydrateBattle(row);
  }

  Future<Battle?> getBattleResult(String battleId) => getBattle(battleId);

  /// Returns the wire-encoded question set stored on a battle row.
  Future<List<Map<String, dynamic>>> getBattleQuestions(String battleId) async {
    final row = _battleRow(battleId);
    return questionsFromRow(row['questions_data']);
  }

  /// Increments the signed-in player's score by one for a correct answer.
  Future<void> submitBattleAnswer({
    required String battleId,
    required bool isChallenger,
    required bool isCorrect,
  }) async {
    if (!isCorrect) return;
    final row = _battleRow(battleId);
    if (row.isEmpty) return;
    final column = isChallenger ? 'challenger_score' : 'opponent_score';
    row[column] = ((row[column] as num?)?.toInt() ?? 0) + 1;
    await _saveBattle(row);
  }

  /// Marks the battle finished. Offline there's no second client, so this
  /// finalizes immediately: the simulated opponent's score is locked in, the
  /// status flips to `completed`, and the winner is decided.
  Future<Battle> markBattleFinished({
    required String battleId,
    required bool isChallenger,
  }) async {
    final row = _battleRow(battleId);
    if (row.isEmpty) {
      throw const ApiException('Шайқас табылмады');
    }

    final total = (row['question_count'] as num?)?.toInt() ?? 0;
    final myKey = isChallenger ? 'challenger_score' : 'opponent_score';
    final oppKey = isChallenger ? 'opponent_score' : 'challenger_score';
    final myScore = (row[myKey] as num?)?.toInt() ?? 0;

    // Lock a plausible final opponent score around the player's performance.
    var oppScore = (row[oppKey] as num?)?.toInt() ?? 0;
    final simulatedFloor = (total * 0.4).round();
    if (oppScore < simulatedFloor) {
      final rng = math.Random();
      oppScore = (myScore - 2 + rng.nextInt(5)).clamp(0, total);
    }
    row[oppKey] = oppScore;

    row['status'] = 'completed';
    row['ended_at'] = DateTime.now().toUtc().toIso8601String();
    final cs = (row['challenger_score'] as num?)?.toInt() ?? 0;
    final os = (row['opponent_score'] as num?)?.toInt() ?? 0;
    if (cs != os) {
      row['winner_id'] =
          cs > os ? row['challenger_id'] : row['opponent_id'];
    } else {
      row['winner_id'] = null;
    }
    await _saveBattle(row);
    return _hydrateBattle(row);
  }

  /// Emits the battle state over time. Offline this drives the whole flow:
  /// a `pending` battle is auto-accepted after a short delay (the opponent
  /// "joining"), the opponent's score creeps up while `in_progress`, and the
  /// final `completed` state is surfaced once [markBattleFinished] runs.
  Stream<Battle> watchBattle(String battleId) async* {
    final rng = math.Random();
    var acceptScheduled = false;
    DateTime? acceptAt;

    while (true) {
      final row = _battleRow(battleId);
      if (row.isEmpty) return;
      final status = row['status'] as String?;

      if (status == 'pending') {
        // Simulate the opponent accepting ~1.4s after creation.
        if (!acceptScheduled) {
          acceptScheduled = true;
          acceptAt = DateTime.now().add(const Duration(milliseconds: 1400));
        } else if (acceptAt != null && DateTime.now().isAfter(acceptAt)) {
          row['status'] = 'in_progress';
          row['started_at'] = DateTime.now().toUtc().toIso8601String();
          await _saveBattle(row);
        }
      } else if (status == 'in_progress') {
        // Creep the opponent's score upward so the match feels live.
        final total = (row['question_count'] as num?)?.toInt() ?? 0;
        final cap = (total * 0.7).round();
        final opp = (row['opponent_score'] as num?)?.toInt() ?? 0;
        if (opp < cap && rng.nextBool()) {
          row['opponent_score'] = opp + 1;
          await _saveBattle(row);
        }
      }

      yield _hydrateBattle(_battleRow(battleId));

      if (status == 'completed' || status == 'cancelled') return;
      await Future<void>.delayed(const Duration(milliseconds: 700));
    }
  }

  Battle _hydrateBattle(Map<String, dynamic> row) {
    final me = _uid;
    final isChallenger = row['challenger_id'] == me;
    final hostId = row['challenger_id'] as String;
    final oppId = row['opponent_id'] as String;
    final cs = (row['challenger_score'] as num?)?.toInt() ?? 0;
    final os = (row['opponent_score'] as num?)?.toInt() ?? 0;
    final status = BattleStatus.fromWire(row['status'] as String?);

    return Battle(
      id: row['id'] as String,
      host: BattlePlayer(
        userId: hostId,
        fullName: isChallenger ? 'Сен' : 'Қарсылас',
        score: cs,
      ),
      opponent: BattlePlayer(
        userId: oppId,
        fullName: isChallenger ? 'Қарсылас' : 'Сен',
        score: os,
      ),
      status: status,
      subjectId: row['subject_filter'] as String?,
      totalRounds: (row['question_count'] as num?)?.toInt() ?? 0,
      currentRound: 0,
      winnerId: row['winner_id'] as String?,
      createdAt: DateTime.tryParse(row['created_at'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  /// Extracts the wire-encoded questions list from a battle row's
  /// `questions_data` (stored as a raw list).
  static List<Map<String, dynamic>> questionsFromRow(dynamic raw) {
    if (raw is List) {
      return [for (final q in raw) Map<String, dynamic>.from(q as Map)];
    }
    if (raw is Map && raw['list'] is List) {
      return [
        for (final q in raw['list'] as List) Map<String, dynamic>.from(q as Map),
      ];
    }
    return const [];
  }

  // =========================================================================
  // Tournaments
  // =========================================================================

  List<String> _participants(String tournamentId) =>
      OfflineService.asStringList(OfflineService.box(
              OfflineService.tournamentParticipantsBox)
          .get(tournamentId));

  Future<List<Tournament>> getTournaments({TournamentStatus? status}) async {
    if (!OfflineService.isReady) return const [];
    final me = _uid;
    final box = OfflineService.box(OfflineService.tournamentsBox);
    final result = <Tournament>[];
    for (final key in box.keys) {
      final m = OfflineService.asMap(box.get(key));
      final st = TournamentStatus.fromWire(m['status'] as String?);
      if (status != null && st != status) continue;

      final parts = _participants(m['id'] as String);
      final prizePool = OfflineService.asMap(m['prize_pool']);
      result.add(Tournament(
        id: m['id'] as String,
        title: m['title'] as String? ?? '',
        description: m['description'] as String?,
        status: st,
        participantCount: parts.length,
        maxParticipants: (m['max_participants'] as num?)?.toInt() ?? 0,
        prizeCoins: (prizePool['coins'] as num?)?.toInt() ?? 0,
        entryAkyl: (prizePool['entry_akyl'] as num?)?.toInt() ?? 0,
        startsAt: DateTime.tryParse(m['start_date'] as String? ?? '') ??
            DateTime.now(),
        endsAt: m['end_date'] != null
            ? DateTime.tryParse(m['end_date'] as String)
            : null,
        isRegistered: me != null && parts.contains(me),
      ));
    }
    result.sort((a, b) => a.startsAt.compareTo(b.startsAt));
    return result;
  }

  Future<void> joinTournament(String tournamentId) async {
    final me = _uid;
    if (me == null) throw const ApiException('Жүйеге кіріңіз');
    final box = OfflineService.box(OfflineService.tournamentParticipantsBox);
    final parts = OfflineService.asStringList(box.get(tournamentId));
    if (parts.contains(me)) {
      throw const ApiException('Сен бұл турнирге қосылғансың');
    }
    parts.add(me);
    await box.put(tournamentId, parts);
  }

  Future<List<LeaderboardEntry>> getTournamentLeaderboard(
      String tournamentId) async {
    final ids = _participants(tournamentId);
    final users = [
      for (final id in ids)
        if (_userMap(id).isNotEmpty) _userMap(id),
    ];
    users.sort((a, b) =>
        ((b['akyl_points'] as num?)?.toInt() ?? 0) -
        ((a['akyl_points'] as num?)?.toInt() ?? 0));
    final rng = math.Random(tournamentId.hashCode);
    return [
      for (var i = 0; i < users.length; i++)
        LeaderboardEntry(
          userId: users[i]['id'] as String,
          qosqanatId: users[i]['qosqanat_id'] as String? ?? '',
          fullName: users[i]['full_name'] as String? ?? '',
          level: (users[i]['level'] as num?)?.toInt() ?? 1,
          profilePhotoUrl: users[i]['profile_photo_url'] as String?,
          // A tournament-specific score derived from akyl for variety.
          score: 200 + (users.length - i) * 35 + rng.nextInt(40),
          rank: i + 1,
        ),
    ];
  }

  // =========================================================================
  // Leaderboards / public profiles / profile-screen data
  // =========================================================================

  Future<List<RatingEntry>> getLeaderboard({
    required String scope, // 'global' | 'city' | 'school' | 'friends'
    String? scopeValue,
    int limit = 100,
  }) async {
    if (!OfflineService.isReady) return const [];
    final me = _uid;
    Set<String>? friendIds;
    if (scope == 'friends') {
      friendIds = {for (final f in await getFriends()) f.userId};
      if (me != null) friendIds.add(me);
    }

    final users = <Map<String, dynamic>>[];
    for (final u in _allUsers()) {
      switch (scope) {
        case 'city':
          if (u['city'] != scopeValue) continue;
        case 'school':
          if (u['school'] != scopeValue) continue;
        case 'friends':
          if (!friendIds!.contains(u['id'])) continue;
      }
      users.add(u);
    }
    users.sort((a, b) =>
        ((b['akyl_points'] as num?)?.toInt() ?? 0) -
        ((a['akyl_points'] as num?)?.toInt() ?? 0));

    return [
      for (var i = 0; i < users.length && i < limit; i++)
        RatingEntry(
          userId: users[i]['id'] as String,
          qosqanatId: users[i]['qosqanat_id'] as String? ?? '',
          fullName: users[i]['full_name'] as String? ?? '',
          city: users[i]['city'] as String?,
          school: users[i]['school'] as String?,
          grade: (users[i]['grade'] as num?)?.toInt(),
          level: (users[i]['level'] as num?)?.toInt() ?? 1,
          akylPoints: (users[i]['akyl_points'] as num?)?.toInt() ?? 0,
          profilePhotoUrl: users[i]['profile_photo_url'] as String?,
          rank: i + 1,
        ),
    ];
  }

  Future<int> schoolUserCount(String school) async {
    var count = 0;
    for (final u in _allUsers()) {
      if (u['school'] == school) count++;
    }
    return count;
  }

  Future<PublicProfile?> getPublicProfile(String userId) async {
    final u = _userMap(userId);
    if (u.isEmpty) return null;
    return PublicProfile(
      userId: u['id'] as String,
      qosqanatId: u['qosqanat_id'] as String? ?? '',
      fullName: u['full_name'] as String? ?? '',
      city: u['city'] as String?,
      school: u['school'] as String?,
      grade: (u['grade'] as num?)?.toInt(),
      level: (u['level'] as num?)?.toInt() ?? 1,
      xp: (u['xp'] as num?)?.toInt() ?? 0,
      akylPoints: (u['akyl_points'] as num?)?.toInt() ?? 0,
      coins: (u['coins'] as num?)?.toInt() ?? 0,
      currentStreak: (u['current_streak'] as num?)?.toInt() ?? 0,
      longestStreak: (u['longest_streak'] as num?)?.toInt() ?? 0,
      totalTasksCompleted: (u['total_tasks_completed'] as num?)?.toInt() ?? 0,
      totalBattlesWon: (u['total_battles_won'] as num?)?.toInt() ?? 0,
      assistantType: AssistantType.fromWire(u['assistant_type'] as String?),
      profilePhotoUrl: u['profile_photo_url'] as String?,
    );
  }

  Future<List<RecentBattleSummary>> getMyRecentBattles({int limit = 5}) async {
    final me = _uid;
    if (me == null) return const [];
    final box = OfflineService.box(OfflineService.battlesBox);
    final summaries = <RecentBattleSummary>[];
    for (final key in box.keys) {
      final row = OfflineService.asMap(box.get(key));
      if (row['status'] != 'completed') continue;
      final challenger = row['challenger_id'] as String?;
      final opponent = row['opponent_id'] as String?;
      if (challenger != me && opponent != me) continue;

      final iAmChallenger = challenger == me;
      final myScore = (iAmChallenger
              ? row['challenger_score']
              : row['opponent_score']) as num? ??
          0;
      final oppScore = (iAmChallenger
              ? row['opponent_score']
              : row['challenger_score']) as num? ??
          0;
      final oppId = (iAmChallenger ? opponent : challenger) ?? '';
      final oppUser = _userMap(oppId);
      summaries.add(RecentBattleSummary(
        battleId: row['id'] as String,
        opponentId: oppId,
        opponentName: oppUser['full_name'] as String? ?? 'Қарсылас',
        opponentQqId: oppUser['qosqanat_id'] as String? ?? '',
        opponentPhotoUrl: oppUser['profile_photo_url'] as String?,
        myScore: myScore.toInt(),
        opponentScore: oppScore.toInt(),
        won: row['winner_id'] == me ||
            (row['winner_id'] == null && myScore > oppScore),
        endedAt: DateTime.tryParse(row['ended_at'] as String? ?? '') ??
            DateTime.now(),
      ));
    }
    summaries.sort((a, b) => b.endedAt.compareTo(a.endedAt));
    return summaries.take(limit).toList();
  }

  Future<Map<DateTime, int>> getMyActivityDays(DateTime since) async {
    final me = _uid;
    if (me == null) return const {};
    final rows = OfflineService.asMapList(
        OfflineService.box(OfflineService.tasksBox).get(me));
    final map = <DateTime, int>{};
    for (final r in rows) {
      final completed = DateTime.tryParse(r['completed_at'] as String? ?? '');
      if (completed == null) continue;
      final c = completed.toUtc();
      if (c.isBefore(since)) continue;
      final day = DateTime.utc(c.year, c.month, c.day);
      map[day] = (map[day] ?? 0) + 1;
    }
    return map;
  }

  Future<Set<String>> getMyUnlockedAchievements() async {
    final me = _uid;
    if (me == null) return const {};
    return OfflineService.asStringList(
            OfflineService.box(OfflineService.achievementsBox).get(me))
        .toSet();
  }

  // =========================================================================
  // Profile mutations (photo "upload" + assistant swap)
  // =========================================================================

  /// Saves [bytes] to the app's temporary cache and stores the local file path
  /// on the user's record. Returns the path (rendered with `Image.file`).
  Future<String> uploadProfilePhoto({
    required List<int> bytes,
    required String filenameWithExt,
  }) async {
    final me = _uid;
    if (me == null) throw const ApiException('Жүйеге кіріңіз');
    final ext = filenameWithExt.contains('.')
        ? filenameWithExt.split('.').last.toLowerCase()
        : 'jpg';
    try {
      final dir = await getTemporaryDirectory();
      final path =
          '${dir.path}/profile_${me}_${DateTime.now().millisecondsSinceEpoch}.$ext';
      await File(path).writeAsBytes(bytes, flush: true);

      final users = OfflineService.box(OfflineService.usersBox);
      final map = OfflineService.asMap(users.get(me));
      map['profile_photo_url'] = path;
      await users.put(me, map);
      return path;
    } catch (e) {
      throw ApiException('Суретті сақтау мүмкін болмады: $e');
    }
  }

  Future<void> changeAssistant(AssistantType assistant) async {
    final me = _uid;
    if (me == null) throw const ApiException('Жүйеге кіріңіз');
    final users = OfflineService.box(OfflineService.usersBox);
    final map = OfflineService.asMap(users.get(me));
    map['assistant_type'] = assistant.wireValue;
    await users.put(me, map);
  }
}
