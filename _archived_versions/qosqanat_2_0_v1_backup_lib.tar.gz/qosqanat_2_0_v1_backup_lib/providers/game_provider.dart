import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/levels.dart';
import '../data/quests.dart';
import '../models/user.dart';
import '../services/game_service.dart';

/// One-shot celebration payload for a level-up, consumed by the UI then cleared.
@immutable
class LevelUpEvent {
  final int newLevel;
  final String title;
  final int coinReward;

  const LevelUpEvent({
    required this.newLevel,
    required this.title,
    required this.coinReward,
  });
}

/// One-shot celebration payload for a streak milestone.
@immutable
class StreakRewardEvent {
  final int streak;
  final int coinReward;

  const StreakRewardEvent({required this.streak, required this.coinReward});
}

/// Immutable snapshot of the player's gamified state.
@immutable
class GameState {
  final int level;
  final int xp; // total accumulated XP
  final int coins;
  final int akylPoints;
  final int currentStreak;
  final int longestStreak;
  final DateTime? lastLoginDate;

  /// Set when a level-up just happened; cleared by [GameNotifier.clearCelebrations].
  final LevelUpEvent? pendingLevelUp;

  /// Set when a streak milestone was just reached.
  final StreakRewardEvent? pendingStreakReward;

  const GameState({
    this.level = 1,
    this.xp = 0,
    this.coins = 0,
    this.akylPoints = 0,
    this.currentStreak = 0,
    this.longestStreak = 0,
    this.lastLoginDate,
    this.pendingLevelUp,
    this.pendingStreakReward,
  });

  // Derived from the XP curve.
  int get xpToNextLevel => xpToNextLevelFor(xp);
  int get xpIntoLevel => xpIntoCurrentLevel(xp);
  int get xpSpan => xpSpanForLevel(level);
  double get progress => levelProgress(xp);
  String get title => titleForLevel(level);

  GameState copyWith({
    int? level,
    int? xp,
    int? coins,
    int? akylPoints,
    int? currentStreak,
    int? longestStreak,
    DateTime? lastLoginDate,
    LevelUpEvent? pendingLevelUp,
    StreakRewardEvent? pendingStreakReward,
    bool clearLevelUp = false,
    bool clearStreakReward = false,
  }) {
    return GameState(
      level: level ?? this.level,
      xp: xp ?? this.xp,
      coins: coins ?? this.coins,
      akylPoints: akylPoints ?? this.akylPoints,
      currentStreak: currentStreak ?? this.currentStreak,
      longestStreak: longestStreak ?? this.longestStreak,
      lastLoginDate: lastLoginDate ?? this.lastLoginDate,
      pendingLevelUp:
          clearLevelUp ? null : (pendingLevelUp ?? this.pendingLevelUp),
      pendingStreakReward: clearStreakReward
          ? null
          : (pendingStreakReward ?? this.pendingStreakReward),
    );
  }
}

/// Helper mirrored here to keep the [GameState] getter terse.
int xpToNextLevelFor(int totalXp) => xpToNextLevel(totalXp);

final gameServiceProvider = Provider<GameService>((ref) => GameService());

/// Owns ALL gamification logic: XP, leveling, currencies, and streaks. Each
/// mutation updates state optimistically and persists to Supabase.
///
/// (Implemented with [Notifier] rather than the deprecated `StateNotifier` so
/// the analyzer stays clean under Riverpod 3.)
class GameNotifier extends Notifier<GameState> {
  @override
  GameState build() => const GameState();

  GameService get _service => ref.read(gameServiceProvider);

  /// Seeds state from a loaded profile (e.g. after login).
  void setGameState(AppUser user) {
    state = GameState(
      level: user.level,
      xp: user.xp,
      coins: user.coins,
      akylPoints: user.akylPoints,
      currentStreak: user.currentStreak,
      longestStreak: user.longestStreak,
    );
  }

  /// Adds XP, applying any level-ups (each grants its coin reward) and raising
  /// the [GameState.pendingLevelUp] celebration flag when the level increases.
  void addXp(int amount) {
    if (amount <= 0) return;
    final newXp = state.xp + amount;
    final newLevel = calculateLevel(newXp);

    var coins = state.coins;
    LevelUpEvent? levelUp;
    if (newLevel > state.level) {
      // Sum the coin rewards for every level crossed.
      var rewardCoins = 0;
      for (var l = state.level + 1; l <= newLevel; l++) {
        rewardCoins += coinRewardForLevel(l);
      }
      coins += rewardCoins;
      levelUp = LevelUpEvent(
        newLevel: newLevel,
        title: titleForLevel(newLevel),
        coinReward: rewardCoins,
      );
    }

    state = state.copyWith(
      xp: newXp,
      level: newLevel,
      coins: coins,
      pendingLevelUp: levelUp,
    );
    _persist();
  }

  void addCoins(int amount) {
    if (amount <= 0) return;
    state = state.copyWith(coins: state.coins + amount);
    _persist();
  }

  void addAkylPoints(int amount) {
    if (amount <= 0) return;
    state = state.copyWith(akylPoints: state.akylPoints + amount);
    _persist();
  }

  /// Attempts to spend [amount] coins. Returns `false` (and changes nothing)
  /// when the balance is insufficient.
  bool spendCoins(int amount) {
    if (amount <= 0) return true;
    if (state.coins < amount) return false;
    state = state.copyWith(coins: state.coins - amount);
    _persist();
    return true;
  }

  /// Forces a single level-up by topping XP up to the next threshold.
  void levelUp() {
    final remaining = xpToNextLevel(state.xp);
    if (remaining <= 0) return;
    addXp(remaining);
  }

  /// Evaluates the daily login streak against [lastLoginDate].
  ///
  /// Continues the streak if the last login was yesterday, resets to 1 if a day
  /// was missed, and grants the milestone coin reward (raising
  /// [GameState.pendingStreakReward]) when the new streak hits a milestone.
  void checkStreak({DateTime? now}) {
    final today = _dateOnly(now ?? DateTime.now());
    final last =
        state.lastLoginDate == null ? null : _dateOnly(state.lastLoginDate!);

    if (last != null && last == today) return; // already counted today

    int newStreak;
    if (last == null) {
      newStreak = 1;
    } else {
      final diff = today.difference(last).inDays;
      newStreak = diff == 1 ? state.currentStreak + 1 : 1;
    }

    final longest =
        newStreak > state.longestStreak ? newStreak : state.longestStreak;

    final reward = streakMilestoneReward(newStreak);
    final coins = reward == null ? state.coins : state.coins + reward;
    final streakEvent =
        reward == null ? null : StreakRewardEvent(streak: newStreak, coinReward: reward);

    state = state.copyWith(
      currentStreak: newStreak,
      longestStreak: longest,
      lastLoginDate: today,
      coins: coins,
      pendingStreakReward: streakEvent,
    );
    _persist();
  }

  /// Clears one-shot celebration flags after the UI has shown them.
  void clearCelebrations() {
    state = state.copyWith(clearLevelUp: true, clearStreakReward: true);
  }

  void _persist() {
    unawaited(_service.save(
      level: state.level,
      xp: state.xp,
      coins: state.coins,
      akylPoints: state.akylPoints,
      currentStreak: state.currentStreak,
      longestStreak: state.longestStreak,
      lastLoginDate: state.lastLoginDate,
    ));
  }

  static DateTime _dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);
}

final gameProvider =
    NotifierProvider<GameNotifier, GameState>(GameNotifier.new);
