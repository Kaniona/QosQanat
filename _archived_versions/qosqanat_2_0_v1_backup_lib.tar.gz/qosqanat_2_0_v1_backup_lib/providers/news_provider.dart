import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/news_item.dart';
import '../services/news_service.dart';

final newsServiceProvider = Provider<NewsService>((ref) => NewsService());

/// Published news for the Home feed. Refresh with
/// `ref.invalidate(newsProvider)` or `ref.refresh(newsProvider.future)`.
final newsProvider = FutureProvider<List<NewsItem>>((ref) {
  return ref.watch(newsServiceProvider).fetchPublished();
});
