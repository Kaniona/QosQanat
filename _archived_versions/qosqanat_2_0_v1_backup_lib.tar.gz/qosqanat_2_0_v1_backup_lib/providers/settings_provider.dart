import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// User-facing app language. (Kazakh is the default; Russian is offered as a
/// future toggle.)
enum AppLanguage { kk, ru }

@immutable
class AppSettings {
  final AppLanguage language;
  final bool soundEnabled;
  final bool vibrationEnabled;
  final bool animationsEnabled;
  final bool notificationsEnabled;
  final bool streakReminderEnabled;
  final int streakReminderHour; // 0–23
  final int streakReminderMinute; // 0–59

  const AppSettings({
    this.language = AppLanguage.kk,
    this.soundEnabled = true,
    this.vibrationEnabled = true,
    this.animationsEnabled = true,
    this.notificationsEnabled = true,
    this.streakReminderEnabled = true,
    this.streakReminderHour = 19,
    this.streakReminderMinute = 0,
  });

  AppSettings copyWith({
    AppLanguage? language,
    bool? soundEnabled,
    bool? vibrationEnabled,
    bool? animationsEnabled,
    bool? notificationsEnabled,
    bool? streakReminderEnabled,
    int? streakReminderHour,
    int? streakReminderMinute,
  }) {
    return AppSettings(
      language: language ?? this.language,
      soundEnabled: soundEnabled ?? this.soundEnabled,
      vibrationEnabled: vibrationEnabled ?? this.vibrationEnabled,
      animationsEnabled: animationsEnabled ?? this.animationsEnabled,
      notificationsEnabled:
          notificationsEnabled ?? this.notificationsEnabled,
      streakReminderEnabled:
          streakReminderEnabled ?? this.streakReminderEnabled,
      streakReminderHour: streakReminderHour ?? this.streakReminderHour,
      streakReminderMinute:
          streakReminderMinute ?? this.streakReminderMinute,
    );
  }
}

/// Persists user preferences via shared_preferences. Reads happen
/// synchronously after the first load; writes are best-effort fire-and-forget.
class SettingsNotifier extends Notifier<AppSettings> {
  static const _kLanguage = 'settings.language';
  static const _kSound = 'settings.sound';
  static const _kVibration = 'settings.vibration';
  static const _kAnimations = 'settings.animations';
  static const _kNotifications = 'settings.notifications';
  static const _kStreakReminder = 'settings.streak_reminder';
  static const _kStreakHour = 'settings.streak_hour';
  static const _kStreakMinute = 'settings.streak_minute';

  bool _loaded = false;

  @override
  AppSettings build() {
    _bootstrap();
    return const AppSettings();
  }

  Future<void> _bootstrap() async {
    if (_loaded) return;
    final prefs = await SharedPreferences.getInstance();
    final lang = prefs.getString(_kLanguage);
    state = state.copyWith(
      language: lang == 'ru' ? AppLanguage.ru : AppLanguage.kk,
      soundEnabled: prefs.getBool(_kSound) ?? true,
      vibrationEnabled: prefs.getBool(_kVibration) ?? true,
      animationsEnabled: prefs.getBool(_kAnimations) ?? true,
      notificationsEnabled: prefs.getBool(_kNotifications) ?? true,
      streakReminderEnabled: prefs.getBool(_kStreakReminder) ?? true,
      streakReminderHour: prefs.getInt(_kStreakHour) ?? 19,
      streakReminderMinute: prefs.getInt(_kStreakMinute) ?? 0,
    );
    _loaded = true;
  }

  Future<SharedPreferences> get _prefs => SharedPreferences.getInstance();

  void setLanguage(AppLanguage value) {
    state = state.copyWith(language: value);
    unawaited(_prefs.then((p) => p.setString(_kLanguage, value.name)));
  }

  void setSound(bool v) {
    state = state.copyWith(soundEnabled: v);
    unawaited(_prefs.then((p) => p.setBool(_kSound, v)));
  }

  void setVibration(bool v) {
    state = state.copyWith(vibrationEnabled: v);
    unawaited(_prefs.then((p) => p.setBool(_kVibration, v)));
  }

  void setAnimations(bool v) {
    state = state.copyWith(animationsEnabled: v);
    unawaited(_prefs.then((p) => p.setBool(_kAnimations, v)));
  }

  void setNotifications(bool v) {
    state = state.copyWith(notificationsEnabled: v);
    unawaited(_prefs.then((p) => p.setBool(_kNotifications, v)));
  }

  void setStreakReminderEnabled(bool v) {
    state = state.copyWith(streakReminderEnabled: v);
    unawaited(_prefs.then((p) => p.setBool(_kStreakReminder, v)));
  }

  void setStreakReminderTime({required int hour, required int minute}) {
    state = state.copyWith(
      streakReminderHour: hour,
      streakReminderMinute: minute,
    );
    unawaited(_prefs.then((p) async {
      await p.setInt(_kStreakHour, hour);
      await p.setInt(_kStreakMinute, minute);
    }));
  }
}

final settingsProvider =
    NotifierProvider<SettingsNotifier, AppSettings>(SettingsNotifier.new);
