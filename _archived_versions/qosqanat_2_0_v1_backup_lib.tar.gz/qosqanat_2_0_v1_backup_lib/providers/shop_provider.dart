import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/shop_items.dart';
import '../models/shop_item.dart';
import '../services/shop_service.dart';

/// Snapshot of the player's shop state: which items they own and what's
/// equipped in each slot. Drives the shop screen, the avatar preview, and
/// every [AvatarDisplay] elsewhere in the app.
@immutable
class ShopState {
  /// `item_id`s the player has purchased.
  final Set<String> owned;

  /// `slot → item_id` for currently equipped cosmetics.
  final Map<String, String> equipped;

  final bool loaded;

  const ShopState({
    this.owned = const {},
    this.equipped = const {},
    this.loaded = false,
  });

  ShopState copyWith({
    Set<String>? owned,
    Map<String, String>? equipped,
    bool? loaded,
  }) =>
      ShopState(
        owned: owned ?? this.owned,
        equipped: equipped ?? this.equipped,
        loaded: loaded ?? this.loaded,
      );

  bool isOwned(String itemId) => owned.contains(itemId);

  bool isEquipped(String itemId) {
    for (final v in equipped.values) {
      if (v == itemId) return true;
    }
    return false;
  }

  /// `slot → assetSvg` map ready for [AvatarBase.equipped].
  Map<String, String> equippedSlotsToSvg() {
    final out = <String, String>{};
    for (final entry in equipped.entries) {
      final item = shopItemById(entry.value);
      if (item != null && item.assetSvg.isNotEmpty) {
        out[entry.key] = item.assetSvg;
      }
    }
    return out;
  }
}

final shopServiceProvider = Provider<ShopService>((ref) => ShopService());

class ShopNotifier extends Notifier<ShopState> {
  bool _loading = false;

  @override
  ShopState build() => const ShopState();

  ShopService get _service => ref.read(shopServiceProvider);

  /// Loads inventory + equipment from Supabase. Idempotent.
  Future<void> ensureLoaded() async {
    if (state.loaded || _loading) return;
    _loading = true;
    final inventory = await _service.loadInventory();
    final equipment = await _service.loadEquipment();
    // The free school jacket is owned by everyone automatically.
    final owned = {...inventory, 'top_school_jacket', 'bottom_pants_school'};
    state = state.copyWith(
      owned: owned,
      equipped: equipment,
      loaded: true,
    );
    _loading = false;
  }

  /// Marks [itemId] as owned and persists (caller must have already deducted
  /// the price via [GameNotifier.spendCoins]).
  void recordPurchase(ShopItem item) {
    state = state.copyWith(owned: {...state.owned, item.id});
    unawaited(_service.insertInventory(
      itemId: item.id,
      purchasePrice: item.price,
    ));
  }

  /// Equips [item] in its slot. Replaces whatever was there.
  void equip(ShopItem item) {
    if (item.slot.isEmpty) return;
    final next = Map<String, String>.from(state.equipped);
    next[item.slot] = item.id;
    state = state.copyWith(equipped: next);
    unawaited(_service.equip(slot: item.slot, itemId: item.id));
  }

  /// Removes whatever is equipped in [slot].
  void unequip(String slot) {
    final next = Map<String, String>.from(state.equipped)..remove(slot);
    state = state.copyWith(equipped: next);
    unawaited(_service.unequip(slot));
  }
}

final shopProvider =
    NotifierProvider<ShopNotifier, ShopState>(ShopNotifier.new);

/// `slot → assetSvg` map intended for [AvatarBase.equipped]. Components anywhere
/// in the app can read this to render the assistant in their currently
/// equipped cosmetics.
final equippedSvgProvider = Provider<Map<String, String>>((ref) {
  return ref.watch(shopProvider).equippedSlotsToSvg();
});
