import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/enums.dart';
import '../models/user.dart';
import '../services/auth_service.dart';

/// Single shared [AuthService] instance.
final authServiceProvider = Provider<AuthService>((ref) => AuthService());

/// Emits offline auth-state changes. Drives router refresh + profile reloads.
final authStateChangesProvider = StreamProvider<void>((ref) {
  return ref.watch(authServiceProvider).onAuthChanged;
});

/// The signed-in user's profile, reloaded whenever auth state changes.
final currentUserProvider = FutureProvider<AppUser?>((ref) async {
  ref.watch(authStateChangesProvider);
  return ref.watch(authServiceProvider).loadCurrentProfile();
});

/// Whether a user session currently exists (synchronous snapshot).
final isAuthenticatedProvider = Provider<bool>((ref) {
  ref.watch(authStateChangesProvider);
  return ref.watch(authServiceProvider).isAuthenticated;
});

// =============================================================================
// Auth action controller (sign in / out, register, recovery, assistant choice)
// =============================================================================

/// Loading + error state for the in-flight auth action.
@immutable
class AuthActionState {
  final bool isLoading;
  final String? error;

  const AuthActionState({this.isLoading = false, this.error});

  AuthActionState copyWith({bool? isLoading, String? error}) {
    return AuthActionState(
      isLoading: isLoading ?? this.isLoading,
      error: error,
    );
  }

  static const idle = AuthActionState();
}

class AuthController extends Notifier<AuthActionState> {
  @override
  AuthActionState build() => AuthActionState.idle;

  AuthService get _service => ref.read(authServiceProvider);

  /// Runs [action], surfacing loading/error state. Returns `true` on success.
  Future<bool> _run(Future<void> Function() action) async {
    state = const AuthActionState(isLoading: true);
    try {
      await action();
      ref.invalidate(currentUserProvider);
      state = AuthActionState.idle;
      return true;
    } on AuthFailure catch (e) {
      state = AuthActionState(error: e.message);
      return false;
    } catch (e) {
      state = AuthActionState(error: e.toString());
      return false;
    }
  }

  void clearError() => state = AuthActionState.idle;

  Future<bool> signIn({required String phoneE164, required String password}) {
    return _run(() => _service.signInWithPhone(
          phoneE164: phoneE164,
          password: password,
        ));
  }

  Future<bool> register({
    required String phoneE164,
    required String password,
    required String fullName,
    required String iin,
    required String city,
    required String school,
    required int grade,
  }) {
    return _run(() => _service.register(
          phoneE164: phoneE164,
          password: password,
          fullName: fullName,
          iin: iin,
          city: city,
          school: school,
          grade: grade,
        ));
  }

  Future<bool> chooseAssistant({
    required AssistantType assistant,
    required int giftCoins,
  }) {
    return _run(() => _service.chooseAssistant(
          assistant: assistant,
          giftCoins: giftCoins,
        ));
  }

  Future<bool> sendRecoveryCode(String phoneE164) {
    return _run(() => _service.sendRecoveryCode(phoneE164));
  }

  Future<bool> verifyRecoveryCode({
    required String phoneE164,
    required String token,
  }) {
    return _run(() => _service.verifyRecoveryCode(
          phoneE164: phoneE164,
          token: token,
        ));
  }

  Future<bool> updatePassword(String newPassword) {
    return _run(() => _service.updatePassword(newPassword));
  }

  Future<void> signOut() async {
    await _service.signOut();
    ref.invalidate(currentUserProvider);
  }
}

final authControllerProvider =
    NotifierProvider<AuthController, AuthActionState>(AuthController.new);
