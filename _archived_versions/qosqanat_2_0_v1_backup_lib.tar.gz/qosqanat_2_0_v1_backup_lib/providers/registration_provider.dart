import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/utils/password_strength.dart';
import '../core/utils/phone_formatter.dart';
import '../core/utils/validators.dart';

/// Accumulated data across the 4-step registration wizard.
@immutable
class RegistrationData {
  final String fullName;
  final String phone; // formatted: +7 (XXX) XXX-XX-XX
  final String iin;
  final String password;
  final String confirmPassword;
  final String? city;
  final String school;
  final int? grade;
  final bool agreedTerms;
  final bool agreedPrivacy;

  const RegistrationData({
    this.fullName = '',
    this.phone = '',
    this.iin = '',
    this.password = '',
    this.confirmPassword = '',
    this.city,
    this.school = '',
    this.grade,
    this.agreedTerms = false,
    this.agreedPrivacy = false,
  });

  RegistrationData copyWith({
    String? fullName,
    String? phone,
    String? iin,
    String? password,
    String? confirmPassword,
    String? city,
    String? school,
    int? grade,
    bool? agreedTerms,
    bool? agreedPrivacy,
  }) {
    return RegistrationData(
      fullName: fullName ?? this.fullName,
      phone: phone ?? this.phone,
      iin: iin ?? this.iin,
      password: password ?? this.password,
      confirmPassword: confirmPassword ?? this.confirmPassword,
      city: city ?? this.city,
      school: school ?? this.school,
      grade: grade ?? this.grade,
      agreedTerms: agreedTerms ?? this.agreedTerms,
      agreedPrivacy: agreedPrivacy ?? this.agreedPrivacy,
    );
  }

  // --- Derived validation -----------------------------------------------------
  PasswordReport get passwordReport => PasswordReport.evaluate(password);

  bool get passwordsMatch =>
      confirmPassword.isNotEmpty && password == confirmPassword;

  bool get isStep1Valid =>
      Validators.fullName(fullName) == null &&
      Validators.phone(phone) == null &&
      Validators.iin(iin) == null;

  bool get isStep2Valid => passwordReport.isValid && passwordsMatch;

  bool get isStep3Valid =>
      city != null && school.trim().isNotEmpty && grade != null;

  bool get isStep4Valid => agreedTerms && agreedPrivacy;

  String get phoneE164 => KzPhoneInputFormatter.toE164(phone);
}

class RegistrationController extends Notifier<RegistrationData> {
  @override
  RegistrationData build() => const RegistrationData();

  void setFullName(String v) => state = state.copyWith(fullName: v);
  void setPhone(String v) => state = state.copyWith(phone: v);
  void setIin(String v) => state = state.copyWith(iin: v);
  void setPassword(String v) => state = state.copyWith(password: v);
  void setConfirmPassword(String v) =>
      state = state.copyWith(confirmPassword: v);
  void setCity(String? v) => state = state.copyWith(city: v);
  void setSchool(String v) => state = state.copyWith(school: v);
  void setGrade(int v) => state = state.copyWith(grade: v);
  void setAgreedTerms(bool v) => state = state.copyWith(agreedTerms: v);
  void setAgreedPrivacy(bool v) => state = state.copyWith(agreedPrivacy: v);

  void reset() => state = const RegistrationData();
}

final registrationProvider =
    NotifierProvider<RegistrationController, RegistrationData>(
  RegistrationController.new,
);
