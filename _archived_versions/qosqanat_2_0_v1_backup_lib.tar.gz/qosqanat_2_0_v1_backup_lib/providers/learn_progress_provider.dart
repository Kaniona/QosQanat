import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/learn_progress_service.dart';

/// Per-node progress snapshot. A node is `mastered` when the best score is
/// 90–100% (rendered as 3 gold stars on the map).
@immutable
class NodeProgress {
  final String nodeId;
  final String subjectId;
  final String moduleId;

  /// 'completed' or 'mastered'. Locked/available are derived from the
  /// curriculum order — see [LearnProgressNotifier.isUnlocked].
  final String status;
  final int bestScore; // 0–100
  final int attempts;
  final int stars; // 0–3, derived from best score

  const NodeProgress({
    required this.nodeId,
    required this.subjectId,
    required this.moduleId,
    required this.status,
    required this.bestScore,
    required this.attempts,
    required this.stars,
  });

  bool get isCompleted => status == 'completed' || status == 'mastered';
  bool get isMastered => status == 'mastered';

  NodeProgress copyWith({
    String? status,
    int? bestScore,
    int? attempts,
    int? stars,
  }) =>
      NodeProgress(
        nodeId: nodeId,
        subjectId: subjectId,
        moduleId: moduleId,
        status: status ?? this.status,
        bestScore: bestScore ?? this.bestScore,
        attempts: attempts ?? this.attempts,
        stars: stars ?? this.stars,
      );

  static int starsForScore(int score) {
    if (score >= 90) return 3;
    if (score >= 60) return 2;
    return 1;
  }
}

final learnProgressServiceProvider =
    Provider<LearnProgressService>((ref) => LearnProgressService());

/// Map of `node_id -> NodeProgress` for the signed-in user. Built once from
/// Supabase, then updated optimistically on each node completion.
class LearnProgressNotifier extends Notifier<Map<String, NodeProgress>> {
  bool _loaded = false;

  @override
  Map<String, NodeProgress> build() => const {};

  LearnProgressService get _service => ref.read(learnProgressServiceProvider);

  /// Lazily loads progress from Supabase the first time it's needed.
  Future<void> ensureLoaded() async {
    if (_loaded) return;
    _loaded = true;
    final rows = await _service.loadAll();
    final map = <String, NodeProgress>{};
    for (final r in rows) {
      final nodeId = r['node_id'] as String? ?? '';
      if (nodeId.isEmpty) continue;
      final best = (r['best_score'] as num?)?.toInt() ?? 0;
      map[nodeId] = NodeProgress(
        nodeId: nodeId,
        subjectId: r['subject_id'] as String? ?? '',
        moduleId: r['module_id'] as String? ?? '',
        status: r['status'] as String? ?? 'completed',
        bestScore: best,
        attempts: (r['attempts'] as num?)?.toInt() ?? 0,
        stars: NodeProgress.starsForScore(best),
      );
    }
    state = map;
  }

  NodeProgress? progressFor(String nodeId) => state[nodeId];

  /// A node is unlocked iff every prior node in the same subject has been
  /// completed (or it is the very first node).
  bool isUnlocked({required List<String> orderedNodeIds, required String nodeId}) {
    final idx = orderedNodeIds.indexOf(nodeId);
    if (idx <= 0) return true;
    for (var i = 0; i < idx; i++) {
      if (!(state[orderedNodeIds[i]]?.isCompleted ?? false)) return false;
    }
    return true;
  }

  /// The next node a player should tackle in a subject — the first unlocked,
  /// uncompleted node, or `null` when the subject is fully mastered.
  String? currentNodeId(List<String> orderedNodeIds) {
    for (final id in orderedNodeIds) {
      if (!(state[id]?.isCompleted ?? false)) return id;
    }
    return null;
  }

  int completedCount(List<String> orderedNodeIds) =>
      orderedNodeIds.where((id) => state[id]?.isCompleted ?? false).length;

  /// Records a node completion, persists it, and returns the resulting record.
  /// Keeps the higher of the old / new best score.
  NodeProgress recordCompletion({
    required String subjectId,
    required String moduleId,
    required String nodeId,
    required int scorePercent,
    required int xpEarned,
    required int coinsEarned,
    required int akylEarned,
  }) {
    final prev = state[nodeId];
    final attempts = (prev?.attempts ?? 0) + 1;
    final bestScore = scorePercent > (prev?.bestScore ?? 0)
        ? scorePercent
        : (prev?.bestScore ?? 0);
    final stars = NodeProgress.starsForScore(bestScore);
    final status = bestScore >= 90 ? 'mastered' : 'completed';

    final next = NodeProgress(
      nodeId: nodeId,
      subjectId: subjectId,
      moduleId: moduleId,
      status: status,
      bestScore: bestScore,
      attempts: attempts,
      stars: stars,
    );
    state = {...state, nodeId: next};

    unawaited(_service.upsertCompletion(
      subjectId: subjectId,
      moduleId: moduleId,
      nodeId: nodeId,
      status: status,
      bestScore: bestScore,
      attempts: attempts,
      xpEarned: xpEarned,
      coinsEarned: coinsEarned,
      akylEarned: akylEarned,
    ));

    return next;
  }
}

final learnProgressProvider =
    NotifierProvider<LearnProgressNotifier, Map<String, NodeProgress>>(
  LearnProgressNotifier.new,
);
