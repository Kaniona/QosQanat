import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/battle.dart';
import '../models/enums.dart';
import '../models/tournament.dart';
import '../services/api_service.dart';

/// Shared API client used by every social/competitive surface.
final apiServiceProvider = Provider<ApiService>((ref) => ApiService());

// =============================================================================
// Friends
// =============================================================================

final friendsProvider = FutureProvider<List<FriendUser>>((ref) async {
  return ref.read(apiServiceProvider).getFriends();
});

final pendingRequestsProvider =
    FutureProvider<List<PendingRequest>>((ref) async {
  return ref.read(apiServiceProvider).getPendingRequests();
});

/// Incoming-request count, used to badge the "Өтінімдер" tab.
final incomingRequestCountProvider = Provider<int>((ref) {
  final pending = ref.watch(pendingRequestsProvider).asData?.value ?? const [];
  return pending.where((r) => r.direction == RequestDirection.incoming).length;
});

// =============================================================================
// Battles — realtime
// =============================================================================

/// Streams every change to a single battle row. Used by the waiting screen
/// (host watches for opponent acceptance), the battle screen (live opponent
/// score), and the result screen (status flips to `completed`).
final battleStreamProvider =
    StreamProvider.family.autoDispose<Battle, String>((ref, battleId) {
  return ref.read(apiServiceProvider).watchBattle(battleId);
});

final battleSnapshotProvider =
    FutureProvider.family<Battle?, String>((ref, battleId) async {
  return ref.read(apiServiceProvider).getBattle(battleId);
});

// =============================================================================
// Tournaments
// =============================================================================

final tournamentsProvider = FutureProvider.family<List<Tournament>,
    TournamentStatus?>((ref, status) async {
  return ref.read(apiServiceProvider).getTournaments(status: status);
});

final tournamentLeaderboardProvider =
    FutureProvider.family<List<LeaderboardEntry>, String>(
        (ref, tournamentId) async {
  return ref.read(apiServiceProvider).getTournamentLeaderboard(tournamentId);
});

// =============================================================================
// Rating / Profile
// =============================================================================

/// Scope of the global ratings screen.
enum RatingScope { global, city, school, friends }

@immutable
class RatingRequest {
  final RatingScope scope;
  final String? value; // city or school name

  const RatingRequest(this.scope, [this.value]);

  @override
  bool operator ==(Object other) =>
      other is RatingRequest && other.scope == scope && other.value == value;

  @override
  int get hashCode => Object.hash(scope, value);
}

final leaderboardProvider =
    FutureProvider.family<List<RatingEntry>, RatingRequest>(
        (ref, req) async {
  return ref.read(apiServiceProvider).getLeaderboard(
        scope: req.scope.name,
        scopeValue: req.value,
      );
});

final schoolUserCountProvider =
    FutureProvider.family<int, String>((ref, school) async {
  return ref.read(apiServiceProvider).schoolUserCount(school);
});

final recentBattlesProvider =
    FutureProvider<List<RecentBattleSummary>>((ref) async {
  return ref.read(apiServiceProvider).getMyRecentBattles();
});

final activityHeatmapProvider =
    FutureProvider.family<Map<DateTime, int>, DateTime>((ref, since) async {
  return ref.read(apiServiceProvider).getMyActivityDays(since);
});

final unlockedAchievementsProvider =
    FutureProvider<Set<String>>((ref) async {
  return ref.read(apiServiceProvider).getMyUnlockedAchievements();
});
