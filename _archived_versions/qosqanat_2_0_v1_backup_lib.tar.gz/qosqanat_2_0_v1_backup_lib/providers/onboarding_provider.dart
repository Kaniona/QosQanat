import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Tracks one-time onboarding milestones that should never repeat on a device.
///
/// Currently holds the first-run spotlight tutorial flag. State starts `false`
/// (not seen) and flips to `true` once the tour completes, persisted via
/// shared_preferences so the tour shows exactly once.
class OnboardingNotifier extends Notifier<bool> {
  static const _kTutorialSeen = 'onboarding.tutorial_seen';

  @override
  bool build() {
    _bootstrap();
    return false;
  }

  Future<void> _bootstrap() async {
    final prefs = await SharedPreferences.getInstance();
    state = prefs.getBool(_kTutorialSeen) ?? false;
  }

  /// Marks the tutorial as seen and persists the flag.
  Future<void> markTutorialSeen() async {
    if (state) return;
    state = true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kTutorialSeen, true);
  }

  /// Resets the flag (debug/testing only).
  Future<void> reset() async {
    state = false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kTutorialSeen);
  }
}

/// `true` once the first-run tutorial has been completed on this device.
final tutorialSeenProvider =
    NotifierProvider<OnboardingNotifier, bool>(OnboardingNotifier.new);
