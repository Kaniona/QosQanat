/// Lightweight Kazakh date formatting (avoids needing intl locale data).
library;

const List<String> _kkMonths = [
  'қаңтар',
  'ақпан',
  'наурыз',
  'сәуір',
  'мамыр',
  'маусым',
  'шілде',
  'тамыз',
  'қыркүйек',
  'қазан',
  'қараша',
  'желтоқсан',
];

/// Formats a date as e.g. `5 маусым, 2026`.
String kazakhDate(DateTime date) {
  final d = date.toLocal();
  return '${d.day} ${_kkMonths[d.month - 1]}, ${d.year}';
}

/// A time-of-day Kazakh greeting: таң / күн / кеш / түн.
String kazakhGreeting([DateTime? now]) {
  final hour = (now ?? DateTime.now()).hour;
  if (hour >= 5 && hour < 12) return 'Қайырлы таң';
  if (hour >= 12 && hour < 18) return 'Қайырлы күн';
  if (hour >= 18 && hour < 23) return 'Қайырлы кеш';
  return 'Қайырлы түн';
}
