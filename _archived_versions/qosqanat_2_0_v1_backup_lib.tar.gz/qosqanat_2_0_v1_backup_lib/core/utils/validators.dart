import '../constants/auth_strings.dart';
import 'phone_formatter.dart';

/// Form field validators returning a Kazakh error message, or `null` when the
/// value is valid (matching Flutter's [FormFieldValidator] contract).
class Validators {
  Validators._();

  static String? required(String? value) {
    if (value == null || value.trim().isEmpty) return AuthStrings.errRequired;
    return null;
  }

  static String? fullName(String? value) {
    if (value == null || value.trim().isEmpty) return AuthStrings.errRequired;
    if (value.trim().length < 3) return AuthStrings.errNameShort;
    return null;
  }

  /// Valid when there are exactly 10 subscriber digits (E.164 `+7XXXXXXXXXX`).
  static String? phone(String? value) {
    if (value == null || value.trim().isEmpty) return AuthStrings.errRequired;
    if (KzPhoneInputFormatter.digitsOf(value).length != 10) {
      return AuthStrings.errPhoneInvalid;
    }
    return null;
  }

  static String? iin(String? value) {
    if (value == null || value.trim().isEmpty) return AuthStrings.errRequired;
    if (!RegExp(r'^[0-9]{12}$').hasMatch(value.trim())) {
      return AuthStrings.errIinInvalid;
    }
    return null;
  }

  static String? password(String? value) {
    if (value == null || value.isEmpty) return AuthStrings.errRequired;
    if (value.length < 8) return AuthStrings.errPasswordShort;
    return null;
  }

  static String? otp(String? value) {
    if (value == null || value.trim().isEmpty) return AuthStrings.errRequired;
    if (!RegExp(r'^[0-9]{4}$').hasMatch(value.trim())) {
      return AuthStrings.errOtpInvalid;
    }
    return null;
  }
}
