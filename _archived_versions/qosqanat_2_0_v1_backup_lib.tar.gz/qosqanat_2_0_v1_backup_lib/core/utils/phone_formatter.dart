import 'package:flutter/services.dart';

/// Formats Kazakhstan phone input as `+7 (XXX) XXX-XX-XX` while the user types.
///
/// Internally keeps only the 10 subscriber digits; the leading country code 7
/// is fixed. Use [digitsOf] / [toE164] to extract canonical forms.
class KzPhoneInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    // Strip everything to raw digits, drop a leading 7/8 country prefix.
    var digits = newValue.text.replaceAll(RegExp(r'\D'), '');
    if (digits.startsWith('8')) digits = digits.substring(1);
    if (digits.startsWith('7')) digits = digits.substring(1);
    if (digits.length > 10) digits = digits.substring(0, 10);

    final formatted = _format(digits);
    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }

  static String _format(String d) {
    final b = StringBuffer('+7');
    if (d.isEmpty) return b.toString();
    b.write(' (');
    b.write(d.substring(0, d.length.clamp(0, 3)));
    if (d.length >= 3) b.write(') ');
    if (d.length > 3) b.write(d.substring(3, d.length.clamp(3, 6)));
    if (d.length > 6) b.write('-${d.substring(6, d.length.clamp(6, 8))}');
    if (d.length > 8) b.write('-${d.substring(8, d.length.clamp(8, 10))}');
    return b.toString();
  }

  /// Returns the 10 subscriber digits from a formatted/raw string.
  static String digitsOf(String input) {
    var digits = input.replaceAll(RegExp(r'\D'), '');
    if (digits.startsWith('8')) digits = digits.substring(1);
    if (digits.startsWith('7')) digits = digits.substring(1);
    if (digits.length > 10) digits = digits.substring(0, 10);
    return digits;
  }

  /// Converts any formatted/raw input to E.164 (`+7XXXXXXXXXX`).
  static String toE164(String input) => '+7${digitsOf(input)}';
}
