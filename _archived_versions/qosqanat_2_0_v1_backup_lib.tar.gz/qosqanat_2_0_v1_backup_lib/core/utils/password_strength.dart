import 'package:flutter/material.dart';

import '../constants/auth_strings.dart';
import '../theme/app_colors.dart';

/// Discrete password strength levels.
enum PasswordStrength { empty, weak, medium, strong }

/// Result of evaluating a password: its [strength], the satisfied requirement
/// flags, and presentation helpers (label, color, 0–1 bar fill).
class PasswordReport {
  final PasswordStrength strength;
  final bool hasMinLength;
  final bool hasLetters;
  final bool hasDigits;
  final bool hasSpecial;

  const PasswordReport({
    required this.strength,
    required this.hasMinLength,
    required this.hasLetters,
    required this.hasDigits,
    required this.hasSpecial,
  });

  /// A password is acceptable once it is at least 8 chars and mixes letters
  /// with digits.
  bool get isValid => hasMinLength && hasLetters && hasDigits;

  String get label {
    switch (strength) {
      case PasswordStrength.strong:
        return AuthStrings.strengthStrong;
      case PasswordStrength.medium:
        return AuthStrings.strengthMedium;
      case PasswordStrength.weak:
      case PasswordStrength.empty:
        return AuthStrings.strengthWeak;
    }
  }

  Color get color {
    switch (strength) {
      case PasswordStrength.strong:
        return AppColors.jade;
      case PasswordStrength.medium:
        return AppColors.sunset;
      case PasswordStrength.weak:
      case PasswordStrength.empty:
        return AppColors.coral;
    }
  }

  /// Bar fill ratio, 0.0–1.0.
  double get fillRatio {
    switch (strength) {
      case PasswordStrength.strong:
        return 1.0;
      case PasswordStrength.medium:
        return 0.66;
      case PasswordStrength.weak:
        return 0.33;
      case PasswordStrength.empty:
        return 0.0;
    }
  }

  static PasswordReport evaluate(String password) {
    final hasMinLength = password.length >= 8;
    final hasLetters = RegExp(r'[A-Za-zӘәҒғҚқҢңӨөҰұҮүҺһІі]').hasMatch(password);
    final hasDigits = RegExp(r'[0-9]').hasMatch(password);
    final hasSpecial = RegExp(r'''[!@#\$%^&*(),.?":{}|<>_\-]''').hasMatch(password);

    PasswordStrength strength;
    if (password.isEmpty) {
      strength = PasswordStrength.empty;
    } else {
      final score = [hasMinLength, hasLetters, hasDigits, hasSpecial]
          .where((v) => v)
          .length;
      if (score >= 4 && hasMinLength) {
        strength = PasswordStrength.strong;
      } else if (score >= 3 && hasMinLength) {
        strength = PasswordStrength.medium;
      } else {
        strength = PasswordStrength.weak;
      }
    }

    return PasswordReport(
      strength: strength,
      hasMinLength: hasMinLength,
      hasLetters: hasLetters,
      hasDigits: hasDigits,
      hasSpecial: hasSpecial,
    );
  }
}
