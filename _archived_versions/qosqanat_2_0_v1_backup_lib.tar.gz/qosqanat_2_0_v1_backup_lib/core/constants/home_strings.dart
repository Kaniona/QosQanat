/// Kazakh strings for the Home screen.
class HomeStrings {
  HomeStrings._();

  static const String newsTitle = '📢 Жаңалықтар';
  static const String readMore = 'Толығырақ →';
  static const String emptyNews = 'Әзірге жаңалық жоқ';
  static const String newsError = 'Жаңалықтарды жүктеу мүмкін болмады';
  static const String levelShort = 'LVL';
  static const String openDrawerHint = 'Мәзір';
}
