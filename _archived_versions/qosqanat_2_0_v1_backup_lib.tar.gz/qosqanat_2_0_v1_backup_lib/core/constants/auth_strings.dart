/// Kazakh strings specific to the authentication & onboarding flow.
class AuthStrings {
  AuthStrings._();

  // Splash / Welcome
  static const String splashTagline = 'Білімнің екі қанаты';
  static const String welcomeTitle = 'QosQanat-қа қош келдің!';
  static const String welcomeSubtitle =
      'Оқуды ойынға айналдыр. Серігіңмен бірге білім шыңына шық!';
  static const String register = 'Тіркелу';
  static const String login = 'Кіру';
  static const String langKaz = 'ҚАЗ';
  static const String langRus = 'РУС';

  // Login
  static const String loginTitle = 'Қайта оралғаныңа қуаныштымыз!';
  static const String phoneLabel = 'Телефон нөмірі';
  static const String phoneHint = '+7 (___) ___-__-__';
  static const String passwordLabel = 'Құпиясөз';
  static const String passwordHint = 'Құпиясөзіңді енгіз';
  static const String forgotPassword = 'Құпиясөзді ұмыттың ба?';
  static const String loginButton = 'Кіру';
  static const String noAccount = 'Аккаунтың жоқ па? ';
  static const String registerLink = 'Тіркел';
  static const String loginError = 'Телефон немесе құпиясөз қате';

  // Registration — common
  static const String haveAccount = 'Аккаунтың бар ма? ';
  static const String loginLink = 'Кір';
  static const String registerButton = 'Тіркелу';

  // Registration — Step 1
  static const String step1Title = 'Өзің туралы айт';
  static const String fullNameLabel = 'Толық аты-жөні';
  static const String fullNameHint = 'Мысалы: Алихан Сейтжанұлы';
  static const String iinLabel = 'ЖСН';
  static const String iinHint = '12 сан';
  static const String iinHelper = 'ЖСН 12 саннан тұрады';

  // Registration — Step 2
  static const String step2Title = 'Құпиясөз жаса';
  static const String confirmPasswordLabel = 'Құпиясөзді растау';
  static const String confirmPasswordHint = 'Құпиясөзді қайта енгіз';
  static const String strengthWeak = 'Әлсіз';
  static const String strengthMedium = 'Орташа';
  static const String strengthStrong = 'Мықты';
  static const String reqMinLength = 'Кемінде 8 таңба';
  static const String reqLetters = 'Әріптер бар';
  static const String reqDigits = 'Сандар бар';
  static const String reqSpecial = 'Арнайы таңба бар';
  static const String passwordsMatch = 'Құпиясөздер сәйкес ✓';
  static const String passwordsNoMatch = 'Құпиясөздер сәйкес емес';

  // Registration — Step 3
  static const String step3Title = 'Мектебің туралы';
  static const String cityLabel = 'Қала';
  static const String cityHint = 'Қалаңды таңда';
  static const String schoolLabel = 'Мектеп';
  static const String schoolHint = 'Мысалы: №25 мектеп-гимназия';
  static const String gradeLabel = 'Сынып';

  // Registration — Step 4
  static const String step4Title = 'Барлығы дұрыс па?';
  static const String summarySubtitle = 'Мәліметтеріңді тексеріп шық';
  static const String agreementTerms =
      'Қызмет көрсету шарттарымен келісемін';
  static const String agreementPrivacy =
      'Жеке деректерді өңдеуге келісім беремін';

  // Forgot password
  static const String forgotTitle = 'Құпиясөзді қалпына келтіру';
  static const String forgotPhonePrompt =
      'Тіркелген телефон нөміріңді енгіз, біз растау кодын жібереміз';
  static const String sendCode = 'Кодты жіберу';
  static const String otpTitle = 'Растау коды';
  static const String otpPrompt = 'Телефоныңа жіберілген 4 таңбалы кодты енгіз';
  static const String resendCode = 'Кодты қайта жіберу';
  static const String verifyCode = 'Растау';
  static const String newPasswordTitle = 'Жаңа құпиясөз';
  static const String newPasswordPrompt = 'Жаңа құпиясөзіңді ойлап тап';
  static const String savePassword = 'Сақтау';
  static const String resetSuccessTitle = 'Дайын!';
  static const String resetSuccessBody =
      'Құпиясөзің сәтті жаңартылды. Енді кіре аласың.';
  static const String backToLogin = 'Кіру бетіне оралу';

  // Assistant selection
  static const String assistantTitle = 'Өз серігіңді таңда!';
  static const String assistantSubtitle =
      'Ол сенімен бірге оқиды, жеңістеріңді тойлап, қиында қолдайды';
  static const String assistantConfirm = 'Таңдадым! ✓';
  static const String giftTitle = 'Саған сыйлық!';
  static const String giftBody = 'Саған 100 монета сыйладым!';
  static const String giftButton = 'Рахмет! Бастаймыз';

  // Validation errors
  static const String errRequired = 'Бұл өрісті толтыр';
  static const String errPhoneInvalid = 'Телефон нөмірі толық емес';
  static const String errIinInvalid = 'ЖСН 12 саннан тұруы керек';
  static const String errNameShort = 'Аты-жөнін толық жаз';
  static const String errPasswordShort = 'Кемінде 8 таңба болуы керек';
  static const String errOtpInvalid = 'Код 4 таңбадан тұруы керек';
}
