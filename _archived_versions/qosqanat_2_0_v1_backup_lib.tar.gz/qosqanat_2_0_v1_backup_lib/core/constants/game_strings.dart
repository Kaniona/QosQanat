/// Kazakh strings for the gamification / reward UI.
class GameStrings {
  GameStrings._();

  static const String levelUpTitle = 'Деңгей көтерілді!';
  static const String newLevelLabel = 'Жаңа деңгей';
  static const String rewardLabel = 'Сыйлық';
  static const String awesome = 'Керемет! ✓';

  static const String streakTitle = 'Серия жалғасуда!';
  static const String streakDays = 'күн қатарынан';
  static const String streakReward = 'Серия сыйлығы';

  static const String questsTitle = 'Күнделікті тапсырмалар';
  static const String questClaim = 'Алу';
  static const String questClaimed = 'Алынды';
  static const String questCompleted = 'Орындалды';

  static const String achievementsTitle = 'Жетістіктер';
  static const String achievementUnlocked = 'Жетістік ашылды!';
  static const String locked = 'Жабық';

  // Reward toast labels
  static const String xpGained = 'XP';
  static const String coinsGained = 'тиын';
  static const String akylGained = 'ақыл';
}
