import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../../models/enums.dart';

/// Static configuration data for QosQanat 2.0 (non-localized lists and
/// metadata). User-facing strings live in [AppStrings] / [AuthStrings].
class AppConfig {
  AppConfig._();

  /// Major Kazakhstan cities offered in the registration city dropdown.
  static const List<String> cities = [
    'Астана',
    'Алматы',
    'Шымкент',
    'Қарағанды',
    'Қызылорда',
    'Қостанай',
    'Ақтөбе',
    'Тараз',
    'Павлодар',
    'Өскемен',
    'Семей',
    'Атырау',
    'Ақтау',
    'Орал',
    'Көкшетау',
    'Талдықорған',
    'Петропавл',
    'Түркістан',
  ];

  /// Selectable grades (1–11).
  static const List<int> grades = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];

  /// Welcome gift granted after choosing an assistant.
  static const int welcomeGiftCoins = 100;

  /// Human-readable app version, shown in the drawer footer / about dialog.
  static const String appVersion = '1.0.0';

  /// Reverse-DNS application/bundle identifier.
  static const String bundleId = 'com.qosqanat.app';

  /// When `true`, the app skips the register/login flow and boots straight in
  /// as `kDemoUser`. In offline test mode this is `false` so the full
  /// register / login flow (backed by local storage) can be exercised.
  static const bool demoMode = false;
}

/// Presentation metadata for an AI study companion.
class AssistantInfo {
  final AssistantType type;
  final String name;
  final String tag;
  final String bio;
  final Color color;
  final Color surfaceColor;
  final IconData icon;

  const AssistantInfo({
    required this.type,
    required this.name,
    required this.tag,
    required this.bio,
    required this.color,
    required this.surfaceColor,
    required this.icon,
  });

  /// Bektur — 14yo boy, energetic, blue theme.
  static const AssistantInfo bektur = AssistantInfo(
    type: AssistantType.bektur,
    name: 'Бектұр',
    tag: 'Жігерлі',
    bio: '14 жаста. Әрдайым жігерлі әрі көмекке дайын. '
        'Сенімен бірге білім шыңына шығады!',
    color: AppColors.bekturBlue,
    surfaceColor: AppColors.eagleBlueSurface,
    icon: Icons.bolt_rounded,
  );

  /// Nazym — 14yo girl, kind, rose theme.
  static const AssistantInfo nazym = AssistantInfo(
    type: AssistantType.nazym,
    name: 'Назым',
    tag: 'Мейірімді',
    bio: '14 жаста. Мейірімді әрі шыдамды. '
        'Қиын сәтте әрқашан қолдау көрсетеді.',
    color: AppColors.nazymRose,
    surfaceColor: AppColors.nazymRoseSurface,
    icon: Icons.favorite_rounded,
  );

  static const List<AssistantInfo> all = [bektur, nazym];

  static AssistantInfo of(AssistantType type) =>
      type == AssistantType.nazym ? nazym : bektur;
}
