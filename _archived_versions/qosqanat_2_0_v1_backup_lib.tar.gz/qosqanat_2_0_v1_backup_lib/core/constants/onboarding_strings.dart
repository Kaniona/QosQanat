/// Kazakh strings for the first-run spotlight tutorial.
class OnboardingStrings {
  OnboardingStrings._();

  // HUD spotlight
  static const String hudTitle = 'Сенің көрсеткіштерің';
  static const String hudBody =
      'Деңгейің, ақыл ұпайларың мен тиындарың осы жерде. '
      'Профиль суретіне бассаң — профиліңе өтесің.';

  // News feed spotlight
  static const String newsTitle = 'Жаңалықтар';
  static const String newsBody =
      'Мұнда мектеп пен QosQanat командасының жаңалықтары шығады. '
      'Жаңартып отыр!';

  // Learn (Оқу) tab spotlight
  static const String learnTitle = 'Оқу';
  static const String learnBody =
      'Басты бөлім! Пәндерді таңдап, сабақ картасымен білім шыңына көтеріл.';

  // Shop tab spotlight
  static const String shopTitle = 'Дүкен';
  static const String shopBody =
      'Тиындарыңа серігіңе киім мен аксессуарлар сатып ал, оны әдемі ет!';

  // Drawer swipe spotlight
  static const String drawerTitle = 'Жасырын мәзір';
  static const String drawerBody =
      'Сол жақ шеттен оңға қарай сипасаң — Турнир, Достар және Баптаулар ашылады.';

  // Daily quests spotlight
  static const String questsTitle = 'Күнделікті тапсырмалар';
  static const String questsBody =
      'Күн сайын тапсырмаларды орында, серияңды үзбе және сыйлықтар жина!';

  // Closing card
  static const String finishTitle = 'Дайынсың, қыран!';
  static const String finishBody =
      'Енді өз сапарыңды баста. Сәтті оқу тілейміз!';
  static const String finishButton = 'Бастау';

  // Controls
  static const String nextButton = 'Келесі';
  static const String skipButton = 'Өткізіп жіберу';
  static const String stepLabel = 'қадам';
}
