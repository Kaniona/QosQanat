/// Centralized Kazakh UI strings for QosQanat 2.0.
///
/// ALL user-facing text must come from here — never hardcode a string literal
/// in a widget. Keys are English for developer ergonomics; values are Kazakh.
class AppStrings {
  AppStrings._();

  // App
  static const String appName = 'QosQanat';
  static const String appTagline = 'Қыран қанат';

  // Common actions / buttons
  static const String continueAction = 'Жалғастыру';
  static const String cancel = 'Болдырмау';
  static const String done = 'Дайын';
  static const String select = 'Таңдау';
  static const String next = 'Келесі';
  static const String back = 'Артқа';
  static const String save = 'Сақтау';
  static const String confirm = 'Растау';
  static const String retry = 'Қайталау';
  static const String close = 'Жабу';
  static const String edit = 'Өзгерту';
  static const String delete = 'Жою';
  static const String add = 'Қосу';
  static const String search = 'Іздеу';
  static const String skip = 'Өткізіп жіберу';
  static const String start = 'Бастау';
  static const String send = 'Жіберу';
  static const String yes = 'Иә';
  static const String no = 'Жоқ';
  static const String ok = 'Жарайды';

  // States
  static const String loading = 'Жүктелуде...';
  static const String error = 'Қате орын алды';
  static const String errorGeneric = 'Бірдеңе дұрыс болмады. Қайталап көріңіз.';
  static const String empty = 'Әзірге мұнда ештеңе жоқ';
  static const String noConnection = 'Интернет байланысы жоқ';
  static const String success = 'Сәтті орындалды';

  // Auth
  static const String welcome = 'Қош келдің!';
  static const String login = 'Кіру';
  static const String register = 'Тіркелу';
  static const String logout = 'Шығу';
  static const String email = 'Электрондық пошта';
  static const String password = 'Құпия сөз';
  static const String confirmPassword = 'Құпия сөзді растау';
  static const String forgotPassword = 'Құпия сөзді ұмыттың ба?';
  static const String fullName = 'Толық аты-жөні';
  static const String phone = 'Телефон нөмірі';
  static const String iin = 'ЖСН';
  static const String city = 'Қала';
  static const String school = 'Мектеп';
  static const String grade = 'Сынып';
  static const String dontHaveAccount = 'Тіркелгің жоқ па?';
  static const String alreadyHaveAccount = 'Тіркелгің бар ма?';

  // Assistant selection
  static const String chooseAssistant = 'Серігіңді таңда';
  static const String chooseAssistantSubtitle =
      'Ол сенімен бірге оқиды, жеңістеріңді тойлайды';
  static const String bektur = 'Бектұр';
  static const String nazym = 'Назым';

  // Navigation — bottom nav tabs
  static const String navHome = 'Басты бет';
  static const String navRating = 'Рейтинг';
  static const String navLearn = 'Оқу';
  static const String navShop = 'Shop';
  static const String navProfile = 'Профиль';

  // Navigation — side drawer
  static const String drawerTournament = 'Турнир';
  static const String drawerFriends = 'Достар';
  static const String drawerSettings = 'Баптаулар';
  static const String drawerSupport = 'Қолдау';
  static const String drawerAboutApp = 'QosQanat туралы';
  static const String version = 'Нұсқа';

  // Currencies / HUD
  static const String level = 'Деңгей';
  static const String levelShort = 'LVL';
  static const String xp = 'XP';
  static const String coins = 'Тиын';
  static const String akyl = 'Ақыл';

  // Home
  static const String news = 'Жаңалықтар';
  static const String dailyQuests = 'Күнделікті тапсырмалар';
  static const String streak = 'Серия';
  static const String streakDays = 'күн';

  // Learn
  static const String learningMap = 'Оқу картасы';
  static const String lesson = 'Сабақ';
  static const String quiz = 'Сынақ';
  static const String boss = 'Босс';
  static const String treasure = 'Қазына';

  // Shop
  static const String shop = 'Дүкен';
  static const String buy = 'Сатып алу';
  static const String owned = 'Сатып алынған';
  static const String equip = 'Кию';
  static const String equipped = 'Киілген';

  // Friends & battle
  static const String friends = 'Достар';
  static const String addFriend = 'Дос қосу';
  static const String qosqanatId = 'QQ-ID';
  static const String battle = 'Шайқас';
  static const String akylBattle = 'Ақыл шайқасы';
  static const String findOpponent = 'Қарсылас іздеу';

  // Rating
  static const String leaderboard = 'Көшбасшылар';
  static const String ratingGlobal = 'Әлемдік';
  static const String ratingCity = 'Қала';
  static const String ratingSchool = 'Мектеп';
  static const String ratingFriends = 'Достар';

  // Profile
  static const String profile = 'Профиль';
  static const String editProfile = 'Профильді өзгерту';
  static const String achievements = 'Жетістіктер';
  static const String statistics = 'Статистика';
  static const String changePhoto = 'Суретті өзгерту';

  // Tournament
  static const String tournament = 'Турнир';

  // Settings
  static const String settings = 'Баптаулар';
  static const String language = 'Тіл';
  static const String notifications = 'Хабарламалар';
  static const String sound = 'Дыбыс';
  static const String about = 'Қосымша туралы';
}
