import 'package:flutter/widgets.dart';

import 'app_colors.dart';

/// QosQanat 2.0 — layered elevation system.
///
/// World-class perceived quality comes from *soft, multi-layer* shadows rather
/// than a single hard drop shadow. Each level stacks a tight contact shadow
/// (small blur, low offset) under a wider ambient shadow (large blur, soft
/// alpha). Use these instead of ad-hoc [BoxShadow]s so depth stays consistent.
///
/// Tints are derived from [AppColors.nightInk] so shadows read as cool indigo,
/// matching the brand sky rather than muddy grey.
class AppElevation {
  AppElevation._();

  /// Resting surface — chips, inputs, subtle separation.
  static const List<BoxShadow> low = [
    BoxShadow(color: Color(0x0F1A1A4E), blurRadius: 4, offset: Offset(0, 1)),
    BoxShadow(color: Color(0x0A1A1A4E), blurRadius: 10, offset: Offset(0, 4)),
  ];

  /// Default cards and list items.
  static const List<BoxShadow> card = [
    BoxShadow(color: Color(0x141A1A4E), blurRadius: 6, offset: Offset(0, 2)),
    BoxShadow(color: Color(0x0F1A1A4E), blurRadius: 20, offset: Offset(0, 10)),
  ];

  /// Raised elements — HUD pills, floating buttons, active nodes.
  static const List<BoxShadow> raised = [
    BoxShadow(color: Color(0x1F1A1A4E), blurRadius: 8, offset: Offset(0, 4)),
    BoxShadow(color: Color(0x141A1A4E), blurRadius: 28, offset: Offset(0, 14)),
  ];

  /// Floating overlays — modals, sheets, dialogs, popovers.
  static const List<BoxShadow> floating = [
    BoxShadow(color: Color(0x291A1A4E), blurRadius: 12, offset: Offset(0, 6)),
    BoxShadow(color: Color(0x1A1A1A4E), blurRadius: 40, offset: Offset(0, 20)),
  ];

  /// Pressed state — collapse the shadow so the element feels pushed in.
  static const List<BoxShadow> pressed = [
    BoxShadow(color: Color(0x141A1A4E), blurRadius: 4, offset: Offset(0, 2)),
  ];

  /// Soft colored glow used to make brand/accent surfaces feel luminous.
  /// Pair with the same [color] used for the element's fill or gradient.
  static List<BoxShadow> glow(Color color, {double opacity = 0.45}) {
    return [
      BoxShadow(
        color: color.withValues(alpha: opacity),
        blurRadius: 24,
        offset: const Offset(0, 10),
      ),
      BoxShadow(
        color: color.withValues(alpha: opacity * 0.4),
        blurRadius: 8,
        offset: const Offset(0, 3),
      ),
    ];
  }

  /// Glow tuned for the primary Eagle Blue CTA.
  static List<BoxShadow> get eagleGlow => glow(AppColors.eagleBlue);

  /// Glow tuned for gold reward surfaces (coins, treasure).
  static List<BoxShadow> get goldGlow => glow(AppColors.steppeGold);

  /// Glow tuned for XP / premium purple surfaces.
  static List<BoxShadow> get cosmicGlow => glow(AppColors.cosmicPurple);

  /// Inner-highlight overlay color for the top edge of clay-like surfaces.
  static const Color innerHighlight = Color(0x33FFFFFF);
}
