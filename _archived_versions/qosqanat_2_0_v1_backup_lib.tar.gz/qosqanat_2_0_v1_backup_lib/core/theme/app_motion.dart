import 'package:flutter/animation.dart';

/// QosQanat 2.0 — motion design tokens.
///
/// Consistent timing and easing are what make an interface feel "alive" but not
/// chaotic. Durations follow the 120/200/320ms rhythm (Material/Apple guidance:
/// 150–300ms for most UI motion); curves favour gentle overshoot for playful,
/// game-grade feedback while staying snappy.
class AppMotion {
  AppMotion._();

  // ---------------------------------------------------------------------------
  // Durations
  // ---------------------------------------------------------------------------

  /// Press / tap feedback — must feel instant.
  static const Duration fast = Duration(milliseconds: 120);

  /// Default for most state changes (color, opacity, small moves).
  static const Duration base = Duration(milliseconds: 200);

  /// Entrances, expansions, page-level transitions.
  static const Duration slow = Duration(milliseconds: 320);

  /// Celebratory / reward sequences (level up, confetti, big reveals).
  static const Duration celebrate = Duration(milliseconds: 520);

  // ---------------------------------------------------------------------------
  // Curves
  // ---------------------------------------------------------------------------

  /// Standard emphasized easing — natural deceleration.
  static const Curve emphasized = Curves.easeOutCubic;

  /// Gentle spring overshoot for playful pops (badges, rewards, nodes).
  static const Curve spring = Curves.easeOutBack;

  /// Snappy settle used when an element returns from a pressed state.
  static const Curve settle = Curves.easeOut;

  /// Scale a tappable element shrinks to while pressed.
  static const double pressScale = 0.96;

  /// Slightly stronger press for large, playful targets (map nodes, big CTAs).
  static const double pressScaleStrong = 0.93;
}
