import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_colors.dart';

/// QosQanat 2.0 typography. Uses Nunito (full Kazakh Cyrillic coverage) as the
/// app-wide type family. Exposes a complete [TextTheme] plus custom display and
/// number styles used across the gamified UI.
class AppTypography {
  AppTypography._();

  /// Base font family. Nunito ships a complete Cyrillic subset, so Kazakh
  /// glyphs (ә, ғ, қ, ң, ө, ұ, ү, һ, і) render correctly.
  static TextStyle _font({
    required double size,
    required FontWeight weight,
    Color color = AppColors.textPrimary,
    double? height,
    double? letterSpacing,
  }) {
    return GoogleFonts.nunito(
      fontSize: size,
      fontWeight: weight,
      color: color,
      height: height,
      letterSpacing: letterSpacing,
    );
  }

  /// Display family — Baloo 2. Rounded, playful, full Cyrillic coverage. Used
  /// for headings, hero numbers, buttons, and any "game UI" emphasis text.
  static TextStyle display({
    required double size,
    FontWeight weight = FontWeight.w800,
    Color color = AppColors.textPrimary,
    double? height,
    double? letterSpacing,
  }) {
    return GoogleFonts.baloo2(
      fontSize: size,
      fontWeight: weight,
      color: color,
      height: height,
      letterSpacing: letterSpacing,
    );
  }

  // ---------------------------------------------------------------------------
  // Display & headings (Baloo 2)
  // ---------------------------------------------------------------------------
  static TextStyle get displayHuge =>
      display(size: 40, weight: FontWeight.w800, height: 1.1, letterSpacing: -0.5);

  static TextStyle get displayLarge =>
      display(size: 32, weight: FontWeight.w800, height: 1.15, letterSpacing: -0.5);

  static TextStyle get h1 =>
      display(size: 28, weight: FontWeight.w700, height: 1.2);

  static TextStyle get h2 =>
      display(size: 24, weight: FontWeight.w700, height: 1.25);

  static TextStyle get h3 =>
      display(size: 20, weight: FontWeight.w700, height: 1.3);

  // ---------------------------------------------------------------------------
  // Body
  // ---------------------------------------------------------------------------
  static TextStyle get bodyLarge =>
      _font(size: 18, weight: FontWeight.w500, height: 1.45);

  static TextStyle get body =>
      _font(size: 16, weight: FontWeight.w500, height: 1.45);

  static TextStyle get bodySecondary => _font(
        size: 16,
        weight: FontWeight.w500,
        color: AppColors.textSecondary,
        height: 1.45,
      );

  static TextStyle get caption => _font(
        size: 12,
        weight: FontWeight.w600,
        color: AppColors.textSecondary,
        height: 1.3,
      );

  // ---------------------------------------------------------------------------
  // Interactive & numeric
  // ---------------------------------------------------------------------------
  static TextStyle get button => display(
        size: 17,
        weight: FontWeight.w800,
        color: AppColors.textOnDark,
        letterSpacing: 0.2,
      );

  /// Large numeric display for HUD values (coins, akyl, XP totals).
  static TextStyle get numberDisplay =>
      display(size: 36, weight: FontWeight.w800, height: 1.0);

  /// Smaller emphasis number (stat strips, ring centres, chips).
  static TextStyle get numberMedium =>
      display(size: 22, weight: FontWeight.w800, height: 1.0);

  // ---------------------------------------------------------------------------
  // Material 3 TextTheme wiring
  // ---------------------------------------------------------------------------
  static TextTheme get textTheme => TextTheme(
        displayLarge: displayHuge,
        displayMedium: displayLarge,
        displaySmall: h1,
        headlineLarge: h1,
        headlineMedium: h2,
        headlineSmall: h3,
        titleLarge: h3,
        titleMedium: _font(size: 18, weight: FontWeight.w700),
        titleSmall: _font(size: 16, weight: FontWeight.w700),
        bodyLarge: bodyLarge,
        bodyMedium: body,
        bodySmall: caption,
        labelLarge: button.copyWith(color: AppColors.textPrimary),
        labelMedium: _font(size: 14, weight: FontWeight.w600),
        labelSmall: caption,
      );
}
