import 'package:flutter/material.dart';

/// QosQanat 2.0 — "Eagle Wings / Steppe Sky Ascension" color system.
///
/// Every brand color and gradient lives here. NEVER hardcode a [Color] in a
/// widget — always reference [AppColors].
class AppColors {
  AppColors._();

  // ---------------------------------------------------------------------------
  // Eagle Blue — primary brand color
  // ---------------------------------------------------------------------------
  static const Color eagleBlue = Color(0xFF4A6CF7);
  static const Color eagleBlueLight = Color(0xFF7B96FF);
  static const Color eagleBlueDark = Color(0xFF2F4ECC);
  static const Color eagleBlueSurface = Color(0xFFEDF1FF);

  // ---------------------------------------------------------------------------
  // Steppe Gold — rewards, coins, energy
  // ---------------------------------------------------------------------------
  static const Color steppeGold = Color(0xFFF5A623);
  static const Color steppeGoldLight = Color(0xFFFFC459);
  static const Color steppeGoldDark = Color(0xFFD4860A);
  static const Color steppeGoldSurface = Color(0xFFFFF4E0);

  // ---------------------------------------------------------------------------
  // Cosmic Purple — XP, magic, premium
  // ---------------------------------------------------------------------------
  static const Color cosmicPurple = Color(0xFF7B61FF);
  static const Color cosmicPurpleLight = Color(0xFFA593FF);
  static const Color cosmicPurpleDark = Color(0xFF5840CC);
  static const Color cosmicPurpleSurface = Color(0xFFF1EDFF);

  // ---------------------------------------------------------------------------
  // Semantic colors
  // ---------------------------------------------------------------------------
  static const Color jade = Color(0xFF00C48C); // success
  static const Color jadeLight = Color(0xFF5BE3BC);
  static const Color jadeDark = Color(0xFF009B6E);
  static const Color jadeSurface = Color(0xFFE3FBF3);

  static const Color coral = Color(0xFFFF4757); // danger / error
  static const Color coralLight = Color(0xFFFF8089);
  static const Color coralDark = Color(0xFFD32F3D);
  static const Color coralSurface = Color(0xFFFFEBED);

  static const Color sunset = Color(0xFFFF8C42); // warning
  static const Color sunsetLight = Color(0xFFFFB37D);
  static const Color sunsetDark = Color(0xFFE06A1F);
  static const Color sunsetSurface = Color(0xFFFFF0E6);

  // ---------------------------------------------------------------------------
  // Ink & neutrals
  // ---------------------------------------------------------------------------
  static const Color nightInk = Color(0xFF1A1A4E); // primary text / dark base
  static const Color background = Color(0xFFFAFBFF); // app background
  static const Color surface = Color(0xFFFFFFFF);
  static const Color surfaceMuted = Color(0xFFF2F4FA);

  static const Color textPrimary = Color(0xFF1A1A4E);
  static const Color textSecondary = Color(0xFF5A5E80);
  static const Color textTertiary = Color(0xFF9AA0BD);
  static const Color textOnDark = Color(0xFFFFFFFF);

  static const Color border = Color(0xFFE4E8F2);
  static const Color borderStrong = Color(0xFFCDD3E4);
  static const Color divider = Color(0xFFEDEFF6);

  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF000000);

  // ---------------------------------------------------------------------------
  // Assistant theme accents
  // ---------------------------------------------------------------------------
  static const Color bekturBlue = Color(0xFF4A6CF7); // Bektur (boy)
  static const Color nazymRose = Color(0xFFFF6B9D); // Nazym (girl)
  static const Color nazymRoseSurface = Color(0xFFFFEBF2);

  // ---------------------------------------------------------------------------
  // Rarity tiers (shop items)
  // ---------------------------------------------------------------------------
  static const Color rarityCommon = Color(0xFF9AA0BD);
  static const Color rarityRare = Color(0xFF4A6CF7);
  static const Color rarityEpic = Color(0xFF7B61FF);
  static const Color rarityLegendary = Color(0xFFF5A623);
  static const Color rarityMythic = Color(0xFFFF4757);

  // ---------------------------------------------------------------------------
  // Shadows
  // ---------------------------------------------------------------------------
  static const Color shadowSoft = Color(0x1A1A1A4E);
  static const Color shadowMedium = Color(0x261A1A4E);

  // ---------------------------------------------------------------------------
  // Gradients
  // ---------------------------------------------------------------------------

  /// Ascension — hero/onboarding backdrop (blue → purple rising sky).
  static const LinearGradient ascension = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [eagleBlue, cosmicPurple],
  );

  /// Eagle — primary buttons and active accents.
  static const LinearGradient eagle = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [eagleBlueLight, eagleBlue],
  );

  /// Gold Soar — coins, rewards, treasure.
  static const LinearGradient goldSoar = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [steppeGoldLight, steppeGold],
  );

  /// Cosmic Night — XP bars, premium surfaces, dark hero panels.
  static const LinearGradient cosmicNight = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [cosmicPurple, nightInk],
  );

  // ---------------------------------------------------------------------------
  // Dark mode — "Cosmic Night" base (#0F0F2E)
  // ---------------------------------------------------------------------------
  static const Color night = Color(0xFF0F0F2E); // dark scaffold base
  static const Color nightElevated = Color(0xFF191945); // raised dark panels
  static const Color nightSurface = Color(0xFF26264F); // clay surface (dark)
  static const Color nightSurfaceLow = Color(0xFF191938); // clay shadow (dark)

  static const Color darkTextPrimary = Color(0xFFE9EAFF);
  static const Color darkTextSecondary = Color(0xFFC4C7EC);
  static const Color darkTextTertiary = Color(0xFF9AA0D0);
  static const Color darkBorder = Color(0x3896A0FF); // rgba(150,150,255,.22)

  /// Aurora backdrop base — deep indigo behind glass screens.
  static const Color auroraBase = Color(0xFF0A0A1F);

  // ---------------------------------------------------------------------------
  // Subject accents — one identity colour per school subject
  // ---------------------------------------------------------------------------
  static const Color subjectMath = eagleBlue;
  static const Color subjectKazakh = jade;
  static const Color subjectEnglish = eagleBlue;
  static const Color subjectPhysics = cosmicPurple;
  static const Color subjectInformatics = sunset;
  static const Color subjectHistory = steppeGold;
  static const Color subjectChemistry = jadeDark;
  static const Color subjectBiology = jade;
  static const Color subjectGeography = eagleBlueLight;
  static const Color subjectRussian = coral;

  /// Aurora glow gradient (blue → purple → gold) used on dark hero screens.
  static const List<Color> auroraGlow = [
    eagleBlueLight,
    cosmicPurpleLight,
    steppeGoldLight,
  ];
}
