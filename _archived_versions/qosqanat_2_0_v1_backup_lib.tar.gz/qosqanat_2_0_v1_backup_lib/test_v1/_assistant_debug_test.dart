import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:qosqanat_2_0/widgets/avatar/avatar_selector.dart';
import 'package:qosqanat_2_0/models/enums.dart';

void main() {
  testWidgets('selector renders both assistants', (tester) async {
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: AvatarSelector(selected: null, onSelect: (_) {}),
      ),
    ));
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.text('Бектұр'), findsOneWidget);
    expect(find.text('Назым'), findsOneWidget);
  });
}
