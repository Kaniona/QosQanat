import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:qosqanat_2_0/data/achievements.dart';
import 'package:qosqanat_2_0/data/levels.dart';
import 'package:qosqanat_2_0/data/quests.dart';
import 'package:qosqanat_2_0/providers/game_provider.dart';
import 'package:qosqanat_2_0/services/game_service.dart';
import 'package:qosqanat_2_0/widgets/game/level_up_modal.dart';
import 'package:qosqanat_2_0/widgets/game/reward_toast.dart';
import 'package:qosqanat_2_0/widgets/game/xp_bar.dart';

/// No-op service so tests exercise pure logic without hitting Supabase.
class _FakeGameService extends GameService {
  @override
  Future<void> save({
    required int level,
    required int xp,
    required int coins,
    required int akylPoints,
    required int currentStreak,
    required int longestStreak,
    DateTime? lastLoginDate,
  }) async {}
}

ProviderContainer _container() {
  final c = ProviderContainer(
    overrides: [gameServiceProvider.overrideWithValue(_FakeGameService())],
  );
  addTearDown(c.dispose);
  return c;
}

void main() {
  group('level curve', () {
    test('xpRequired matches the formula at boundaries', () {
      expect(xpRequiredForLevel(1), 0);
      expect(xpRequiredForLevel(2), 110); // 100 + 10
      expect(xpRequiredForLevel(3), 240); // 200 + 40
      expect(coinRewardForLevel(5), 100); // 5 * 20
    });

    test('calculateLevel is consistent with thresholds', () {
      expect(calculateLevel(0), 1);
      expect(calculateLevel(109), 1);
      expect(calculateLevel(110), 2);
      expect(calculateLevel(239), 2);
      expect(calculateLevel(240), 3);
      expect(calculateLevel(99999999), 100);
    });

    test('titles map to the right ranges', () {
      expect(titleForLevel(1), 'Жас оқушы');
      expect(titleForLevel(7), 'Білімгер');
      expect(titleForLevel(100), 'QosQanat Чемпионы');
      expect(titleForLevel(95), 'Легенда');
    });
  });

  group('catalog', () {
    test('has 30+ achievements across all categories', () {
      expect(kAchievements.length, greaterThanOrEqualTo(30));
      for (final cat in AchievementCategory.values) {
        expect(achievementsByCategory(cat), isNotEmpty);
      }
    });

    test('streak milestones reward exact days only', () {
      expect(streakMilestoneReward(3), 50);
      expect(streakMilestoneReward(100), 5000);
      expect(streakMilestoneReward(4), isNull);
    });
  });

  group('GameNotifier', () {
    test('addXp triggers a level-up with summed coin rewards', () {
      final c = _container();
      final notifier = c.read(gameProvider.notifier);

      notifier.addXp(250); // crosses into level 3
      final s = c.read(gameProvider);

      expect(s.level, 3);
      expect(s.xp, 250);
      // Level 2 (40) + level 3 (60) coin rewards granted.
      expect(s.coins, 100);
      expect(s.pendingLevelUp?.newLevel, 3);
    });

    test('spendCoins fails when insufficient and succeeds otherwise', () {
      final c = _container();
      final notifier = c.read(gameProvider.notifier);

      notifier.addCoins(100);
      expect(notifier.spendCoins(150), isFalse);
      expect(c.read(gameProvider).coins, 100);
      expect(notifier.spendCoins(60), isTrue);
      expect(c.read(gameProvider).coins, 40);
    });

    test('checkStreak continues, resets, and rewards milestones', () {
      final c = _container();
      final notifier = c.read(gameProvider.notifier);
      final day1 = DateTime(2026, 1, 1);

      notifier.checkStreak(now: day1);
      expect(c.read(gameProvider).currentStreak, 1);

      // Consecutive day → streak grows.
      notifier.checkStreak(now: DateTime(2026, 1, 2));
      expect(c.read(gameProvider).currentStreak, 2);

      // Third consecutive day hits the 3-day milestone (+50 coins).
      notifier.checkStreak(now: DateTime(2026, 1, 3));
      expect(c.read(gameProvider).currentStreak, 3);
      expect(c.read(gameProvider).pendingStreakReward?.coinReward, 50);

      // Skipping a day resets to 1.
      notifier.checkStreak(now: DateTime(2026, 1, 10));
      expect(c.read(gameProvider).currentStreak, 1);
    });
  });

  group('reward widgets render', () {
    testWidgets('XpBar.fromTotalXp builds', (tester) async {
      await tester.pumpWidget(
        MaterialApp(home: Scaffold(body: XpBar.fromTotalXp(totalXp: 180))),
      );
      expect(tester.takeException(), isNull);
    });

    testWidgets('LevelUpModal shows and dismisses', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Builder(
              builder: (context) => ElevatedButton(
                onPressed: () => showLevelUpModal(
                  context,
                  newLevel: 5,
                  title: 'Жас оқушы',
                  coinReward: 100,
                ),
                child: const Text('go'),
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.text('go'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));
      expect(find.text('Керемет! ✓'), findsOneWidget);
      expect(tester.takeException(), isNull);

      await tester.tap(find.text('Керемет! ✓'));
      await tester.pumpAndSettle();
    });

    testWidgets('RewardToast.show inserts and removes', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Builder(
              builder: (context) => ElevatedButton(
                onPressed: () => RewardToast.show(
                  context,
                  kind: RewardKind.coins,
                  amount: 50,
                ),
                child: const Text('toast'),
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.text('toast'));
      await tester.pump();
      expect(find.textContaining('+50'), findsOneWidget);
      // Let the toast animation finish and self-remove.
      await tester.pump(const Duration(milliseconds: 1900));
      expect(tester.takeException(), isNull);
    });
  });
}
