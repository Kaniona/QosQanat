import 'package:flutter_test/flutter_test.dart';
import 'package:qosqanat_2_0/data/question_bank.dart';
import 'package:qosqanat_2_0/models/question.dart';

void main() {
  test('each bank has >=1000 questions, unique ids, valid options', () {
    final banks = {
      'math': mathBank,
      'physics': physicsBank,
      'informatics': informaticsBank,
      'english': englishBank,
      'kazakh': kazakhBank,
    };
    banks.forEach((name, b) {
      // count
      expect(b.length >= 1000, true, reason: '$name has only ${b.length}');
      // unique ids
      final ids = b.map((q) => q.id).toSet();
      expect(ids.length, b.length, reason: '$name has duplicate ids');
      // MC integrity
      for (final q in b) {
        if (q.type == QuestionType.multipleChoice) {
          expect(q.options.length, 4, reason: '$name ${q.id} not 4 opts');
          expect(q.options.toSet().length, 4, reason: '$name ${q.id} dup opts: ${q.options}');
          expect(q.correctIndex >= 0 && q.correctIndex < 4, true);
        }
      }
      // ignore: avoid_print
      print('$name: ${b.length} questions');
    });
  });
}
