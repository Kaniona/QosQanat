import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';

import 'package:qosqanat_2_0/models/enums.dart';
import 'package:qosqanat_2_0/models/news_item.dart';
import 'package:qosqanat_2_0/models/user.dart';
import 'package:qosqanat_2_0/providers/auth_provider.dart';
import 'package:qosqanat_2_0/providers/game_provider.dart';
import 'package:qosqanat_2_0/providers/news_provider.dart';
import 'package:qosqanat_2_0/screens/home/home_screen.dart';
import 'package:qosqanat_2_0/services/game_service.dart';

class _FakeGameService extends GameService {
  @override
  Future<void> save({
    required int level,
    required int xp,
    required int coins,
    required int akylPoints,
    required int currentStreak,
    required int longestStreak,
    DateTime? lastLoginDate,
  }) async {}
}

final _user = AppUser(
  id: 'u1',
  qosqanatId: 'QQ-TEST00001',
  fullName: 'Алихан Сейтжанұлы',
  assistantType: AssistantType.bektur,
  coins: 1250,
  akylPoints: 890,
  level: 12,
  createdAt: DateTime(2026, 1, 1),
);

Widget _app(List<NewsItem> news) {
  final router = GoRouter(
    routes: [GoRoute(path: '/', builder: (_, _) => const HomeScreen())],
  );
  return ProviderScope(
    overrides: [
      gameServiceProvider.overrideWithValue(_FakeGameService()),
      currentUserProvider.overrideWith((ref) async => _user),
      newsProvider.overrideWith((ref) async => news),
    ],
    child: MaterialApp.router(routerConfig: router),
  );
}

void main() {
  testWidgets('Home shows the news section and a news card', (tester) async {
    final news = [
      NewsItem(
        id: 'n1',
        title: 'Жаңа тапсырмалар қосылды',
        body: 'Математика пәніне жаңа деңгейлер енгізілді.',
        category: 'Жаңарту',
        publishedAt: DateTime(2026, 6, 1),
      ),
    ];

    await tester.pumpWidget(_app(news));
    await tester.pump(); // resolve futures
    await tester.pump(const Duration(milliseconds: 50));

    expect(find.text('📢 Жаңалықтар'), findsOneWidget);
    expect(find.text('Жаңа тапсырмалар қосылды'), findsOneWidget);
    expect(find.text('Жаңарту'), findsOneWidget);
    expect(tester.takeException(), isNull);

    // Dispose animated children cleanly (avatar timers/controllers).
    await tester.pumpWidget(const SizedBox.shrink());
  });

  testWidgets('Home shows the empty state when there is no news',
      (tester) async {
    await tester.pumpWidget(_app(const []));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 50));

    expect(find.text('Әзірге жаңалық жоқ'), findsOneWidget);
    expect(tester.takeException(), isNull);

    await tester.pumpWidget(const SizedBox.shrink());
  });
}
