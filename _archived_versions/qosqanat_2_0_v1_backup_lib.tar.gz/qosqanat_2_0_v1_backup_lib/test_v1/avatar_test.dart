// Renders the avatar system across both characters and every expression to
// catch malformed SVG layers (a runtime-only failure mode).

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:qosqanat_2_0/models/enums.dart';
import 'package:qosqanat_2_0/widgets/avatar/avatar_base.dart';
import 'package:qosqanat_2_0/widgets/avatar/avatar_display.dart';
import 'package:qosqanat_2_0/widgets/avatar/expressions.dart';

void main() {
  testWidgets('AvatarBase renders every expression for both characters',
      (tester) async {
    for (final type in AssistantType.values) {
      for (final expr in AvatarExpression.values) {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: Center(
                child: AvatarBase(assistantType: type, expression: expr),
              ),
            ),
          ),
        );
        await tester.pump();
        expect(tester.takeException(), isNull);
      }
    }
  });

  testWidgets('AvatarDisplay animates without throwing', (tester) async {
    for (final anim in AvatarAnimation.values) {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: AvatarDisplay(
                assistantType: AssistantType.nazym,
                animation: anim,
              ),
            ),
          ),
        ),
      );
      await tester.pump(const Duration(milliseconds: 300));
      expect(tester.takeException(), isNull);
    }

    // Allow timers/controllers to settle and dispose cleanly.
    await tester.pumpWidget(const SizedBox.shrink());
  });
}
