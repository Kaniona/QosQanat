import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:qosqanat_2_0/widgets/avatar/avatar_base.dart';
import 'package:qosqanat_2_0/models/enums.dart';

void main() {
  testWidgets('avatar svg paints visible pixels', (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(
        body: Center(
          child: RepaintBoundary(
            child: AvatarBase(assistantType: AssistantType.bektur, size: 120),
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle(const Duration(milliseconds: 200));
    final boundary = tester.renderObject<RenderRepaintBoundary>(
        find.byType(RepaintBoundary).first);
    final img = await boundary.toImage();
    final bytes = await img.toByteData(format: ui.ImageByteFormat.rawRgba);
    final data = bytes!.buffer.asUint8List();
    int opaque = 0;
    for (int i = 3; i < data.length; i += 4) {
      if (data[i] > 10) opaque++;
    }
    debugPrint('OPAQUE_PIXELS=$opaque of ${data.length ~/ 4}');
    expect(opaque, greaterThan(0));
  });
}
