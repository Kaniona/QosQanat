import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:qosqanat_2_0/widgets/avatar/avatar_base.dart';
import 'package:qosqanat_2_0/models/enums.dart';

void main() {
  testWidgets('dump avatar png', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          backgroundColor: Colors.grey.shade300,
          body: Center(
            child: RepaintBoundary(
              key: const Key('cap'),
              child: Container(
                color: Colors.white,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    AvatarBase(assistantType: AssistantType.bektur, size: 140),
                    AvatarBase(assistantType: AssistantType.nazym, size: 140),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pump(const Duration(milliseconds: 300));
    final boundary =
        tester.renderObject<RenderRepaintBoundary>(find.byKey(const Key('cap')));
    final img = await boundary.toImage(pixelRatio: 2.0);
    final png = await img.toByteData(format: ui.ImageByteFormat.png);
    final file = File('/tmp/avatar_dump.png');
    await file.writeAsBytes(png!.buffer.asUint8List());
    debugPrint('WROTE ${file.path} ${png.lengthInBytes} bytes');
  });
}
