import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/enums.dart';
import '../../providers/shop_provider.dart';
import 'avatar_display.dart';

/// Renders [AvatarDisplay] with the player's currently equipped cosmetics
/// pulled from [shopProvider] / [equippedSvgProvider].
///
/// Drop this in anywhere that previously used [AvatarDisplay] directly — the
/// HUD greeting, the task-screen peek, the result celebration, profile, etc.
/// As soon as `shopProvider.equip(...)` runs anywhere in the app, every
/// [EquippedAvatar] re-renders with the new look.
class EquippedAvatar extends ConsumerWidget {
  final AssistantType assistantType;
  final double size;
  final AvatarAnimation animation;

  const EquippedAvatar({
    super.key,
    required this.assistantType,
    this.size = 160,
    this.animation = AvatarAnimation.idle,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final equipped = ref.watch(equippedSvgProvider);
    // Kick off the first load lazily so a HUD that mounts before the shop
    // screen still gets the saved look.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(shopProvider.notifier).ensureLoaded();
    });
    return AvatarDisplay(
      assistantType: assistantType,
      equipped: equipped,
      animation: animation,
      size: size,
    );
  }
}
