import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../core/constants/app_config.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import 'avatar_display.dart';

/// Side-by-side companion picker used on the assistant-selection screen.
///
/// The selected card lifts and gains a gold glow, its avatar waves, and the
/// other card dims. Tapping a card reports the choice via [onSelect].
class AvatarSelector extends StatelessWidget {
  final AssistantType? selected;
  final ValueChanged<AssistantType> onSelect;

  const AvatarSelector({super.key, required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          child: _AvatarChoiceCard(
            info: AssistantInfo.bektur,
            isSelected: selected == AssistantType.bektur,
            isDimmed: selected == AssistantType.nazym,
            onTap: () => onSelect(AssistantType.bektur),
          ),
        ),
        AppSpacing.gapH16,
        Expanded(
          child: _AvatarChoiceCard(
            info: AssistantInfo.nazym,
            isSelected: selected == AssistantType.nazym,
            isDimmed: selected == AssistantType.bektur,
            onTap: () => onSelect(AssistantType.nazym),
          ),
        ),
      ],
    );
  }
}

class _AvatarChoiceCard extends StatelessWidget {
  final AssistantInfo info;
  final bool isSelected;
  final bool isDimmed;
  final VoidCallback onTap;

  const _AvatarChoiceCard({
    required this.info,
    required this.isSelected,
    required this.isDimmed,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 250),
        opacity: isDimmed ? 0.45 : 1,
        child: AnimatedScale(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
          scale: isSelected ? 1.04 : 1,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            padding: const EdgeInsets.all(AppSpacing.md),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: AppRadius.radiusXl,
              border: Border.all(
                color: isSelected ? AppColors.steppeGold : Colors.transparent,
                width: 3,
              ),
              boxShadow: isSelected
                  ? [
                      BoxShadow(
                        color: AppColors.steppeGold.withValues(alpha: 0.5),
                        blurRadius: 28,
                        offset: const Offset(0, 10),
                      ),
                    ]
                  : const [
                      BoxShadow(
                        color: AppColors.shadowMedium,
                        blurRadius: 16,
                        offset: Offset(0, 8),
                      ),
                    ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  alignment: Alignment.topRight,
                  children: [
                    AvatarDisplay(
                      assistantType: info.type,
                      size: 104,
                      animation: isSelected
                          ? AvatarAnimation.wave
                          : AvatarAnimation.idle,
                    ),
                    if (isSelected)
                      const Icon(Icons.auto_awesome,
                              color: AppColors.steppeGold, size: 26)
                          .animate(onPlay: (c) => c.repeat(reverse: true))
                          .scale(
                            duration: 700.ms,
                            begin: const Offset(0.8, 0.8),
                            end: const Offset(1.2, 1.2),
                          ),
                  ],
                ),
                AppSpacing.gapV12,
                Text(info.name, style: AppTypography.h3),
                AppSpacing.gapV8,
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppSpacing.sm,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: info.surfaceColor,
                    borderRadius: AppRadius.radiusPill,
                  ),
                  child: Text(
                    info.tag,
                    style: AppTypography.caption.copyWith(color: info.color),
                  ),
                ),
                AppSpacing.gapV12,
                Text(
                  info.bio,
                  textAlign: TextAlign.center,
                  style: AppTypography.caption.copyWith(
                    color: AppColors.textSecondary,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
