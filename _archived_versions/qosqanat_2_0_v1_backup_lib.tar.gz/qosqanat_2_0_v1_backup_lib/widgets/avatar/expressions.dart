/// Facial expression SVGs for the QosQanat avatars.
///
/// The face is a single composable layer (eyes + mouth + extras) drawn over the
/// head in the shared 200×240 viewBox used by every avatar layer, so it swaps
/// independently of body and clothing.
library;

/// The set of expressions an avatar can wear.
enum AvatarExpression {
  neutral,
  happy,
  sad,
  surprised,
  thinking,
  celebrate,
}

const String _ink = '#2A2A3E';

String _wrap(String inner) =>
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 240">$inner</svg>';

/// Builds the full SVG for the face layer.
///
/// [blink] briefly closes the eyes (ignored for [AvatarExpression.celebrate],
/// whose eyes are already closed). [blush] tints the cheeks for warm
/// expressions.
String faceLayerSvg({
  required AvatarExpression expression,
  bool blink = false,
  String ink = _ink,
  String blush = '#FF8FB1',
}) {
  final closed = blink && expression != AvatarExpression.celebrate;
  final eyes = closed ? _closedEyes(ink) : _eyes(expression, ink);
  final mouth = _mouth(expression, ink);
  final extras = _extras(expression, ink, blush);
  return _wrap('$extras$eyes$mouth');
}

// -----------------------------------------------------------------------------
// Eyes
// -----------------------------------------------------------------------------
String _closedEyes(String ink) =>
    '<path d="M73 64 Q82 71 91 64" fill="none" stroke="$ink" stroke-width="4" '
    'stroke-linecap="round"/>'
    '<path d="M109 64 Q118 71 127 64" fill="none" stroke="$ink" '
    'stroke-width="4" stroke-linecap="round"/>';

String _eyes(AvatarExpression e, String ink) {
  switch (e) {
    case AvatarExpression.celebrate:
      // Happy closed ^_^ eyes.
      return '<path d="M73 66 Q82 56 91 66" fill="none" stroke="$ink" '
          'stroke-width="4.5" stroke-linecap="round"/>'
          '<path d="M109 66 Q118 56 127 66" fill="none" stroke="$ink" '
          'stroke-width="4.5" stroke-linecap="round"/>';
    case AvatarExpression.surprised:
      return _roundEye(82, 64, 11, ink) + _roundEye(118, 64, 11, ink);
    case AvatarExpression.thinking:
      // Pupils glance upward + a raised brow.
      return '<path d="M72 50 Q82 45 92 50" fill="none" stroke="$ink" '
          'stroke-width="3" stroke-linecap="round"/>'
          '${_pupil(82, 60, 8, ink)}${_pupil(118, 62, 8, ink)}';
    case AvatarExpression.sad:
      // Sad slanted brows + downcast eyes.
      return '<path d="M74 54 Q82 50 90 56" fill="none" stroke="$ink" '
          'stroke-width="3" stroke-linecap="round"/>'
          '<path d="M110 56 Q118 50 126 54" fill="none" stroke="$ink" '
          'stroke-width="3" stroke-linecap="round"/>'
          '${_pupil(82, 66, 8, ink)}${_pupil(118, 66, 8, ink)}';
    case AvatarExpression.neutral:
    case AvatarExpression.happy:
      return _pupil(82, 64, 9, ink) + _pupil(118, 64, 9, ink);
  }
}

String _pupil(double cx, double cy, double r, String ink) =>
    '<circle cx="$cx" cy="$cy" r="$r" fill="$ink"/>'
    '<circle cx="${cx - 3}" cy="${cy - 3}" r="3" fill="#FFFFFF"/>';

String _roundEye(double cx, double cy, double r, String ink) =>
    '<circle cx="$cx" cy="$cy" r="$r" fill="#FFFFFF" stroke="$ink" '
    'stroke-width="2.5"/>'
    '<circle cx="$cx" cy="$cy" r="${r * 0.45}" fill="$ink"/>';

// -----------------------------------------------------------------------------
// Mouth
// -----------------------------------------------------------------------------
String _mouth(AvatarExpression e, String ink) {
  switch (e) {
    case AvatarExpression.neutral:
      return '<path d="M88 88 Q100 96 112 88" fill="none" stroke="$ink" '
          'stroke-width="4" stroke-linecap="round"/>';
    case AvatarExpression.happy:
      return '<path d="M84 86 Q100 104 116 86 Z" fill="$ink"/>'
          '<path d="M94 96 Q100 101 106 96 Z" fill="#FF7A8A"/>';
    case AvatarExpression.celebrate:
      return '<path d="M80 84 Q100 110 120 84 Z" fill="$ink"/>'
          '<path d="M92 96 Q100 103 108 96 Z" fill="#FF7A8A"/>';
    case AvatarExpression.surprised:
      return '<ellipse cx="100" cy="92" rx="7" ry="9" fill="$ink"/>';
    case AvatarExpression.thinking:
      return '<path d="M92 92 Q102 89 110 93" fill="none" stroke="$ink" '
          'stroke-width="4" stroke-linecap="round"/>';
    case AvatarExpression.sad:
      return '<path d="M88 95 Q100 86 112 95" fill="none" stroke="$ink" '
          'stroke-width="4" stroke-linecap="round"/>';
  }
}

// -----------------------------------------------------------------------------
// Extras: blush, tears, sparkles
// -----------------------------------------------------------------------------
String _extras(AvatarExpression e, String ink, String blush) {
  switch (e) {
    case AvatarExpression.happy:
    case AvatarExpression.celebrate:
      final blushMarks =
          '<ellipse cx="68" cy="80" rx="9" ry="6" fill="$blush" '
          'fill-opacity="0.55"/>'
          '<ellipse cx="132" cy="80" rx="9" ry="6" fill="$blush" '
          'fill-opacity="0.55"/>';
      if (e == AvatarExpression.celebrate) {
        return '$blushMarks'
            '<g fill="#F5A623">'
            '<path d="M40 44 l3 7 7 3 -7 3 -3 7 -3 -7 -7 -3 7 -3 z"/>'
            '<path d="M162 38 l2.5 6 6 2.5 -6 2.5 -2.5 6 -2.5 -6 -6 -2.5 6 -2.5 z"/>'
            '<path d="M150 96 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2 z"/>'
            '</g>';
      }
      return blushMarks;
    case AvatarExpression.sad:
      return '<ellipse cx="74" cy="78" rx="4" ry="6" fill="#5BC8FF"/>';
    case AvatarExpression.thinking:
      return '<circle cx="150" cy="40" r="4" fill="$ink" fill-opacity="0.5"/>'
          '<circle cx="162" cy="30" r="6" fill="$ink" fill-opacity="0.5"/>';
    case AvatarExpression.neutral:
    case AvatarExpression.surprised:
      return '';
  }
}
