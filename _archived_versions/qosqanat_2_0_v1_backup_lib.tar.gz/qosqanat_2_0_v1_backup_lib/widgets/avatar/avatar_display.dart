import 'dart:async';
import 'dart:ui' show lerpDouble;

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../models/enums.dart';
import 'avatar_base.dart';
import 'expressions.dart';

/// High-level animation states for an avatar.
enum AvatarAnimation { idle, celebrate, sad, wave, thinking }

/// Animated wrapper around [AvatarBase].
///
/// A continuous controller drives a gentle idle float, a periodic timer drives
/// eye blinks, and one-shot [AvatarAnimation]s (celebrate / sad / wave /
/// thinking) replay via flutter_animate whenever [animation] changes. All
/// controllers/timers are disposed.
class AvatarDisplay extends StatefulWidget {
  final AssistantType assistantType;
  final Map<String, String> equipped;
  final AvatarAnimation animation;

  /// Overrides the expression implied by [animation] when provided.
  final AvatarExpression? expression;
  final double size;

  const AvatarDisplay({
    super.key,
    required this.assistantType,
    this.equipped = const {},
    this.animation = AvatarAnimation.idle,
    this.expression,
    this.size = 160,
  });

  @override
  State<AvatarDisplay> createState() => _AvatarDisplayState();
}

class _AvatarDisplayState extends State<AvatarDisplay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _floatController;
  late final Animation<double> _float;
  Timer? _blinkTimer;
  bool _blinking = false;
  int _trigger = 0; // bumping this restarts the one-shot animation

  @override
  void initState() {
    super.initState();
    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);
    _float = CurvedAnimation(parent: _floatController, curve: Curves.easeInOut);
    _scheduleBlink();
  }

  void _scheduleBlink() {
    _blinkTimer = Timer.periodic(const Duration(milliseconds: 3500), (_) {
      if (!mounted) return;
      setState(() => _blinking = true);
      Future<void>.delayed(const Duration(milliseconds: 130), () {
        if (mounted) setState(() => _blinking = false);
      });
    });
  }

  @override
  void didUpdateWidget(covariant AvatarDisplay oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.animation != widget.animation &&
        widget.animation != AvatarAnimation.idle) {
      setState(() => _trigger++);
    }
  }

  @override
  void dispose() {
    _blinkTimer?.cancel();
    _floatController.dispose();
    super.dispose();
  }

  AvatarExpression get _expression {
    if (widget.expression != null) return widget.expression!;
    switch (widget.animation) {
      case AvatarAnimation.celebrate:
        return AvatarExpression.celebrate;
      case AvatarAnimation.sad:
        return AvatarExpression.sad;
      case AvatarAnimation.wave:
        return AvatarExpression.happy;
      case AvatarAnimation.thinking:
        return AvatarExpression.thinking;
      case AvatarAnimation.idle:
        return AvatarExpression.neutral;
    }
  }

  Widget _applyAnimation(Widget avatar) {
    final key = ValueKey(_trigger);
    switch (widget.animation) {
      case AvatarAnimation.idle:
        return avatar;
      case AvatarAnimation.celebrate:
        return avatar
            .animate(key: key)
            .moveY(begin: 0, end: -30, duration: 320.ms, curve: Curves.easeOut)
            .scaleXY(begin: 1, end: 1.08, duration: 320.ms)
            .then()
            .moveY(begin: -30, end: 0, duration: 700.ms, curve: Curves.elasticOut)
            .scaleXY(begin: 1.08, end: 1, duration: 700.ms);
      case AvatarAnimation.sad:
        return avatar
            .animate(key: key)
            .moveY(begin: 0, end: 8, duration: 220.ms, curve: Curves.easeIn)
            .scaleXY(begin: 1, end: 0.97, duration: 220.ms)
            .then()
            .moveY(begin: 8, end: 0, duration: 600.ms, curve: Curves.easeOut);
      case AvatarAnimation.wave:
        return avatar
            .animate(key: key)
            .shake(duration: 700.ms, hz: 3, rotation: 0.10);
      case AvatarAnimation.thinking:
        return avatar.animate(key: key).rotate(
              begin: 0,
              end: -0.035,
              duration: 400.ms,
              curve: Curves.easeOut,
            );
    }
  }

  @override
  Widget build(BuildContext context) {
    final avatar = AvatarBase(
      assistantType: widget.assistantType,
      equipped: widget.equipped,
      expression: _expression,
      blink: _blinking,
      size: widget.size,
    );

    final animated = _applyAnimation(avatar);

    return AnimatedBuilder(
      animation: _float,
      child: animated,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, lerpDouble(3, -5, _float.value)!),
          child: child,
        );
      },
    );
  }
}
