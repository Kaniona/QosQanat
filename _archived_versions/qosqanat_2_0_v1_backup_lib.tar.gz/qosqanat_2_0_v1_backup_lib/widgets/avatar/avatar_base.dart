import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../models/enums.dart';
import 'expressions.dart';

/// Equipment slot keys for the [AvatarBase.equipped] override map. Providing an
/// SVG string for a slot replaces that layer's default art, so clothing swaps
/// independently of the body.
class AvatarSlot {
  AvatarSlot._();
  static const String pet = 'pet';
  static const String bottom = 'bottom';
  static const String shoes = 'shoes';
  static const String top = 'top';
  static const String neck = 'neck';
  static const String hat = 'hat';
  static const String faceAccessory = 'face_accessory';
}

/// Per-character color palette (hex strings, used directly inside SVG markup).
class AvatarPalette {
  final String skin;
  final String skinShadow;
  final String hair;
  final String ink;
  final String accent;
  final String accentDark;
  final String shirt;
  final String pants;
  final String shoes;
  final String blush;

  const AvatarPalette({
    required this.skin,
    required this.skinShadow,
    required this.hair,
    required this.ink,
    required this.accent,
    required this.accentDark,
    required this.shirt,
    required this.pants,
    required this.shoes,
    required this.blush,
  });

  /// Bektur — tan skin, short black hair, blue accents.
  static const AvatarPalette bektur = AvatarPalette(
    skin: '#E8B98C',
    skinShadow: '#D49E73',
    hair: '#1E1E2A',
    ink: '#2A2A3E',
    accent: '#4A6CF7',
    accentDark: '#2F4ECC',
    shirt: '#4A6CF7',
    pants: '#33384D',
    shoes: '#1E1E2A',
    blush: '#FF9E7A',
  );

  /// Nazym — lighter skin, long black hair, rose accents.
  static const AvatarPalette nazym = AvatarPalette(
    skin: '#F6D7BE',
    skinShadow: '#E6BFA0',
    hair: '#23202E',
    ink: '#2A2A3E',
    accent: '#FF6B9D',
    accentDark: '#D64A7B',
    shirt: '#FF6B9D',
    pants: '#6B5B95',
    shoes: '#23202E',
    blush: '#FF8FB1',
  );

  static AvatarPalette of(AssistantType type) =>
      type == AssistantType.nazym ? nazym : bektur;
}

/// A layered SVG character (Bektur / Nazym) composed in strict z-order:
///   pet → shadow → body → bottom → shoes → top → neck → face → hair → hat →
///   face accessory.
///
/// Each layer is an independent SVG drawn in the same 200×240 coordinate space,
/// so any clothing slot can be swapped via [equipped] without touching the rest.
class AvatarBase extends StatelessWidget {
  final AssistantType assistantType;
  final Map<String, String> equipped;
  final AvatarExpression expression;
  final bool blink;
  final double size;

  const AvatarBase({
    super.key,
    required this.assistantType,
    this.equipped = const {},
    this.expression = AvatarExpression.neutral,
    this.blink = false,
    this.size = 160,
  });

  @override
  Widget build(BuildContext context) {
    final p = AvatarPalette.of(assistantType);
    final t = assistantType;

    // z-ordered layers; nulls (absent optional slots) are skipped.
    final layers = <String?>[
      equipped[AvatarSlot.pet],
      _shadow(),
      _body(p, t),
      equipped[AvatarSlot.bottom] ?? _bottom(p, t),
      equipped[AvatarSlot.shoes] ?? _shoes(p),
      equipped[AvatarSlot.top] ?? _top(p),
      equipped[AvatarSlot.neck],
      faceLayerSvg(
        expression: expression,
        blink: blink,
        ink: p.ink,
        blush: p.blush,
      ),
      _hair(p, t),
      equipped[AvatarSlot.hat],
      equipped[AvatarSlot.faceAccessory],
    ];

    return SizedBox(
      width: size,
      height: size * 1.2, // viewBox is 200×240
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          for (final svg in layers)
            if (svg != null && svg.isNotEmpty)
              Positioned.fill(
                child: SvgPicture.string(svg, fit: BoxFit.contain),
              ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Layer builders
  // ---------------------------------------------------------------------------
  static String _wrap(String inner) =>
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 240">$inner</svg>';

  String _shadow() => _wrap(
        '<ellipse cx="100" cy="228" rx="50" ry="9" fill="#1A1A4E" '
        'fill-opacity="0.15"/>',
      );

  String _body(AvatarPalette p, AssistantType t) {
    // Nazym's long hair falls behind the body/head.
    final backHair = t == AssistantType.nazym
        ? '<path d="M48 60 Q46 30 100 26 Q154 30 152 60 Q158 150 132 200 '
            'L68 200 Q42 150 48 60 Z" fill="${p.hair}"/>'
        : '';
    return _wrap('''
      $backHair
      <rect x="82" y="176" width="14" height="46" rx="7" fill="${p.skin}"/>
      <rect x="104" y="176" width="14" height="46" rx="7" fill="${p.skin}"/>
      <ellipse cx="58" cy="150" rx="13" ry="30" fill="${p.skin}"/>
      <ellipse cx="142" cy="150" rx="13" ry="30" fill="${p.skin}"/>
      <circle cx="56" cy="176" r="11" fill="${p.skin}"/>
      <circle cx="144" cy="176" r="11" fill="${p.skin}"/>
      <rect x="64" y="116" width="72" height="74" rx="26" fill="${p.skin}"/>
      <rect x="90" y="100" width="20" height="20" rx="6" fill="${p.skinShadow}"/>
      <circle cx="100" cy="66" r="46" fill="${p.skin}"/>
      <circle cx="56" cy="70" r="9" fill="${p.skin}"/>
      <circle cx="144" cy="70" r="9" fill="${p.skin}"/>
    ''');
  }

  String _bottom(AvatarPalette p, AssistantType t) {
    if (t == AssistantType.nazym) {
      // Flared skirt.
      return _wrap(
        '<path d="M66 168 L134 168 L148 208 L52 208 Z" fill="${p.pants}"/>',
      );
    }
    return _wrap('''
      <rect x="68" y="168" width="64" height="26" rx="12" fill="${p.pants}"/>
      <rect x="80" y="186" width="18" height="38" rx="8" fill="${p.pants}"/>
      <rect x="102" y="186" width="18" height="38" rx="8" fill="${p.pants}"/>
    ''');
  }

  String _shoes(AvatarPalette p) => _wrap('''
      <ellipse cx="89" cy="222" rx="15" ry="9" fill="${p.shoes}"/>
      <ellipse cx="111" cy="222" rx="15" ry="9" fill="${p.shoes}"/>
    ''');

  String _top(AvatarPalette p) => _wrap('''
      <path d="M60 120 Q100 104 140 120 L140 178 Q100 190 60 178 Z"
            fill="${p.shirt}"/>
      <circle cx="58" cy="132" r="17" fill="${p.shirt}"/>
      <circle cx="142" cy="132" r="17" fill="${p.shirt}"/>
      <path d="M86 112 Q100 124 114 112" fill="none" stroke="${p.accentDark}"
            stroke-width="3" stroke-linecap="round"/>
    ''');

  String _hair(AvatarPalette p, AssistantType t) {
    if (t == AssistantType.nazym) {
      // Center-parted bangs + front side locks.
      return _wrap('''
        <path d="M52 66 Q48 22 100 20 Q152 22 148 66 Q144 46 124 46
                 Q116 60 108 46 Q100 64 92 46 Q84 60 76 46 Q56 46 52 66 Z"
              fill="${p.hair}"/>
        <path d="M50 60 Q44 120 60 156 L70 156 Q56 112 64 64 Z"
              fill="${p.hair}"/>
        <path d="M150 60 Q156 120 140 156 L130 156 Q144 112 136 64 Z"
              fill="${p.hair}"/>
      ''');
    }
    // Bektur — short, spiky.
    return _wrap('''
      <path d="M54 66 Q50 24 100 22 Q150 24 146 66 Q140 42 122 44
               Q112 30 100 42 Q88 30 78 44 Q60 42 54 66 Z" fill="${p.hair}"/>
    ''');
  }
}
