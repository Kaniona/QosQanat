import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/levels.dart';

/// XP progress bar: a gold level badge, a gradient fill with a glowing leading
/// edge, and the remaining-XP label.
class XpBar extends StatelessWidget {
  /// Current level (1–100), shown in the gold badge.
  final int level;

  /// Fill ratio through the current level, 0.0–1.0.
  final double progress;

  /// Optional "X / Y XP" label values.
  final int? xpInto;
  final int? xpSpan;

  final double height;

  const XpBar({
    super.key,
    required this.level,
    required this.progress,
    this.xpInto,
    this.xpSpan,
    this.height = 16,
  });

  /// Builds the bar directly from a total-XP value using the level curve.
  factory XpBar.fromTotalXp({
    Key? key,
    required int totalXp,
    double height = 16,
  }) {
    final lvl = calculateLevel(totalXp);
    return XpBar(
      key: key,
      level: lvl,
      progress: levelProgress(totalXp),
      xpInto: xpIntoCurrentLevel(totalXp),
      xpSpan: xpSpanForLevel(lvl),
      height: height,
    );
  }

  @override
  Widget build(BuildContext context) {
    final clamped = progress.clamp(0.0, 1.0);
    return Row(
      children: [
        _LevelBadge(level: level, size: height + 16),
        AppSpacing.gapH12,
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              LayoutBuilder(
                builder: (context, constraints) {
                  final fillWidth = constraints.maxWidth * clamped;
                  return Stack(
                    children: [
                      // Track
                      Container(
                        height: height,
                        decoration: BoxDecoration(
                          color: AppColors.surfaceMuted,
                          borderRadius: BorderRadius.circular(999),
                        ),
                      ),
                      // Fill
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 400),
                        curve: Curves.easeOut,
                        height: height,
                        width: fillWidth,
                        decoration: BoxDecoration(
                          gradient: AppColors.cosmicNight,
                          borderRadius: BorderRadius.circular(999),
                        ),
                      ),
                      // Glowing leading edge
                      if (clamped > 0 && clamped < 1)
                        AnimatedPositioned(
                          duration: const Duration(milliseconds: 400),
                          curve: Curves.easeOut,
                          left: (fillWidth - height / 2)
                              .clamp(0.0, constraints.maxWidth - height),
                          child: Container(
                            width: height,
                            height: height,
                            decoration: BoxDecoration(
                              color: AppColors.cosmicPurpleLight,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.cosmicPurple
                                      .withValues(alpha: 0.8),
                                  blurRadius: 10,
                                  spreadRadius: 1,
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  );
                },
              ),
              if (xpInto != null && xpSpan != null) ...[
                AppSpacing.gapV4,
                Text(
                  '$xpInto / $xpSpan XP',
                  textAlign: TextAlign.right,
                  style: AppTypography.caption,
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _LevelBadge extends StatelessWidget {
  final int level;
  final double size;

  const _LevelBadge({required this.level, required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: AppColors.goldSoar,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: AppColors.steppeGold.withValues(alpha: 0.45),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Text(
        '$level',
        style: AppTypography.caption.copyWith(
          color: AppColors.nightInk,
          fontWeight: FontWeight.w800,
          fontSize: size * 0.4,
        ),
      ),
    );
  }
}
