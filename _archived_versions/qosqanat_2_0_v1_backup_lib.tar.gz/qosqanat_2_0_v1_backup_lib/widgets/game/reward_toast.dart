import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../core/constants/game_strings.dart';

/// The three reward currencies, each color-coded in the toast.
enum RewardKind { xp, coins, akyl }

/// A floating, color-coded reward notification that rises and fades near the
/// top of the screen.
class RewardToast {
  RewardToast._();

  /// Shows a transient reward toast above the current screen.
  static void show(
    BuildContext context, {
    required RewardKind kind,
    required int amount,
  }) {
    final overlay = Overlay.of(context);
    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => _RewardToastView(
        kind: kind,
        amount: amount,
        onDismiss: () => entry.remove(),
      ),
    );
    overlay.insert(entry);
  }
}

class _RewardToastView extends StatefulWidget {
  final RewardKind kind;
  final int amount;
  final VoidCallback onDismiss;

  const _RewardToastView({
    required this.kind,
    required this.amount,
    required this.onDismiss,
  });

  @override
  State<_RewardToastView> createState() => _RewardToastViewState();
}

class _RewardToastViewState extends State<_RewardToastView>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..forward();
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) widget.onDismiss();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  ({Color color, IconData icon, String label}) get _style {
    switch (widget.kind) {
      case RewardKind.xp:
        return (
          color: AppColors.cosmicPurple,
          icon: Icons.auto_graph_rounded,
          label: GameStrings.xpGained,
        );
      case RewardKind.coins:
        return (
          color: AppColors.steppeGold,
          icon: Icons.monetization_on_rounded,
          label: GameStrings.coinsGained,
        );
      case RewardKind.akyl:
        return (
          color: AppColors.eagleBlue,
          icon: Icons.star_rounded,
          label: GameStrings.akylGained,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = _style;
    final topInset = MediaQuery.of(context).padding.top;

    return Positioned(
      top: topInset + 16,
      left: 0,
      right: 0,
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            final t = _controller.value;
            // Fade/slide in (0–0.2), hold (0.2–0.75), fade/slide out (0.75–1).
            final double opacity;
            final double offsetY;
            if (t < 0.2) {
              final p = t / 0.2;
              opacity = p;
              offsetY = 20 * (1 - p);
            } else if (t < 0.75) {
              opacity = 1;
              offsetY = 0;
            } else {
              final p = (t - 0.75) / 0.25;
              opacity = 1 - p;
              offsetY = -16 * p;
            }
            return Opacity(
              opacity: opacity.clamp(0.0, 1.0),
              child: Transform.translate(offset: Offset(0, offsetY), child: child),
            );
          },
          child: Center(
            child: Material(
              color: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.md,
                  vertical: AppSpacing.xs,
                ),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: AppRadius.radiusPill,
                  border: Border.all(color: s.color.withValues(alpha: 0.4)),
                  boxShadow: const [
                    BoxShadow(
                      color: AppColors.shadowMedium,
                      blurRadius: 16,
                      offset: Offset(0, 6),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(s.icon, color: s.color, size: 22),
                    AppSpacing.gapH8,
                    Text(
                      '+${widget.amount} ${s.label}',
                      style: AppTypography.body.copyWith(
                        color: s.color,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
