import 'dart:math';

import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../core/constants/game_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../ui/primary_button.dart';

/// Shows the level-up celebration modal. Returns when the user dismisses it.
Future<void> showLevelUpModal(
  BuildContext context, {
  required int newLevel,
  required String title,
  required int coinReward,
}) {
  return showDialog<void>(
    context: context,
    barrierDismissible: false,
    barrierColor: AppColors.nightInk.withValues(alpha: 0.75),
    builder: (_) => LevelUpModal(
      newLevel: newLevel,
      title: title,
      coinReward: coinReward,
    ),
  );
}

/// Celebration dialog for reaching a new level: confetti burst, spring scale-in,
/// glowing gold level badge, revealed rank title, and the coin reward.
class LevelUpModal extends StatefulWidget {
  final int newLevel;
  final String title;
  final int coinReward;

  const LevelUpModal({
    super.key,
    required this.newLevel,
    required this.title,
    required this.coinReward,
  });

  @override
  State<LevelUpModal> createState() => _LevelUpModalState();
}

class _LevelUpModalState extends State<LevelUpModal> {
  late final ConfettiController _confetti;

  @override
  void initState() {
    super.initState();
    _confetti = ConfettiController(duration: const Duration(seconds: 2))..play();
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.topCenter,
      children: [
        Align(
          alignment: Alignment.center,
          child: SingleChildScrollView(
            child: Padding(
              padding: AppSpacing.screenPadding,
              child: _card(context),
            ),
          ),
        ),
        // Confetti rains from the top.
        ConfettiWidget(
          confettiController: _confetti,
          blastDirection: pi / 2,
          maxBlastForce: 18,
          minBlastForce: 8,
          emissionFrequency: 0.05,
          numberOfParticles: 18,
          gravity: 0.25,
          colors: const [
            AppColors.steppeGold,
            AppColors.eagleBlue,
            AppColors.cosmicPurple,
            AppColors.jade,
          ],
        ),
      ],
    );
  }

  Widget _card(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.xl),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.radiusXl,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            GameStrings.levelUpTitle,
            style: AppTypography.h2.copyWith(color: AppColors.cosmicPurple),
          ),
          AppSpacing.gapV20,

          // Glowing gold level badge.
          Container(
            width: 132,
            height: 132,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              gradient: AppColors.goldSoar,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppColors.steppeGold.withValues(alpha: 0.6),
                  blurRadius: 36,
                  spreadRadius: 4,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  GameStrings.newLevelLabel,
                  style: AppTypography.caption
                      .copyWith(color: AppColors.nightInk),
                ),
                Text(
                  '${widget.newLevel}',
                  style: AppTypography.displayLarge
                      .copyWith(color: AppColors.nightInk),
                ),
              ],
            ),
          )
              .animate()
              .scale(
                duration: 600.ms,
                curve: Curves.elasticOut,
                begin: const Offset(0.5, 0.5),
                end: const Offset(1, 1),
              )
              .fadeIn(duration: 250.ms),

          AppSpacing.gapV20,

          // Revealed rank title.
          Text(
            widget.title,
            textAlign: TextAlign.center,
            style: AppTypography.h3,
          ).animate().fadeIn(delay: 400.ms).slideY(begin: 0.3),

          if (widget.coinReward > 0) ...[
            AppSpacing.gapV16,
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.md,
                vertical: AppSpacing.xs,
              ),
              decoration: BoxDecoration(
                color: AppColors.steppeGoldSurface,
                borderRadius: AppRadius.radiusPill,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('💰', style: TextStyle(fontSize: 22)),
                  AppSpacing.gapH8,
                  Text(
                    '+${widget.coinReward}',
                    style: AppTypography.h3
                        .copyWith(color: AppColors.steppeGoldDark),
                  ),
                ],
              ),
            ).animate().fadeIn(delay: 600.ms).scale(
                  begin: const Offset(0.8, 0.8),
                  end: const Offset(1, 1),
                  curve: Curves.easeOutBack,
                ),
          ],

          AppSpacing.gapV24,
          PrimaryButton(
            label: GameStrings.awesome,
            gradient: AppColors.goldSoar,
            onPressed: () => Navigator.of(context).pop(),
          ),
        ],
      ),
    );
  }
}
