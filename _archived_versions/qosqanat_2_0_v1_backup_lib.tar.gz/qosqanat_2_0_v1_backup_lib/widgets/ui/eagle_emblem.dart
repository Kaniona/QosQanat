import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// QosQanat eagle-wings emblem.
///
/// Placeholder vector mark (a stylized winged badge) standing in for the final
/// brand logo from `design_reference/`. Swap the inner [Icon] for the real
/// SVG/Lottie asset once available.
class EagleEmblem extends StatelessWidget {
  final double size;
  final bool onDark;

  const EagleEmblem({super.key, this.size = 96, this.onDark = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: onDark ? AppColors.goldSoar : AppColors.eagle,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: (onDark ? AppColors.steppeGold : AppColors.eagleBlue)
                .withValues(alpha: 0.35),
            blurRadius: size * 0.3,
            offset: Offset(0, size * 0.1),
          ),
        ],
      ),
      child: Icon(
        Icons.flutter_dash, // placeholder eagle silhouette
        size: size * 0.58,
        color: AppColors.textOnDark,
      ),
    );
  }
}
