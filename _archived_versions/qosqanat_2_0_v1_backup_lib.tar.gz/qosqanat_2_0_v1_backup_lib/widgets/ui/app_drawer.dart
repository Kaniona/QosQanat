import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_config.dart';
import '../../core/constants/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/user.dart';
import '../../navigation/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../providers/game_provider.dart';
import '../../providers/social_provider.dart';
import 'oyu_ornek_divider.dart';
import 'profile_photo.dart';

/// Left side drawer: slides in on a left-edge swipe from any tab. ~78% width,
/// rounded right corners, an ою-өрнек watermark, a user header, the three main
/// nav rows (Турнир, Достар, Баптаулар), smaller links, and a footer.
class AppDrawer extends ConsumerWidget {
  const AppDrawer({super.key});

  void _go(BuildContext context, String route) {
    Navigator.of(context).pop(); // close the drawer first
    context.push(route);
  }

  Future<void> _logout(BuildContext context, WidgetRef ref) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: const RoundedRectangleBorder(borderRadius: AppRadius.radiusLg),
        title: const Text(AppStrings.logout),
        content: const Text('Аккаунттан шығасыз ба?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text(AppStrings.cancel),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.coral),
            child: const Text(AppStrings.logout),
          ),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    await ref.read(authControllerProvider.notifier).signOut();
    if (context.mounted) context.go(AppRoutes.welcome);
  }

  void _about(BuildContext context) {
    showAboutDialog(
      context: context,
      applicationName: AppStrings.appName,
      applicationVersion: AppConfig.appVersion,
      applicationLegalese: AppStrings.appTagline,
      children: const [
        Padding(
          padding: EdgeInsets.only(top: AppSpacing.md),
          child: Text(
            'QosQanat — қазақ мектеп оқушыларына арналған геймификацияланған '
            'білім беру қосымшасы.',
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final width = MediaQuery.of(context).size.width * 0.78;
    final user = ref.watch(currentUserProvider).asData?.value;
    final game = ref.watch(gameProvider);
    final pending = ref.watch(incomingRequestCountProvider);

    return Drawer(
      width: width,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.horizontal(right: Radius.circular(28)),
      ),
      child: Stack(
        children: [
          // Faint ою-өрнек watermark behind the content.
          Positioned(
            right: -30,
            bottom: 80,
            child: Opacity(
              opacity: 0.05,
              child: Icon(
                Icons.flutter_dash,
                size: 220,
                color: AppColors.eagleBlue,
              ),
            ),
          ),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _DrawerHeader(user: user, game: game),
                const OyuOrnekDivider(),
                AppSpacing.gapV8,
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppSpacing.md,
                    ),
                    children: [
                      _NavRow(
                        emoji: '🏆',
                        label: AppStrings.drawerTournament,
                        onTap: () => _go(context, AppRoutes.tournament),
                      ),
                      _NavRow(
                        emoji: '👥',
                        label: AppStrings.drawerFriends,
                        badge: pending,
                        onTap: () => _go(context, AppRoutes.friends),
                      ),
                      _NavRow(
                        emoji: '⚙️',
                        label: AppStrings.drawerSettings,
                        onTap: () => _go(context, AppRoutes.settings),
                      ),
                      AppSpacing.gapV16,
                      _SmallLink(
                        icon: Icons.support_agent_rounded,
                        label: AppStrings.drawerSupport,
                        onTap: () => _about(context),
                      ),
                      _SmallLink(
                        icon: Icons.info_outline_rounded,
                        label: AppStrings.drawerAboutApp,
                        onTap: () => _about(context),
                      ),
                    ],
                  ),
                ),
                _DrawerFooter(onLogout: () => _logout(context, ref)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DrawerHeader extends StatelessWidget {
  final AppUser? user;
  final GameState game;

  const _DrawerHeader({required this.user, required this.game});

  @override
  Widget build(BuildContext context) {
    final name = (user?.fullName ?? '').trim();
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.lg,
        AppSpacing.lg,
        AppSpacing.lg,
        AppSpacing.md,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _Avatar(url: user?.profilePhotoUrl, size: 64),
          AppSpacing.gapV12,
          Text(
            name.isEmpty ? AppStrings.appName : name,
            style: AppTypography.h3,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          if ((user?.qosqanatId ?? '').isNotEmpty) ...[
            AppSpacing.gapV8,
            _QqIdPill(id: user!.qosqanatId),
          ],
          AppSpacing.gapV16,
          _StatRow(game: game),
        ],
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  final String? url;
  final double size;

  const _Avatar({required this.url, required this.size});

  @override
  Widget build(BuildContext context) {
    final hasPhoto = url != null && url!.isNotEmpty;
    return Container(
      width: size,
      height: size,
      padding: const EdgeInsets.all(2.5),
      decoration: const BoxDecoration(
        gradient: AppColors.goldSoar,
        shape: BoxShape.circle,
      ),
      child: ClipOval(
        child: hasPhoto
            ? ProfilePhoto(url: url, fallback: const _DefaultAvatar())
            : const _DefaultAvatar(),
      ),
    );
  }
}

class _DefaultAvatar extends StatelessWidget {
  const _DefaultAvatar();

  @override
  Widget build(BuildContext context) {
    return const ColoredBox(
      color: AppColors.eagleBlueSurface,
      child: Icon(Icons.person_rounded, color: AppColors.eagleBlue, size: 34),
    );
  }
}

class _QqIdPill extends StatelessWidget {
  final String id;

  const _QqIdPill({required this.id});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.sm,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: AppColors.eagleBlueSurface,
        borderRadius: AppRadius.radiusPill,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.badge_rounded, size: 14, color: AppColors.eagleBlue),
          AppSpacing.gapH4,
          Text(
            '${AppStrings.qosqanatId}: $id',
            style: AppTypography.caption.copyWith(
              color: AppColors.eagleBlueDark,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  final GameState game;

  const _StatRow({required this.game});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _Stat(
          icon: Icons.military_tech_rounded,
          color: AppColors.steppeGold,
          value: '${game.level}',
          label: AppStrings.level,
        ),
        _Stat(
          icon: Icons.star_rounded,
          color: AppColors.cosmicPurple,
          value: '${game.akylPoints}',
          label: AppStrings.akyl,
        ),
        _Stat(
          icon: Icons.monetization_on_rounded,
          color: AppColors.steppeGoldDark,
          value: '${game.coins}',
          label: AppStrings.coins,
        ),
      ],
    );
  }
}

class _Stat extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String value;
  final String label;

  const _Stat({
    required this.icon,
    required this.color,
    required this.value,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: color, size: 22),
          AppSpacing.gapV4,
          Text(
            value,
            style: AppTypography.body.copyWith(fontWeight: FontWeight.w800),
          ),
          Text(label, style: AppTypography.caption),
        ],
      ),
    );
  }
}

class _NavRow extends StatelessWidget {
  final String emoji;
  final String label;
  final int badge;
  final VoidCallback onTap;

  const _NavRow({
    required this.emoji,
    required this.label,
    required this.onTap,
    this.badge = 0,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.xs),
      decoration: BoxDecoration(
        color: AppColors.surfaceMuted,
        borderRadius: AppRadius.radiusMd,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: AppRadius.radiusMd,
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.md,
              vertical: AppSpacing.md,
            ),
            child: Row(
              children: [
                Text(emoji, style: const TextStyle(fontSize: 22)),
                AppSpacing.gapH16,
                Expanded(
                  child: Text(
                    label,
                    style: AppTypography.body.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                if (badge > 0) _Badge(count: badge),
                const SizedBox(width: 4),
                const Icon(
                  Icons.chevron_right_rounded,
                  color: AppColors.textTertiary,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final int count;

  const _Badge({required this.count});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      constraints: const BoxConstraints(minWidth: 22),
      decoration: const BoxDecoration(
        color: AppColors.coral,
        borderRadius: AppRadius.radiusPill,
      ),
      child: Text(
        count > 99 ? '99+' : '$count',
        textAlign: TextAlign.center,
        style: AppTypography.caption.copyWith(
          color: AppColors.white,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _SmallLink extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _SmallLink({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: AppRadius.radiusMd,
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.xs,
          vertical: AppSpacing.sm,
        ),
        child: Row(
          children: [
            Icon(icon, size: 20, color: AppColors.textSecondary),
            AppSpacing.gapH12,
            Text(label, style: AppTypography.bodySecondary),
          ],
        ),
      ),
    );
  }
}

class _DrawerFooter extends StatelessWidget {
  final VoidCallback onLogout;

  const _DrawerFooter({required this.onLogout});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.md,
        AppSpacing.xs,
        AppSpacing.md,
        AppSpacing.md,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          InkWell(
            borderRadius: AppRadius.radiusMd,
            onTap: onLogout,
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.sm,
                vertical: AppSpacing.sm,
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.logout_rounded,
                    size: 20,
                    color: AppColors.coral,
                  ),
                  AppSpacing.gapH12,
                  Text(
                    AppStrings.logout,
                    style: AppTypography.body.copyWith(
                      color: AppColors.coral,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),
          AppSpacing.gapV4,
          Center(
            child: Text(
              '${AppStrings.version} ${AppConfig.appVersion}',
              style: AppTypography.caption.copyWith(
                color: AppColors.textTertiary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
