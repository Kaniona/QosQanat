import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../core/constants/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';

/// Friendly Kazakh fallback shown in place of Flutter's red error screen when a
/// widget throws during build. Installed as [ErrorWidget.builder] in `main`.
///
/// In debug mode the underlying exception is still surfaced (small, muted) to
/// keep development productive; in release it stays hidden from students.
class AppErrorView extends StatelessWidget {
  final FlutterErrorDetails details;

  const AppErrorView({super.key, required this.details});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: ColoredBox(
        color: AppColors.background,
        child: Center(
          child: Padding(
            padding: AppSpacing.screenPadding,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 88,
                  height: 88,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(
                    color: AppColors.coralSurface,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.sentiment_dissatisfied_rounded,
                    size: 44,
                    color: AppColors.coral,
                  ),
                ),
                AppSpacing.gapV20,
                Text(
                  AppStrings.error,
                  textAlign: TextAlign.center,
                  style: AppTypography.h2,
                ),
                AppSpacing.gapV8,
                Text(
                  AppStrings.errorGeneric,
                  textAlign: TextAlign.center,
                  style: AppTypography.bodySecondary,
                ),
                if (kDebugMode) ...[
                  AppSpacing.gapV16,
                  Text(
                    details.exceptionAsString(),
                    textAlign: TextAlign.center,
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.caption.copyWith(
                      color: AppColors.textTertiary,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
