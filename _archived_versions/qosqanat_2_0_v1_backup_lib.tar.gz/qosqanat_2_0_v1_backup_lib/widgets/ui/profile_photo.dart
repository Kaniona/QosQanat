import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

/// Renders a user's profile photo, transparently handling both remote URLs
/// (the live Supabase backend) and local file paths (offline test mode, where
/// the picked image is cached on disk). Falls back to [fallback] on error or
/// when [url] is null/empty.
class ProfilePhoto extends StatelessWidget {
  final String? url;
  final Widget fallback;
  final BoxFit fit;

  const ProfilePhoto({
    super.key,
    required this.url,
    required this.fallback,
    this.fit = BoxFit.cover,
  });

  @override
  Widget build(BuildContext context) {
    final value = url;
    if (value == null || value.isEmpty) return fallback;
    if (value.startsWith('http')) {
      return CachedNetworkImage(
        imageUrl: value,
        fit: fit,
        placeholder: (_, _) => fallback,
        errorWidget: (_, _, _) => fallback,
      );
    }
    return Image.file(File(value), fit: fit, errorBuilder: (_, _, _) => fallback);
  }
}
