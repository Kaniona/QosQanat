import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_elevation.dart';
import '../../core/theme/app_spacing.dart';
import 'pressable.dart';

/// Standard surface container for QosQanat content.
///
/// Gives every card the same rounded geometry, soft layered [AppElevation]
/// shadow, and (when [onTap] is set) the shared spring + haptic press via
/// [Pressable]. Prefer this over hand-rolled [Container] + [BoxShadow] so depth
/// and corner radius stay consistent app-wide.
class AppCard extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry padding;
  final Color color;
  final BorderRadius borderRadius;
  final List<BoxShadow> shadow;
  final Border? border;
  final Gradient? gradient;

  const AppCard({
    super.key,
    required this.child,
    this.onTap,
    this.padding = AppSpacing.cardPadding,
    this.color = AppColors.surface,
    this.borderRadius = AppRadius.radiusLg,
    this.shadow = AppElevation.card,
    this.border,
    this.gradient,
  });

  @override
  Widget build(BuildContext context) {
    final surface = AnimatedContainer(
      duration: const Duration(milliseconds: 160),
      padding: padding,
      decoration: BoxDecoration(
        color: gradient == null ? color : null,
        gradient: gradient,
        borderRadius: borderRadius,
        boxShadow: shadow,
        border: border,
      ),
      child: child,
    );

    if (onTap == null) return surface;

    return Pressable(
      onTap: onTap,
      borderRadius: borderRadius,
      child: surface,
    );
  }
}
