import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// A thin horizontal divider decorated with a repeating Kazakh oyu-ornek
/// (ою-өрнек) motif — a subtle diamond-and-hook band rendered with a painter.
class OyuOrnekDivider extends StatelessWidget {
  final Color color;
  final double height;

  const OyuOrnekDivider({
    super.key,
    this.color = AppColors.steppeGold,
    this.height = 14,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(
        painter: _OyuOrnekPainter(color.withValues(alpha: 0.5)),
      ),
    );
  }
}

class _OyuOrnekPainter extends CustomPainter {
  final Color color;

  _OyuOrnekPainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..strokeJoin = StrokeJoin.round;

    final midY = size.height / 2;

    // Faint baseline.
    canvas.drawLine(Offset(0, midY), Offset(size.width, midY), paint);

    // Repeating motif: a small diamond flanked by hooks.
    const unit = 26.0;
    final h = size.height * 0.42;
    for (double x = unit / 2; x < size.width; x += unit) {
      final path = Path()
        ..moveTo(x - 6, midY)
        ..lineTo(x, midY - h)
        ..lineTo(x + 6, midY)
        ..lineTo(x, midY + h)
        ..close()
        // hooks
        ..moveTo(x - 10, midY)
        ..quadraticBezierTo(x - 13, midY - h, x - 6, midY - h * 0.5)
        ..moveTo(x + 10, midY)
        ..quadraticBezierTo(x + 13, midY + h, x + 6, midY + h * 0.5);
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _OyuOrnekPainter oldDelegate) =>
      oldDelegate.color != color;
}
