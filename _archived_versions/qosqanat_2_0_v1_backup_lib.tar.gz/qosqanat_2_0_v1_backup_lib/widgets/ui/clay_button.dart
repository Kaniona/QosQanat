import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import 'clay_container.dart';

/// The primary call-to-action of QosQanat 2.0 — a colored claymorphism button
/// that physically depresses on tap. Defaults to the Jade "confirm" palette.
class ClayButton extends StatefulWidget {
  final String label;
  final VoidCallback? onTap;
  final List<Color> colors;
  final Color glow;
  final Color foreground;
  final IconData? icon;
  final String? trailingGlyph;
  final bool expand;
  final EdgeInsetsGeometry padding;

  const ClayButton({
    super.key,
    required this.label,
    required this.onTap,
    this.colors = const [AppColors.jadeLight, AppColors.jadeDark],
    this.glow = const Color(0x8000C48C),
    this.foreground = Colors.white,
    this.icon,
    this.trailingGlyph,
    this.expand = true,
    this.padding = const EdgeInsets.symmetric(vertical: 17, horizontal: 22),
  });

  /// Eagle-blue variant for "continue / next" actions.
  factory ClayButton.eagle({
    Key? key,
    required String label,
    required VoidCallback? onTap,
    IconData? icon,
    String? trailingGlyph,
    bool expand = true,
  }) {
    return ClayButton(
      key: key,
      label: label,
      onTap: onTap,
      icon: icon,
      trailingGlyph: trailingGlyph,
      expand: expand,
      colors: const [AppColors.eagleBlueLight, AppColors.eagleBlueDark],
      glow: const Color(0x802F4ECC),
    );
  }

  @override
  State<ClayButton> createState() => _ClayButtonState();
}

class _ClayButtonState extends State<ClayButton> {
  bool _pressed = false;

  bool get _enabled => widget.onTap != null;

  @override
  Widget build(BuildContext context) {
    final disabled = !_enabled;
    final row = Row(
      mainAxisSize: widget.expand ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (widget.icon != null) ...[
          Icon(widget.icon, color: widget.foreground, size: 20),
          AppSpacing.gapH8,
        ],
        Flexible(
          child: Text(
            widget.label,
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            style: AppTypography.button.copyWith(color: widget.foreground),
          ),
        ),
        if (widget.trailingGlyph != null) ...[
          AppSpacing.gapH8,
          Text(
            widget.trailingGlyph!,
            style: AppTypography.button.copyWith(color: widget.foreground),
          ),
        ],
      ],
    );

    return GestureDetector(
      onTapDown: _enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: _enabled ? (_) => setState(() => _pressed = false) : null,
      onTapCancel: _enabled ? () => setState(() => _pressed = false) : null,
      onTap: _enabled
          ? () {
              HapticFeedback.mediumImpact();
              widget.onTap!.call();
            }
          : null,
      child: Opacity(
        opacity: disabled ? 0.5 : 1,
        child: ClayContainer(
          radius: AppRadius.lg,
          pressed: _pressed,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: widget.colors,
          ),
          glow: widget.glow,
          padding: widget.padding,
          child: row,
        ),
      ),
    );
  }
}
