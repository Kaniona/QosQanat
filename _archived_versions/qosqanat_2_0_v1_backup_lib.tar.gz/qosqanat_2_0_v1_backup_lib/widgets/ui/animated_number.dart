import 'package:flutter/material.dart';

/// A number that smoothly counts up/down to its new value whenever [value]
/// changes. Used for HUD currencies (coins, akyl, level).
class AnimatedNumber extends StatelessWidget {
  final int value;
  final TextStyle? style;

  /// When true, thousands are grouped with a comma (e.g. `1,250`).
  final bool grouped;
  final Duration duration;

  const AnimatedNumber({
    super.key,
    required this.value,
    this.style,
    this.grouped = false,
    this.duration = const Duration(milliseconds: 600),
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<int>(
      // `begin` seeds the first frame (count up from 0); on later rebuilds
      // TweenAnimationBuilder animates from the current value to the new end.
      tween: IntTween(begin: 0, end: value),
      duration: duration,
      curve: Curves.easeOut,
      builder: (context, v, _) => Text(_format(v), style: style),
    );
  }

  String _format(int v) {
    if (!grouped) return '$v';
    final s = v.abs().toString();
    final buf = StringBuffer(v < 0 ? '-' : '');
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write(',');
      buf.write(s[i]);
    }
    return buf.toString();
  }
}
