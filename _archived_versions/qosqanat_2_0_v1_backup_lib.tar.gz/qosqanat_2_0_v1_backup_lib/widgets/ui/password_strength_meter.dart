import 'package:flutter/material.dart';

import '../../core/constants/auth_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../core/utils/password_strength.dart';

/// Live password strength meter: a colored fill bar (Coral → Sunset → Jade),
/// a strength label, and a checklist of satisfied requirements.
class PasswordStrengthMeter extends StatelessWidget {
  final PasswordReport report;

  const PasswordStrengthMeter({super.key, required this.report});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(999),
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: report.fillRatio),
                  duration: const Duration(milliseconds: 250),
                  builder: (context, value, _) => LinearProgressIndicator(
                    value: value,
                    minHeight: 8,
                    backgroundColor: AppColors.surfaceMuted,
                    valueColor: AlwaysStoppedAnimation(report.color),
                  ),
                ),
              ),
            ),
            AppSpacing.gapH12,
            Text(
              report.label,
              style: AppTypography.caption.copyWith(color: report.color),
            ),
          ],
        ),
        AppSpacing.gapV12,
        Wrap(
          spacing: AppSpacing.md,
          runSpacing: AppSpacing.xs,
          children: [
            _Req(label: AuthStrings.reqMinLength, ok: report.hasMinLength),
            _Req(label: AuthStrings.reqLetters, ok: report.hasLetters),
            _Req(label: AuthStrings.reqDigits, ok: report.hasDigits),
            _Req(label: AuthStrings.reqSpecial, ok: report.hasSpecial),
          ],
        ),
      ],
    );
  }
}

class _Req extends StatelessWidget {
  final String label;
  final bool ok;

  const _Req({required this.label, required this.ok});

  @override
  Widget build(BuildContext context) {
    final color = ok ? AppColors.jade : AppColors.textTertiary;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          ok ? Icons.check_circle_rounded : Icons.circle_outlined,
          size: 16,
          color: color,
        ),
        AppSpacing.gapH4,
        Text(label, style: AppTypography.caption.copyWith(color: color)),
      ],
    );
  }
}
