import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';

/// A single inner shadow descriptor for [_InnerShadowPainter].
class _Inset {
  final Color color;
  final Offset offset;
  final double blur;
  const _Inset(this.color, this.offset, this.blur);
}

/// Paints one or more *inner* shadows clipped to a rounded rectangle. Flutter's
/// [BoxDecoration] only supports outer shadows, so claymorphism's inset
/// highlight (top-left, white) and inset shadow (bottom-right, dark) are drawn
/// here. Runs behind the child, on top of the container's gradient surface.
class _InnerShadowPainter extends CustomPainter {
  final double radius;
  final List<_Inset> insets;
  const _InnerShadowPainter(this.radius, this.insets);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius));
    canvas.save();
    canvas.clipRRect(rrect);
    for (final inset in insets) {
      final paint = Paint()
        ..color = inset.color
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, inset.blur);
      // Inverse fill: everything outside the shifted rounded rect, so only the
      // blurred edge bleeds inward — i.e. an inner shadow.
      final outer = Path()..addRect(rect.inflate(inset.blur * 3));
      final inner = Path()
        ..addRRect(rrect.shift(inset.offset).deflate(0));
      final diff = Path.combine(PathOperation.difference, outer, inner);
      canvas.drawPath(diff, paint);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(_InnerShadowPainter old) =>
      old.radius != radius || old.insets != insets;
}

/// Claymorphism surface — the signature "soft 3D" card of QosQanat 2.0.
///
/// Two flavours:
/// * **Neutral** (default): pale surface that reads as embossed plastic. Adapts
///   to light/dark automatically.
/// * **Colored** ([gradient] + [glow]): vivid pill/node/button with a coloured
///   drop glow and glossy inset highlight.
///
/// Set [pressed] to render the depressed (inset) state for tactile feedback.
class ClayContainer extends StatelessWidget {
  final Widget? child;
  final EdgeInsetsGeometry? padding;
  final double? width;
  final double? height;
  final BorderRadiusGeometry borderRadius;
  final double radius;

  /// Colored-clay fill. When null, a neutral surface is used.
  final Gradient? gradient;

  /// Coloured drop-glow for colored clay (the `--sh` token in the design).
  final Color? glow;

  /// Override the neutral surface base (rarely needed).
  final Color? baseColor;

  final bool pressed;
  final bool clip;
  final AlignmentGeometry? alignment;

  const ClayContainer({
    super.key,
    this.child,
    this.padding,
    this.width,
    this.height,
    double? radius,
    this.gradient,
    this.glow,
    this.baseColor,
    this.pressed = false,
    this.clip = false,
    this.alignment,
  })  : radius = radius ?? AppRadius.lg,
        borderRadius =
            const BorderRadius.all(Radius.circular(AppRadius.lg));

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final br = BorderRadius.circular(radius);

    final Gradient surface = gradient ??
        (dark
            ? const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppColors.nightSurface, AppColors.nightSurfaceLow],
              )
            : const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Colors.white, Color(0xFFEEF1FB)],
              ));

    final List<BoxShadow> outer;
    final List<_Inset> insets;

    if (pressed) {
      outer = const [];
      insets = const [
        _Inset(Color(0x38000000), Offset(4, 4), 9),
        _Inset(Color(0x66FFFFFF), Offset(-3, -3), 8),
      ];
    } else if (gradient != null) {
      outer = [
        BoxShadow(
          color: glow ?? AppColors.shadowMedium,
          offset: const Offset(6, 8),
          blurRadius: 18,
        ),
      ];
      insets = const [
        _Inset(Color(0x8CFFFFFF), Offset(2, 2), 6),
        _Inset(Color(0x2E000000), Offset(-5, -6), 12),
      ];
    } else if (dark) {
      outer = const [
        BoxShadow(color: Color(0x80000000), offset: Offset(7, 7), blurRadius: 18),
        BoxShadow(color: Color(0x1F5A5AA0), offset: Offset(-4, -4), blurRadius: 12),
      ];
      insets = const [
        _Inset(Color(0x1FA0A0FF), Offset(2, 2), 5),
        _Inset(Color(0x66000000), Offset(-5, -5), 11),
      ];
    } else {
      outer = const [
        BoxShadow(color: Color(0x291A1A4E), offset: Offset(7, 7), blurRadius: 16),
        BoxShadow(color: Color(0xF2FFFFFF), offset: Offset(-5, -5), blurRadius: 14),
      ];
      insets = const [
        _Inset(Color(0xE6FFFFFF), Offset(2, 2), 5),
        _Inset(Color(0x121A1A4E), Offset(-5, -5), 11),
      ];
    }

    Widget content = CustomPaint(
      painter: _InnerShadowPainter(radius, insets),
      child: Padding(
        padding: padding ?? EdgeInsets.zero,
        child: child,
      ),
    );

    return Container(
      width: width,
      height: height,
      alignment: alignment,
      clipBehavior: clip ? Clip.antiAlias : Clip.none,
      decoration: BoxDecoration(
        gradient: surface,
        borderRadius: br,
        boxShadow: outer,
        color: baseColor,
      ),
      child: content,
    );
  }
}
