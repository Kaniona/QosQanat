import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';

/// A compact circular progress dial used on subject cards and grade tiles.
/// Draws a coloured sweep over a soft track, with optional centre content
/// (defaults to the rounded percentage).
class ProgressRing extends StatelessWidget {
  /// 0.0–1.0.
  final double value;
  final double size;
  final double stroke;
  final Color color;
  final Color? trackColor;

  /// Centre widget. When null, shows "NN%".
  final Widget? center;
  final Color? centerTextColor;

  const ProgressRing({
    super.key,
    required this.value,
    this.size = 54,
    this.stroke = 6,
    this.color = AppColors.eagleBlue,
    this.trackColor,
    this.center,
    this.centerTextColor,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _RingPainter(
          value: value.clamp(0, 1),
          stroke: stroke,
          color: color,
          trackColor: trackColor ?? color.withValues(alpha: 0.16),
        ),
        child: Center(
          child: center ??
              Text(
                '${(value.clamp(0, 1) * 100).round()}%',
                style: AppTypography.display(
                  size: size * 0.24,
                  weight: FontWeight.w800,
                  color: centerTextColor ?? AppColors.textPrimary,
                ),
              ),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final double value;
  final double stroke;
  final Color color;
  final Color trackColor;

  _RingPainter({
    required this.value,
    required this.stroke,
    required this.color,
    required this.trackColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = (size.width - stroke) / 2;
    final rect = Rect.fromCircle(center: center, radius: radius);

    final track = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..color = trackColor;
    canvas.drawCircle(center, radius, track);

    if (value <= 0) return;
    final arc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        startAngle: 0,
        endAngle: 2 * math.pi,
        colors: [color.withValues(alpha: 0.85), color],
        transform: const GradientRotation(-math.pi / 2),
      ).createShader(rect);
    canvas.drawArc(rect, -math.pi / 2, 2 * math.pi * value, false, arc);
  }

  @override
  bool shouldRepaint(_RingPainter old) =>
      old.value != value ||
      old.color != color ||
      old.stroke != stroke ||
      old.trackColor != trackColor;
}
