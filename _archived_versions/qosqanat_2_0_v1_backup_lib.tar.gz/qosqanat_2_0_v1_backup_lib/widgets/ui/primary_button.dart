import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_elevation.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import 'pressable.dart';

/// Primary call-to-action button with the Eagle gradient, an optional leading
/// icon, a disabled state, and an inline loading spinner.
///
/// Premium feel: a soft colored glow under the gradient plus the shared
/// [Pressable] spring + haptic on tap. The glow tint follows the gradient's
/// dominant color so gold / cosmic variants stay luminous too.
class PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool isLoading;
  final IconData? icon;
  final Gradient gradient;

  const PrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.isLoading = false,
    this.icon,
    this.gradient = AppColors.eagle,
  });

  /// Best-effort glow tint from the gradient's last (deepest) color.
  Color get _glowColor =>
      gradient.colors.isNotEmpty ? gradient.colors.last : AppColors.eagleBlue;

  @override
  Widget build(BuildContext context) {
    final isEnabled = onPressed != null && !isLoading;

    final surface = DecoratedBox(
      decoration: BoxDecoration(
        gradient: gradient,
        borderRadius: AppRadius.radiusMd,
        boxShadow: isEnabled ? AppElevation.glow(_glowColor) : null,
      ),
      child: SizedBox(
        height: 56,
        child: Center(
          child: isLoading
              ? const SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    valueColor: AlwaysStoppedAnimation(AppColors.textOnDark),
                  ),
                )
              : Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (icon != null) ...[
                      Icon(icon, color: AppColors.textOnDark, size: 22),
                      AppSpacing.gapH8,
                    ],
                    Text(label, style: AppTypography.button),
                  ],
                ),
        ),
      ),
    );

    return Opacity(
      opacity: isEnabled ? 1 : 0.5,
      child: Pressable(
        onTap: isEnabled ? onPressed : null,
        borderRadius: AppRadius.radiusMd,
        child: surface,
      ),
    );
  }
}

/// Secondary outlined button used beside [PrimaryButton].
class SecondaryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;

  const SecondaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onPressed,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 22, color: AppColors.eagleBlue),
            AppSpacing.gapH8,
          ],
          Text(label),
        ],
      ),
    );
  }
}
