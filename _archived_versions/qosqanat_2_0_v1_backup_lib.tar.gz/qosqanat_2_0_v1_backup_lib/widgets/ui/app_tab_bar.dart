import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_elevation.dart';
import '../../core/theme/app_typography.dart';

/// A single tab definition for [AppTabBar].
class AppTabItem {
  final IconData icon;
  final String label;
  final bool raised;
  final Key? spotlightKey;

  const AppTabItem({
    required this.icon,
    required this.label,
    this.raised = false,
    this.spotlightKey,
  });
}

/// Custom bottom navigation bar matching the QosQanat design: a white surface
/// with rounded top corners, a soft shadow, an ою-өрнек edge band along the
/// top, and five tabs. The middle "Оқу" tab is a raised gradient button that
/// floats above the bar. The active tab scales up and turns Steppe Gold.
///
/// Layout note: the raised button overflows above the bar using a [Stack] with
/// [Clip.none] (Scaffold does not clip a bottom bar's upward overflow), so no
/// `RenderFlex` overflow is possible.
class AppTabBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  final List<AppTabItem> items;

  const AppTabBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).padding.bottom;

    return Container(
      height: 64 + bottomInset,
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        boxShadow: [
          BoxShadow(
            color: Color(0x1A1A1A4E),
            blurRadius: 28,
            offset: Offset(0, -8),
          ),
          BoxShadow(
            color: Color(0x0F1A1A4E),
            blurRadius: 8,
            offset: Offset(0, -2),
          ),
        ],
      ),
      child: Column(
        children: [
          // ою-өрнек edge band hugging the top of the bar.
          SizedBox(
            height: 8,
            width: double.infinity,
            child: CustomPaint(
              painter: _TabEdgePainter(
                AppColors.steppeGold.withValues(alpha: 0.45),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(bottom: bottomInset),
              child: Row(
                children: [
                  for (var i = 0; i < items.length; i++)
                    Expanded(
                      child: _TabSlot(
                        item: items[i],
                        active: i == currentIndex,
                        onTap: () => onTap(i),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// One tab slot — delegates to the raised or flat variant and attaches an
/// optional spotlight key for the tutorial.
class _TabSlot extends StatelessWidget {
  final AppTabItem item;
  final bool active;
  final VoidCallback onTap;

  const _TabSlot({
    required this.item,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final slot = item.raised
        ? _RaisedTab(item: item, active: active, onTap: onTap)
        : _FlatTab(item: item, active: active, onTap: onTap);
    if (item.spotlightKey == null) return slot;
    return KeyedSubtree(key: item.spotlightKey, child: slot);
  }
}

class _FlatTab extends StatelessWidget {
  final AppTabItem item;
  final bool active;
  final VoidCallback onTap;

  const _FlatTab({
    required this.item,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = active ? AppColors.steppeGold : AppColors.textTertiary;
    return InkResponse(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      radius: 36,
      highlightColor: Colors.transparent,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedScale(
            scale: active ? 1.18 : 1,
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOutBack,
            child: Icon(item.icon, color: color, size: 26),
          ),
          const SizedBox(height: 3),
          Text(
            item.label,
            style: AppTypography.caption.copyWith(
              color: color,
              fontWeight: active ? FontWeight.w800 : FontWeight.w600,
              fontSize: 11,
            ),
          ),
          const SizedBox(height: 3),
          AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOut,
            height: 4,
            width: active ? 18 : 0,
            decoration: BoxDecoration(
              color: AppColors.steppeGold,
              borderRadius: BorderRadius.circular(999),
              boxShadow: active ? AppElevation.glow(AppColors.steppeGold, opacity: 0.5) : null,
            ),
          ),
        ],
      ),
    );
  }
}

/// The raised middle tab — a gradient circle floating above the bar with its
/// label pinned to the bottom. Built with a [Stack] so the circle can overflow
/// upward without affecting layout height.
class _RaisedTab extends StatelessWidget {
  final AppTabItem item;
  final bool active;
  final VoidCallback onTap;

  const _RaisedTab({
    required this.item,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        onTap();
      },
      behavior: HitTestBehavior.opaque,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.bottomCenter,
        children: [
          // Label pinned near the bottom of the bar.
          Positioned(
            bottom: 2,
            child: Text(
              item.label,
              style: AppTypography.caption.copyWith(
                color:
                    active ? AppColors.steppeGoldDark : AppColors.textSecondary,
                fontWeight: FontWeight.w800,
                fontSize: 11,
              ),
            ),
          ),
          // Gradient circle floating above the bar.
          Positioned(
            bottom: 20,
            child: AnimatedScale(
              scale: active ? 1.06 : 1,
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOutBack,
              child: Container(
                width: 56,
                height: 56,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  gradient: active ? AppColors.goldSoar : AppColors.eagle,
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.surface, width: 4),
                  boxShadow: AppElevation.glow(
                    active ? AppColors.steppeGold : AppColors.eagleBlue,
                  ),
                ),
                child: Icon(item.icon, color: AppColors.white, size: 28),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Paints a delicate ою-өрнек band along the top edge of the tab bar.
class _TabEdgePainter extends CustomPainter {
  final Color color;

  _TabEdgePainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..strokeJoin = StrokeJoin.round;

    final midY = size.height / 2;
    const unit = 24.0;
    final h = size.height * 0.4;
    for (double x = unit / 2; x < size.width; x += unit) {
      final path = Path()
        ..moveTo(x - 5, midY)
        ..lineTo(x, midY - h)
        ..lineTo(x + 5, midY)
        ..lineTo(x, midY + h)
        ..close();
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _TabEdgePainter oldDelegate) =>
      oldDelegate.color != color;
}
