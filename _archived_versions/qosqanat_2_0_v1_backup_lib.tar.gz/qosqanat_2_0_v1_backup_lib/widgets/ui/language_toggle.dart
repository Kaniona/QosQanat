import 'package:flutter/material.dart';

import '../../core/constants/auth_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';

/// Simple ҚАЗ | РУС language toggle. Kazakh is the active default; Russian is a
/// placeholder for a future localization pass.
class LanguageToggle extends StatelessWidget {
  final bool isKazakh;
  final ValueChanged<bool> onChanged;
  final bool onDark;

  const LanguageToggle({
    super.key,
    this.isKazakh = true,
    required this.onChanged,
    this.onDark = false,
  });

  @override
  Widget build(BuildContext context) {
    final baseColor = onDark ? AppColors.textOnDark : AppColors.textSecondary;
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: onDark
            ? AppColors.white.withValues(alpha: 0.15)
            : AppColors.surfaceMuted,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _segment(AuthStrings.langKaz, isKazakh, baseColor, () {
            if (!isKazakh) onChanged(true);
          }),
          _segment(AuthStrings.langRus, !isKazakh, baseColor, () {
            if (isKazakh) onChanged(false);
          }),
        ],
      ),
    );
  }

  Widget _segment(String label, bool active, Color baseColor, VoidCallback tap) {
    return GestureDetector(
      onTap: tap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: active ? AppColors.steppeGold : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(
          label,
          style: AppTypography.caption.copyWith(
            color: active ? AppColors.nightInk : baseColor,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }
}
