import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/theme/app_motion.dart';

/// Wraps any child with a spring scale-down + haptic on press.
///
/// This is the single source of tactile feedback across QosQanat — buttons,
/// cards, HUD pills, map nodes. Centralising it keeps the "feel" identical
/// everywhere and respects `prefers-reduced-motion` via [enableScale].
class Pressable extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;

  /// Scale applied while pressed. Defaults to [AppMotion.pressScale].
  final double pressedScale;

  /// Fire a light haptic on tap-down. Disable for high-frequency targets.
  final bool haptic;

  /// Corner radius for the InkWell splash (visual only).
  final BorderRadius borderRadius;

  const Pressable({
    super.key,
    required this.child,
    required this.onTap,
    this.onLongPress,
    double? pressedScale,
    this.haptic = true,
    this.borderRadius = BorderRadius.zero,
  }) : pressedScale = pressedScale ?? AppMotion.pressScale;

  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool _pressed = false;

  bool get _enabled => widget.onTap != null || widget.onLongPress != null;

  void _setPressed(bool value) {
    if (!_enabled || _pressed == value) return;
    setState(() => _pressed = value);
  }

  void _handleTap() {
    if (widget.haptic) HapticFeedback.lightImpact();
    widget.onTap?.call();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _setPressed(true),
      onTapUp: (_) => _setPressed(false),
      onTapCancel: () => _setPressed(false),
      onTap: _enabled ? _handleTap : null,
      onLongPress: widget.onLongPress == null
          ? null
          : () {
              if (widget.haptic) HapticFeedback.mediumImpact();
              widget.onLongPress!.call();
            },
      child: AnimatedScale(
        scale: _pressed ? widget.pressedScale : 1.0,
        duration: AppMotion.fast,
        curve: AppMotion.settle,
        child: widget.child,
      ),
    );
  }
}
