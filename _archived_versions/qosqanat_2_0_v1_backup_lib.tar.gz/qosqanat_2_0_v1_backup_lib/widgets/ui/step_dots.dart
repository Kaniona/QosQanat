import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// Horizontal step indicator: the active step is a stretched gold pill, others
/// are small dots. Used by the registration wizard.
class StepDots extends StatelessWidget {
  final int count;
  final int activeIndex;

  const StepDots({super.key, required this.count, required this.activeIndex});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(count, (i) {
        final isActive = i == activeIndex;
        final isDone = i < activeIndex;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: isActive ? 28 : 8,
          height: 8,
          decoration: BoxDecoration(
            color: isActive
                ? AppColors.steppeGold
                : isDone
                    ? AppColors.eagleBlue
                    : AppColors.border,
            borderRadius: BorderRadius.circular(999),
          ),
        );
      }),
    );
  }
}
