import 'dart:math';

import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// Cosmic Night gradient backdrop sprinkled with deterministic stars. Used by
/// the splash and assistant-selection screens.
class StarryBackground extends StatelessWidget {
  final Widget child;
  final int starCount;

  const StarryBackground({super.key, required this.child, this.starCount = 60});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(gradient: AppColors.cosmicNight),
      child: CustomPaint(
        painter: _StarsPainter(starCount),
        child: child,
      ),
    );
  }
}

class _StarsPainter extends CustomPainter {
  final int starCount;

  _StarsPainter(this.starCount);

  @override
  void paint(Canvas canvas, Size size) {
    final rng = Random(42); // fixed seed → stable star field
    final paint = Paint()..color = AppColors.white;
    for (var i = 0; i < starCount; i++) {
      final dx = rng.nextDouble() * size.width;
      final dy = rng.nextDouble() * size.height;
      final radius = rng.nextDouble() * 1.6 + 0.4;
      paint.color = AppColors.white.withValues(alpha: rng.nextDouble() * 0.7 + 0.2);
      canvas.drawCircle(Offset(dx, dy), radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _StarsPainter oldDelegate) => false;
}
