import 'dart:ui';

import 'package:flutter/material.dart';

import '../../core/theme/app_spacing.dart';

/// Glassmorphism 2.0 surface — frosted translucent panel with a blurred
/// backdrop, gradient fill, and a 1px light border. Used for sticky headers,
/// HUD strips, bottom sheets, and grade gates. Adapts to light/dark.
///
/// Place over a colourful backdrop (aurora, map gradient, photo) for the glass
/// effect to read; on a flat surface it falls back to a subtle tint.
class GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final double blur;

  /// Force a variant; defaults to the ambient [Theme] brightness.
  final Brightness? brightness;
  final double? width;
  final double? height;
  final AlignmentGeometry? alignment;

  const GlassPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(AppSpacing.md),
    this.radius = AppRadius.xl,
    this.blur = 22,
    this.brightness,
    this.width,
    this.height,
    this.alignment,
  });

  @override
  Widget build(BuildContext context) {
    final dark =
        (brightness ?? Theme.of(context).brightness) == Brightness.dark;
    final br = BorderRadius.circular(radius);

    final gradient = dark
        ? const LinearGradient(
            begin: Alignment(-0.6, -1),
            end: Alignment(0.6, 1),
            colors: [Color(0x6B3C3C78), Color(0x52141437)],
          )
        : const LinearGradient(
            begin: Alignment(-0.6, -1),
            end: Alignment(0.6, 1),
            colors: [Color(0xB8FFFFFF), Color(0x6BFFFFFF)],
          );

    return ClipRRect(
      borderRadius: br,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          width: width,
          height: height,
          alignment: alignment,
          padding: padding,
          decoration: BoxDecoration(
            gradient: gradient,
            borderRadius: br,
            border: Border.all(
              color: dark ? const Color(0x3896A0FF) : const Color(0xA6FFFFFF),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: dark ? const Color(0x8C000000) : const Color(0x471A1A4E),
                offset: const Offset(0, 10),
                blurRadius: 34,
                spreadRadius: -8,
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}
