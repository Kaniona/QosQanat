import 'dart:ui';

import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// A single blurred colour blob in an [AuroraBackground].
class AuroraBlob {
  final Color color;
  final double size;
  final Alignment alignment;
  final double opacity;
  const AuroraBlob({
    required this.color,
    required this.size,
    required this.alignment,
    this.opacity = 0.45,
  });
}

/// The dreamy backdrop behind hero/learning screens: a deep base with a few
/// heavily-blurred coloured blobs (Eagle blue, Cosmic purple, Steppe gold)
/// drifting at the corners. Mirrors the `.aurora` layer in the 2026 design.
class AuroraBackground extends StatelessWidget {
  final Widget child;

  /// Solid base painted behind the blobs.
  final Color? baseColor;

  /// Blobs to scatter. Defaults to the signature three-colour aurora.
  final List<AuroraBlob>? blobs;

  /// Use the lighter daytime palette (pale base) instead of cosmic night.
  final bool light;

  const AuroraBackground({
    super.key,
    required this.child,
    this.baseColor,
    this.blobs,
    this.light = false,
  });

  static const List<AuroraBlob> _darkDefault = [
    AuroraBlob(
        color: AppColors.eagleBlueLight,
        size: 320,
        alignment: Alignment(-0.8, -0.95),
        opacity: 0.45),
    AuroraBlob(
        color: AppColors.cosmicPurpleLight,
        size: 300,
        alignment: Alignment(1.1, -0.2),
        opacity: 0.40),
    AuroraBlob(
        color: AppColors.steppeGoldLight,
        size: 300,
        alignment: Alignment(-0.9, 1.05),
        opacity: 0.35),
  ];

  static const List<AuroraBlob> _lightDefault = [
    AuroraBlob(
        color: AppColors.eagleBlueLight,
        size: 300,
        alignment: Alignment(-0.85, -0.95),
        opacity: 0.32),
    AuroraBlob(
        color: AppColors.cosmicPurpleLight,
        size: 260,
        alignment: Alignment(1.1, -0.1),
        opacity: 0.28),
    AuroraBlob(
        color: AppColors.steppeGoldLight,
        size: 280,
        alignment: Alignment(-0.9, 1.05),
        opacity: 0.26),
  ];

  @override
  Widget build(BuildContext context) {
    final list = blobs ?? (light ? _lightDefault : _darkDefault);
    final base =
        baseColor ?? (light ? AppColors.background : AppColors.auroraBase);

    return Stack(
      children: [
        Positioned.fill(child: ColoredBox(color: base)),
        Positioned.fill(
          child: ImageFiltered(
            imageFilter: ImageFilter.blur(sigmaX: 55, sigmaY: 55),
            child: Stack(
              children: [
                for (final blob in list)
                  Align(
                    alignment: blob.alignment,
                    child: Container(
                      width: blob.size,
                      height: blob.size,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: blob.color.withValues(alpha: blob.opacity),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
        Positioned.fill(child: child),
      ],
    );
  }
}
