import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import 'clay_container.dart';
import 'pressable.dart';

/// Progress state of a learning-map node.
enum NodeStatus { completed, current, available, locked }

/// A circular claymorphism node on the ascent map. Colour and glyph follow the
/// node's [status]; the current node gets a pulsing aura. A small level badge
/// (e.g. "7.6") sits at the bottom-right.
class MapNode extends StatefulWidget {
  final NodeStatus status;

  /// Centre glyph — emoji or symbol (✓ 👑 💎 ⚡ 🔒).
  final String glyph;

  /// Level label shown in the corner badge (omit to hide).
  final String? badge;
  final double size;
  final VoidCallback? onTap;

  const MapNode({
    super.key,
    required this.status,
    required this.glyph,
    this.badge,
    this.size = 78,
    this.onTap,
  });

  @override
  State<MapNode> createState() => _MapNodeState();
}

class _MapNodeState extends State<MapNode>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2200),
  )..repeat();

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  ({Gradient gradient, Color glow}) _style(bool dark) {
    switch (widget.status) {
      case NodeStatus.completed:
        return (
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.jadeLight, AppColors.jadeDark],
          ),
          glow: AppColors.jadeDark.withValues(alpha: 0.5),
        );
      case NodeStatus.current:
        return (
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.steppeGoldLight, AppColors.steppeGold],
          ),
          glow: AppColors.steppeGold.withValues(alpha: 0.7),
        );
      case NodeStatus.available:
        return (
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.cosmicPurpleLight, AppColors.cosmicPurpleDark],
          ),
          glow: AppColors.cosmicPurpleDark.withValues(alpha: 0.5),
        );
      case NodeStatus.locked:
        return (
          gradient: dark
              ? const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF3A3A64), Color(0xFF26264A)],
                )
              : const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFFCFD0E6), Color(0xFFA9ABC9)],
                ),
          glow: Colors.black.withValues(alpha: 0.2),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final style = _style(dark);
    final isCurrent = widget.status == NodeStatus.current;
    final isLocked = widget.status == NodeStatus.locked;

    final node = ClayContainer(
      width: widget.size,
      height: widget.size,
      radius: widget.size / 2,
      gradient: style.gradient,
      glow: style.glow,
      alignment: Alignment.center,
      child: Text(
        widget.glyph,
        style: TextStyle(
          fontSize: widget.size * 0.38,
          color: isLocked && dark ? AppColors.darkTextTertiary : Colors.white,
        ),
      ),
    );

    final badge = widget.badge == null
        ? null
        : Positioned(
            bottom: -6,
            right: -4,
            child: Container(
              width: 26,
              height: 26,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: dark ? AppColors.nightSurface : Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: AppColors.nightInk.withValues(alpha: 0.25),
                    offset: const Offset(0, 3),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: Text(
                widget.badge!,
                style: AppTypography.display(
                  size: 11,
                  weight: FontWeight.w800,
                  color: dark ? Colors.white : AppColors.nightInk,
                ),
              ),
            ),
          );

    return Pressable(
      onTap: widget.onTap,
      child: SizedBox(
        width: widget.size + 16,
        height: widget.size + 16,
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.center,
          children: [
            if (isCurrent)
              AnimatedBuilder(
                animation: _pulse,
                builder: (context, _) {
                  final t = _pulse.value;
                  return Container(
                    width: widget.size * (1.0 + 0.34 * t),
                    height: widget.size * (1.0 + 0.34 * t),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          AppColors.steppeGold
                              .withValues(alpha: 0.55 * (1 - t)),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  );
                },
              ),
            Opacity(opacity: isLocked ? 0.88 : 1, child: node),
            ?badge,
          ],
        ),
      ),
    );
  }
}
