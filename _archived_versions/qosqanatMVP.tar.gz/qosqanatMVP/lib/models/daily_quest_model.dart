import 'package:cloud_firestore/cloud_firestore.dart';

// 🔹 QOSQANAT: daily quest cache under users/{uid}/daily_quests/{questId}
enum QuestType {
  loginStreak3,
  completeTasks7,
  playBattle1;

  static QuestType fromJson(Object? value) {
    return QuestType.values.firstWhere(
      (item) => item.name == value,
      orElse: () => QuestType.loginStreak3,
    );
  }
}

class DailyQuestModel {
  const DailyQuestModel({
    required this.id,
    required this.type,
    required this.title,
    required this.targetValue,
    required this.currentValue,
    required this.coinReward,
    required this.isClaimed,
    required this.resetAt,
  });

  final String id;
  final QuestType type;
  final String title;
  final int targetValue;
  final int currentValue;
  final int coinReward;
  final bool isClaimed;
  final DateTime resetAt;

  static DailyQuestModel fromFirestore(
    DocumentSnapshot<Map<String, dynamic>> snapshot,
    SnapshotOptions? options,
  ) {
    final data = snapshot.data() ?? <String, dynamic>{};
    return DailyQuestModel.fromJson({...data, 'id': snapshot.id});
  }

  static Map<String, Object?> toFirestore(
    DailyQuestModel quest,
    SetOptions? options,
  ) {
    return quest.toJson();
  }

  factory DailyQuestModel.fromJson(Map<String, dynamic> json) {
    return DailyQuestModel(
      id: (json['id'] ?? '').toString(),
      type: QuestType.fromJson(json['type']),
      title: (json['title'] ?? '').toString(),
      targetValue: _readInt(json['targetValue'], fallback: 1),
      currentValue: _readInt(json['currentValue']),
      coinReward: _readInt(json['coinReward']),
      isClaimed: json['isClaimed'] == true,
      resetAt: _readDate(json['resetAt']) ?? _nextLocalMidnight(),
    );
  }

  factory DailyQuestModel.seed(QuestType type) {
    return switch (type) {
      QuestType.loginStreak3 => DailyQuestModel(
          id: type.name,
          type: type,
          title: '3 күн қатарынан кіру',
          targetValue: 3,
          currentValue: 0,
          coinReward: 50,
          isClaimed: false,
          resetAt: _nextLocalMidnight(),
        ),
      QuestType.completeTasks7 => DailyQuestModel(
          id: type.name,
          type: type,
          title: '7 тапсырма орындау',
          targetValue: 7,
          currentValue: 0,
          coinReward: 100,
          isClaimed: false,
          resetAt: _nextLocalMidnight(),
        ),
      QuestType.playBattle1 => DailyQuestModel(
          id: type.name,
          type: type,
          title: '1 шайқас ойнау',
          targetValue: 1,
          currentValue: 0,
          coinReward: 30,
          isClaimed: false,
          resetAt: _nextLocalMidnight(),
        ),
    };
  }

  Map<String, dynamic> toJson() {
    return {
      'type': type.name,
      'title': title,
      'targetValue': targetValue,
      'currentValue': currentValue,
      'coinReward': coinReward,
      'isClaimed': isClaimed,
      'resetAt': Timestamp.fromDate(resetAt),
    };
  }

  double get progress {
    if (targetValue <= 0) return 1;
    return (currentValue / targetValue).clamp(0, 1).toDouble();
  }

  bool get canClaim => currentValue >= targetValue && !isClaimed;

  DailyQuestModel copyWith({
    int? currentValue,
    bool? isClaimed,
    DateTime? resetAt,
  }) {
    return DailyQuestModel(
      id: id,
      type: type,
      title: title,
      targetValue: targetValue,
      currentValue: currentValue ?? this.currentValue,
      coinReward: coinReward,
      isClaimed: isClaimed ?? this.isClaimed,
      resetAt: resetAt ?? this.resetAt,
    );
  }

  static int _readInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '') ?? fallback;
  }

  static DateTime? _readDate(Object? value) {
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }

  static DateTime _nextLocalMidnight() {
    final now = DateTime.now();
    return DateTime(now.year, now.month, now.day + 1);
  }
}
