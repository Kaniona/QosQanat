import 'package:cloud_firestore/cloud_firestore.dart';

// 🔹 QOSQANAT: questions/{id} model
enum SubjectType {
  math,
  english;

  static SubjectType fromJson(Object? value) {
    return SubjectType.values.firstWhere(
      (item) => item.name == value,
      orElse: () => SubjectType.math,
    );
  }
}

enum QuestionType {
  multipleChoice,
  trueFalse,
  fillBlank,
  mathInput;

  static QuestionType fromJson(Object? value) {
    return QuestionType.values.firstWhere(
      (item) => item.name == value,
      orElse: () => QuestionType.multipleChoice,
    );
  }
}

class QuestionModel {
  const QuestionModel({
    required this.id,
    required this.subject,
    required this.grade,
    required this.topic,
    required this.difficulty,
    required this.type,
    required this.questionText,
    required this.options,
    required this.correctAnswer,
    required this.explanation,
    required this.aqylReward,
    required this.expReward,
    required this.timeLimitSec,
  });

  final String id;
  final SubjectType subject;
  final int grade;
  final String topic;
  final int difficulty;
  final QuestionType type;
  final String questionText;
  final List<String> options;
  final String correctAnswer;
  final String explanation;
  final int aqylReward;
  final int expReward;
  final int timeLimitSec;

  static QuestionModel fromFirestore(
    DocumentSnapshot<Map<String, dynamic>> snapshot,
    SnapshotOptions? options,
  ) {
    final data = snapshot.data() ?? <String, dynamic>{};
    return QuestionModel.fromJson({...data, 'id': snapshot.id});
  }

  static Map<String, Object?> toFirestore(
    QuestionModel question,
    SetOptions? options,
  ) {
    return question.toJson();
  }

  factory QuestionModel.fromJson(Map<String, dynamic> json) {
    final question = QuestionModel(
      id: (json['id'] ?? '').toString(),
      subject: SubjectType.fromJson(json['subject']),
      grade: _readInt(json['grade'], fallback: 6),
      topic: (json['topic'] ?? '').toString(),
      difficulty: _readInt(json['difficulty'], fallback: 1),
      type: QuestionType.fromJson(json['type']),
      questionText: (json['questionText'] ?? '').toString(),
      options: _readStringList(json['options']),
      correctAnswer: (json['correctAnswer'] ?? '').toString(),
      explanation: (json['explanation'] ?? '').toString(),
      aqylReward: _readInt(json['aqylReward'], fallback: 1),
      expReward: _readInt(json['expReward'], fallback: 10),
      timeLimitSec: _readInt(json['timeLimitSec'], fallback: 30),
    );
    return question..assertValid();
  }

  Map<String, dynamic> toJson() {
    assertValid();
    return {
      'subject': subject.name,
      'grade': grade,
      'topic': topic,
      'difficulty': difficulty,
      'type': type.name,
      'questionText': questionText,
      'options': options,
      'correctAnswer': correctAnswer,
      'explanation': explanation,
      'aqylReward': aqylReward,
      'expReward': expReward,
      'timeLimitSec': timeLimitSec,
    };
  }

  bool isCorrect(String answer) {
    final submitted = _normalize(answer);
    final expected = _normalize(correctAnswer);
    if (type == QuestionType.mathInput) {
      final left = num.tryParse(submitted.replaceAll(',', '.'));
      final right = num.tryParse(expected.replaceAll(',', '.'));
      if (left != null && right != null) {
        return (left - right).abs() < 0.0001;
      }
    }
    return submitted == expected;
  }

  List<String> validate() {
    final errors = <String>[];
    if (id.isEmpty) errors.add('id is required');
    if (![6, 7, 8].contains(grade)) errors.add('grade must be 6, 7, or 8');
    if (topic.trim().isEmpty) errors.add('topic is required');
    if (difficulty < 1 || difficulty > 3) {
      errors.add('difficulty must be 1..3');
    }
    if (questionText.trim().isEmpty) errors.add('questionText is required');
    if (correctAnswer.trim().isEmpty) errors.add('correctAnswer is required');
    if (explanation.trim().isEmpty) errors.add('explanation is required');
    if (type == QuestionType.multipleChoice && options.length < 2) {
      errors.add('multipleChoice questions require at least 2 options');
    }
    if (aqylReward < 0 || expReward < 0 || timeLimitSec < 5) {
      errors.add('rewards and time limit must be positive');
    }
    return errors;
  }

  void assertValid() {
    final errors = validate();
    if (errors.isNotEmpty) {
      throw FormatException('Invalid QuestionModel: ${errors.join(', ')}');
    }
  }

  QuestionModel copyWith({
    String? id,
    SubjectType? subject,
    int? grade,
    String? topic,
    int? difficulty,
    QuestionType? type,
    String? questionText,
    List<String>? options,
    String? correctAnswer,
    String? explanation,
    int? aqylReward,
    int? expReward,
    int? timeLimitSec,
  }) {
    return QuestionModel(
      id: id ?? this.id,
      subject: subject ?? this.subject,
      grade: grade ?? this.grade,
      topic: topic ?? this.topic,
      difficulty: difficulty ?? this.difficulty,
      type: type ?? this.type,
      questionText: questionText ?? this.questionText,
      options: options ?? this.options,
      correctAnswer: correctAnswer ?? this.correctAnswer,
      explanation: explanation ?? this.explanation,
      aqylReward: aqylReward ?? this.aqylReward,
      expReward: expReward ?? this.expReward,
      timeLimitSec: timeLimitSec ?? this.timeLimitSec,
    )..assertValid();
  }

  static String _normalize(String value) {
    return value.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');
  }

  static int _readInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '') ?? fallback;
  }

  static List<String> _readStringList(Object? value) {
    if (value is Iterable) {
      return value.map((item) => item.toString()).toList(growable: false);
    }
    return const [];
  }
}
