import 'package:cloud_firestore/cloud_firestore.dart';

import 'user_model.dart';

// 🔹 QOSQANAT: anonymized ranking projection
class RankingModel {
  const RankingModel({
    required this.uid,
    required this.qqId,
    required this.displayName,
    required this.school,
    required this.city,
    required this.grade,
    required this.assistant,
    required this.aqyl,
    required this.level,
    required this.lastActive,
  });

  final String uid;
  final String qqId;
  final String displayName;
  final String school;
  final String city;
  final int grade;
  final AssistantType assistant;
  final int aqyl;
  final int level;
  final DateTime? lastActive;

  factory RankingModel.fromUser(UserModel user) {
    final firstName = user.fullName.trim().split(RegExp(r'\s+')).first;
    return RankingModel(
      uid: user.uid,
      qqId: user.qqId,
      displayName: firstName,
      school: user.school,
      city: user.city,
      grade: user.grade,
      assistant: user.assistant,
      aqyl: user.aqyl,
      level: user.level,
      lastActive: user.lastLogin,
    );
  }

  factory RankingModel.fromJson(Map<String, dynamic> json) {
    return RankingModel(
      uid: (json['uid'] ?? '').toString(),
      qqId: (json['qqId'] ?? '').toString(),
      displayName: (json['displayName'] ?? '').toString(),
      school: (json['school'] ?? '').toString(),
      city: (json['city'] ?? '').toString(),
      grade: _readInt(json['grade'], fallback: 6),
      assistant: AssistantType.fromJson(json['assistant']),
      aqyl: _readInt(json['aqyl']),
      level: _readInt(json['level'], fallback: 1),
      lastActive: _readDate(json['lastActive']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'uid': uid,
      'qqId': qqId,
      'displayName': displayName,
      'school': school,
      'city': city,
      'grade': grade,
      'assistant': assistant.name,
      'aqyl': aqyl,
      'level': level,
      'lastActive': lastActive == null ? null : Timestamp.fromDate(lastActive!),
    };
  }

  static int _readInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '') ?? fallback;
  }

  static DateTime? _readDate(Object? value) {
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }
}

