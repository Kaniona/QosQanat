import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';

// 🔹 QOSQANAT: users/{uid} model
enum AssistantType {
  bektur,
  nazym;

  static AssistantType fromJson(Object? value) {
    return AssistantType.values.firstWhere(
      (item) => item.name == value,
      orElse: () => AssistantType.bektur,
    );
  }
}

class UserModel {
  const UserModel({
    required this.uid,
    required this.qqId,
    required this.fullName,
    required this.phone,
    required this.city,
    required this.school,
    required this.grade,
    required this.assistant,
    required this.aqyl,
    required this.exp,
    required this.coin,
    required this.level,
    required this.loginStreak,
    required this.lastLogin,
    required this.completedLessons,
    required this.friendIds,
    required this.inventory,
    required this.activePet,
    required this.isPremium,
    required this.premiumExpires,
    required this.createdAt,
    required this.updatedAt,
  });

  final String uid;
  final String qqId;
  final String fullName;
  final String phone;
  final String city;
  final String school;
  final int grade;
  final AssistantType assistant;
  final int aqyl;
  final int exp;
  final int coin;
  final int level;
  final int loginStreak;
  final DateTime? lastLogin;
  final List<String> completedLessons;
  final List<String> friendIds;
  final Map<String, bool> inventory;
  final String? activePet;
  final bool isPremium;
  final DateTime? premiumExpires;
  final DateTime createdAt;
  final DateTime updatedAt;

  static final qqIdPattern = RegExp(r'^QQ-[A-Z0-9]{9}$');

  static UserModel fromFirestore(
    DocumentSnapshot<Map<String, dynamic>> snapshot,
    SnapshotOptions? options,
  ) {
    final data = snapshot.data() ?? <String, dynamic>{};
    return UserModel.fromJson({...data, 'uid': snapshot.id});
  }

  static Map<String, Object?> toFirestore(
    UserModel user,
    SetOptions? options,
  ) {
    return user.toJson();
  }

  factory UserModel.initial({
    required String uid,
    required String qqId,
    required String fullName,
    required String phone,
    required String city,
    required String school,
    required int grade,
    required AssistantType assistant,
    DateTime? now,
  }) {
    final created = now ?? DateTime.now();
    return UserModel(
      uid: uid,
      qqId: qqId,
      fullName: fullName.trim(),
      phone: phone.trim(),
      city: city.trim(),
      school: school.trim(),
      grade: grade,
      assistant: assistant,
      aqyl: 0,
      exp: 0,
      coin: 50,
      level: 1,
      loginStreak: 0,
      lastLogin: null,
      completedLessons: const [],
      friendIds: const [],
      inventory: const {},
      activePet: null,
      isPremium: false,
      premiumExpires: null,
      createdAt: created,
      updatedAt: created,
    )..assertValid();
  }

  factory UserModel.fromJson(Map<String, dynamic> json) {
    final user = UserModel(
      uid: (json['uid'] ?? '').toString(),
      qqId: (json['qqId'] ?? '').toString(),
      fullName: (json['fullName'] ?? '').toString(),
      phone: (json['phone'] ?? '').toString(),
      city: (json['city'] ?? '').toString(),
      school: (json['school'] ?? '').toString(),
      grade: _readInt(json['grade'], fallback: 6),
      assistant: AssistantType.fromJson(json['assistant']),
      aqyl: _readInt(json['aqyl']),
      exp: _readInt(json['exp']),
      coin: _readInt(json['coin']),
      level: _readInt(json['level'], fallback: 1),
      loginStreak: _readInt(json['loginStreak']),
      lastLogin: _readDate(json['lastLogin']),
      completedLessons: _readStringList(json['completedLessons']),
      friendIds: _readStringList(json['friendIds']),
      inventory: _readBoolMap(json['inventory']),
      activePet: json['activePet']?.toString(),
      isPremium: json['isPremium'] == true,
      premiumExpires: _readDate(json['premiumExpires']),
      createdAt: _readDate(json['createdAt']) ?? DateTime.now(),
      updatedAt: _readDate(json['updatedAt']) ?? DateTime.now(),
    );
    return user..assertValid();
  }

  Map<String, dynamic> toJson() {
    assertValid();
    return {
      'qqId': qqId,
      'fullName': fullName,
      'phone': phone,
      'city': city,
      'school': school,
      'grade': grade,
      'assistant': assistant.name,
      'aqyl': aqyl,
      'exp': exp,
      'coin': coin,
      'level': level,
      'loginStreak': loginStreak,
      'lastLogin': _writeDate(lastLogin),
      'completedLessons': completedLessons,
      'friendIds': friendIds,
      'inventory': inventory,
      'activePet': activePet,
      'isPremium': isPremium,
      'premiumExpires': _writeDate(premiumExpires),
      'createdAt': _writeDate(createdAt),
      'updatedAt': _writeDate(updatedAt),
    };
  }

  List<String> validate() {
    final errors = <String>[];
    if (uid.isEmpty) errors.add('uid is required');
    if (!qqIdPattern.hasMatch(qqId)) {
      errors.add('qqId must match QQ-XXXXXXXXX');
    }
    if (fullName.trim().length < 2) errors.add('fullName is too short');
    if (phone.trim().isEmpty) errors.add('phone is required');
    if (city.trim().isEmpty) errors.add('city is required');
    if (school.trim().isEmpty) errors.add('school is required');
    if (![6, 7, 8].contains(grade)) errors.add('grade must be 6, 7, or 8');
    if (aqyl < 0 || exp < 0 || coin < 0 || level < 1 || loginStreak < 0) {
      errors.add('stats cannot be negative');
    }
    return errors;
  }

  void assertValid() {
    final errors = validate();
    if (errors.isNotEmpty) {
      throw FormatException('Invalid UserModel: ${errors.join(', ')}');
    }
  }

  static String generateQqId({Random? random}) {
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final rng = random ?? Random.secure();
    final body = List.generate(
      9,
      (_) => alphabet[rng.nextInt(alphabet.length)],
    ).join();
    return 'QQ-$body';
  }

  static int levelForExp(int exp) => sqrt(exp / 100).floor() + 1;

  bool get isOnboarded => fullName.isNotEmpty && qqIdPattern.hasMatch(qqId);

  UserModel copyWith({
    String? uid,
    String? qqId,
    String? fullName,
    String? phone,
    String? city,
    String? school,
    int? grade,
    AssistantType? assistant,
    int? aqyl,
    int? exp,
    int? coin,
    int? level,
    int? loginStreak,
    Object? lastLogin = _unset,
    List<String>? completedLessons,
    List<String>? friendIds,
    Map<String, bool>? inventory,
    Object? activePet = _unset,
    bool? isPremium,
    Object? premiumExpires = _unset,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return UserModel(
      uid: uid ?? this.uid,
      qqId: qqId ?? this.qqId,
      fullName: fullName ?? this.fullName,
      phone: phone ?? this.phone,
      city: city ?? this.city,
      school: school ?? this.school,
      grade: grade ?? this.grade,
      assistant: assistant ?? this.assistant,
      aqyl: aqyl ?? this.aqyl,
      exp: exp ?? this.exp,
      coin: coin ?? this.coin,
      level: level ?? this.level,
      loginStreak: loginStreak ?? this.loginStreak,
      lastLogin:
          identical(lastLogin, _unset) ? this.lastLogin : lastLogin as DateTime?,
      completedLessons: completedLessons ?? this.completedLessons,
      friendIds: friendIds ?? this.friendIds,
      inventory: inventory ?? this.inventory,
      activePet:
          identical(activePet, _unset) ? this.activePet : activePet as String?,
      isPremium: isPremium ?? this.isPremium,
      premiumExpires: identical(premiumExpires, _unset)
          ? this.premiumExpires
          : premiumExpires as DateTime?,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    )..assertValid();
  }

  static int _readInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '') ?? fallback;
  }

  static DateTime? _readDate(Object? value) {
    if (value == null) return null;
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }

  static Object? _writeDate(DateTime? value) {
    return value == null ? null : Timestamp.fromDate(value);
  }

  static List<String> _readStringList(Object? value) {
    if (value is Iterable) {
      return value.map((item) => item.toString()).toList(growable: false);
    }
    return const [];
  }

  static Map<String, bool> _readBoolMap(Object? value) {
    if (value is Map) {
      return value.map(
        (key, item) => MapEntry(key.toString(), item == true),
      );
    }
    return const {};
  }
}

const _unset = Object();
