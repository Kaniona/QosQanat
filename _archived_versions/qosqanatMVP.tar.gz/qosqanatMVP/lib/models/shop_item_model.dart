import 'package:cloud_firestore/cloud_firestore.dart';

import 'user_model.dart';

// 🔹 QOSQANAT: shop_items/{id} model
enum ShopCategory {
  outfit,
  accessory,
  pet;

  static ShopCategory fromJson(Object? value) {
    return ShopCategory.values.firstWhere(
      (item) => item.name == value,
      orElse: () => ShopCategory.outfit,
    );
  }
}

class ShopItemModel {
  const ShopItemModel({
    required this.id,
    required this.category,
    required this.name,
    required this.description,
    required this.price,
    required this.compatibleWith,
    required this.assetPath,
    required this.isAvailable,
  });

  final String id;
  final ShopCategory category;
  final String name;
  final String description;
  final int price;
  final List<AssistantType> compatibleWith;
  final String assetPath;
  final bool isAvailable;

  static ShopItemModel fromFirestore(
    DocumentSnapshot<Map<String, dynamic>> snapshot,
    SnapshotOptions? options,
  ) {
    final data = snapshot.data() ?? <String, dynamic>{};
    return ShopItemModel.fromJson({...data, 'id': snapshot.id});
  }

  static Map<String, Object?> toFirestore(
    ShopItemModel item,
    SetOptions? options,
  ) {
    return item.toJson();
  }

  factory ShopItemModel.fromJson(Map<String, dynamic> json) {
    final item = ShopItemModel(
      id: (json['id'] ?? '').toString(),
      category: ShopCategory.fromJson(json['category']),
      name: (json['name'] ?? '').toString(),
      description: (json['description'] ?? '').toString(),
      price: _readInt(json['price']),
      compatibleWith: _readStringList(json['compatibleWith'])
          .map(AssistantType.fromJson)
          .toList(growable: false),
      assetPath: (json['assetPath'] ?? '').toString(),
      isAvailable: json['isAvailable'] != false,
    );
    return item..assertValid();
  }

  Map<String, dynamic> toJson() {
    assertValid();
    return {
      'category': category.name,
      'name': name,
      'description': description,
      'price': price,
      'compatibleWith': compatibleWith.map((item) => item.name).toList(),
      'assetPath': assetPath,
      'isAvailable': isAvailable,
    };
  }

  bool supports(AssistantType assistant) {
    return compatibleWith.isEmpty || compatibleWith.contains(assistant);
  }

  List<String> validate() {
    final errors = <String>[];
    if (id.isEmpty) errors.add('id is required');
    if (name.trim().isEmpty) errors.add('name is required');
    if (description.trim().isEmpty) errors.add('description is required');
    if (price < 0) errors.add('price cannot be negative');
    if (assetPath.trim().isEmpty) errors.add('assetPath is required');
    return errors;
  }

  void assertValid() {
    final errors = validate();
    if (errors.isNotEmpty) {
      throw FormatException('Invalid ShopItemModel: ${errors.join(', ')}');
    }
  }

  static int _readInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '') ?? fallback;
  }

  static List<String> _readStringList(Object? value) {
    if (value is Iterable) {
      return value.map((item) => item.toString()).toList(growable: false);
    }
    return const [];
  }
}
