import 'package:cloud_firestore/cloud_firestore.dart';

import 'question_model.dart';

// 🔹 QOSQANAT: battles/{id} model
enum BattleStatus {
  pending,
  accepted,
  in_progress,
  completed,
  declined;

  static BattleStatus fromJson(Object? value) {
    return BattleStatus.values.firstWhere(
      (item) => item.name == value,
      orElse: () => BattleStatus.pending,
    );
  }
}

class BattleAnswer {
  const BattleAnswer({
    required this.questionId,
    required this.answer,
    required this.durationMs,
    required this.answeredAt,
    this.isCorrect,
  });

  final String questionId;
  final String answer;
  final int durationMs;
  final DateTime answeredAt;
  final bool? isCorrect;

  factory BattleAnswer.fromJson(Map<String, dynamic> json) {
    return BattleAnswer(
      questionId: (json['questionId'] ?? '').toString(),
      answer: (json['answer'] ?? '').toString(),
      durationMs: _readInt(json['durationMs']),
      answeredAt: _readDate(json['answeredAt']) ?? DateTime.now(),
      isCorrect: json['isCorrect'] is bool ? json['isCorrect'] as bool : null,
    );
  }

  Map<String, dynamic> toJson({bool includeServerOnly = true}) {
    return {
      'questionId': questionId,
      'answer': answer,
      'durationMs': durationMs,
      'answeredAt': Timestamp.fromDate(answeredAt),
      if (includeServerOnly && isCorrect != null) 'isCorrect': isCorrect,
    };
  }

  static int _readInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '') ?? fallback;
  }

  static DateTime? _readDate(Object? value) {
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }
}

class BattleModel {
  const BattleModel({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.subject,
    required this.questionCount,
    required this.status,
    required this.questions,
    required this.senderAnswers,
    required this.receiverAnswers,
    required this.startedAt,
    required this.completedAt,
    required this.winnerId,
    required this.senderScore,
    required this.receiverScore,
    required this.senderTotalTimeMs,
    required this.receiverTotalTimeMs,
  });

  final String id;
  final String senderId;
  final String receiverId;
  final SubjectType subject;
  final int questionCount;
  final BattleStatus status;
  final List<String> questions;
  final Map<String, BattleAnswer> senderAnswers;
  final Map<String, BattleAnswer> receiverAnswers;
  final DateTime? startedAt;
  final DateTime? completedAt;
  final String? winnerId;
  final int senderScore;
  final int receiverScore;
  final int senderTotalTimeMs;
  final int receiverTotalTimeMs;

  static const allowedQuestionCounts = [15, 20, 25, 40, 50];

  static BattleModel fromFirestore(
    DocumentSnapshot<Map<String, dynamic>> snapshot,
    SnapshotOptions? options,
  ) {
    final data = snapshot.data() ?? <String, dynamic>{};
    return BattleModel.fromJson({...data, 'id': snapshot.id});
  }

  static Map<String, Object?> toFirestore(
    BattleModel battle,
    SetOptions? options,
  ) {
    return battle.toJson();
  }

  factory BattleModel.create({
    required String id,
    required String senderId,
    required String receiverId,
    required SubjectType subject,
    required int questionCount,
    required List<String> questions,
  }) {
    return BattleModel(
      id: id,
      senderId: senderId,
      receiverId: receiverId,
      subject: subject,
      questionCount: questionCount,
      status: BattleStatus.pending,
      questions: questions,
      senderAnswers: const {},
      receiverAnswers: const {},
      startedAt: null,
      completedAt: null,
      winnerId: null,
      senderScore: 0,
      receiverScore: 0,
      senderTotalTimeMs: 0,
      receiverTotalTimeMs: 0,
    )..assertValid();
  }

  factory BattleModel.fromJson(Map<String, dynamic> json) {
    final battle = BattleModel(
      id: (json['id'] ?? '').toString(),
      senderId: (json['senderId'] ?? '').toString(),
      receiverId: (json['receiverId'] ?? '').toString(),
      subject: SubjectType.fromJson(json['subject']),
      questionCount: _readInt(json['questionCount'], fallback: 15),
      status: BattleStatus.fromJson(json['status']),
      questions: _readStringList(json['questions']),
      senderAnswers: _readAnswers(json['senderAnswers']),
      receiverAnswers: _readAnswers(json['receiverAnswers']),
      startedAt: _readDate(json['startedAt']),
      completedAt: _readDate(json['completedAt']),
      winnerId: json['winnerId']?.toString(),
      senderScore: _readInt(json['senderScore']),
      receiverScore: _readInt(json['receiverScore']),
      senderTotalTimeMs: _readInt(json['senderTotalTimeMs']),
      receiverTotalTimeMs: _readInt(json['receiverTotalTimeMs']),
    );
    return battle..assertValid();
  }

  Map<String, dynamic> toJson() {
    assertValid();
    return {
      'senderId': senderId,
      'receiverId': receiverId,
      'subject': subject.name,
      'questionCount': questionCount,
      'status': status.name,
      'questions': questions,
      'senderAnswers': senderAnswers.map(
        (key, value) => MapEntry(key, value.toJson()),
      ),
      'receiverAnswers': receiverAnswers.map(
        (key, value) => MapEntry(key, value.toJson()),
      ),
      'startedAt': _writeDate(startedAt),
      'completedAt': _writeDate(completedAt),
      'winnerId': winnerId,
      'senderScore': senderScore,
      'receiverScore': receiverScore,
      'senderTotalTimeMs': senderTotalTimeMs,
      'receiverTotalTimeMs': receiverTotalTimeMs,
    };
  }

  bool isParticipant(String uid) => senderId == uid || receiverId == uid;

  Map<String, BattleAnswer> answersFor(String uid) {
    return uid == senderId ? senderAnswers : receiverAnswers;
  }

  int scoreFor(String uid) => uid == senderId ? senderScore : receiverScore;

  int totalTimeFor(String uid) {
    return uid == senderId ? senderTotalTimeMs : receiverTotalTimeMs;
  }

  List<String> validate() {
    final errors = <String>[];
    if (id.isEmpty) errors.add('id is required');
    if (senderId.isEmpty) errors.add('senderId is required');
    if (receiverId.isEmpty) errors.add('receiverId is required');
    if (senderId == receiverId) errors.add('sender and receiver differ');
    if (!allowedQuestionCounts.contains(questionCount)) {
      errors.add('questionCount must be 15, 20, 25, 40, or 50');
    }
    if (questions.length > questionCount) {
      errors.add('questions cannot exceed questionCount');
    }
    return errors;
  }

  void assertValid() {
    final errors = validate();
    if (errors.isNotEmpty) {
      throw FormatException('Invalid BattleModel: ${errors.join(', ')}');
    }
  }

  BattleModel copyWith({
    String? id,
    String? senderId,
    String? receiverId,
    SubjectType? subject,
    int? questionCount,
    BattleStatus? status,
    List<String>? questions,
    Map<String, BattleAnswer>? senderAnswers,
    Map<String, BattleAnswer>? receiverAnswers,
    Object? startedAt = _unset,
    Object? completedAt = _unset,
    Object? winnerId = _unset,
    int? senderScore,
    int? receiverScore,
    int? senderTotalTimeMs,
    int? receiverTotalTimeMs,
  }) {
    return BattleModel(
      id: id ?? this.id,
      senderId: senderId ?? this.senderId,
      receiverId: receiverId ?? this.receiverId,
      subject: subject ?? this.subject,
      questionCount: questionCount ?? this.questionCount,
      status: status ?? this.status,
      questions: questions ?? this.questions,
      senderAnswers: senderAnswers ?? this.senderAnswers,
      receiverAnswers: receiverAnswers ?? this.receiverAnswers,
      startedAt:
          identical(startedAt, _unset) ? this.startedAt : startedAt as DateTime?,
      completedAt: identical(completedAt, _unset)
          ? this.completedAt
          : completedAt as DateTime?,
      winnerId:
          identical(winnerId, _unset) ? this.winnerId : winnerId as String?,
      senderScore: senderScore ?? this.senderScore,
      receiverScore: receiverScore ?? this.receiverScore,
      senderTotalTimeMs: senderTotalTimeMs ?? this.senderTotalTimeMs,
      receiverTotalTimeMs: receiverTotalTimeMs ?? this.receiverTotalTimeMs,
    )..assertValid();
  }

  static Map<String, BattleAnswer> _readAnswers(Object? value) {
    if (value is Map) {
      return value.map((key, item) {
        final answer = item is Map<String, dynamic>
            ? BattleAnswer.fromJson(item)
            : BattleAnswer.fromJson(Map<String, dynamic>.from(item as Map));
        return MapEntry(key.toString(), answer);
      });
    }
    return const {};
  }

  static int _readInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '') ?? fallback;
  }

  static List<String> _readStringList(Object? value) {
    if (value is Iterable) {
      return value.map((item) => item.toString()).toList(growable: false);
    }
    return const [];
  }

  static DateTime? _readDate(Object? value) {
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }

  static Object? _writeDate(DateTime? value) {
    return value == null ? null : Timestamp.fromDate(value);
  }
}

const _unset = Object();
