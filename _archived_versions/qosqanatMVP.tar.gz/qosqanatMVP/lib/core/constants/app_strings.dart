import 'package:flutter/material.dart';

// 🔹 QOSQANAT: localization
class AppStrings {
  const AppStrings._();

  static const appName = 'QosQanat';
  static const tagline = 'Экран уақытын білімге айналдыр';
  static const primaryLocale = Locale('kk', 'KZ');
  static const fallbackLocale = Locale('ru', 'RU');

  static const navHome = 'Үй';
  static const navLearn = 'Оқу';
  static const navRanking = 'Рейтинг';
  static const navShop = 'Дүкен';
  static const navProfile = 'Профиль';

  static const phone = 'Телефон';
  static const phoneHint = '+7 700 000 00 00';
  static const sendCode = 'Код жіберу';
  static const smsCode = 'SMS коды';
  static const confirmCode = 'Кіру';
  static const fullName = 'Аты-жөнің';
  static const city = 'Қала';
  static const school = 'Мектеп';
  static const grade = 'Сынып';
  static const chooseAssistant = 'Көмекшіні таңда';
  static const bektur = 'Бектұр';
  static const nazym = 'Назым';
  static const startLearning = 'Оқуды бастау';
  static const onboardingIntro =
      'Алдымен аккаунтты растап, өз көмекшіңді таңда.';

  static const loading = 'Жүктелуде...';
  static const retry = 'Қайталау';
  static const save = 'Сақтау';
  static const cancel = 'Бас тарту';
  static const continueText = 'Жалғастыру';
  static const close = 'Жабу';
  static const errorGeneric = 'Қате шықты. Қайта байқап көр.';
  static const offlineBanner =
      'Интернет жоқ, бірақ оқуды жалғастыра аласыз!';
  static const emptyState = 'Әзірге дерек жоқ';
  static const success = 'Сәтті орындалды!';

  static const homeGreeting = 'Сәлем!';
  static const dailyLesson = 'Бүгінгі тапсырма';
  static const dailyQuests = 'Күндік квесттер';
  static const voiceHelp = 'Көмекші';
  static const voiceListening = 'Тыңдап тұрмын...';
  static const voiceStart = 'Дауыспен айту';
  static const commandHelp =
      'Айта алатын командалар: ютуб аш, ватсап аш, бүгінгі тапсырма, досымды қос, көмек.';

  static const subjectMath = 'Математика';
  static const subjectEnglish = 'Ағылшын';
  static const topicFractions = 'Бөлшектер';
  static const topicPercent = 'Пайыз';
  static const topicGeometry = 'Геометрия';
  static const topicVocabulary = 'Сөздік';
  static const topicGrammar = 'Грамматика';
  static const topicReading = 'Оқу';
  static const chooseSubject = 'Пәнді таңда';
  static const topic = 'Тақырып';
  static const level = 'Деңгей';
  static const locked = 'Құлыптаулы';
  static const unlocked = 'Ашық';
  static const completed = 'Аяқталды';
  static const lessonComplete = 'Деңгей аяқталды!';
  static const lessonFailed = '3/3 дұрыс жауап керек. Қайта байқап көр.';
  static const correct = 'Дұрыс!';
  static const wrong = 'Қате';
  static const trueLabel = 'Дұрыс';
  static const falseLabel = 'Қате';
  static const explanation = 'Түсіндіру';
  static const timeLeft = 'Уақыт';
  static const nextQuestion = 'Келесі сұрақ';
  static const checkAnswer = 'Тексеру';

  static const battle = 'Aqyl Battle';
  static const battleLobby = 'Достар шайқасы';
  static const chooseFriend = 'Дос таңда';
  static const friendUid = 'Дос UID';
  static const friendUidHint = 'Firebase UID';
  static const chooseQuestionCount = 'Сұрақ саны';
  static const sendChallenge = 'Шақыру жіберу';
  static const accept = 'Қабылдау';
  static const decline = 'Қабылдамау';
  static const pendingBattles = 'Күтіп тұрған шайқастар';
  static const battleHint = 'Досыңды шақырып, бірдей сұрақтарға жауап бер.';
  static const battleWaitingOpponent = 'Қарсылас жауабын күтеміз';
  static const battleAnswersSent = 'Жауаптар жіберілді';
  static const battleWaitingFinish = 'Қарсыластың аяқтауын күтеміз.';
  static const battleDeclined = 'Шақыру қабылданбады';
  static const battlePending = 'Күтіп тұр';
  static const opponentWon = 'Қарсылас жеңді';
  static const youWon = 'Сен жеңдің!';
  static const battleInProgress = 'Шайқас жүріп жатыр';
  static const battleCompleted = 'Шайқас аяқталды';
  static const winner = 'Жеңімпаз';
  static const draw = 'Тең ойын';
  static const accuracy = 'Дәлдік';
  static const totalTime = 'Уақыт';
  static const rankChange = 'Ранг өзгерісі';

  static const shop = 'Дүкен';
  static const outfits = 'Киімдер';
  static const accessories = 'Аксессуарлар';
  static const pets = 'Питомецтер';
  static const buy = 'Сатып алу';
  static const apply = 'Қолдану';
  static const refund = 'Қайтару';
  static const purchased = 'Сатып алынды';
  static const notEnoughCoins = 'Монета жеткіліксіз';

  static const profile = 'Профиль';
  static const qqId = 'QQ-ID';
  static const aqyl = 'Aqyl';
  static const exp = 'EXP';
  static const coin = 'Coin';
  static const loginStreak = 'Күндік серия';
  static const global = 'Жалпы';
  static const schoolTab = 'Мектеп';
  static const friends = 'Достар';
  static const badges = 'Белгілер';
  static const firstWin = 'Алғашқы жеңіс';
  static const tenCorrect = '10 дұрыс серия';
  static const sevenDayLogin = '7 күн кіру';
  static const signOut = 'Шығу';

  static const questLogin3 = '3 күн қатарынан кіру';
  static const questComplete7 = '7 тапсырма орындау';
  static const questBattle1 = '1 шайқас ойнау';

  static String subjectLabel(String value) => switch (value) {
        'math' => subjectMath,
        'english' => subjectEnglish,
        _ => value,
      };

  static String assistantLabel(String value) => switch (value) {
        'bektur' => bektur,
        'nazym' => nazym,
        _ => value,
      };
}
