import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/question_model.dart';
import '../models/user_model.dart';
import '../services/firestore_service.dart';
import '../services/local_cache_service.dart';
import 'user_provider.dart';

// 🔹 QOSQANAT: gameProvider
final localCacheProvider = Provider<LocalCacheService>((ref) {
  throw UnimplementedError('LocalCacheService must be overridden in main.dart');
});

enum LessonFeedback { idle, correct, wrong, completed, failed }

class GameState {
  const GameState({
    this.isLoading = false,
    this.isOffline = false,
    this.questions = const [],
    this.currentIndex = 0,
    this.correctCount = 0,
    this.attempts = 0,
    this.feedback = LessonFeedback.idle,
    this.error,
    this.lessonId,
  });

  final bool isLoading;
  final bool isOffline;
  final List<QuestionModel> questions;
  final int currentIndex;
  final int correctCount;
  final int attempts;
  final LessonFeedback feedback;
  final String? error;
  final String? lessonId;

  QuestionModel? get currentQuestion {
    if (currentIndex < 0 || currentIndex >= questions.length) return null;
    return questions[currentIndex];
  }

  bool get isFinished {
    return feedback == LessonFeedback.completed || feedback == LessonFeedback.failed;
  }

  GameState copyWith({
    bool? isLoading,
    bool? isOffline,
    List<QuestionModel>? questions,
    int? currentIndex,
    int? correctCount,
    int? attempts,
    LessonFeedback? feedback,
    Object? error = _unset,
    Object? lessonId = _unset,
  }) {
    return GameState(
      isLoading: isLoading ?? this.isLoading,
      isOffline: isOffline ?? this.isOffline,
      questions: questions ?? this.questions,
      currentIndex: currentIndex ?? this.currentIndex,
      correctCount: correctCount ?? this.correctCount,
      attempts: attempts ?? this.attempts,
      feedback: feedback ?? this.feedback,
      error: identical(error, _unset) ? this.error : error as String?,
      lessonId: identical(lessonId, _unset) ? this.lessonId : lessonId as String?,
    );
  }
}

class GameController extends StateNotifier<GameState> {
  GameController(this._ref) : super(const GameState());

  final Ref _ref;

  FirestoreService get _firestore => _ref.read(firestoreServiceProvider);
  LocalCacheService get _cache => _ref.read(localCacheProvider);

  Future<void> loadLesson({
    required SubjectType subject,
    required String topic,
    required int level,
  }) async {
    final user = _ref.read(userProvider).valueOrNull;
    if (user == null) return;
    final lessonId = buildLessonId(subject: subject, topic: topic, level: level);
    state = GameState(isLoading: true, lessonId: lessonId);
    try {
      final questions = await _firestore.fetchLessonQuestions(
        subject: subject,
        grade: user.grade,
        topic: topic,
        level: level,
      );
      await _cache.cacheLesson(
        subject: subject,
        grade: user.grade,
        topic: topic,
        level: level,
        questions: questions,
      );
      try {
        await _cacheNextLevels(user, subject, topic, level);
      } catch (_) {
        // The active lesson is already cached; prefetch failures should not block play.
      }
      state = state.copyWith(
        isLoading: false,
        questions: questions,
        lessonId: lessonId,
      );
    } catch (error) {
      final cached = await _cache.readLesson(
        subject: subject,
        grade: user.grade,
        topic: topic,
        level: level,
      );
      state = state.copyWith(
        isLoading: false,
        isOffline: cached.isNotEmpty,
        questions: cached,
        error: cached.isEmpty ? error.toString() : null,
      );
    }
  }

  Future<void> submitAnswer(String answer) async {
    final question = state.currentQuestion;
    final user = _ref.read(userProvider).valueOrNull;
    if (question == null || user == null || state.isFinished) return;

    if (question.isCorrect(answer)) {
      await _firestore.addLearningReward(user.uid, question);
      final nextCorrect = state.correctCount + 1;
      final completed = state.currentIndex == state.questions.length - 1;
      state = state.copyWith(
        correctCount: nextCorrect,
        attempts: 0,
        feedback: completed && nextCorrect == 3
            ? LessonFeedback.completed
            : LessonFeedback.correct,
      );
      if (completed && nextCorrect == 3 && state.lessonId != null) {
        await _firestore.completeLesson(uid: user.uid, lessonId: state.lessonId!);
      }
      return;
    }

    final nextAttempts = state.attempts + 1;
    state = state.copyWith(
      attempts: nextAttempts,
      feedback: nextAttempts >= 3 ? LessonFeedback.failed : LessonFeedback.wrong,
    );
  }

  void continueAfterFeedback() {
    if (state.feedback == LessonFeedback.correct &&
        state.currentIndex < state.questions.length - 1) {
      state = state.copyWith(
        currentIndex: state.currentIndex + 1,
        feedback: LessonFeedback.idle,
        attempts: 0,
      );
      return;
    }
    if (state.feedback == LessonFeedback.wrong) {
      state = state.copyWith(feedback: LessonFeedback.idle);
    }
  }

  Future<void> _cacheNextLevels(
    UserModel user,
    SubjectType subject,
    String topic,
    int level,
  ) async {
    for (final nextLevel in [level + 1, level + 2]) {
      final questions = await _firestore.fetchLessonQuestions(
        subject: subject,
        grade: user.grade,
        topic: topic,
        level: nextLevel,
      );
      await _cache.cacheLesson(
        subject: subject,
        grade: user.grade,
        topic: topic,
        level: nextLevel,
        questions: questions,
      );
    }
  }

  static String buildLessonId({
    required SubjectType subject,
    required String topic,
    required int level,
  }) {
    return '${subject.name}:$topic:$level';
  }
}

final gameProvider = StateNotifierProvider<GameController, GameState>((ref) {
  return GameController(ref);
});

const _unset = Object();
