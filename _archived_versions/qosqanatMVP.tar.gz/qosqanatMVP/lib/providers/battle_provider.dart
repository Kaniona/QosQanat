import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/battle_model.dart';
import '../models/question_model.dart';
import '../services/firestore_service.dart';
import 'user_provider.dart';

// 🔹 QOSQANAT: battleProvider
final myBattlesProvider = StreamProvider<List<BattleModel>>((ref) {
  final uid = ref.watch(currentUidProvider);
  if (uid == null) return Stream<List<BattleModel>>.value(const []);
  return ref.watch(firestoreServiceProvider).watchMyBattles(uid);
});

final battleProvider =
    StreamProvider.family<BattleModel?, String>((ref, battleId) {
  return ref.watch(firestoreServiceProvider).watchBattle(battleId);
});

final battleQuestionsProvider =
    FutureProvider.family<List<QuestionModel>, List<String>>((ref, ids) {
  return ref.watch(firestoreServiceProvider).fetchQuestionsByIds(ids);
});

class BattleController extends StateNotifier<AsyncValue<void>> {
  BattleController(this._ref) : super(const AsyncData(null));

  final Ref _ref;

  FirestoreService get _firestore => _ref.read(firestoreServiceProvider);

  Future<String?> createBattle({
    required String receiverId,
    required SubjectType subject,
    required int questionCount,
  }) async {
    final uid = _ref.read(currentUidProvider);
    if (uid == null) return null;
    state = const AsyncLoading();
    try {
      final id = await _firestore.createBattle(
        senderId: uid,
        receiverId: receiverId,
        subject: subject,
        questionCount: questionCount,
      );
      state = const AsyncData(null);
      return id;
    } catch (error, stackTrace) {
      state = AsyncError(error, stackTrace);
      return null;
    }
  }

  Future<void> accept(String battleId) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _firestore.acceptBattle(battleId));
  }

  Future<void> decline(String battleId) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _firestore.declineBattle(battleId));
  }

  Future<void> submitAnswer({
    required BattleModel battle,
    required String questionId,
    required String answer,
    required int durationMs,
  }) async {
    final uid = _ref.read(currentUidProvider);
    if (uid == null) return;
    await _firestore.submitBattleAnswer(
      battle: battle,
      uid: uid,
      questionId: questionId,
      answer: answer,
      durationMs: durationMs,
    );
  }

  Future<void> validate(String battleId) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _firestore.validateBattle(battleId));
  }
}

final battleControllerProvider =
    StateNotifierProvider<BattleController, AsyncValue<void>>((ref) {
  return BattleController(ref);
});

