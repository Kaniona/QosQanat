import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/shop_item_model.dart';
import '../services/firestore_service.dart';
import 'user_provider.dart';

// 🔹 QOSQANAT: shopProvider
final shopProvider = StreamProvider<List<ShopItemModel>>((ref) {
  return ref.watch(firestoreServiceProvider).watchShopItems();
});

class ShopController extends StateNotifier<AsyncValue<void>> {
  ShopController(this._ref) : super(const AsyncData(null));

  final Ref _ref;

  FirestoreService get _firestore => _ref.read(firestoreServiceProvider);

  Future<void> purchase(ShopItemModel item) async {
    final uid = _ref.read(currentUidProvider);
    if (uid == null) return;
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _firestore.purchaseItem(uid, item));
  }

  Future<void> apply(ShopItemModel item) async {
    final uid = _ref.read(currentUidProvider);
    if (uid == null) return;
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _firestore.applyItem(uid, item));
  }

  Future<void> refund(ShopItemModel item) async {
    final uid = _ref.read(currentUidProvider);
    if (uid == null) return;
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _firestore.refundItem(uid, item));
  }
}

final shopControllerProvider =
    StateNotifierProvider<ShopController, AsyncValue<void>>((ref) {
  return ShopController(ref);
});

