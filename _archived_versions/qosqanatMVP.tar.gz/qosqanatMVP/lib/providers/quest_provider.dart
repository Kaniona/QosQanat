import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/daily_quest_model.dart';
import '../services/firestore_service.dart';
import 'user_provider.dart';

// 🔹 QOSQANAT: questProvider
final questProvider = StreamProvider<List<DailyQuestModel>>((ref) {
  final uid = ref.watch(currentUidProvider);
  if (uid == null) return Stream<List<DailyQuestModel>>.value(const []);
  return ref.watch(firestoreServiceProvider).watchDailyQuests(uid);
});

class QuestController extends StateNotifier<AsyncValue<void>> {
  QuestController(this._ref) : super(const AsyncData(null));

  final Ref _ref;

  Future<void> claim(DailyQuestModel quest) async {
    final uid = _ref.read(currentUidProvider);
    if (uid == null) return;
    state = const AsyncLoading();
    state = await AsyncValue.guard(
      () => _ref.read(firestoreServiceProvider).claimQuest(uid, quest),
    );
  }
}

final questControllerProvider =
    StateNotifierProvider<QuestController, AsyncValue<void>>((ref) {
  return QuestController(ref);
});

