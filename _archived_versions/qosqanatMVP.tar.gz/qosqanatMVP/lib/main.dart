import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'core/constants/app_strings.dart';
import 'core/theme/app_theme.dart';
import 'models/question_model.dart';
import 'providers/game_provider.dart';
import 'providers/user_provider.dart';
import 'screens/battle/battle_game_screen.dart';
import 'screens/battle/battle_lobby_screen.dart';
import 'screens/home/home_screen.dart';
import 'screens/learning/lesson_screen.dart';
import 'screens/learning/map_screen.dart';
import 'screens/onboarding/assistant_select_screen.dart';
import 'screens/profile/profile_screen.dart';
import 'screens/shop/shop_screen.dart';
import 'services/local_cache_service.dart';

// 🔹 QOSQANAT: app bootstrap + router
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  FirebaseFirestore.instance.settings = const Settings(
    persistenceEnabled: true,
    cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
  );
  await FirebaseMessaging.instance.requestPermission();
  await FirebaseAnalytics.instance.logAppOpen();
  final cache = await LocalCacheService.init();
  runApp(
    ProviderScope(
      overrides: [localCacheProvider.overrideWithValue(cache)],
      child: const QosQanatApp(),
    ),
  );
}

class QosQanatApp extends ConsumerStatefulWidget {
  const QosQanatApp({super.key});

  @override
  ConsumerState<QosQanatApp> createState() => _QosQanatAppState();
}

class _QosQanatAppState extends ConsumerState<QosQanatApp> {
  StreamSubscription<RemoteMessage>? _pushSubscription;

  @override
  void initState() {
    super.initState();
    _pushSubscription = FirebaseMessaging.onMessageOpenedApp.listen(_openPush);
    FirebaseMessaging.instance.getInitialMessage().then(_openPush);
  }

  @override
  void dispose() {
    _pushSubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final router = ref.watch(routerProvider);
    return MaterialApp.router(
      title: AppStrings.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      locale: AppStrings.primaryLocale,
      supportedLocales: const [
        AppStrings.primaryLocale,
        AppStrings.fallbackLocale,
      ],
      routerConfig: router,
    );
  }

  void _openPush(RemoteMessage? message) {
    final battleId = message?.data['battleId']?.toString();
    if (battleId == null || battleId.isEmpty) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ref.read(routerProvider).goNamed('battle', pathParameters: {'id': battleId});
    });
  }
}

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);
  final userState = ref.watch(userProvider);
  return GoRouter(
    initialLocation: '/home',
    debugLogDiagnostics: true,
    refreshListenable: GoRouterRefreshStream(
      ref.watch(authProvider).authStateChanges(),
    ),
    redirect: (context, state) {
      final location = state.matchedLocation;
      final onOnboarding = location == '/onboarding';
      final authUser = authState.valueOrNull;
      if (authState.isLoading || userState.isLoading) return null;
      if (authUser == null) return onOnboarding ? null : '/onboarding';
      final profile = userState.valueOrNull;
      if (profile == null) return onOnboarding ? null : '/onboarding';
      if (onOnboarding) return '/home';
      return null;
    },
    routes: [
      GoRoute(
        path: '/onboarding',
        name: 'onboarding',
        builder: (context, state) => const AssistantSelectScreen(),
      ),
      ShellRoute(
        builder: (context, state, child) => QosQanatShell(child: child),
        routes: [
          GoRoute(
            path: '/home',
            name: 'home',
            builder: (context, state) => const HomeScreen(),
          ),
          GoRoute(
            path: '/learning',
            name: 'learning',
            builder: (context, state) => const MapScreen(),
          ),
          GoRoute(
            path: '/ranking',
            name: 'ranking',
            builder: (context, state) => const ProfileScreen(rankingOnly: true),
          ),
          GoRoute(
            path: '/shop',
            name: 'shop',
            builder: (context, state) => const ShopScreen(),
          ),
          GoRoute(
            path: '/profile',
            name: 'profile',
            builder: (context, state) => const ProfileScreen(),
          ),
        ],
      ),
      GoRoute(
        path: '/learning/:subject/:topic/:level',
        name: 'lesson',
        builder: (context, state) {
          final subject = SubjectType.values.firstWhere(
            (item) => item.name == state.pathParameters['subject'],
            orElse: () => SubjectType.math,
          );
          return LessonScreen(
            subject: subject,
            topic: Uri.decodeComponent(state.pathParameters['topic'] ?? ''),
            level: int.tryParse(state.pathParameters['level'] ?? '') ?? 1,
          );
        },
      ),
      GoRoute(
        path: '/battle',
        name: 'battleLobby',
        builder: (context, state) => const BattleLobbyScreen(),
      ),
      GoRoute(
        path: '/battle/:id',
        name: 'battle',
        builder: (context, state) {
          return BattleGameScreen(battleId: state.pathParameters['id'] ?? '');
        },
      ),
    ],
  );
});

class QosQanatShell extends StatelessWidget {
  const QosQanatShell({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final location = GoRouterState.of(context).matchedLocation;
    final index = _indexFor(location);
    return Scaffold(
      body: child,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: index,
        onTap: (value) => _go(context, value),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: AppStrings.navHome,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.map_outlined),
            activeIcon: Icon(Icons.map),
            label: AppStrings.navLearn,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.leaderboard_outlined),
            activeIcon: Icon(Icons.leaderboard),
            label: AppStrings.navRanking,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.storefront_outlined),
            activeIcon: Icon(Icons.storefront),
            label: AppStrings.navShop,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person),
            label: AppStrings.navProfile,
          ),
        ],
      ),
    );
  }

  int _indexFor(String location) {
    if (location.startsWith('/learning')) return 1;
    if (location.startsWith('/ranking')) return 2;
    if (location.startsWith('/shop')) return 3;
    if (location.startsWith('/profile')) return 4;
    return 0;
  }

  void _go(BuildContext context, int index) {
    final name = switch (index) {
      0 => 'home',
      1 => 'learning',
      2 => 'ranking',
      3 => 'shop',
      4 => 'profile',
      _ => 'home',
    };
    context.goNamed(name);
  }
}

class GoRouterRefreshStream extends ChangeNotifier {
  GoRouterRefreshStream(Stream<dynamic> stream) {
    notifyListeners();
    _subscription = stream.asBroadcastStream().listen((_) => notifyListeners());
  }

  late final StreamSubscription<dynamic> _subscription;

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }
}
