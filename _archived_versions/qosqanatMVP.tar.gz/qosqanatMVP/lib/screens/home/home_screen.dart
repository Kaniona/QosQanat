import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lottie/lottie.dart';

import '../../core/constants/app_strings.dart';
import '../../core/theme/app_theme.dart';
import '../../models/daily_quest_model.dart';
import '../../models/question_model.dart';
import '../../providers/quest_provider.dart';
import '../../providers/user_provider.dart';
import '../../services/voice_service.dart';

// 🔹 QOSQANAT: home dashboard + assistant commands
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final _voice = VoiceService();
  bool _listening = false;

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(userProvider).valueOrNull;
    final quests = ref.watch(questProvider);

    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.appName)),
      body: ListView(
        padding: const EdgeInsets.all(AppTheme.gap16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(AppTheme.gap16),
              child: Row(
                children: [
                  SizedBox(
                    width: 96,
                    height: 96,
                    child: Lottie.asset(
                      'assets/lottie/assistant_idle.json',
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.auto_awesome,
                        size: 64,
                        color: AppTheme.primary,
                      ),
                    ),
                  ),
                  const SizedBox(width: AppTheme.gap16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${AppStrings.homeGreeting} ${user?.fullName.split(' ').first ?? ''}',
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.w900,
                              ),
                        ),
                        const SizedBox(height: AppTheme.gap8),
                        Text(
                          '${AppStrings.level} ${user?.level ?? 1} · '
                          '${AppStrings.aqyl}: ${user?.aqyl ?? 0}',
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: AppTheme.gap16),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _openDailyLesson,
                  icon: const Icon(Icons.school),
                  label: const Text(AppStrings.dailyLesson),
                ),
              ),
              const SizedBox(width: AppTheme.gap8),
              IconButton.filledTonal(
                tooltip: AppStrings.voiceStart,
                onPressed: _listening ? null : _listen,
                icon: Icon(_listening ? Icons.mic : Icons.mic_none),
              ),
            ],
          ),
          const SizedBox(height: AppTheme.gap24),
          Text(
            AppStrings.dailyQuests,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
          ),
          const SizedBox(height: AppTheme.gap8),
          quests.when(
            data: (items) => items.isEmpty
                ? const Text(AppStrings.emptyState)
                : Column(
                    children: [
                      for (final quest in items)
                        Padding(
                          padding: const EdgeInsets.only(bottom: AppTheme.gap8),
                          child: _QuestTile(quest: quest),
                        ),
                    ],
                  ),
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, _) => Text(error.toString()),
          ),
          const SizedBox(height: AppTheme.gap24),
          Card(
            child: ListTile(
              leading: const Icon(Icons.sports_martial_arts, color: AppTheme.primary),
              title: const Text(AppStrings.battle),
              subtitle: const Text(AppStrings.battleHint),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => context.goNamed('battleLobby'),
            ),
          ),
        ],
      ),
    );
  }

  void _openDailyLesson() {
    context.goNamed(
      'lesson',
      pathParameters: {
        'subject': SubjectType.math.name,
        'topic': Uri.encodeComponent(AppStrings.topicFractions),
        'level': '1',
      },
    );
  }

  Future<void> _listen() async {
    setState(() => _listening = true);
    await _voice.speak(AppStrings.voiceListening);
    final command = await _voice.listenOnce();
    if (!mounted) return;
    setState(() => _listening = false);
    switch (command) {
      case VoiceCommand.openYoutube:
      case VoiceCommand.openWhatsapp:
        await _voice.executeExternal(command);
      case VoiceCommand.dailyLesson:
        _openDailyLesson();
      case VoiceCommand.addFriend:
        context.goNamed('battleLobby');
      case VoiceCommand.help:
        _showHelp();
      case VoiceCommand.unknown:
        _snack(AppStrings.commandHelp);
    }
  }

  void _showHelp() {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text(AppStrings.voiceHelp),
        content: const Text(AppStrings.commandHelp),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text(AppStrings.close),
          ),
        ],
      ),
    );
  }

  void _snack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class _QuestTile extends ConsumerWidget {
  const _QuestTile({required this.quest});

  final DailyQuestModel quest;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      child: ListTile(
        title: Text(quest.title),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: AppTheme.gap8),
          child: LinearProgressIndicator(
            value: quest.progress,
            minHeight: 8,
            borderRadius: BorderRadius.circular(99),
          ),
        ),
        trailing: quest.canClaim
            ? FilledButton.tonal(
                onPressed: () {
                  ref.read(questControllerProvider.notifier).claim(quest);
                },
                child: Text('+${quest.coinReward}'),
              )
            : Text('${quest.currentValue}/${quest.targetValue}'),
      ),
    );
  }
}

