import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_strings.dart';
import '../../core/theme/app_theme.dart';
import '../../models/battle_model.dart';
import '../../models/question_model.dart';
import '../../providers/battle_provider.dart';
import '../../providers/user_provider.dart';

// 🔹 QOSQANAT: real-time battle game
class BattleGameScreen extends ConsumerStatefulWidget {
  const BattleGameScreen({super.key, required this.battleId});

  final String battleId;

  @override
  ConsumerState<BattleGameScreen> createState() => _BattleGameScreenState();
}

class _BattleGameScreenState extends ConsumerState<BattleGameScreen> {
  final _answerController = TextEditingController();
  Timer? _timer;
  int _secondsLeft = 30;
  String? _questionId;
  bool _validationRequested = false;

  @override
  void dispose() {
    _timer?.cancel();
    _answerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final battleAsync = ref.watch(battleProvider(widget.battleId));
    final uid = ref.watch(currentUidProvider);

    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.battle)),
      body: battleAsync.when(
        data: (battle) {
          if (battle == null || uid == null) {
            return const Center(child: Text(AppStrings.emptyState));
          }
          if (battle.status == BattleStatus.pending) {
            return _WaitingView(
              title: AppStrings.battleWaitingOpponent,
              action: AppStrings.close,
              onPressed: () => context.goNamed('battleLobby'),
            );
          }
          if (battle.status == BattleStatus.declined) {
            return _WaitingView(
              title: AppStrings.battleDeclined,
              action: AppStrings.close,
              onPressed: () => context.goNamed('battleLobby'),
            );
          }
          if (battle.status == BattleStatus.completed) {
            _timer?.cancel();
            return _ResultView(battle: battle, uid: uid);
          }
          return ref.watch(battleQuestionsProvider(battle.questions)).when(
                data: (questions) => _BattleQuestionView(
                  battle: battle,
                  questions: questions,
                  uid: uid,
                  secondsLeft: _secondsLeft,
                  answerController: _answerController,
                  onQuestionVisible: _armTimer,
                  onSubmit: _submit,
                  maybeValidate: _maybeValidate,
                ),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (error, _) => _WaitingView(
                  title: AppStrings.errorGeneric,
                  message: error.toString(),
                  action: AppStrings.retry,
                  onPressed: () => ref.invalidate(
                    battleQuestionsProvider(battle.questions),
                  ),
                ),
              );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => _WaitingView(
          title: AppStrings.errorGeneric,
          message: error.toString(),
          action: AppStrings.close,
          onPressed: () => context.goNamed('battleLobby'),
        ),
      ),
    );
  }

  void _armTimer(QuestionModel question) {
    if (_questionId == question.id) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _timer?.cancel();
      setState(() {
        _questionId = question.id;
        _secondsLeft = 30;
      });
      _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (_secondsLeft <= 1) {
          timer.cancel();
          _submit('', question);
        } else if (mounted) {
          setState(() => _secondsLeft--);
        }
      });
    });
  }

  Future<void> _submit(String answer, QuestionModel question) async {
    final battle = ref.read(battleProvider(widget.battleId)).valueOrNull;
    if (battle == null) return;
    final uid = ref.read(currentUidProvider);
    if (uid == null || battle.answersFor(uid).containsKey(question.id)) return;
    _timer?.cancel();
    await HapticFeedback.selectionClick();
    await ref.read(battleControllerProvider.notifier).submitAnswer(
          battle: battle,
          questionId: question.id,
          answer: answer,
          durationMs: (30 - _secondsLeft).clamp(0, 30) * 1000,
        );
    _answerController.clear();
    setState(() => _questionId = null);
  }

  void _maybeValidate(BattleModel battle) {
    if (_validationRequested) return;
    if (battle.senderAnswers.length < battle.questionCount ||
        battle.receiverAnswers.length < battle.questionCount) {
      return;
    }
    _validationRequested = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(battleControllerProvider.notifier).validate(battle.id);
    });
  }
}

class _BattleQuestionView extends StatelessWidget {
  const _BattleQuestionView({
    required this.battle,
    required this.questions,
    required this.uid,
    required this.secondsLeft,
    required this.answerController,
    required this.onQuestionVisible,
    required this.onSubmit,
    required this.maybeValidate,
  });

  final BattleModel battle;
  final List<QuestionModel> questions;
  final String uid;
  final int secondsLeft;
  final TextEditingController answerController;
  final ValueChanged<QuestionModel> onQuestionVisible;
  final void Function(String answer, QuestionModel question) onSubmit;
  final ValueChanged<BattleModel> maybeValidate;

  @override
  Widget build(BuildContext context) {
    final answers = battle.answersFor(uid);
    final next = questions.where((question) => !answers.containsKey(question.id));

    if (next.isEmpty) {
      maybeValidate(battle);
      return _WaitingView(
        title: AppStrings.battleAnswersSent,
        message: AppStrings.battleWaitingFinish,
        action: AppStrings.close,
        onPressed: () => context.goNamed('battleLobby'),
      );
    }

    final question = next.first;
    onQuestionVisible(question);
    final answered = answers.length;

    return ListView(
      padding: const EdgeInsets.all(AppTheme.gap16),
      children: [
        Row(
          children: [
            Expanded(
              child: LinearProgressIndicator(
                value: answered / battle.questionCount,
                minHeight: 10,
                borderRadius: BorderRadius.circular(99),
              ),
            ),
            const SizedBox(width: AppTheme.gap16),
            Text(
              '$answered/${battle.questionCount}',
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
          ],
        ),
        const SizedBox(height: AppTheme.gap16),
        _BattleTimer(secondsLeft: secondsLeft),
        const SizedBox(height: AppTheme.gap24),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(AppTheme.gap24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  question.questionText,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
                const SizedBox(height: AppTheme.gap24),
                _BattleAnswerInput(
                  question: question,
                  controller: answerController,
                  onSubmit: onSubmit,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _BattleAnswerInput extends StatelessWidget {
  const _BattleAnswerInput({
    required this.question,
    required this.controller,
    required this.onSubmit,
  });

  final QuestionModel question;
  final TextEditingController controller;
  final void Function(String answer, QuestionModel question) onSubmit;

  @override
  Widget build(BuildContext context) {
    if (question.type == QuestionType.multipleChoice ||
        question.type == QuestionType.trueFalse) {
      final options = question.type == QuestionType.trueFalse
          ? const ['true', 'false']
          : question.options;
      return Column(
        children: [
          for (final option in options)
            Padding(
              padding: const EdgeInsets.only(bottom: AppTheme.gap8),
              child: OutlinedButton(
                onPressed: () => onSubmit(option, question),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    option == 'true'
                        ? AppStrings.trueLabel
                        : option == 'false'
                            ? AppStrings.falseLabel
                            : option,
                  ),
                ),
              ),
            ),
        ],
      );
    }

    return Column(
      children: [
        TextField(
          controller: controller,
          keyboardType: question.type == QuestionType.mathInput
              ? TextInputType.number
              : TextInputType.text,
          decoration: const InputDecoration(labelText: AppStrings.checkAnswer),
          onSubmitted: (value) => onSubmit(value, question),
        ),
        const SizedBox(height: AppTheme.gap16),
        FilledButton(
          onPressed: () => onSubmit(controller.text, question),
          child: const Text(AppStrings.checkAnswer),
        ),
      ],
    );
  }
}

class _BattleTimer extends StatelessWidget {
  const _BattleTimer({required this.secondsLeft});

  final int secondsLeft;

  @override
  Widget build(BuildContext context) {
    final danger = secondsLeft <= 8;
    return Align(
      alignment: Alignment.centerLeft,
      child: Chip(
        avatar: Icon(
          Icons.timer,
          color: danger ? AppTheme.error : AppTheme.primary,
        ),
        label: Text('${AppStrings.timeLeft}: $secondsLeft'),
        side: BorderSide.none,
        backgroundColor:
            (danger ? AppTheme.error : AppTheme.primary).withOpacity(0.1),
      ),
    );
  }
}

class _ResultView extends StatelessWidget {
  const _ResultView({required this.battle, required this.uid});

  final BattleModel battle;
  final String uid;

  @override
  Widget build(BuildContext context) {
    final myScore = battle.scoreFor(uid);
    final theirScore = uid == battle.senderId ? battle.receiverScore : battle.senderScore;
    final winnerText = battle.winnerId == null
        ? AppStrings.draw
        : battle.winnerId == uid
            ? AppStrings.youWon
            : AppStrings.opponentWon;
    final accuracy = battle.questionCount == 0
        ? 0
        : (myScore / battle.questionCount * 100).round();
    return ListView(
      padding: const EdgeInsets.all(AppTheme.gap24),
      children: [
        Icon(
          battle.winnerId == uid ? Icons.emoji_events : Icons.flag,
          color: battle.winnerId == uid ? Colors.amber.shade700 : AppTheme.primary,
          size: 84,
        ),
        const SizedBox(height: AppTheme.gap16),
        Text(
          winnerText,
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w900,
              ),
        ),
        const SizedBox(height: AppTheme.gap24),
        _StatRow(label: AppStrings.aqyl, value: '$myScore : $theirScore'),
        _StatRow(label: AppStrings.accuracy, value: '$accuracy%'),
        _StatRow(
          label: AppStrings.totalTime,
          value: '${(battle.totalTimeFor(uid) / 1000).round()} сек',
        ),
        _StatRow(label: AppStrings.rankChange, value: _rankDeltaText(battle, uid)),
        const SizedBox(height: AppTheme.gap24),
        FilledButton(
          onPressed: () => context.goNamed('battleLobby'),
          child: const Text(AppStrings.continueText),
        ),
      ],
    );
  }

  String _rankDeltaText(BattleModel battle, String uid) {
    if (battle.winnerId == null) return '0';
    return battle.winnerId == uid ? '+1' : '-1';
  }
}

class _StatRow extends StatelessWidget {
  const _StatRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(label),
        trailing: Text(
          value,
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
    );
  }
}

class _WaitingView extends StatelessWidget {
  const _WaitingView({
    required this.title,
    required this.action,
    required this.onPressed,
    this.message,
  });

  final String title;
  final String? message;
  final String action;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.gap24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
            if (message != null) ...[
              const SizedBox(height: AppTheme.gap8),
              Text(message!, textAlign: TextAlign.center),
            ],
            const SizedBox(height: AppTheme.gap24),
            FilledButton(onPressed: onPressed, child: Text(action)),
          ],
        ),
      ),
    );
  }
}
