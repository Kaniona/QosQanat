import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_strings.dart';
import '../../core/theme/app_theme.dart';
import '../../models/battle_model.dart';
import '../../models/question_model.dart';
import '../../providers/battle_provider.dart';
import '../../providers/user_provider.dart';

// 🔹 QOSQANAT: battle challenge lobby
class BattleLobbyScreen extends ConsumerStatefulWidget {
  const BattleLobbyScreen({super.key});

  @override
  ConsumerState<BattleLobbyScreen> createState() => _BattleLobbyScreenState();
}

class _BattleLobbyScreenState extends ConsumerState<BattleLobbyScreen> {
  final _receiverController = TextEditingController();
  SubjectType _subject = SubjectType.math;
  int _questionCount = 15;

  @override
  void dispose() {
    _receiverController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(userProvider).valueOrNull;
    final battles = ref.watch(myBattlesProvider);
    final controller = ref.watch(battleControllerProvider);

    ref.listen(battleControllerProvider, (_, next) {
      next.whenOrNull(
        error: (error, _) => _snack(error.toString()),
      );
    });

    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.battleLobby)),
      body: ListView(
        padding: const EdgeInsets.all(AppTheme.gap16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(AppTheme.gap16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    AppStrings.sendChallenge,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                  ),
                  const SizedBox(height: AppTheme.gap16),
                  DropdownButtonFormField<String>(
                    decoration: const InputDecoration(
                      labelText: AppStrings.chooseFriend,
                    ),
                    value: user?.friendIds.isNotEmpty == true
                        ? user!.friendIds.first
                        : null,
                    items: [
                      for (final friendId in user?.friendIds ?? const <String>[])
                        DropdownMenuItem(value: friendId, child: Text(friendId)),
                    ],
                    onChanged: (value) => _receiverController.text = value ?? '',
                  ),
                  const SizedBox(height: AppTheme.gap8),
                  TextField(
                    controller: _receiverController,
                    decoration: const InputDecoration(
                      labelText: AppStrings.friendUid,
                      hintText: AppStrings.friendUidHint,
                    ),
                  ),
                  const SizedBox(height: AppTheme.gap16),
                  SegmentedButton<SubjectType>(
                    segments: const [
                      ButtonSegment(
                        value: SubjectType.math,
                        icon: Icon(Icons.calculate),
                        label: Text(AppStrings.subjectMath),
                      ),
                      ButtonSegment(
                        value: SubjectType.english,
                        icon: Icon(Icons.translate),
                        label: Text(AppStrings.subjectEnglish),
                      ),
                    ],
                    selected: {_subject},
                    onSelectionChanged: (value) {
                      setState(() => _subject = value.first);
                    },
                  ),
                  const SizedBox(height: AppTheme.gap16),
                  DropdownButtonFormField<int>(
                    value: _questionCount,
                    decoration: const InputDecoration(
                      labelText: AppStrings.chooseQuestionCount,
                    ),
                    items: const [
                      DropdownMenuItem(value: 15, child: Text('15')),
                      DropdownMenuItem(value: 20, child: Text('20')),
                      DropdownMenuItem(value: 25, child: Text('25')),
                      DropdownMenuItem(value: 40, child: Text('40')),
                      DropdownMenuItem(value: 50, child: Text('50')),
                    ],
                    onChanged: (value) {
                      setState(() => _questionCount = value ?? 15);
                    },
                  ),
                  const SizedBox(height: AppTheme.gap16),
                  FilledButton.icon(
                    onPressed: controller.isLoading ? null : _createBattle,
                    icon: const Icon(Icons.sports_martial_arts),
                    label: Text(
                      controller.isLoading
                          ? AppStrings.loading
                          : AppStrings.sendChallenge,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: AppTheme.gap24),
          Text(
            AppStrings.pendingBattles,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
          ),
          const SizedBox(height: AppTheme.gap8),
          battles.when(
            data: (items) => items.isEmpty
                ? const Padding(
                    padding: EdgeInsets.all(AppTheme.gap24),
                    child: Center(child: Text(AppStrings.emptyState)),
                  )
                : Column(
                    children: [
                      for (final battle in items)
                        Padding(
                          padding: const EdgeInsets.only(bottom: AppTheme.gap8),
                          child: _BattleTile(battle: battle),
                        ),
                    ],
                  ),
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, _) => Text(error.toString()),
          ),
        ],
      ),
    );
  }

  Future<void> _createBattle() async {
    final receiverId = _receiverController.text.trim();
    if (receiverId.isEmpty) {
      _snack(AppStrings.chooseFriend);
      return;
    }
    final id = await ref.read(battleControllerProvider.notifier).createBattle(
          receiverId: receiverId,
          subject: _subject,
          questionCount: _questionCount,
        );
    if (!mounted || id == null) return;
    _receiverController.clear();
    context.goNamed('battle', pathParameters: {'id': id});
  }

  void _snack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class _BattleTile extends ConsumerWidget {
  const _BattleTile({required this.battle});

  final BattleModel battle;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final uid = ref.watch(currentUidProvider);
    final incoming = uid == battle.receiverId;
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: AppTheme.primary.withOpacity(0.1),
          child: const Icon(Icons.bolt, color: AppTheme.primary),
        ),
        title: Text(
          '${AppStrings.subjectLabel(battle.subject.name)} · ${battle.questionCount}',
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: Text(_statusText(battle.status)),
        trailing: _actions(context, ref, incoming),
      ),
    );
  }

  Widget _actions(BuildContext context, WidgetRef ref, bool incoming) {
    if (battle.status == BattleStatus.pending && incoming) {
      return Wrap(
        spacing: AppTheme.gap8,
        children: [
          IconButton.filled(
            tooltip: AppStrings.accept,
            onPressed: () {
              ref.read(battleControllerProvider.notifier).accept(battle.id);
              context.goNamed('battle', pathParameters: {'id': battle.id});
            },
            icon: const Icon(Icons.check),
          ),
          IconButton.outlined(
            tooltip: AppStrings.decline,
            onPressed: () {
              ref.read(battleControllerProvider.notifier).decline(battle.id);
            },
            icon: const Icon(Icons.close),
          ),
        ],
      );
    }
    if (battle.status == BattleStatus.in_progress ||
        battle.status == BattleStatus.accepted) {
      return IconButton.filledTonal(
        tooltip: AppStrings.continueText,
        onPressed: () => context.goNamed(
          'battle',
          pathParameters: {'id': battle.id},
        ),
        icon: const Icon(Icons.play_arrow),
      );
    }
    return IconButton(
      tooltip: AppStrings.battle,
      onPressed: () => context.goNamed('battle', pathParameters: {'id': battle.id}),
      icon: const Icon(Icons.chevron_right),
    );
  }

  String _statusText(BattleStatus status) {
    return switch (status) {
      BattleStatus.pending => AppStrings.battlePending,
      BattleStatus.accepted => AppStrings.battleInProgress,
      BattleStatus.in_progress => AppStrings.battleInProgress,
      BattleStatus.completed => AppStrings.battleCompleted,
      BattleStatus.declined => AppStrings.battleDeclined,
    };
  }
}

