import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lottie/lottie.dart';

import '../../core/constants/app_strings.dart';
import '../../core/theme/app_theme.dart';
import '../../models/user_model.dart';
import '../../providers/user_provider.dart';
import '../../services/auth_service.dart';

// 🔹 QOSQANAT: phone auth + onboarding
class AssistantSelectScreen extends ConsumerStatefulWidget {
  const AssistantSelectScreen({super.key});

  @override
  ConsumerState<AssistantSelectScreen> createState() =>
      _AssistantSelectScreenState();
}

class _AssistantSelectScreenState extends ConsumerState<AssistantSelectScreen> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  final _codeController = TextEditingController();
  final _nameController = TextEditingController();
  final _cityController = TextEditingController();
  final _schoolController = TextEditingController();

  String? _verificationId;
  int _grade = 6;
  AssistantType _assistant = AssistantType.bektur;
  bool _isSendingCode = false;
  bool _isSaving = false;

  @override
  void dispose() {
    _phoneController.dispose();
    _codeController.dispose();
    _nameController.dispose();
    _cityController.dispose();
    _schoolController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final firebaseUser = ref.watch(authStateProvider).valueOrNull;
    final user = ref.watch(userProvider).valueOrNull;
    if (user != null && user.isOnboarded) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.goNamed('home');
      });
    }

    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.appName)),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(AppTheme.gap24),
            children: [
              Text(
                AppStrings.tagline,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: AppTheme.gap8),
              const Text(AppStrings.onboardingIntro),
              const SizedBox(height: AppTheme.gap24),
              if (firebaseUser == null) _PhoneStep(onSend: _sendCode),
              if (firebaseUser == null && _verificationId != null)
                Padding(
                  padding: const EdgeInsets.only(top: AppTheme.gap16),
                  child: _SmsStep(onConfirm: _confirmCode),
                ),
              if (firebaseUser != null) _ProfileStep(onSave: _complete),
            ],
          ),
        ),
      ),
    );
  }

  Widget _PhoneStep({required VoidCallback onSend}) {
    return Column(
      children: [
        TextFormField(
          controller: _phoneController,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
            labelText: AppStrings.phone,
            hintText: AppStrings.phoneHint,
          ),
          validator: (value) =>
              (value == null || value.trim().length < 10) ? AppStrings.phone : null,
        ),
        const SizedBox(height: AppTheme.gap16),
        FilledButton(
          onPressed: _isSendingCode ? null : onSend,
          child: Text(_isSendingCode ? AppStrings.loading : AppStrings.sendCode),
        ),
      ],
    );
  }

  Widget _SmsStep({required VoidCallback onConfirm}) {
    return Column(
      children: [
        TextFormField(
          controller: _codeController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: AppStrings.smsCode),
          validator: (value) =>
              (value == null || value.trim().length < 6) ? AppStrings.smsCode : null,
        ),
        const SizedBox(height: AppTheme.gap16),
        FilledButton(
          onPressed: onConfirm,
          child: const Text(AppStrings.confirmCode),
        ),
      ],
    );
  }

  Widget _ProfileStep({required VoidCallback onSave}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextFormField(
          controller: _nameController,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(labelText: AppStrings.fullName),
          validator: _required,
        ),
        const SizedBox(height: AppTheme.gap16),
        TextFormField(
          controller: _cityController,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(labelText: AppStrings.city),
          validator: _required,
        ),
        const SizedBox(height: AppTheme.gap16),
        TextFormField(
          controller: _schoolController,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(labelText: AppStrings.school),
          validator: _required,
        ),
        const SizedBox(height: AppTheme.gap16),
        DropdownButtonFormField<int>(
          value: _grade,
          decoration: const InputDecoration(labelText: AppStrings.grade),
          items: const [
            DropdownMenuItem(value: 6, child: Text('6')),
            DropdownMenuItem(value: 7, child: Text('7')),
            DropdownMenuItem(value: 8, child: Text('8')),
          ],
          onChanged: (value) => setState(() => _grade = value ?? 6),
        ),
        const SizedBox(height: AppTheme.gap24),
        Text(
          AppStrings.chooseAssistant,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w900,
              ),
        ),
        const SizedBox(height: AppTheme.gap8),
        Row(
          children: [
            Expanded(
              child: _AssistantCard(
                selected: _assistant == AssistantType.bektur,
                name: AppStrings.bektur,
                asset: 'assets/lottie/assistant_idle.json',
                onTap: () => setState(() => _assistant = AssistantType.bektur),
              ),
            ),
            const SizedBox(width: AppTheme.gap8),
            Expanded(
              child: _AssistantCard(
                selected: _assistant == AssistantType.nazym,
                name: AppStrings.nazym,
                asset: 'assets/lottie/assistant_happy.json',
                onTap: () => setState(() => _assistant = AssistantType.nazym),
              ),
            ),
          ],
        ),
        const SizedBox(height: AppTheme.gap24),
        FilledButton(
          onPressed: _isSaving ? null : onSave,
          child: Text(_isSaving ? AppStrings.loading : AppStrings.startLearning),
        ),
      ],
    );
  }

  Future<void> _sendCode() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSendingCode = true);
    await ref.read(authProvider).verifyPhoneNumber(
          phoneNumber: _phoneController.text,
          onCodeSent: (verificationId, _) {
            if (!mounted) return;
            setState(() {
              _verificationId = verificationId;
              _isSendingCode = false;
            });
          },
          onAutoVerified: (PhoneAuthCredential _) {
            if (mounted) setState(() => _isSendingCode = false);
          },
          onError: (message) {
            if (!mounted) return;
            setState(() => _isSendingCode = false);
            _showSnack(message);
          },
        );
  }

  Future<void> _confirmCode() async {
    if (_verificationId == null || !_formKey.currentState!.validate()) return;
    try {
      await ref.read(authProvider).signInWithSmsCode(
            verificationId: _verificationId!,
            smsCode: _codeController.text,
          );
    } catch (error) {
      _showSnack(error.toString());
    }
  }

  Future<void> _complete() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);
    try {
      await ref.read(authProvider).completeOnboarding(
            UserRegistrationData(
              fullName: _nameController.text,
              phone: _phoneController.text,
              city: _cityController.text,
              school: _schoolController.text,
              grade: _grade,
              assistant: _assistant,
            ),
          );
      if (!mounted) return;
      context.goNamed('home');
    } catch (error) {
      _showSnack(error.toString());
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  String? _required(String? value) {
    return value == null || value.trim().isEmpty ? AppStrings.errorGeneric : null;
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class _AssistantCard extends StatelessWidget {
  const _AssistantCard({
    required this.selected,
    required this.name,
    required this.asset,
    required this.onTap,
  });

  final bool selected;
  final String name;
  final String asset;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(AppTheme.cardRadius),
      onTap: onTap,
      child: Card(
        color: selected ? AppTheme.primary.withOpacity(0.08) : null,
        child: Padding(
          padding: const EdgeInsets.all(AppTheme.gap16),
          child: Column(
            children: [
              SizedBox(
                height: 110,
                child: Lottie.asset(
                  asset,
                  repeat: true,
                  errorBuilder: (_, __, ___) => const Icon(
                    Icons.auto_awesome,
                    size: 64,
                    color: AppTheme.primary,
                  ),
                ),
              ),
              const SizedBox(height: AppTheme.gap8),
              Text(
                name,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: AppTheme.gap8),
              Icon(
                selected ? Icons.check_circle : Icons.circle_outlined,
                color: selected ? AppTheme.success : AppTheme.muted,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

