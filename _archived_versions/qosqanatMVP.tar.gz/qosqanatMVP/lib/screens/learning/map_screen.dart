import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_strings.dart';
import '../../core/theme/app_theme.dart';
import '../../models/question_model.dart';
import '../../providers/game_provider.dart';
import '../../providers/user_provider.dart';

// 🔹 QOSQANAT: learning map
class MapScreen extends ConsumerWidget {
  const MapScreen({super.key});

  static const topics = {
    SubjectType.math: [AppStrings.topicFractions, AppStrings.topicPercent, AppStrings.topicGeometry],
    SubjectType.english: [AppStrings.topicVocabulary, AppStrings.topicGrammar, AppStrings.topicReading],
  };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userAsync = ref.watch(userProvider);
    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.navLearn)),
      body: userAsync.when(
        data: (user) {
          if (user == null) {
            return const Center(child: Text(AppStrings.loading));
          }
          return ListView(
            padding: const EdgeInsets.all(AppTheme.gap16),
            children: [
              Text(
                AppStrings.chooseSubject,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: AppTheme.gap16),
              for (final subject in SubjectType.values)
                Padding(
                  padding: const EdgeInsets.only(bottom: AppTheme.gap24),
                  child: _SubjectSection(
                    subject: subject,
                    completedLessons: user.completedLessons,
                  ),
                ),
            ],
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => _ErrorView(message: error.toString()),
      ),
    );
  }
}

class _SubjectSection extends StatelessWidget {
  const _SubjectSection({
    required this.subject,
    required this.completedLessons,
  });

  final SubjectType subject;
  final List<String> completedLessons;

  @override
  Widget build(BuildContext context) {
    final topicList = MapScreen.topics[subject] ?? const <String>[];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              subject == SubjectType.math ? Icons.calculate : Icons.translate,
              color: AppTheme.primary,
            ),
            const SizedBox(width: AppTheme.gap8),
            Text(
              AppStrings.subjectLabel(subject.name),
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
          ],
        ),
        const SizedBox(height: AppTheme.gap8),
        for (final topic in topicList)
          Padding(
            padding: const EdgeInsets.only(bottom: AppTheme.gap16),
            child: _TopicLevels(
              subject: subject,
              topic: topic,
              completedLessons: completedLessons,
            ),
          ),
      ],
    );
  }
}

class _TopicLevels extends StatelessWidget {
  const _TopicLevels({
    required this.subject,
    required this.topic,
    required this.completedLessons,
  });

  final SubjectType subject;
  final String topic;
  final List<String> completedLessons;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.gap16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              topic,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
            const SizedBox(height: AppTheme.gap8),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 10,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 5,
                mainAxisSpacing: AppTheme.gap8,
                crossAxisSpacing: AppTheme.gap8,
                childAspectRatio: 1,
              ),
              itemBuilder: (context, index) {
                final level = index + 1;
                final lessonId = GameController.buildLessonId(
                  subject: subject,
                  topic: topic,
                  level: level,
                );
                final previousId = GameController.buildLessonId(
                  subject: subject,
                  topic: topic,
                  level: level - 1,
                );
                final completed = completedLessons.contains(lessonId);
                final unlocked = level == 1 || completedLessons.contains(previousId);
                return _LevelTile(
                  level: level,
                  completed: completed,
                  unlocked: unlocked,
                  onTap: unlocked
                      ? () => context.goNamed(
                            'lesson',
                            pathParameters: {
                              'subject': subject.name,
                              'topic': Uri.encodeComponent(topic),
                              'level': '$level',
                            },
                          )
                      : null,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _LevelTile extends StatelessWidget {
  const _LevelTile({
    required this.level,
    required this.completed,
    required this.unlocked,
    required this.onTap,
  });

  final int level;
  final bool completed;
  final bool unlocked;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final color = completed
        ? AppTheme.success
        : unlocked
            ? AppTheme.primary
            : AppTheme.muted;
    return Tooltip(
      message: completed
          ? AppStrings.completed
          : unlocked
              ? AppStrings.unlocked
              : AppStrings.locked,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: color.withOpacity(unlocked ? 0.12 : 0.08),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(0.25)),
          ),
          child: Center(
            child: completed
                ? const Icon(Icons.check, color: AppTheme.success)
                : unlocked
                    ? Text(
                        '$level',
                        style: const TextStyle(
                          color: AppTheme.primary,
                          fontWeight: FontWeight.w900,
                        ),
                      )
                    : const Icon(Icons.lock, color: AppTheme.muted, size: 18),
          ),
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.gap24),
        child: Text(message, textAlign: TextAlign.center),
      ),
    );
  }
}

