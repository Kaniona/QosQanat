import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lottie/lottie.dart';

import '../../core/constants/app_strings.dart';
import '../../core/theme/app_theme.dart';
import '../../models/question_model.dart';
import '../../providers/game_provider.dart';

// 🔹 QOSQANAT: timed lesson flow
class LessonScreen extends ConsumerStatefulWidget {
  const LessonScreen({
    super.key,
    required this.subject,
    required this.topic,
    required this.level,
  });

  final SubjectType subject;
  final String topic;
  final int level;

  @override
  ConsumerState<LessonScreen> createState() => _LessonScreenState();
}

class _LessonScreenState extends ConsumerState<LessonScreen> {
  final _answerController = TextEditingController();
  Timer? _timer;
  int _secondsLeft = 30;
  String? _timerQuestionId;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(gameProvider.notifier).loadLesson(
            subject: widget.subject,
            topic: widget.topic,
            level: widget.level,
          );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _answerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(gameProvider);
    _armTimerFor(state);

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.topic} · ${AppStrings.level} ${widget.level}'),
      ),
      body: SafeArea(
        child: AnimatedSwitcher(
          duration: 220.ms,
          child: _bodyFor(state),
        ),
      ),
    );
  }

  Widget _bodyFor(GameState state) {
    if (state.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (state.error != null && state.questions.isEmpty) {
      return _CenteredMessage(
        title: AppStrings.errorGeneric,
        message: state.error!,
        action: AppStrings.retry,
        onPressed: _reload,
      );
    }
    if (state.questions.isEmpty) {
      return _CenteredMessage(
        title: AppStrings.emptyState,
        message: AppStrings.errorGeneric,
        action: AppStrings.retry,
        onPressed: _reload,
      );
    }
    if (state.feedback == LessonFeedback.completed) {
      _timer?.cancel();
      return _ResultView(
        title: AppStrings.lessonComplete,
        asset: 'assets/lottie/celebration.json',
        action: AppStrings.continueText,
        onPressed: () => context.goNamed('learning'),
      );
    }
    if (state.feedback == LessonFeedback.failed) {
      _timer?.cancel();
      return _ResultView(
        title: AppStrings.lessonFailed,
        asset: 'assets/lottie/assistant_sad.json',
        action: AppStrings.retry,
        onPressed: _reload,
      );
    }

    final question = state.currentQuestion!;
    return ListView(
      padding: const EdgeInsets.all(AppTheme.gap16),
      children: [
        if (state.isOffline)
          Container(
            margin: const EdgeInsets.only(bottom: AppTheme.gap16),
            padding: const EdgeInsets.all(AppTheme.gap8),
            decoration: BoxDecoration(
              color: AppTheme.accent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(AppTheme.buttonRadius),
            ),
            child: const Text(AppStrings.offlineBanner),
          ),
        Row(
          children: [
            Expanded(
              child: LinearProgressIndicator(
                value: (state.currentIndex + 1) / state.questions.length,
                minHeight: 10,
                borderRadius: BorderRadius.circular(99),
              ),
            ),
            const SizedBox(width: AppTheme.gap16),
            Text(
              '${state.currentIndex + 1}/${state.questions.length}',
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
          ],
        ),
        const SizedBox(height: AppTheme.gap16),
        _TimerPill(secondsLeft: _secondsLeft),
        const SizedBox(height: AppTheme.gap24),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(AppTheme.gap24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  question.questionText,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
                const SizedBox(height: AppTheme.gap24),
                _AnswerInput(
                  question: question,
                  controller: _answerController,
                  enabled: state.feedback == LessonFeedback.idle,
                  onSubmit: _submit,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: AppTheme.gap16),
        if (state.feedback == LessonFeedback.correct)
          _FeedbackBox(
            color: AppTheme.success,
            icon: Icons.check_circle,
            title: AppStrings.correct,
            message: '+${question.aqylReward} ${AppStrings.aqyl} · '
                '+${question.expReward} ${AppStrings.exp}',
            action: AppStrings.nextQuestion,
            onPressed: _continue,
          ),
        if (state.feedback == LessonFeedback.wrong)
          _FeedbackBox(
            color: AppTheme.error,
            icon: Icons.cancel,
            title: AppStrings.wrong,
            message: '${AppStrings.explanation}: ${question.explanation}',
            action: AppStrings.retry,
            onPressed: _continue,
          ),
      ],
    );
  }

  void _armTimerFor(GameState state) {
    final question = state.currentQuestion;
    if (question == null || state.feedback != LessonFeedback.idle) return;
    if (_timerQuestionId == question.id) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _startTimer(question);
    });
  }

  void _startTimer(QuestionModel question) {
    _timer?.cancel();
    setState(() {
      _secondsLeft = question.timeLimitSec;
      _timerQuestionId = question.id;
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_secondsLeft <= 1) {
        timer.cancel();
        _submit('');
      } else if (mounted) {
        setState(() => _secondsLeft--);
      }
    });
  }

  Future<void> _submit(String answer) async {
    final state = ref.read(gameProvider);
    final question = state.currentQuestion;
    if (question == null || state.feedback != LessonFeedback.idle) return;
    _timer?.cancel();
    final isCorrect = question.isCorrect(answer);
    await HapticFeedback.mediumImpact();
    if (isCorrect) {
      await HapticFeedback.selectionClick();
    }
    await ref.read(gameProvider.notifier).submitAnswer(answer);
    if (!isCorrect && mounted) {
      await HapticFeedback.heavyImpact();
    }
  }

  void _continue() {
    _answerController.clear();
    ref.read(gameProvider.notifier).continueAfterFeedback();
    final question = ref.read(gameProvider).currentQuestion;
    if (question != null) _startTimer(question);
  }

  void _reload() {
    _answerController.clear();
    _timerQuestionId = null;
    ref.read(gameProvider.notifier).loadLesson(
          subject: widget.subject,
          topic: widget.topic,
          level: widget.level,
        );
  }
}

class _AnswerInput extends StatelessWidget {
  const _AnswerInput({
    required this.question,
    required this.controller,
    required this.enabled,
    required this.onSubmit,
  });

  final QuestionModel question;
  final TextEditingController controller;
  final bool enabled;
  final ValueChanged<String> onSubmit;

  @override
  Widget build(BuildContext context) {
    if (question.type == QuestionType.multipleChoice ||
        question.type == QuestionType.trueFalse) {
      final options = question.type == QuestionType.trueFalse
          ? const ['true', 'false']
          : question.options;
      return Column(
        children: [
          for (final option in options)
            Padding(
              padding: const EdgeInsets.only(bottom: AppTheme.gap8),
              child: OutlinedButton(
                onPressed: enabled ? () => onSubmit(option) : null,
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    option == 'true'
                        ? AppStrings.trueLabel
                        : option == 'false'
                            ? AppStrings.falseLabel
                            : option,
                  ),
                ),
              ),
            ),
        ],
      );
    }

    return Column(
      children: [
        TextField(
          controller: controller,
          enabled: enabled,
          keyboardType: question.type == QuestionType.mathInput
              ? TextInputType.number
              : TextInputType.text,
          decoration: const InputDecoration(labelText: AppStrings.checkAnswer),
          onSubmitted: enabled ? onSubmit : null,
        ),
        const SizedBox(height: AppTheme.gap16),
        FilledButton(
          onPressed: enabled ? () => onSubmit(controller.text) : null,
          child: const Text(AppStrings.checkAnswer),
        ),
      ],
    );
  }
}

class _TimerPill extends StatelessWidget {
  const _TimerPill({required this.secondsLeft});

  final int secondsLeft;

  @override
  Widget build(BuildContext context) {
    final warning = secondsLeft <= 8;
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppTheme.gap16,
          vertical: AppTheme.gap8,
        ),
        decoration: BoxDecoration(
          color: (warning ? AppTheme.error : AppTheme.primary)
              .withOpacity(0.1),
          borderRadius: BorderRadius.circular(99),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.timer,
              size: 18,
              color: warning ? AppTheme.error : AppTheme.primary,
            ),
            const SizedBox(width: AppTheme.gap8),
            Text(
              '${AppStrings.timeLeft}: $secondsLeft',
              style: TextStyle(
                color: warning ? AppTheme.error : AppTheme.primary,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FeedbackBox extends StatelessWidget {
  const _FeedbackBox({
    required this.color,
    required this.icon,
    required this.title,
    required this.message,
    required this.action,
    required this.onPressed,
  });

  final Color color;
  final IconData icon;
  final String title;
  final String message;
  final String action;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppTheme.gap16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(AppTheme.cardRadius),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color),
              const SizedBox(width: AppTheme.gap8),
              Text(
                title,
                style: TextStyle(color: color, fontWeight: FontWeight.w900),
              ),
            ],
          ),
          const SizedBox(height: AppTheme.gap8),
          Text(message),
          const SizedBox(height: AppTheme.gap16),
          FilledButton(onPressed: onPressed, child: Text(action)),
        ],
      ),
    ).animate().fadeIn(duration: 160.ms).slideY(begin: 0.08, end: 0);
  }
}

class _ResultView extends StatelessWidget {
  const _ResultView({
    required this.title,
    required this.asset,
    required this.action,
    required this.onPressed,
  });

  final String title;
  final String asset;
  final String action;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.gap24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 180,
              child: Lottie.asset(
                asset,
                repeat: true,
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.emoji_events,
                  size: 96,
                  color: AppTheme.primary,
                ),
              ),
            ),
            const SizedBox(height: AppTheme.gap16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
            const SizedBox(height: AppTheme.gap24),
            FilledButton(onPressed: onPressed, child: Text(action)),
          ],
        ),
      ),
    );
  }
}

class _CenteredMessage extends StatelessWidget {
  const _CenteredMessage({
    required this.title,
    required this.message,
    required this.action,
    required this.onPressed,
  });

  final String title;
  final String message;
  final String action;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.gap24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
            const SizedBox(height: AppTheme.gap8),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: AppTheme.gap16),
            FilledButton(onPressed: onPressed, child: Text(action)),
          ],
        ),
      ),
    );
  }
}

