import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lottie/lottie.dart';

import '../../core/constants/app_strings.dart';
import '../../core/theme/app_theme.dart';
import '../../models/shop_item_model.dart';
import '../../providers/shop_provider.dart';
import '../../providers/user_provider.dart';

// 🔹 QOSQANAT: shop + inventory
class ShopScreen extends ConsumerStatefulWidget {
  const ShopScreen({super.key});

  @override
  ConsumerState<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends ConsumerState<ShopScreen> {
  ShopCategory _category = ShopCategory.outfit;

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(userProvider).valueOrNull;
    final itemsAsync = ref.watch(shopProvider);

    ref.listen(shopControllerProvider, (_, next) {
      next.whenOrNull(
        data: (_) => _showSuccess(),
        error: (error, _) => _snack(error.toString()),
      );
    });

    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.shop)),
      body: ListView(
        padding: const EdgeInsets.all(AppTheme.gap16),
        children: [
          if (user != null)
            Card(
              child: ListTile(
                leading: const Icon(Icons.monetization_on, color: Colors.amber),
                title: const Text(AppStrings.coin),
                trailing: Text(
                  '${user.coin}',
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
              ),
            ),
          const SizedBox(height: AppTheme.gap16),
          SegmentedButton<ShopCategory>(
            segments: const [
              ButtonSegment(
                value: ShopCategory.outfit,
                icon: Icon(Icons.checkroom),
                label: Text(AppStrings.outfits),
              ),
              ButtonSegment(
                value: ShopCategory.accessory,
                icon: Icon(Icons.auto_awesome),
                label: Text(AppStrings.accessories),
              ),
              ButtonSegment(
                value: ShopCategory.pet,
                icon: Icon(Icons.pets),
                label: Text(AppStrings.pets),
              ),
            ],
            selected: {_category},
            onSelectionChanged: (value) => setState(() => _category = value.first),
          ),
          const SizedBox(height: AppTheme.gap16),
          itemsAsync.when(
            data: (items) {
              final filtered = items
                  .where((item) => item.category == _category)
                  .where((item) => user == null || item.supports(user.assistant))
                  .toList(growable: false);
              if (filtered.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.all(AppTheme.gap24),
                  child: Center(child: Text(AppStrings.emptyState)),
                );
              }
              return GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: filtered.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: AppTheme.gap8,
                  crossAxisSpacing: AppTheme.gap8,
                  childAspectRatio: 0.72,
                ),
                itemBuilder: (context, index) {
                  return _ShopCard(item: filtered[index]);
                },
              );
            },
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, _) => Text(error.toString()),
          ),
        ],
      ),
    );
  }

  Future<void> _showSuccess() async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 120,
              child: Lottie.asset(
                'assets/lottie/success.json',
                repeat: false,
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.check_circle,
                  color: AppTheme.success,
                  size: 72,
                ),
              ),
            ),
            const Text(AppStrings.success),
          ],
        ),
      ),
    );
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class _ShopCard extends ConsumerWidget {
  const _ShopCard({required this.item});

  final ShopItemModel item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(userProvider).valueOrNull;
    final owned = user?.inventory[item.id] == true;
    final active = item.category == ShopCategory.pet && user?.activePet == item.id;
    final controller = ref.watch(shopControllerProvider);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.gap8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(AppTheme.cardRadius),
                ),
                child: Icon(
                  item.category == ShopCategory.pet
                      ? Icons.pets
                      : item.category == ShopCategory.outfit
                          ? Icons.checkroom
                          : Icons.auto_awesome,
                  size: 54,
                  color: AppTheme.primary,
                ),
              ),
            ),
            const SizedBox(height: AppTheme.gap8),
            Text(
              item.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: AppTheme.gap4),
            Text(
              item.description,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppTheme.muted,
                  ),
            ),
            const SizedBox(height: AppTheme.gap8),
            Row(
              children: [
                const Icon(Icons.monetization_on, color: Colors.amber, size: 18),
                const SizedBox(width: AppTheme.gap4),
                Text('${item.price}'),
              ],
            ),
            const SizedBox(height: AppTheme.gap8),
            if (!owned)
              FilledButton(
                onPressed: controller.isLoading
                    ? null
                    : () => ref.read(shopControllerProvider.notifier).purchase(item),
                child: const Text(AppStrings.buy),
              )
            else
              Row(
                children: [
                  Expanded(
                    child: FilledButton.tonal(
                      onPressed: active
                          ? null
                          : () => ref.read(shopControllerProvider.notifier).apply(item),
                      child: Text(active ? AppStrings.purchased : AppStrings.apply),
                    ),
                  ),
                  const SizedBox(width: AppTheme.gap8),
                  IconButton.outlined(
                    tooltip: AppStrings.refund,
                    onPressed: () {
                      ref.read(shopControllerProvider.notifier).refund(item);
                    },
                    icon: const Icon(Icons.undo),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}

