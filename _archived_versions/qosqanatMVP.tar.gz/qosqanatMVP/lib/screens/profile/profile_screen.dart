import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants/app_strings.dart';
import '../../core/theme/app_theme.dart';
import '../../models/question_model.dart';
import '../../models/ranking_model.dart';
import '../../providers/user_provider.dart';

// 🔹 QOSQANAT: profile + ranking
class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key, this.rankingOnly = false});

  final bool rankingOnly;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userAsync = ref.watch(userProvider);
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(rankingOnly ? AppStrings.navRanking : AppStrings.profile),
          bottom: rankingOnly
              ? const TabBar(
                  tabs: [
                    Tab(text: AppStrings.global),
                    Tab(text: AppStrings.schoolTab),
                    Tab(text: AppStrings.friends),
                  ],
                )
              : null,
        ),
        body: userAsync.when(
          data: (user) {
            if (user == null) {
              return const Center(child: Text(AppStrings.loading));
            }
            if (rankingOnly) return _RankingTabs(userSchool: user.school);
            return ListView(
              padding: const EdgeInsets.all(AppTheme.gap16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(AppTheme.gap16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 32,
                              backgroundColor:
                                  AppTheme.primary.withOpacity(0.12),
                              child: Text(
                                user.fullName.trim().isEmpty
                                    ? 'Q'
                                    : user.fullName.trim().substring(0, 1),
                                style: const TextStyle(
                                  color: AppTheme.primary,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 24,
                                ),
                              ),
                            ),
                            const SizedBox(width: AppTheme.gap16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    user.fullName,
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleLarge
                                        ?.copyWith(fontWeight: FontWeight.w900),
                                  ),
                                  Text('${AppStrings.qqId}: ${user.qqId}'),
                                  Text('${user.school} · ${user.grade}-сынып'),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: AppTheme.gap16),
                        Row(
                          children: [
                            _StatChip(label: AppStrings.aqyl, value: '${user.aqyl}'),
                            _StatChip(label: AppStrings.exp, value: '${user.exp}'),
                            _StatChip(label: AppStrings.coin, value: '${user.coin}'),
                          ],
                        ),
                        const SizedBox(height: AppTheme.gap16),
                        LinearProgressIndicator(
                          value: ((user.exp % 100) / 100).clamp(0, 1),
                          minHeight: 10,
                          borderRadius: BorderRadius.circular(99),
                        ),
                        const SizedBox(height: AppTheme.gap8),
                        Text('${AppStrings.level}: ${user.level}'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: AppTheme.gap16),
                _Badges(
                  firstWin: user.aqyl >= 20,
                  tenCorrect: user.completedLessons.length >= 4,
                  sevenDayLogin: user.loginStreak >= 7,
                ),
                const SizedBox(height: AppTheme.gap16),
                _SubjectProgress(completedLessons: user.completedLessons),
                const SizedBox(height: AppTheme.gap16),
                FilledButton.icon(
                  onPressed: () => ref.read(authControllerProvider.notifier).signOut(),
                  icon: const Icon(Icons.logout),
                  label: const Text(AppStrings.signOut),
                ),
              ],
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => Center(child: Text(error.toString())),
        ),
      ),
    );
  }
}

class _RankingTabs extends ConsumerWidget {
  const _RankingTabs({required this.userSchool});

  final String userSchool;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final service = ref.watch(firestoreServiceProvider);
    final user = ref.watch(userProvider).valueOrNull;
    return TabBarView(
      children: [
        _RankingList(stream: service.watchGlobalRanking()),
        _RankingList(stream: service.watchSchoolRanking(userSchool)),
        _RankingList(stream: service.watchFriendRanking(user?.friendIds ?? const [])),
      ],
    );
  }
}

class _RankingList extends StatelessWidget {
  const _RankingList({required this.stream});

  final Stream<List<RankingModel>> stream;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<RankingModel>>(
      stream: stream,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        final items = snapshot.data ?? const [];
        if (items.isEmpty) return const Center(child: Text(AppStrings.emptyState));
        return ListView.builder(
          padding: const EdgeInsets.all(AppTheme.gap16),
          itemCount: items.length,
          itemBuilder: (context, index) {
            final item = items[index];
            return Padding(
              padding: const EdgeInsets.only(bottom: AppTheme.gap8),
              child: Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: index < 3
                        ? Colors.amber.withOpacity(0.18)
                        : AppTheme.primary.withOpacity(0.1),
                    child: Text('${index + 1}'),
                  ),
                  title: Text(item.displayName),
                  subtitle: Text('${item.school} · ${item.grade}-сынып'),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        '${item.aqyl}',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                      Text('${AppStrings.level} ${item.level}'),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.only(right: AppTheme.gap8),
        padding: const EdgeInsets.all(AppTheme.gap8),
        decoration: BoxDecoration(
          color: AppTheme.primary.withOpacity(0.08),
          borderRadius: BorderRadius.circular(AppTheme.buttonRadius),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(color: AppTheme.muted)),
            Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}

class _Badges extends StatelessWidget {
  const _Badges({
    required this.firstWin,
    required this.tenCorrect,
    required this.sevenDayLogin,
  });

  final bool firstWin;
  final bool tenCorrect;
  final bool sevenDayLogin;

  @override
  Widget build(BuildContext context) {
    final badges = [
      (AppStrings.firstWin, firstWin, Icons.emoji_events),
      (AppStrings.tenCorrect, tenCorrect, Icons.local_fire_department),
      (AppStrings.sevenDayLogin, sevenDayLogin, Icons.calendar_month),
    ];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.gap16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              AppStrings.badges,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
            const SizedBox(height: AppTheme.gap8),
            Wrap(
              spacing: AppTheme.gap8,
              runSpacing: AppTheme.gap8,
              children: [
                for (final badge in badges)
                  Chip(
                    avatar: Icon(
                      badge.$3,
                      color: badge.$2 ? AppTheme.primary : AppTheme.muted,
                    ),
                    label: Text(badge.$1),
                    backgroundColor: badge.$2
                        ? AppTheme.primary.withOpacity(0.1)
                        : Colors.grey.withOpacity(0.08),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SubjectProgress extends StatelessWidget {
  const _SubjectProgress({required this.completedLessons});

  final List<String> completedLessons;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.gap16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              AppStrings.navLearn,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
            const SizedBox(height: AppTheme.gap16),
            _ProgressRow(
              label: AppStrings.subjectMath,
              count: completedLessons
                  .where((lesson) => lesson.startsWith(SubjectType.math.name))
                  .length,
            ),
            const SizedBox(height: AppTheme.gap8),
            _ProgressRow(
              label: AppStrings.subjectEnglish,
              count: completedLessons
                  .where((lesson) => lesson.startsWith(SubjectType.english.name))
                  .length,
            ),
          ],
        ),
      ),
    );
  }
}

class _ProgressRow extends StatelessWidget {
  const _ProgressRow({required this.label, required this.count});

  final String label;
  final int count;

  @override
  Widget build(BuildContext context) {
    final value = (count / 30).clamp(0, 1).toDouble();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label),
            Text('$count/30'),
          ],
        ),
        const SizedBox(height: AppTheme.gap8),
        LinearProgressIndicator(
          value: value,
          minHeight: 8,
          borderRadius: BorderRadius.circular(99),
        ),
      ],
    );
  }
}
