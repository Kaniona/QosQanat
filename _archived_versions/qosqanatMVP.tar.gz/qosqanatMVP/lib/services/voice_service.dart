import 'dart:async';

import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:url_launcher/url_launcher.dart';

// 🔹 QOSQANAT: voice command mapping
enum VoiceCommand {
  openYoutube,
  openWhatsapp,
  dailyLesson,
  addFriend,
  help,
  unknown,
}

class VoiceService {
  VoiceService({
    SpeechToText? speech,
    FlutterTts? tts,
  })  : _speech = speech ?? SpeechToText(),
        _tts = tts ?? FlutterTts();

  final SpeechToText _speech;
  final FlutterTts _tts;

  Future<bool> initialize() async {
    final available = await _speech.initialize();
    await _tts.setLanguage('kk-KZ');
    await _tts.setSpeechRate(0.45);
    await _tts.setPitch(1.0);
    return available;
  }

  Future<void> speak(String message) async {
    await _tts.stop();
    await _tts.speak(message);
  }

  Future<VoiceCommand> listenOnce() async {
    final completer = Completer<VoiceCommand>();
    final available = await initialize();
    if (!available) return VoiceCommand.unknown;

    await _speech.listen(
      localeId: 'kk_KZ',
      listenOptions: SpeechListenOptions(
        listenMode: ListenMode.confirmation,
        partialResults: false,
      ),
      onResult: (result) {
        if (result.finalResult && !completer.isCompleted) {
          completer.complete(parseCommand(result.recognizedWords));
        }
      },
    );

    return completer.future.timeout(
      const Duration(seconds: 8),
      onTimeout: () async {
        await _speech.stop();
        return VoiceCommand.unknown;
      },
    );
  }

  Future<void> executeExternal(VoiceCommand command) async {
    switch (command) {
      case VoiceCommand.openYoutube:
        await _launchWithFallback(
          Uri.parse('youtube://'),
          Uri.parse('https://youtube.com'),
        );
      case VoiceCommand.openWhatsapp:
        await _launchWithFallback(
          Uri.parse('whatsapp://send'),
          Uri.parse('https://wa.me/'),
        );
      case VoiceCommand.dailyLesson:
      case VoiceCommand.addFriend:
      case VoiceCommand.help:
      case VoiceCommand.unknown:
        return;
    }
  }

  VoiceCommand parseCommand(String raw) {
    final text = raw.toLowerCase().trim();
    if (text.contains('ютуб аш') || text.contains('youtube')) {
      return VoiceCommand.openYoutube;
    }
    if (text.contains('ватсап аш') || text.contains('whatsapp')) {
      return VoiceCommand.openWhatsapp;
    }
    if (text.contains('бүгінгі тапсырма')) return VoiceCommand.dailyLesson;
    if (text.contains('досымды қос') || text.contains('дос қос')) {
      return VoiceCommand.addFriend;
    }
    if (text.contains('көмек')) return VoiceCommand.help;
    return VoiceCommand.unknown;
  }

  Future<void> _launchWithFallback(Uri appUri, Uri webUri) async {
    if (await canLaunchUrl(appUri)) {
      await launchUrl(appUri, mode: LaunchMode.externalApplication);
      return;
    }
    await launchUrl(webUri, mode: LaunchMode.externalApplication);
  }
}

