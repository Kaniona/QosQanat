import 'package:firebase_auth/firebase_auth.dart';

import '../models/user_model.dart';
import 'firestore_service.dart';

// 🔹 QOSQANAT: Firebase phone auth + onboarding
class UserRegistrationData {
  const UserRegistrationData({
    required this.fullName,
    required this.phone,
    required this.city,
    required this.school,
    required this.grade,
    required this.assistant,
  });

  final String fullName;
  final String phone;
  final String city;
  final String school;
  final int grade;
  final AssistantType assistant;
}

class AuthService {
  AuthService({
    FirebaseAuth? auth,
    required FirestoreService firestoreService,
  })  : _auth = auth ?? FirebaseAuth.instance,
        _firestore = firestoreService;

  final FirebaseAuth _auth;
  final FirestoreService _firestore;

  User? get currentUser => _auth.currentUser;

  Stream<User?> authStateChanges() => _auth.authStateChanges();

  Future<void> verifyPhoneNumber({
    required String phoneNumber,
    required void Function(String verificationId, int? resendToken) onCodeSent,
    required void Function(String message) onError,
    void Function(PhoneAuthCredential credential)? onAutoVerified,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber.trim(),
      timeout: const Duration(seconds: 60),
      verificationCompleted: (credential) async {
        if (onAutoVerified != null) onAutoVerified(credential);
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: (error) => onError(error.message ?? 'SMS қате шықты'),
      codeSent: onCodeSent,
      codeAutoRetrievalTimeout: (_) {},
    );
  }

  Future<UserCredential> signInWithSmsCode({
    required String verificationId,
    required String smsCode,
  }) {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode.trim(),
    );
    return _auth.signInWithCredential(credential);
  }

  Future<UserModel> completeOnboarding(UserRegistrationData data) async {
    final firebaseUser = _auth.currentUser;
    if (firebaseUser == null) {
      throw StateError('Алдымен телефон арқылы кіріңіз');
    }
    final existing = await _firestore.getUser(firebaseUser.uid);
    if (existing != null) return existing;
    final qqId = await _generateUniqueQqId();
    final user = UserModel.initial(
      uid: firebaseUser.uid,
      qqId: qqId,
      fullName: data.fullName,
      phone: data.phone.isEmpty ? firebaseUser.phoneNumber ?? '' : data.phone,
      city: data.city,
      school: data.school,
      grade: data.grade,
      assistant: data.assistant,
    );
    await _firestore.createUser(user);
    await _firestore.updateLoginStreak(firebaseUser.uid);
    return user;
  }

  Future<bool> isOnboarded(String uid) async {
    final user = await _firestore.getUser(uid);
    return user?.isOnboarded ?? false;
  }

  Future<void> signOut() => _auth.signOut();

  Future<String> _generateUniqueQqId() async {
    for (var attempt = 0; attempt < 12; attempt++) {
      final id = UserModel.generateQqId();
      final exists = await _firestore.users
          .where('qqId', isEqualTo: id)
          .limit(1)
          .get()
          .then((snapshot) => snapshot.docs.isNotEmpty);
      if (!exists) return id;
    }
    throw StateError('QQ-ID генерациясы сәтсіз аяқталды');
  }
}

