import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';

import '../models/battle_model.dart';
import '../models/daily_quest_model.dart';
import '../models/question_model.dart';
import '../models/ranking_model.dart';
import '../models/shop_item_model.dart';
import '../models/user_model.dart';

// 🔹 QOSQANAT: Firebase repository
class FirestoreService {
  FirestoreService({
    FirebaseFirestore? firestore,
    FirebaseFunctions? functions,
  })  : _db = firestore ?? FirebaseFirestore.instance,
        _functions = functions ?? FirebaseFunctions.instance;

  final FirebaseFirestore _db;
  final FirebaseFunctions _functions;

  CollectionReference<UserModel> get users =>
      _db.collection('users').withConverter<UserModel>(
            fromFirestore: UserModel.fromFirestore,
            toFirestore: UserModel.toFirestore,
          );

  CollectionReference<QuestionModel> get questions =>
      _db.collection('questions').withConverter<QuestionModel>(
            fromFirestore: QuestionModel.fromFirestore,
            toFirestore: QuestionModel.toFirestore,
          );

  CollectionReference<BattleModel> get battles =>
      _db.collection('battles').withConverter<BattleModel>(
            fromFirestore: BattleModel.fromFirestore,
            toFirestore: BattleModel.toFirestore,
          );

  CollectionReference<ShopItemModel> get shopItems =>
      _db.collection('shop_items').withConverter<ShopItemModel>(
            fromFirestore: ShopItemModel.fromFirestore,
            toFirestore: ShopItemModel.toFirestore,
          );

  CollectionReference<Map<String, dynamic>> get rankings =>
      _db.collection('rankings');

  Future<UserModel?> getUser(String uid) async {
    final doc = await users.doc(uid).get();
    return doc.data();
  }

  Stream<UserModel?> watchUser(String uid) {
    return users.doc(uid).snapshots().map((snapshot) => snapshot.data());
  }

  Future<void> createUser(UserModel user) async {
    final batch = _db.batch();
    batch.set(users.doc(user.uid), user);
    batch.set(rankings.doc(user.uid), RankingModel.fromUser(user).toJson());
    for (final type in QuestType.values) {
      final quest = DailyQuestModel.seed(type);
      batch.set(_questDoc(user.uid, quest.id), quest.toJson());
    }
    await batch.commit();
  }

  Future<void> updateLoginStreak(String uid) async {
    await _db.runTransaction((transaction) async {
      final ref = users.doc(uid);
      final snapshot = await transaction.get(ref);
      final user = snapshot.data();
      if (user == null) return;
      final now = DateTime.now();
      final last = user.lastLogin;
      final nextStreak = last == null
          ? 1
          : _sameLocalDay(now, last)
              ? user.loginStreak
              : now.difference(last).inHours > 48
                  ? 1
                  : user.loginStreak + 1;
      transaction.update(ref, {
        'loginStreak': nextStreak,
        'lastLogin': Timestamp.fromDate(now),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      transaction.set(
        rankings.doc(uid),
        RankingModel.fromUser(user.copyWith(
          loginStreak: nextStreak,
          lastLogin: now,
          updatedAt: now,
        )).toJson(),
        SetOptions(merge: true),
      );
      if (nextStreak >= 3) {
        transaction.set(
          _questDoc(uid, QuestType.loginStreak3.name),
          {'currentValue': nextStreak},
          SetOptions(merge: true),
        );
      }
    });
    await ensureDailyQuests(uid);
  }

  Future<void> ensureDailyQuests(String uid) async {
    final batch = _db.batch();
    for (final type in QuestType.values) {
      final doc = _questDoc(uid, type.name);
      final snapshot = await doc.get();
      if (!snapshot.exists) {
        batch.set(doc, DailyQuestModel.seed(type).toJson());
      }
    }
    await batch.commit();
  }

  Stream<List<DailyQuestModel>> watchDailyQuests(String uid) {
    return users
        .doc(uid)
        .collection('daily_quests')
        .withConverter<DailyQuestModel>(
          fromFirestore: DailyQuestModel.fromFirestore,
          toFirestore: DailyQuestModel.toFirestore,
        )
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => doc.data()).toList());
  }

  Future<void> incrementQuest(String uid, QuestType type, {int by = 1}) async {
    await _questDoc(uid, type.name).set({
      'currentValue': FieldValue.increment(by),
    }, SetOptions(merge: true));
  }

  Future<void> claimQuest(String uid, DailyQuestModel quest) async {
    await _db.runTransaction((transaction) async {
      final questRef = _questDoc(uid, quest.id);
      final userRef = users.doc(uid);
      final fresh = await transaction.get(questRef);
      final model = DailyQuestModel.fromJson({
        ...?fresh.data(),
        'id': quest.id,
      });
      if (!model.canClaim) {
        throw FirebaseException(
          plugin: 'cloud_firestore',
          message: 'Квест әлі дайын емес',
        );
      }
      transaction.update(userRef, {
        'coin': FieldValue.increment(model.coinReward),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      transaction.update(questRef, {'isClaimed': true});
    });
  }

  Future<List<QuestionModel>> fetchLessonQuestions({
    required SubjectType subject,
    required int grade,
    required String topic,
    required int level,
  }) async {
    final difficulty = ((level - 1) % 3) + 1;
    final snapshot = await questions
        .where('subject', isEqualTo: subject.name)
        .where('grade', isEqualTo: grade)
        .where('topic', isEqualTo: topic)
        .where('difficulty', isEqualTo: difficulty)
        .limit(3)
        .get(const GetOptions(source: Source.serverAndCache));
    final items = snapshot.docs.map((doc) => doc.data()).toList();
    if (items.length >= 3) return items;
    return _sampleLessonQuestions(subject, grade, topic, difficulty);
  }

  Future<List<QuestionModel>> fetchQuestionsByIds(List<String> ids) async {
    if (ids.isEmpty) return const [];
    final result = <QuestionModel>[];
    for (var i = 0; i < ids.length; i += 10) {
      final chunk = ids.skip(i).take(10).toList(growable: false);
      final snapshot = await questions
          .where(FieldPath.documentId, whereIn: chunk)
          .get(const GetOptions(source: Source.serverAndCache));
      result.addAll(snapshot.docs.map((doc) => doc.data()));
    }
    final byId = {for (final question in result) question.id: question};
    return ids.map((id) => byId[id]).whereType<QuestionModel>().toList();
  }

  Future<void> addLearningReward(String uid, QuestionModel question) async {
    await users.doc(uid).update({
      'aqyl': FieldValue.increment(question.aqylReward),
      'exp': FieldValue.increment(question.expReward),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    await syncRankingForUser(uid);
  }

  Future<void> completeLesson({
    required String uid,
    required String lessonId,
    int coinBonus = 15,
  }) async {
    await _db.runTransaction((transaction) async {
      final ref = users.doc(uid);
      final snapshot = await transaction.get(ref);
      final user = snapshot.data();
      if (user == null || user.completedLessons.contains(lessonId)) return;
      transaction.update(ref, {
        'completedLessons': FieldValue.arrayUnion([lessonId]),
        'coin': FieldValue.increment(coinBonus),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      transaction.set(
        _questDoc(uid, QuestType.completeTasks7.name),
        {'currentValue': FieldValue.increment(1)},
        SetOptions(merge: true),
      );
    });
  }

  Future<String> createBattle({
    required String senderId,
    required String receiverId,
    required SubjectType subject,
    required int questionCount,
  }) async {
    if (!BattleModel.allowedQuestionCounts.contains(questionCount)) {
      throw ArgumentError('Сұрақ саны дұрыс емес');
    }
    final pool = await questions
        .where('subject', isEqualTo: subject.name)
        .limit(questionCount * 2)
        .get(const GetOptions(source: Source.server));
    final ids = pool.docs.map((doc) => doc.id).toList()..shuffle(Random());
    if (ids.length < questionCount) {
      throw FirebaseException(
        plugin: 'cloud_firestore',
        message: 'Бұл шайқасқа сұрақ жеткіліксіз',
      );
    }
    final doc = battles.doc();
    final battle = BattleModel.create(
      id: doc.id,
      senderId: senderId,
      receiverId: receiverId,
      subject: subject,
      questionCount: questionCount,
      questions: ids.take(questionCount).toList(growable: false),
    );
    await doc.set(battle);
    return doc.id;
  }

  Stream<List<BattleModel>> watchMyBattles(String uid) {
    return battles
        .where(
          Filter.or(
            Filter('senderId', isEqualTo: uid),
            Filter('receiverId', isEqualTo: uid),
          ),
        )
        .snapshots()
        .map((snapshot) {
      final items = snapshot.docs.map((doc) => doc.data()).toList();
      items.sort((a, b) {
        final left = a.completedAt ?? a.startedAt ?? DateTime(1970);
        final right = b.completedAt ?? b.startedAt ?? DateTime(1970);
        return right.compareTo(left);
      });
      return items;
    });
  }

  Stream<BattleModel?> watchBattle(String id) {
    return battles.doc(id).snapshots().map((snapshot) => snapshot.data());
  }

  Future<void> acceptBattle(String battleId) async {
    await battles.doc(battleId).update({
      'status': BattleStatus.in_progress.name,
      'startedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> declineBattle(String battleId) async {
    await battles.doc(battleId).update({'status': BattleStatus.declined.name});
  }

  Future<void> submitBattleAnswer({
    required BattleModel battle,
    required String uid,
    required String questionId,
    required String answer,
    required int durationMs,
  }) async {
    final field = uid == battle.senderId ? 'senderAnswers' : 'receiverAnswers';
    final payload = BattleAnswer(
      questionId: questionId,
      answer: answer,
      durationMs: durationMs,
      answeredAt: DateTime.now(),
    ).toJson(includeServerOnly: false);
    await battles.doc(battle.id).update({
      '$field.$questionId': payload,
      'status': BattleStatus.in_progress.name,
    });
  }

  Future<void> validateBattle(String battleId) async {
    final callable = _functions.httpsCallable('validateBattleAnswers');
    await callable.call({'battleId': battleId});
  }

  Stream<List<ShopItemModel>> watchShopItems() {
    return shopItems.where('isAvailable', isEqualTo: true).snapshots().map(
      (snapshot) {
        final items = snapshot.docs.map((doc) => doc.data()).toList();
        return items.isEmpty ? _sampleShopItems() : items;
      },
    );
  }

  Future<void> purchaseItem(String uid, ShopItemModel item) async {
    await _db.runTransaction((transaction) async {
      final ref = users.doc(uid);
      final snapshot = await transaction.get(ref);
      final user = snapshot.data();
      if (user == null) throw StateError('Пайдаланушы табылмады');
      if ((user.inventory[item.id] ?? false) == true) return;
      if (user.coin < item.price) throw StateError('Монета жеткіліксіз');
      transaction.update(ref, {
        'coin': FieldValue.increment(-item.price),
        'inventory.${item.id}': true,
        if (item.category == ShopCategory.pet) 'activePet': item.id,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      transaction.set(
        users.doc(uid).collection('refunds').doc(item.id),
        {
          'itemId': item.id,
          'price': item.price,
          'expiresAt': Timestamp.fromDate(
            DateTime.now().add(const Duration(minutes: 5)),
          ),
        },
      );
    });
  }

  Future<void> applyItem(String uid, ShopItemModel item) async {
    final field = switch (item.category) {
      ShopCategory.pet => 'activePet',
      ShopCategory.outfit => 'activeOutfit',
      ShopCategory.accessory => 'activeAccessory',
    };
    await users.doc(uid).update({
      field: item.id,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> refundItem(String uid, ShopItemModel item) async {
    await _db.runTransaction((transaction) async {
      final userRef = users.doc(uid);
      final refundRef = users.doc(uid).collection('refunds').doc(item.id);
      final refund = await transaction.get(refundRef);
      final data = refund.data();
      final expiresAt = data?['expiresAt'];
      final expiry = expiresAt is Timestamp ? expiresAt.toDate() : null;
      if (!refund.exists || expiry == null || DateTime.now().isAfter(expiry)) {
        throw StateError('Қайтару уақыты аяқталды');
      }
      transaction.update(userRef, {
        'coin': FieldValue.increment(data?['price'] ?? item.price),
        'inventory.${item.id}': FieldValue.delete(),
        if (item.category == ShopCategory.pet) 'activePet': FieldValue.delete(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      transaction.delete(refundRef);
    });
  }

  Stream<List<RankingModel>> watchGlobalRanking() {
    return rankings
        .orderBy('aqyl', descending: true)
        .orderBy('level', descending: true)
        .orderBy('lastActive', descending: true)
        .limit(50)
        .snapshots()
        .map(_rankingsFromSnapshot);
  }

  Stream<List<RankingModel>> watchSchoolRanking(String school) {
    return rankings
        .where('school', isEqualTo: school)
        .orderBy('aqyl', descending: true)
        .orderBy('level', descending: true)
        .orderBy('lastActive', descending: true)
        .limit(50)
        .snapshots()
        .map(_rankingsFromSnapshot);
  }

  Stream<List<RankingModel>> watchFriendRanking(List<String> friendIds) {
    if (friendIds.isEmpty) return Stream.value(const []);
    return rankings
        .where(FieldPath.documentId, whereIn: friendIds.take(10).toList())
        .snapshots()
        .map((snapshot) {
      final items = _rankingsFromSnapshot(snapshot);
      items.sort((a, b) {
        final byAqyl = b.aqyl.compareTo(a.aqyl);
        if (byAqyl != 0) return byAqyl;
        final byLevel = b.level.compareTo(a.level);
        if (byLevel != 0) return byLevel;
        return (b.lastActive ?? DateTime(1970))
            .compareTo(a.lastActive ?? DateTime(1970));
      });
      return items;
    });
  }

  Future<void> syncRankingForUser(String uid) async {
    final user = await getUser(uid);
    if (user == null) return;
    await rankings.doc(uid).set(RankingModel.fromUser(user).toJson());
  }

  DocumentReference<Map<String, dynamic>> _questDoc(String uid, String id) {
    return users.doc(uid).collection('daily_quests').doc(id);
  }

  bool _sameLocalDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  List<RankingModel> _rankingsFromSnapshot(
    QuerySnapshot<Map<String, dynamic>> snapshot,
  ) {
    return snapshot.docs
        .map((doc) => RankingModel.fromJson({...doc.data(), 'uid': doc.id}))
        .toList(growable: false);
  }

  List<QuestionModel> _sampleLessonQuestions(
    SubjectType subject,
    int grade,
    String topic,
    int difficulty,
  ) {
    final label = subject == SubjectType.math ? 'Математика' : 'Ағылшын';
    return List.generate(3, (index) {
      final number = index + 1;
      return QuestionModel(
        id: 'sample-${subject.name}-$grade-$topic-$difficulty-$number',
        subject: subject,
        grade: grade,
        topic: topic,
        difficulty: difficulty,
        type: QuestionType.multipleChoice,
        questionText: '$label: $topic бойынша $number-сұрақ',
        options: const ['A', 'B', 'C', 'D'],
        correctAnswer: 'A',
        explanation: 'Бұл демо сұрақ. Нақты сұрақтар Firestore-дан келеді.',
        aqylReward: 2,
        expReward: 15,
        timeLimitSec: 30,
      );
    });
  }

  List<ShopItemModel> _sampleShopItems() {
    return const [
      ShopItemModel(
        id: 'bektur_blue_cap',
        category: ShopCategory.accessory,
        name: 'Көк қалпақ',
        description: 'Бектұрға арналған жеңіл аксессуар.',
        price: 30,
        compatibleWith: [AssistantType.bektur],
        assetPath: 'assets/shop/bektur_blue_cap.png',
        isAvailable: true,
      ),
      ShopItemModel(
        id: 'nazym_star_pin',
        category: ShopCategory.accessory,
        name: 'Жұлдыз белгі',
        description: 'Назымға арналған жарқын белгі.',
        price: 30,
        compatibleWith: [AssistantType.nazym],
        assetPath: 'assets/shop/nazym_star_pin.png',
        isAvailable: true,
      ),
      ShopItemModel(
        id: 'samuryq_pet',
        category: ShopCategory.pet,
        name: 'Самұрық',
        description: 'Сенімен бірге оқитын қанатты дос.',
        price: 75,
        compatibleWith: [AssistantType.bektur, AssistantType.nazym],
        assetPath: 'assets/shop/samuryq_pet.png',
        isAvailable: true,
      ),
    ];
  }
}
