import 'dart:convert';

import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/question_model.dart';

// 🔹 QOSQANAT: offline lesson cache
class LocalCacheService {
  LocalCacheService._(this._box, this._prefs);

  final Box<String> _box;
  final SharedPreferences _prefs;

  static const _boxName = 'qosqanat_lesson_cache';

  static Future<LocalCacheService> init() async {
    await Hive.initFlutter();
    final box = await Hive.openBox<String>(_boxName);
    final prefs = await SharedPreferences.getInstance();
    return LocalCacheService._(box, prefs);
  }

  Future<void> cacheLesson({
    required SubjectType subject,
    required int grade,
    required String topic,
    required int level,
    required List<QuestionModel> questions,
  }) async {
    final key = lessonKey(subject: subject, grade: grade, topic: topic, level: level);
    final payload = questions
        .map((question) => {'id': question.id, ...question.toJson()})
        .toList(growable: false);
    await _box.put(key, jsonEncode(payload));
    await _prefs.setString('last_cached_lesson', key);
    await _prefs.setString('last_cached_at', DateTime.now().toIso8601String());
  }

  String? get lastCachedLesson => _prefs.getString('last_cached_lesson');

  Future<List<QuestionModel>> readLesson({
    required SubjectType subject,
    required int grade,
    required String topic,
    required int level,
  }) async {
    final raw = _box.get(
      lessonKey(subject: subject, grade: grade, topic: topic, level: level),
    );
    if (raw == null) return const [];
    final decoded = jsonDecode(raw);
    if (decoded is! List) return const [];
    return decoded
        .whereType<Map>()
        .map((item) => QuestionModel.fromJson(Map<String, dynamic>.from(item)))
        .toList(growable: false);
  }

  static String lessonKey({
    required SubjectType subject,
    required int grade,
    required String topic,
    required int level,
  }) {
    return '${subject.name}|$grade|$topic|$level';
  }
}
