# QosQanat - Claude Code Instructions

## Project Overview
QosQanat is a gamified educational mobile app for Kazakh school students (grades 5-11).
Built with Expo React Native + TypeScript + Supabase.

## Tech Stack
- Expo SDK 56 + React Native 0.85 + React 19 (TypeScript ONLY - never use .js files)
- React Navigation 7 (native stack + bottom tabs)
- Zustand 5 (state management - no Redux, no Context API for global state)
- Supabase (backend, auth, realtime, storage)
- React Native Reanimated 4 (ALL animations - never use Animated API)
- React Native SVG (avatar system)
- Expo Linear Gradient (gradients)
- Expo Speech (TTS for voice assistant)

## Tooling & Quality Gates (run before every commit)
- `npm run typecheck` — `tsc --noEmit`, strict mode, must pass with zero errors
- `npm run lint` — ESLint 9 flat config (strict-type-checked). Zero errors required;
  warnings are tracked tech debt (color literals, React Compiler rules)
- `npm run format` — Prettier (single quotes, trailing commas, width 100)
- `npm run check` — runs all three; this is the gate CI enforces
- Reanimated 4: `runOnJS` is deprecated — use `scheduleOnRN` from `react-native-worklets`

## Code Quality Rules
- ALWAYS use TypeScript with strict types - never use 'any'
- ALWAYS use functional components with hooks - never class components
- ALWAYS use async/await - never .then().catch() chains
- ALWAYS handle loading and error states
- ALWAYS add try/catch to all async operations
- NEVER use inline styles - always use StyleSheet.create()
- NEVER hardcode colors - always import from src/theme/colors.ts
- NEVER hardcode strings - use Kazakh language variables

## Folder Structure Rules
- screens/ = full page components only
- components/ = reusable UI components
- store/ = Zustand stores only
- services/ = API calls and external services
- data/ = static data and constants
- hooks/ = custom React hooks
- utils/ = pure utility functions

## Component Pattern - ALWAYS follow this:
```typescript
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '@/theme/colors';

interface Props {
  // always define props interface
}

const ComponentName: React.FC<Props> = ({ prop1, prop2 }) => {
  return (
    <View style={styles.container}>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    // styles here
  },
});

export default ComponentName;
```

## Navigation Pattern
- Use typed navigation params always
- Stack screens use NativeStackScreenProps
- Tab screens use BottomTabScreenProps

## Supabase Rules
- ALL database calls go in src/services/api.ts
- NEVER call Supabase directly from components
- Always use Row Level Security
- Always handle Supabase errors properly

## State Management Rules
- User data: userStore.ts
- Game data (XP, coins, level): gameStore.ts
- Use shallow comparison in selectors

## Animation Rules
- Use useSharedValue, useAnimatedStyle from Reanimated 4
- Spring animations for interactive elements
- Timing animations for transitions
- NEVER use setTimeout for animations
- To call JS from a worklet use `scheduleOnRN` (react-native-worklets), NOT `runOnJS`

## Design System Rules
- Primary: #4A6CF7
- Secondary: #7B61FF
- Gold: #FFD700
- Success: #00C48C
- Danger: #FF4757
- Border radius: 12 (small), 16 (medium), 20 (large), 30 (xl)
- Spacing: 8, 12, 16, 20, 24, 32

## Kazakh Language Rules
- ALL UI text must be in Kazakh
- Buttons: "Жалғастыру", "Болдырмау", "Дайын", "Таңдау"
- Error messages in Kazakh
- Loading text: "Жүктелуде..."

## Performance Rules
- Use React.memo for list items
- Use useCallback for functions passed as props
- Use FlatList instead of ScrollView for long lists
- Lazy load screens with React.lazy

## File Naming
- Components: PascalCase (HomeScreen.tsx)
- Hooks: camelCase starting with use (useGameStore.ts)
- Utils: camelCase (formatNumber.ts)
- Constants: UPPER_CASE

## What NOT to do
- Never use Class components
- Never use Redux or MobX
- Never use Animated API (use Reanimated 3)
- Never hardcode text strings
- Never use 'any' TypeScript type
- Never write business logic in components
- Never call API directly from UI components
