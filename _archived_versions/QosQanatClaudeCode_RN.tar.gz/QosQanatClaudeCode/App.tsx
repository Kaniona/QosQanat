import { NavigationContainer } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import GlobalLevelUp from '@/components/Game/GlobalLevelUp';
import ErrorBoundary from '@/components/UI/ErrorBoundary';
import RootNavigator, { useRootBootstrap } from '@/navigation/RootNavigator';

// ----------------------------------------------------------------------------
// App — composition root.
//
// Order of providers (top-down):
//   1. GestureHandlerRootView — required for react-native-gesture-handler.
//   2. SafeAreaProvider        — feeds `useSafeAreaInsets()`.
//   3. ErrorBoundary           — catches render errors below it.
//   4. NavigationContainer     — React Navigation root.
//   5. RootNavigator           — auth-gated router (Auth ↔ Main).
//   6. GlobalLevelUp           — modal overlay that fires whenever the player
//                                 levels up, regardless of which screen
//                                 they're on.
// ----------------------------------------------------------------------------

const App: React.FC = () => {
  // useRootBootstrap loads the session + hydrates settings (which includes
  // the `onboarded` flag) before flipping `ready` to true.
  const { ready } = useRootBootstrap();

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <ErrorBoundary>
          <NavigationContainer>
            <RootNavigator ready={ready} />
            <GlobalLevelUp />
          </NavigationContainer>
          <StatusBar style="light" />
        </ErrorBoundary>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
};

export default App;
