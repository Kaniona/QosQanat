# QosQanat

> A gamified educational mobile app for Kazakh school students (grades 5–11).
> Learn by completing quests, defeating bosses, dueling friends in real-time
> battles, and customising a 2-D avatar — all in Kazakh.

Built with **Expo SDK 56 + React Native 0.85**, **TypeScript** (strict),
**Supabase** (auth, realtime, RLS), **Zustand**, **React Navigation 7**,
**Reanimated 3**, **expo-speech**, and **react-native-svg**.

---

## Features

### Core learning loop
- **5 subjects** seeded from `src/data/curriculum.ts`: Mathematics, Kazakh,
  English, Physics, Informatics — each with one or more grade-organised
  modules of 8-14 lesson/quiz/boss/treasure nodes.
- **4 question types**: multiple-choice, true/false, fill-in-the-blank,
  match-pairs. All content in Kazakh.
- **XP / coins / akyl points** per node, with first-clear vs replay distinction.
- **Animated learning map** with locked / available / completed / mastered
  node states and a path-walking avatar.

### Avatars + shop
- **Two assistants** — Бектұр (boy, blue) and Назым (girl, pink) — rendered
  with `react-native-svg`, blink + idle micro-animations, action presets
  for `idle | celebrate | sad | thinking`.
- **50+ shop items** across 5 categories (top/bottom/hat/accessory/pet),
  with rarity tiers (common/rare/epic/legendary), level locks, and a
  3-D swipe-to-rotate avatar preview.

### Multiplayer battles
- **Akyl Battle**: realtime 1-v-1 quiz duel via Supabase Realtime
  (broadcast pings + Postgres-change row updates), 15/20/25/40/50 question
  modes, optional subject filter, 10-second per-question timer, animated
  scoreboard, win/lose/tie result screen with confetti + animated rewards.

### Social
- **Friends** with QQ-XXXXXXXXX IDs, search-by-id, accept/decline requests,
  online-presence indicators (Supabase Presence channel).
- **Leaderboards** in 4 scopes — Global / City / School / Friends — with a
  podium for the top 3 and rank-delta indicators. School scope unlocks at
  ≥10 enrolled users.

### Daily engagement
- **3 rotating daily quests** per day, deterministic per-day slate, claim
  flow with flying-reward chips.
- **Streak tracker** with milestone bonuses, longest-streak persistence.
- **Achievements** — 30 unlockables across 6 categories, evaluated against
  a metrics snapshot on every relevant action.

### Profile
- Hero gradient avatar (tap to spin + sparkle), 24px name, tap-to-copy QQ-ID,
  level badge + animated XP bar.
- 2×3 stats grid: akyl / coins / friends / longest streak / tasks
  completed / battles (W/L).
- Achievement grid with locked "???" placeholders.
- GitHub-style 119-day activity heatmap fed by `task_progress` + `battles`.
- Last 5 completed battles.

### Voice assistant
- **TTS** via `expo-speech` (`kk-KZ`, pitch 1.1 for Bektur, 1.3 for Nazym).
- **STT** via `@react-native-voice/voice` (optional, needs a dev build —
  gracefully unavailable on Expo Go, falling back to tap-to-simulate chips).
- Kazakh command catalog: navigation (`басты бет`, `сабақ`, `дүкен`…),
  info (`деңгейім қанша`, `монетам`, `ақыл ұпайым`…), external app launches
  (`youtube аш`, `whatsapp аш`…) and an AI-placeholder fallback.
- Pulsing FAB on Home → semi-transparent overlay with glowing avatar,
  bouncing waveform, live transcript, response speech bubble, lip-sync pip,
  7-second timeout.

### Settings
- Language (ҚАЗ/РУС), sound, vibration, animations, dark-mode toggles.
- Per-type notification preferences + streak-reminder hour picker.
- Account section (edit profile, change assistant w/ 30-day lock, QQ-ID).
- About section (version, T&C, privacy, support@qosqanat.kz).
- Persisted in `AsyncStorage` via `useSettingsStore` (Zustand).

### App-wide polish
- Custom bottom tab bar (`QTabBar`) — 5 tabs, raised middle Shop button,
  animated active-tab scale + gold accent, Friends notification badge,
  rounded top corners + shadow.
- Global `LevelUpModal` overlay fires automatically whenever `gameStore.addXP`
  crosses a level boundary, anywhere in the app.
- 8-step onboarding spotlight tour after first assistant selection, with
  a +100 welcome-coin bonus on completion.
- `ErrorBoundary` at the root catches render errors and shows a Kazakh
  fallback with a "Retry" button instead of a white screen.

---

## Project layout

```
App.tsx                        ← composition root
app.json                       ← Expo config (name, bundle ids, mic permissions)
SUPABASE_SETUP.sql             ← idempotent schema + RLS + RPCs (run once)
src/
  components/
    Avatar/                    ← AvatarBase, AvatarDisplay, expressions, selector
    Game/                      ← XPBar, AnimatedCounter, RewardToast, LevelUpModal, GlobalLevelUp
    Quest/                     ← QuestCard
    UI/                        ← QTabBar, ErrorBoundary
    VoiceButton.tsx            ← FAB + voice overlay
  config/voiceCommands.ts      ← Kazakh command catalog + matcher
  data/                        ← achievements, avatarItems, cities, curriculum,
                                  levels, quests, shopItems
  navigation/
    types.ts                   ← AuthFlow / MainTab / MainStack / union param types
    AuthNavigator.tsx          ← Splash → Welcome → Register → AssistantSelect → Onboarding
    MainNavigator.tsx          ← Home | Learn | Shop | Friends | Profile tabs
    RootNavigator.tsx          ← auth gate + modal stack + bootstrap hook
  screens/
    Auth/                      ← Splash, Welcome, Register, AssistantSelect, Onboarding
    main/                      ← Home, Shop, Friends*, Profile* (* stubs replaced by feature screens)
    learn/                     ← LearnScreen, MapScreen, TaskScreen, ResultScreen, task types
    Friends/, Battle/,         ← real feature screens (Battle Setup/Waiting/Battle/Result)
    Rating/, Profile/          ← Rating, Profile, Settings
  services/
    supabase.ts                ← Supabase client (reads `extra.supabaseUrl` / `anonKey`)
    auth.ts                    ← register, setAssistant, signOut, loadSessionUser
    api.ts                     ← every other Supabase RPC + table call
    voice.ts                   ← TTS + STT + intent dispatcher + AI placeholder
  store/
    userStore.ts               ← profile (Zustand)
    gameStore.ts               ← economy + level-up event (Zustand)
    settingsStore.ts           ← prefs + onboarded flag (Zustand + AsyncStorage)
  theme/                       ← colors, spacing, typography
  utils/                       ← phoneFormat, validation
  types/                       ← shared TS types (User, ShopItem, etc.)
```

---

## Setup

### 1. Prerequisites
- Node 20+, Yarn or npm.
- Expo CLI (`npx expo` works without a global install).
- A Supabase project.

### 2. Install dependencies
```bash
npm install
```

### 3. Configure Supabase
1. Create a Supabase project at <https://supabase.com>.
2. Open the SQL editor and **run the full `SUPABASE_SETUP.sql`** at the
   repo root — it creates all tables, indices, RLS policies, and the
   `generate_qosqanat_id`, `search_user_by_qq_id`, friend-request RPCs,
   `send_battle_notification`, `get_leaderboard`, and
   `count_users_at_my_school` SECURITY DEFINER functions.
3. In **Database → Replication**, enable Realtime for `battles` and
   `friendships` (used by realtime subscriptions).
4. In **Authentication → Providers**, leave Email enabled. The app uses
   phone-derived synthetic emails (`<canonical-phone>@qosqanat.app`) +
   the IIN as the password.
5. Copy the project URL and anon key into `app.json`:
   ```json
   "extra": {
     "supabaseUrl": "https://YOUR-PROJECT.supabase.co",
     "supabaseAnonKey": "ey…"
   }
   ```

### 4. Run the app
```bash
npx expo start
```
Then press `i` (iOS simulator), `a` (Android emulator), or scan the QR
code with Expo Go.

> **For real STT (microphone listening)** install
> `@react-native-voice/voice` + `expo-dev-client` and rebuild
> (`npx expo run:ios` / `:android`). On Expo Go without the dev build,
> the overlay will display *"Дауысты тану үшін арнайы dev-build керек"*
> and only the tap-to-simulate command chips work.

### 5. Verify
```bash
npx tsc --noEmit
```
should report no errors.

---

## Architecture notes

- **State is split by domain**: `userStore` (profile), `gameStore`
  (economy + level-up events), `settingsStore` (client prefs +
  onboarded flag).
- **All Supabase calls live in `src/services`**. Components never
  import `supabase` directly.
- **RLS is on for every table**. Cross-user queries (search, leaderboard,
  friend-requests, battle notifications) go through SECURITY DEFINER
  RPCs that project safe public fields.
- **Realtime battles**: each player only writes to their own jsonb column
  (`challenger_answers`/`opponent_answers` + matching score), so
  concurrent writes don't collide. Broadcast pings on
  `battle:<id>` give sub-second visual feedback; postgres-changes is the
  authoritative confirmation.
- **Navigation**: `RootNavigator` swaps between `AuthNavigator` and the
  main stack based on `userStore.isAuthenticated && settingsStore.onboarded`.
  All screens import a flat `AuthStackParamList` union for nav typing.

---

## Known limitations

- **No microphone STT on Expo Go.** Mocked via clickable command chips in
  the overlay. Needs a dev build with `@react-native-voice/voice`.
- **No clipboard library.** Tap-to-copy on the QQ-ID shows the
  *"Көшірілді!"* toast but doesn't actually copy. Add `expo-clipboard`
  and call `Clipboard.setStringAsync(qqId)` to wire it up.
- **AI assistant returns a placeholder reply.** Plug in the Anthropic
  API in `aiRespond()` (`src/services/voice.ts`) when an API key is
  added.
- **Push notifications are inserted to the `notifications` table** via
  `send_battle_notification` RPC; no Expo Push or APNs hook is wired
  yet, so users only see them in-app.
- **Assistant-change 30-day lock** uses the `updated_at` column as a
  proxy. Adding a dedicated `assistant_changed_at` column gives a
  precise lock.
- **No social login** (Google/Apple). Phone + IIN only.
- **`expo-linking` not installed** — `Linking` from `react-native` is
  used directly. Most schemes (whatsapp://, instagram://, tiktok://,
  tg://) work on real devices; `camera://` and `calculator://` are
  best-effort and may show a fallback Kazakh hint when the OS can't
  open them.

---

## Assets that need to be provided

The repo references the following paths in `app.json` and elsewhere:

- `assets/icon.png` — app icon, 1024×1024 PNG.
- `assets/splash-icon.png` — splash centerpiece on `#1A1A4E` background.
- `assets/android-icon-foreground.png`, `…-background.png`,
  `…-monochrome.png` — Android adaptive icon layers.
- `assets/favicon.png` — web favicon.

The avatars and characters are **drawn entirely in SVG**
(`src/components/Avatar/*`) — there are no avatar PNGs to ship.

---

## Scripts

```bash
npm run start       # Expo dev server
npm run ios         # build + run on iOS simulator
npm run android     # build + run on Android emulator
npm run web         # web preview
npx tsc --noEmit    # type check (zero errors expected)
```

---

## Support

`support@qosqanat.kz`
