export const colors = {
  primary: '#4A6CF7',
  secondary: '#7B61FF',
  gold: '#FFD700',
  success: '#00C48C',
  danger: '#FF4757',
  warning: '#FFA502',
  background: '#F8F9FF',
  white: '#FFFFFF',
  text: '#1A1A4E',
  textLight: '#9CA3AF',
  border: '#E8ECFF',
  bekturColor: '#4A6CF7',
  nazymColor: '#FF6B9D',
} as const;

export type ColorName = keyof typeof colors;
