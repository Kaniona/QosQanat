// ----------------------------------------------------------------------------
// Voice command registry — Kazakh-language patterns mapped to intents.
//
// The voice service normalises the recognised text (lower-case, trim, strip
// punctuation) and then walks this list in order. The first definition whose
// `patterns` includes a substring of the utterance wins. If nothing matches,
// the caller treats the utterance as an open-ended question for the AI
// placeholder (intent `ai_query`).
// ----------------------------------------------------------------------------

import type { AuthStackParamList } from '@/navigation/types';

// Subset of routes the voice assistant can navigate to. We intentionally do
// not allow navigating into mid-flow screens (Task/Result/Battle*) — those
// need typed params the assistant cannot reasonably infer.
export type VoiceRoute = Extract<
  keyof AuthStackParamList,
  'Main' | 'Learn' | 'Friends' | 'Rating' | 'Profile' | 'Settings'
>;

// ---- Intent shapes ---------------------------------------------------------

export type VoiceIntent =
  | { kind: 'navigation'; route: VoiceRoute; responseKz: string }
  | { kind: 'info'; infoKey: InfoKey; responseTemplateKz: string }
  | { kind: 'external'; url: string; responseKz: string }
  | { kind: 'unknown'; rawText: string } // → caller hands off to ai_query
  | { kind: 'ai_query'; rawText: string };

export type InfoKey = 'level' | 'coins' | 'akyl' | 'streak' | 'friends_count';

// Public command definition — a label, matching patterns, and a builder that
// produces an Intent. Splitting the resolver from the static data lets the UI
// list available phrases on a "what can I say?" screen without invoking them.
export interface VoiceCommand {
  id: string;
  // First pattern is treated as the canonical phrasing for help text.
  patterns: readonly string[];
  build: () => VoiceIntent;
}

// ---- Templates -------------------------------------------------------------
//
// `{N}` / `{M}` placeholders are filled in by the voice service after the
// intent is matched. The TTS layer never reads raw braces.
//
// `responseKz` on navigation/external intents is a fixed line spoken before
// the action — e.g. "Үй экранына өтемін.".

const NAV_COMMANDS: readonly VoiceCommand[] = [
  {
    id: 'nav_home',
    patterns: ['басты бет', 'үй', 'үйге', 'басты'],
    build: () => ({
      kind: 'navigation',
      route: 'Main',
      responseKz: 'Үй экранына өтемін.',
    }),
  },
  {
    id: 'nav_learn',
    patterns: ['сабақ', 'оқу', 'карта', 'сабаққа', 'оқуға'],
    build: () => ({
      kind: 'navigation',
      route: 'Learn',
      responseKz: 'Сабақтар бөліміне өтемін.',
    }),
  },
  {
    id: 'nav_shop',
    patterns: ['дүкен', 'дүкенге', 'киім дүкені'],
    // Shop currently lives at screens/main/ShopScreen and is reached via the
    // tab bar from Main. Until we add it as a separate stack route we re-use
    // Main and let the user tap the Shop tab.
    build: () => ({
      kind: 'navigation',
      route: 'Main',
      responseKz: 'Дүкен бөліміне өтемін. Төменгі тақтадан таңдаңыз.',
    }),
  },
  {
    id: 'nav_friends',
    patterns: ['достар', 'дос', 'достарым'],
    build: () => ({
      kind: 'navigation',
      route: 'Friends',
      responseKz: 'Достар бөліміне өтемін.',
    }),
  },
  {
    id: 'nav_rating',
    patterns: ['рейтинг', 'рейтингке', 'көшбасшы', 'лидерборд'],
    build: () => ({
      kind: 'navigation',
      route: 'Rating',
      responseKz: 'Рейтингке өтемін.',
    }),
  },
  {
    id: 'nav_profile',
    patterns: ['профиль', 'профильге', 'менің профилім'],
    build: () => ({
      kind: 'navigation',
      route: 'Profile',
      responseKz: 'Профиль бөліміне өтемін.',
    }),
  },
  {
    id: 'nav_settings',
    patterns: ['баптау', 'баптаулар', 'настройка'],
    build: () => ({
      kind: 'navigation',
      route: 'Settings',
      responseKz: 'Баптаулар бөліміне өтемін.',
    }),
  },
];

// Info intents read state directly — the voice service handles the
// template substitution against gameStore / userStore / leaderboard data.
const INFO_COMMANDS: readonly VoiceCommand[] = [
  {
    id: 'info_level',
    patterns: ['деңгейім қанша', 'деңгейім', 'қандай деңгейім', 'қандай деңгеймін'],
    build: () => ({
      kind: 'info',
      infoKey: 'level',
      responseTemplateKz: 'Сіздің деңгейіңіз {N}.',
    }),
  },
  {
    id: 'info_coins',
    patterns: ['монетам қанша', 'тиынным', 'қанша монета', 'қанша тиын'],
    build: () => ({
      kind: 'info',
      infoKey: 'coins',
      responseTemplateKz: 'Сізде {N} монета бар.',
    }),
  },
  {
    id: 'info_akyl',
    patterns: ['ақыл ұпайым', 'ақылым қанша', 'қанша ақыл', 'ұпайым'],
    build: () => ({
      kind: 'info',
      infoKey: 'akyl',
      // The {M} placeholder is filled in only if the caller resolved the
      // user's global rank; otherwise the trailing clause is stripped.
      responseTemplateKz: 'Ақыл ұпайыңыз {N}, рейтингте {M}-орындасыз.',
    }),
  },
  {
    id: 'info_streak',
    patterns: ['стригім', 'серия', 'қанша күн', 'streak', 'неше күн'],
    build: () => ({
      kind: 'info',
      infoKey: 'streak',
      responseTemplateKz: 'Сіз {N} күн қатарынан кіріп тұрсыз. Жалғастырыңыз!',
    }),
  },
  {
    id: 'info_friends',
    patterns: ['қанша досым', 'дос саным', 'неше досым'],
    build: () => ({
      kind: 'info',
      infoKey: 'friends_count',
      responseTemplateKz: 'Сізде {N} дос бар.',
    }),
  },
];

// External — opens via Linking. URL schemes degrade to web URLs on platforms
// where the app isn't installed; the responseKz line plays while the OS opens
// the target.
const EXTERNAL_COMMANDS: readonly VoiceCommand[] = [
  {
    id: 'ext_youtube',
    patterns: ['youtube аш', 'ютуб аш', 'youtube', 'ютуб'],
    build: () => ({
      kind: 'external',
      url: 'https://www.youtube.com/',
      responseKz: 'YouTube ашамын.',
    }),
  },
  {
    id: 'ext_whatsapp',
    patterns: ['whatsapp аш', 'ватсап аш', 'ватсап', 'whatsapp'],
    build: () => ({
      kind: 'external',
      url: 'whatsapp://send',
      responseKz: 'WhatsApp ашамын.',
    }),
  },
  {
    id: 'ext_instagram',
    patterns: ['instagram аш', 'инстаграм аш', 'инстаграм', 'instagram'],
    build: () => ({
      kind: 'external',
      url: 'instagram://app',
      responseKz: 'Instagram ашамын.',
    }),
  },
  {
    id: 'ext_tiktok',
    patterns: ['tiktok аш', 'тикток аш', 'тикток', 'tiktok'],
    build: () => ({
      kind: 'external',
      url: 'tiktok://',
      responseKz: 'TikTok ашамын.',
    }),
  },
  {
    id: 'ext_telegram',
    patterns: ['telegram аш', 'телеграм аш', 'телеграм', 'telegram'],
    build: () => ({
      kind: 'external',
      url: 'tg://',
      responseKz: 'Telegram ашамын.',
    }),
  },
  {
    id: 'ext_camera',
    patterns: ['камера аш', 'камера', 'фото түсір', 'сурет түсір'],
    // No universal camera scheme; Android uses an action intent. We fall back
    // to the "camera" scheme which most launchers redirect; the voice layer
    // shows a friendly "open camera manually" if Linking can't open it.
    build: () => ({
      kind: 'external',
      url: 'camera://',
      responseKz: 'Камераны ашайын.',
    }),
  },
  {
    id: 'ext_calculator',
    patterns: ['калькулятор аш', 'калькулятор', 'есеп'],
    build: () => ({
      kind: 'external',
      url: 'calculator://',
      responseKz: 'Калькуляторды ашайын.',
    }),
  },
];

export const VOICE_COMMANDS: readonly VoiceCommand[] = [
  ...NAV_COMMANDS,
  ...INFO_COMMANDS,
  ...EXTERNAL_COMMANDS,
];

// ----------------------------------------------------------------------------
// Help / suggestion list — surfaced in the overlay so the user knows what to
// try. We keep just the canonical phrasing of each command, grouped by intent.
// ----------------------------------------------------------------------------

export interface VoiceHelpGroup {
  titleKz: string;
  examples: readonly string[];
}

export const VOICE_HELP: readonly VoiceHelpGroup[] = [
  {
    titleKz: 'Навигация',
    examples: NAV_COMMANDS.map((c) => c.patterns[0]),
  },
  {
    titleKz: 'Деректер',
    examples: INFO_COMMANDS.map((c) => c.patterns[0]),
  },
  {
    titleKz: 'Сыртқы',
    examples: EXTERNAL_COMMANDS.map((c) => c.patterns[0]),
  },
];

// ----------------------------------------------------------------------------
// Matcher
// ----------------------------------------------------------------------------

// Strip punctuation, collapse whitespace, lower-case (Kazakh letters survive
// because String.prototype.toLowerCase is unicode-aware in JS engines).
export const normaliseUtterance = (raw: string): string =>
  raw
    .toLowerCase()
    .replace(/[!?,.;:"`'«»()[\]{}]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

export const matchCommand = (utterance: string): VoiceIntent => {
  const text = normaliseUtterance(utterance);
  if (!text) return { kind: 'unknown', rawText: utterance };
  for (const cmd of VOICE_COMMANDS) {
    for (const p of cmd.patterns) {
      const pn = normaliseUtterance(p);
      if (text === pn || text.includes(pn)) return cmd.build();
    }
  }
  return { kind: 'ai_query', rawText: utterance };
};
