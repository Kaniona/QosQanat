import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type ListRenderItem,
} from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AvatarDisplay from '@/components/Avatar/AvatarDisplay';
import type { AuthStackParamList } from '@/navigation/types';
import {
  acceptFriendRequest,
  cancelFriendRequest,
  declineFriendRequest,
  getFriends,
  getIncomingFriendRequests,
  getOutgoingFriendRequests,
  removeFriend,
  searchUserById,
  sendFriendRequest,
  subscribeOnlinePresence,
  type FriendEntry,
  type FriendRequestEntry,
  type PublicUserProfile,
} from '@/services/api';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import type { AssistantType } from '@/types';

type Nav = NativeStackNavigationProp<AuthStackParamList>;

type TabKey = 'friends' | 'requests' | 'search';
type SortKey = 'recent' | 'level' | 'akyl' | 'name';

const KZ = {
  title: '👥 Достар',
  tabFriends: 'Достарым',
  tabRequests: 'Өтінімдер',
  tabSearch: 'Іздеу',
  searchPlaceholder: 'QQ-XXXXXXXXX',
  searchBtn: '🔎 Іздеу',
  searchHint: 'Дос ID-і — QQ-XXXXXXXXX форматында.',
  searching: 'Іздеу...',
  notFound: 'Бұндай ID табылмады.',
  selfNotice: 'Бұл сіздің ID-іңіз 🙂',
  alreadyFriend: 'Сіз бұл оқушымен достасасыз.',
  add: 'Дос қос +',
  added: 'Өтінім жіберілді ✓',
  empty: 'Тізім бос.',
  emptyRequests: 'Өтінімдер жоқ.',
  emptyFriends: 'Әзірге достарыңыз жоқ. ID арқылы іздеп қосыңыз!',
  incoming: 'Кірген өтінімдер',
  outgoing: 'Жіберілген өтінімдер',
  accept: 'Қабылдау ✓',
  decline: 'Бас тарту ✕',
  cancel: 'Өтінімді алу',
  battle: '⚔️ Батлға шақыр',
  profile: 'Профиль 👤',
  remove: 'Достан шығару',
  online: 'желіде',
  offline: 'желіден тыс',
  sortLabel: 'Сұрыптау:',
  sortRecent: 'Жаңалары',
  sortLevel: 'Деңгей',
  sortAkyl: 'Ақыл',
  sortName: 'Аты',
  level: (n: number) => `Деңгей ${n}`,
  akyl: (n: number) => `${n} 🔮`,
  loadFailed: 'Деректерді жүктеу мүмкін болмады.',
  confirmRemove: 'Достан шығарасыз ба?',
  confirmRemoveBody: 'Бұл әрекетті қайтару мүмкін емес.',
  yes: 'Иә',
  no: 'Болдырмау',
  back: '← Артқа',
};

// ----------------------------------------------------------------------------
// Tab pill
// ----------------------------------------------------------------------------

interface TabProps {
  label: string;
  active: boolean;
  badge?: number;
  onPress: () => void;
}

const Tab: React.FC<TabProps> = ({ label, active, badge, onPress }) => {
  const scale = useSharedValue(1);
  useEffect(() => {
    scale.value = withSpring(active ? 1 : 0.97, { damping: 14, stiffness: 220 });
  }, [active, scale]);
  const animStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Pressable onPress={onPress} style={styles.tabWrap}>
      <Animated.View style={[styles.tab, active && styles.tabActive, animStyle]}>
        <Text style={[styles.tabText, active && styles.tabTextActive]}>{label}</Text>
        {badge && badge > 0 ? (
          <View style={styles.tabBadge}>
            <Text style={styles.tabBadgeText}>{badge}</Text>
          </View>
        ) : null}
      </Animated.View>
    </Pressable>
  );
};

// ----------------------------------------------------------------------------
// Friend card
// ----------------------------------------------------------------------------

interface FriendCardProps {
  friend: FriendEntry;
  online: boolean;
  onBattle: () => void;
  onProfile: () => void;
  onRemove: () => void;
}

const assistantOrDefault = (t: AssistantType | null): AssistantType => t ?? 'bektur';

const FriendCard: React.FC<FriendCardProps> = React.memo(
  ({ friend, online, onBattle, onProfile, onRemove }) => (
    <View style={styles.card}>
      <View style={styles.cardRow}>
        <View style={styles.avatarBox}>
          <AvatarDisplay
            assistantType={assistantOrDefault(friend.assistant_type)}
            action="idle"
            size={64}
          />
          <View style={[styles.onlineDot, { backgroundColor: online ? colors.success : '#666' }]} />
        </View>
        <View style={styles.cardMeta}>
          <Text style={styles.cardName} numberOfLines={1}>
            {friend.full_name}
          </Text>
          <Text style={styles.cardSub} numberOfLines={1}>
            {friend.qosqanat_id} · {online ? KZ.online : KZ.offline}
          </Text>
          <View style={styles.cardStats}>
            <View style={styles.statChip}>
              <Text style={styles.statChipText}>⭐ {KZ.level(friend.level)}</Text>
            </View>
            <View style={[styles.statChip, { backgroundColor: 'rgba(123,97,255,0.18)' }]}>
              <Text style={[styles.statChipText, { color: colors.secondary }]}>
                {KZ.akyl(friend.akyl_points)}
              </Text>
            </View>
          </View>
        </View>
      </View>
      <View style={styles.cardActions}>
        <Pressable style={[styles.primaryBtn, styles.battleBtn]} onPress={onBattle}>
          <LinearGradient
            colors={[colors.danger, '#FF8C5A'] as readonly [string, string]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <Text style={styles.primaryBtnText}>{KZ.battle}</Text>
        </Pressable>
        <Pressable style={styles.secondaryBtn} onPress={onProfile}>
          <Text style={styles.secondaryBtnText}>{KZ.profile}</Text>
        </Pressable>
      </View>
      <Pressable onPress={onRemove} hitSlop={8} style={styles.removeBtn}>
        <Text style={styles.removeBtnText}>{KZ.remove}</Text>
      </Pressable>
    </View>
  ),
);

// ----------------------------------------------------------------------------
// Request card
// ----------------------------------------------------------------------------

interface RequestCardProps {
  request: FriendRequestEntry;
  direction: 'incoming' | 'outgoing';
  busy: boolean;
  onAccept?: () => void;
  onDecline?: () => void;
  onCancel?: () => void;
}

const RequestCard: React.FC<RequestCardProps> = ({
  request,
  direction,
  busy,
  onAccept,
  onDecline,
  onCancel,
}) => (
  <View style={styles.card}>
    <View style={styles.cardRow}>
      <View style={styles.avatarBox}>
        <AvatarDisplay
          assistantType={assistantOrDefault(request.assistant_type)}
          action="idle"
          size={56}
        />
      </View>
      <View style={styles.cardMeta}>
        <Text style={styles.cardName} numberOfLines={1}>
          {request.full_name}
        </Text>
        <Text style={styles.cardSub} numberOfLines={1}>
          {request.qosqanat_id} · {KZ.level(request.level)}
        </Text>
        <Text style={styles.cardSubMuted} numberOfLines={1}>
          {request.school}
        </Text>
      </View>
    </View>
    <View style={styles.cardActions}>
      {direction === 'incoming' ? (
        <>
          <Pressable
            style={[styles.primaryBtn, styles.acceptBtn, busy && styles.btnDisabled]}
            onPress={busy ? undefined : onAccept}
            disabled={busy}
          >
            <LinearGradient
              colors={[colors.success, '#3DDC97'] as readonly [string, string]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            <Text style={styles.primaryBtnText}>{KZ.accept}</Text>
          </Pressable>
          <Pressable
            style={[styles.secondaryBtn, busy && styles.btnDisabled]}
            onPress={busy ? undefined : onDecline}
            disabled={busy}
          >
            <Text style={[styles.secondaryBtnText, { color: colors.danger }]}>{KZ.decline}</Text>
          </Pressable>
        </>
      ) : (
        <Pressable
          style={[styles.secondaryBtn, { flex: 1 }, busy && styles.btnDisabled]}
          onPress={busy ? undefined : onCancel}
          disabled={busy}
        >
          <Text style={styles.secondaryBtnText}>{KZ.cancel}</Text>
        </Pressable>
      )}
    </View>
  </View>
);

// ----------------------------------------------------------------------------
// Search panel
// ----------------------------------------------------------------------------

interface SearchPanelProps {
  myId: string | undefined;
  alreadyFriendIds: ReadonlySet<string>;
  outgoingTargetIds: ReadonlySet<string>;
  onAdded: () => void;
}

const SearchPanel: React.FC<SearchPanelProps> = ({
  myId,
  alreadyFriendIds,
  outgoingTargetIds,
  onAdded,
}) => {
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [searched, setSearched] = useState(false);
  const [result, setResult] = useState<PublicUserProfile | null>(null);
  const [adding, setAdding] = useState(false);
  const [added, setAdded] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChange = useCallback((text: string) => {
    // Auto-uppercase + only allow alphanumeric + dash
    const cleaned = text.toUpperCase().replace(/[^A-Z0-9-]/g, '');
    setQuery(cleaned);
    setSearched(false);
    setResult(null);
    setAdded(false);
    setError(null);
  }, []);

  const handleSearch = useCallback(async () => {
    if (!query) return;
    setSearching(true);
    setError(null);
    try {
      const profile = await searchUserById(query);
      setResult(profile);
      setSearched(true);
    } catch {
      setError(KZ.loadFailed);
    } finally {
      setSearching(false);
    }
  }, [query]);

  const handleAdd = useCallback(async () => {
    if (!result) return;
    setAdding(true);
    try {
      await sendFriendRequest(result.id);
      setAdded(true);
      onAdded();
    } catch {
      setError(KZ.loadFailed);
    } finally {
      setAdding(false);
    }
  }, [result, onAdded]);

  const isSelf = !!result && !!myId && result.id === myId;
  const isAlreadyFriend = !!result && alreadyFriendIds.has(result.id);
  const isAlreadyRequested = !!result && outgoingTargetIds.has(result.id);

  return (
    <View style={styles.searchPanel}>
      <View style={styles.searchRow}>
        <TextInput
          style={styles.searchInput}
          value={query}
          onChangeText={handleChange}
          placeholder={KZ.searchPlaceholder}
          placeholderTextColor="rgba(255,255,255,0.45)"
          autoCapitalize="characters"
          autoCorrect={false}
          maxLength={12}
        />
        <Pressable
          style={[styles.searchBtn, (!query || searching) && styles.btnDisabled]}
          onPress={handleSearch}
          disabled={!query || searching}
        >
          {searching ? (
            <ActivityIndicator color={colors.white} />
          ) : (
            <Text style={styles.searchBtnText}>{KZ.searchBtn}</Text>
          )}
        </Pressable>
      </View>
      <Text style={styles.searchHint}>{KZ.searchHint}</Text>

      {error ? <Text style={styles.errorText}>{error}</Text> : null}

      {searched && !result ? (
        <View style={styles.searchEmpty}>
          <Text style={styles.searchEmptyEmoji}>🔍</Text>
          <Text style={styles.searchEmptyText}>{KZ.notFound}</Text>
        </View>
      ) : null}

      {result ? (
        <View style={styles.foundCard}>
          <View style={styles.foundHeader}>
            <AvatarDisplay
              assistantType={assistantOrDefault(result.assistant_type)}
              action="idle"
              size={96}
            />
            <View style={{ flex: 1, marginLeft: spacing.md }}>
              <Text style={styles.foundName}>{result.full_name}</Text>
              <Text style={styles.foundId}>{result.qosqanat_id}</Text>
              <Text style={styles.foundMeta}>
                {KZ.level(result.level)} · {KZ.akyl(result.akyl_points)}
              </Text>
              <Text style={styles.foundMetaMuted} numberOfLines={1}>
                {result.school}
              </Text>
              <Text style={styles.foundMetaMuted} numberOfLines={1}>
                {result.city}
              </Text>
            </View>
          </View>
          {isSelf ? (
            <Text style={styles.foundNotice}>{KZ.selfNotice}</Text>
          ) : isAlreadyFriend ? (
            <Text style={styles.foundNotice}>{KZ.alreadyFriend}</Text>
          ) : added || isAlreadyRequested ? (
            <View style={[styles.addBtn, { backgroundColor: colors.success }]}>
              <Text style={styles.addBtnText}>{KZ.added}</Text>
            </View>
          ) : (
            <Pressable
              style={[styles.addBtn, adding && styles.btnDisabled]}
              onPress={handleAdd}
              disabled={adding}
            >
              <LinearGradient
                colors={[colors.primary, colors.secondary] as readonly [string, string]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
              {adding ? (
                <ActivityIndicator color={colors.white} />
              ) : (
                <Text style={styles.addBtnText}>{KZ.add}</Text>
              )}
            </Pressable>
          )}
        </View>
      ) : null}
    </View>
  );
};

// ----------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------

const FriendsScreen: React.FC = () => {
  const nav = useNavigation<Nav>();
  const insets = useSafeAreaInsets();
  const myUser = useUserStore((s) => s.user);

  const [tab, setTab] = useState<TabKey>('friends');
  const [friends, setFriends] = useState<readonly FriendEntry[]>([]);
  const [incoming, setIncoming] = useState<readonly FriendRequestEntry[]>([]);
  const [outgoing, setOutgoing] = useState<readonly FriendRequestEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyIds, setBusyIds] = useState<ReadonlySet<string>>(() => new Set());
  const [online, setOnline] = useState<ReadonlySet<string>>(() => new Set());
  const [sort, setSort] = useState<SortKey>('recent');

  const setBusy = useCallback((id: string, busy: boolean) => {
    setBusyIds((curr) => {
      const next = new Set(curr);
      if (busy) next.add(id);
      else next.delete(id);
      return next;
    });
  }, []);

  // Initial fetch + refetch on focus.
  const refresh = useCallback(async () => {
    try {
      setLoading(true);
      const [f, inc, out] = await Promise.all([
        getFriends(),
        getIncomingFriendRequests(),
        getOutgoingFriendRequests(),
      ]);
      setFriends(f);
      setIncoming(inc);
      setOutgoing(out);
    } catch {
      // Soft-fail.
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  // Online presence subscription.
  useEffect(() => {
    const unsub = subscribeOnlinePresence((ids) => { setOnline(ids); });
    return unsub;
  }, []);

  const friendIds = useMemo<ReadonlySet<string>>(
    () => new Set(friends.map((f) => f.id)),
    [friends],
  );
  const outgoingIds = useMemo<ReadonlySet<string>>(
    () => new Set(outgoing.map((o) => o.id)),
    [outgoing],
  );

  const sortedFriends = useMemo(() => {
    const arr = friends.slice();
    switch (sort) {
      case 'level':
        arr.sort((a, b) => b.level - a.level);
        break;
      case 'akyl':
        arr.sort((a, b) => b.akyl_points - a.akyl_points);
        break;
      case 'name':
        arr.sort((a, b) => a.full_name.localeCompare(b.full_name, 'kk'));
        break;
      case 'recent':
      default:
        arr.sort((a, b) => (b.accepted_at ?? '').localeCompare(a.accepted_at ?? ''));
        break;
    }
    return arr;
  }, [friends, sort]);

  const handleAccept = useCallback(
    async (req: FriendRequestEntry) => {
      setBusy(req.friendship_id, true);
      try {
        await acceptFriendRequest(req.friendship_id);
        await refresh();
      } finally {
        setBusy(req.friendship_id, false);
      }
    },
    [refresh, setBusy],
  );

  const handleDecline = useCallback(
    async (req: FriendRequestEntry) => {
      setBusy(req.friendship_id, true);
      try {
        await declineFriendRequest(req.friendship_id);
        setIncoming((curr) => curr.filter((r) => r.friendship_id !== req.friendship_id));
      } finally {
        setBusy(req.friendship_id, false);
      }
    },
    [setBusy],
  );

  const handleCancel = useCallback(
    async (req: FriendRequestEntry) => {
      setBusy(req.friendship_id, true);
      try {
        await cancelFriendRequest(req.friendship_id);
        setOutgoing((curr) => curr.filter((r) => r.friendship_id !== req.friendship_id));
      } finally {
        setBusy(req.friendship_id, false);
      }
    },
    [setBusy],
  );

  const handleRemove = useCallback((friend: FriendEntry) => {
    Alert.alert(KZ.confirmRemove, KZ.confirmRemoveBody, [
      { text: KZ.no, style: 'cancel' },
      {
        text: KZ.yes,
        style: 'destructive',
        onPress: async () => {
          try {
            await removeFriend(friend.friendship_id);
            setFriends((curr) => curr.filter((f) => f.friendship_id !== friend.friendship_id));
          } catch {
            // soft-fail
          }
        },
      },
    ]);
  }, []);

  const handleBattle = useCallback(
    (friend: FriendEntry) => {
      nav.navigate('BattleSetup', { opponentId: friend.id });
    },
    [nav],
  );

  const renderFriend: ListRenderItem<FriendEntry> = useCallback(
    ({ item }) => (
      <FriendCard
        friend={item}
        online={online.has(item.id)}
        onBattle={() => { handleBattle(item); }}
        onProfile={() => undefined}
        onRemove={() => { handleRemove(item); }}
      />
    ),
    [online, handleBattle, handleRemove],
  );

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
      />

      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => { nav.goBack(); }} hitSlop={12} style={styles.backBtn}>
          <Text style={styles.backText}>{KZ.back}</Text>
        </Pressable>
        <Text style={styles.title}>{KZ.title}</Text>
        <View style={{ width: 60 }} />
      </View>

      <View style={styles.tabRow}>
        <Tab label={KZ.tabFriends} active={tab === 'friends'} onPress={() => { setTab('friends'); }} />
        <Tab
          label={KZ.tabRequests}
          active={tab === 'requests'}
          badge={incoming.length}
          onPress={() => { setTab('requests'); }}
        />
        <Tab label={KZ.tabSearch} active={tab === 'search'} onPress={() => { setTab('search'); }} />
      </View>

      {tab === 'friends' ? (
        <View style={{ flex: 1 }}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.sortRow}
          >
            <Text style={styles.sortLabel}>{KZ.sortLabel}</Text>
            {(
              [
                ['recent', KZ.sortRecent],
                ['level', KZ.sortLevel],
                ['akyl', KZ.sortAkyl],
                ['name', KZ.sortName],
              ] as readonly (readonly [SortKey, string])[]
            ).map(([key, label]) => (
              <Pressable
                key={key}
                onPress={() => { setSort(key); }}
                style={[styles.sortChip, sort === key && styles.sortChipActive]}
              >
                <Text style={[styles.sortChipText, sort === key && styles.sortChipTextActive]}>
                  {label}
                </Text>
              </Pressable>
            ))}
          </ScrollView>
          {loading ? (
            <View style={styles.loading}>
              <ActivityIndicator color={colors.white} size="large" />
            </View>
          ) : sortedFriends.length === 0 ? (
            <View style={styles.empty}>
              <Text style={styles.emptyEmoji}>🧑‍🤝‍🧑</Text>
              <Text style={styles.emptyText}>{KZ.emptyFriends}</Text>
            </View>
          ) : (
            <FlatList
              data={sortedFriends}
              renderItem={renderFriend}
              keyExtractor={(f) => f.friendship_id}
              contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + spacing.xl }]}
            />
          )}
        </View>
      ) : null}

      {tab === 'requests' ? (
        <ScrollView
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + spacing.xl }]}
        >
          {loading ? (
            <View style={styles.loading}>
              <ActivityIndicator color={colors.white} size="large" />
            </View>
          ) : (
            <>
              <Text style={styles.sectionHeader}>
                {KZ.incoming} · {incoming.length}
              </Text>
              {incoming.length === 0 ? (
                <Text style={styles.subEmpty}>{KZ.emptyRequests}</Text>
              ) : (
                incoming.map((req) => (
                  <RequestCard
                    key={req.friendship_id}
                    request={req}
                    direction="incoming"
                    busy={busyIds.has(req.friendship_id)}
                    onAccept={() => handleAccept(req)}
                    onDecline={() => handleDecline(req)}
                  />
                ))
              )}
              <Text style={[styles.sectionHeader, { marginTop: spacing.lg }]}>
                {KZ.outgoing} · {outgoing.length}
              </Text>
              {outgoing.length === 0 ? (
                <Text style={styles.subEmpty}>{KZ.emptyRequests}</Text>
              ) : (
                outgoing.map((req) => (
                  <RequestCard
                    key={req.friendship_id}
                    request={req}
                    direction="outgoing"
                    busy={busyIds.has(req.friendship_id)}
                    onCancel={() => handleCancel(req)}
                  />
                ))
              )}
            </>
          )}
        </ScrollView>
      ) : null}

      {tab === 'search' ? (
        <ScrollView
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + spacing.xl }]}
          keyboardShouldPersistTaps="handled"
        >
          <SearchPanel
            myId={myUser?.id}
            alreadyFriendIds={friendIds}
            outgoingTargetIds={outgoingIds}
            onAdded={() => {
              void refresh();
            }}
          />
        </ScrollView>
      ) : null}
    </View>
  );
};

// ----------------------------------------------------------------------------
// Styles
// ----------------------------------------------------------------------------

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#1A1A4E',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.sm,
  },
  backBtn: { width: 60 },
  backText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
  },
  title: {
    color: colors.white,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
  },
  tabRow: {
    flexDirection: 'row',
    paddingHorizontal: spacing.md,
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  tabWrap: { flex: 1 },
  tab: {
    paddingVertical: spacing.sm,
    borderRadius: radius.full,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  tabActive: {
    backgroundColor: colors.gold,
    borderColor: colors.gold,
  },
  tabText: {
    color: 'rgba(255,255,255,0.75)',
    fontWeight: fontWeight.semibold,
    fontSize: fontSize.sm,
  },
  tabTextActive: { color: colors.text, fontWeight: fontWeight.extrabold },
  tabBadge: {
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    paddingHorizontal: 6,
    backgroundColor: colors.danger,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabBadgeText: {
    color: colors.white,
    fontSize: 11,
    fontWeight: fontWeight.extrabold,
  },
  sortRow: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.sm,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  sortLabel: { color: 'rgba(255,255,255,0.6)', fontSize: fontSize.sm },
  sortChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.full,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  sortChipActive: { backgroundColor: 'rgba(255,215,0,0.2)' },
  sortChipText: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
  },
  sortChipTextActive: { color: colors.gold, fontWeight: fontWeight.extrabold },
  list: {
    paddingHorizontal: spacing.md,
    gap: spacing.md,
  },
  card: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    gap: spacing.sm,
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  avatarBox: {
    position: 'relative',
  },
  onlineDot: {
    position: 'absolute',
    bottom: 4,
    right: 4,
    width: 14,
    height: 14,
    borderRadius: 7,
    borderWidth: 2,
    borderColor: '#1A1A4E',
  },
  cardMeta: { flex: 1, gap: 4 },
  cardName: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
  },
  cardSub: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
  },
  cardSubMuted: {
    color: 'rgba(255,255,255,0.45)',
    fontSize: fontSize.xs,
  },
  cardStats: {
    flexDirection: 'row',
    gap: 6,
    marginTop: 2,
  },
  statChip: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: radius.full,
    backgroundColor: 'rgba(255,215,0,0.18)',
  },
  statChipText: {
    color: colors.gold,
    fontSize: 11,
    fontWeight: fontWeight.extrabold,
  },
  cardActions: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  primaryBtn: {
    flex: 1,
    height: 44,
    borderRadius: radius.md,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  battleBtn: {},
  acceptBtn: {},
  primaryBtnText: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
  },
  secondaryBtn: {
    flex: 1,
    height: 44,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  secondaryBtnText: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
  },
  btnDisabled: { opacity: 0.5 },
  removeBtn: { alignItems: 'center', marginTop: 4 },
  removeBtnText: {
    color: 'rgba(255,255,255,0.45)',
    fontSize: fontSize.xs,
    fontWeight: fontWeight.semibold,
  },
  loading: { paddingVertical: spacing.xl, alignItems: 'center' },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: spacing.lg },
  emptyEmoji: { fontSize: 56, marginBottom: spacing.sm },
  emptyText: {
    color: 'rgba(255,255,255,0.7)',
    textAlign: 'center',
    fontSize: fontSize.md,
    lineHeight: 22,
  },
  subEmpty: {
    color: 'rgba(255,255,255,0.45)',
    fontSize: fontSize.sm,
    textAlign: 'center',
    paddingVertical: spacing.md,
  },
  sectionHeader: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
    marginBottom: spacing.sm,
  },
  // ---- Search ----
  searchPanel: { gap: spacing.md },
  searchRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  searchInput: {
    flex: 1,
    height: 52,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.5,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  searchBtn: {
    height: 52,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary,
  },
  searchBtnText: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
  },
  searchHint: {
    color: 'rgba(255,255,255,0.45)',
    fontSize: fontSize.xs,
  },
  errorText: {
    color: colors.danger,
    fontSize: fontSize.sm,
    textAlign: 'center',
  },
  searchEmpty: { alignItems: 'center', paddingVertical: spacing.lg },
  searchEmptyEmoji: { fontSize: 48, marginBottom: spacing.sm },
  searchEmptyText: { color: 'rgba(255,255,255,0.6)', fontSize: fontSize.md },
  foundCard: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    gap: spacing.md,
  },
  foundHeader: { flexDirection: 'row', alignItems: 'center' },
  foundName: { color: colors.white, fontSize: fontSize.lg, fontWeight: fontWeight.extrabold },
  foundId: { color: colors.gold, fontSize: fontSize.sm, fontWeight: fontWeight.bold, marginTop: 2 },
  foundMeta: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
    marginTop: 4,
  },
  foundMetaMuted: { color: 'rgba(255,255,255,0.5)', fontSize: fontSize.xs, marginTop: 2 },
  foundNotice: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.sm,
    textAlign: 'center',
    paddingVertical: spacing.sm,
  },
  addBtn: {
    height: 52,
    borderRadius: radius.md,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addBtnText: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
  },
});

export default FriendsScreen;
