import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Dimensions, ScrollView } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  withRepeat,
  withSequence,
  withDelay,
  Easing,
} from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';

import AvatarSelector from '@/components/Avatar/AvatarSelector';
import GradientButton from '@/components/GradientButton';
import type { AuthScreenProps } from '@/navigation/types';
import { setAssistant } from '@/services/auth';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import type { AssistantType } from '@/types';

const KZ = {
  title: 'Өз серігіңді таңда!',
  subtitle: 'Ол сенімен бірге оқиды, мадақтайды',
  confirm: 'Таңдадым! ✓',
  error: 'Қате болды. Қайталап көріңіз',
};

const SCREEN_W = Dimensions.get('window').width;

interface StarProps {
  left: number;
  top: number;
  size: number;
  delay: number;
}

const Star: React.FC<StarProps> = ({ left, top, size, delay }) => {
  const opacity = useSharedValue(0.2);
  useEffect(() => {
    opacity.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(0.9, { duration: 1400, easing: Easing.inOut(Easing.quad) }),
          withTiming(0.2, { duration: 1400, easing: Easing.inOut(Easing.quad) }),
        ),
        -1,
        true,
      ),
    );
  }, [opacity, delay]);
  const style = useAnimatedStyle(() => ({ opacity: opacity.value }));
  return (
    <Animated.View
      pointerEvents="none"
      style={[styles.star, { left, top, width: size, height: size, borderRadius: size / 2 }, style]}
    />
  );
};

const STAR_COUNT = 22;
const STARS = Array.from({ length: STAR_COUNT }, (_, i) => ({
  id: i,
  left: Math.random() * SCREEN_W,
  top: Math.random() * 400,
  size: 2 + Math.random() * 3,
  delay: Math.random() * 2000,
}));

const AssistantSelectScreen: React.FC<AuthScreenProps<'AssistantSelect'>> = ({ navigation }) => {
  const [selected, setSelected] = useState<AssistantType | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const titleScale = useSharedValue(0.9);
  const titleOpacity = useSharedValue(0);
  const ctaTranslate = useSharedValue(80);
  const ctaOpacity = useSharedValue(0);

  useEffect(() => {
    titleScale.value = withSpring(1, { damping: 12, stiffness: 120 });
    titleOpacity.value = withTiming(1, { duration: 700 });
  }, [titleScale, titleOpacity]);

  useEffect(() => {
    if (selected) {
      ctaTranslate.value = withSpring(0, { damping: 16, stiffness: 120 });
      ctaOpacity.value = withTiming(1, { duration: 280 });
    } else {
      ctaTranslate.value = withTiming(80, { duration: 250 });
      ctaOpacity.value = withTiming(0, { duration: 250 });
    }
  }, [selected, ctaTranslate, ctaOpacity]);

  const titleStyle = useAnimatedStyle(() => ({
    transform: [{ scale: titleScale.value }],
    opacity: titleOpacity.value,
  }));
  const ctaStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: ctaTranslate.value }],
    opacity: ctaOpacity.value,
  }));

  const confirm = useCallback(async () => {
    if (!selected) return;
    setLoading(true);
    setError(null);
    try {
      await setAssistant(selected);
      navigation.reset({ index: 0, routes: [{ name: 'Onboarding' }] });
    } catch {
      setError(KZ.error);
    } finally {
      setLoading(false);
    }
  }, [selected, navigation]);

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#0E0B33', '#1A1A4E', colors.primary] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      />
      {STARS.map((s) => (
        <Star key={s.id} left={s.left} top={s.top} size={s.size} delay={s.delay} />
      ))}

      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <Animated.Text style={[styles.title, titleStyle]}>{KZ.title}</Animated.Text>
          <Text style={styles.subtitle}>{KZ.subtitle}</Text>

          <AvatarSelector selected={selected} onSelect={setSelected} />

          {error ? <Text style={styles.errorText}>{error}</Text> : null}
        </ScrollView>

        <Animated.View
          style={[styles.ctaWrap, ctaStyle]}
          pointerEvents={selected ? 'auto' : 'none'}
        >
          <GradientButton
            title={KZ.confirm}
            onPress={confirm}
            loading={loading}
            gradientColors={[colors.gold, '#FFB347'] as const}
          />
        </Animated.View>
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0E0B33' },
  safe: { flex: 1 },
  content: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xl,
    paddingBottom: 120,
    alignItems: 'center',
  },
  title: {
    color: colors.white,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.bold,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
  subtitle: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: fontSize.md,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  star: {
    position: 'absolute',
    backgroundColor: colors.white,
  },
  errorText: {
    color: colors.danger,
    backgroundColor: 'rgba(255,71,87,0.15)',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.md,
    marginTop: spacing.lg,
    fontWeight: fontWeight.semibold,
  },
  ctaWrap: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    bottom: spacing.xl,
  },
});

export default AssistantSelectScreen;
