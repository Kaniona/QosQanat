import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Modal,
  FlatList,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSpring,
  withSequence,
  Easing,
} from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';

import FormInput from '@/components/FormInput';
import GradientButton from '@/components/GradientButton';
import { KZ_CITIES } from '@/data/cities';
import type { AuthScreenProps } from '@/navigation/types';
import { registerUser } from '@/services/auth';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import { formatKzPhone, maskKzPhone, maskIin, digitsOnly } from '@/utils/phoneFormat';
import {
  isValidFullName,
  isValidIin,
  isValidKzPhone,
  isValidSchool,
  isValidGrade,
  isValidCity,
} from '@/utils/validation';

const KZ = {
  back: '←',
  next: 'Келесі →',
  prev: 'Артқа',
  submit: 'Тіркелу',
  step1Title: 'Жеке мәлімет',
  step2Title: 'Мектеп мәліметі',
  step3Title: 'Шолу',

  fullNameLabel: 'Толық аты-жөні',
  fullNamePlaceholder: 'Мысалы, Айдос Ерланұлы',
  fullNameError: 'Аты-жөніңізді толық жазыңыз',

  phoneLabel: 'Телефон нөмірі',
  phonePlaceholder: '+7 (___) ___-__-__',
  phoneError: 'Телефон нөмірі толық емес',

  iinLabel: 'ЖСН (ИИН)',
  iinPlaceholder: '12 сан',
  iinError: 'ЖСН 12 саннан тұруы керек',

  cityLabel: 'Қала',
  cityPlaceholder: 'Қаланы таңдаңыз',
  cityModalTitle: 'Қалаңды таңда',

  schoolLabel: 'Мектеп атауы',
  schoolPlaceholder: 'Мысалы, №25 мектеп-гимназия',
  schoolError: 'Мектеп атауын жазыңыз',

  gradeLabel: 'Сыныбың',
  gradeError: 'Сыныпты таңдаңыз',

  reviewName: 'Аты-жөні',
  reviewPhone: 'Телефон',
  reviewIin: 'ЖСН',
  reviewCity: 'Қала',
  reviewSchool: 'Мектеп',
  reviewGrade: 'Сынып',
  gradeUnit: '-сынып',

  termsAgree: 'Қолдану шарттарымен келісемін',
  dataAgree: 'Жеке деректерді өңдеуге келісім беремін',

  toastDefault: 'Қате болды. Қайталап көріңіз',
  toastTaken: 'Бұл телефон немесе ЖСН тіркелген',
};

type Step = 1 | 2 | 3;

interface ToastBannerProps {
  message: string | null;
  onHide: () => void;
}

const ToastBanner: React.FC<ToastBannerProps> = ({ message, onHide }) => {
  const translateY = useSharedValue(-80);
  const opacity = useSharedValue(0);

  useEffect(() => {
    if (!message) return;
    translateY.value = withSpring(0, { damping: 14, stiffness: 140 });
    opacity.value = withTiming(1, { duration: 200 });
    const t = setTimeout(() => {
      translateY.value = withTiming(-80, { duration: 250 });
      opacity.value = withTiming(0, { duration: 250 }, (finished) => {
        if (finished) {
          // schedule hide on JS thread
        }
      });
      onHide();
    }, 3500);
    return () => { clearTimeout(t); };
  }, [message, translateY, opacity, onHide]);

  const style = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
    opacity: opacity.value,
  }));

  if (!message) return null;
  return (
    <Animated.View style={[styles.toast, style]} pointerEvents="none">
      <Text style={styles.toastText}>{message}</Text>
    </Animated.View>
  );
};

const ProgressDots: React.FC<{ step: Step }> = ({ step }) => (
  <View style={styles.progressRow}>
    {[1, 2, 3].map((i) => (
      <View key={i} style={[styles.dot, i <= step && styles.dotActive]} />
    ))}
  </View>
);

const RegisterScreen: React.FC<AuthScreenProps<'Register'>> = ({ navigation }) => {
  const [step, setStep] = useState<Step>(1);
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [iin, setIin] = useState('');
  const [city, setCity] = useState('');
  const [school, setSchool] = useState('');
  const [grade, setGrade] = useState<number | null>(null);
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [agreeData, setAgreeData] = useState(false);

  const [showCityPicker, setShowCityPicker] = useState(false);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const stepOpacity = useSharedValue(1);
  const stepTranslate = useSharedValue(0);

  const markTouched = useCallback(
    (k: string) => { setTouched((t) => (t[k] ? t : { ...t, [k]: true })); },
    [],
  );

  const errors = useMemo(() => {
    return {
      fullName: !isValidFullName(fullName) ? KZ.fullNameError : undefined,
      phone: !isValidKzPhone(phone) ? KZ.phoneError : undefined,
      iin: !isValidIin(iin) ? KZ.iinError : undefined,
      school: !isValidSchool(school) ? KZ.schoolError : undefined,
      grade: !isValidGrade(grade) ? KZ.gradeError : undefined,
    };
  }, [fullName, phone, iin, school, grade]);

  const step1Valid = !errors.fullName && !errors.phone && !errors.iin;
  const step2Valid = isValidCity(city) && !errors.school && !errors.grade;
  const canSubmit = step1Valid && step2Valid && agreeTerms && agreeData;

  const animateStepChange = useCallback(
    (next: Step) => {
      stepOpacity.value = withSequence(
        withTiming(0, { duration: 140, easing: Easing.out(Easing.cubic) }),
        withTiming(1, { duration: 220, easing: Easing.out(Easing.cubic) }),
      );
      stepTranslate.value = withSequence(
        withTiming(-12, { duration: 140 }),
        withTiming(0, { duration: 220 }),
      );
      setTimeout(() => { setStep(next); }, 140);
    },
    [stepOpacity, stepTranslate],
  );

  const goNext = useCallback(() => {
    if (step === 1) {
      setTouched({ fullName: true, phone: true, iin: true });
      if (step1Valid) animateStepChange(2);
    } else if (step === 2) {
      setTouched((t) => ({ ...t, city: true, school: true, grade: true }));
      if (step2Valid) animateStepChange(3);
    }
  }, [step, step1Valid, step2Valid, animateStepChange]);

  const goBack = useCallback(() => {
    if (step === 1) navigation.goBack();
    else animateStepChange((step - 1) as Step);
  }, [step, animateStepChange, navigation]);

  const submit = useCallback(async () => {
    if (!canSubmit || grade === null) return;
    setLoading(true);
    try {
      await registerUser({ fullName, phone, iin, city, school, grade });
      navigation.replace('AssistantSelect');
    } catch (e) {
      const msg = (e as Error).message?.toLowerCase() ?? '';
      if (msg.includes('duplicate') || msg.includes('already') || msg.includes('unique')) {
        setToast(KZ.toastTaken);
      } else {
        setToast(KZ.toastDefault);
      }
    } finally {
      setLoading(false);
    }
  }, [canSubmit, fullName, phone, iin, city, school, grade, navigation]);

  const stepStyle = useAnimatedStyle(() => ({
    opacity: stepOpacity.value,
    transform: [{ translateY: stepTranslate.value }],
  }));

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <ToastBanner message={toast} onHide={() => { setToast(null); }} />

      <View style={styles.header}>
        <Pressable onPress={goBack} hitSlop={12} style={styles.backBtn}>
          <Text style={styles.backText}>{KZ.back}</Text>
        </Pressable>
        <ProgressDots step={step} />
        <View style={styles.backBtn} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.flex}
      >
        <Animated.View style={[styles.flex, stepStyle]}>
          <ScrollView
            contentContainerStyle={styles.scroll}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {step === 1 && (
              <>
                <Text style={styles.stepTitle}>{KZ.step1Title}</Text>

                <FormInput
                  label={KZ.fullNameLabel}
                  placeholder={KZ.fullNamePlaceholder}
                  value={fullName}
                  onChangeText={setFullName}
                  onBlur={() => { markTouched('fullName'); }}
                  error={touched.fullName ? errors.fullName : undefined}
                  autoCapitalize="words"
                />

                <FormInput
                  label={KZ.phoneLabel}
                  placeholder={KZ.phonePlaceholder}
                  value={phone}
                  onChangeText={(v) => { setPhone(formatKzPhone(v)); }}
                  onBlur={() => { markTouched('phone'); }}
                  error={touched.phone ? errors.phone : undefined}
                  keyboardType="phone-pad"
                  maxLength={18}
                />

                <FormInput
                  label={KZ.iinLabel}
                  placeholder={KZ.iinPlaceholder}
                  value={iin}
                  onChangeText={(v) => { setIin(digitsOnly(v).slice(0, 12)); }}
                  onBlur={() => { markTouched('iin'); }}
                  error={touched.iin ? errors.iin : undefined}
                  keyboardType="number-pad"
                  maxLength={12}
                />
              </>
            )}

            {step === 2 && (
              <>
                <Text style={styles.stepTitle}>{KZ.step2Title}</Text>

                <View style={styles.fieldWrap}>
                  <Text style={styles.fieldLabel}>{KZ.cityLabel}</Text>
                  <Pressable
                    style={[styles.dropdown, !city && styles.dropdownEmpty]}
                    onPress={() => { setShowCityPicker(true); }}
                  >
                    <Text style={city ? styles.dropdownText : styles.dropdownPlaceholder}>
                      {city || KZ.cityPlaceholder}
                    </Text>
                    <Text style={styles.dropdownArrow}>▾</Text>
                  </Pressable>
                </View>

                <FormInput
                  label={KZ.schoolLabel}
                  placeholder={KZ.schoolPlaceholder}
                  value={school}
                  onChangeText={setSchool}
                  onBlur={() => { markTouched('school'); }}
                  error={touched.school ? errors.school : undefined}
                />

                <Text style={styles.fieldLabel}>{KZ.gradeLabel}</Text>
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.gradeRow}
                >
                  {Array.from({ length: 11 }, (_, i) => i + 1).map((g) => {
                    const selected = grade === g;
                    return (
                      <Pressable
                        key={g}
                        onPress={() => { setGrade(g); }}
                        style={[styles.gradeChip, selected && styles.gradeChipSelected]}
                      >
                        <Text style={[styles.gradeText, selected && styles.gradeTextSelected]}>
                          {g}
                        </Text>
                      </Pressable>
                    );
                  })}
                </ScrollView>
                {touched.grade && errors.grade ? (
                  <Text style={styles.errorText}>{errors.grade}</Text>
                ) : null}
              </>
            )}

            {step === 3 && (
              <>
                <Text style={styles.stepTitle}>{KZ.step3Title}</Text>

                <View style={styles.reviewCard}>
                  <ReviewRow label={KZ.reviewName} value={fullName} />
                  <ReviewRow label={KZ.reviewPhone} value={maskKzPhone(phone)} />
                  <ReviewRow label={KZ.reviewIin} value={maskIin(iin)} />
                  <ReviewRow label={KZ.reviewCity} value={city} />
                  <ReviewRow label={KZ.reviewSchool} value={school} />
                  <ReviewRow
                    label={KZ.reviewGrade}
                    value={grade ? `${grade}${KZ.gradeUnit}` : ''}
                  />
                </View>

                <Checkbox
                  checked={agreeTerms}
                  onToggle={() => { setAgreeTerms((v) => !v); }}
                  label={KZ.termsAgree}
                />
                <Checkbox
                  checked={agreeData}
                  onToggle={() => { setAgreeData((v) => !v); }}
                  label={KZ.dataAgree}
                />
              </>
            )}
          </ScrollView>
        </Animated.View>
      </KeyboardAvoidingView>

      <View style={styles.footer}>
        {step < 3 ? (
          <GradientButton
            title={KZ.next}
            onPress={goNext}
            disabled={step === 1 ? !step1Valid : !step2Valid}
          />
        ) : (
          <GradientButton
            title={KZ.submit}
            onPress={submit}
            disabled={!canSubmit}
            loading={loading}
          />
        )}
      </View>

      <Modal
        visible={showCityPicker}
        transparent
        animationType="slide"
        onRequestClose={() => { setShowCityPicker(false); }}
      >
        <Pressable style={styles.modalBackdrop} onPress={() => { setShowCityPicker(false); }}>
          <Pressable style={styles.modalCard} onPress={() => undefined}>
            <Text style={styles.modalTitle}>{KZ.cityModalTitle}</Text>
            <FlatList
              data={KZ_CITIES}
              keyExtractor={(item) => item}
              renderItem={({ item }) => (
                <Pressable
                  style={styles.cityRow}
                  onPress={() => {
                    setCity(item);
                    setShowCityPicker(false);
                  }}
                >
                  <Text style={[styles.cityText, item === city && styles.cityTextSelected]}>
                    {item}
                  </Text>
                  {item === city ? <Text style={styles.cityCheck}>✓</Text> : null}
                </Pressable>
              )}
            />
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
};

const ReviewRow: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <View style={styles.reviewRow}>
    <Text style={styles.reviewLabel}>{label}</Text>
    <Text style={styles.reviewValue}>{value}</Text>
  </View>
);

const Checkbox: React.FC<{ checked: boolean; onToggle: () => void; label: string }> = ({
  checked,
  onToggle,
  label,
}) => (
  <Pressable style={styles.checkRow} onPress={onToggle}>
    <View style={[styles.checkBox, checked && styles.checkBoxChecked]}>
      {checked ? <Text style={styles.checkMark}>✓</Text> : null}
    </View>
    <Text style={styles.checkLabel}>{label}</Text>
  </Pressable>
);

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
  },
  flex: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    paddingBottom: spacing.md,
  },
  backBtn: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  backText: {
    color: colors.text,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.medium,
  },
  progressRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.border,
  },
  dotActive: {
    backgroundColor: colors.primary,
  },
  scroll: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    paddingBottom: spacing.xl,
  },
  stepTitle: {
    color: colors.text,
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
    marginBottom: spacing.lg,
  },
  fieldWrap: {
    marginBottom: spacing.md,
  },
  fieldLabel: {
    color: colors.text,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
    marginBottom: spacing.xs,
  },
  dropdown: {
    backgroundColor: colors.white,
    borderRadius: radius.md,
    borderWidth: 1.5,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 52,
  },
  dropdownEmpty: {},
  dropdownText: {
    color: colors.text,
    fontSize: fontSize.md,
  },
  dropdownPlaceholder: {
    color: colors.textLight,
    fontSize: fontSize.md,
  },
  dropdownArrow: {
    color: colors.textLight,
    fontSize: fontSize.md,
  },
  gradeRow: {
    paddingVertical: spacing.sm,
    gap: spacing.sm,
  },
  gradeChip: {
    width: 52,
    height: 52,
    borderRadius: radius.md,
    backgroundColor: colors.white,
    borderWidth: 2,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  gradeChipSelected: {
    borderColor: colors.gold,
    backgroundColor: '#FFFBE5',
  },
  gradeText: {
    color: colors.text,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.medium,
  },
  gradeTextSelected: {
    color: colors.text,
    fontWeight: fontWeight.extrabold,
  },
  errorText: {
    color: colors.danger,
    fontSize: fontSize.xs,
    marginTop: spacing.xs,
  },
  footer: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    paddingBottom: spacing.md,
    backgroundColor: colors.background,
  },
  reviewCard: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
  },
  reviewRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  reviewLabel: {
    color: colors.textLight,
    fontSize: fontSize.sm,
  },
  reviewValue: {
    color: colors.text,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
    flexShrink: 1,
    textAlign: 'right',
    marginLeft: spacing.md,
  },
  checkRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
  },
  checkBox: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
    backgroundColor: colors.white,
  },
  checkBoxChecked: {
    borderColor: colors.primary,
    backgroundColor: colors.primary,
  },
  checkMark: {
    color: colors.white,
    fontWeight: fontWeight.bold,
  },
  checkLabel: {
    color: colors.text,
    fontSize: fontSize.sm,
    flexShrink: 1,
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.45)',
    justifyContent: 'flex-end',
  },
  modalCard: {
    backgroundColor: colors.white,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.xl,
    maxHeight: '70%',
  },
  modalTitle: {
    color: colors.text,
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
    marginBottom: spacing.md,
  },
  cityRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  cityText: {
    color: colors.text,
    fontSize: fontSize.md,
  },
  cityTextSelected: {
    color: colors.primary,
    fontWeight: fontWeight.bold,
  },
  cityCheck: {
    color: colors.primary,
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
  },
  toast: {
    position: 'absolute',
    top: spacing.md,
    left: spacing.md,
    right: spacing.md,
    backgroundColor: colors.danger,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    zIndex: 50,
    shadowColor: colors.danger,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 8,
  },
  toastText: {
    color: colors.white,
    fontWeight: fontWeight.semibold,
    fontSize: fontSize.sm,
    textAlign: 'center',
  },
});

export default RegisterScreen;
