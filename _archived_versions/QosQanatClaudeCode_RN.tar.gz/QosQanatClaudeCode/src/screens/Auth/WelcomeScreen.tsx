import { LinearGradient } from 'expo-linear-gradient';
import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Pressable, Dimensions } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withDelay,
  withSpring,
  withTiming,
  withRepeat,
  withSequence,
  Easing,
} from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';

import GradientButton from '@/components/GradientButton';
import Logo from '@/components/Logo';
import type { AuthScreenProps } from '@/navigation/types';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

const KZ = {
  title: 'QosQanat-қа қош келдіңіз!',
  subtitle: 'Оқуды ойынға айналдыр',
  register: 'Тіркелу',
  kaz: 'ҚАЗ',
  rus: 'РУС',
};

const SCREEN_H = Dimensions.get('window').height;

const WelcomeScreen: React.FC<AuthScreenProps<'Welcome'>> = ({ navigation }) => {
  const cardY = useSharedValue(120);
  const cardOpacity = useSharedValue(0);
  const logoFloat = useSharedValue(0);
  const titleOpacity = useSharedValue(0);

  useEffect(() => {
    cardY.value = withSpring(0, { damping: 16, stiffness: 110 });
    cardOpacity.value = withTiming(1, { duration: 600 });
    titleOpacity.value = withDelay(300, withTiming(1, { duration: 600 }));
    logoFloat.value = withRepeat(
      withSequence(
        withTiming(-10, { duration: 1600, easing: Easing.inOut(Easing.quad) }),
        withTiming(10, { duration: 1600, easing: Easing.inOut(Easing.quad) }),
      ),
      -1,
      true,
    );
  }, [cardY, cardOpacity, titleOpacity, logoFloat]);

  const cardStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: cardY.value }],
    opacity: cardOpacity.value,
  }));

  const logoStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: logoFloat.value }],
  }));

  const titleStyle = useAnimatedStyle(() => ({ opacity: titleOpacity.value }));

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#1A1A4E', colors.primary, colors.secondary] as readonly [string, string, string]}
        style={styles.hero}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <SafeAreaView edges={['top']} style={styles.heroSafe}>
          <View style={styles.langRow}>
            <Pressable style={[styles.langChip, styles.langChipActive]}>
              <Text style={styles.langTextActive}>{KZ.kaz}</Text>
            </Pressable>
            <Text style={styles.langSeparator}>|</Text>
            <Pressable style={styles.langChip}>
              <Text style={styles.langText}>{KZ.rus}</Text>
            </Pressable>
          </View>

          <View style={styles.heroBody}>
            <Animated.View style={logoStyle}>
              <Logo size={180} />
            </Animated.View>
          </View>
        </SafeAreaView>
      </LinearGradient>

      <Animated.View style={[styles.card, cardStyle]}>
        <SafeAreaView edges={['bottom']} style={styles.cardSafe}>
          <Animated.Text style={[styles.title, titleStyle]}>{KZ.title}</Animated.Text>
          <Text style={styles.subtitle}>{KZ.subtitle}</Text>
          <GradientButton
            title={KZ.register}
            onPress={() => { navigation.navigate('Register'); }}
            style={styles.cta}
          />
        </SafeAreaView>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  hero: {
    height: SCREEN_H * 0.6,
  },
  heroSafe: {
    flex: 1,
  },
  heroBody: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  langRow: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-end',
    paddingRight: spacing.lg,
    paddingTop: spacing.sm,
    gap: spacing.xs,
  },
  langChip: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.sm,
  },
  langChipActive: {
    backgroundColor: 'rgba(255,255,255,0.18)',
  },
  langText: {
    color: 'rgba(255,255,255,0.7)',
    fontWeight: fontWeight.semibold,
    fontSize: fontSize.sm,
  },
  langTextActive: {
    color: colors.white,
    fontWeight: fontWeight.bold,
    fontSize: fontSize.sm,
  },
  langSeparator: {
    color: 'rgba(255,255,255,0.5)',
  },
  card: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    minHeight: SCREEN_H * 0.42,
    backgroundColor: colors.white,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xl,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -8 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 12,
  },
  cardSafe: {
    flex: 1,
  },
  title: {
    color: colors.text,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.bold,
    textAlign: 'center',
  },
  subtitle: {
    color: colors.textLight,
    fontSize: fontSize.md,
    textAlign: 'center',
    marginTop: spacing.sm,
    marginBottom: spacing.xl,
  },
  cta: {
    marginTop: 'auto',
    marginBottom: spacing.md,
  },
});

export default WelcomeScreen;
