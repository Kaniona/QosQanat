import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Dimensions, Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, {
  Easing,
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AvatarDisplay from '@/components/Avatar/AvatarDisplay';
import { useGameStore } from '@/store/gameStore';
import { useSettingsStore } from '@/store/settingsStore';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import type { AssistantType } from '@/types';

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');
const WELCOME_COINS = 100;

// ----------------------------------------------------------------------------
// Step config — 8 spotlight steps. Each step targets a virtual region of the
// screen so the dim overlay can punch a soft "spotlight" hole that previews
// the relevant feature. Tap "Әрі қарай" to advance, "Алдыңғы" to step back,
// and "Бастау! 🎉" on the final step grants the welcome coins + finishes.
// ----------------------------------------------------------------------------

interface Step {
  id: string;
  emoji: string;
  titleKz: string;
  bodyKz: (assistantName: string) => string;
  spotlight: { cx: number; cy: number; r: number };
}

const buildSteps = (): readonly Step[] => [
  {
    id: 'intro',
    emoji: '👋',
    titleKz: 'Сәлем!',
    bodyKz: (n) => `${n} сізбен бірге оқуға дайын! Бұл шағын экскурсия 1 минутқа ғана созылады.`,
    spotlight: { cx: SCREEN_W / 2, cy: SCREEN_H * 0.45, r: 180 },
  },
  {
    id: 'points',
    emoji: '⭐',
    titleKz: 'Ұпайлар жүйесі',
    bodyKz: () =>
      'Үш түрлі ұпай бар: ✨ XP (деңгей), 🪙 Тиын (дүкенде жұмсайсыз) және 🔮 Ақыл (рейтингке әсер етеді).',
    spotlight: { cx: SCREEN_W - 80, cy: 120, r: 140 },
  },
  {
    id: 'learn',
    emoji: '📚',
    titleKz: 'Оқу картасы',
    bodyKz: () =>
      'Әр пәнде кезеңдік карта бар. Ойын тәрізді өтіп, сабақ, тест және «босс» тапсырмаларын орындайсыз.',
    spotlight: { cx: SCREEN_W * 0.3, cy: SCREEN_H - 100, r: 100 },
  },
  {
    id: 'shop',
    emoji: '🛍️',
    titleKz: 'Дүкен',
    bodyKz: () =>
      'Тиындарыңызға аватарға арналған киім, бас киім, аксессуар және үй жануарларын алуыңызға болады.',
    spotlight: { cx: SCREEN_W / 2, cy: SCREEN_H - 100, r: 110 },
  },
  {
    id: 'friends',
    emoji: '👥',
    titleKz: 'Достар',
    bodyKz: () =>
      'Достарыңызды QQ-ID арқылы қосыңыз. Кейін олармен «Ақыл шайқасында» жарысуыңызға болады!',
    spotlight: { cx: SCREEN_W * 0.7, cy: SCREEN_H - 100, r: 100 },
  },
  {
    id: 'rating',
    emoji: '🏆',
    titleKz: 'Рейтинг',
    bodyKz: () => 'Жалпы, қалаңыз, мектебіңіз бен достарыңыз арасында кім алда екенін көріңіз.',
    spotlight: { cx: SCREEN_W / 2, cy: SCREEN_H * 0.5, r: 180 },
  },
  {
    id: 'quests',
    emoji: '🎯',
    titleKz: 'Күнделікті квесттер',
    bodyKz: () => 'Әр күн сайын 3 квест жаңарады. Орындап, бонустарды жинаңыз — серия сақтаңыз!',
    spotlight: { cx: SCREEN_W / 2, cy: SCREEN_H * 0.55, r: 200 },
  },
  {
    id: 'voice',
    emoji: '🎤',
    titleKz: 'Дауыстық көмекші',
    bodyKz: (n) =>
      `${n}-ке кез келген сұрақ қойыңыз — экранды ауыстыру, балансты білу немесе жай ғана әңгімелесу үшін.`,
    spotlight: { cx: SCREEN_W - 60, cy: SCREEN_H - 110, r: 120 },
  },
];

// ----------------------------------------------------------------------------
// Spotlight — dim overlay + animated highlight ring around the focus area.
// ----------------------------------------------------------------------------

interface SpotlightProps {
  cx: number;
  cy: number;
  r: number;
}

const Spotlight: React.FC<SpotlightProps> = ({ cx, cy, r }) => {
  const pulse = useSharedValue(0);
  useEffect(() => {
    pulse.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1000, easing: Easing.inOut(Easing.quad) }),
        withTiming(0, { duration: 1000, easing: Easing.inOut(Easing.quad) }),
      ),
      -1,
    );
    return () => { cancelAnimation(pulse); };
  }, [pulse]);
  const ringStyle = useAnimatedStyle(() => ({
    opacity: 0.35 + pulse.value * 0.45,
    transform: [{ scale: 1 + pulse.value * 0.08 }],
  }));
  return (
    <>
      <View
        pointerEvents="none"
        style={[
          styles.spotlightHole,
          {
            left: cx - r,
            top: cy - r,
            width: r * 2,
            height: r * 2,
            borderRadius: r,
          },
        ]}
      />
      <Animated.View
        pointerEvents="none"
        style={[
          styles.spotlightRing,
          {
            left: cx - r,
            top: cy - r,
            width: r * 2,
            height: r * 2,
            borderRadius: r,
          },
          ringStyle,
        ]}
      />
    </>
  );
};

// ----------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------

const OnboardingScreen: React.FC = () => {
  const insets = useSafeAreaInsets();
  const user = useUserStore((s) => s.user);
  const addCoins = useGameStore((s) => s.addCoins);
  const setSetting = useSettingsStore((s) => s.setSetting);

  const [stepIndex, setStepIndex] = useState(0);
  const [finishing, setFinishing] = useState(false);

  const assistantType: AssistantType = user?.assistant_type ?? 'bektur';
  const assistantName = assistantType === 'nazym' ? 'Назым' : 'Бектұр';

  const steps = useMemo(() => buildSteps(), []);
  const step = steps[stepIndex];

  // Card spring-in on step change.
  const cardScale = useSharedValue(0.85);
  const cardOpacity = useSharedValue(0);
  useEffect(() => {
    cardOpacity.value = 0;
    cardScale.value = 0.85;
    cardOpacity.value = withTiming(1, { duration: 220 });
    cardScale.value = withSpring(1, { damping: 12, stiffness: 220 });
  }, [stepIndex, cardOpacity, cardScale]);
  const cardStyle = useAnimatedStyle(() => ({
    opacity: cardOpacity.value,
    transform: [{ scale: cardScale.value }],
  }));

  const isFirst = stepIndex === 0;
  const isLast = stepIndex === steps.length - 1;

  const finishOnboarding = useCallback(async () => {
    if (finishing) return;
    setFinishing(true);
    try {
      await addCoins(WELCOME_COINS);
    } catch {
      // soft-fail — still let them in
    }
    // Toggling `onboarded` in the settings store causes RootNavigator to
    // re-render and switch to MainStackNavigator.
    await setSetting('onboarded', true);
  }, [finishing, addCoins, setSetting]);

  const handleNext = useCallback(async () => {
    if (!isLast) {
      setStepIndex((i) => i + 1);
      return;
    }
    await finishOnboarding();
  }, [isLast, finishOnboarding]);

  const handleBack = useCallback(() => {
    setStepIndex((i) => Math.max(0, i - 1));
  }, []);

  const handleSkip = useCallback(async () => {
    await finishOnboarding();
  }, [finishOnboarding]);

  if (!step) return null;

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={
          assistantType === 'nazym'
            ? (['#1A0A2E', '#3A1655', '#7B1545'] as readonly [string, string, string])
            : (['#0E1A4E', '#1A2A7E', '#2A3CA8'] as readonly [string, string, string])
        }
        style={StyleSheet.absoluteFill}
      />

      {/* Spotlight highlight */}
      <Spotlight cx={step.spotlight.cx} cy={step.spotlight.cy} r={step.spotlight.r} />

      {/* Skip in top-right */}
      <View style={[styles.topBar, { paddingTop: insets.top + spacing.sm }]}>
        <View style={styles.progressDots}>
          {steps.map((_, i) => (
            <View
              key={i}
              style={[
                styles.dot,
                i === stepIndex && styles.dotActive,
                i < stepIndex && styles.dotDone,
              ]}
            />
          ))}
        </View>
        <Pressable onPress={handleSkip} hitSlop={10}>
          <Text style={styles.skipText}>Өткізіп жіберу</Text>
        </Pressable>
      </View>

      {/* Step card */}
      <View style={styles.contentWrap} pointerEvents="box-none">
        <Animated.View style={[styles.card, cardStyle]}>
          <View style={styles.cardAvatarRow}>
            <AvatarDisplay assistantType={assistantType} action="idle" size={72} />
            <Text style={styles.cardEmoji}>{step.emoji}</Text>
          </View>
          <Text style={styles.cardTitle}>{step.titleKz}</Text>
          <Text style={styles.cardBody}>{step.bodyKz(assistantName)}</Text>

          {isLast ? (
            <View style={styles.rewardCard}>
              <Text style={styles.rewardLabel}>Сыйлық:</Text>
              <Text style={styles.rewardValue}>+{WELCOME_COINS} 🪙</Text>
              <Text style={styles.rewardHint}>Қош келдіңіз бонусы!</Text>
            </View>
          ) : null}

          <View style={styles.actions}>
            {!isFirst ? (
              <Pressable style={styles.backBtn} onPress={handleBack}>
                <Text style={styles.backText}>Алдыңғы</Text>
              </Pressable>
            ) : (
              <View style={{ flex: 1 }} />
            )}
            <Pressable
              style={[styles.nextBtn, finishing && styles.nextBtnDisabled]}
              onPress={() => void handleNext()}
              disabled={finishing}
            >
              <LinearGradient
                colors={
                  isLast
                    ? ([colors.gold, '#FFB84A'] as readonly [string, string])
                    : ([colors.primary, colors.secondary] as readonly [string, string])
                }
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
              {finishing ? (
                <ActivityIndicator color={colors.white} />
              ) : (
                <Text style={[styles.nextText, isLast && { color: colors.text }]}>
                  {isLast ? 'Бастау! 🎉' : 'Әрі қарай →'}
                </Text>
              )}
            </Pressable>
          </View>
        </Animated.View>
      </View>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Styles
// ----------------------------------------------------------------------------

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#1A1A4E',
  },
  // Spotlight is a translucent ring + circle that visually distinguishes the
  // focused region; we keep the rest of the screen dim with the gradient.
  spotlightHole: {
    position: 'absolute',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  spotlightRing: {
    position: 'absolute',
    borderWidth: 3,
    borderColor: colors.gold,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.sm,
    zIndex: 2,
  },
  progressDots: {
    flexDirection: 'row',
    gap: 6,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  dotActive: {
    backgroundColor: colors.gold,
    width: 24,
  },
  dotDone: {
    backgroundColor: 'rgba(255,215,0,0.5)',
  },
  skipText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
  },
  contentWrap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.xl + 20,
  },
  card: {
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderRadius: radius.lg,
    padding: spacing.lg,
    width: '100%',
    maxWidth: 420,
    gap: spacing.md,
    shadowColor: '#000',
    shadowOpacity: 0.4,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 8 },
    elevation: 14,
  },
  cardAvatarRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  cardEmoji: { fontSize: 44 },
  cardTitle: {
    color: colors.text,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
  },
  cardBody: {
    color: '#3A3A5E',
    fontSize: fontSize.md,
    lineHeight: 24,
    fontWeight: fontWeight.semibold,
  },
  rewardCard: {
    backgroundColor: 'rgba(255,215,0,0.12)',
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1.5,
    borderColor: colors.gold,
    alignItems: 'center',
    gap: 2,
  },
  rewardLabel: {
    color: colors.text,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  rewardValue: {
    color: colors.gold,
    fontSize: fontSize.huge,
    fontWeight: fontWeight.extrabold,
  },
  rewardHint: {
    color: 'rgba(0,0,0,0.6)',
    fontSize: fontSize.xs,
    fontWeight: fontWeight.semibold,
  },
  actions: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  backBtn: {
    flex: 1,
    height: 52,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.1)',
  },
  backText: { color: colors.text, fontSize: fontSize.md, fontWeight: fontWeight.bold },
  nextBtn: {
    flex: 2,
    height: 52,
    borderRadius: radius.md,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  nextBtnDisabled: { opacity: 0.6 },
  nextText: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
  },
});

export default OnboardingScreen;
