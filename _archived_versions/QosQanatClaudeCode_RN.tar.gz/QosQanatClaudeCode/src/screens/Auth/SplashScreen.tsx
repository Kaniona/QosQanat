import { LinearGradient } from 'expo-linear-gradient';
import React, { useEffect, useMemo } from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  withRepeat,
  withDelay,
  withSequence,
  Easing,
} from 'react-native-reanimated';

import Logo from '@/components/Logo';
import type { AuthScreenProps } from '@/navigation/types';
import { loadSessionUser } from '@/services/auth';
import { colors, fontSize, fontWeight, spacing } from '@/theme';

const KZ = {
  title: 'QosQanat',
  subtitle: 'Білімнің екі қанаты',
};

const BAR_WIDTH = 240;
const SPLASH_DURATION_MS = 2500;
const PARTICLE_COUNT = 8;
const SCREEN_W = Dimensions.get('window').width;
const SCREEN_H = Dimensions.get('window').height;

interface ParticleProps {
  left: number;
  delay: number;
  size: number;
  duration: number;
}

const Particle: React.FC<ParticleProps> = ({ left, delay, size, duration }) => {
  const translateY = useSharedValue(0);
  const opacity = useSharedValue(0);

  useEffect(() => {
    translateY.value = withDelay(
      delay,
      withRepeat(withTiming(-SCREEN_H * 0.4, { duration, easing: Easing.linear }), -1, false),
    );
    opacity.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(0.7, { duration: duration / 2 }),
          withTiming(0, { duration: duration / 2 }),
        ),
        -1,
        false,
      ),
    );
  }, [translateY, opacity, delay, duration]);

  const style = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
    opacity: opacity.value,
  }));

  return (
    <Animated.View
      pointerEvents="none"
      style={[styles.particle, { left, width: size, height: size, borderRadius: size / 2 }, style]}
    />
  );
};

const SplashScreen: React.FC<AuthScreenProps<'Splash'>> = ({ navigation }) => {
  const translateY = useSharedValue(80);
  const opacity = useSharedValue(0);
  const titleOpacity = useSharedValue(0);
  const subtitleOpacity = useSharedValue(0);
  const progress = useSharedValue(0);

  const particles = useMemo(
    () =>
      Array.from({ length: PARTICLE_COUNT }, (_, i) => ({
        id: i,
        left: Math.random() * SCREEN_W,
        delay: Math.random() * 1500,
        size: 4 + Math.random() * 6,
        duration: 3500 + Math.random() * 2500,
      })),
    [],
  );

  useEffect(() => {
    translateY.value = withSpring(0, { damping: 12, stiffness: 90, mass: 1 });
    opacity.value = withTiming(1, { duration: 700, easing: Easing.out(Easing.cubic) });
    titleOpacity.value = withDelay(350, withTiming(1, { duration: 600 }));
    subtitleOpacity.value = withDelay(700, withTiming(1, { duration: 600 }));
    progress.value = withDelay(
      200,
      withTiming(1, { duration: SPLASH_DURATION_MS - 400, easing: Easing.inOut(Easing.cubic) }),
    );

    const timer = setTimeout(async () => {
      try {
        const user = await loadSessionUser();
        if (user) {
          // Authenticated users without an assistant land on the picker;
          // authenticated users *with* an assistant who haven't finished
          // the welcome tour land on Onboarding. Fully-onboarded users do
          // not see AuthNavigator at all — RootNavigator routes them to
          // MainStackNavigator directly.
          if (!user.assistant_type) navigation.replace('AssistantSelect');
          else navigation.replace('Onboarding');
        } else {
          navigation.replace('Welcome');
        }
      } catch {
        navigation.replace('Welcome');
      }
    }, SPLASH_DURATION_MS);

    return () => { clearTimeout(timer); };
  }, [navigation, translateY, opacity, titleOpacity, subtitleOpacity, progress]);

  const logoStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
    opacity: opacity.value,
  }));

  const titleStyle = useAnimatedStyle(() => ({ opacity: titleOpacity.value }));
  const subtitleStyle = useAnimatedStyle(() => ({ opacity: subtitleOpacity.value }));
  const barFillStyle = useAnimatedStyle(() => ({ width: BAR_WIDTH * progress.value }));

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      />

      {particles.map((p) => (
        <Particle key={p.id} left={p.left} delay={p.delay} size={p.size} duration={p.duration} />
      ))}

      <View style={styles.content}>
        <Animated.View style={logoStyle}>
          <Logo size={160} />
        </Animated.View>
        <Animated.Text style={[styles.title, titleStyle]}>{KZ.title}</Animated.Text>
        <Animated.Text style={[styles.subtitle, subtitleStyle]}>{KZ.subtitle}</Animated.Text>
      </View>

      <View style={styles.barWrapper}>
        <View style={styles.barTrack}>
          <Animated.View style={[styles.barFill, barFillStyle]}>
            <LinearGradient
              colors={[colors.gold, '#FFB347'] as readonly [string, string]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={StyleSheet.absoluteFill}
            />
          </Animated.View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  content: {
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
  },
  title: {
    color: colors.white,
    fontSize: fontSize.huge,
    fontWeight: fontWeight.bold,
    marginTop: spacing.lg,
    letterSpacing: 1.5,
  },
  subtitle: {
    color: colors.white,
    fontSize: fontSize.md,
    marginTop: spacing.sm,
    fontStyle: 'italic',
    opacity: 0.85,
  },
  barWrapper: {
    position: 'absolute',
    bottom: spacing.xxl,
    width: BAR_WIDTH,
    alignSelf: 'center',
  },
  barTrack: {
    width: BAR_WIDTH,
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.18)',
    overflow: 'hidden',
  },
  barFill: {
    height: '100%',
    borderRadius: 3,
    overflow: 'hidden',
  },
  particle: {
    position: 'absolute',
    bottom: -20,
    backgroundColor: colors.white,
  },
});

export default SplashScreen;
