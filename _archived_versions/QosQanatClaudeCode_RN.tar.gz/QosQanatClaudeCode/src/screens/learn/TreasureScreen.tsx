import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

import { colors, fontSize, fontWeight, spacing } from '@/theme';

const TITLE_KZ = 'Қазына';

const TreasureScreen: React.FC = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{TITLE_KZ}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.background,
    padding: spacing.lg,
  },
  title: {
    color: colors.text,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.bold,
  },
});

export default TreasureScreen;
