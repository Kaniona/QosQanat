import { useFocusEffect } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import {
  flattenSubject,
  getSubject,
  type CurriculumModule,
  type CurriculumNode,
  type FlatNodeEntry,
} from '@/data/curriculum';
import type { AuthScreenProps } from '@/navigation/types';
import { getSubjectProgress, type TaskProgressRow } from '@/services/api';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

const KZ = {
  back: '←',
  lockedToast: '🔒 Алдыңғы тапсырманы аяқта!',
  start: 'Бастау →',
  rewardsTitle: 'Сыйақы',
  type: {
    lesson: '📘 Сабақ',
    quiz: '⚡ Тест',
    boss: '🐉 Босс',
    treasure: '💎 Қазына',
  },
  progress: (done: number, total: number) => `${done}/${total}`,
  noSubject: 'Пән табылмады',
};

type NodeVisualState = 'locked' | 'available' | 'current' | 'completed' | 'mastered';

interface NodePlacement {
  entry: FlatNodeEntry;
  state: NodeVisualState;
  bestScore: number;
}

const SCREEN_W = Dimensions.get('window').width;
const NODE_SIZE = 72;
const ROW_HEIGHT = 130;
const AMPLITUDE = Math.min(110, SCREEN_W * 0.22);

const TYPE_ICON: Record<CurriculumNode['type'], string> = {
  lesson: '📘',
  quiz: '⚡',
  boss: '🐉',
  treasure: '💎',
};

// ----------------------------------------------------------------------------
// Compute every node's visual state from the player's progress map.
// Progression rule: a node is unlocked when its immediate predecessor in the
// flat (subject-wide) order is completed/mastered. The first available node
// that hasn't been cleared is the "current" node.
// ----------------------------------------------------------------------------
const buildPlacements = (
  flat: readonly FlatNodeEntry[],
  progress: ReadonlyMap<string, TaskProgressRow>,
): readonly NodePlacement[] => {
  let foundCurrent = false;
  const out: NodePlacement[] = [];
  for (let i = 0; i < flat.length; i += 1) {
    const entry = flat[i];
    const row = progress.get(entry.node.id);
    const previousCleared =
      i === 0 ||
      (() => {
        const prev = progress.get(flat[i - 1].node.id);
        return prev?.status === 'completed' || prev?.status === 'mastered';
      })();

    let state: NodeVisualState;
    if (row?.status === 'mastered') {
      state = 'mastered';
    } else if (row?.status === 'completed') {
      state = 'completed';
    } else if (previousCleared) {
      state = foundCurrent ? 'available' : 'current';
      foundCurrent = true;
    } else {
      state = 'locked';
    }
    out.push({ entry, state, bestScore: row?.best_score ?? 0 });
  }
  return out;
};

// ----------------------------------------------------------------------------
// Connector — three small dots stacked vertically between two nodes.
// ----------------------------------------------------------------------------
interface ConnectorProps {
  fromX: number;
  toX: number;
}

const Connector: React.FC<ConnectorProps> = ({ fromX, toX }) => {
  const dots = [0.25, 0.5, 0.75];
  return (
    <View style={styles.connector} pointerEvents="none">
      {dots.map((t) => (
        <View
          key={t}
          style={[styles.connectorDot, { left: SCREEN_W / 2 + fromX + (toX - fromX) * t - 4 }]}
        />
      ))}
    </View>
  );
};

// ----------------------------------------------------------------------------
// Node circle. Renders the visual state and handles per-instance shake when
// the player taps a locked node. `shakeKey` is incremented from the parent —
// any change re-triggers the shake animation if the node id matches.
// ----------------------------------------------------------------------------
interface NodeCircleProps {
  placement: NodePlacement;
  offsetX: number;
  onPress: () => void;
  shakeKey: number;
  isShakeTarget: boolean;
  enterDelay: number;
}

const NodeCircle: React.FC<NodeCircleProps> = ({
  placement,
  offsetX,
  onPress,
  shakeKey,
  isShakeTarget,
  enterDelay,
}) => {
  const { entry, state } = placement;
  const press = useSharedValue(1);
  const shake = useSharedValue(0);
  const pulse = useSharedValue(0);
  const enter = useSharedValue(0);

  useEffect(() => {
    enter.value = withDelay(enterDelay, withSpring(1, { damping: 12, stiffness: 180 }));
  }, [enter, enterDelay]);

  useEffect(() => {
    if (state === 'available' || state === 'current') {
      pulse.value = withRepeat(
        withSequence(
          withTiming(1, { duration: 900, easing: Easing.inOut(Easing.quad) }),
          withTiming(0, { duration: 900, easing: Easing.inOut(Easing.quad) }),
        ),
        -1,
        false,
      );
    } else {
      pulse.value = withTiming(0, { duration: 200 });
    }
  }, [state, pulse]);

  useEffect(() => {
    if (!isShakeTarget || shakeKey === 0) return;
    shake.value = withSequence(
      withTiming(-12, { duration: 60 }),
      withTiming(12, { duration: 60 }),
      withTiming(-10, { duration: 60 }),
      withTiming(10, { duration: 60 }),
      withTiming(0, { duration: 60 }),
    );
  }, [shakeKey, isShakeTarget, shake]);

  const wrapStyle = useAnimatedStyle(() => ({
    opacity: enter.value,
    transform: [
      { translateX: shake.value },
      { scale: press.value * (state === 'current' ? 1 + pulse.value * 0.05 : 1) },
    ],
  }));

  const glowStyle = useAnimatedStyle(() => ({
    opacity: 0.6 * pulse.value,
    transform: [{ scale: 1 + pulse.value * 0.35 }],
  }));

  const palette = useMemo(() => {
    switch (state) {
      case 'locked':
        return {
          primary: '#4B5876',
          secondary: '#3A4863',
          text: 'rgba(255,255,255,0.5)',
          accent: 'transparent',
        };
      case 'available':
        return {
          primary: colors.primary,
          secondary: colors.secondary,
          text: colors.white,
          accent: 'rgba(255,255,255,0.4)',
        };
      case 'current':
        return {
          primary: colors.gold,
          secondary: '#FFB347',
          text: colors.text,
          accent: colors.gold,
        };
      case 'completed':
        return {
          primary: colors.success,
          secondary: '#3DDC97',
          text: colors.white,
          accent: 'transparent',
        };
      case 'mastered':
        return {
          primary: colors.gold,
          secondary: '#FFE066',
          text: colors.text,
          accent: colors.gold,
        };
    }
  }, [state]);

  const overlay =
    state === 'locked'
      ? '🔒'
      : state === 'completed'
        ? '✓'
        : state === 'mastered'
          ? '⭐'
          : TYPE_ICON[entry.node.type];

  return (
    <View style={[styles.nodeWrap, { transform: [{ translateX: offsetX }] }]}>
      <Animated.View style={[styles.nodeGlow, glowStyle, { backgroundColor: palette.primary }]} />
      <Pressable
        onPress={onPress}
        onPressIn={() => {
          press.value = withSpring(0.92, { damping: 14, stiffness: 240 });
        }}
        onPressOut={() => {
          press.value = withSpring(1, { damping: 12, stiffness: 200 });
        }}
      >
        <Animated.View
          style={[
            styles.nodeCircle,
            wrapStyle,
            { borderColor: palette.accent, borderWidth: palette.accent === 'transparent' ? 0 : 4 },
          ]}
        >
          <LinearGradient
            colors={[palette.primary, palette.secondary] as readonly [string, string]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <Text style={[styles.nodeIcon, { color: palette.text }]}>{overlay}</Text>
        </Animated.View>
      </Pressable>
      <Text style={styles.nodeLabel} numberOfLines={2}>
        {entry.node.titleKz}
      </Text>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Module banner — horizontal divider between consecutive modules.
// ----------------------------------------------------------------------------
interface ModuleDividerProps {
  module: CurriculumModule;
  subjectColor: string;
}

const ModuleDivider: React.FC<ModuleDividerProps> = ({ module, subjectColor }) => (
  <View style={styles.dividerWrap}>
    <View style={[styles.dividerBanner, { backgroundColor: subjectColor }]}>
      <Text style={styles.dividerGrade}>{`${module.grade}-сынып`}</Text>
      <Text style={styles.dividerTitle} numberOfLines={1}>
        {module.titleKz}
      </Text>
    </View>
  </View>
);

// ----------------------------------------------------------------------------
// Bottom sheet — slides up when an available/current/completed node is tapped.
// ----------------------------------------------------------------------------
interface BottomSheetProps {
  placement: NodePlacement | null;
  onClose: () => void;
  onStart: () => void;
  insetsBottom: number;
}

const SHEET_HEIGHT = 360;

const BottomSheet: React.FC<BottomSheetProps> = ({ placement, onClose, onStart, insetsBottom }) => {
  const translateY = useSharedValue(SHEET_HEIGHT);
  const backdrop = useSharedValue(0);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    if (placement) {
      setMounted(true);
      translateY.value = withSpring(0, { damping: 18, stiffness: 180 });
      backdrop.value = withTiming(1, { duration: 220 });
    } else if (mounted) {
      translateY.value = withTiming(SHEET_HEIGHT, {
        duration: 220,
        easing: Easing.in(Easing.cubic),
      });
      backdrop.value = withTiming(0, { duration: 220 });
      const t = setTimeout(() => { setMounted(false); }, 240);
      return () => { clearTimeout(t); };
    }
  }, [placement, translateY, backdrop, mounted]);

  const sheetStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
  }));
  const backdropStyle = useAnimatedStyle(() => ({
    opacity: backdrop.value * 0.6,
  }));

  if (!mounted || !placement) return null;
  const { entry, state, bestScore } = placement;
  const { node } = entry;
  const typeLabel = KZ.type[node.type];

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
      <Animated.View style={[styles.sheetBackdrop, backdropStyle]} pointerEvents="auto">
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
      </Animated.View>
      <Animated.View
        style={[
          styles.sheet,
          { paddingBottom: insetsBottom + spacing.lg, height: SHEET_HEIGHT + insetsBottom },
          sheetStyle,
        ]}
      >
        <View style={styles.sheetGrabber} />
        <View style={styles.sheetTypeRow}>
          <Text style={styles.sheetTypeBadge}>{typeLabel}</Text>
          {state === 'completed' || state === 'mastered' ? (
            <Text style={styles.sheetScore}>
              {state === 'mastered' ? '⭐ ' : '✓ '}
              {bestScore}%
            </Text>
          ) : null}
        </View>
        <Text style={styles.sheetTitle}>{node.titleKz}</Text>
        <Text style={styles.sheetDescription}>{node.descriptionKz}</Text>

        <View style={styles.sheetRewardCard}>
          <Text style={styles.sheetSection}>{KZ.rewardsTitle}</Text>
          <View style={styles.sheetRewards}>
            <RewardPill icon="✨" value={node.xpReward} label="XP" />
            <RewardPill icon="🪙" value={node.coinReward} label="" />
            <RewardPill icon="🔮" value={node.akylReward} label="" />
          </View>
        </View>

        <Pressable onPress={onStart} style={styles.startButton}>
          <LinearGradient
            colors={[colors.primary, colors.secondary] as readonly [string, string]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={StyleSheet.absoluteFill}
          />
          <Text style={styles.startText}>{KZ.start}</Text>
        </Pressable>
      </Animated.View>
    </View>
  );
};

interface RewardPillProps {
  icon: string;
  value: number;
  label: string;
}

const RewardPill: React.FC<RewardPillProps> = ({ icon, value, label }) => (
  <View style={styles.rewardPill}>
    <Text style={styles.rewardIcon}>{icon}</Text>
    <Text style={styles.rewardValue}>
      {value}
      {label ? ` ${label}` : ''}
    </Text>
  </View>
);

// ----------------------------------------------------------------------------
// Top toast — appears for ~2s when the player taps a locked node.
// ----------------------------------------------------------------------------
interface ToastProps {
  message: string | null;
  topInset: number;
}

const Toast: React.FC<ToastProps> = ({ message, topInset }) => {
  const opacity = useSharedValue(0);
  const translate = useSharedValue(-30);

  useEffect(() => {
    if (message) {
      opacity.value = withTiming(1, { duration: 180 });
      translate.value = withSpring(0, { damping: 14, stiffness: 180 });
    } else {
      opacity.value = withTiming(0, { duration: 180 });
      translate.value = withTiming(-30, { duration: 180 });
    }
  }, [message, opacity, translate]);

  const animStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateY: translate.value }],
  }));

  if (!message) return null;
  return (
    <Animated.View
      style={[styles.toast, { top: topInset + spacing.lg }, animStyle]}
      pointerEvents="none"
    >
      <Text style={styles.toastText}>{message}</Text>
    </Animated.View>
  );
};

// ----------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------

const MapScreen: React.FC<AuthScreenProps<'Map'>> = ({ route, navigation }) => {
  const { subjectId } = route.params;
  const insets = useSafeAreaInsets();
  const subject = useMemo(() => getSubject(subjectId), [subjectId]);
  const flat = useMemo(() => flattenSubject(subjectId), [subjectId]);

  const [progress, setProgress] = useState<ReadonlyMap<string, TaskProgressRow>>(new Map());
  const [sheetPlacement, setSheetPlacement] = useState<NodePlacement | null>(null);
  const [shakeKey, setShakeKey] = useState(0);
  const [shakeNodeId, setShakeNodeId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const loadProgress = useCallback(async () => {
    if (!subject) return;
    try {
      const map = await getSubjectProgress(subject.id);
      setProgress(map);
    } catch {
      // Show the map even if progress fails to load — every node falls back to
      // locked / first-available; the next focus will retry.
    }
  }, [subject]);

  useFocusEffect(
    useCallback(() => {
      void loadProgress();
    }, [loadProgress]),
  );

  const placements = useMemo(() => buildPlacements(flat, progress), [flat, progress]);

  const completedCount = useMemo(
    () => placements.filter((p) => p.state === 'completed' || p.state === 'mastered').length,
    [placements],
  );

  const handleNodePress = useCallback((placement: NodePlacement) => {
    if (placement.state === 'locked') {
      setShakeNodeId(placement.entry.node.id);
      setShakeKey((k) => k + 1);
      setToastMessage(KZ.lockedToast);
      return;
    }
    setSheetPlacement(placement);
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const t = setTimeout(() => { setToastMessage(null); }, 2000);
    return () => { clearTimeout(t); };
  }, [toastMessage]);

  const closeSheet = useCallback(() => { setSheetPlacement(null); }, []);

  const startNode = useCallback(() => {
    if (!sheetPlacement) return;
    const { entry } = sheetPlacement;
    setSheetPlacement(null);
    navigation.navigate('Task', {
      subjectId,
      moduleId: entry.module.id,
      nodeId: entry.node.id,
    });
  }, [navigation, sheetPlacement, subjectId]);

  if (!subject) {
    return (
      <View style={styles.root}>
        <Text style={styles.empty}>{KZ.noSubject}</Text>
      </View>
    );
  }

  // Iterate placements while inserting a ModuleDivider whenever the module id
  // changes from one node to the next.
  const elements: React.ReactNode[] = [];
  let lastModuleId: string | null = null;
  placements.forEach((placement, idx) => {
    const { entry, state } = placement;
    if (entry.module.id !== lastModuleId) {
      elements.push(
        <ModuleDivider
          key={`mod-${entry.module.id}`}
          module={entry.module}
          subjectColor={subject.color}
        />,
      );
      lastModuleId = entry.module.id;
    }
    // Serpentine layout: pattern repeats every 4 rows for a smoother curve.
    const phase = idx % 4;
    const offsetX =
      phase === 0
        ? -AMPLITUDE
        : phase === 1
          ? -AMPLITUDE * 0.4
          : phase === 2
            ? AMPLITUDE * 0.4
            : AMPLITUDE;
    const prevPhase = (idx - 1 + 4) % 4;
    const prevOffsetX =
      idx === 0
        ? offsetX
        : prevPhase === 0
          ? -AMPLITUDE
          : prevPhase === 1
            ? -AMPLITUDE * 0.4
            : prevPhase === 2
              ? AMPLITUDE * 0.4
              : AMPLITUDE;

    if (idx > 0 && entry.module.id === placements[idx - 1].entry.module.id) {
      elements.push(<Connector key={`con-${entry.node.id}`} fromX={prevOffsetX} toX={offsetX} />);
    }
    elements.push(
      <NodeCircle
        key={entry.node.id}
        placement={placement}
        offsetX={offsetX}
        onPress={() => { handleNodePress(placement); }}
        shakeKey={state === 'locked' && shakeNodeId === entry.node.id ? shakeKey : 0}
        isShakeTarget={shakeNodeId === entry.node.id}
        enterDelay={Math.min(idx * 60, 600)}
      />,
    );
  });

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      />

      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => { navigation.goBack(); }} hitSlop={10} style={styles.backButton}>
          <Text style={styles.backText}>{KZ.back}</Text>
        </Pressable>
        <View style={styles.headerCenter}>
          <Text style={styles.headerIcon}>{subject.icon}</Text>
          <Text style={styles.headerTitle} numberOfLines={1}>
            {subject.nameKz}
          </Text>
        </View>
        <View style={styles.progressBadge}>
          <Text style={styles.progressBadgeText}>{KZ.progress(completedCount, flat.length)}</Text>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={[styles.scrollContent, { paddingBottom: insets.bottom + 120 }]}
        showsVerticalScrollIndicator={false}
      >
        {elements}
      </ScrollView>

      <Toast message={toastMessage} topInset={insets.top} />
      <BottomSheet
        placement={sheetPlacement}
        onClose={closeSheet}
        onStart={startNode}
        insetsBottom={insets.bottom}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#1A1A4E',
  },
  empty: {
    color: colors.white,
    textAlign: 'center',
    marginTop: 100,
    fontSize: fontSize.lg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.md,
    gap: spacing.sm,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  backText: {
    color: colors.white,
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
    marginTop: -3,
  },
  headerCenter: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  headerIcon: {
    fontSize: 24,
  },
  headerTitle: {
    color: colors.white,
    fontSize: fontSize.xl,
    fontWeight: fontWeight.extrabold,
    flex: 1,
  },
  progressBadge: {
    backgroundColor: 'rgba(255,255,255,0.18)',
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 6,
    borderRadius: 999,
  },
  progressBadgeText: {
    color: colors.white,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
  },
  scrollContent: {
    paddingTop: spacing.md,
    alignItems: 'center',
  },
  nodeWrap: {
    width: SCREEN_W,
    height: ROW_HEIGHT,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nodeGlow: {
    position: 'absolute',
    width: NODE_SIZE + 24,
    height: NODE_SIZE + 24,
    borderRadius: (NODE_SIZE + 24) / 2,
    top: (ROW_HEIGHT - NODE_SIZE) / 2 - 12,
  },
  nodeCircle: {
    width: NODE_SIZE,
    height: NODE_SIZE,
    borderRadius: NODE_SIZE / 2,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  nodeIcon: {
    fontSize: 30,
    fontWeight: fontWeight.bold,
  },
  nodeLabel: {
    position: 'absolute',
    bottom: 4,
    color: 'rgba(255,255,255,0.85)',
    fontSize: 11,
    fontWeight: fontWeight.semibold,
    textAlign: 'center',
    maxWidth: 130,
  },
  connector: {
    width: SCREEN_W,
    height: 28,
    position: 'relative',
  },
  connectorDot: {
    position: 'absolute',
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.35)',
    top: 10,
  },
  dividerWrap: {
    width: SCREEN_W,
    paddingHorizontal: spacing.md,
    marginVertical: spacing.md,
  },
  dividerBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm + 2,
    borderRadius: radius.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 3,
  },
  dividerGrade: {
    color: colors.white,
    backgroundColor: 'rgba(0,0,0,0.25)',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 999,
    fontSize: fontSize.xs,
    fontWeight: fontWeight.bold,
  },
  dividerTitle: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
    flex: 1,
  },
  sheetBackdrop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#000',
  },
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.white,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    padding: spacing.lg,
    gap: spacing.sm,
  },
  sheetGrabber: {
    alignSelf: 'center',
    width: 44,
    height: 5,
    borderRadius: 3,
    backgroundColor: colors.border,
    marginBottom: spacing.sm,
  },
  sheetTypeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  sheetTypeBadge: {
    backgroundColor: colors.background,
    color: colors.text,
    fontWeight: fontWeight.bold,
    fontSize: fontSize.sm,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
  },
  sheetScore: {
    color: colors.success,
    fontWeight: fontWeight.extrabold,
    fontSize: fontSize.sm,
  },
  sheetTitle: {
    color: colors.text,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
  },
  sheetDescription: {
    color: colors.textLight,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
    lineHeight: 20,
  },
  sheetRewardCard: {
    backgroundColor: colors.background,
    borderRadius: radius.md,
    padding: spacing.md,
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  sheetSection: {
    color: colors.text,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
  },
  sheetRewards: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  rewardPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.white,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: colors.border,
  },
  rewardIcon: {
    fontSize: 14,
  },
  rewardValue: {
    color: colors.text,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
  },
  startButton: {
    height: 56,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    marginTop: spacing.md,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
    elevation: 5,
  },
  startText: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
  },
  toast: {
    position: 'absolute',
    alignSelf: 'center',
    backgroundColor: 'rgba(26, 26, 78, 0.95)',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm + 2,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  toastText: {
    color: colors.white,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
  },
});

export default MapScreen;
