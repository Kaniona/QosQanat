import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import Svg, { Line } from 'react-native-svg';

import type { MatchPair, MatchPairsQuestion } from '@/data/curriculum';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

import { XpFloat, type AnswerState, type TaskTypeCallbacks } from './feedback';

interface Props extends TaskTypeCallbacks {
  question: MatchPairsQuestion;
}

const ROW_HEIGHT = 56;
const ROW_GAP = 8;
const MID_GAP = 30;

// Deterministic shuffle that always produces the same scramble per question.
// We seed off the question id so the layout doesn't reshuffle if the screen
// re-renders before the player answers.
const shuffle = <T,>(items: readonly T[], seed: string): T[] => {
  const arr = [...items];
  let h = 0;
  for (let i = 0; i < seed.length; i += 1) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  for (let i = arr.length - 1; i > 0; i -= 1) {
    h = (h * 1103515245 + 12345) >>> 0;
    const j = h % (i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
};

const MatchPairs: React.FC<Props> = ({ question, onAnswer }) => {
  const leftItems = question.pairs;
  const rightItems = useMemo<readonly MatchPair[]>(
    () => shuffle(question.pairs, question.id),
    [question],
  );

  const [pairs, setPairs] = useState<Map<string, string>>(new Map()); // leftId -> rightId
  const [selectedLeft, setSelectedLeft] = useState<string | null>(null);
  const [selectedRight, setSelectedRight] = useState<string | null>(null);
  const [answerState, setAnswerState] = useState<AnswerState>('idle');

  const [containerWidth, setContainerWidth] = useState(0);
  const colWidth = containerWidth > 0 ? (containerWidth - MID_GAP) / 2 : 0;

  const rightIndexById = useMemo(() => {
    const m = new Map<string, number>();
    rightItems.forEach((r, i) => m.set(r.id, i));
    return m;
  }, [rightItems]);

  // Resolve a single ambiguity: tapping the same item twice deselects it,
  // tapping a paired item clears its pair, tapping a left while a right is
  // already chosen forms a pair (and vice-versa).
  const onLeftPress = (id: string) => {
    if (answerState !== 'idle') return;
    if (pairs.has(id)) {
      const next = new Map(pairs);
      next.delete(id);
      setPairs(next);
      return;
    }
    if (selectedLeft === id) {
      setSelectedLeft(null);
      return;
    }
    if (selectedRight !== null) {
      const next = new Map(pairs);
      // If the right side is already paired, free it first.
      for (const [lid, rid] of next.entries()) {
        if (rid === selectedRight) next.delete(lid);
      }
      next.set(id, selectedRight);
      setPairs(next);
      setSelectedLeft(null);
      setSelectedRight(null);
      return;
    }
    setSelectedLeft(id);
  };

  const onRightPress = (id: string) => {
    if (answerState !== 'idle') return;
    const pairedLeft = [...pairs.entries()].find(([, rid]) => rid === id)?.[0];
    if (pairedLeft !== undefined) {
      const next = new Map(pairs);
      next.delete(pairedLeft);
      setPairs(next);
      return;
    }
    if (selectedRight === id) {
      setSelectedRight(null);
      return;
    }
    if (selectedLeft !== null) {
      const next = new Map(pairs);
      next.set(selectedLeft, id);
      setPairs(next);
      setSelectedLeft(null);
      setSelectedRight(null);
      return;
    }
    setSelectedRight(id);
  };

  const evaluatedRef = useRef(false);
  useEffect(() => {
    if (evaluatedRef.current) return;
    if (pairs.size !== leftItems.length) return;
    evaluatedRef.current = true;
    const allCorrect = [...pairs.entries()].every(([leftId, rightId]) => leftId === rightId);
    setAnswerState(allCorrect ? 'correct' : 'wrong');
    onAnswer(allCorrect);
  }, [pairs, leftItems.length, onAnswer]);

  const lineColor =
    answerState === 'correct'
      ? colors.success
      : answerState === 'wrong'
        ? colors.danger
        : colors.primary;

  const totalHeight = leftItems.length * (ROW_HEIGHT + ROW_GAP);

  return (
    <View style={styles.root}>
      <Text style={styles.label}>{question.promptKz}</Text>

      <View
        style={styles.boardWrap}
        onLayout={(e) => { setContainerWidth(e.nativeEvent.layout.width); }}
      >
        {containerWidth > 0 ? (
          <Svg
            width={containerWidth}
            height={totalHeight}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          >
            {[...pairs.entries()].map(([leftId, rightId]) => {
              const leftIdx = leftItems.findIndex((l) => l.id === leftId);
              const rightIdx = rightIndexById.get(rightId);
              if (leftIdx < 0 || rightIdx === undefined) return null;
              const x1 = colWidth;
              const y1 = leftIdx * (ROW_HEIGHT + ROW_GAP) + ROW_HEIGHT / 2;
              const x2 = colWidth + MID_GAP;
              const y2 = rightIdx * (ROW_HEIGHT + ROW_GAP) + ROW_HEIGHT / 2;
              const correctIfChecked = answerState === 'idle' ? null : leftId === rightId;
              const stroke =
                correctIfChecked === null
                  ? lineColor
                  : correctIfChecked
                    ? colors.success
                    : colors.danger;
              return (
                <Line
                  key={`${leftId}-${rightId}`}
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke={stroke}
                  strokeWidth={4}
                  strokeLinecap="round"
                />
              );
            })}
          </Svg>
        ) : null}

        <View style={styles.column}>
          {leftItems.map((item) => (
            <ItemRow
              key={`l-${item.id}`}
              text={item.leftKz}
              selected={selectedLeft === item.id}
              paired={pairs.has(item.id)}
              disabled={answerState !== 'idle'}
              answerState={answerState}
              isCorrectlyPaired={pairs.get(item.id) === item.id}
              onPress={() => { onLeftPress(item.id); }}
            />
          ))}
        </View>

        <View style={{ width: MID_GAP }} />

        <View style={styles.column}>
          {rightItems.map((item) => {
            const isPaired = [...pairs.values()].includes(item.id);
            const pairedLeftId = [...pairs.entries()].find(([, rid]) => rid === item.id)?.[0];
            return (
              <ItemRow
                key={`r-${item.id}`}
                text={item.rightKz}
                selected={selectedRight === item.id}
                paired={isPaired}
                disabled={answerState !== 'idle'}
                answerState={answerState}
                isCorrectlyPaired={pairedLeftId === item.id}
                onPress={() => { onRightPress(item.id); }}
              />
            );
          })}
        </View>
      </View>

      <XpFloat visible={answerState === 'correct'} amount={5} />
    </View>
  );
};

interface ItemRowProps {
  text: string;
  selected: boolean;
  paired: boolean;
  isCorrectlyPaired: boolean;
  answerState: AnswerState;
  disabled: boolean;
  onPress: () => void;
}

const ItemRow: React.FC<ItemRowProps> = ({
  text,
  selected,
  paired,
  isCorrectlyPaired,
  answerState,
  disabled,
  onPress,
}) => {
  const scale = useSharedValue(1);
  const animStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  let bg: string = colors.white;
  let border: string = colors.border;
  let text_color: string = colors.text;
  if (paired) {
    if (answerState === 'correct' || (answerState === 'wrong' && isCorrectlyPaired)) {
      bg = colors.success;
      border = colors.success;
      text_color = colors.white;
    } else if (answerState === 'wrong') {
      bg = colors.danger;
      border = colors.danger;
      text_color = colors.white;
    } else {
      bg = 'rgba(74, 108, 247, 0.10)';
      border = colors.primary;
      text_color = colors.primary;
    }
  } else if (selected) {
    bg = 'rgba(123, 97, 255, 0.18)';
    border = colors.secondary;
    text_color = colors.secondary;
  }

  return (
    <Pressable
      onPress={disabled ? undefined : onPress}
      onPressIn={() => {
        if (!disabled) scale.value = withSpring(0.95, { damping: 14, stiffness: 240 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 12, stiffness: 200 });
      }}
    >
      <Animated.View style={[styles.row, { backgroundColor: bg, borderColor: border }, animStyle]}>
        <Text style={[styles.rowText, { color: text_color }]} numberOfLines={2}>
          {text}
        </Text>
      </Animated.View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    gap: spacing.md,
  },
  label: {
    color: colors.text,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.bold,
  },
  boardWrap: {
    flexDirection: 'row',
    position: 'relative',
  },
  column: {
    flex: 1,
    gap: ROW_GAP,
  },
  row: {
    height: ROW_HEIGHT,
    borderRadius: radius.md,
    borderWidth: 2,
    paddingHorizontal: spacing.sm + 2,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  rowText: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
    textAlign: 'center',
  },
});

export default MatchPairs;
