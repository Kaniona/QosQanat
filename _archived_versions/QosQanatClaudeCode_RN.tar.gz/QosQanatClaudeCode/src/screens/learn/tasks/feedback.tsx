import React, { useEffect } from 'react';
import { StyleSheet, Text } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withSpring,
  withTiming,
  Easing,
} from 'react-native-reanimated';

import { colors, fontSize, fontWeight } from '@/theme';

// Floating "+N XP" chip used by every task type when the player answers a
// question correctly. Positioned absolutely by the caller.
export const XpFloat: React.FC<{ amount?: number; visible: boolean }> = ({
  amount = 5,
  visible,
}) => {
  const translateY = useSharedValue(0);
  const opacity = useSharedValue(0);
  const scale = useSharedValue(0.6);

  useEffect(() => {
    if (!visible) return;
    translateY.value = withTiming(-60, { duration: 700, easing: Easing.out(Easing.cubic) });
    opacity.value = withSequence(
      withTiming(1, { duration: 200 }),
      withTiming(1, { duration: 300 }),
      withTiming(0, { duration: 200 }),
    );
    scale.value = withSpring(1, { damping: 10, stiffness: 200 });
  }, [visible, translateY, opacity, scale]);

  const animStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateY: translateY.value }, { scale: scale.value }],
  }));

  if (!visible) return null;
  return (
    <Animated.View style={[styles.xpFloat, animStyle]} pointerEvents="none">
      <Text style={styles.xpFloatText}>+{amount} XP ✨</Text>
    </Animated.View>
  );
};

// Background card flash — green or red — that the task types stretch behind
// their answer surface. Returns a stable animated style.
export const useFeedbackBgStyle = (state: 'idle' | 'correct' | 'wrong') => {
  const opacity = useSharedValue(0);

  useEffect(() => {
    if (state === 'idle') {
      opacity.value = withTiming(0, { duration: 180 });
      return;
    }
    opacity.value = withSequence(
      withTiming(1, { duration: 160 }),
      withTiming(0.85, { duration: 400 }),
    );
  }, [state, opacity]);

  return useAnimatedStyle(() => ({
    opacity: opacity.value,
  }));
};

const styles = StyleSheet.create({
  xpFloat: {
    position: 'absolute',
    alignSelf: 'center',
    top: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: colors.success,
    shadowColor: colors.success,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
    elevation: 5,
  },
  xpFloatText: {
    color: colors.white,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
  },
});

export type AnswerState = 'idle' | 'correct' | 'wrong';

export interface TaskTypeCallbacks {
  onAnswer: (correct: boolean) => void;
}
