import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';

import type { MultipleChoiceQuestion } from '@/data/curriculum';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

import { XpFloat, type AnswerState, type TaskTypeCallbacks } from './feedback';

interface Props extends TaskTypeCallbacks {
  question: MultipleChoiceQuestion;
}

// Per-option state on top of the question's idle/correct/wrong gate. After the
// player picks an option we mark the picked one and (on wrong) reveal the
// correct one, then disable all further input.
type OptionVisualState = 'idle' | 'selected-correct' | 'selected-wrong' | 'revealed-correct';

const OPTION_PALETTE: Record<OptionVisualState, { bg: string; border: string; text: string }> = {
  idle: { bg: colors.white, border: colors.border, text: colors.text },
  'selected-correct': { bg: colors.success, border: '#3DDC97', text: colors.white },
  'selected-wrong': { bg: colors.danger, border: '#FF6B7B', text: colors.white },
  'revealed-correct': { bg: '#E8FBF3', border: colors.success, text: colors.success },
};

interface OptionProps {
  label: string;
  state: OptionVisualState;
  disabled: boolean;
  onPress: () => void;
}

const Option: React.FC<OptionProps> = ({ label, state, disabled, onPress }) => {
  const scale = useSharedValue(1);
  const cardStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));
  const palette = OPTION_PALETTE[state];

  return (
    <Pressable
      onPress={disabled ? undefined : onPress}
      onPressIn={() => {
        if (!disabled) scale.value = withSpring(0.96, { damping: 14, stiffness: 240 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 12, stiffness: 200 });
      }}
      style={styles.optionWrap}
    >
      <Animated.View
        style={[
          styles.option,
          { backgroundColor: palette.bg, borderColor: palette.border },
          cardStyle,
        ]}
      >
        <Text style={[styles.optionText, { color: palette.text }]}>{label}</Text>
        {state === 'selected-correct' || state === 'revealed-correct' ? (
          <Text style={[styles.optionBadge, { color: palette.text }]}>✓</Text>
        ) : null}
        {state === 'selected-wrong' ? (
          <Text style={[styles.optionBadge, { color: palette.text }]}>✗</Text>
        ) : null}
      </Animated.View>
    </Pressable>
  );
};

const MultipleChoice: React.FC<Props> = ({ question, onAnswer }) => {
  const [answerState, setAnswerState] = useState<AnswerState>('idle');
  const [pickedIndex, setPickedIndex] = useState<number | null>(null);

  const handlePick = (idx: number) => {
    if (answerState !== 'idle') return;
    const correct = idx === question.correctIndex;
    setPickedIndex(idx);
    setAnswerState(correct ? 'correct' : 'wrong');
    onAnswer(correct);
  };

  const renderOption = (label: string, idx: number) => {
    let state: OptionVisualState = 'idle';
    if (pickedIndex === idx) {
      state = answerState === 'correct' ? 'selected-correct' : 'selected-wrong';
    } else if (answerState === 'wrong' && idx === question.correctIndex) {
      state = 'revealed-correct';
    }
    return (
      <Option
        key={`opt-${idx}`}
        label={label}
        state={state}
        disabled={answerState !== 'idle'}
        onPress={() => { handlePick(idx); }}
      />
    );
  };

  return (
    <View style={styles.root}>
      <Text style={styles.question}>{question.questionKz}</Text>
      <View style={styles.options}>
        {question.options.map((label, idx) => renderOption(label, idx))}
      </View>
      {question.explanationKz && answerState !== 'idle' ? (
        <Text style={styles.explanation}>{question.explanationKz}</Text>
      ) : null}
      <XpFloat visible={answerState === 'correct'} amount={5} />
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    gap: spacing.lg,
  },
  question: {
    color: colors.text,
    fontSize: fontSize.xl,
    fontWeight: fontWeight.extrabold,
    lineHeight: 30,
  },
  options: {
    gap: spacing.sm + 2,
  },
  optionWrap: {
    width: '100%',
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 2,
    minHeight: 60,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 1,
  },
  optionText: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
    flex: 1,
  },
  optionBadge: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.extrabold,
    marginLeft: spacing.sm,
  },
  explanation: {
    color: colors.textLight,
    fontSize: fontSize.sm,
    fontStyle: 'italic',
    lineHeight: 20,
  },
});

export default MultipleChoice;
