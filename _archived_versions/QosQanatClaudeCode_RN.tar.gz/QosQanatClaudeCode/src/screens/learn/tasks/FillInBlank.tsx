import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';

import type { FillInBlankQuestion } from '@/data/curriculum';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

import { XpFloat, type AnswerState, type TaskTypeCallbacks } from './feedback';

interface Props extends TaskTypeCallbacks {
  question: FillInBlankQuestion;
}

// The sentence is split on the literal "___" placeholder. The blank slot is
// drawn as a pill the player fills by tapping a word-bank chip below.
const splitSentence = (sentenceKz: string): { before: string; after: string } => {
  const idx = sentenceKz.indexOf('___');
  if (idx === -1) return { before: sentenceKz, after: '' };
  return {
    before: sentenceKz.slice(0, idx),
    after: sentenceKz.slice(idx + 3),
  };
};

const FillInBlank: React.FC<Props> = ({ question, onAnswer }) => {
  const [picked, setPicked] = useState<string | null>(null);
  const [answerState, setAnswerState] = useState<AnswerState>('idle');
  const { before, after } = useMemo(() => splitSentence(question.sentenceKz), [question]);

  const handlePick = (word: string) => {
    if (answerState !== 'idle') return;
    const correct = word === question.correctWord;
    setPicked(word);
    setAnswerState(correct ? 'correct' : 'wrong');
    onAnswer(correct);
  };

  return (
    <View style={styles.root}>
      <Text style={styles.label}>Бос орынды толтыр</Text>
      <View style={styles.sentenceWrap}>
        <Text style={styles.sentence}>
          {before}
          <Blank
            text={picked}
            state={answerState}
            correctWord={question.correctWord}
            isPicked={picked !== null}
          />
          {after}
        </Text>
      </View>

      <View style={styles.bank}>
        {question.bank.map((word) => (
          <BankChip
            key={word}
            word={word}
            isPicked={picked === word}
            answerState={answerState}
            isCorrectWord={word === question.correctWord}
            disabled={answerState !== 'idle'}
            onPress={() => { handlePick(word); }}
          />
        ))}
      </View>

      {question.explanationKz && answerState !== 'idle' ? (
        <Text style={styles.explanation}>{question.explanationKz}</Text>
      ) : null}

      <XpFloat visible={answerState === 'correct'} amount={5} />
    </View>
  );
};

interface BlankProps {
  text: string | null;
  state: AnswerState;
  correctWord: string;
  isPicked: boolean;
}

const Blank: React.FC<BlankProps> = ({ text, state, correctWord }) => {
  let bg = 'rgba(74, 108, 247, 0.10)';
  let color: string = colors.primary;
  let label = text ?? '_____';
  if (state === 'correct') {
    bg = 'rgba(0, 196, 140, 0.18)';
    color = colors.success;
  } else if (state === 'wrong') {
    bg = 'rgba(255, 71, 87, 0.18)';
    color = colors.danger;
    // On wrong answer we still show what the player picked, but a follow-up
    // hint underneath surfaces the right word — see hint rendering below.
    label = `${text ?? ''}  →  ${correctWord}`;
  }
  return <Text style={[styles.blank, { backgroundColor: bg, color }]}>{label}</Text>;
};

interface BankChipProps {
  word: string;
  isPicked: boolean;
  isCorrectWord: boolean;
  answerState: AnswerState;
  disabled: boolean;
  onPress: () => void;
}

const BankChip: React.FC<BankChipProps> = ({
  word,
  isPicked,
  isCorrectWord,
  answerState,
  disabled,
  onPress,
}) => {
  const scale = useSharedValue(1);
  const animStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  let bg: string = colors.white;
  let border: string = colors.border;
  let text: string = colors.text;
  if (isPicked) {
    if (answerState === 'correct') {
      bg = colors.success;
      border = colors.success;
      text = colors.white;
    } else if (answerState === 'wrong') {
      bg = colors.danger;
      border = colors.danger;
      text = colors.white;
    }
  } else if (answerState === 'wrong' && isCorrectWord) {
    bg = 'rgba(0, 196, 140, 0.18)';
    border = colors.success;
    text = colors.success;
  }

  return (
    <Pressable
      onPress={disabled ? undefined : onPress}
      onPressIn={() => {
        if (!disabled) scale.value = withSpring(0.92, { damping: 14, stiffness: 240 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 12, stiffness: 200 });
      }}
    >
      <Animated.View style={[styles.chip, { backgroundColor: bg, borderColor: border }, animStyle]}>
        <Text style={[styles.chipText, { color: text }]}>{word}</Text>
      </Animated.View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    gap: spacing.lg,
  },
  label: {
    color: colors.textLight,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  sentenceWrap: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    padding: spacing.lg,
    minHeight: 100,
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 1,
  },
  sentence: {
    color: colors.text,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semibold,
    lineHeight: 30,
  },
  blank: {
    paddingHorizontal: 10,
    paddingVertical: 2,
    borderRadius: 8,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
    overflow: 'hidden',
  },
  bank: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  chip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm + 2,
    borderRadius: 999,
    borderWidth: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  chipText: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
  },
  explanation: {
    color: colors.textLight,
    fontSize: fontSize.sm,
    fontStyle: 'italic',
    lineHeight: 20,
  },
});

export default FillInBlank;
