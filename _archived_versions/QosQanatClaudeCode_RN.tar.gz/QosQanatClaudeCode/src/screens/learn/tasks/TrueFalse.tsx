import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, {
  interpolateColor,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
  Easing,
} from 'react-native-reanimated';

import type { TrueFalseQuestion } from '@/data/curriculum';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

import { XpFloat, type AnswerState, type TaskTypeCallbacks } from './feedback';

interface Props extends TaskTypeCallbacks {
  question: TrueFalseQuestion;
}

const KZ = { yes: '✅ Дұрыс', no: '❌ Қате' };

const TrueFalse: React.FC<Props> = ({ question, onAnswer }) => {
  const [answerState, setAnswerState] = useState<AnswerState>('idle');
  const [picked, setPicked] = useState<boolean | null>(null);

  // Card colour smoothly interpolates from neutral to green / red.
  const colourPhase = useSharedValue(0);

  const handlePick = (value: boolean) => {
    if (answerState !== 'idle') return;
    const correct = value === question.isTrue;
    setPicked(value);
    setAnswerState(correct ? 'correct' : 'wrong');
    colourPhase.value = withTiming(correct ? 1 : -1, {
      duration: 350,
      easing: Easing.out(Easing.cubic),
    });
    onAnswer(correct);
  };

  const cardStyle = useAnimatedStyle(() => ({
    backgroundColor: interpolateColor(
      colourPhase.value,
      [-1, 0, 1],
      [colors.danger, colors.white, colors.success],
    ),
    borderColor: interpolateColor(
      colourPhase.value,
      [-1, 0, 1],
      ['#FF6B7B', colors.border, '#3DDC97'],
    ),
  }));

  const textStyle = useAnimatedStyle(() => ({
    color: interpolateColor(
      colourPhase.value,
      [-1, 0, 1],
      [colors.white, colors.text, colors.white],
    ),
  }));

  return (
    <View style={styles.root}>
      <Text style={styles.label}>Шындық па?</Text>
      <Animated.View style={[styles.statementCard, cardStyle]}>
        <Animated.Text style={[styles.statementText, textStyle]}>
          {question.statementKz}
        </Animated.Text>
      </Animated.View>

      <View style={styles.buttonRow}>
        <ChoiceButton
          label={KZ.yes}
          color={colors.success}
          picked={picked === true}
          answerState={answerState}
          correctChoice={question.isTrue}
          disabled={answerState !== 'idle'}
          onPress={() => { handlePick(true); }}
        />
        <ChoiceButton
          label={KZ.no}
          color={colors.danger}
          picked={picked === false}
          answerState={answerState}
          correctChoice={!question.isTrue}
          disabled={answerState !== 'idle'}
          onPress={() => { handlePick(false); }}
        />
      </View>

      {question.explanationKz && answerState !== 'idle' ? (
        <Text style={styles.explanation}>{question.explanationKz}</Text>
      ) : null}

      <XpFloat visible={answerState === 'correct'} amount={5} />
    </View>
  );
};

interface ChoiceButtonProps {
  label: string;
  color: string;
  picked: boolean;
  correctChoice: boolean;
  answerState: AnswerState;
  disabled: boolean;
  onPress: () => void;
}

const ChoiceButton: React.FC<ChoiceButtonProps> = ({
  label,
  color,
  picked,
  correctChoice,
  answerState,
  disabled,
  onPress,
}) => {
  const scale = useSharedValue(1);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  // Background: if picked, paint with the side colour; if not picked and answer
  // resolved wrong + this is the correct side, faintly hint at it.
  const reveal = !picked && answerState === 'wrong' && correctChoice;
  const bg = picked ? color : reveal ? 'rgba(0, 196, 140, 0.15)' : colors.white;
  const borderColor = picked ? color : reveal ? colors.success : colors.border;
  const textColor = picked ? colors.white : reveal ? colors.success : colors.text;

  return (
    <Pressable
      onPress={disabled ? undefined : onPress}
      onPressIn={() => {
        if (!disabled) scale.value = withSpring(0.94, { damping: 14, stiffness: 240 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 12, stiffness: 200 });
      }}
      style={styles.buttonPressable}
    >
      <Animated.View style={[styles.choiceButton, { backgroundColor: bg, borderColor }, style]}>
        <Text style={[styles.choiceText, { color: textColor }]}>{label}</Text>
      </Animated.View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    gap: spacing.lg,
  },
  label: {
    color: colors.textLight,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  statementCard: {
    padding: spacing.lg,
    borderRadius: radius.lg,
    borderWidth: 2,
    minHeight: 120,
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 2,
  },
  statementText: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
    lineHeight: 30,
    textAlign: 'center',
  },
  buttonRow: {
    flexDirection: 'row',
    gap: spacing.sm + 2,
  },
  buttonPressable: {
    flex: 1,
  },
  choiceButton: {
    height: 64,
    borderRadius: radius.md,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  choiceText: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
  },
  explanation: {
    color: colors.textLight,
    fontSize: fontSize.sm,
    fontStyle: 'italic',
    lineHeight: 20,
  },
});

export default TrueFalse;
