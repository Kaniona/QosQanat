import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AvatarDisplay, { type AvatarAction } from '@/components/Avatar/AvatarDisplay';
import { getNode, getSubject, type Question } from '@/data/curriculum';
import type { AuthScreenProps } from '@/navigation/types';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

import FillInBlank from './tasks/FillInBlank';
import MatchPairs from './tasks/MatchPairs';
import MultipleChoice from './tasks/MultipleChoice';
import TrueFalse from './tasks/TrueFalse';


const KZ = {
  close: '✕',
  confirmTitle: 'Тапсырмадан шығу?',
  confirmBody: 'Үлгерген XP сақталмайды.',
  cancel: 'Болдырмау',
  confirm: 'Шығу',
  noNode: 'Тапсырма табылмады',
  noQuestions: 'Сұрақтар жоқ',
};

const CORRECT_DELAY_MS = 800;
const WRONG_DELAY_MS = 1200;
const TOTAL_HEARTS = 3;

const TaskScreen: React.FC<AuthScreenProps<'Task'>> = ({ route, navigation }) => {
  const { subjectId, moduleId, nodeId } = route.params;
  const insets = useSafeAreaInsets();
  const user = useUserStore((s) => s.user);

  const subject = useMemo(() => getSubject(subjectId), [subjectId]);
  const node = useMemo(() => getNode(subjectId, moduleId, nodeId), [subjectId, moduleId, nodeId]);
  const questions: readonly Question[] = node?.questions ?? [];
  const total = questions.length;

  const [idx, setIdx] = useState(0);
  const [hearts, setHearts] = useState(TOTAL_HEARTS);
  const [correctCount, setCorrectCount] = useState(0);
  const [avatarAction, setAvatarAction] = useState<AvatarAction>('idle');
  const transitioningRef = useRef(false);

  const progress = useSharedValue(0);
  useEffect(() => {
    if (total > 0) {
      progress.value = withTiming(idx / total, { duration: 400, easing: Easing.out(Easing.cubic) });
    }
  }, [idx, total, progress]);

  const fillStyle = useAnimatedStyle(() => ({
    width: `${progress.value * 100}%`,
  }));

  const finish = useCallback(
    (finalCorrect: number, finalHearts: number) => {
      const scorePercent = total > 0 ? Math.round((finalCorrect / total) * 100) : 0;
      navigation.replace('Result', {
        subjectId,
        moduleId,
        nodeId,
        scorePercent,
        correctCount: finalCorrect,
        totalQuestions: total,
        heartsLeft: finalHearts,
      });
    },
    [navigation, subjectId, moduleId, nodeId, total],
  );

  const handleAnswer = useCallback(
    (isCorrect: boolean) => {
      if (transitioningRef.current) return;
      transitioningRef.current = true;

      const newHearts = isCorrect ? hearts : hearts - 1;
      const newCorrect = isCorrect ? correctCount + 1 : correctCount;
      const isLast = idx + 1 >= total;
      const failed = newHearts <= 0;
      const delay = isCorrect ? CORRECT_DELAY_MS : WRONG_DELAY_MS;

      setAvatarAction(isCorrect ? 'celebrate' : 'sad');
      if (!isCorrect) setHearts(newHearts);
      setCorrectCount(newCorrect);

      setTimeout(() => {
        transitioningRef.current = false;
        setAvatarAction('idle');
        if (failed || isLast) {
          finish(newCorrect, newHearts);
        } else {
          setIdx((i) => i + 1);
        }
      }, delay);
    },
    [hearts, correctCount, idx, total, finish],
  );

  const requestExit = useCallback(() => {
    Alert.alert(
      KZ.confirmTitle,
      KZ.confirmBody,
      [
        { text: KZ.cancel, style: 'cancel' },
        { text: KZ.confirm, style: 'destructive', onPress: () => { navigation.goBack(); } },
      ],
      { cancelable: true },
    );
  }, [navigation]);

  if (!node || !subject) {
    return (
      <View style={styles.centered}>
        <Text style={styles.errorText}>{KZ.noNode}</Text>
      </View>
    );
  }

  if (total === 0) {
    return (
      <View style={styles.centered}>
        <Text style={styles.errorText}>{KZ.noQuestions}</Text>
      </View>
    );
  }

  const currentQuestion = questions[idx];

  return (
    <View style={styles.root}>
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={requestExit} hitSlop={10} style={styles.closeButton}>
          <Text style={styles.closeText}>{KZ.close}</Text>
        </Pressable>

        <View style={styles.progressTrack}>
          <Animated.View style={[styles.progressFill, fillStyle]}>
            <LinearGradient
              colors={[colors.primary, colors.secondary] as readonly [string, string]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={StyleSheet.absoluteFill}
            />
          </Animated.View>
          <Text style={styles.progressLabel}>
            {Math.min(idx + 1, total)}/{total}
          </Text>
        </View>

        <Hearts count={hearts} maxCount={TOTAL_HEARTS} />
      </View>

      <ScrollView
        contentContainerStyle={styles.body}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <QuestionRenderer key={`q-${idx}`} question={currentQuestion} onAnswer={handleAnswer} />
      </ScrollView>

      <View style={[styles.avatarFooter, { paddingBottom: insets.bottom + spacing.sm }]}>
        {user?.assistant_type ? (
          <AvatarDisplay assistantType={user.assistant_type} action={avatarAction} size={88} />
        ) : null}
      </View>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Renders the right task-type component for the question's discriminant.
// ----------------------------------------------------------------------------
interface QuestionRendererProps {
  question: Question;
  onAnswer: (correct: boolean) => void;
}

const QuestionRenderer: React.FC<QuestionRendererProps> = ({ question, onAnswer }) => {
  switch (question.type) {
    case 'multiple_choice':
      return <MultipleChoice question={question} onAnswer={onAnswer} />;
    case 'true_false':
      return <TrueFalse question={question} onAnswer={onAnswer} />;
    case 'fill_in_blank':
      return <FillInBlank question={question} onAnswer={onAnswer} />;
    case 'match_pairs':
      return <MatchPairs question={question} onAnswer={onAnswer} />;
  }
};

// ----------------------------------------------------------------------------
// Hearts row. The lost heart shrinks + fades so the loss is felt.
// ----------------------------------------------------------------------------
interface HeartsProps {
  count: number;
  maxCount: number;
}

const Hearts: React.FC<HeartsProps> = ({ count, maxCount }) => {
  return (
    <View style={styles.hearts}>
      {Array.from({ length: maxCount }, (_, i) => (
        <Heart key={i} alive={i < count} index={i} totalLost={maxCount - count} />
      ))}
    </View>
  );
};

interface HeartProps {
  alive: boolean;
  index: number;
  totalLost: number;
}

const Heart: React.FC<HeartProps> = ({ alive }) => {
  const scale = useSharedValue(1);
  const opacity = useSharedValue(1);

  useEffect(() => {
    if (alive) {
      scale.value = withSpring(1, { damping: 10, stiffness: 200 });
      opacity.value = withTiming(1, { duration: 160 });
    } else {
      scale.value = withSequence(
        withTiming(1.25, { duration: 120 }),
        withTiming(0.6, { duration: 200, easing: Easing.in(Easing.cubic) }),
      );
      opacity.value = withTiming(0.25, { duration: 280 });
    }
  }, [alive, scale, opacity]);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: opacity.value,
  }));

  return <Animated.Text style={[styles.heart, animStyle]}>{alive ? '❤️' : '🤍'}</Animated.Text>;
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.background,
  },
  centered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.background,
  },
  errorText: {
    color: colors.text,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.bold,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.md,
    gap: spacing.sm,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeText: {
    color: colors.text,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.bold,
  },
  progressTrack: {
    flex: 1,
    height: 14,
    backgroundColor: colors.border,
    borderRadius: 7,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    position: 'relative',
  },
  progressFill: {
    height: '100%',
    borderRadius: 7,
    overflow: 'hidden',
  },
  progressLabel: {
    position: 'absolute',
    right: 8,
    color: colors.text,
    fontSize: 10,
    fontWeight: fontWeight.extrabold,
  },
  hearts: {
    flexDirection: 'row',
    gap: 2,
  },
  heart: {
    fontSize: 18,
  },
  body: {
    padding: spacing.md,
    paddingBottom: spacing.xl,
  },
  avatarFooter: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: spacing.sm,
  },
});

export default TaskScreen;
