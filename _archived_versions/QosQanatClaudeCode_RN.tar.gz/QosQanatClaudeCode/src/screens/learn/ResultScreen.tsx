import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AvatarDisplay from '@/components/Avatar/AvatarDisplay';
import { getNode, getSubject, type CurriculumNode } from '@/data/curriculum';
import type { AuthScreenProps, ResultParams } from '@/navigation/types';
import { completeNode } from '@/services/api';
import { useGameStore } from '@/store/gameStore';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

const KZ = {
  titleSuccess: '🎉 Тапсырма аяқталды!',
  titleFail: '😔 Тапсырма аяқталмады',
  score: (s: number) => `Ұпай: ${s}/100`,
  correct: (c: number, t: number) => `${c}/${t} дұрыс жауап`,
  noNode: 'Тапсырма табылмады',
  continue: 'Жалғастыру →',
  retry: 'Қайтадан →',
  rewards: 'Сыйақы',
  perfect: 'Мінсіз! ⭐',
  great: 'Өте жақсы!',
  ok: 'Жақсы! Тағы тырыс.',
  unlockedNext: 'Келесі тапсырма ашылды! 🔓',
};

const STAR_THRESHOLDS = [0, 50, 80, 100] as const; // %: <50 → 0★, ≥50 → 1★, etc.

const starsForScore = (scorePercent: number): number => {
  if (scorePercent >= STAR_THRESHOLDS[3]) return 3;
  if (scorePercent >= STAR_THRESHOLDS[2]) return 3; // 80-99 → 3 stars
  if (scorePercent >= STAR_THRESHOLDS[1]) return 2; // 50-79 → 2 stars
  if (scorePercent > 0) return 1;
  return 0;
};

interface AnimatedStarProps {
  active: boolean;
  delay: number;
  size: number;
}

const AnimatedStar: React.FC<AnimatedStarProps> = ({ active, delay, size }) => {
  const scale = useSharedValue(0);
  const rotate = useSharedValue(-30);

  useEffect(() => {
    if (!active) {
      scale.value = withTiming(0.6, { duration: 200 });
      return;
    }
    scale.value = withDelay(
      delay,
      withSequence(
        withSpring(1.25, { damping: 8, stiffness: 200 }),
        withSpring(1, { damping: 10, stiffness: 160 }),
      ),
    );
    rotate.value = withDelay(delay, withSpring(0, { damping: 9, stiffness: 180 }));
  }, [active, delay, scale, rotate]);

  const style = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }, { rotate: `${rotate.value}deg` }],
    opacity: active ? 1 : 0.35,
  }));

  return (
    <Animated.Text style={[styles.star, { fontSize: size }, style]}>
      {active ? '⭐' : '☆'}
    </Animated.Text>
  );
};

// Flies a single reward chip up from the card center toward the implied
// counter area at the top of the screen. The store has already been updated
// by the parent — this is the visual confirmation.
interface FlyingRewardProps {
  icon: string;
  amount: number;
  color: string;
  startDelay: number;
  endX: number;
}

const FlyingReward: React.FC<FlyingRewardProps> = ({ icon, amount, color, startDelay, endX }) => {
  const ty = useSharedValue(0);
  const tx = useSharedValue(0);
  const op = useSharedValue(0);
  const sc = useSharedValue(0.6);

  useEffect(() => {
    op.value = withDelay(
      startDelay,
      withSequence(
        withTiming(1, { duration: 220 }),
        withTiming(1, { duration: 500 }),
        withTiming(0, { duration: 220 }),
      ),
    );
    sc.value = withDelay(startDelay, withSpring(1, { damping: 9, stiffness: 200 }));
    ty.value = withDelay(
      startDelay + 220,
      withTiming(-260, { duration: 700, easing: Easing.inOut(Easing.cubic) }),
    );
    tx.value = withDelay(
      startDelay + 220,
      withTiming(endX, { duration: 700, easing: Easing.inOut(Easing.cubic) }),
    );
  }, [op, sc, ty, tx, startDelay, endX]);

  const style = useAnimatedStyle(() => ({
    transform: [{ translateX: tx.value }, { translateY: ty.value }, { scale: sc.value }],
    opacity: op.value,
  }));

  return (
    <Animated.View
      style={[styles.flyingReward, { backgroundColor: color }, style]}
      pointerEvents="none"
    >
      <Text style={styles.flyingIcon}>{icon}</Text>
      <Text style={styles.flyingAmount}>+{amount}</Text>
    </Animated.View>
  );
};

const ResultScreen: React.FC<AuthScreenProps<'Result'>> = ({ route, navigation }) => {
  const insets = useSafeAreaInsets();
  const params: ResultParams = route.params;
  const subject = useMemo(() => getSubject(params.subjectId), [params.subjectId]);
  const node = useMemo(
    () => getNode(params.subjectId, params.moduleId, params.nodeId),
    [params.subjectId, params.moduleId, params.nodeId],
  );

  const addCoins = useGameStore((s) => s.addCoins);
  const addXP = useGameStore((s) => s.addXP);
  const addAkylPoints = useGameStore((s) => s.addAkylPoints);
  const user = useUserStore((s) => s.user);

  const stars = useMemo(() => starsForScore(params.scorePercent), [params.scorePercent]);
  const isSuccess = params.scorePercent >= STAR_THRESHOLDS[1] && params.heartsLeft > 0;

  const [grantedRewards, setGrantedRewards] = useState<{
    xp: number;
    coins: number;
    akyl: number;
  } | null>(null);
  const savedRef = useRef(false);

  useEffect(() => {
    if (savedRef.current || !node || !isSuccess) return;
    savedRef.current = true;
    (async () => {
      try {
        const result = await completeNode({
          subjectId: params.subjectId,
          moduleId: params.moduleId,
          nodeId: params.nodeId,
          scorePercent: params.scorePercent,
          xpReward: node.xpReward,
          coinReward: node.coinReward,
          akylReward: node.akylReward,
        });
        if (result.isFirstClear) {
          setGrantedRewards({
            xp: node.xpReward,
            coins: node.coinReward,
            akyl: node.akylReward,
          });
          if (node.xpReward > 0) await addXP(node.xpReward);
          if (node.coinReward > 0) await addCoins(node.coinReward);
          if (node.akylReward > 0) await addAkylPoints(node.akylReward);
        } else {
          setGrantedRewards({ xp: 0, coins: 0, akyl: 0 });
        }
      } catch {
        Alert.alert('Сақтау мүмкін болмады', 'Интернет байланысын тексеріп қайталаңыз.');
      }
    })();
  }, [node, isSuccess, params, addXP, addCoins, addAkylPoints]);

  const headerOpacity = useSharedValue(0);
  const cardTranslate = useSharedValue(60);
  useEffect(() => {
    headerOpacity.value = withTiming(1, { duration: 400 });
    cardTranslate.value = withDelay(200, withSpring(0, { damping: 12, stiffness: 140 }));
  }, [headerOpacity, cardTranslate]);

  const headerStyle = useAnimatedStyle(() => ({ opacity: headerOpacity.value }));
  const cardStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: cardTranslate.value }],
    opacity: cardTranslate.value === 0 ? 1 : Math.max(0, 1 - cardTranslate.value / 60),
  }));

  const onContinue = useCallback(() => {
    navigation.replace('Map', { subjectId: params.subjectId });
  }, [navigation, params.subjectId]);

  if (!node || !subject) {
    return (
      <View style={styles.centered}>
        <Text style={styles.errorText}>{KZ.noNode}</Text>
      </View>
    );
  }

  const subtitle =
    params.scorePercent >= STAR_THRESHOLDS[2]
      ? KZ.perfect
      : params.scorePercent >= STAR_THRESHOLDS[1]
        ? KZ.great
        : KZ.ok;

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      />

      <Animated.View style={[styles.header, { paddingTop: insets.top + spacing.lg }, headerStyle]}>
        <Text style={styles.title}>{isSuccess ? KZ.titleSuccess : KZ.titleFail}</Text>
        <Text style={styles.subtitle}>{subtitle}</Text>
      </Animated.View>

      <View style={styles.avatarRow}>
        {user?.assistant_type ? (
          <AvatarDisplay
            assistantType={user.assistant_type}
            action={isSuccess ? 'celebrate' : 'sad'}
            size={140}
          />
        ) : null}
      </View>

      <Animated.View style={[styles.card, cardStyle]}>
        <View style={styles.stars}>
          <AnimatedStar active={stars >= 1} delay={300} size={56} />
          <AnimatedStar active={stars >= 2} delay={500} size={70} />
          <AnimatedStar active={stars >= 3} delay={700} size={56} />
        </View>

        <Text style={styles.scoreText}>{KZ.score(params.scorePercent)}</Text>
        <Text style={styles.correctText}>
          {KZ.correct(params.correctCount, params.totalQuestions)}
        </Text>

        {isSuccess ? (
          <View style={styles.rewardsRow}>
            <View style={styles.rewardChip}>
              <Text style={styles.rewardIcon}>✨</Text>
              <Text style={styles.rewardValue}>+{node.xpReward}</Text>
            </View>
            <View style={styles.rewardChip}>
              <Text style={styles.rewardIcon}>🪙</Text>
              <Text style={styles.rewardValue}>+{node.coinReward}</Text>
            </View>
            <View style={styles.rewardChip}>
              <Text style={styles.rewardIcon}>🔮</Text>
              <Text style={styles.rewardValue}>+{node.akylReward}</Text>
            </View>
          </View>
        ) : null}

        {isSuccess ? <Text style={styles.unlockText}>{KZ.unlockedNext}</Text> : null}

        <Pressable onPress={onContinue} style={styles.continueButton}>
          <LinearGradient
            colors={[colors.primary, colors.secondary] as readonly [string, string]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={StyleSheet.absoluteFill}
          />
          <Text style={styles.continueText}>{isSuccess ? KZ.continue : KZ.retry}</Text>
        </Pressable>
      </Animated.View>

      {grantedRewards && grantedRewards.xp + grantedRewards.coins + grantedRewards.akyl > 0 ? (
        <View style={styles.flyingHost} pointerEvents="none">
          {grantedRewards.xp > 0 ? (
            <FlyingReward
              icon="✨"
              amount={grantedRewards.xp}
              color={colors.success}
              startDelay={900}
              endX={-90}
            />
          ) : null}
          {grantedRewards.coins > 0 ? (
            <FlyingReward
              icon="🪙"
              amount={grantedRewards.coins}
              color={colors.gold}
              startDelay={1100}
              endX={0}
            />
          ) : null}
          {grantedRewards.akyl > 0 ? (
            <FlyingReward
              icon="🔮"
              amount={grantedRewards.akyl}
              color={colors.secondary}
              startDelay={1300}
              endX={90}
            />
          ) : null}
        </View>
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#1A1A4E',
  },
  centered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.background,
  },
  errorText: {
    color: colors.text,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.bold,
  },
  header: {
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    gap: 4,
  },
  title: {
    color: colors.white,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
    textAlign: 'center',
  },
  subtitle: {
    color: colors.gold,
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
  },
  avatarRow: {
    alignItems: 'center',
    marginTop: spacing.md,
    height: 160,
  },
  card: {
    backgroundColor: colors.white,
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    borderRadius: radius.xl,
    padding: spacing.lg,
    gap: spacing.md,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 8,
  },
  stars: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: spacing.sm,
    height: 80,
  },
  star: {
    textAlign: 'center',
  },
  scoreText: {
    color: colors.text,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
  },
  correctText: {
    color: colors.textLight,
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
  },
  rewardsRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  rewardChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: spacing.sm,
    borderRadius: 999,
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
  },
  rewardIcon: {
    fontSize: 16,
  },
  rewardValue: {
    color: colors.text,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
  },
  unlockText: {
    color: colors.success,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
  },
  continueButton: {
    width: '100%',
    height: 56,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    marginTop: spacing.sm,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
    elevation: 5,
  },
  continueText: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
  },
  flyingHost: {
    position: 'absolute',
    top: '40%',
    left: 0,
    right: 0,
    alignItems: 'center',
    height: 60,
  },
  flyingReward: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
  },
  flyingIcon: {
    fontSize: 14,
  },
  flyingAmount: {
    color: colors.white,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
  },
});

export default ResultScreen;
