import { useFocusEffect } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View, type ListRenderItem } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { CURRICULUM, countSubjectNodes, type Subject } from '@/data/curriculum';
import type { AuthScreenProps } from '@/navigation/types';
import { getSubjectProgressSummary } from '@/services/api';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

const KZ = {
  title: '📚 Пәндер',
  subtitle: 'Қай пәнді бүгін бастаймыз?',
  back: '←',
};

interface SubjectCardProps {
  subject: Subject;
  completed: number;
  total: number;
  onPress: () => void;
}

const SubjectCard: React.FC<SubjectCardProps> = ({ subject, completed, total, onPress }) => {
  const scale = useSharedValue(1);
  const progressValue = useSharedValue(0);
  const ratio = total > 0 ? completed / total : 0;

  useEffect(() => {
    progressValue.value = withTiming(ratio, { duration: 700, easing: Easing.out(Easing.cubic) });
  }, [ratio, progressValue]);

  const cardStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));
  const fillStyle = useAnimatedStyle(() => ({
    width: `${progressValue.value * 100}%`,
  }));

  return (
    <Pressable
      onPress={onPress}
      onPressIn={() => {
        scale.value = withSpring(0.95, { damping: 14, stiffness: 220 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 12, stiffness: 200 });
      }}
      style={styles.cardPressable}
    >
      <Animated.View style={[styles.card, cardStyle]}>
        <LinearGradient
          colors={[subject.color, subject.colorLight] as readonly [string, string]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.cardOverlay} />
        <View style={styles.cardHeader}>
          <Text style={styles.cardIcon}>{subject.icon}</Text>
          <Text style={styles.cardProgress}>
            {completed}/{total}
          </Text>
        </View>
        <View style={styles.cardBody}>
          <Text style={styles.cardName} numberOfLines={2}>
            {subject.nameKz}
          </Text>
          <Text style={styles.cardDescription} numberOfLines={2}>
            {subject.descriptionKz}
          </Text>
        </View>
        <View style={styles.progressTrack}>
          <Animated.View style={[styles.progressFill, fillStyle]} />
        </View>
      </Animated.View>
    </Pressable>
  );
};

const LearnScreen: React.FC<AuthScreenProps<'Learn'>> = ({ navigation }) => {
  const insets = useSafeAreaInsets();
  const [summary, setSummary] = useState<Record<string, { completed: number; total: number }>>({});

  const loadSummary = useCallback(async () => {
    const entries = await Promise.all(
      CURRICULUM.map(async (s) => {
        try {
          const sum = await getSubjectProgressSummary(s.id);
          return [s.id, { completed: sum.completed, total: countSubjectNodes(s.id) }] as const;
        } catch {
          return [s.id, { completed: 0, total: countSubjectNodes(s.id) }] as const;
        }
      }),
    );
    const next: Record<string, { completed: number; total: number }> = {};
    for (const [id, val] of entries) next[id] = val;
    setSummary(next);
  }, []);

  useFocusEffect(
    useCallback(() => {
      void loadSummary();
    }, [loadSummary]),
  );

  const renderItem: ListRenderItem<Subject> = useCallback(
    ({ item }) => {
      const s = summary[item.id] ?? { completed: 0, total: countSubjectNodes(item.id) };
      return (
        <SubjectCard
          subject={item}
          completed={s.completed}
          total={s.total}
          onPress={() => { navigation.navigate('Map', { subjectId: item.id }); }}
        />
      );
    },
    [navigation, summary],
  );

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      />
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => { navigation.goBack(); }} hitSlop={10} style={styles.backButton}>
          <Text style={styles.backText}>{KZ.back}</Text>
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>{KZ.title}</Text>
          <Text style={styles.subtitle}>{KZ.subtitle}</Text>
        </View>
      </View>

      <FlatList
        data={CURRICULUM}
        keyExtractor={(s) => s.id}
        renderItem={renderItem}
        numColumns={2}
        columnWrapperStyle={styles.row}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + spacing.xl }]}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#1A1A4E',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.md,
    gap: spacing.sm,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  backText: {
    color: colors.white,
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
    marginTop: -3,
  },
  title: {
    color: colors.white,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
  },
  subtitle: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: fontSize.sm,
    marginTop: 2,
  },
  list: {
    paddingHorizontal: spacing.md,
  },
  row: {
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  cardPressable: {
    flex: 1,
  },
  card: {
    height: 180,
    borderRadius: radius.lg,
    padding: spacing.md,
    overflow: 'hidden',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 5,
  },
  cardOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.05)',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  cardIcon: {
    fontSize: 36,
  },
  cardProgress: {
    color: colors.white,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
    backgroundColor: 'rgba(0,0,0,0.25)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
  },
  cardBody: {
    gap: 4,
  },
  cardName: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
  },
  cardDescription: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: fontSize.xs,
    fontWeight: fontWeight.medium,
    lineHeight: 16,
  },
  progressTrack: {
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.25)',
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 3,
    backgroundColor: colors.white,
  },
});

export default LearnScreen;
