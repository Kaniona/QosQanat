import { useNavigation, useRoute, type RouteProp } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, {
  Easing,
  cancelAnimation,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AvatarDisplay, { type AvatarAction } from '@/components/Avatar/AvatarDisplay';
import type { AuthStackParamList } from '@/navigation/types';
import {
  finalizeBattle,
  getBattle,
  getUserPublicProfile,
  submitBattleAnswer,
  subscribeBattle,
  type BattleAnswer,
  type BattleAnswerPing,
  type BattleQuestion,
  type BattleRow,
  type BattleSubscription,
  type PublicUserProfile,
} from '@/services/api';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import type { AssistantType } from '@/types';

type Nav = NativeStackNavigationProp<AuthStackParamList, 'Battle'>;
type Rt = RouteProp<AuthStackParamList, 'Battle'>;

const QUESTION_DURATION_MS = 10_000;
const TICK_MS = 100;

const KZ = {
  questionOf: (i: number, n: number) => `${i} / ${n}`,
  you: 'Сіз',
  opponent: 'Қарсылас',
  waitingNext: 'Келесі сұрақ...',
  timedOut: 'Уақыт бітті!',
  preparing: 'Дайындалуда...',
  errLoad: 'Шайқас жүктелмеді.',
};

const assistantOrDefault = (t: AssistantType | null): AssistantType => t ?? 'bektur';

// ----------------------------------------------------------------------------
// Stars overlay — pops a couple of "+1 ⭐" stars on a correct answer.
// ----------------------------------------------------------------------------

interface StarBurstProps {
  side: 'top' | 'bottom';
  onDone: () => void;
}

const StarBurst: React.FC<StarBurstProps> = ({ side, onDone }) => {
  const opacity = useSharedValue(0);
  const translate = useSharedValue(0);
  const scale = useSharedValue(0.5);

  useEffect(() => {
    opacity.value = withSequence(
      withTiming(1, { duration: 150 }),
      withDelay(
        400,
        withTiming(0, { duration: 350 }, (finished) => {
          if (finished) runOnJS(onDone)();
        }),
      ),
    );
    translate.value = withTiming(side === 'top' ? 28 : -28, {
      duration: 800,
      easing: Easing.out(Easing.cubic),
    });
    scale.value = withSpring(1.2, { damping: 8, stiffness: 220 });
    return () => {
      cancelAnimation(opacity);
      cancelAnimation(translate);
      cancelAnimation(scale);
    };
  }, [opacity, translate, scale, side, onDone]);

  const style = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateY: translate.value }, { scale: scale.value }],
  }));

  return (
    <Animated.View
      pointerEvents="none"
      style={[styles.starBurst, side === 'top' ? styles.starTop : styles.starBottom, style]}
    >
      <Text style={styles.starText}>+1 ⭐</Text>
    </Animated.View>
  );
};

// ----------------------------------------------------------------------------
// Timer bar
// ----------------------------------------------------------------------------

const TimerBar: React.FC<{ remainingMs: number; totalMs: number }> = ({ remainingMs, totalMs }) => {
  const pct = Math.max(0, Math.min(1, remainingMs / totalMs));
  const remainSec = Math.ceil(remainingMs / 1000);
  let color: string;
  if (remainingMs <= 3000) color = colors.danger;
  else if (remainingMs <= 5000) color = colors.warning;
  else color = colors.success;
  return (
    <View style={styles.timerWrap}>
      <View style={styles.timerTrack}>
        <View style={[styles.timerFill, { width: `${pct * 100}%`, backgroundColor: color }]} />
      </View>
      <Text style={[styles.timerText, { color }]}>{remainSec}s</Text>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Score side
// ----------------------------------------------------------------------------

interface SideProps {
  label: string;
  name: string;
  assistant: AssistantType;
  score: number;
  action: AvatarAction;
  alignTop: boolean;
  size?: number;
}

const Side: React.FC<SideProps> = ({
  label,
  name,
  assistant,
  score,
  action,
  alignTop,
  size = 80,
}) => (
  <View style={[styles.side, alignTop ? styles.sideTop : styles.sideBottom]}>
    <View style={styles.sideAvatar}>
      <AvatarDisplay assistantType={assistant} action={action} size={size} />
    </View>
    <View style={styles.sideMeta}>
      <Text style={styles.sideLabel}>{label}</Text>
      <Text style={styles.sideName} numberOfLines={1}>
        {name}
      </Text>
    </View>
    <View style={styles.scoreBox}>
      <Text style={styles.scoreNum}>{score}</Text>
    </View>
  </View>
);

// ----------------------------------------------------------------------------
// Option button
// ----------------------------------------------------------------------------

interface OptionProps {
  index: number;
  label: string;
  selected: boolean;
  reveal: 'none' | 'correct' | 'wrong' | 'unselectedCorrect';
  disabled: boolean;
  onPress: () => void;
}

const OPTION_LETTERS = ['A', 'B', 'C', 'D'];

const Option: React.FC<OptionProps> = React.memo(
  ({ index, label, selected, reveal, disabled, onPress }) => {
    const scale = useSharedValue(1);
    const style = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

    let bg = 'rgba(255,255,255,0.08)';
    let border = 'rgba(255,255,255,0.18)';
    const textColor = colors.white;
    if (reveal === 'correct') {
      bg = 'rgba(0,196,140,0.25)';
      border = colors.success;
    } else if (reveal === 'wrong') {
      bg = 'rgba(255,71,87,0.25)';
      border = colors.danger;
    } else if (reveal === 'unselectedCorrect') {
      bg = 'rgba(0,196,140,0.12)';
      border = colors.success;
    } else if (selected) {
      bg = 'rgba(74,108,247,0.25)';
      border = colors.primary;
    }

    return (
      <Pressable
        disabled={disabled}
        onPressIn={() => {
          if (!disabled) scale.value = withSpring(0.96, { damping: 14, stiffness: 220 });
        }}
        onPressOut={() => {
          scale.value = withSpring(1, { damping: 14, stiffness: 220 });
        }}
        onPress={onPress}
      >
        <Animated.View style={[styles.option, { backgroundColor: bg, borderColor: border }, style]}>
          <View style={[styles.optionLetter, { backgroundColor: border }]}>
            <Text style={styles.optionLetterText}>{OPTION_LETTERS[index]}</Text>
          </View>
          <Text style={[styles.optionText, { color: textColor }]}>{label}</Text>
        </Animated.View>
      </Pressable>
    );
  },
);

// ----------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------

const BattleScreen: React.FC = () => {
  const nav = useNavigation<Nav>();
  const route = useRoute<Rt>();
  const insets = useSafeAreaInsets();
  const me = useUserStore((s) => s.user);
  const { battleId } = route.params;

  // ---- Battle data ----
  const [battle, setBattle] = useState<BattleRow | null>(null);
  const [opponent, setOpponent] = useState<PublicUserProfile | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  // ---- Per-question state ----
  const [questionIndex, setQuestionIndex] = useState(0);
  const [remainingMs, setRemainingMs] = useState(QUESTION_DURATION_MS);
  const [mySelection, setMySelection] = useState<number | null>(null);
  const [reveal, setReveal] = useState<boolean>(false);

  // ---- Scores ----
  const [myScore, setMyScore] = useState(0);
  const [opponentScore, setOpponentScore] = useState(0);
  const [myAnswers, setMyAnswers] = useState<readonly BattleAnswer[]>([]);

  // ---- Avatar reactions ----
  const [myAction, setMyAction] = useState<AvatarAction>('idle');
  const [oppAction, setOppAction] = useState<AvatarAction>('idle');

  // ---- Star bursts ----
  const [stars, setStars] = useState<readonly { id: number; side: 'top' | 'bottom' }[]>([]);

  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const subRef = useRef<BattleSubscription | null>(null);
  const advanceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const questionStartedAtRef = useRef<number>(Date.now());
  const finalizedRef = useRef(false);
  // Track the running total of opponent answers we've received so we don't
  // double-process duplicate postgres_changes payloads.
  const oppAnswerCountRef = useRef(0);

  // ---- Derived ----
  const myRole = useMemo<'challenger' | 'opponent'>(() => {
    if (!battle || !me) return 'challenger';
    return battle.challenger_id === me.id ? 'challenger' : 'opponent';
  }, [battle, me]);

  const totalQuestions = battle?.question_count ?? 0;
  const currentQuestion: BattleQuestion | undefined = battle?.questions_data[questionIndex];

  // ---------- Initial fetch ----------
  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        const row = await getBattle(battleId);
        if (cancelled || !row) {
          if (!cancelled) setLoadError(KZ.errLoad);
          return;
        }
        setBattle(row);
        const oppId = row.challenger_id === me?.id ? row.opponent_id : row.challenger_id;
        const oppProfile = await getUserPublicProfile(oppId);
        if (!cancelled) setOpponent(oppProfile);
        // Restore scores if there were prior answers.
        if (row.challenger_id === me?.id) {
          setMyScore(row.challenger_score);
          setOpponentScore(row.opponent_score);
          setMyAnswers(row.challenger_answers ?? []);
          oppAnswerCountRef.current = (row.opponent_answers ?? []).length;
          setQuestionIndex((row.challenger_answers ?? []).length);
        } else {
          setMyScore(row.opponent_score);
          setOpponentScore(row.challenger_score);
          setMyAnswers(row.opponent_answers ?? []);
          oppAnswerCountRef.current = (row.challenger_answers ?? []).length;
          setQuestionIndex((row.opponent_answers ?? []).length);
        }
        questionStartedAtRef.current = Date.now();
      } catch {
        if (!cancelled) setLoadError(KZ.errLoad);
      }
    };
    void run();
    return () => {
      cancelled = true;
    };
  }, [battleId, me?.id]);

  // ---------- Realtime sub ----------
  useEffect(() => {
    if (!battle || !me) return;
    const sub = subscribeBattle(battleId, {
      onRow: (row) => {
        // Update opponent score from authoritative column the opponent writes.
        const oppCol = row.challenger_id === me.id ? row.opponent_score : row.challenger_score;
        setOpponentScore(oppCol);
        if (row.status === 'completed' || row.status === 'cancelled') {
          if (!finalizedRef.current) {
            finalizedRef.current = true;
            nav.replace('BattleResult', { battleId });
          }
        }
      },
      onAnswerPing: (ping) => {
        // Mirror the opponent's just-submitted score immediately.
        const oppRole = myRole === 'challenger' ? 'opponent' : 'challenger';
        if (ping.role !== oppRole) return;
        setOpponentScore(ping.scoreAfter);
        if (ping.isCorrect) {
          setOppAction('celebrate');
          setStars((s) => [...s, { id: Date.now(), side: 'top' }]);
        } else {
          setOppAction('sad');
        }
        oppAnswerCountRef.current = ping.questionIndex + 1;
      },
    });
    subRef.current = sub;
    return () => {
      sub.unsubscribe();
    };
  }, [battle, me, battleId, myRole, nav]);

  // ---------- Per-question timer ----------
  useEffect(() => {
    if (!currentQuestion || reveal) return;
    questionStartedAtRef.current = Date.now();
    setRemainingMs(QUESTION_DURATION_MS);
    if (tickRef.current) clearInterval(tickRef.current);
    tickRef.current = setInterval(() => {
      const elapsed = Date.now() - questionStartedAtRef.current;
      const left = QUESTION_DURATION_MS - elapsed;
      if (left <= 0) {
        setRemainingMs(0);
        if (tickRef.current) clearInterval(tickRef.current);
        // Submit a "no answer" if the player hasn't selected anything.
        handleAnswerInternal(null);
      } else {
        setRemainingMs(left);
      }
    }, TICK_MS);
    return () => {
      if (tickRef.current) clearInterval(tickRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [questionIndex, reveal, currentQuestion?.id]);

  // ---------- Reset avatar actions back to idle ----------
  useEffect(() => {
    if (myAction === 'idle') return;
    const t = setTimeout(() => { setMyAction('idle'); }, 1200);
    return () => { clearTimeout(t); };
  }, [myAction]);
  useEffect(() => {
    if (oppAction === 'idle') return;
    const t = setTimeout(() => { setOppAction('idle'); }, 1200);
    return () => { clearTimeout(t); };
  }, [oppAction]);

  // ---------- Answer handling ----------
  const handleAnswerInternal = useCallback(
    async (answerIndex: number | null) => {
      if (!battle || !currentQuestion || reveal) return;
      if (tickRef.current) clearInterval(tickRef.current);
      const isCorrect = answerIndex !== null && answerIndex === currentQuestion.correctIndex;
      const elapsed = Date.now() - questionStartedAtRef.current;
      const answer: BattleAnswer = {
        questionIndex,
        answerIndex,
        isCorrect,
        answeredAtMs: Math.min(elapsed, QUESTION_DURATION_MS),
      };
      const nextAnswers = [...myAnswers, answer];
      const nextScore = myScore + (isCorrect ? 1 : 0);
      setMyAnswers(nextAnswers);
      setMyScore(nextScore);
      setMySelection(answerIndex);
      setReveal(true);
      setMyAction(isCorrect ? 'celebrate' : 'sad');
      if (isCorrect) {
        setStars((s) => [...s, { id: Date.now(), side: 'bottom' }]);
      }

      // Persist + broadcast.
      try {
        await submitBattleAnswer({
          battleId,
          role: myRole,
          answers: nextAnswers,
          score: nextScore,
        });
        if (subRef.current) {
          await subRef.current.broadcastAnswer({
            role: myRole,
            questionIndex,
            isCorrect,
            scoreAfter: nextScore,
          });
        }
      } catch {
        // Soft-fail: results screen reloads from DB so a missed write
        // will surface there if it happened.
      }

      // Schedule advance to next question.
      if (advanceTimerRef.current) clearTimeout(advanceTimerRef.current);
      advanceTimerRef.current = setTimeout(() => {
        const next = questionIndex + 1;
        if (next >= totalQuestions) {
          void finishBattle();
        } else {
          setQuestionIndex(next);
          setMySelection(null);
          setReveal(false);
        }
      }, 1500);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      battle,
      currentQuestion,
      reveal,
      questionIndex,
      myAnswers,
      myScore,
      myRole,
      battleId,
      totalQuestions,
    ],
  );

  const handlePickOption = useCallback(
    (idx: number) => {
      if (reveal || mySelection !== null) return;
      void handleAnswerInternal(idx);
    },
    [reveal, mySelection, handleAnswerInternal],
  );

  const finishBattle = useCallback(async () => {
    if (finalizedRef.current) return;
    finalizedRef.current = true;
    try {
      await finalizeBattle(battleId);
    } catch {
      // soft-fail
    }
    nav.replace('BattleResult', { battleId });
  }, [battleId, nav]);

  // ---------- Render ----------
  if (loadError) {
    return (
      <View style={[styles.root, styles.center]}>
        <LinearGradient
          colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
          style={StyleSheet.absoluteFill}
        />
        <Text style={styles.loadError}>{loadError}</Text>
      </View>
    );
  }

  if (!battle || !opponent || !me || !currentQuestion) {
    return (
      <View style={[styles.root, styles.center]}>
        <LinearGradient
          colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
          style={StyleSheet.absoluteFill}
        />
        <ActivityIndicator color={colors.white} size="large" />
        <Text style={styles.loadingText}>{KZ.preparing}</Text>
      </View>
    );
  }

  const myAssistant = assistantOrDefault(me.assistant_type ?? null);
  const oppAssistant = assistantOrDefault(opponent.assistant_type);

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
      />

      {/* Top — opponent */}
      <View style={[styles.topBar, { paddingTop: insets.top + spacing.sm }]}>
        <Side
          label={KZ.opponent}
          name={opponent.full_name}
          assistant={oppAssistant}
          score={opponentScore}
          action={oppAction}
          alignTop
        />
        {stars
          .filter((s) => s.side === 'top')
          .map((s) => (
            <StarBurst
              key={s.id}
              side="top"
              onDone={() => { setStars((curr) => curr.filter((x) => x.id !== s.id)); }}
            />
          ))}
      </View>

      {/* Middle — question */}
      <View style={styles.middle}>
        <View style={styles.questionHeader}>
          <View style={styles.subjectBadge}>
            <Text style={styles.subjectBadgeText}>{currentQuestion.subjectNameKz}</Text>
          </View>
          <Text style={styles.counter}>{KZ.questionOf(questionIndex + 1, totalQuestions)}</Text>
        </View>
        <TimerBar remainingMs={remainingMs} totalMs={QUESTION_DURATION_MS} />
        <View style={styles.questionBox}>
          <Text style={styles.questionText}>{currentQuestion.questionKz}</Text>
        </View>
        <View style={styles.options}>
          {currentQuestion.options.map((opt, idx) => {
            let revealKind: OptionProps['reveal'] = 'none';
            if (reveal) {
              if (idx === currentQuestion.correctIndex) {
                revealKind = idx === mySelection ? 'correct' : 'unselectedCorrect';
              } else if (idx === mySelection) {
                revealKind = 'wrong';
              }
            }
            return (
              <Option
                key={`${currentQuestion.id}-${idx}`}
                index={idx}
                label={opt}
                selected={mySelection === idx}
                reveal={revealKind}
                disabled={reveal || mySelection !== null}
                onPress={() => { handlePickOption(idx); }}
              />
            );
          })}
        </View>
        {reveal ? (
          <Text style={styles.waitingText}>
            {mySelection === null ? KZ.timedOut : KZ.waitingNext}
          </Text>
        ) : null}
      </View>

      {/* Bottom — me */}
      <View style={[styles.bottomBar, { paddingBottom: insets.bottom + spacing.sm }]}>
        <Side
          label={KZ.you}
          name={me.full_name}
          assistant={myAssistant}
          score={myScore}
          action={myAction}
          alignTop={false}
        />
        {stars
          .filter((s) => s.side === 'bottom')
          .map((s) => (
            <StarBurst
              key={s.id}
              side="bottom"
              onDone={() => { setStars((curr) => curr.filter((x) => x.id !== s.id)); }}
            />
          ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#1A1A4E' },
  center: { alignItems: 'center', justifyContent: 'center' },
  loadingText: { color: 'rgba(255,255,255,0.7)', fontSize: fontSize.md, marginTop: spacing.md },
  loadError: { color: colors.danger, fontSize: fontSize.md, fontWeight: fontWeight.bold },
  topBar: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.sm,
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.06)',
  },
  bottomBar: {
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.06)',
  },
  side: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  sideTop: {},
  sideBottom: {},
  sideAvatar: {
    width: 80,
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sideMeta: { flex: 1, gap: 2 },
  sideLabel: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 11,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  sideName: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
  },
  scoreBox: {
    minWidth: 56,
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.md,
    backgroundColor: 'rgba(255,215,0,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(255,215,0,0.4)',
    alignItems: 'center',
  },
  scoreNum: {
    color: colors.gold,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
  },
  middle: {
    flex: 1,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    gap: spacing.sm,
  },
  questionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  subjectBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.full,
    backgroundColor: 'rgba(123,97,255,0.25)',
    borderWidth: 1,
    borderColor: 'rgba(123,97,255,0.5)',
  },
  subjectBadgeText: {
    color: colors.white,
    fontSize: fontSize.xs,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 0.5,
  },
  counter: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
  },
  timerWrap: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  timerTrack: {
    flex: 1,
    height: 10,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 5,
    overflow: 'hidden',
  },
  timerFill: { height: '100%', borderRadius: 5 },
  timerText: {
    width: 36,
    textAlign: 'right',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
  },
  questionBox: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  questionText: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.bold,
    lineHeight: 26,
  },
  options: { gap: spacing.sm, marginTop: 4 },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    borderWidth: 2,
    minHeight: 56,
  },
  optionLetter: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  optionLetterText: {
    color: colors.white,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
  },
  optionText: {
    flex: 1,
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
  },
  waitingText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.sm,
    textAlign: 'center',
    marginTop: 4,
  },
  starBurst: {
    position: 'absolute',
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.full,
    backgroundColor: 'rgba(0,196,140,0.95)',
  },
  starTop: { top: 16, right: spacing.md + 60 },
  starBottom: { bottom: 16, right: spacing.md + 60 },
  starText: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
  },
});

export default BattleScreen;
