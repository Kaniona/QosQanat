import { useNavigation, useRoute, type RouteProp } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Animated, {
  Easing,
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AvatarDisplay from '@/components/Avatar/AvatarDisplay';
import type { AuthStackParamList } from '@/navigation/types';
import {
  getBattleResult,
  getUserPublicProfile,
  incrementBattleStats,
  type BattleResultSummary,
  type PublicUserProfile,
} from '@/services/api';
import { useGameStore } from '@/store/gameStore';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import type { AssistantType } from '@/types';

type Nav = NativeStackNavigationProp<AuthStackParamList, 'BattleResult'>;
type Rt = RouteProp<AuthStackParamList, 'BattleResult'>;

const KZ = {
  win: '🏆 ЖЕҢДІҢІЗ!',
  lose: '😔 Жеңілдіңіз...',
  tie: '🤝 Тең түсті',
  scoreTitle: 'Нәтиже',
  rewardsTitle: 'Сыйлық',
  correctLabel: 'Дұрыс',
  wrongLabel: 'Қате',
  accuracyLabel: 'Дәлдік',
  youLabel: 'Сіз',
  opponentLabel: 'Қарсылас',
  akylReward: 'ақыл',
  coinReward: 'тиын',
  rematch: '🔄 Қайта батл',
  home: '🏠 Басты бетке',
  loading: 'Нәтиже есептелуде...',
  loadError: 'Нәтижені жүктеу мүмкін болмады.',
};

const SCREEN_W = Dimensions.get('window').width;
const SCREEN_H = Dimensions.get('window').height;

const assistantOrDefault = (t: AssistantType | null): AssistantType => t ?? 'bektur';

// ----------------------------------------------------------------------------
// Confetti — small absolute-positioned squares falling/rotating.
// ----------------------------------------------------------------------------

const CONFETTI_COLORS = [
  colors.gold,
  colors.primary,
  colors.danger,
  colors.success,
  colors.secondary,
  '#FF8C5A',
];

interface ConfettiPieceProps {
  startX: number;
  delay: number;
  color: string;
  rotateDir: number;
}

const ConfettiPiece: React.FC<ConfettiPieceProps> = React.memo(
  ({ startX, delay, color, rotateDir }) => {
    const ty = useSharedValue(-30);
    const tx = useSharedValue(0);
    const rot = useSharedValue(0);
    const opacity = useSharedValue(0);

    useEffect(() => {
      opacity.value = withDelay(delay, withTiming(1, { duration: 200 }));
      ty.value = withDelay(
        delay,
        withTiming(SCREEN_H + 40, {
          duration: 3500 + Math.random() * 1500,
          easing: Easing.in(Easing.quad),
        }),
      );
      tx.value = withDelay(
        delay,
        withRepeat(
          withSequence(
            withTiming(20, { duration: 600, easing: Easing.inOut(Easing.quad) }),
            withTiming(-20, { duration: 600, easing: Easing.inOut(Easing.quad) }),
          ),
          -1,
          true,
        ),
      );
      rot.value = withDelay(
        delay,
        withRepeat(withTiming(360 * rotateDir, { duration: 1400, easing: Easing.linear }), -1),
      );
      return () => {
        cancelAnimation(ty);
        cancelAnimation(tx);
        cancelAnimation(rot);
        cancelAnimation(opacity);
      };
    }, [delay, rotateDir, ty, tx, rot, opacity]);

    const style = useAnimatedStyle(() => ({
      opacity: opacity.value,
      transform: [
        { translateX: tx.value },
        { translateY: ty.value },
        { rotate: `${rot.value}deg` },
      ],
    }));

    return (
      <Animated.View
        pointerEvents="none"
        style={[styles.confettiPiece, { left: startX, backgroundColor: color }, style]}
      />
    );
  },
);

const Confetti: React.FC = () => {
  const pieces = useMemo(
    () =>
      Array.from({ length: 40 }, (_, i) => ({
        startX: Math.random() * SCREEN_W,
        delay: Math.floor(Math.random() * 1200),
        color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
        rotateDir: Math.random() > 0.5 ? 1 : -1,
        key: i,
      })),
    [],
  );
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      {pieces.map((p) => (
        <ConfettiPiece
          key={p.key}
          startX={p.startX}
          delay={p.delay}
          color={p.color}
          rotateDir={p.rotateDir}
        />
      ))}
    </View>
  );
};

// ----------------------------------------------------------------------------
// Animated counter (rolls up from 0 to value)
// ----------------------------------------------------------------------------

const RollupNumber: React.FC<{ value: number; style?: object }> = ({ value, style }) => {
  const [displayed, setDisplayed] = useState(0);
  useEffect(() => {
    if (value <= 0) {
      setDisplayed(0);
      return;
    }
    const duration = 700;
    const startedAt = Date.now();
    const id = setInterval(() => {
      const elapsed = Date.now() - startedAt;
      const t = Math.min(1, elapsed / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      const next = Math.round(value * eased);
      setDisplayed(next);
      if (t >= 1) {
        clearInterval(id);
        setDisplayed(value);
      }
    }, 30);
    return () => { clearInterval(id); };
  }, [value]);
  return <Text style={style}>{displayed}</Text>;
};

// ----------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------

const BattleResultScreen: React.FC = () => {
  const nav = useNavigation<Nav>();
  const route = useRoute<Rt>();
  const insets = useSafeAreaInsets();
  const me = useUserStore((s) => s.user);
  const addCoins = useGameStore((s) => s.addCoins);
  const addAkyl = useGameStore((s) => s.addAkylPoints);
  const { battleId } = route.params;

  const [summary, setSummary] = useState<BattleResultSummary | null>(null);
  const [opponent, setOpponent] = useState<PublicUserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const grantedRef = useRef(false);

  // Hero (trophy/defeat) pulse.
  const heroScale = useSharedValue(0.4);
  const heroRotate = useSharedValue(-10);

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        const s = await getBattleResult(battleId);
        if (cancelled || !s) {
          if (!cancelled) setError(KZ.loadError);
          return;
        }
        setSummary(s);
        const oppId = s.myRole === 'challenger' ? s.battle.opponent_id : s.battle.challenger_id;
        const op = await getUserPublicProfile(oppId);
        if (cancelled) return;
        setOpponent(op);
      } catch {
        if (!cancelled) setError(KZ.loadError);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    void run();
    return () => {
      cancelled = true;
    };
  }, [battleId]);

  // Compute rewards.
  const rewards = useMemo(() => {
    if (!summary) return { akyl: 0, coins: 0 };
    const correct = summary.myScore;
    const baseAkyl = correct * 5;
    if (summary.outcome === 'win') return { akyl: baseAkyl * 2, coins: 50 };
    if (summary.outcome === 'tie') return { akyl: baseAkyl, coins: 30 };
    return { akyl: baseAkyl, coins: 20 };
  }, [summary]);

  // Grant rewards + stats once when summary arrives.
  useEffect(() => {
    if (!summary || grantedRef.current) return;
    grantedRef.current = true;
    void (async () => {
      try {
        if (rewards.akyl > 0) await addAkyl(rewards.akyl);
        if (rewards.coins > 0) await addCoins(rewards.coins);
        await incrementBattleStats(summary.outcome === 'win');
      } catch {
        // soft-fail
      }
    })();
  }, [summary, rewards, addAkyl, addCoins]);

  // Hero animation when summary loads.
  useEffect(() => {
    if (!summary) return;
    heroScale.value = withSpring(1, { damping: 9, stiffness: 200 });
    heroRotate.value = withSequence(
      withTiming(0, { duration: 400, easing: Easing.out(Easing.cubic) }),
      withRepeat(
        withSequence(
          withTiming(-4, { duration: 1500, easing: Easing.inOut(Easing.quad) }),
          withTiming(4, { duration: 1500, easing: Easing.inOut(Easing.quad) }),
        ),
        -1,
        true,
      ),
    );
    return () => {
      cancelAnimation(heroScale);
      cancelAnimation(heroRotate);
    };
  }, [summary, heroScale, heroRotate]);

  const heroStyle = useAnimatedStyle(() => ({
    transform: [{ scale: heroScale.value }, { rotate: `${heroRotate.value}deg` }],
  }));

  const handleRematch = useCallback(() => {
    if (!summary) return;
    const oppId =
      summary.myRole === 'challenger' ? summary.battle.opponent_id : summary.battle.challenger_id;
    nav.replace('BattleSetup', { opponentId: oppId });
  }, [summary, nav]);

  const handleHome = useCallback(() => {
    nav.reset({ index: 0, routes: [{ name: 'Main' }] });
  }, [nav]);

  if (loading || !summary || !opponent || !me) {
    return (
      <View style={[styles.root, styles.center]}>
        <LinearGradient
          colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
          style={StyleSheet.absoluteFill}
        />
        {error ? (
          <Text style={styles.error}>{error}</Text>
        ) : (
          <>
            <ActivityIndicator size="large" color={colors.white} />
            <Text style={styles.loadingText}>{KZ.loading}</Text>
          </>
        )}
      </View>
    );
  }

  const isWin = summary.outcome === 'win';
  const isTie = summary.outcome === 'tie';
  const correct = summary.myScore;
  const wrong = summary.battle.question_count - correct;
  const accuracy =
    summary.totalQuestions > 0 ? Math.round((correct / summary.totalQuestions) * 100) : 0;

  const myAssistant = assistantOrDefault(me.assistant_type ?? null);
  const oppAssistant = assistantOrDefault(opponent.assistant_type);

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={
          isWin
            ? (['#3A2F00', '#5E4A00', colors.gold] as readonly [string, string, string])
            : isTie
              ? (['#1A1A4E', '#2A2870', colors.secondary] as readonly [string, string, string])
              : (['#2A0010', '#4A1020', '#7A1030'] as readonly [string, string, string])
        }
        style={StyleSheet.absoluteFill}
      />

      {isWin ? <Confetti /> : null}

      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          { paddingTop: insets.top + spacing.lg, paddingBottom: insets.bottom + 120 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View style={[styles.heroBox, heroStyle]}>
          <Text style={[styles.heroEmoji, isWin && styles.heroEmojiWin]}>
            {isWin ? '🏆' : isTie ? '🤝' : '💔'}
          </Text>
          <Text style={[styles.heroTitle, isWin && { color: colors.gold }]}>
            {isWin ? KZ.win : isTie ? KZ.tie : KZ.lose}
          </Text>
        </Animated.View>

        <View style={styles.avatarRow}>
          <View style={styles.avatarCol}>
            <View style={[styles.avatarStage, isWin && styles.avatarStageWin]}>
              <AvatarDisplay
                assistantType={myAssistant}
                action={isWin ? 'celebrate' : isTie ? 'idle' : 'sad'}
                size={110}
              />
              {isWin ? <Text style={styles.trophyEmoji}>🏆</Text> : null}
            </View>
            <Text style={styles.avatarName}>{KZ.youLabel}</Text>
            <Text style={styles.avatarScore}>{summary.myScore}</Text>
          </View>
          <View style={styles.avatarCol}>
            <View style={[styles.avatarStage, !isWin && !isTie && styles.avatarStageWin]}>
              <AvatarDisplay
                assistantType={oppAssistant}
                action={!isWin && !isTie ? 'celebrate' : 'idle'}
                size={110}
              />
            </View>
            <Text style={styles.avatarName} numberOfLines={1}>
              {opponent.full_name}
            </Text>
            <Text style={styles.avatarScore}>{summary.opponentScore}</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{KZ.scoreTitle}</Text>
          <View style={styles.statRow}>
            <View style={styles.statBox}>
              <Text style={[styles.statValue, { color: colors.success }]}>{correct}</Text>
              <Text style={styles.statLabel}>{KZ.correctLabel} ✓</Text>
            </View>
            <View style={styles.statBox}>
              <Text style={[styles.statValue, { color: colors.danger }]}>{wrong}</Text>
              <Text style={styles.statLabel}>{KZ.wrongLabel} ✕</Text>
            </View>
            <View style={styles.statBox}>
              <Text style={[styles.statValue, { color: colors.gold }]}>{accuracy}%</Text>
              <Text style={styles.statLabel}>{KZ.accuracyLabel}</Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{KZ.rewardsTitle}</Text>
          <View style={styles.rewardsRow}>
            <View style={[styles.rewardCard, { borderColor: colors.secondary }]}>
              <Text style={styles.rewardEmoji}>🔮</Text>
              <RollupNumber value={rewards.akyl} style={styles.rewardValue} />
              <Text style={styles.rewardLabel}>{KZ.akylReward}</Text>
            </View>
            <View style={[styles.rewardCard, { borderColor: colors.gold }]}>
              <Text style={styles.rewardEmoji}>🪙</Text>
              <RollupNumber value={rewards.coins} style={styles.rewardValue} />
              <Text style={styles.rewardLabel}>{KZ.coinReward}</Text>
            </View>
          </View>
        </View>
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: insets.bottom + spacing.md }]}>
        <Pressable style={styles.homeBtn} onPress={handleHome}>
          <Text style={styles.homeText}>{KZ.home}</Text>
        </Pressable>
        <Pressable style={styles.rematchBtn} onPress={handleRematch}>
          <LinearGradient
            colors={[colors.primary, colors.secondary] as readonly [string, string]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <Text style={styles.rematchText}>{KZ.rematch}</Text>
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#1A1A4E' },
  center: { alignItems: 'center', justifyContent: 'center' },
  loadingText: { color: 'rgba(255,255,255,0.7)', marginTop: spacing.md, fontSize: fontSize.md },
  error: { color: colors.danger, fontSize: fontSize.md, fontWeight: fontWeight.bold },
  scroll: {
    paddingHorizontal: spacing.md,
    gap: spacing.lg,
  },
  heroBox: { alignItems: 'center', gap: spacing.sm },
  heroEmoji: { fontSize: 80 },
  heroEmojiWin: { fontSize: 96 },
  heroTitle: {
    color: colors.white,
    fontSize: fontSize.huge,
    fontWeight: fontWeight.extrabold,
    textAlign: 'center',
    letterSpacing: 1,
  },
  avatarRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'flex-start',
    paddingHorizontal: spacing.md,
  },
  avatarCol: { alignItems: 'center', gap: 6, flex: 1 },
  avatarStage: {
    width: 130,
    height: 130,
    borderRadius: 65,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarStageWin: {
    borderColor: colors.gold,
    backgroundColor: 'rgba(255,215,0,0.15)',
    shadowColor: colors.gold,
    shadowOpacity: 0.6,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 0 },
    elevation: 12,
  },
  trophyEmoji: {
    position: 'absolute',
    top: -10,
    right: -6,
    fontSize: 32,
  },
  avatarName: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
    textAlign: 'center',
    maxWidth: 140,
  },
  avatarScore: {
    color: colors.gold,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
  },
  section: {
    backgroundColor: 'rgba(0,0,0,0.3)',
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    gap: spacing.sm,
  },
  sectionTitle: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  statRow: { flexDirection: 'row', gap: spacing.sm },
  statBox: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: radius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  statValue: {
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
  },
  statLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.xs,
    marginTop: 2,
    fontWeight: fontWeight.bold,
  },
  rewardsRow: { flexDirection: 'row', gap: spacing.sm },
  rewardCard: {
    flex: 1,
    paddingVertical: spacing.md,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: radius.md,
    borderWidth: 2,
    alignItems: 'center',
  },
  rewardEmoji: { fontSize: 32 },
  rewardValue: {
    color: colors.white,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
    marginTop: 4,
  },
  rewardLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.xs,
    fontWeight: fontWeight.bold,
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.md,
    backgroundColor: 'rgba(0,0,0,0.45)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  homeBtn: {
    flex: 1,
    height: 56,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  homeText: { color: colors.white, fontSize: fontSize.md, fontWeight: fontWeight.bold },
  rematchBtn: {
    flex: 2,
    height: 56,
    borderRadius: radius.md,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  rematchText: { color: colors.white, fontSize: fontSize.lg, fontWeight: fontWeight.extrabold },
  confettiPiece: {
    position: 'absolute',
    top: 0,
    width: 10,
    height: 14,
    borderRadius: 2,
  },
});

export default BattleResultScreen;
