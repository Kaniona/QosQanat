import { useNavigation, useRoute, type RouteProp } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AvatarDisplay from '@/components/Avatar/AvatarDisplay';
import type { AuthStackParamList } from '@/navigation/types';
import {
  BATTLE_SUBJECTS,
  createBattle,
  getUserPublicProfile,
  type BattleQuestionCount,
  type BattleSubjectOption,
  type PublicUserProfile,
} from '@/services/api';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import type { AssistantType } from '@/types';

type Nav = NativeStackNavigationProp<AuthStackParamList, 'BattleSetup'>;
type Rt = RouteProp<AuthStackParamList, 'BattleSetup'>;

const QUESTION_COUNTS: readonly BattleQuestionCount[] = [15, 20, 25, 40, 50];

const KZ = {
  title: '⚔️ Шайқас баптауы',
  loadingOpp: 'Қарсыластың деректері жүктелуде...',
  yourOpponent: 'Сіздің қарсыласыңыз',
  questions: 'Сұрақ саны',
  subjects: 'Пәндер',
  allSubjects: 'Барлығы',
  start: '⚔️ Батл бастау!',
  starting: 'Жіберілуде...',
  cancel: 'Болдырмау',
  rule1: '⏱ Әр сұраққа 10 секунд',
  rule2: '✅ Дұрыс жауап = 1 ұпай',
  rule3: '🏆 Көбірек ұпай жинаған жеңеді',
  rule4: '🔮 Ақыл ұпайлары мен тиындар жүлдеге беріледі',
  rulesTitle: 'Ережелер',
  errCreate: 'Шайқас бастау мүмкін болмады. Қайталап көріңіз.',
  level: (n: number) => `Деңгей ${n}`,
  akyl: (n: number) => `${n} 🔮`,
};

const assistantOrDefault = (t: AssistantType | null): AssistantType => t ?? 'bektur';

// ----------------------------------------------------------------------------
// Selector chip — used for both question-count and subject filters.
// ----------------------------------------------------------------------------

interface ChipProps {
  label: string;
  active: boolean;
  onPress: () => void;
}

const Chip: React.FC<ChipProps> = React.memo(({ label, active, onPress }) => {
  const scale = useSharedValue(1);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Pressable
      onPress={() => {
        scale.value = withSpring(0.93, { damping: 14, stiffness: 220 });
        setTimeout(() => {
          scale.value = withSpring(1, { damping: 14, stiffness: 220 });
        }, 80);
        onPress();
      }}
    >
      <Animated.View style={[styles.chip, active && styles.chipActive, style]}>
        <Text style={[styles.chipText, active && styles.chipTextActive]}>{label}</Text>
      </Animated.View>
    </Pressable>
  );
});

// ----------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------

const BattleSetupScreen: React.FC = () => {
  const nav = useNavigation<Nav>();
  const route = useRoute<Rt>();
  const insets = useSafeAreaInsets();
  const { opponentId } = route.params;

  const [opponent, setOpponent] = useState<PublicUserProfile | null>(null);
  const [loadingOpp, setLoadingOpp] = useState(true);
  const [count, setCount] = useState<BattleQuestionCount>(20);
  const [subjectId, setSubjectId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        const p = await getUserPublicProfile(opponentId);
        if (!cancelled) setOpponent(p);
      } finally {
        if (!cancelled) setLoadingOpp(false);
      }
    };
    void run();
    return () => {
      cancelled = true;
    };
  }, [opponentId]);

  const availableSubjects = useMemo<readonly BattleSubjectOption[]>(() => BATTLE_SUBJECTS, []);

  const handleStart = useCallback(async () => {
    if (!opponent || creating) return;
    setCreating(true);
    try {
      const battle = await createBattle({
        opponentId: opponent.id,
        questionCount: count,
        subjectId,
      });
      nav.replace('BattleWaiting', { battleId: battle.id, role: 'challenger' });
    } catch {
      Alert.alert(KZ.errCreate);
    } finally {
      setCreating(false);
    }
  }, [opponent, creating, count, subjectId, nav]);

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
      />
      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          { paddingTop: insets.top + spacing.md, paddingBottom: insets.bottom + 120 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.title}>{KZ.title}</Text>

        <Text style={styles.sectionLabel}>{KZ.yourOpponent}</Text>
        {loadingOpp ? (
          <View style={styles.oppLoading}>
            <ActivityIndicator color={colors.white} />
            <Text style={styles.oppLoadingText}>{KZ.loadingOpp}</Text>
          </View>
        ) : opponent ? (
          <View style={styles.oppCard}>
            <View style={styles.oppAvatar}>
              <AvatarDisplay
                assistantType={assistantOrDefault(opponent.assistant_type)}
                action="idle"
                size={110}
              />
            </View>
            <View style={styles.oppMeta}>
              <Text style={styles.oppName}>{opponent.full_name}</Text>
              <Text style={styles.oppId}>{opponent.qosqanat_id}</Text>
              <View style={styles.oppChips}>
                <View style={styles.oppStat}>
                  <Text style={styles.oppStatText}>⭐ {KZ.level(opponent.level)}</Text>
                </View>
                <View style={[styles.oppStat, { backgroundColor: 'rgba(123,97,255,0.2)' }]}>
                  <Text style={[styles.oppStatText, { color: colors.secondary }]}>
                    {KZ.akyl(opponent.akyl_points)}
                  </Text>
                </View>
              </View>
              <Text style={styles.oppSub} numberOfLines={1}>
                {opponent.school}
              </Text>
            </View>
          </View>
        ) : null}

        <Text style={styles.sectionLabel}>{KZ.questions}</Text>
        <View style={styles.chipRow}>
          {QUESTION_COUNTS.map((n) => (
            <Chip key={n} label={`${n}`} active={count === n} onPress={() => { setCount(n); }} />
          ))}
        </View>

        <Text style={styles.sectionLabel}>{KZ.subjects}</Text>
        <View style={styles.chipRow}>
          <Chip
            label={KZ.allSubjects}
            active={subjectId === null}
            onPress={() => { setSubjectId(null); }}
          />
          {availableSubjects.map((s) => (
            <Chip
              key={s.id}
              label={`${s.icon} ${s.nameKz}`}
              active={subjectId === s.id}
              onPress={() => { setSubjectId(s.id); }}
            />
          ))}
        </View>

        <View style={styles.rulesBox}>
          <Text style={styles.rulesTitle}>{KZ.rulesTitle}</Text>
          {[KZ.rule1, KZ.rule2, KZ.rule3, KZ.rule4].map((r) => (
            <Text key={r} style={styles.rulesText}>
              {r}
            </Text>
          ))}
        </View>
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: insets.bottom + spacing.md }]}>
        <Pressable onPress={() => { nav.goBack(); }} style={styles.cancelBtn} disabled={creating}>
          <Text style={styles.cancelText}>{KZ.cancel}</Text>
        </Pressable>
        <Pressable
          onPress={handleStart}
          disabled={!opponent || creating}
          style={[styles.startBtn, (!opponent || creating) && styles.startBtnDisabled]}
        >
          <LinearGradient
            colors={[colors.danger, '#FF8C5A'] as readonly [string, string]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          {creating ? (
            <ActivityIndicator color={colors.white} />
          ) : (
            <Text style={styles.startText}>{KZ.start}</Text>
          )}
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#1A1A4E' },
  scroll: {
    paddingHorizontal: spacing.md,
    gap: spacing.md,
  },
  title: {
    color: colors.white,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
  sectionLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginTop: spacing.sm,
  },
  oppCard: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: radius.lg,
    padding: spacing.md,
    gap: spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  oppAvatar: {
    width: 110,
    height: 110,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  oppMeta: { flex: 1, gap: 4, justifyContent: 'center' },
  oppName: { color: colors.white, fontSize: fontSize.xl, fontWeight: fontWeight.extrabold },
  oppId: { color: colors.gold, fontSize: fontSize.sm, fontWeight: fontWeight.bold, marginTop: 2 },
  oppChips: { flexDirection: 'row', gap: 6, marginTop: 4 },
  oppStat: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: radius.full,
    backgroundColor: 'rgba(255,215,0,0.18)',
  },
  oppStatText: { color: colors.gold, fontSize: 11, fontWeight: fontWeight.extrabold },
  oppSub: { color: 'rgba(255,255,255,0.5)', fontSize: fontSize.xs, marginTop: 4 },
  oppLoading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
  },
  oppLoadingText: { color: 'rgba(255,255,255,0.65)', fontSize: fontSize.sm },
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  chip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.full,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  chipActive: {
    backgroundColor: colors.gold,
    borderColor: colors.gold,
  },
  chipText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
  },
  chipTextActive: { color: colors.text, fontWeight: fontWeight.extrabold },
  rulesBox: {
    backgroundColor: 'rgba(0,0,0,0.25)',
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    gap: 6,
    marginTop: spacing.sm,
  },
  rulesTitle: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
    marginBottom: 4,
  },
  rulesText: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: fontSize.sm,
    lineHeight: 20,
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    paddingHorizontal: spacing.md,
    paddingTop: spacing.md,
    gap: spacing.sm,
    backgroundColor: 'rgba(26,26,78,0.95)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  cancelBtn: {
    flex: 1,
    height: 56,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  cancelText: { color: colors.white, fontSize: fontSize.md, fontWeight: fontWeight.bold },
  startBtn: {
    flex: 2,
    height: 56,
    borderRadius: radius.md,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  startBtnDisabled: { opacity: 0.5 },
  startText: { color: colors.white, fontSize: fontSize.lg, fontWeight: fontWeight.extrabold },
});

export default BattleSetupScreen;
