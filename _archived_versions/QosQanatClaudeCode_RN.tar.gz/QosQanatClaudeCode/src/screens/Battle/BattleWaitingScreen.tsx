import { useNavigation, useRoute, type RouteProp } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, {
  Easing,
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AvatarDisplay from '@/components/Avatar/AvatarDisplay';
import type { AuthStackParamList } from '@/navigation/types';
import {
  acceptBattle,
  cancelBattle,
  getBattle,
  getUserPublicProfile,
  subscribeBattle,
  type BattleRow,
  type PublicUserProfile,
} from '@/services/api';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import type { AssistantType } from '@/types';

type Nav = NativeStackNavigationProp<AuthStackParamList, 'BattleWaiting'>;
type Rt = RouteProp<AuthStackParamList, 'BattleWaiting'>;

const KZ = {
  challengerWaiting: 'Қарсыласты күтіп тұрмыз...',
  opponentWaiting: 'Сізді шайқасқа шақырды!',
  challengerHint: 'Қарсылас қабылдағанша осы экранда күтіңіз.',
  opponentHint: 'Шайқасты қабылдағанда дереу басталады.',
  accept: '✓ Қабылдау',
  declineOrCancel: 'Болдырмау',
  rulesTitle: 'Шайқас ережелері',
  rule1: '⏱ Әр сұраққа 10 секунд',
  rule2: '✅ Дұрыс жауап = 1 ұпай',
  rule3: '🏆 Көбірек ұпай жинаған жеңеді',
  loading: 'Жүктелуде...',
  errLoad: 'Шайқасты ашу мүмкін болмады.',
  cancelledByOther: 'Қарсылас шайқастан бас тартты.',
  confirmCancel: 'Шайқастан бас тартасыз ба?',
  yes: 'Иә',
  no: 'Жоқ',
  vs: 'VS',
  you: 'Сіз',
  opponent: 'Қарсылас',
  questions: (n: number) => `Сұрақ саны: ${n}`,
};

const assistantOrDefault = (t: AssistantType | null): AssistantType => t ?? 'bektur';

// ----------------------------------------------------------------------------
// Loading dots
// ----------------------------------------------------------------------------

const LoadingDots: React.FC = () => {
  const d1 = useSharedValue(0);
  const d2 = useSharedValue(0);
  const d3 = useSharedValue(0);

  useEffect(() => {
    const make = (v: typeof d1, delay: number) => {
      v.value = withRepeat(
        withSequence(
          withTiming(0, { duration: delay }),
          withTiming(-8, { duration: 320, easing: Easing.out(Easing.quad) }),
          withTiming(0, { duration: 320, easing: Easing.in(Easing.quad) }),
          withTiming(0, { duration: 600 - delay }),
        ),
        -1,
      );
    };
    make(d1, 0);
    make(d2, 160);
    make(d3, 320);
    return () => {
      cancelAnimation(d1);
      cancelAnimation(d2);
      cancelAnimation(d3);
    };
  }, [d1, d2, d3]);

  const s1 = useAnimatedStyle(() => ({ transform: [{ translateY: d1.value }] }));
  const s2 = useAnimatedStyle(() => ({ transform: [{ translateY: d2.value }] }));
  const s3 = useAnimatedStyle(() => ({ transform: [{ translateY: d3.value }] }));

  return (
    <View style={styles.dotsRow}>
      <Animated.Text style={[styles.dot, s1]}>●</Animated.Text>
      <Animated.Text style={[styles.dot, s2]}>●</Animated.Text>
      <Animated.Text style={[styles.dot, s3]}>●</Animated.Text>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Animated VS badge
// ----------------------------------------------------------------------------

const VsBadge: React.FC = () => {
  const scale = useSharedValue(1);
  const rotate = useSharedValue(0);

  useEffect(() => {
    scale.value = withRepeat(
      withSequence(
        withTiming(1.12, { duration: 700, easing: Easing.inOut(Easing.quad) }),
        withTiming(1, { duration: 700, easing: Easing.inOut(Easing.quad) }),
      ),
      -1,
    );
    rotate.value = withRepeat(
      withSequence(
        withTiming(-6, { duration: 800, easing: Easing.inOut(Easing.quad) }),
        withTiming(6, { duration: 800, easing: Easing.inOut(Easing.quad) }),
      ),
      -1,
      true,
    );
    return () => {
      cancelAnimation(scale);
      cancelAnimation(rotate);
    };
  }, [scale, rotate]);

  const style = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }, { rotate: `${rotate.value}deg` }],
  }));

  return (
    <Animated.View style={[styles.vsBadge, style]}>
      <LinearGradient
        colors={[colors.danger, '#FF9C5A'] as readonly [string, string]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <Text style={styles.vsText}>{KZ.vs}</Text>
    </Animated.View>
  );
};

// ----------------------------------------------------------------------------
// Avatar tile (with a glow ring)
// ----------------------------------------------------------------------------

interface TileProps {
  label: string;
  name: string;
  assistant: AssistantType;
  accentColor: string;
}

const Tile: React.FC<TileProps> = ({ label, name, assistant, accentColor }) => {
  const pulse = useSharedValue(0);
  useEffect(() => {
    pulse.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 900, easing: Easing.inOut(Easing.quad) }),
        withTiming(0, { duration: 900, easing: Easing.inOut(Easing.quad) }),
      ),
      -1,
    );
    return () => { cancelAnimation(pulse); };
  }, [pulse]);
  const ring = useAnimatedStyle(() => ({
    opacity: 0.35 + pulse.value * 0.4,
    transform: [{ scale: 1 + pulse.value * 0.08 }],
  }));
  return (
    <View style={styles.tile}>
      <View style={styles.tileAvatarWrap}>
        <Animated.View style={[styles.tileRing, { borderColor: accentColor }, ring]} />
        <AvatarDisplay assistantType={assistant} action="idle" size={120} />
      </View>
      <Text style={[styles.tileLabel, { color: accentColor }]}>{label}</Text>
      <Text style={styles.tileName} numberOfLines={1}>
        {name}
      </Text>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------

const BattleWaitingScreen: React.FC = () => {
  const nav = useNavigation<Nav>();
  const route = useRoute<Rt>();
  const insets = useSafeAreaInsets();
  const me = useUserStore((s) => s.user);
  const { battleId, role } = route.params;

  const [battle, setBattle] = useState<BattleRow | null>(null);
  const [opponent, setOpponent] = useState<PublicUserProfile | null>(null);
  const [accepting, setAccepting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const subscriptionRef = useRef<{ unsubscribe: () => void } | null>(null);

  // ---------- Initial battle + opponent fetch ----------
  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        const row = await getBattle(battleId);
        if (cancelled) return;
        if (!row) {
          setError(KZ.errLoad);
          return;
        }
        setBattle(row);
        const oppId = role === 'challenger' ? row.opponent_id : row.challenger_id;
        const oppProfile = await getUserPublicProfile(oppId);
        if (!cancelled) setOpponent(oppProfile);
        // If the opponent has already accepted (race) — go right to battle.
        if (row.status === 'in_progress' || row.status === 'accepted') {
          nav.replace('Battle', { battleId });
        } else if (row.status === 'cancelled' || row.status === 'completed') {
          setError(KZ.cancelledByOther);
        }
      } catch {
        if (!cancelled) setError(KZ.errLoad);
      }
    };
    void run();
    return () => {
      cancelled = true;
    };
  }, [battleId, role, nav]);

  // ---------- Realtime row subscription ----------
  useEffect(() => {
    const sub = subscribeBattle(battleId, {
      onRow: (row) => {
        setBattle(row);
        if (row.status === 'in_progress' || row.status === 'accepted') {
          nav.replace('Battle', { battleId });
        }
        if (row.status === 'cancelled') {
          setError(KZ.cancelledByOther);
        }
      },
    });
    subscriptionRef.current = sub;
    return () => {
      sub.unsubscribe();
    };
  }, [battleId, nav]);

  // ---------- Actions ----------
  const handleAccept = useCallback(async () => {
    if (accepting) return;
    setAccepting(true);
    try {
      await acceptBattle(battleId);
      nav.replace('Battle', { battleId });
    } catch {
      setError(KZ.errLoad);
    } finally {
      setAccepting(false);
    }
  }, [accepting, battleId, nav]);

  const handleCancel = useCallback(() => {
    Alert.alert(KZ.confirmCancel, undefined, [
      { text: KZ.no, style: 'cancel' },
      {
        text: KZ.yes,
        style: 'destructive',
        onPress: async () => {
          try {
            await cancelBattle(battleId);
          } finally {
            nav.goBack();
          }
        },
      },
    ]);
  }, [battleId, nav]);

  // ---------- Render ----------
  if (!battle || !opponent || !me) {
    return (
      <View style={[styles.root, styles.center]}>
        <LinearGradient
          colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
          style={StyleSheet.absoluteFill}
        />
        <ActivityIndicator size="large" color={colors.white} />
        <Text style={styles.loadingText}>{KZ.loading}</Text>
        {error ? <Text style={styles.errorText}>{error}</Text> : null}
      </View>
    );
  }

  const myAssistant = assistantOrDefault(me.assistant_type ?? null);
  const oppAssistant = assistantOrDefault(opponent.assistant_type);

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
      />
      <View
        style={[
          styles.body,
          { paddingTop: insets.top + spacing.lg, paddingBottom: insets.bottom + spacing.lg },
        ]}
      >
        <View style={styles.headlineWrap}>
          <Text style={styles.headline}>
            {role === 'challenger' ? KZ.challengerWaiting : KZ.opponentWaiting}
          </Text>
          <Text style={styles.subhead}>
            {role === 'challenger' ? KZ.challengerHint : KZ.opponentHint}
          </Text>
          <Text style={styles.questions}>{KZ.questions(battle.question_count)}</Text>
        </View>

        <View style={styles.versusRow}>
          <Tile
            label={KZ.you}
            name={me.full_name}
            assistant={myAssistant}
            accentColor={colors.primary}
          />
          <VsBadge />
          <Tile
            label={KZ.opponent}
            name={opponent.full_name}
            assistant={oppAssistant}
            accentColor={colors.danger}
          />
        </View>

        {role === 'challenger' ? <LoadingDots /> : null}

        <View style={styles.rulesBox}>
          <Text style={styles.rulesTitle}>{KZ.rulesTitle}</Text>
          {[KZ.rule1, KZ.rule2, KZ.rule3].map((r) => (
            <Text key={r} style={styles.rulesText}>
              {r}
            </Text>
          ))}
        </View>

        {error ? <Text style={styles.errorText}>{error}</Text> : null}

        <View style={styles.actions}>
          {role === 'opponent' ? (
            <Pressable
              style={[styles.acceptBtn, accepting && styles.btnDisabled]}
              onPress={handleAccept}
              disabled={accepting}
            >
              <LinearGradient
                colors={[colors.success, '#3DDC97'] as readonly [string, string]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
              {accepting ? (
                <ActivityIndicator color={colors.white} />
              ) : (
                <Text style={styles.acceptText}>{KZ.accept}</Text>
              )}
            </Pressable>
          ) : null}
          <Pressable style={styles.cancelBtn} onPress={handleCancel}>
            <Text style={styles.cancelText}>{KZ.declineOrCancel}</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#1A1A4E' },
  center: { alignItems: 'center', justifyContent: 'center' },
  body: { flex: 1, paddingHorizontal: spacing.md, justifyContent: 'space-between' },
  headlineWrap: { alignItems: 'center', gap: 6 },
  headline: {
    color: colors.white,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
    textAlign: 'center',
  },
  subhead: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: fontSize.sm,
    textAlign: 'center',
  },
  questions: {
    color: colors.gold,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
    marginTop: 4,
  },
  versusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.sm,
  },
  tile: {
    flex: 1,
    alignItems: 'center',
    gap: spacing.sm,
  },
  tileAvatarWrap: {
    width: 140,
    height: 140,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tileRing: {
    position: 'absolute',
    width: 140,
    height: 140,
    borderRadius: 70,
    borderWidth: 3,
  },
  tileLabel: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  tileName: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
    textAlign: 'center',
    paddingHorizontal: 4,
  },
  vsBadge: {
    width: 76,
    height: 76,
    borderRadius: 38,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    shadowColor: colors.danger,
    shadowOpacity: 0.7,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 0 },
    elevation: 12,
  },
  vsText: {
    color: colors.white,
    fontSize: fontSize.xl,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 2,
  },
  dotsRow: { flexDirection: 'row', justifyContent: 'center', gap: 10 },
  dot: { color: colors.white, fontSize: 18, opacity: 0.85 },
  rulesBox: {
    backgroundColor: 'rgba(0,0,0,0.25)',
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    gap: 6,
  },
  rulesTitle: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
    marginBottom: 4,
  },
  rulesText: { color: 'rgba(255,255,255,0.85)', fontSize: fontSize.sm, lineHeight: 20 },
  actions: { gap: spacing.sm },
  acceptBtn: {
    height: 56,
    borderRadius: radius.md,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  acceptText: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
  },
  cancelBtn: {
    height: 52,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  cancelText: { color: colors.white, fontSize: fontSize.md, fontWeight: fontWeight.bold },
  btnDisabled: { opacity: 0.5 },
  loadingText: {
    color: 'rgba(255,255,255,0.7)',
    marginTop: spacing.md,
    fontSize: fontSize.md,
  },
  errorText: {
    color: colors.danger,
    textAlign: 'center',
    fontSize: fontSize.sm,
    marginTop: spacing.sm,
    fontWeight: fontWeight.bold,
  },
});

export default BattleWaitingScreen;
