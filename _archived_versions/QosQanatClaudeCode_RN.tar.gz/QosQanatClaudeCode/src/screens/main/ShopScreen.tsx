import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Dimensions,
  FlatList,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type ListRenderItem,
} from 'react-native';
import { GestureDetector, Gesture } from 'react-native-gesture-handler';
import Animated, {
  Easing,
  cancelAnimation,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AvatarDisplay from '@/components/Avatar/AvatarDisplay';
import AnimatedCounter from '@/components/Game/AnimatedCounter';
import {
  CATEGORY_LABELS_KZ,
  CATEGORY_ORDER,
  RARITY_COLORS,
  RARITY_LABELS_KZ,
  itemsByCategory,
  type ShopItem,
} from '@/data/shopItems';
import {
  equipItem as apiEquipItem,
  getEquipment,
  getInventory,
  purchaseItem as apiPurchaseItem,
} from '@/services/api';
import { useGameStore } from '@/store/gameStore';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import type { ItemCategory } from '@/types';

const KZ = {
  title: '🛍️ Дүкен',
  loading: 'Жүктелуде...',
  buy: (price: number) => `Сатып алу: ${price} 💰`,
  buyShort: 'Сатып алу',
  tryOn: 'Аватарда көру',
  stopPreview: 'Алдын ала қарауды тоқтату',
  equip: 'Кию',
  equipped: 'КИГЕН ✓',
  owned: 'АЛЫНДЫ ✓',
  newBadge: 'ЖАҢА',
  lockBadge: (lvl: number) => `🔒 Деңгей ${lvl}`,
  free: 'ТЕГІН',
  confirmTitle: 'Сатып алуды растайсыз ба?',
  confirmYes: 'Иә, сатып аламын',
  confirmNo: 'Болдырмау',
  insufficient: '💰 Монета жетімсіз!',
  bought: 'Алынды! ✓',
  equippedToast: 'Кигіздіңіз! ✓',
  errorGeneric: 'Қателік шықты. Қайталап көріңіз.',
  closeSheet: 'Жабу',
  emptyCategory: 'Бұл санатта тауар жоқ.',
};

const SCREEN_W = Dimensions.get('window').width;
const PREVIEW_SIZE = 200;
const CARD_GAP = spacing.md;
const GRID_PADDING_H = spacing.md;
const CARD_WIDTH = (SCREEN_W - GRID_PADDING_H * 2 - CARD_GAP) / 2;
const CARD_AVATAR_SIZE = Math.min(96, CARD_WIDTH - 32);

// ----------------------------------------------------------------------------
// Toast (in-screen status pill — purchase success / failure)
// ----------------------------------------------------------------------------

type ToastKind = 'success' | 'error';

interface ToastProps {
  kind: ToastKind;
  message: string;
  onDone: () => void;
}

const Toast: React.FC<ToastProps> = ({ kind, message, onDone }) => {
  const opacity = useSharedValue(0);
  const translateY = useSharedValue(20);

  useEffect(() => {
    opacity.value = withTiming(1, { duration: 180 });
    translateY.value = withSpring(0, { damping: 12, stiffness: 220 });
    opacity.value = withDelay(
      1400,
      withTiming(0, { duration: 250, easing: Easing.in(Easing.quad) }, (finished) => {
        if (finished) runOnJS(onDone)();
      }),
    );
  }, [opacity, translateY, onDone]);

  const style = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateY: translateY.value }],
  }));

  const bg = kind === 'success' ? colors.success : colors.danger;

  return (
    <Animated.View pointerEvents="none" style={[styles.toast, { backgroundColor: bg }, style]}>
      <Text style={styles.toastText}>{message}</Text>
    </Animated.View>
  );
};

// ----------------------------------------------------------------------------
// Coin spend animation — overlays a "-N 💰" chip that floats up & fades.
// ----------------------------------------------------------------------------

interface CoinSpendChipProps {
  amount: number;
  onDone: () => void;
}

const CoinSpendChip: React.FC<CoinSpendChipProps> = ({ amount, onDone }) => {
  const translateY = useSharedValue(0);
  const opacity = useSharedValue(0);
  const scale = useSharedValue(0.7);

  useEffect(() => {
    opacity.value = withSequence(
      withTiming(1, { duration: 180 }),
      withTiming(1, { duration: 360 }),
      withTiming(0, { duration: 260, easing: Easing.in(Easing.quad) }, (finished) => {
        if (finished) runOnJS(onDone)();
      }),
    );
    scale.value = withSpring(1.1, { damping: 7, stiffness: 220 });
    translateY.value = withTiming(-60, { duration: 800, easing: Easing.out(Easing.cubic) });
  }, [opacity, scale, translateY, onDone]);

  const style = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateY: translateY.value }, { scale: scale.value }],
  }));

  return (
    <Animated.View pointerEvents="none" style={[styles.spendChip, style]}>
      <Text style={styles.spendChipText}>-{amount} 💰</Text>
    </Animated.View>
  );
};

// ----------------------------------------------------------------------------
// Avatar preview — 200px full-body, swipe horizontally to rotate.
// ----------------------------------------------------------------------------

interface AvatarPreviewProps {
  assistantType: 'bektur' | 'nazym';
  equippedItems: Partial<Record<ItemCategory, string>>;
}

const AvatarPreview: React.FC<AvatarPreviewProps> = ({ assistantType, equippedItems }) => {
  const rotateY = useSharedValue(0);
  const startRotate = useSharedValue(0);

  const pan = Gesture.Pan()
    .onStart(() => {
      startRotate.value = rotateY.value;
    })
    .onUpdate((e) => {
      // Translate horizontal pan to Y-axis rotation, clamped to ±60° so the
      // avatar never fully turns its back to the camera.
      const next = startRotate.value + e.translationX * 0.6;
      rotateY.value = Math.max(-60, Math.min(60, next));
    })
    .onEnd(() => {
      // Snap back to face-front when the gesture lifts.
      rotateY.value = withSpring(0, { damping: 14, stiffness: 110 });
    });

  const wrapStyle = useAnimatedStyle(() => ({
    transform: [{ perspective: 600 }, { rotateY: `${rotateY.value}deg` }],
  }));

  return (
    <View style={styles.previewWrap}>
      <LinearGradient
        colors={['rgba(255,255,255,0.18)', 'rgba(255,255,255,0.04)'] as readonly [string, string]}
        style={styles.previewStage}
      >
        <GestureDetector gesture={pan}>
          <Animated.View style={[styles.previewAvatar, wrapStyle]}>
            <AvatarDisplay
              assistantType={assistantType}
              equippedItems={equippedItems}
              action="idle"
              size={PREVIEW_SIZE}
            />
          </Animated.View>
        </GestureDetector>
      </LinearGradient>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Category tab
// ----------------------------------------------------------------------------

interface CategoryTabProps {
  category: ItemCategory;
  active: boolean;
  onPress: () => void;
}

const CATEGORY_ICONS: Record<ItemCategory, string> = {
  top: '👕',
  bottom: '👖',
  hat: '🎩',
  accessory: '🎒',
  pet: '🐾',
};

const CategoryTab: React.FC<CategoryTabProps> = ({ category, active, onPress }) => {
  const scale = useSharedValue(active ? 1 : 0.98);
  useEffect(() => {
    scale.value = withSpring(active ? 1 : 0.97, { damping: 14, stiffness: 220 });
  }, [active, scale]);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Pressable onPress={onPress}>
      <Animated.View style={[styles.tab, active && styles.tabActive, style]}>
        <Text style={styles.tabIcon}>{CATEGORY_ICONS[category]}</Text>
        <Text style={[styles.tabLabel, active && styles.tabLabelActive]}>
          {CATEGORY_LABELS_KZ[category]}
        </Text>
      </Animated.View>
    </Pressable>
  );
};

// ----------------------------------------------------------------------------
// Item card
// ----------------------------------------------------------------------------

type ItemStatus = 'equipped' | 'owned' | 'locked' | 'available';

interface ItemCardProps {
  item: ShopItem;
  status: ItemStatus;
  userLevel: number;
  assistantType: 'bektur' | 'nazym';
  cardEquippedItems: Partial<Record<ItemCategory, string>>;
  onPress: () => void;
}

const ItemCard: React.FC<ItemCardProps> = React.memo(
  ({ item, status, userLevel, assistantType, cardEquippedItems, onPress }) => {
    const scale = useSharedValue(1);
    const style = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

    const rarityColor = RARITY_COLORS[item.rarity];
    const locked = status === 'locked';
    const isEquipped = status === 'equipped';
    const isOwned = status === 'owned';

    return (
      <Pressable
        onPressIn={() => {
          scale.value = withSpring(0.95, { damping: 14, stiffness: 220 });
        }}
        onPressOut={() => {
          scale.value = withSpring(1, { damping: 12, stiffness: 200 });
        }}
        onPress={onPress}
      >
        <Animated.View
          style={[
            styles.card,
            { borderColor: isEquipped ? colors.gold : `${rarityColor}55` },
            style,
          ]}
        >
          {/* Top-right status / rarity / new badge */}
          {isEquipped ? (
            <View style={[styles.cardBadge, { backgroundColor: colors.gold }]}>
              <Text style={[styles.cardBadgeText, { color: colors.text }]}>{KZ.equipped}</Text>
            </View>
          ) : isOwned ? (
            <View style={[styles.cardBadge, { backgroundColor: colors.success }]}>
              <Text style={styles.cardBadgeText}>{KZ.owned}</Text>
            </View>
          ) : item.isNew ? (
            <View style={[styles.cardBadge, { backgroundColor: colors.danger }]}>
              <Text style={styles.cardBadgeText}>{KZ.newBadge}</Text>
            </View>
          ) : item.rarity !== 'common' ? (
            <View style={[styles.cardBadge, { backgroundColor: rarityColor }]}>
              <Text style={styles.cardBadgeText}>{RARITY_LABELS_KZ[item.rarity]}</Text>
            </View>
          ) : null}

          {/* Avatar preview with this item equipped on top of current loadout */}
          <View style={[styles.cardPreviewWrap, { backgroundColor: `${rarityColor}15` }]}>
            <AvatarDisplay
              assistantType={assistantType}
              equippedItems={cardEquippedItems}
              action="idle"
              size={CARD_AVATAR_SIZE}
            />
            {locked ? (
              <View style={styles.lockOverlay}>
                <Text style={styles.lockText}>{KZ.lockBadge(item.levelRequired)}</Text>
              </View>
            ) : null}
          </View>

          <Text style={styles.cardName} numberOfLines={1}>
            {item.nameKz}
          </Text>
          <View style={styles.cardPriceRow}>
            {item.price === 0 ? (
              <Text style={styles.cardPriceFree}>{KZ.free}</Text>
            ) : (
              <Text style={[styles.cardPrice, locked && styles.cardPriceLocked]}>
                💰 {item.price}
              </Text>
            )}
            {locked ? <Text style={styles.cardLockedHint}>лвл {item.levelRequired}</Text> : null}
            {!locked &&
            userLevel >= item.levelRequired &&
            !isOwned &&
            !isEquipped &&
            item.price > 0 ? (
              <Text style={styles.cardAvailableHint}>✨</Text>
            ) : null}
          </View>
        </Animated.View>
      </Pressable>
    );
  },
);

// ----------------------------------------------------------------------------
// Bottom sheet
// ----------------------------------------------------------------------------

interface BottomSheetProps {
  item: ShopItem;
  status: ItemStatus;
  userCoins: number;
  userLevel: number;
  assistantType: 'bektur' | 'nazym';
  isPreviewing: boolean;
  onClose: () => void;
  onTryOn: () => void;
  onAction: () => void;
}

const BottomSheet: React.FC<BottomSheetProps> = ({
  item,
  status,
  userCoins,
  userLevel,
  assistantType,
  isPreviewing,
  onClose,
  onTryOn,
  onAction,
}) => {
  const translateY = useSharedValue(400);

  useEffect(() => {
    translateY.value = withSpring(0, { damping: 18, stiffness: 180 });
    return () => {
      cancelAnimation(translateY);
    };
  }, [translateY]);

  const sheetStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
  }));

  const rarityColor = RARITY_COLORS[item.rarity];
  const locked = status === 'locked';
  const isEquipped = status === 'equipped';
  const isOwned = status === 'owned';
  const canAfford = userCoins >= item.price;

  let actionLabel: string;
  let actionDisabled = false;
  if (isEquipped) {
    actionLabel = KZ.equipped;
    actionDisabled = true;
  } else if (isOwned) {
    actionLabel = KZ.equip;
  } else if (locked) {
    actionLabel = KZ.lockBadge(item.levelRequired);
    actionDisabled = true;
  } else if (item.price === 0) {
    actionLabel = KZ.equip;
  } else {
    actionLabel = KZ.buy(item.price);
    actionDisabled = !canAfford;
  }

  return (
    <Pressable style={styles.sheetBackdrop} onPress={onClose}>
      <Animated.View style={[styles.sheet, sheetStyle]} onStartShouldSetResponder={() => true}>
        <Pressable onPress={() => undefined}>
          <View style={styles.sheetHandle} />
          <View style={styles.sheetPreview}>
            <View style={[styles.sheetPreviewStage, { backgroundColor: `${rarityColor}20` }]}>
              <AvatarDisplay
                assistantType={assistantType}
                equippedItems={{ [item.category]: item.id }}
                action="idle"
                size={140}
              />
            </View>
            <View style={styles.sheetHeaderText}>
              <Text style={[styles.sheetRarity, { color: rarityColor }]}>
                {RARITY_LABELS_KZ[item.rarity]}
              </Text>
              <Text style={styles.sheetTitle}>{item.nameKz}</Text>
              <Text style={styles.sheetDescription}>{item.descriptionKz}</Text>
              <Text style={styles.sheetMeta}>
                {CATEGORY_LABELS_KZ[item.category]} · Деңгей {item.levelRequired}+
              </Text>
            </View>
          </View>

          <Pressable
            onPress={onTryOn}
            style={[styles.sheetSecondaryBtn, isPreviewing && styles.sheetSecondaryBtnActive]}
          >
            <Text style={styles.sheetSecondaryText}>
              {isPreviewing ? KZ.stopPreview : KZ.tryOn}
            </Text>
          </Pressable>

          <Pressable
            onPress={actionDisabled ? undefined : onAction}
            disabled={actionDisabled}
            style={[styles.sheetPrimaryBtn, actionDisabled && styles.sheetPrimaryBtnDisabled]}
          >
            <LinearGradient
              colors={
                actionDisabled
                  ? (['#555', '#333'] as readonly [string, string])
                  : ([colors.primary, colors.secondary] as readonly [string, string])
              }
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            <Text style={styles.sheetPrimaryText}>{actionLabel}</Text>
          </Pressable>

          {!isOwned && !isEquipped && !locked && item.price > 0 && !canAfford ? (
            <Text style={styles.sheetWarn}>{KZ.insufficient}</Text>
          ) : null}

          <Pressable onPress={onClose} hitSlop={10} style={styles.sheetClose}>
            <Text style={styles.sheetCloseText}>{KZ.closeSheet}</Text>
          </Pressable>

          <View style={{ height: spacing.lg }} />
        </Pressable>
      </Animated.View>
    </Pressable>
  );
};

// ----------------------------------------------------------------------------
// Confirm modal
// ----------------------------------------------------------------------------

interface ConfirmProps {
  item: ShopItem;
  onCancel: () => void;
  onConfirm: () => void;
}

const Confirm: React.FC<ConfirmProps> = ({ item, onCancel, onConfirm }) => (
  <View style={styles.confirmBackdrop}>
    <View style={styles.confirmBox}>
      <Text style={styles.confirmTitle}>{KZ.confirmTitle}</Text>
      <Text style={styles.confirmBody}>
        {item.nameKz} — <Text style={{ color: colors.gold }}>{item.price} 💰</Text>
      </Text>
      <View style={styles.confirmRow}>
        <Pressable style={[styles.confirmBtn, styles.confirmCancel]} onPress={onCancel}>
          <Text style={styles.confirmBtnText}>{KZ.confirmNo}</Text>
        </Pressable>
        <Pressable style={[styles.confirmBtn, styles.confirmYes]} onPress={onConfirm}>
          <Text style={[styles.confirmBtnText, { color: colors.white }]}>{KZ.confirmYes}</Text>
        </Pressable>
      </View>
    </View>
  </View>
);

// ----------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------

const ShopScreen: React.FC = () => {
  const insets = useSafeAreaInsets();
  const user = useUserStore((s) => s.user);
  const coins = useGameStore((s) => s.coins);
  const level = useGameStore((s) => s.level);
  const spendCoins = useGameStore((s) => s.spendCoins);

  const assistantType = (user?.assistant_type ?? 'bektur');

  const [owned, setOwned] = useState<ReadonlySet<string>>(() => new Set());
  const [equipped, setEquipped] = useState<Partial<Record<ItemCategory, string>>>({});
  const [selectedCategory, setSelectedCategory] = useState<ItemCategory>('top');
  const [sheetItem, setSheetItem] = useState<ShopItem | null>(null);
  const [previewItem, setPreviewItem] = useState<ShopItem | null>(null);
  const [confirmItem, setConfirmItem] = useState<ShopItem | null>(null);
  const [toast, setToast] = useState<{ kind: ToastKind; message: string; id: number } | null>(null);
  const [spendChips, setSpendChips] = useState<readonly { id: number; amount: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  // ------------------------------------------------------------------
  // Load inventory + equipment on first mount.
  // ------------------------------------------------------------------
  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        setLoading(true);
        const [inv, eq] = await Promise.all([getInventory(), getEquipment()]);
        if (cancelled) return;
        setOwned(inv);
        setEquipped(eq);
      } catch {
        // Soft-fail; user can retry by switching categories.
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    void run();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  // ------------------------------------------------------------------
  // Helpers
  // ------------------------------------------------------------------
  const showToast = useCallback((kind: ToastKind, message: string) => {
    setToast({ kind, message, id: Date.now() });
  }, []);

  const previewEquipped = useMemo<Partial<Record<ItemCategory, string>>>(() => {
    if (!previewItem) return equipped;
    return { ...equipped, [previewItem.category]: previewItem.id };
  }, [equipped, previewItem]);

  const statusFor = useCallback(
    (item: ShopItem): ItemStatus => {
      const equippedId = equipped[item.category];
      // An item is "equipped" if (a) its id is in the equipment map, OR
      // (b) the slot is empty AND this item is the default ("school uniform"
      //     or "Жоқ") for that category.
      if (equippedId === item.id) return 'equipped';
      if (equippedId === undefined && item.isDefault && item.price === 0) return 'equipped';
      if (owned.has(item.id)) return 'owned';
      if (level < item.levelRequired) return 'locked';
      return 'available';
    },
    [equipped, owned, level],
  );

  // Equip an item the user already owns (or a default). Optimistic + API.
  const equip = useCallback(
    async (item: ShopItem, opts: { silent?: boolean } = {}) => {
      const prev = equipped;
      const next = { ...equipped, [item.category]: item.id };
      setEquipped(next);
      try {
        await apiEquipItem(item.id);
        if (!opts.silent) showToast('success', KZ.equippedToast);
      } catch {
        setEquipped(prev);
        showToast('error', KZ.errorGeneric);
      }
    },
    [equipped, showToast],
  );

  // Open the bottom sheet for an item.
  const openSheet = useCallback((item: ShopItem) => {
    setSheetItem(item);
    setPreviewItem(null);
  }, []);

  const closeSheet = useCallback(() => {
    setSheetItem(null);
    setPreviewItem(null);
  }, []);

  // ------------------------------------------------------------------
  // Primary action handler — what the big button at the bottom of the
  // sheet does depends on the current item status.
  // ------------------------------------------------------------------
  const handlePrimaryAction = useCallback(
    async (item: ShopItem) => {
      const status = statusFor(item);
      if (busy) return;

      if (status === 'equipped' || status === 'locked') return;

      if (status === 'owned') {
        await equip(item);
        closeSheet();
        return;
      }

      // 'available' with price > 0 — open confirm modal.
      if (item.price === 0) {
        await equip(item);
        closeSheet();
        return;
      }
      if (coins < item.price) {
        showToast('error', KZ.insufficient);
        return;
      }
      setConfirmItem(item);
    },
    [statusFor, busy, equip, closeSheet, coins, showToast],
  );

  const handleConfirmPurchase = useCallback(
    async (item: ShopItem) => {
      setConfirmItem(null);
      if (busy) return;
      setBusy(true);
      const id = Date.now();
      setSpendChips((c) => [...c, { id, amount: item.price }]);
      try {
        const ok = await spendCoins(item.price);
        if (!ok) {
          showToast('error', KZ.insufficient);
          return;
        }
        await apiPurchaseItem(item.id);
        setOwned((curr) => {
          const next = new Set(curr);
          next.add(item.id);
          return next;
        });
        await equip(item, { silent: true });
        showToast('success', KZ.bought);
        closeSheet();
      } catch {
        showToast('error', KZ.errorGeneric);
      } finally {
        setBusy(false);
      }
    },
    [busy, spendCoins, equip, showToast, closeSheet],
  );

  const removeSpendChip = useCallback((id: number) => {
    setSpendChips((c) => c.filter((x) => x.id !== id));
  }, []);

  // ------------------------------------------------------------------
  // List rendering
  // ------------------------------------------------------------------
  const items = useMemo(() => itemsByCategory(selectedCategory), [selectedCategory]);

  const renderItem: ListRenderItem<ShopItem> = useCallback(
    ({ item }) => {
      const status = statusFor(item);
      // Show the card preview with the user's full current loadout PLUS this
      // item overlaid in its slot, so the player always sees the change.
      const cardEquippedItems: Partial<Record<ItemCategory, string>> = {
        ...equipped,
        [item.category]: item.id,
      };
      return (
        <ItemCard
          item={item}
          status={status}
          userLevel={level}
          assistantType={assistantType}
          cardEquippedItems={cardEquippedItems}
          onPress={() => { openSheet(item); }}
        />
      );
    },
    [statusFor, equipped, level, assistantType, openSheet],
  );

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      />

      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Text style={styles.headerTitle}>{KZ.title}</Text>
        <View style={styles.headerCoinPill}>
          <AnimatedCounter
            value={coins}
            icon="🪙"
            color={colors.white}
            pillColor="rgba(255,255,255,0.2)"
          />
        </View>
      </View>

      <AvatarPreview assistantType={assistantType} equippedItems={previewEquipped} />

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.tabRow}
      >
        {CATEGORY_ORDER.map((cat) => (
          <CategoryTab
            key={cat}
            category={cat}
            active={selectedCategory === cat}
            onPress={() => { setSelectedCategory(cat); }}
          />
        ))}
      </ScrollView>

      {loading ? (
        <View style={styles.emptyWrap}>
          <Text style={styles.emptyText}>{KZ.loading}</Text>
        </View>
      ) : items.length === 0 ? (
        <View style={styles.emptyWrap}>
          <Text style={styles.emptyText}>{KZ.emptyCategory}</Text>
        </View>
      ) : (
        <FlatList
          data={items}
          renderItem={renderItem}
          keyExtractor={(it) => it.id}
          numColumns={2}
          columnWrapperStyle={styles.gridRow}
          contentContainerStyle={[
            styles.gridContent,
            { paddingBottom: insets.bottom + spacing.xl },
          ]}
          showsVerticalScrollIndicator={false}
        />
      )}

      <Modal
        visible={sheetItem !== null}
        transparent
        animationType="fade"
        onRequestClose={closeSheet}
      >
        {sheetItem ? (
          <BottomSheet
            item={sheetItem}
            status={statusFor(sheetItem)}
            userCoins={coins}
            userLevel={level}
            assistantType={assistantType}
            isPreviewing={previewItem?.id === sheetItem.id}
            onClose={closeSheet}
            onTryOn={() => { setPreviewItem((prev) => (prev?.id === sheetItem.id ? null : sheetItem)); }}
            onAction={() => handlePrimaryAction(sheetItem)}
          />
        ) : null}
      </Modal>

      <Modal
        visible={confirmItem !== null}
        transparent
        animationType="fade"
        onRequestClose={() => { setConfirmItem(null); }}
      >
        {confirmItem ? (
          <Confirm
            item={confirmItem}
            onCancel={() => { setConfirmItem(null); }}
            onConfirm={() => void handleConfirmPurchase(confirmItem)}
          />
        ) : null}
      </Modal>

      {spendChips.map((chip) => (
        <CoinSpendChip key={chip.id} amount={chip.amount} onDone={() => { removeSpendChip(chip.id); }} />
      ))}

      {toast ? (
        <Toast
          key={toast.id}
          kind={toast.kind}
          message={toast.message}
          onDone={() => { setToast(null); }}
        />
      ) : null}
    </View>
  );
};

// ----------------------------------------------------------------------------
// Styles
// ----------------------------------------------------------------------------

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#1A1A4E',
  },
  header: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.sm,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerTitle: {
    color: colors.white,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
  },
  headerCoinPill: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  previewWrap: {
    alignItems: 'center',
    marginTop: spacing.sm,
    marginBottom: spacing.sm,
    paddingHorizontal: spacing.md,
  },
  previewStage: {
    width: PREVIEW_SIZE + 60,
    height: PREVIEW_SIZE + 60,
    borderRadius: radius.xl,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  previewAvatar: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabRow: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    gap: spacing.sm,
    flexDirection: 'row',
  },
  tab: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.full,
    backgroundColor: 'rgba(255,255,255,0.08)',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  tabActive: {
    backgroundColor: colors.gold,
    borderColor: colors.gold,
  },
  tabIcon: {
    fontSize: 16,
  },
  tabLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
  },
  tabLabelActive: {
    color: colors.text,
    fontWeight: fontWeight.extrabold,
  },
  gridRow: {
    gap: CARD_GAP,
    justifyContent: 'space-between',
  },
  gridContent: {
    paddingHorizontal: GRID_PADDING_H,
    paddingTop: spacing.sm,
    gap: CARD_GAP,
  },
  card: {
    width: CARD_WIDTH,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: radius.lg,
    padding: spacing.sm,
    borderWidth: 2,
    overflow: 'hidden',
    alignItems: 'center',
  },
  cardBadge: {
    position: 'absolute',
    top: 6,
    right: 6,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: radius.sm,
    zIndex: 2,
  },
  cardBadgeText: {
    color: colors.white,
    fontSize: 10,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 0.5,
  },
  cardPreviewWrap: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    marginBottom: spacing.xs,
  },
  lockOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  lockText: {
    color: colors.white,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
  },
  cardName: {
    color: colors.white,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
    marginTop: 4,
    textAlign: 'center',
    width: '100%',
  },
  cardPriceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    marginTop: 2,
  },
  cardPrice: {
    color: colors.gold,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
  },
  cardPriceFree: {
    color: colors.success,
    fontSize: 11,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 0.5,
  },
  cardPriceLocked: {
    color: 'rgba(255,255,255,0.4)',
  },
  cardLockedHint: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 10,
    fontWeight: fontWeight.semibold,
  },
  cardAvailableHint: {
    fontSize: 12,
  },
  emptyWrap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: fontSize.md,
  },
  // ---- Bottom sheet ----
  sheetBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: '#1A1A4E',
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    padding: spacing.lg,
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  sheetHandle: {
    alignSelf: 'center',
    width: 44,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.25)',
    marginBottom: spacing.md,
  },
  sheetPreview: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.lg,
  },
  sheetPreviewStage: {
    width: 140,
    height: 140,
    borderRadius: radius.lg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sheetHeaderText: {
    flex: 1,
    gap: 4,
    justifyContent: 'center',
  },
  sheetRarity: {
    fontSize: 11,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  sheetTitle: {
    color: colors.white,
    fontSize: fontSize.xl,
    fontWeight: fontWeight.extrabold,
  },
  sheetDescription: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: fontSize.sm,
    lineHeight: 18,
  },
  sheetMeta: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 11,
    marginTop: 4,
    fontWeight: fontWeight.semibold,
  },
  sheetSecondaryBtn: {
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    backgroundColor: 'rgba(255,255,255,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  sheetSecondaryBtnActive: {
    backgroundColor: 'rgba(255,215,0,0.18)',
    borderColor: colors.gold,
  },
  sheetSecondaryText: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
  },
  sheetPrimaryBtn: {
    height: 56,
    borderRadius: radius.md,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
    elevation: 6,
  },
  sheetPrimaryBtnDisabled: {
    opacity: 0.5,
  },
  sheetPrimaryText: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
  },
  sheetWarn: {
    color: colors.danger,
    textAlign: 'center',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
    marginTop: spacing.sm,
  },
  sheetClose: {
    alignItems: 'center',
    marginTop: spacing.md,
  },
  sheetCloseText: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
  },
  // ---- Confirm modal ----
  confirmBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.65)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.lg,
  },
  confirmBox: {
    width: '100%',
    maxWidth: 360,
    backgroundColor: '#2A2870',
    borderRadius: radius.lg,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  confirmTitle: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
    marginBottom: spacing.sm,
    textAlign: 'center',
  },
  confirmBody: {
    color: colors.white,
    fontSize: fontSize.md,
    textAlign: 'center',
    marginBottom: spacing.lg,
  },
  confirmRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  confirmBtn: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    alignItems: 'center',
  },
  confirmCancel: {
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  confirmYes: {
    backgroundColor: colors.primary,
  },
  confirmBtnText: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
  },
  // ---- Toasts ----
  toast: {
    position: 'absolute',
    bottom: 100,
    alignSelf: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderRadius: radius.full,
    shadowColor: '#000',
    shadowOpacity: 0.4,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
  toastText: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
  },
  spendChip: {
    position: 'absolute',
    top: 60,
    right: spacing.md + 30,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.full,
    backgroundColor: 'rgba(0,0,0,0.6)',
  },
  spendChipText: {
    color: colors.gold,
    fontWeight: fontWeight.extrabold,
    fontSize: fontSize.md,
  },
});

export default ShopScreen;
