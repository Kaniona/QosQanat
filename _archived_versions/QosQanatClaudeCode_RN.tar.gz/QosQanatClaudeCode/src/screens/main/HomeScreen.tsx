import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Dimensions,
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type ListRenderItem,
} from 'react-native';
import Animated, {
  Easing,
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AvatarDisplay from '@/components/Avatar/AvatarDisplay';
import AnimatedCounter from '@/components/Game/AnimatedCounter';
import XPBar from '@/components/Game/XPBar';
import QuestCard from '@/components/Quest/QuestCard';
import VoiceButton from '@/components/VoiceButton';
import { getLevelInfo } from '@/data/levels';
import {
  claimDailyQuest,
  ensureTodayQuests,
  getRecentAchievements,
  getUnreadNotificationCount,
  type DailyQuestState,
  type UnlockedAchievement,
} from '@/services/api';
import { useGameStore } from '@/store/gameStore';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

const KZ = {
  morning: (n: string) => `Қайырлы таң, ${n}! Таңертең оқу өте тиімді!`,
  afternoon: (n: string) => `Сәлем, ${n}! Бүгінгі тапсырмаларды орындадың ба?`,
  evening: (n: string) => `Кешкі сәлем, ${n}! Соңғы тапсырманы орындайық!`,
  night: 'Ұйықтар алдында бір тапсырма? 🌙',
  level: (l: number, t: string) => `Деңгей ${l} — ${t}`,
  streak: (n: number) => `🔥 ${n} күн қатарынан!`,
  streakTomorrow: (n: number) => `Ертең ${n + 1} болады!`,
  streakZero: 'Бүгін кір! Streak бастасаң 🔥',
  questsTitle: '📋 Бүгінгі квесттер',
  questsEmpty: 'Бүгінгі квесттер жүктелуде...',
  achievementsTitle: '🏅 Соңғы жетістіктер',
  achievementsEmpty: 'Алғашқы жетістік жақын!',
  seeAll: 'Барлығын көру →',
  learn: 'Оқу',
  battle: 'Батл',
  rating: 'Рейтинг',
  loading: 'Жүктелуде...',
  claimError: 'Сыйақыны алу мүмкін болмады. Қайталап көріңіз.',
};

const FAB_SIZE = 64;
const AVATAR_SIZE = 44;
const SCREEN_W = Dimensions.get('window').width;

const firstName = (full: string | undefined): string => {
  if (!full) return 'дос';
  const parts = full.trim().split(/\s+/);
  return parts[0] ?? 'дос';
};

const greetingFor = (hour: number, name: string): string => {
  if (hour >= 6 && hour < 12) return KZ.morning(name);
  if (hour >= 12 && hour < 18) return KZ.afternoon(name);
  if (hour >= 18 && hour < 22) return KZ.evening(name);
  return KZ.night;
};

// ----------------------------------------------------------------------------
// Flying-reward overlay: when the player claims a quest we briefly fly small
// reward chips up the screen toward the header counters. The counters
// themselves pop their own scale animation via AnimatedCounter once the store
// updates, so the chip just sells the "where it came from" half of the cue.
// ----------------------------------------------------------------------------

type FlyingKind = 'coins' | 'xp' | 'akyl';

interface FlyingReward {
  id: number;
  kind: FlyingKind;
  amount: number;
  startX: number;
  startY: number;
  targetX: number;
  targetY: number;
}

const FLY_ICONS: Record<FlyingKind, string> = { coins: '🪙', xp: '✨', akyl: '🔮' };
const FLY_COLORS: Record<FlyingKind, string> = {
  coins: colors.gold,
  xp: colors.success,
  akyl: colors.secondary,
};

interface FlyingChipProps {
  reward: FlyingReward;
  onDone: (id: number) => void;
}

const FlyingChip: React.FC<FlyingChipProps> = ({ reward, onDone }) => {
  const tx = useSharedValue(0);
  const ty = useSharedValue(0);
  const opacity = useSharedValue(0);
  const scale = useSharedValue(0.6);

  useEffect(() => {
    const dx = reward.targetX - reward.startX;
    const dy = reward.targetY - reward.startY;
    opacity.value = withSequence(
      withTiming(1, { duration: 140, easing: Easing.out(Easing.quad) }),
      withTiming(1, { duration: 380 }),
      withTiming(0, { duration: 180, easing: Easing.in(Easing.quad) }),
    );
    scale.value = withSequence(
      withSpring(1, { damping: 9, stiffness: 220 }),
      withTiming(1.2, { duration: 280 }),
      withTiming(0.6, { duration: 200 }),
    );
    tx.value = withTiming(dx, { duration: 700, easing: Easing.inOut(Easing.cubic) });
    ty.value = withTiming(dy, { duration: 700, easing: Easing.inOut(Easing.cubic) });
    const removeId = setTimeout(() => { onDone(reward.id); }, 780);
    return () => { clearTimeout(removeId); };
  }, [reward, tx, ty, opacity, scale, onDone]);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: tx.value }, { translateY: ty.value }, { scale: scale.value }],
    opacity: opacity.value,
  }));

  return (
    <Animated.View
      pointerEvents="none"
      style={[
        styles.flyingChip,
        { left: reward.startX, top: reward.startY, backgroundColor: FLY_COLORS[reward.kind] },
        animStyle,
      ]}
    >
      <Text style={styles.flyingIcon}>{FLY_ICONS[reward.kind]}</Text>
      <Text style={styles.flyingAmount}>+{reward.amount}</Text>
    </Animated.View>
  );
};

// ----------------------------------------------------------------------------
// Section: header (avatar + counters + bell)
// ----------------------------------------------------------------------------

interface HeaderProps {
  onAvatar: () => void;
  onBell: () => void;
  unreadCount: number;
  coins: number;
  xp: number;
  akyl: number;
  assistantInitial: string;
  assistantColor: string;
  registerCounterRef: (kind: FlyingKind, x: number, y: number) => void;
}

const Header: React.FC<HeaderProps> = ({
  onAvatar,
  onBell,
  unreadCount,
  coins,
  xp,
  akyl,
  assistantInitial,
  assistantColor,
  registerCounterRef,
}) => {
  return (
    <View style={styles.header}>
      <Pressable onPress={onAvatar} hitSlop={6}>
        <View
          style={[
            styles.avatarCircle,
            { backgroundColor: assistantColor, width: AVATAR_SIZE, height: AVATAR_SIZE },
          ]}
        >
          <Text style={styles.avatarInitial}>{assistantInitial}</Text>
        </View>
      </Pressable>

      <View style={styles.counters}>
        <View
          onLayout={(e) => {
            const { x, y, width, height } = e.nativeEvent.layout;
            registerCounterRef('coins', x + width / 2, y + height / 2);
          }}
        >
          <AnimatedCounter value={coins} icon="🪙" color={colors.white} />
        </View>
        <View
          onLayout={(e) => {
            const { x, y, width, height } = e.nativeEvent.layout;
            registerCounterRef('xp', x + width / 2, y + height / 2);
          }}
        >
          <AnimatedCounter value={xp} icon="✨" color={colors.white} />
        </View>
        <View
          onLayout={(e) => {
            const { x, y, width, height } = e.nativeEvent.layout;
            registerCounterRef('akyl', x + width / 2, y + height / 2);
          }}
        >
          <AnimatedCounter value={akyl} icon="🔮" color={colors.white} />
        </View>
      </View>

      <Pressable onPress={onBell} style={styles.bellWrap} hitSlop={6}>
        <Text style={styles.bellIcon}>🔔</Text>
        {unreadCount > 0 ? (
          <View style={styles.bellDot}>
            <Text style={styles.bellDotText}>{unreadCount > 9 ? '9+' : String(unreadCount)}</Text>
          </View>
        ) : null}
      </Pressable>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Section: achievements row item
// ----------------------------------------------------------------------------

interface AchievementBadgeProps {
  unlocked: UnlockedAchievement;
}

const AchievementBadge: React.FC<AchievementBadgeProps> = ({ unlocked }) => {
  const { achievement } = unlocked;
  return (
    <View style={styles.badge}>
      <LinearGradient
        colors={[colors.gold, '#FFB347'] as readonly [string, string]}
        style={styles.badgeCircle}
      >
        <Text style={styles.badgeIcon}>{achievement.icon}</Text>
      </LinearGradient>
      <Text style={styles.badgeLabel} numberOfLines={1}>
        {achievement.titleKz}
      </Text>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------

const HomeScreen: React.FC = () => {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();

  const user = useUserStore((s) => s.user);
  const coins = useGameStore((s) => s.coins);
  const akyl = useGameStore((s) => s.akylPoints);
  const xp = useGameStore((s) => s.xp);
  const level = useGameStore((s) => s.level);
  const currentStreak = useGameStore((s) => s.currentStreak);
  const addCoins = useGameStore((s) => s.addCoins);
  const addAkylPoints = useGameStore((s) => s.addAkylPoints);
  const addXP = useGameStore((s) => s.addXP);
  const setGameState = useGameStore((s) => s.setGameState);

  const [quests, setQuests] = useState<readonly DailyQuestState[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [achievements, setAchievements] = useState<readonly UnlockedAchievement[]>([]);
  const [questsLoading, setQuestsLoading] = useState(true);
  const [flyings, setFlyings] = useState<readonly FlyingReward[]>([]);

  // Mirror user fields into the gameStore so counters always reflect server truth.
  useEffect(() => {
    if (user) setGameState(user);
  }, [user, setGameState]);

  // Counter screen-coordinates registry (filled by Header onLayout). Used as
  // the destination for flying-reward chips when the player claims a quest.
  const counterTargets = useRef<Record<FlyingKind, { x: number; y: number }>>({
    coins: { x: SCREEN_W - 80, y: 60 },
    xp: { x: SCREEN_W - 130, y: 60 },
    akyl: { x: SCREEN_W - 180, y: 60 },
  });
  const headerY = useRef<number>(insets.top + 20);

  const registerCounterRef = useCallback((kind: FlyingKind, localX: number, localY: number) => {
    // The header is positioned at the top of the screen with its own padding;
    // approximate the absolute screen coords using insets + section offset.
    counterTargets.current[kind] = {
      x: spacing.md + 60 + localX, // 60 ≈ avatar + gap
      y: headerY.current + localY,
    };
  }, []);

  const loadData = useCallback(async () => {
    if (!user) return;
    try {
      setQuestsLoading(true);
      const [q, n, a] = await Promise.all([
        ensureTodayQuests(),
        getUnreadNotificationCount(),
        getRecentAchievements(6),
      ]);
      setQuests(q);
      setUnreadCount(n);
      setAchievements(a);
    } catch {
      // Soft-fail: keep showing whatever is currently in state. The next
      // focus refresh will retry.
    } finally {
      setQuestsLoading(false);
    }
  }, [user]);

  useFocusEffect(
    useCallback(() => {
      void loadData();
    }, [loadData]),
  );

  const fabColor = user?.assistant_type === 'nazym' ? colors.nazymColor : colors.bekturColor;
  const name = firstName(user?.full_name);
  const greeting = useMemo(() => greetingFor(new Date().getHours(), name), [name]);
  const levelInfo = useMemo(() => getLevelInfo(level), [level]);

  const goTo = useCallback(
    (route: string, fallback?: string) => {
      // Routes for other tabs/stacks aren't wired into this stack yet — fall
      // back to a friendly alert so taps still feel responsive in development.
      const nav = navigation as unknown as { navigate: (name: string) => void };
      try {
        nav.navigate(route);
      } catch {
        if (fallback) Alert.alert(fallback);
      }
    },
    [navigation],
  );

  const spawnFlying = useCallback(
    (kind: FlyingKind, amount: number, originX: number, originY: number) => {
      const target = counterTargets.current[kind];
      const id = Date.now() + Math.floor(Math.random() * 1000);
      const reward: FlyingReward = {
        id,
        kind,
        amount,
        startX: originX,
        startY: originY,
        targetX: target.x,
        targetY: target.y,
      };
      setFlyings((arr) => [...arr, reward]);
    },
    [],
  );

  const removeFlying = useCallback((id: number) => {
    setFlyings((arr) => arr.filter((f) => f.id !== id));
  }, []);

  const handleClaim = useCallback(
    async (state: DailyQuestState) => {
      const { quest } = state;
      // Optimistic UI: mark this row as claimed locally so the card flips to
      // "Аяқталды" before the network round-trip lands.
      setQuests((curr) => curr.map((q) => (q.id === state.id ? { ...q, status: 'claimed' } : q)));

      const originX = SCREEN_W / 2 - 28;
      const originY = 380;
      if (quest.rewardCoins > 0) spawnFlying('coins', quest.rewardCoins, originX, originY);
      if (quest.rewardXp > 0) spawnFlying('xp', quest.rewardXp, originX + 14, originY + 8);
      if (quest.rewardAkyl > 0) spawnFlying('akyl', quest.rewardAkyl, originX - 14, originY + 8);

      try {
        await claimDailyQuest(state.id);
        if (quest.rewardCoins > 0) await addCoins(quest.rewardCoins);
        if (quest.rewardXp > 0) await addXP(quest.rewardXp);
        if (quest.rewardAkyl > 0) await addAkylPoints(quest.rewardAkyl);
      } catch {
        // Roll back the optimistic flip so the player can retry.
        setQuests((curr) =>
          curr.map((q) => (q.id === state.id ? { ...q, status: 'completed' } : q)),
        );
        Alert.alert(KZ.claimError);
      }
    },
    [addCoins, addXP, addAkylPoints, spawnFlying],
  );

  const renderQuest: ListRenderItem<DailyQuestState> = useCallback(
    ({ item }) => <QuestCard state={item} onClaim={handleClaim} />,
    [handleClaim],
  );

  const renderBadge: ListRenderItem<UnlockedAchievement> = useCallback(
    ({ item }) => <AchievementBadge unlocked={item} />,
    [],
  );

  const assistantInitial = name.charAt(0).toUpperCase();

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      />

      <ScrollView showsVerticalScrollIndicator={false}>
        <View>
          <View
            style={[styles.headerSection, { paddingTop: insets.top + spacing.sm }]}
            onLayout={(e) => {
              headerY.current = e.nativeEvent.layout.y + insets.top + spacing.sm;
            }}
          >
            <Header
              onAvatar={() => { goTo('Profile', 'Профиль жақында'); }}
              onBell={() => { goTo('Notifications', 'Хабарламалар жақында'); }}
              unreadCount={unreadCount}
              coins={coins}
              xp={xp}
              akyl={akyl}
              assistantInitial={assistantInitial}
              assistantColor={fabColor}
              registerCounterRef={registerCounterRef}
            />
          </View>

          <View style={styles.greetingCard}>
            <View style={styles.greetingAvatar}>
              {user?.assistant_type ? (
                <AvatarDisplay assistantType={user.assistant_type} action="idle" size={84} />
              ) : null}
            </View>
            <Text style={styles.greetingText}>{greeting}</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>{KZ.level(level, levelInfo.title)}</Text>
            <XPBar totalXp={xp} size="md" showLabel />
          </View>

          <View style={styles.card}>
            {currentStreak > 0 ? (
              <>
                <Text style={styles.streakBig}>{KZ.streak(currentStreak)}</Text>
                <Text style={styles.streakSub}>{KZ.streakTomorrow(currentStreak)}</Text>
              </>
            ) : (
              <Text style={styles.streakBig}>{KZ.streakZero}</Text>
            )}
          </View>

          <View style={styles.sectionWrap}>
            <Text style={[styles.sectionTitle, styles.sectionTitleStandalone]}>
              {KZ.questsTitle}
            </Text>
            {questsLoading && quests.length === 0 ? (
              <View style={styles.sectionEmpty}>
                <Text style={styles.emptyText}>{KZ.loading}</Text>
              </View>
            ) : quests.length === 0 ? (
              <View style={styles.sectionEmpty}>
                <Text style={styles.emptyText}>{KZ.questsEmpty}</Text>
              </View>
            ) : (
              <FlatList
                horizontal
                data={quests}
                keyExtractor={(q) => q.id}
                renderItem={renderQuest}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.questListContent}
                ItemSeparatorComponent={() => <View style={{ width: spacing.sm }} />}
              />
            )}
          </View>

          <View style={styles.quickActions}>
            <QuickAction
              label={KZ.learn}
              icon="📘"
              onPress={() => { goTo('Learn', 'Оқу картасы жақында'); }}
            />
            <QuickAction
              label={KZ.battle}
              icon="⚔️"
              onPress={() => { goTo('BattleSetup', 'Шайқас жақында'); }}
            />
            <QuickAction
              label={KZ.rating}
              icon="🏆"
              onPress={() => { goTo('Rating', 'Рейтинг жақында'); }}
            />
          </View>

          <View style={styles.sectionWrap}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>{KZ.achievementsTitle}</Text>
              <Pressable onPress={() => { goTo('Achievements', 'Жетістіктер жақында'); }} hitSlop={6}>
                <Text style={styles.seeAll}>{KZ.seeAll}</Text>
              </Pressable>
            </View>
            {achievements.length === 0 ? (
              <View style={styles.sectionEmpty}>
                <Text style={styles.emptyText}>{KZ.achievementsEmpty}</Text>
              </View>
            ) : (
              <FlatList
                horizontal
                data={achievements}
                keyExtractor={(a) => a.achievement.id}
                renderItem={renderBadge}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.badgeListContent}
                ItemSeparatorComponent={() => <View style={{ width: spacing.md }} />}
              />
            )}
          </View>

          <View style={{ height: FAB_SIZE + insets.bottom + spacing.xl }} />
        </View>
      </ScrollView>

      {flyings.map((f) => (
        <FlyingChip key={f.id} reward={f} onDone={removeFlying} />
      ))}

      <VoiceButton
        color={fabColor}
        bottomOffset={Math.max(insets.bottom, spacing.md) + spacing.md}
      />
    </View>
  );
};

// ----------------------------------------------------------------------------
// Quick action button
// ----------------------------------------------------------------------------

interface QuickActionProps {
  label: string;
  icon: string;
  onPress: () => void;
}

const QuickAction: React.FC<QuickActionProps> = ({ label, icon, onPress }) => {
  const scale = useSharedValue(1);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Pressable
      onPressIn={() => {
        scale.value = withSpring(0.93, { damping: 14, stiffness: 220 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 12, stiffness: 200 });
      }}
      onPress={onPress}
      style={styles.quickPressable}
    >
      <Animated.View style={[styles.quickButton, style]}>
        <LinearGradient
          colors={[colors.primary, colors.secondary] as readonly [string, string]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
        <Text style={styles.quickIcon}>{icon}</Text>
        <Text style={styles.quickLabel}>{label}</Text>
      </Animated.View>
    </Pressable>
  );
};

// ----------------------------------------------------------------------------
// Styles
// ----------------------------------------------------------------------------

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#1A1A4E',
  },
  headerSection: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.md,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  avatarCircle: {
    borderRadius: AVATAR_SIZE / 2,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.35)',
  },
  avatarInitial: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
  },
  counters: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    gap: 6,
  },
  bellWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  bellIcon: {
    fontSize: 18,
  },
  bellDot: {
    position: 'absolute',
    top: -2,
    right: -2,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 4,
    backgroundColor: colors.danger,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#1A1A4E',
  },
  bellDotText: {
    color: colors.white,
    fontSize: 9,
    fontWeight: fontWeight.extrabold,
  },
  greetingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.10)',
    borderRadius: radius.lg,
    marginHorizontal: spacing.md,
    marginTop: spacing.sm,
    padding: spacing.md,
    gap: spacing.md,
  },
  greetingAvatar: {
    width: 84,
    alignItems: 'center',
    justifyContent: 'center',
  },
  greetingText: {
    flex: 1,
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
    lineHeight: 22,
  },
  card: {
    backgroundColor: 'rgba(255,255,255,0.10)',
    borderRadius: radius.lg,
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    padding: spacing.md,
    gap: spacing.sm,
  },
  cardTitle: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
  },
  streakBig: {
    color: colors.white,
    fontSize: fontSize.xl,
    fontWeight: fontWeight.extrabold,
  },
  streakSub: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
  },
  sectionWrap: {
    marginTop: spacing.lg,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },
  sectionTitle: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.bold,
  },
  sectionTitleStandalone: {
    paddingHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },
  seeAll: {
    color: colors.gold,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
  },
  sectionEmpty: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.lg,
    backgroundColor: 'rgba(255,255,255,0.06)',
    marginHorizontal: spacing.md,
    borderRadius: radius.md,
  },
  emptyText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.sm,
    textAlign: 'center',
  },
  questListContent: {
    paddingHorizontal: spacing.md,
  },
  quickActions: {
    flexDirection: 'row',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    marginTop: spacing.lg,
  },
  quickPressable: {
    flex: 1,
  },
  quickButton: {
    height: 72,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    gap: 4,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 4,
  },
  quickIcon: {
    fontSize: 22,
  },
  quickLabel: {
    color: colors.white,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
  },
  badgeListContent: {
    paddingHorizontal: spacing.md,
  },
  badge: {
    width: 72,
    alignItems: 'center',
    gap: 6,
  },
  badgeCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.gold,
    shadowOpacity: 0.5,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 5,
  },
  badgeIcon: {
    fontSize: 26,
  },
  badgeLabel: {
    color: colors.white,
    fontSize: 11,
    fontWeight: fontWeight.semibold,
    textAlign: 'center',
  },
  flyingChip: {
    position: 'absolute',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    zIndex: 50,
  },
  flyingIcon: {
    fontSize: 14,
  },
  flyingAmount: {
    color: colors.white,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
  },
});

export default HomeScreen;
