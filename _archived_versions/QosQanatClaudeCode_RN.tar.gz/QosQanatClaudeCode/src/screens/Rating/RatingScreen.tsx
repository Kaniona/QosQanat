import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type ListRenderItem,
} from 'react-native';
import Animated, {
  Easing,
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AvatarDisplay from '@/components/Avatar/AvatarDisplay';
import type { AuthStackParamList } from '@/navigation/types';
import {
  getLeaderboard,
  getSchoolUserCount,
  type LeaderboardEntry,
  type LeaderboardScope,
} from '@/services/api';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import type { AssistantType } from '@/types';

type Nav = NativeStackNavigationProp<AuthStackParamList>;

const KZ = {
  title: '🏆 Рейтинг',
  back: '← Артқа',
  tabGlobal: '🌍 Жалпы',
  tabCity: '🏙️ Қалам',
  tabSchool: '🏫 Мектебім',
  tabFriends: '👥 Достарым',
  schoolGate: 'Мектеп рейтингі кемінде 10 оқушы тіркелгенде ашылады.\nҚазір тіркелгендер саны: ',
  podium: 'Үздік үштік',
  rankings: 'Толық тізім',
  you: 'СІЗ',
  loading: 'Жүктелуде...',
  empty: 'Тізім бос. Көбірек ақыл ұпайын жинаңыз!',
  emptyFriends: 'Достарыңыз әлі жоқ. ID арқылы іздеп қосыңыз!',
  emptyCity: 'Қалаңызда басқа ойыншылар жоқ.',
  emptySchool: 'Мектебіңізде басқа ойыншылар жоқ.',
  level: (n: number) => `лвл ${n}`,
  akyl: (n: number) => `${formatNum(n)} 🔮`,
};

const formatNum = (n: number): string => {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 10_000) return `${Math.floor(n / 1_000)}K`;
  return n.toLocaleString('kk-KZ');
};

const SCREEN_W = Dimensions.get('window').width;
const assistantOrDefault = (t: AssistantType | null): AssistantType => t ?? 'bektur';

// ----------------------------------------------------------------------------
// Tab pill
// ----------------------------------------------------------------------------

interface TabProps {
  label: string;
  active: boolean;
  onPress: () => void;
}

const Tab: React.FC<TabProps> = ({ label, active, onPress }) => {
  const scale = useSharedValue(1);
  useEffect(() => {
    scale.value = withSpring(active ? 1 : 0.97, { damping: 14, stiffness: 220 });
  }, [active, scale]);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <Pressable onPress={onPress} style={styles.tabWrap}>
      <Animated.View style={[styles.tab, active && styles.tabActive, style]}>
        <Text style={[styles.tabText, active && styles.tabTextActive]} numberOfLines={1}>
          {label}
        </Text>
      </Animated.View>
    </Pressable>
  );
};

// ----------------------------------------------------------------------------
// Podium spot (1st/2nd/3rd)
// ----------------------------------------------------------------------------

interface PodiumProps {
  entry?: LeaderboardEntry;
  place: 1 | 2 | 3;
  isMe: boolean;
}

const PLACE_DATA: Record<
  1 | 2 | 3,
  { color: string; emoji: string; height: number; size: number; ring: string }
> = {
  1: { color: '#FFD700', emoji: '👑', height: 140, size: 100, ring: '#FFD700' },
  2: { color: '#C0C0C0', emoji: '🥈', height: 110, size: 86, ring: '#C0C0C0' },
  3: { color: '#CD7F32', emoji: '🥉', height: 90, size: 78, ring: '#CD7F32' },
};

const PodiumSpot: React.FC<PodiumProps> = ({ entry, place, isMe }) => {
  const meta = PLACE_DATA[place];
  const pulse = useSharedValue(0);

  useEffect(() => {
    pulse.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1100, easing: Easing.inOut(Easing.quad) }),
        withTiming(0, { duration: 1100, easing: Easing.inOut(Easing.quad) }),
      ),
      -1,
    );
    return () => { cancelAnimation(pulse); };
  }, [pulse]);

  const ringStyle = useAnimatedStyle(() => ({
    opacity: 0.35 + pulse.value * 0.45,
    transform: [{ scale: 1 + pulse.value * 0.06 }],
  }));

  const crownStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: -2 - pulse.value * 4 }, { rotate: `${(pulse.value - 0.5) * 8}deg` }],
  }));

  return (
    <View style={[styles.podiumSlot, { height: meta.height + 60 }]}>
      <View style={[styles.podiumAvatarWrap, { width: meta.size + 14, height: meta.size + 14 }]}>
        <Animated.View
          style={[
            styles.podiumRing,
            {
              borderColor: meta.ring,
              width: meta.size + 14,
              height: meta.size + 14,
              borderRadius: (meta.size + 14) / 2,
            },
            ringStyle,
          ]}
        />
        {entry ? (
          <AvatarDisplay
            assistantType={assistantOrDefault(entry.assistant_type)}
            action="idle"
            size={meta.size}
          />
        ) : (
          <View
            style={{
              width: meta.size,
              height: meta.size,
              borderRadius: meta.size / 2,
              backgroundColor: 'rgba(255,255,255,0.06)',
            }}
          />
        )}
        <Animated.Text style={[styles.podiumCrown, crownStyle]}>{meta.emoji}</Animated.Text>
      </View>
      <Text style={styles.podiumName} numberOfLines={1}>
        {entry?.full_name ?? '—'}
      </Text>
      <Text style={[styles.podiumAkyl, { color: meta.color }]}>
        {entry ? KZ.akyl(entry.akyl_points) : '—'}
      </Text>
      <View style={[styles.podiumBase, { backgroundColor: meta.color, height: meta.height }]}>
        <LinearGradient
          colors={[`${meta.color}cc`, `${meta.color}66`] as readonly [string, string]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
        />
        <Text style={styles.podiumPlace}>{place}</Text>
        {isMe ? <Text style={styles.podiumYou}>{KZ.you}</Text> : null}
      </View>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Ranking row (4th onwards + sticky)
// ----------------------------------------------------------------------------

interface RowProps {
  entry: LeaderboardEntry;
  isMe: boolean;
  rankChange?: number;
}

const RankingRow: React.FC<RowProps> = React.memo(({ entry, isMe, rankChange }) => {
  let changeBadge: React.ReactNode = null;
  if (typeof rankChange === 'number' && rankChange !== 0) {
    const up = rankChange > 0;
    changeBadge = (
      <View
        style={[
          styles.changeBadge,
          { backgroundColor: up ? 'rgba(0,196,140,0.2)' : 'rgba(255,71,87,0.2)' },
        ]}
      >
        <Text style={[styles.changeText, { color: up ? colors.success : colors.danger }]}>
          {up ? '↑' : '↓'}
          {Math.abs(rankChange)}
        </Text>
      </View>
    );
  }
  return (
    <View style={[styles.row, isMe && styles.rowMe]}>
      <View style={styles.rankNumWrap}>
        <Text style={[styles.rankNum, isMe && styles.rankNumMe]}>{entry.rank}</Text>
      </View>
      <View style={styles.rowAvatarWrap}>
        <AvatarDisplay
          assistantType={assistantOrDefault(entry.assistant_type)}
          action="idle"
          size={42}
        />
      </View>
      <View style={styles.rowMeta}>
        <View style={styles.rowNameRow}>
          {isMe ? <Text style={styles.youTag}>{KZ.you}: </Text> : null}
          <Text style={[styles.rowName, isMe && styles.rowNameMe]} numberOfLines={1}>
            {entry.full_name}
          </Text>
        </View>
        <Text style={styles.rowSub} numberOfLines={1}>
          {entry.qosqanat_id} · {entry.school}
        </Text>
      </View>
      <View style={styles.rowRight}>
        <View style={styles.levelBadge}>
          <Text style={styles.levelBadgeText}>⭐ {KZ.level(entry.level)}</Text>
        </View>
        <Text style={styles.rowAkyl}>{KZ.akyl(entry.akyl_points)}</Text>
        {changeBadge}
      </View>
    </View>
  );
});

// ----------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------

const RatingScreen: React.FC = () => {
  const nav = useNavigation<Nav>();
  const insets = useSafeAreaInsets();
  const me = useUserStore((s) => s.user);

  const [scope, setScope] = useState<LeaderboardScope>('global');
  const [entries, setEntries] = useState<readonly LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [schoolCount, setSchoolCount] = useState<number | null>(null);
  // Rank deltas vs. the previous time we viewed this scope. Stored per-scope.
  const [rankDeltas, setRankDeltas] = useState<ReadonlyMap<string, number>>(new Map());

  const prevRanksRef = React.useRef<Map<LeaderboardScope, Map<string, number>>>(new Map());

  const load = useCallback(async (s: LeaderboardScope) => {
    setLoading(true);
    try {
      if (s === 'school') {
        const cnt = await getSchoolUserCount();
        setSchoolCount(cnt);
        if (cnt < 10) {
          setEntries([]);
          setLoading(false);
          return;
        }
      }
      const list = await getLeaderboard(s, 100);
      setEntries(list);
      // Compute deltas vs. previous snapshot for this scope.
      const prev = prevRanksRef.current.get(s);
      const next = new Map<string, number>();
      for (const e of list) next.set(e.id, e.rank);
      if (prev) {
        const deltas = new Map<string, number>();
        for (const e of list) {
          const old = prev.get(e.id);
          if (typeof old === 'number') deltas.set(e.id, old - e.rank);
        }
        setRankDeltas(deltas);
      } else {
        setRankDeltas(new Map());
      }
      prevRanksRef.current.set(s, next);
    } catch {
      setEntries([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load(scope);
  }, [scope, load]);

  // Top 3 and rest split.
  const top3 = useMemo(() => entries.slice(0, 3), [entries]);
  const rest = useMemo(() => entries.slice(3), [entries]);
  const myEntry = useMemo<LeaderboardEntry | undefined>(
    () => entries.find((e) => e.id === me?.id),
    [entries, me?.id],
  );
  const myEntryNotInList = !myEntry && !!me;
  const myInTop3 = !!myEntry && myEntry.rank <= 3;
  const myInRest = !!myEntry && myEntry.rank > 3;

  const renderRow: ListRenderItem<LeaderboardEntry> = useCallback(
    ({ item }) => (
      <RankingRow entry={item} isMe={item.id === me?.id} rankChange={rankDeltas.get(item.id)} />
    ),
    [me?.id, rankDeltas],
  );

  const schoolLocked = scope === 'school' && schoolCount !== null && schoolCount < 10;

  const emptyHint = useMemo(() => {
    if (scope === 'friends') return KZ.emptyFriends;
    if (scope === 'city') return KZ.emptyCity;
    if (scope === 'school') return KZ.emptySchool;
    return KZ.empty;
  }, [scope]);

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#1A1A4E', '#2A2870', colors.primary] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
      />

      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => { nav.goBack(); }} hitSlop={10} style={styles.backBtn}>
          <Text style={styles.backText}>{KZ.back}</Text>
        </Pressable>
        <Text style={styles.title}>{KZ.title}</Text>
        <View style={styles.backBtn} />
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.tabsRow}
      >
        {(
          [
            ['global', KZ.tabGlobal],
            ['city', KZ.tabCity],
            ['school', KZ.tabSchool],
            ['friends', KZ.tabFriends],
          ] as readonly (readonly [LeaderboardScope, string])[]
        ).map(([key, label]) => (
          <Tab key={key} label={label} active={scope === key} onPress={() => { setScope(key); }} />
        ))}
      </ScrollView>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.white} size="large" />
          <Text style={styles.loadingText}>{KZ.loading}</Text>
        </View>
      ) : schoolLocked ? (
        <View style={styles.center}>
          <Text style={styles.gateEmoji}>🔒</Text>
          <Text style={styles.gateText}>
            {KZ.schoolGate}
            <Text style={{ color: colors.gold, fontWeight: fontWeight.extrabold }}>
              {schoolCount}
            </Text>
            /10
          </Text>
        </View>
      ) : entries.length === 0 ? (
        <View style={styles.center}>
          <Text style={styles.gateEmoji}>📊</Text>
          <Text style={styles.gateText}>{emptyHint}</Text>
        </View>
      ) : (
        <View style={{ flex: 1 }}>
          {/* Podium */}
          <View style={styles.podiumRow}>
            <PodiumSpot entry={top3[1]} place={2} isMe={top3[1]?.id === me?.id} />
            <PodiumSpot entry={top3[0]} place={1} isMe={top3[0]?.id === me?.id} />
            <PodiumSpot entry={top3[2]} place={3} isMe={top3[2]?.id === me?.id} />
          </View>

          {/* Rest */}
          <FlatList
            data={rest}
            renderItem={renderRow}
            keyExtractor={(it) => it.id}
            contentContainerStyle={[
              styles.list,
              { paddingBottom: insets.bottom + (myEntryNotInList || myInRest ? 90 : spacing.xl) },
            ]}
            ListHeaderComponent={<Text style={styles.listHeader}>{KZ.rankings}</Text>}
            ListEmptyComponent={<Text style={styles.subEmpty}>—</Text>}
          />

          {/* Sticky "you" row when not in top 3 (in rest OR not in 100). */}
          {(myEntryNotInList || (myInRest && myEntry)) && me ? (
            <View style={[styles.sticky, { bottom: insets.bottom + spacing.sm }]}>
              <RankingRow
                entry={
                  myEntry ?? {
                    id: me.id,
                    qosqanat_id: me.qosqanat_id,
                    full_name: me.full_name,
                    city: me.city,
                    school: me.school,
                    grade: me.grade,
                    assistant_type: me.assistant_type,
                    level: me.level,
                    akyl_points: me.akyl_points,
                    rank: entries.length + 1,
                  }
                }
                isMe
                rankChange={myEntry ? rankDeltas.get(myEntry.id) : undefined}
              />
            </View>
          ) : null}

          {/* If in top 3, show a subtle "you are on the podium" pill. */}
          {myInTop3 ? (
            <View style={[styles.sticky, { bottom: insets.bottom + spacing.sm }]}>
              <View style={styles.podiumYouPill}>
                <Text style={styles.podiumYouPillText}>🏆 Сіз подиумдасыз!</Text>
              </View>
            </View>
          ) : null}
        </View>
      )}
    </View>
  );
};

// ----------------------------------------------------------------------------
// Styles
// ----------------------------------------------------------------------------

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#1A1A4E' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.sm,
  },
  backBtn: { width: 70 },
  backText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
  },
  title: {
    color: colors.white,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
  },
  tabsRow: {
    paddingHorizontal: spacing.md,
    gap: spacing.sm,
    paddingBottom: spacing.sm,
  },
  tabWrap: {},
  tab: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.full,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  tabActive: { backgroundColor: colors.gold, borderColor: colors.gold },
  tabText: { color: 'rgba(255,255,255,0.75)', fontSize: fontSize.sm, fontWeight: fontWeight.bold },
  tabTextActive: { color: colors.text, fontWeight: fontWeight.extrabold },

  // ---- Podium ----
  podiumRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'center',
    paddingHorizontal: spacing.sm,
    marginVertical: spacing.md,
    gap: spacing.xs,
  },
  podiumSlot: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
    maxWidth: SCREEN_W / 3,
  },
  podiumAvatarWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  podiumRing: {
    position: 'absolute',
    borderWidth: 3,
  },
  podiumCrown: {
    position: 'absolute',
    top: -10,
    fontSize: 26,
  },
  podiumName: {
    color: colors.white,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
    textAlign: 'center',
    maxWidth: '100%',
  },
  podiumAkyl: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
  },
  podiumBase: {
    width: '90%',
    borderTopLeftRadius: radius.md,
    borderTopRightRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    marginTop: 4,
  },
  podiumPlace: {
    color: colors.text,
    fontSize: fontSize.huge,
    fontWeight: fontWeight.extrabold,
  },
  podiumYou: {
    color: colors.text,
    fontSize: 10,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 1,
  },

  // ---- Rankings list ----
  list: { paddingHorizontal: spacing.md, gap: spacing.sm },
  listHeader: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: spacing.sm,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: radius.md,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.sm,
    gap: spacing.sm,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  rowMe: {
    backgroundColor: 'rgba(74,108,247,0.25)',
    borderColor: colors.primary,
    borderWidth: 2,
  },
  rankNumWrap: {
    width: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankNum: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
  },
  rankNumMe: { color: colors.white },
  rowAvatarWrap: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  rowMeta: { flex: 1, gap: 2 },
  rowNameRow: { flexDirection: 'row', alignItems: 'center' },
  youTag: {
    color: colors.gold,
    fontSize: fontSize.xs,
    fontWeight: fontWeight.extrabold,
  },
  rowName: {
    color: 'rgba(255,255,255,0.95)',
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
    flex: 1,
  },
  rowNameMe: { color: colors.white },
  rowSub: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 11,
  },
  rowRight: {
    alignItems: 'flex-end',
    gap: 2,
  },
  levelBadge: {
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: radius.full,
    backgroundColor: 'rgba(255,215,0,0.18)',
  },
  levelBadgeText: { color: colors.gold, fontSize: 10, fontWeight: fontWeight.extrabold },
  rowAkyl: { color: colors.white, fontSize: fontSize.sm, fontWeight: fontWeight.extrabold },
  changeBadge: {
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: radius.full,
  },
  changeText: { fontSize: 10, fontWeight: fontWeight.extrabold },

  // ---- Sticky ----
  sticky: {
    position: 'absolute',
    left: spacing.md,
    right: spacing.md,
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: -2 },
    elevation: 14,
  },
  podiumYouPill: {
    backgroundColor: 'rgba(255,215,0,0.95)',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: radius.full,
    alignItems: 'center',
  },
  podiumYouPillText: {
    color: colors.text,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
  },

  // ---- Misc ----
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
  },
  loadingText: { color: 'rgba(255,255,255,0.7)', marginTop: spacing.md },
  gateEmoji: { fontSize: 56, marginBottom: spacing.sm },
  gateText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: fontSize.md,
    textAlign: 'center',
    lineHeight: 22,
  },
  subEmpty: {
    color: 'rgba(255,255,255,0.4)',
    textAlign: 'center',
    fontSize: fontSize.sm,
    paddingVertical: spacing.lg,
  },
});

export default RatingScreen;
