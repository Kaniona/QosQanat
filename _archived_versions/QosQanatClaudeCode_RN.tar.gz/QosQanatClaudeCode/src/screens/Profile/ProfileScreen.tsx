import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Dimensions,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Animated, {
  Easing,
  cancelAnimation,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AvatarDisplay from '@/components/Avatar/AvatarDisplay';
import { ACHIEVEMENTS, type Achievement, type AchievementCategory } from '@/data/achievements';
import { getLevelInfo, getLevelProgress } from '@/data/levels';
import type { AuthStackParamList } from '@/navigation/types';
import {
  getActivityMap,
  getFriends,
  getRecentBattles,
  getUnlockedAchievementIds,
  type ActivityDay,
  type RecentBattleEntry,
} from '@/services/api';
import { signOut } from '@/services/auth';
import { useGameStore } from '@/store/gameStore';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import type { AssistantType } from '@/types';

type Nav = NativeStackNavigationProp<AuthStackParamList>;

const SCREEN_W = Dimensions.get('window').width;

const KZ = {
  back: '← Артқа',
  edit: 'Аватарды өңдеу ✏️',
  copy: 'Көшірілді!',
  level: (n: number, title: string) => `Деңгей ${n} · ${title}`,
  xpProgress: (left: number) => `Келесі деңгейге дейін ${left} XP`,
  maxLevel: 'Максималды деңгей!',
  statsTitle: 'Көрсеткіштер',
  achievementsTitle: '🏅 Жетістіктер',
  achievementsCount: (a: number, b: number) => `${a}/${b} ашылды`,
  achievementsAll: 'Барлығы',
  activityTitle: '📊 Соңғы 119 күн белсенділігі',
  battlesTitle: '⚔️ Соңғы шайқастар',
  noBattles: 'Әзірге шайқастар жоқ.',
  win: 'Жеңіс',
  loss: 'Жеңіліс',
  tie: 'Тең',
  settings: '⚙️ Баптаулар',
  logout: '🚪 Шығу',
  logoutConfirm: 'Шығасыз ба?',
  logoutBody: 'Жүйеден шыққанда қайта кіру керек болады.',
  yes: 'Иә, шығамын',
  no: 'Болдырмау',
  loading: 'Жүктелуде...',
  akyl: 'Ақыл',
  coins: 'Тиын',
  friends: 'Достар',
  streak: 'Серия',
  tasksDone: 'Тапсырмалар',
  battlesLabel: 'Шайқас',
  unlocked: 'Ашылды',
  locked: 'Жабық',
};

const assistantOrDefault = (t: AssistantType | null | undefined): AssistantType => t ?? 'bektur';

// ----------------------------------------------------------------------------
// Hero avatar — tap to play spin + sparkle.
// ----------------------------------------------------------------------------

interface HeroAvatarProps {
  assistant: AssistantType;
}

const HeroAvatar: React.FC<HeroAvatarProps> = ({ assistant }) => {
  const rotate = useSharedValue(0);
  const scale = useSharedValue(1);
  const [sparkles, setSparkles] = useState<
    readonly { id: number; x: number; y: number; delay: number }[]
  >([]);

  const onPress = useCallback(() => {
    rotate.value = withSequence(
      withTiming(rotate.value + 360, { duration: 700, easing: Easing.out(Easing.cubic) }),
    );
    scale.value = withSequence(
      withSpring(1.08, { damping: 9, stiffness: 220 }),
      withSpring(1, { damping: 10, stiffness: 200 }),
    );
    const burst = Array.from({ length: 8 }, (_, i) => ({
      id: Date.now() + i,
      x: Math.cos((i / 8) * Math.PI * 2) * 80,
      y: Math.sin((i / 8) * Math.PI * 2) * 80,
      delay: i * 30,
    }));
    setSparkles((s) => [...s, ...burst]);
    setTimeout(() => {
      setSparkles((s) => s.filter((sp) => !burst.find((b) => b.id === sp.id)));
    }, 900);
  }, [rotate, scale]);

  const style = useAnimatedStyle(() => ({
    transform: [{ rotate: `${rotate.value}deg` }, { scale: scale.value }],
  }));

  return (
    <View style={styles.heroAvatarWrap}>
      <Pressable onPress={onPress}>
        <Animated.View style={style}>
          <AvatarDisplay assistantType={assistant} action="idle" size={200} />
        </Animated.View>
      </Pressable>
      {sparkles.map((sp) => (
        <Sparkle key={sp.id} x={sp.x} y={sp.y} delay={sp.delay} />
      ))}
    </View>
  );
};

const Sparkle: React.FC<{ x: number; y: number; delay: number }> = ({ x, y, delay }) => {
  const opacity = useSharedValue(0);
  const tx = useSharedValue(0);
  const ty = useSharedValue(0);
  const scale = useSharedValue(0.4);

  useEffect(() => {
    opacity.value = withDelay(
      delay,
      withSequence(withTiming(1, { duration: 150 }), withTiming(0, { duration: 500 })),
    );
    tx.value = withDelay(delay, withTiming(x, { duration: 600, easing: Easing.out(Easing.cubic) }));
    ty.value = withDelay(delay, withTiming(y, { duration: 600, easing: Easing.out(Easing.cubic) }));
    scale.value = withDelay(delay, withSpring(1.1, { damping: 8, stiffness: 220 }));
    return () => {
      cancelAnimation(opacity);
      cancelAnimation(tx);
      cancelAnimation(ty);
      cancelAnimation(scale);
    };
  }, [opacity, tx, ty, scale, x, y, delay]);

  const style = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateX: tx.value }, { translateY: ty.value }, { scale: scale.value }],
  }));

  return (
    <Animated.Text pointerEvents="none" style={[styles.sparkle, style]}>
      ✨
    </Animated.Text>
  );
};

// ----------------------------------------------------------------------------
// XP bar
// ----------------------------------------------------------------------------

const XpBar: React.FC<{ progress: number; xpToNext: number; isMax: boolean }> = ({
  progress,
  xpToNext,
  isMax,
}) => {
  const fill = useSharedValue(0);
  useEffect(() => {
    fill.value = withTiming(progress, { duration: 700, easing: Easing.out(Easing.cubic) });
  }, [progress, fill]);
  const fillStyle = useAnimatedStyle(() => ({
    width: `${Math.max(0, Math.min(1, fill.value)) * 100}%`,
  }));
  return (
    <View style={styles.xpWrap}>
      <View style={styles.xpTrack}>
        <Animated.View style={[styles.xpFill, fillStyle]}>
          <LinearGradient
            colors={[colors.gold, '#FFB84A'] as readonly [string, string]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={StyleSheet.absoluteFill}
          />
        </Animated.View>
      </View>
      <Text style={styles.xpText}>{isMax ? KZ.maxLevel : KZ.xpProgress(xpToNext)}</Text>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Toast for "Көшірілді!"
// ----------------------------------------------------------------------------

const CopyToast: React.FC<{ onDone: () => void }> = ({ onDone }) => {
  const opacity = useSharedValue(0);
  const ty = useSharedValue(8);
  useEffect(() => {
    opacity.value = withTiming(1, { duration: 180 });
    ty.value = withSpring(0, { damping: 12, stiffness: 220 });
    opacity.value = withDelay(
      1100,
      withTiming(0, { duration: 320 }, (finished) => {
        if (finished) runOnJS(onDone)();
      }),
    );
    return () => {
      cancelAnimation(opacity);
      cancelAnimation(ty);
    };
  }, [opacity, ty, onDone]);
  const s = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateY: ty.value }],
  }));
  return (
    <Animated.View style={[styles.copyToast, s]} pointerEvents="none">
      <Text style={styles.copyToastText}>✓ {KZ.copy}</Text>
    </Animated.View>
  );
};

// ----------------------------------------------------------------------------
// Stat card
// ----------------------------------------------------------------------------

interface StatCardProps {
  icon: string;
  label: string;
  value: string;
  accent: string;
}

const StatCard: React.FC<StatCardProps> = ({ icon, label, value, accent }) => (
  <View style={[styles.statCard, { borderColor: `${accent}55` }]}>
    <Text style={styles.statIcon}>{icon}</Text>
    <Text style={[styles.statValue, { color: accent }]}>{value}</Text>
    <Text style={styles.statLabel}>{label}</Text>
  </View>
);

// ----------------------------------------------------------------------------
// Achievement tile
// ----------------------------------------------------------------------------

interface AchievementTileProps {
  achievement: Achievement;
  unlocked: boolean;
  cellSize: number;
}

const AchievementTile: React.FC<AchievementTileProps> = React.memo(
  ({ achievement, unlocked, cellSize }) => (
    <View style={[styles.achTile, { width: cellSize, height: cellSize + 26 }]}>
      <View
        style={[
          styles.achIconWrap,
          {
            width: cellSize - 12,
            height: cellSize - 12,
            backgroundColor: unlocked ? 'rgba(255,215,0,0.18)' : 'rgba(255,255,255,0.04)',
            borderColor: unlocked ? colors.gold : 'rgba(255,255,255,0.1)',
          },
        ]}
      >
        <Text style={[styles.achIcon, !unlocked && styles.achIconLocked]}>
          {unlocked ? achievement.icon : '???'}
        </Text>
      </View>
      <Text style={[styles.achLabel, !unlocked && styles.achLabelLocked]} numberOfLines={1}>
        {unlocked ? achievement.titleKz : '—'}
      </Text>
    </View>
  ),
);

// ----------------------------------------------------------------------------
// Activity heatmap (GitHub-style)
// ----------------------------------------------------------------------------

const ROWS = 7; // days of week
const CELL = 14; // cell side incl. gap
const CELL_GAP = 3;

const intensityColor = (count: number): string => {
  if (count <= 0) return 'rgba(255,255,255,0.07)';
  if (count === 1) return '#1B6444';
  if (count <= 3) return '#249363';
  if (count <= 6) return '#2EC180';
  return colors.success;
};

const ActivityMap: React.FC<{ days: readonly ActivityDay[] }> = ({ days }) => {
  // Group into columns of 7 (top = oldest weekday). To keep things simple we
  // don't align to weekday — we just chunk in order.
  const columns = useMemo(() => {
    const out: ActivityDay[][] = [];
    for (let i = 0; i < days.length; i += ROWS) {
      out.push(days.slice(i, i + ROWS));
    }
    return out;
  }, [days]);

  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
      <View style={styles.heatmap}>
        {columns.map((col, ci) => (
          <View key={ci} style={styles.heatmapCol}>
            {col.map((d) => (
              <View
                key={d.date}
                style={{
                  width: CELL - CELL_GAP,
                  height: CELL - CELL_GAP,
                  marginBottom: CELL_GAP,
                  backgroundColor: intensityColor(d.count),
                  borderRadius: 3,
                }}
              />
            ))}
          </View>
        ))}
      </View>
    </ScrollView>
  );
};

// ----------------------------------------------------------------------------
// Recent battle row
// ----------------------------------------------------------------------------

const BattleRow: React.FC<{ entry: RecentBattleEntry }> = React.memo(({ entry }) => {
  const accent =
    entry.outcome === 'win'
      ? colors.success
      : entry.outcome === 'tie'
        ? colors.gold
        : colors.danger;
  const label = entry.outcome === 'win' ? KZ.win : entry.outcome === 'tie' ? KZ.tie : KZ.loss;
  return (
    <View style={styles.battleRow}>
      <View style={[styles.battleOutcome, { backgroundColor: accent }]}>
        <Text style={styles.battleOutcomeText}>{label}</Text>
      </View>
      <View style={styles.battleAvatar}>
        <AvatarDisplay
          assistantType={assistantOrDefault(entry.opponent.assistant_type)}
          action="idle"
          size={40}
        />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.battleName} numberOfLines={1}>
          {entry.opponent.full_name}
        </Text>
        <Text style={styles.battleSub}>
          {entry.myScore} : {entry.opponentScore} ({entry.totalQuestions})
        </Text>
      </View>
    </View>
  );
});

// ----------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------

const ProfileScreen: React.FC = () => {
  const nav = useNavigation<Nav>();
  const insets = useSafeAreaInsets();
  const me = useUserStore((s) => s.user);
  const setUser = useUserStore((s) => s.setUser);
  const resetGame = useGameStore((s) => s.reset);

  const xp = useGameStore((s) => s.xp);
  const level = useGameStore((s) => s.level);
  const coins = useGameStore((s) => s.coins);
  const akyl = useGameStore((s) => s.akylPoints);
  const longestStreak = useGameStore((s) => s.longestStreak);

  const [friendCount, setFriendCount] = useState<number | null>(null);
  const [unlocked, setUnlocked] = useState<ReadonlySet<string>>(() => new Set());
  const [activity, setActivity] = useState<readonly ActivityDay[]>([]);
  const [recentBattles, setRecentBattles] = useState<readonly RecentBattleEntry[]>([]);
  const [achCategory, setAchCategory] = useState<AchievementCategory | 'all'>('all');
  const [loading, setLoading] = useState(true);
  const [copyToastId, setCopyToastId] = useState<number | null>(null);
  const loggingOutRef = useRef(false);

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        setLoading(true);
        const [friends, ids, act, battles] = await Promise.all([
          getFriends(),
          getUnlockedAchievementIds(),
          getActivityMap(119),
          getRecentBattles(5),
        ]);
        if (cancelled) return;
        setFriendCount(friends.length);
        setUnlocked(ids);
        setActivity(act);
        setRecentBattles(battles);
      } catch {
        // soft-fail
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    void run();
    return () => {
      cancelled = true;
    };
  }, []);

  const handleCopyId = useCallback(() => {
    // expo-clipboard is not installed; show the toast so the player gets
    // feedback. A future patch can wire `Clipboard.setStringAsync(me.qosqanat_id)`.
    setCopyToastId(Date.now());
  }, []);

  const handleLogout = useCallback(() => {
    Alert.alert(KZ.logoutConfirm, KZ.logoutBody, [
      { text: KZ.no, style: 'cancel' },
      {
        text: KZ.yes,
        style: 'destructive',
        onPress: async () => {
          if (loggingOutRef.current) return;
          loggingOutRef.current = true;
          try {
            await signOut();
          } finally {
            // RootNavigator watches isAuthenticated and will swap back to
            // AuthNavigator automatically — no nav.reset needed.
            resetGame();
            setUser(null);
          }
        },
      },
    ]);
  }, [nav, resetGame, setUser]);

  if (!me) {
    return (
      <View style={[styles.root, styles.center]}>
        <ActivityIndicator color={colors.white} />
      </View>
    );
  }

  const progress = getLevelProgress(xp);
  const levelInfo = getLevelInfo(level);
  const battleWins = me.total_battles_won ?? 0;
  const battlesPlayed = me.total_battles_played ?? 0;
  const battlesLost = Math.max(0, battlesPlayed - battleWins);
  const assistant = assistantOrDefault(me.assistant_type);

  const heroGradient =
    assistant === 'nazym'
      ? (['#7B1545', '#B83370', colors.nazymColor] as readonly [string, string, string])
      : (['#142A6E', '#2C3CA8', colors.bekturColor] as readonly [string, string, string]);

  const filteredAchievements =
    achCategory === 'all' ? ACHIEVEMENTS : ACHIEVEMENTS.filter((a) => a.category === achCategory);
  const cellSize = (SCREEN_W - spacing.md * 2 - spacing.sm * 2) / 3;

  return (
    <View style={styles.root}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + spacing.xl }}
        showsVerticalScrollIndicator={false}
      >
        {/* HERO */}
        <View style={styles.hero}>
          <LinearGradient
            colors={heroGradient}
            style={StyleSheet.absoluteFill}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          />
          <View style={[styles.heroTop, { paddingTop: insets.top + spacing.sm }]}>
            <Pressable onPress={() => { nav.goBack(); }} hitSlop={10} style={{ width: 70 }}>
              <Text style={styles.backText}>{KZ.back}</Text>
            </Pressable>
            <View style={{ flexDirection: 'row', gap: spacing.sm }}>
              <Pressable onPress={() => { nav.navigate('Settings'); }} hitSlop={10}>
                <Text style={styles.iconBtn}>⚙️</Text>
              </Pressable>
            </View>
          </View>

          <HeroAvatar assistant={assistant} />

          <Pressable
            onPress={() => { nav.navigate('Main', { screen: 'Shop' }); }}
            style={styles.editBtn}
          >
            <Text style={styles.editBtnText}>{KZ.edit}</Text>
          </Pressable>

          <Text style={styles.heroName}>{me.full_name}</Text>

          <Pressable onPress={handleCopyId} hitSlop={10} style={styles.heroIdRow}>
            <Text style={styles.heroId}>{me.qosqanat_id}</Text>
            <Text style={styles.heroCopyIcon}>📋</Text>
          </Pressable>

          <View style={styles.heroLevelBadge}>
            <Text style={styles.heroLevelText}>{KZ.level(level, levelInfo.title)}</Text>
          </View>

          <View style={{ width: '100%', paddingHorizontal: spacing.md, marginTop: spacing.sm }}>
            <XpBar
              progress={progress.progress}
              xpToNext={progress.xpToNextLevel}
              isMax={progress.xpForNextLevel === 0}
            />
          </View>
        </View>

        {/* STATS */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{KZ.statsTitle}</Text>
          <View style={styles.statsGrid}>
            <StatCard icon="⭐" label={KZ.akyl} value={formatBig(akyl)} accent={colors.secondary} />
            <StatCard icon="🪙" label={KZ.coins} value={formatBig(coins)} accent={colors.gold} />
            <StatCard
              icon="👥"
              label={KZ.friends}
              value={`${friendCount ?? 0}`}
              accent={colors.primary}
            />
            <StatCard
              icon="🔥"
              label={KZ.streak}
              value={`${longestStreak}`}
              accent={colors.danger}
            />
            <StatCard
              icon="✓"
              label={KZ.tasksDone}
              value={`${me.total_tasks_completed ?? 0}`}
              accent={colors.success}
            />
            <StatCard
              icon="⚔️"
              label={KZ.battlesLabel}
              value={`${battleWins}/${battlesLost}`}
              accent={colors.warning}
            />
          </View>
        </View>

        {/* ACHIEVEMENTS */}
        <View style={styles.section}>
          <View style={styles.sectionHeaderRow}>
            <Text style={styles.sectionTitle}>{KZ.achievementsTitle}</Text>
            <Text style={styles.sectionSub}>
              {KZ.achievementsCount(unlocked.size, ACHIEVEMENTS.length)}
            </Text>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.catRow}
          >
            {(
              ['all', 'learning', 'battle', 'collection', 'friends', 'streak', 'special'] as const
            ).map((c) => {
              const label =
                c === 'all'
                  ? KZ.achievementsAll
                  : c === 'learning'
                    ? '📚'
                    : c === 'battle'
                      ? '⚔️'
                      : c === 'collection'
                        ? '🎁'
                        : c === 'friends'
                          ? '👥'
                          : c === 'streak'
                            ? '🔥'
                            : '⭐';
              const active = achCategory === c;
              return (
                <Pressable
                  key={c}
                  onPress={() => { setAchCategory(c); }}
                  style={[styles.catChip, active && styles.catChipActive]}
                >
                  <Text style={[styles.catChipText, active && styles.catChipTextActive]}>
                    {label}
                  </Text>
                </Pressable>
              );
            })}
          </ScrollView>
          <View style={styles.achGrid}>
            {filteredAchievements.map((a) => (
              <AchievementTile
                key={a.id}
                achievement={a}
                unlocked={unlocked.has(a.id)}
                cellSize={cellSize}
              />
            ))}
          </View>
        </View>

        {/* ACTIVITY */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{KZ.activityTitle}</Text>
          <ActivityMap days={activity} />
          <View style={styles.heatmapLegend}>
            <Text style={styles.heatmapLegendText}>Аз</Text>
            {[0, 1, 3, 6, 9].map((c) => (
              <View
                key={c}
                style={{
                  width: 12,
                  height: 12,
                  borderRadius: 3,
                  backgroundColor: intensityColor(c),
                  marginHorizontal: 2,
                }}
              />
            ))}
            <Text style={styles.heatmapLegendText}>Көп</Text>
          </View>
        </View>

        {/* RECENT BATTLES */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{KZ.battlesTitle}</Text>
          {loading ? (
            <ActivityIndicator color={colors.white} />
          ) : recentBattles.length === 0 ? (
            <Text style={styles.subEmpty}>{KZ.noBattles}</Text>
          ) : (
            <View style={{ gap: spacing.sm }}>
              {recentBattles.map((b) => (
                <BattleRow key={b.battleId} entry={b} />
              ))}
            </View>
          )}
        </View>

        {/* FOOTER ACTIONS */}
        <View style={[styles.section, { gap: spacing.sm }]}>
          <Pressable style={styles.bigBtn} onPress={() => { nav.navigate('Settings'); }}>
            <Text style={styles.bigBtnText}>{KZ.settings}</Text>
          </Pressable>
          <Pressable style={[styles.bigBtn, styles.logoutBtn]} onPress={handleLogout}>
            <Text style={[styles.bigBtnText, { color: colors.danger }]}>{KZ.logout}</Text>
          </Pressable>
        </View>
      </ScrollView>

      {copyToastId ? <CopyToast key={copyToastId} onDone={() => { setCopyToastId(null); }} /> : null}
    </View>
  );
};

const formatBig = (n: number): string => {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 10_000) return `${Math.floor(n / 1_000)}K`;
  return n.toLocaleString('kk-KZ');
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0E0E2E' },
  center: { alignItems: 'center', justifyContent: 'center' },
  hero: {
    paddingBottom: spacing.lg,
    alignItems: 'center',
    overflow: 'hidden',
  },
  heroTop: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.sm,
  },
  backText: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
  },
  iconBtn: { fontSize: 22 },
  heroAvatarWrap: {
    width: 220,
    height: 220,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: spacing.sm,
  },
  sparkle: {
    position: 'absolute',
    fontSize: 22,
    left: '50%',
    top: '50%',
  },
  editBtn: {
    marginTop: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.full,
    backgroundColor: 'rgba(0,0,0,0.35)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
  },
  editBtnText: { color: colors.white, fontSize: fontSize.sm, fontWeight: fontWeight.bold },
  heroName: {
    color: colors.white,
    fontSize: 24,
    fontWeight: fontWeight.extrabold,
    marginTop: spacing.md,
    textAlign: 'center',
    paddingHorizontal: spacing.md,
  },
  heroIdRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
  },
  heroId: {
    color: colors.gold,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 1.5,
  },
  heroCopyIcon: { fontSize: fontSize.sm },
  heroLevelBadge: {
    marginTop: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.full,
    backgroundColor: 'rgba(0,0,0,0.45)',
    borderWidth: 1,
    borderColor: 'rgba(255,215,0,0.5)',
  },
  heroLevelText: {
    color: colors.gold,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
  },

  // ---- XP ----
  xpWrap: { width: '100%', gap: 6 },
  xpTrack: {
    height: 12,
    borderRadius: 6,
    backgroundColor: 'rgba(0,0,0,0.35)',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  xpFill: { height: '100%' },
  xpText: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 11,
    textAlign: 'center',
    fontWeight: fontWeight.semibold,
  },

  // ---- Sections ----
  section: {
    marginHorizontal: spacing.md,
    marginTop: spacing.lg,
    gap: spacing.sm,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  sectionTitle: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
  },
  sectionSub: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
  },

  // ---- Stats grid ----
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  statCard: {
    flexBasis: '31%',
    flexGrow: 1,
    paddingVertical: spacing.md,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: radius.md,
    borderWidth: 1,
    alignItems: 'center',
    gap: 4,
  },
  statIcon: { fontSize: 22 },
  statValue: { fontSize: fontSize.lg, fontWeight: fontWeight.extrabold },
  statLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 11, fontWeight: fontWeight.semibold },

  // ---- Achievements ----
  catRow: { paddingVertical: spacing.sm, gap: spacing.xs },
  catChip: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.full,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  catChipActive: { backgroundColor: 'rgba(255,215,0,0.22)', borderColor: colors.gold },
  catChipText: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
  },
  catChipTextActive: { color: colors.gold },
  achGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  achTile: {
    alignItems: 'center',
    gap: 4,
  },
  achIconWrap: {
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  achIcon: { fontSize: 28 },
  achIconLocked: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.35)',
    fontWeight: fontWeight.extrabold,
  },
  achLabel: {
    color: colors.white,
    fontSize: 11,
    fontWeight: fontWeight.bold,
    textAlign: 'center',
  },
  achLabelLocked: { color: 'rgba(255,255,255,0.35)' },

  // ---- Activity heatmap ----
  heatmap: {
    flexDirection: 'row',
    paddingVertical: spacing.sm,
  },
  heatmapCol: {
    marginRight: CELL_GAP,
    flexDirection: 'column',
  },
  heatmapLegend: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 4,
  },
  heatmapLegendText: { color: 'rgba(255,255,255,0.5)', fontSize: 11 },

  // ---- Battle row ----
  battleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: radius.md,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.sm,
    gap: spacing.sm,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  battleOutcome: {
    width: 60,
    paddingVertical: 4,
    borderRadius: radius.full,
    alignItems: 'center',
  },
  battleOutcomeText: {
    color: colors.white,
    fontSize: 11,
    fontWeight: fontWeight.extrabold,
  },
  battleAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  battleName: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
  },
  battleSub: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
  },

  subEmpty: {
    color: 'rgba(255,255,255,0.45)',
    textAlign: 'center',
    fontSize: fontSize.sm,
    paddingVertical: spacing.sm,
  },

  // ---- Footer buttons ----
  bigBtn: {
    height: 52,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  bigBtnText: { color: colors.white, fontSize: fontSize.md, fontWeight: fontWeight.extrabold },
  logoutBtn: {
    backgroundColor: 'rgba(255,71,87,0.12)',
    borderColor: 'rgba(255,71,87,0.5)',
  },

  // ---- Copy toast ----
  copyToast: {
    position: 'absolute',
    bottom: 120,
    alignSelf: 'center',
    backgroundColor: colors.success,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: radius.full,
  },
  copyToastText: { color: colors.white, fontSize: fontSize.md, fontWeight: fontWeight.extrabold },
});

export default ProfileScreen;
