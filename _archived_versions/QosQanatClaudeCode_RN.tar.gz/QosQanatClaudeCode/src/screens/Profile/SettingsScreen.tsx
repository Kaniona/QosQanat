import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import type { AuthStackParamList } from '@/navigation/types';
import { signOut } from '@/services/auth';
import { useGameStore } from '@/store/gameStore';
import { useSettingsStore, type Language, type Settings } from '@/store/settingsStore';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

import appJson from '../../../app.json';


type Nav = NativeStackNavigationProp<AuthStackParamList>;

const KZ = {
  title: '⚙️ Баптаулар',
  back: '← Артқа',
  generalHeader: 'Жалпы',
  language: 'Тіл',
  languageKk: 'ҚАЗ',
  languageRu: 'РУС',
  sound: 'Дыбыс',
  vibration: 'Дірілдеу',
  animations: 'Анимациялар',
  darkMode: 'Қара тақырып',

  notifyHeader: 'Хабарламалар',
  notifyFriendRequests: 'Дос өтінімдері',
  notifyBattleInvites: 'Шайқас шақырулары',
  notifyQuestComplete: 'Күнделікті тапсырмалар',
  notifyStreakReminder: 'Серия еске салғыш',
  streakReminderHour: 'Еске салу уақыты',

  accountHeader: 'Аккаунт',
  editProfile: 'Профильді өңдеу',
  changeAssistant: 'Көмекшіні ауыстыру',
  changeAssistantHint: '30 күнде 1 рет',
  qqId: 'QQ-ID',

  aboutHeader: 'Қосымша',
  appVersion: 'Қолданба нұсқасы',
  terms: 'Пайдалану шарттары',
  privacy: 'Құпиялық саясаты',
  support: 'Қолдау: support@qosqanat.kz',

  logout: 'Шығу',
  logoutConfirm: 'Шығасыз ба?',
  logoutBody: 'Жүйеден шыққанда қайта кіру керек болады.',
  logoutYes: 'Иә, шығамын',
  logoutNo: 'Болдырмау',

  comingSoon: 'Жақын арада қол жетімді болады.',
  assistantLocked: (days: number) => `Көмекшіні келесі ${days} күн ішінде ауыстыруға болмайды.`,
};

// 30-day lock — assistant change is allowed only once per 30 days. We use the
// users.updated_at column as a proxy: if it was modified within 30 days the
// button is locked. (A dedicated `assistant_changed_at` column would be more
// precise but is out of scope here.)
const ASSISTANT_LOCK_DAYS = 30;

// ----------------------------------------------------------------------------
// Animated row container
// ----------------------------------------------------------------------------

interface RowProps {
  children: React.ReactNode;
  onPress?: () => void;
  disabled?: boolean;
}

const Row: React.FC<RowProps> = ({ children, onPress, disabled }) => {
  const scale = useSharedValue(1);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const inner = (
    <Animated.View style={[styles.row, disabled && styles.rowDisabled, style]}>
      {children}
    </Animated.View>
  );
  if (!onPress) return inner;
  return (
    <Pressable
      onPress={disabled ? undefined : onPress}
      onPressIn={() => {
        if (!disabled) scale.value = withSpring(0.98, { damping: 14, stiffness: 220 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 14, stiffness: 220 });
      }}
    >
      {inner}
    </Pressable>
  );
};

// ----------------------------------------------------------------------------
// Section card
// ----------------------------------------------------------------------------

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <View style={styles.section}>
    <Text style={styles.sectionTitle}>{title}</Text>
    <View style={styles.sectionCard}>{children}</View>
  </View>
);

// ----------------------------------------------------------------------------
// Language pill (КАЗ/РУС segmented)
// ----------------------------------------------------------------------------

interface LangProps {
  value: Language;
  onChange: (v: Language) => void;
}

const LangPill: React.FC<LangProps> = ({ value, onChange }) => (
  <View style={styles.langPill}>
    {(['kk', 'ru'] as const).map((l) => {
      const active = value === l;
      return (
        <Pressable
          key={l}
          onPress={() => { onChange(l); }}
          style={[styles.langSeg, active && styles.langSegActive]}
        >
          <Text style={[styles.langSegText, active && styles.langSegTextActive]}>
            {l === 'kk' ? KZ.languageKk : KZ.languageRu}
          </Text>
        </Pressable>
      );
    })}
  </View>
);

// ----------------------------------------------------------------------------
// Hour wheel — picks 0..23.
// ----------------------------------------------------------------------------

const HourPickerModal: React.FC<{
  visible: boolean;
  value: number;
  onSelect: (h: number) => void;
  onClose: () => void;
}> = ({ visible, value, onSelect, onClose }) => {
  const ty = useSharedValue(400);
  useEffect(() => {
    if (visible) ty.value = withSpring(0, { damping: 18, stiffness: 200 });
    else ty.value = withTiming(400, { duration: 200 });
  }, [visible, ty]);
  const style = useAnimatedStyle(() => ({ transform: [{ translateY: ty.value }] }));
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={styles.modalBackdrop} onPress={onClose}>
        <Animated.View style={[styles.modalSheet, style]} onStartShouldSetResponder={() => true}>
          <Pressable onPress={() => undefined}>
            <Text style={styles.modalTitle}>{KZ.streakReminderHour}</Text>
            <ScrollView style={{ maxHeight: 320 }}>
              {Array.from({ length: 24 }, (_, h) => h).map((h) => {
                const active = h === value;
                return (
                  <Pressable
                    key={h}
                    onPress={() => {
                      onSelect(h);
                      onClose();
                    }}
                    style={[styles.hourRow, active && styles.hourRowActive]}
                  >
                    <Text style={[styles.hourText, active && styles.hourTextActive]}>
                      {`${String(h).padStart(2, '0')}:00`}
                    </Text>
                    {active ? <Text style={styles.hourCheck}>✓</Text> : null}
                  </Pressable>
                );
              })}
            </ScrollView>
          </Pressable>
        </Animated.View>
      </Pressable>
    </Modal>
  );
};

// ----------------------------------------------------------------------------
// Logout confirm modal
// ----------------------------------------------------------------------------

const LogoutModal: React.FC<{
  visible: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}> = ({ visible, onCancel, onConfirm }) => (
  <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
    <View style={styles.modalBackdrop}>
      <View style={styles.confirmBox}>
        <Text style={styles.confirmTitle}>{KZ.logoutConfirm}</Text>
        <Text style={styles.confirmBody}>{KZ.logoutBody}</Text>
        <View style={styles.confirmRow}>
          <Pressable style={[styles.confirmBtn, styles.confirmCancel]} onPress={onCancel}>
            <Text style={styles.confirmBtnText}>{KZ.logoutNo}</Text>
          </Pressable>
          <Pressable style={[styles.confirmBtn, styles.confirmYes]} onPress={onConfirm}>
            <Text style={[styles.confirmBtnText, { color: colors.white }]}>{KZ.logoutYes}</Text>
          </Pressable>
        </View>
      </View>
    </View>
  </Modal>
);

// ----------------------------------------------------------------------------
// Screen
// ----------------------------------------------------------------------------

const SettingsScreen: React.FC = () => {
  const nav = useNavigation<Nav>();
  const insets = useSafeAreaInsets();
  const user = useUserStore((s) => s.user);
  const setUser = useUserStore((s) => s.setUser);
  const resetGame = useGameStore((s) => s.reset);

  const language = useSettingsStore((s) => s.language);
  const sound = useSettingsStore((s) => s.sound);
  const vibration = useSettingsStore((s) => s.vibration);
  const animations = useSettingsStore((s) => s.animations);
  const darkMode = useSettingsStore((s) => s.darkMode);
  const notifyFriendRequests = useSettingsStore((s) => s.notifyFriendRequests);
  const notifyBattleInvites = useSettingsStore((s) => s.notifyBattleInvites);
  const notifyQuestComplete = useSettingsStore((s) => s.notifyQuestComplete);
  const notifyStreakReminder = useSettingsStore((s) => s.notifyStreakReminder);
  const streakReminderHour = useSettingsStore((s) => s.streakReminderHour);
  const hydrate = useSettingsStore((s) => s.hydrate);
  const setSetting = useSettingsStore((s) => s.setSetting);

  const [hourModalVisible, setHourModalVisible] = useState(false);
  const [logoutVisible, setLogoutVisible] = useState(false);

  useEffect(() => {
    void hydrate();
  }, [hydrate]);

  // 30-day assistant lock — proxy by updated_at on the user row.
  const assistantLockedDaysLeft = useMemo(() => {
    if (!user) return 0;
    const lastChange = (user as { updated_at?: string }).updated_at;
    if (!lastChange) return 0;
    const last = new Date(lastChange).getTime();
    if (Number.isNaN(last)) return 0;
    const diffMs = Date.now() - last;
    const left = ASSISTANT_LOCK_DAYS - Math.floor(diffMs / 86_400_000);
    return Math.max(0, left);
  }, [user]);

  const toggle = useCallback(
    <K extends keyof Settings>(key: K) =>
      (value: Settings[K]) => {
        void setSetting(key, value);
      },
    [setSetting],
  );

  const handleLogout = useCallback(async () => {
    setLogoutVisible(false);
    try {
      await signOut();
    } finally {
      // RootNavigator watches isAuthenticated and will swap back to
      // AuthNavigator automatically — no nav.reset needed.
      resetGame();
      setUser(null);
    }
  }, [resetGame, setUser]);

  const handleChangeAssistant = useCallback(() => {
    if (assistantLockedDaysLeft > 0) {
      Alert.alert(KZ.assistantLocked(assistantLockedDaysLeft));
      return;
    }
    nav.navigate('AssistantSelect');
  }, [assistantLockedDaysLeft, nav]);

  const appVersion = (appJson as { expo?: { version?: string } }).expo?.version ?? '1.0.0';

  return (
    <View style={styles.root}>
      <LinearGradient
        colors={['#0E0E2E', '#1A1A4E', '#252570'] as readonly [string, string, string]}
        style={StyleSheet.absoluteFill}
      />

      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => { nav.goBack(); }} hitSlop={10} style={{ width: 70 }}>
          <Text style={styles.backText}>{KZ.back}</Text>
        </Pressable>
        <Text style={styles.title}>{KZ.title}</Text>
        <View style={{ width: 70 }} />
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + spacing.xl }}>
        <Section title={KZ.generalHeader}>
          <Row>
            <Text style={styles.rowLabel}>🌐 {KZ.language}</Text>
            <LangPill value={language} onChange={(v) => void setSetting('language', v)} />
          </Row>
          <Row>
            <Text style={styles.rowLabel}>🔊 {KZ.sound}</Text>
            <Switch
              value={sound}
              onValueChange={toggle('sound')}
              thumbColor={sound ? colors.gold : colors.white}
              trackColor={{ false: '#3A3A6E', true: 'rgba(255,215,0,0.4)' }}
            />
          </Row>
          <Row>
            <Text style={styles.rowLabel}>📳 {KZ.vibration}</Text>
            <Switch
              value={vibration}
              onValueChange={toggle('vibration')}
              thumbColor={vibration ? colors.gold : colors.white}
              trackColor={{ false: '#3A3A6E', true: 'rgba(255,215,0,0.4)' }}
            />
          </Row>
          <Row>
            <Text style={styles.rowLabel}>✨ {KZ.animations}</Text>
            <Switch
              value={animations}
              onValueChange={toggle('animations')}
              thumbColor={animations ? colors.gold : colors.white}
              trackColor={{ false: '#3A3A6E', true: 'rgba(255,215,0,0.4)' }}
            />
          </Row>
          <Row>
            <Text style={styles.rowLabel}>🌙 {KZ.darkMode}</Text>
            <Switch
              value={darkMode}
              onValueChange={toggle('darkMode')}
              thumbColor={darkMode ? colors.gold : colors.white}
              trackColor={{ false: '#3A3A6E', true: 'rgba(255,215,0,0.4)' }}
            />
          </Row>
        </Section>

        <Section title={KZ.notifyHeader}>
          <Row>
            <Text style={styles.rowLabel}>👥 {KZ.notifyFriendRequests}</Text>
            <Switch
              value={notifyFriendRequests}
              onValueChange={toggle('notifyFriendRequests')}
              thumbColor={notifyFriendRequests ? colors.gold : colors.white}
              trackColor={{ false: '#3A3A6E', true: 'rgba(255,215,0,0.4)' }}
            />
          </Row>
          <Row>
            <Text style={styles.rowLabel}>⚔️ {KZ.notifyBattleInvites}</Text>
            <Switch
              value={notifyBattleInvites}
              onValueChange={toggle('notifyBattleInvites')}
              thumbColor={notifyBattleInvites ? colors.gold : colors.white}
              trackColor={{ false: '#3A3A6E', true: 'rgba(255,215,0,0.4)' }}
            />
          </Row>
          <Row>
            <Text style={styles.rowLabel}>🎯 {KZ.notifyQuestComplete}</Text>
            <Switch
              value={notifyQuestComplete}
              onValueChange={toggle('notifyQuestComplete')}
              thumbColor={notifyQuestComplete ? colors.gold : colors.white}
              trackColor={{ false: '#3A3A6E', true: 'rgba(255,215,0,0.4)' }}
            />
          </Row>
          <Row>
            <Text style={styles.rowLabel}>🔥 {KZ.notifyStreakReminder}</Text>
            <Switch
              value={notifyStreakReminder}
              onValueChange={toggle('notifyStreakReminder')}
              thumbColor={notifyStreakReminder ? colors.gold : colors.white}
              trackColor={{ false: '#3A3A6E', true: 'rgba(255,215,0,0.4)' }}
            />
          </Row>
          <Row
            onPress={notifyStreakReminder ? () => { setHourModalVisible(true); } : undefined}
            disabled={!notifyStreakReminder}
          >
            <Text style={styles.rowLabel}>⏰ {KZ.streakReminderHour}</Text>
            <Text style={styles.rowValue}>
              {`${String(streakReminderHour).padStart(2, '0')}:00`}
            </Text>
          </Row>
        </Section>

        <Section title={KZ.accountHeader}>
          <Row onPress={() => { Alert.alert(KZ.comingSoon); }}>
            <Text style={styles.rowLabel}>✏️ {KZ.editProfile}</Text>
            <Text style={styles.rowChevron}>›</Text>
          </Row>
          <Row onPress={handleChangeAssistant}>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowLabel}>🧑‍🚀 {KZ.changeAssistant}</Text>
              <Text style={styles.rowHint}>{KZ.changeAssistantHint}</Text>
            </View>
            <Text style={styles.rowChevron}>›</Text>
          </Row>
          <Row>
            <Text style={styles.rowLabel}>🆔 {KZ.qqId}</Text>
            <Text style={[styles.rowValue, { color: colors.gold, letterSpacing: 1.5 }]}>
              {user?.qosqanat_id ?? '—'}
            </Text>
          </Row>
        </Section>

        <Section title={KZ.aboutHeader}>
          <Row>
            <Text style={styles.rowLabel}>📦 {KZ.appVersion}</Text>
            <Text style={styles.rowValue}>{appVersion}</Text>
          </Row>
          <Row onPress={() => { Alert.alert(KZ.comingSoon); }}>
            <Text style={styles.rowLabel}>📜 {KZ.terms}</Text>
            <Text style={styles.rowChevron}>›</Text>
          </Row>
          <Row onPress={() => { Alert.alert(KZ.comingSoon); }}>
            <Text style={styles.rowLabel}>🔒 {KZ.privacy}</Text>
            <Text style={styles.rowChevron}>›</Text>
          </Row>
          <Row>
            <Text style={styles.rowLabel}>📧 {KZ.support}</Text>
          </Row>
        </Section>

        <View style={styles.section}>
          <Pressable style={styles.logoutBtn} onPress={() => { setLogoutVisible(true); }}>
            <Text style={styles.logoutText}>🚪 {KZ.logout}</Text>
          </Pressable>
        </View>
      </ScrollView>

      <HourPickerModal
        visible={hourModalVisible}
        value={streakReminderHour}
        onSelect={(h) => void setSetting('streakReminderHour', h)}
        onClose={() => { setHourModalVisible(false); }}
      />

      <LogoutModal
        visible={logoutVisible}
        onCancel={() => { setLogoutVisible(false); }}
        onConfirm={() => void handleLogout()}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0E0E2E' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.sm,
  },
  backText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
  },
  title: { color: colors.white, fontSize: fontSize.xl, fontWeight: fontWeight.extrabold },

  section: {
    marginHorizontal: spacing.md,
    marginTop: spacing.lg,
    gap: spacing.sm,
  },
  sectionTitle: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  sectionCard: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    overflow: 'hidden',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(255,255,255,0.08)',
    gap: spacing.sm,
  },
  rowDisabled: { opacity: 0.4 },
  rowLabel: {
    flex: 1,
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
  },
  rowValue: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
  },
  rowHint: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: fontSize.xs,
    marginTop: 2,
  },
  rowChevron: {
    color: 'rgba(255,255,255,0.4)',
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
  },

  // Language pill
  langPill: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0,0,0,0.35)',
    borderRadius: radius.full,
    padding: 3,
    gap: 2,
  },
  langSeg: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.full,
  },
  langSegActive: { backgroundColor: colors.gold },
  langSegText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 11,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 1,
  },
  langSegTextActive: { color: colors.text },

  // Logout button
  logoutBtn: {
    height: 56,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,71,87,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(255,71,87,0.5)',
  },
  logoutText: {
    color: colors.danger,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
  },

  // Modals
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'flex-end',
  },
  modalSheet: {
    backgroundColor: '#1A1A4E',
    paddingTop: spacing.md,
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.xl,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    gap: spacing.sm,
  },
  modalTitle: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
    marginBottom: spacing.sm,
    textAlign: 'center',
  },
  hourRow: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 2,
  },
  hourRowActive: { backgroundColor: 'rgba(255,215,0,0.18)' },
  hourText: { color: colors.white, fontSize: fontSize.md, fontWeight: fontWeight.bold },
  hourTextActive: { color: colors.gold },
  hourCheck: { color: colors.gold, fontSize: fontSize.lg, fontWeight: fontWeight.extrabold },

  // Confirm dialog
  confirmBox: {
    marginHorizontal: spacing.lg,
    backgroundColor: '#2A2870',
    borderRadius: radius.lg,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
    gap: spacing.md,
    marginTop: 'auto',
    marginBottom: 'auto',
  },
  confirmTitle: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
    textAlign: 'center',
  },
  confirmBody: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.sm,
    textAlign: 'center',
    lineHeight: 20,
  },
  confirmRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  confirmBtn: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    alignItems: 'center',
  },
  confirmCancel: { backgroundColor: 'rgba(255,255,255,0.12)' },
  confirmYes: { backgroundColor: colors.danger },
  confirmBtnText: { color: colors.white, fontSize: fontSize.md, fontWeight: fontWeight.bold },
});

export default SettingsScreen;
