import type { ItemCategory, Rarity } from '@/types';

// ----------------------------------------------------------------------------
// Shop items registry — pure metadata. Every entry's `id` MUST also exist in
// `src/data/avatarItems.tsx` so that AvatarBase can render it.
//
// Pricing model:
//   * `price === 0` AND `isDefault === true` => auto-owned, included in the
//     "starter wardrobe" (cannot be bought, only equipped/unequipped).
//   * `price > 0` => unlocks in user_inventory after a successful purchase.
//
// `levelRequired` is enforced client-side: items below the player's level show
// a lock badge on the card and the purchase button is disabled.
// ----------------------------------------------------------------------------

export interface ShopItem {
  id: string;
  nameKz: string;
  descriptionKz: string;
  category: ItemCategory;
  price: number;
  levelRequired: number;
  rarity: Rarity;
  isDefault: boolean;
  isNew?: boolean; // shown as "ЖАҢА" badge in the grid
}

export const CATEGORY_LABELS_KZ: Readonly<Record<ItemCategory, string>> = {
  top: 'Жоғарғы',
  bottom: 'Төменгі',
  hat: 'Бас киім',
  accessory: 'Аксессуар',
  pet: 'Питомец',
};

export const RARITY_LABELS_KZ: Readonly<Record<Rarity, string>> = {
  common: 'Қарапайым',
  rare: 'Сирек',
  epic: 'Эпикалық',
  legendary: 'Аңыздық',
};

export const RARITY_COLORS: Readonly<Record<Rarity, string>> = {
  common: '#9CA3AF',
  rare: '#4A6CF7',
  epic: '#7B61FF',
  legendary: '#FFD700',
};

// ---------------------------------------------------------------------------
// TOPS
// ---------------------------------------------------------------------------
const TOPS: readonly ShopItem[] = [
  {
    id: 'top_school_jacket',
    nameKz: 'Мектеп жакеті',
    descriptionKz: 'Мектеп формасы — әр оқушының бастапқы киімі.',
    category: 'top',
    price: 0,
    levelRequired: 1,
    rarity: 'common',
    isDefault: true,
  },
  {
    id: 'top_tshirt_white',
    nameKz: 'Ақ футболка',
    descriptionKz: 'Қарапайым, бірақ әсем ақ футболка.',
    category: 'top',
    price: 40,
    levelRequired: 1,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'top_tshirt_blue',
    nameKz: 'Көк футболка',
    descriptionKz: 'Аспан түсті жұмсақ мақта футболка.',
    category: 'top',
    price: 40,
    levelRequired: 1,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'top_hoodie_red',
    nameKz: 'Қызыл худи',
    descriptionKz: 'Жайлы әрі ыстық қызыл худи.',
    category: 'top',
    price: 100,
    levelRequired: 3,
    rarity: 'common',
    isDefault: false,
    isNew: true,
  },
  {
    id: 'top_hoodie_blue',
    nameKz: 'Көк худи',
    descriptionKz: 'Шынайы көк түсті стильді худи.',
    category: 'top',
    price: 100,
    levelRequired: 3,
    rarity: 'common',
    isDefault: false,
    isNew: true,
  },
  {
    id: 'top_hoodie_green',
    nameKz: 'Жасыл худи',
    descriptionKz: 'Орманның түсіндегі жайлы худи.',
    category: 'top',
    price: 100,
    levelRequired: 3,
    rarity: 'common',
    isDefault: false,
    isNew: true,
  },
  {
    id: 'top_sport_sweatshirt',
    nameKz: 'Спорт свитшот',
    descriptionKz: 'Жаттығу үшін икемді әрі жеңіл свитшот.',
    category: 'top',
    price: 150,
    levelRequired: 5,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'top_ethnic_shirt',
    nameKz: 'Этно жейде',
    descriptionKz: 'Қазақы өрнекпен тігілген ұлттық жейде.',
    category: 'top',
    price: 180,
    levelRequired: 7,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'top_leather_jacket',
    nameKz: 'Кожаный жакет',
    descriptionKz: 'Қара былғары жакет — стильдің шыңы.',
    category: 'top',
    price: 250,
    levelRequired: 8,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'top_chapan',
    nameKz: 'Чапан',
    descriptionKz: 'Дәстүрлі қазақ чапаны — мерекеге арнайы.',
    category: 'top',
    price: 400,
    levelRequired: 10,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'top_winter_coat',
    nameKz: 'Қысқы пальто',
    descriptionKz: 'Қатты аязға да төтеп беретін жылы пальто.',
    category: 'top',
    price: 450,
    levelRequired: 12,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'top_warrior_uniform',
    nameKz: 'Жауынгер мундирі',
    descriptionKz: 'Алтын ниткалармен өрілген батыр киімі.',
    category: 'top',
    price: 600,
    levelRequired: 18,
    rarity: 'epic',
    isDefault: false,
  },
  {
    id: 'top_astronaut',
    nameKz: 'Астронавт костюмі',
    descriptionKz: 'Жұлдыздарды жаулауға дайын ғарыш костюмі.',
    category: 'top',
    price: 800,
    levelRequired: 20,
    rarity: 'epic',
    isDefault: false,
  },
  {
    id: 'top_robot_armor',
    nameKz: 'Робот сауыт',
    descriptionKz: 'Болашақтың роботтанған ауыр сауыты.',
    category: 'top',
    price: 1200,
    levelRequired: 25,
    rarity: 'legendary',
    isDefault: false,
  },
  {
    id: 'top_dragon_armor',
    nameKz: 'Айдаhар сауыты',
    descriptionKz: 'Айдаhар қабыршағынан жасалған аңыздық сауыт.',
    category: 'top',
    price: 2000,
    levelRequired: 30,
    rarity: 'legendary',
    isDefault: false,
  },
];

// ---------------------------------------------------------------------------
// BOTTOMS
// ---------------------------------------------------------------------------
const BOTTOMS: readonly ShopItem[] = [
  {
    id: 'bottom_school_pants',
    nameKz: 'Мектеп шалбары',
    descriptionKz: 'Мектеп формасының классикалық шалбары.',
    category: 'bottom',
    price: 0,
    levelRequired: 1,
    rarity: 'common',
    isDefault: true,
  },
  {
    id: 'bottom_shorts',
    nameKz: 'Шорт',
    descriptionKz: 'Жазғы ыстық күнге арналған жайлы шорт.',
    category: 'bottom',
    price: 50,
    levelRequired: 1,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'bottom_jeans',
    nameKz: 'Джинс',
    descriptionKz: 'Көк түсті классикалық джинс шалбар.',
    category: 'bottom',
    price: 80,
    levelRequired: 3,
    rarity: 'common',
    isDefault: false,
    isNew: true,
  },
  {
    id: 'bottom_sport_pants',
    nameKz: 'Спорт шалбар',
    descriptionKz: 'Жаттығуға арналған икемді спорт шалбары.',
    category: 'bottom',
    price: 80,
    levelRequired: 3,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'bottom_dark_jeans',
    nameKz: 'Қара джинс',
    descriptionKz: 'Қара түсті стильді джинс шалбар.',
    category: 'bottom',
    price: 120,
    levelRequired: 5,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'bottom_traditional',
    nameKz: 'Дәстүрлі шалбар',
    descriptionKz: 'Қазақы өрнекпен өрілген ұлттық шалбар.',
    category: 'bottom',
    price: 200,
    levelRequired: 8,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'bottom_leather_pants',
    nameKz: 'Кожаный шалбар',
    descriptionKz: 'Қара былғары шалбар — рок мәнерінде.',
    category: 'bottom',
    price: 350,
    levelRequired: 14,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'bottom_armor_pants',
    nameKz: 'Сауыт шалбары',
    descriptionKz: 'Металл пластиналармен қапталған сауыт шалбары.',
    category: 'bottom',
    price: 550,
    levelRequired: 20,
    rarity: 'epic',
    isDefault: false,
  },
];

// ---------------------------------------------------------------------------
// HATS
// ---------------------------------------------------------------------------
const HATS: readonly ShopItem[] = [
  {
    id: 'hat_none',
    nameKz: 'Жоқ',
    descriptionKz: 'Бас киімсіз. Шашты көрсетіңіз!',
    category: 'hat',
    price: 0,
    levelRequired: 1,
    rarity: 'common',
    isDefault: true,
  },
  {
    id: 'hat_baseball_cap',
    nameKz: 'Бейсболка',
    descriptionKz: 'Ең сүйікті көк бейсболка.',
    category: 'hat',
    price: 50,
    levelRequired: 2,
    rarity: 'common',
    isDefault: false,
    isNew: true,
  },
  {
    id: 'hat_winter',
    nameKz: 'Қыс шапка',
    descriptionKz: 'Қыста жылы ұстайтын жүн шапка.',
    category: 'hat',
    price: 80,
    levelRequired: 4,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'hat_takiya',
    nameKz: 'Такия',
    descriptionKz: 'Дәстүрлі қазақ такиясы.',
    category: 'hat',
    price: 150,
    levelRequired: 6,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'hat_grab',
    nameKz: 'Граб-шляпа',
    descriptionKz: 'Шынайы джентльменнің шляпасы.',
    category: 'hat',
    price: 250,
    levelRequired: 10,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'hat_borik',
    nameKz: 'Бөрік',
    descriptionKz: 'Қазақы аң терісінен тігілген бөрік.',
    category: 'hat',
    price: 300,
    levelRequired: 12,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'hat_crown',
    nameKz: 'Патша тәжі',
    descriptionKz: 'Алтын тәж — нағыз патшаның белгісі.',
    category: 'hat',
    price: 500,
    levelRequired: 15,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'hat_space_helmet',
    nameKz: 'Ғарышкер дулыға',
    descriptionKz: 'Шынайы ғарыш сапарына арналған дулыға.',
    category: 'hat',
    price: 900,
    levelRequired: 22,
    rarity: 'epic',
    isDefault: false,
  },
];

// ---------------------------------------------------------------------------
// ACCESSORIES
// ---------------------------------------------------------------------------
const ACCESSORIES: readonly ShopItem[] = [
  {
    id: 'acc_none',
    nameKz: 'Жоқ',
    descriptionKz: 'Аксессуарсыз — таза стиль.',
    category: 'accessory',
    price: 0,
    levelRequired: 1,
    rarity: 'common',
    isDefault: true,
  },
  {
    id: 'acc_book',
    nameKz: 'Кітап',
    descriptionKz: 'Білім — ең құнды аксессуар.',
    category: 'accessory',
    price: 40,
    levelRequired: 1,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'acc_bracelet',
    nameKz: 'Білезік',
    descriptionKz: 'Көк моншақтары бар әсем білезік.',
    category: 'accessory',
    price: 60,
    levelRequired: 2,
    rarity: 'common',
    isDefault: false,
    isNew: true,
  },
  {
    id: 'acc_gold_chain',
    nameKz: 'Алтын тізбек',
    descriptionKz: 'Жарқыраған шынайы алтын тізбек.',
    category: 'accessory',
    price: 120,
    levelRequired: 5,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'acc_backpack',
    nameKz: 'Рюкзак',
    descriptionKz: 'Мектеп заттарын алып жүруге арналған рюкзак.',
    category: 'accessory',
    price: 180,
    levelRequired: 6,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'acc_vr_glasses',
    nameKz: 'VR очки',
    descriptionKz: 'Виртуалды әлемге өту үшін очки.',
    category: 'accessory',
    price: 300,
    levelRequired: 10,
    rarity: 'rare',
    isDefault: false,
    isNew: true,
  },
  {
    id: 'acc_gold_medal',
    nameKz: 'Алтын медаль',
    descriptionKz: 'Жеңімпаздың алтын медалі.',
    category: 'accessory',
    price: 450,
    levelRequired: 16,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'acc_wings',
    nameKz: 'Қанат',
    descriptionKz: 'Шынайы аңыздық алтын қанаттар.',
    category: 'accessory',
    price: 1000,
    levelRequired: 22,
    rarity: 'epic',
    isDefault: false,
  },
];

// ---------------------------------------------------------------------------
// PETS
// ---------------------------------------------------------------------------
const PETS: readonly ShopItem[] = [
  {
    id: 'pet_none',
    nameKz: 'Жоқ',
    descriptionKz: 'Питомецсіз — жалғыз кейіпкер.',
    category: 'pet',
    price: 0,
    levelRequired: 1,
    rarity: 'common',
    isDefault: true,
  },
  {
    id: 'pet_fish',
    nameKz: 'Балық',
    descriptionKz: 'Алтын балық — сіздің тілегіңізді орындайды.',
    category: 'pet',
    price: 200,
    levelRequired: 7,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'pet_butterfly',
    nameKz: 'Шапалақ',
    descriptionKz: 'Көк-сары түсті керемет шапалақ.',
    category: 'pet',
    price: 300,
    levelRequired: 8,
    rarity: 'common',
    isDefault: false,
  },
  {
    id: 'pet_white_cat',
    nameKz: 'Ақ мысық',
    descriptionKz: 'Тілекті орындайтын ақ мысық.',
    category: 'pet',
    price: 500,
    levelRequired: 10,
    rarity: 'rare',
    isDefault: false,
    isNew: true,
  },
  {
    id: 'pet_black_cat',
    nameKz: 'Қара мысық',
    descriptionKz: 'Сиқырлы қара мысық — сәттіліктің белгісі.',
    category: 'pet',
    price: 500,
    levelRequired: 10,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'pet_wolf_pup',
    nameKz: 'Қасқыр күшігі',
    descriptionKz: 'Адал әрі батыл қасқыр күшігі.',
    category: 'pet',
    price: 600,
    levelRequired: 12,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'pet_robot_friend',
    nameKz: 'Робот достас',
    descriptionKz: 'Әрқашан қасында болатын кішкентай робот.',
    category: 'pet',
    price: 750,
    levelRequired: 15,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'pet_eagle',
    nameKz: 'Бүркіт',
    descriptionKz: 'Дала перзенті — мақтаныш құсы.',
    category: 'pet',
    price: 800,
    levelRequired: 15,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'pet_snow_leopard',
    nameKz: 'Барс балапаны',
    descriptionKz: 'Жоғары таулардың сирек жыртқышы.',
    category: 'pet',
    price: 1000,
    levelRequired: 20,
    rarity: 'rare',
    isDefault: false,
  },
  {
    id: 'pet_dragon_chick',
    nameKz: 'Айдаhар балапаны',
    descriptionKz: 'Аңыздан шыққан жалын шашатын балапан.',
    category: 'pet',
    price: 1500,
    levelRequired: 25,
    rarity: 'epic',
    isDefault: false,
  },
  {
    id: 'pet_phoenix',
    nameKz: 'Феникс балапаны',
    descriptionKz: 'Күлден қайта туылған отты құс.',
    category: 'pet',
    price: 1800,
    levelRequired: 28,
    rarity: 'legendary',
    isDefault: false,
  },
];

// ---------------------------------------------------------------------------
// Public registry
// ---------------------------------------------------------------------------
export const SHOP_ITEMS: readonly ShopItem[] = [
  ...TOPS,
  ...BOTTOMS,
  ...HATS,
  ...ACCESSORIES,
  ...PETS,
];

const SHOP_INDEX = new Map<string, ShopItem>(SHOP_ITEMS.map((i) => [i.id, i]));

export const getShopItem = (id: string | null | undefined): ShopItem | undefined =>
  id ? SHOP_INDEX.get(id) : undefined;

export const itemsByCategory = (category: ItemCategory): readonly ShopItem[] =>
  SHOP_ITEMS.filter((i) => i.category === category);

// Items that the player owns by default (no purchase required).
export const DEFAULT_OWNED_IDS: readonly string[] = SHOP_ITEMS.filter(
  (i) => i.price === 0 && i.isDefault,
).map((i) => i.id);

export const CATEGORY_ORDER: readonly ItemCategory[] = ['top', 'bottom', 'hat', 'accessory', 'pet'];
