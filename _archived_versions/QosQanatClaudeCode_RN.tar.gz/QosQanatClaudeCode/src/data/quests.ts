// ----------------------------------------------------------------------------
// Daily quests + streak milestones.
//
// Quest IDs are stable strings (Q001..) so that daily_quests rows in Supabase
// can reference them across releases without DB migrations.
//
// A quest's `event` is the engine signal that drives progress. The gameStore /
// quest engine calls `recordQuestEvent(event, delta)` and any active quest
// with a matching event has its `progress` incremented.
// ----------------------------------------------------------------------------

export type QuestEvent =
  | 'login' // first time logging in today
  | 'task_completed' // any learning-map node finished
  | 'task_perfect' // perfect-score completion
  | 'battle_played' // joined any battle
  | 'battle_won' // won a battle
  | 'shop_purchase' // bought any shop item
  | 'friend_added'; // added a new friend

export interface Quest {
  id: string;
  titleKz: string;
  descriptionKz: string;
  event: QuestEvent;
  target: number;
  rewardCoins: number;
  rewardXp: number;
  rewardAkyl: number;
  icon: string;
}

export const DAILY_QUESTS: readonly Quest[] = [
  {
    id: 'Q001',
    titleKz: 'Бүгінгі кіру',
    descriptionKz: 'QosQanat-қа бүгін кіріп шық',
    event: 'login',
    target: 1,
    rewardCoins: 10,
    rewardXp: 10,
    rewardAkyl: 0,
    icon: '🌅',
  },
  {
    id: 'Q002',
    titleKz: 'Алғашқы тапсырма',
    descriptionKz: 'Бір тапсырманы аяқта',
    event: 'task_completed',
    target: 1,
    rewardCoins: 15,
    rewardXp: 20,
    rewardAkyl: 0,
    icon: '📘',
  },
  {
    id: 'Q003',
    titleKz: 'Белсенді оқушы',
    descriptionKz: 'Үш тапсырманы аяқта',
    event: 'task_completed',
    target: 3,
    rewardCoins: 30,
    rewardXp: 50,
    rewardAkyl: 5,
    icon: '⚡',
  },
  {
    id: 'Q004',
    titleKz: 'Білімқор',
    descriptionKz: 'Бес тапсырманы аяқта',
    event: 'task_completed',
    target: 5,
    rewardCoins: 50,
    rewardXp: 80,
    rewardAkyl: 10,
    icon: '🎓',
  },
  {
    id: 'Q006',
    titleKz: 'Мінсіз орындаушы',
    descriptionKz: 'Бір тапсырманы мінсіз орында',
    event: 'task_perfect',
    target: 1,
    rewardCoins: 20,
    rewardXp: 30,
    rewardAkyl: 0,
    icon: '💯',
  },
  {
    id: 'Q008',
    titleKz: 'Социалды оқушы',
    descriptionKz: 'Бір шайқасқа қатыс',
    event: 'battle_played',
    target: 1,
    rewardCoins: 20,
    rewardXp: 25,
    rewardAkyl: 0,
    icon: '⚔️',
  },
  {
    id: 'Q009',
    titleKz: 'Жеңімпаз',
    descriptionKz: 'Бір шайқаста жеңіске жет',
    event: 'battle_won',
    target: 1,
    rewardCoins: 40,
    rewardXp: 50,
    rewardAkyl: 0,
    icon: '🏆',
  },
  {
    id: 'Q011',
    titleKz: 'Дүкен барушы',
    descriptionKz: 'Дүкеннен бір зат сатып ал',
    event: 'shop_purchase',
    target: 1,
    rewardCoins: 15,
    rewardXp: 0,
    rewardAkyl: 0,
    icon: '🛍️',
  },
  {
    id: 'Q012',
    titleKz: 'Дос тапты',
    descriptionKz: 'Бір дос қос',
    event: 'friend_added',
    target: 1,
    rewardCoins: 25,
    rewardXp: 30,
    rewardAkyl: 0,
    icon: '🤝',
  },
];

const dailyQuestMap = new Map<string, Quest>(DAILY_QUESTS.map((q) => [q.id, q]));

export const getQuest = (id: string): Quest | undefined => dailyQuestMap.get(id);

// ----------------------------------------------------------------------------
// Streak milestones
// ----------------------------------------------------------------------------

export interface StreakMilestone {
  days: number;
  rewardCoins: number;
  titleKz: string;
}

export const STREAK_MILESTONES: readonly StreakMilestone[] = [
  { days: 3, rewardCoins: 50, titleKz: '3 күн қатарынан!' },
  { days: 7, rewardCoins: 150, titleKz: '7 күн қатарынан!' },
  { days: 14, rewardCoins: 300, titleKz: '2 апта қатарынан!' },
  { days: 30, rewardCoins: 1000, titleKz: 'Ай бойы күн сайын!' },
  { days: 60, rewardCoins: 2500, titleKz: '2 ай қатарынан!' },
  { days: 100, rewardCoins: 5000, titleKz: '100 күн — Аңыз!' },
];

export const milestoneFor = (streakDays: number): StreakMilestone | undefined =>
  STREAK_MILESTONES.find((m) => m.days === streakDays);
