import React from 'react';
import { Circle, Ellipse, G, Line, Path, Polygon, Rect } from 'react-native-svg';

import type { AssistantType, ItemCategory } from '@/types';

// ----------------------------------------------------------------------------
// Item registry — each item knows its slot and how to render itself as a set
// of SVG fragments inside the AvatarBase 100x125 viewBox. Equipment rows in
// the DB store the item.id string; the renderer is looked up here.
//
// New shop items added in Task 8 share IDs with src/data/shopItems.ts.
// ----------------------------------------------------------------------------

export interface AvatarItemCtx {
  assistantType: AssistantType;
}

export interface AvatarItem {
  id: string;
  slot: ItemCategory;
  nameKz: string;
  forAssistant?: AssistantType; // restrict to one character if set
  isDefault?: boolean; // school-uniform fallback for that slot
  render: (ctx: AvatarItemCtx) => React.ReactElement | null;
}

const SHIRT_WHITE = '#F8F8FB';
const OUTLINE = '#0E0B26';
const PANTS_NAVY = '#1F2D5C';
const TIE_RED = '#C8102E';
const BOW_PINK = '#FF6B9D';

// ----------------------------------------------------------------------------
// Reusable building blocks used by multiple items.
// ----------------------------------------------------------------------------

interface TorsoProps {
  fill: string;
  collarFill?: string;
  hood?: boolean;
  hoodFill?: string;
}

// Standard upper-body silhouette matching the body torso outline.
const TorsoShape: React.FC<TorsoProps> = ({ fill, collarFill, hood, hoodFill }) => (
  <G>
    {hood ? (
      <Path
        d="M 26 60 Q 26 50, 38 50 Q 50 47, 62 50 Q 74 50, 74 60 L 70 70 L 30 70 Z"
        fill={hoodFill ?? fill}
        stroke={OUTLINE}
        strokeWidth="1"
        strokeLinejoin="round"
      />
    ) : null}
    <Path
      d="M 28 76 Q 28 90, 30 102 L 30 115 L 70 115 L 70 102 Q 72 90, 72 76 L 60 70 L 50 78 L 40 70 Z"
      fill={fill}
      stroke={OUTLINE}
      strokeWidth="1"
      strokeLinejoin="round"
    />
    {collarFill ? (
      <Path
        d="M 40 70 L 50 78 L 60 70 L 56 70 L 50 74 L 44 70 Z"
        fill={collarFill}
        stroke={OUTLINE}
        strokeWidth="0.8"
        strokeLinejoin="round"
      />
    ) : null}
  </G>
);

interface PantsProps {
  fill: string;
  detail?: string;
}

const PantsShape: React.FC<PantsProps> = ({ fill, detail }) => (
  <G>
    <Path
      d="M 35 108 L 33 122 L 47 122 L 49 112 L 51 112 L 53 122 L 67 122 L 65 108 Z"
      fill={fill}
      stroke={OUTLINE}
      strokeWidth="1"
      strokeLinejoin="round"
    />
    {detail ? <Path d="M 50 112 L 50 122" stroke={detail} strokeWidth="0.6" /> : null}
  </G>
);

const SkirtShape: React.FC<{ fill: string; detail?: string }> = ({ fill, detail }) => (
  <G>
    <Path
      d="M 30 108 L 24 122 L 76 122 L 70 108 Z"
      fill={fill}
      stroke={OUTLINE}
      strokeWidth="1"
      strokeLinejoin="round"
    />
    {detail ? (
      <>
        <Path d="M 40 108 L 38 122" stroke={detail} strokeWidth="0.6" />
        <Path d="M 50 108 L 50 122" stroke={detail} strokeWidth="0.6" />
        <Path d="M 60 108 L 62 122" stroke={detail} strokeWidth="0.6" />
      </>
    ) : null}
  </G>
);

// ----------------------------------------------------------------------------
// DEFAULT UNIFORM (used by AvatarBase as fallback when nothing equipped)
// ----------------------------------------------------------------------------

const bekturTop: AvatarItem = {
  id: 'default_top_bektur',
  slot: 'top',
  nameKz: 'Мектеп көйлегі',
  forAssistant: 'bektur',
  isDefault: true,
  render: () => (
    <G>
      <TorsoShape fill={SHIRT_WHITE} collarFill={SHIRT_WHITE} />
      <Path
        d="M 48 78 L 52 78 L 53 89 L 50 95 L 47 89 Z"
        fill={TIE_RED}
        stroke={OUTLINE}
        strokeWidth="0.8"
        strokeLinejoin="round"
      />
    </G>
  ),
};

const nazymTop: AvatarItem = {
  id: 'default_top_nazym',
  slot: 'top',
  nameKz: 'Мектеп блузкасы',
  forAssistant: 'nazym',
  isDefault: true,
  render: () => (
    <G>
      <TorsoShape fill={SHIRT_WHITE} />
      <Path
        d="M 41 71 Q 50 80, 59 71"
        stroke={OUTLINE}
        strokeWidth="1"
        fill="none"
        strokeLinecap="round"
      />
      <Path
        d="M 44 80 L 50 84 L 56 80 L 56 86 L 50 84 L 44 86 Z"
        fill={BOW_PINK}
        stroke={OUTLINE}
        strokeWidth="0.7"
        strokeLinejoin="round"
      />
      <Circle cx="50" cy="84" r="1.4" fill="#C8336B" />
    </G>
  ),
};

const bekturBottom: AvatarItem = {
  id: 'default_bottom_bektur',
  slot: 'bottom',
  nameKz: 'Мектеп шалбары',
  forAssistant: 'bektur',
  isDefault: true,
  render: () => <PantsShape fill={PANTS_NAVY} />,
};

const nazymBottom: AvatarItem = {
  id: 'default_bottom_nazym',
  slot: 'bottom',
  nameKz: 'Мектеп юбкасы',
  forAssistant: 'nazym',
  isDefault: true,
  render: () => <SkirtShape fill={PANTS_NAVY} detail="#2A3A70" />,
};

// ----------------------------------------------------------------------------
// "NONE" stubs — equipping these in a slot clears its visual layer.
// ----------------------------------------------------------------------------
const noneItem = (id: string, slot: ItemCategory, nameKz: string): AvatarItem => ({
  id,
  slot,
  nameKz,
  isDefault: true,
  render: () => null,
});

// ----------------------------------------------------------------------------
// TOPS — shop items
// ----------------------------------------------------------------------------

const topSchoolJacket: AvatarItem = {
  id: 'top_school_jacket',
  slot: 'top',
  nameKz: 'Мектеп жакеті',
  isDefault: true,
  render: (ctx) => (ctx.assistantType === 'bektur' ? bekturTop.render(ctx) : nazymTop.render(ctx)),
};

const topTshirtWhite: AvatarItem = {
  id: 'top_tshirt_white',
  slot: 'top',
  nameKz: 'Ақ футболка',
  render: () => <TorsoShape fill="#FFFFFF" />,
};

const topTshirtBlue: AvatarItem = {
  id: 'top_tshirt_blue',
  slot: 'top',
  nameKz: 'Көк футболка',
  render: () => <TorsoShape fill="#4A6CF7" />,
};

const hoodieRender =
  (color: string): AvatarItem['render'] =>
  () => (
    <G>
      <TorsoShape fill={color} hood />
      <Line x1="50" y1="80" x2="50" y2="105" stroke={OUTLINE} strokeWidth="0.6" />
      <Path
        d="M 46 80 L 50 82 L 54 80"
        stroke="#FFFFFF"
        strokeWidth="0.8"
        fill="none"
        strokeLinecap="round"
      />
    </G>
  );

const topHoodieRed: AvatarItem = {
  id: 'top_hoodie_red',
  slot: 'top',
  nameKz: 'Қызыл худи',
  render: hoodieRender('#E63946'),
};
const topHoodieBlue: AvatarItem = {
  id: 'top_hoodie_blue',
  slot: 'top',
  nameKz: 'Көк худи',
  render: hoodieRender('#2A6FCB'),
};
const topHoodieGreen: AvatarItem = {
  id: 'top_hoodie_green',
  slot: 'top',
  nameKz: 'Жасыл худи',
  render: hoodieRender('#1F9E5C'),
};

const topSportSweatshirt: AvatarItem = {
  id: 'top_sport_sweatshirt',
  slot: 'top',
  nameKz: 'Спорт свитшот',
  render: () => (
    <G>
      <TorsoShape fill="#1A1A2E" />
      <Path d="M 30 86 L 70 86" stroke="#FFD700" strokeWidth="1.6" fill="none" />
      <Path d="M 44 92 L 56 92 L 54 100 L 46 100 Z" fill="#FFD700" />
    </G>
  ),
};

const topEthnicShirt: AvatarItem = {
  id: 'top_ethnic_shirt',
  slot: 'top',
  nameKz: 'Этно жейде',
  render: () => (
    <G>
      <TorsoShape fill="#F2E1B6" />
      <Path d="M 50 70 L 50 105" stroke="#C8102E" strokeWidth="1.2" />
      <Path
        d="M 46 80 L 54 80 M 46 90 L 54 90 M 46 100 L 54 100"
        stroke="#C8102E"
        strokeWidth="0.8"
      />
      <Circle cx="50" cy="84" r="1" fill="#C8102E" />
      <Circle cx="50" cy="94" r="1" fill="#C8102E" />
    </G>
  ),
};

const topLeatherJacket: AvatarItem = {
  id: 'top_leather_jacket',
  slot: 'top',
  nameKz: 'Кожаный жакет',
  render: () => (
    <G>
      <TorsoShape fill="#1A1A2E" />
      <Path d="M 50 78 L 50 110" stroke="#C0C0C0" strokeWidth="0.6" />
      <Path d="M 38 76 L 38 108" stroke="#3A3A50" strokeWidth="0.6" />
      <Path d="M 62 76 L 62 108" stroke="#3A3A50" strokeWidth="0.6" />
      <Circle cx="40" cy="82" r="1" fill="#C0C0C0" />
      <Circle cx="40" cy="92" r="1" fill="#C0C0C0" />
    </G>
  ),
};

const topChapan: AvatarItem = {
  id: 'top_chapan',
  slot: 'top',
  nameKz: 'Чапан',
  render: () => (
    <G>
      <Path
        d="M 26 72 Q 26 92, 28 110 L 28 118 L 72 118 L 72 110 Q 74 92, 74 72 L 60 68 L 50 76 L 40 68 Z"
        fill="#7A1F3C"
        stroke={OUTLINE}
        strokeWidth="1"
        strokeLinejoin="round"
      />
      <Path d="M 50 76 L 50 118" stroke="#FFD700" strokeWidth="1.2" />
      <Path d="M 30 84 L 70 84" stroke="#FFD700" strokeWidth="0.6" />
      <Path d="M 30 100 L 70 100" stroke="#FFD700" strokeWidth="0.6" />
      <Path d="M 42 90 L 50 86 L 58 90 L 50 94 Z" fill="#FFD700" opacity="0.85" />
    </G>
  ),
};

const topWinterCoat: AvatarItem = {
  id: 'top_winter_coat',
  slot: 'top',
  nameKz: 'Қысқы пальто',
  render: () => (
    <G>
      <Path
        d="M 24 72 Q 24 96, 28 114 L 28 120 L 72 120 L 72 114 Q 76 96, 76 72 L 60 68 L 50 78 L 40 68 Z"
        fill="#3D2B1F"
        stroke={OUTLINE}
        strokeWidth="1"
        strokeLinejoin="round"
      />
      <Path d="M 30 74 Q 50 70, 70 74" stroke="#F8F8FB" strokeWidth="2.5" fill="none" />
      <Path d="M 50 80 L 50 118" stroke="#1A1A2E" strokeWidth="0.6" />
      <Circle cx="50" cy="90" r="1.2" fill="#1A1A2E" />
      <Circle cx="50" cy="100" r="1.2" fill="#1A1A2E" />
      <Circle cx="50" cy="110" r="1.2" fill="#1A1A2E" />
    </G>
  ),
};

const topWarriorUniform: AvatarItem = {
  id: 'top_warrior_uniform',
  slot: 'top',
  nameKz: 'Жауынгер мундирі',
  render: () => (
    <G>
      <TorsoShape fill="#2A4A6B" />
      <Path d="M 30 80 L 70 80" stroke="#FFD700" strokeWidth="1.6" />
      <Path d="M 30 90 L 70 90" stroke="#FFD700" strokeWidth="0.8" />
      <Polygon points="46,96 50,92 54,96 50,100" fill="#FFD700" />
      <Path d="M 35 78 L 40 78" stroke="#FFD700" strokeWidth="2" />
      <Path d="M 60 78 L 65 78" stroke="#FFD700" strokeWidth="2" />
    </G>
  ),
};

const topAstronaut: AvatarItem = {
  id: 'top_astronaut',
  slot: 'top',
  nameKz: 'Астронавт костюмі',
  render: () => (
    <G>
      <TorsoShape fill="#EFEFF5" />
      <Path d="M 30 86 L 70 86" stroke="#4A6CF7" strokeWidth="1" />
      <Rect x="40" y="90" width="20" height="10" rx="2" fill="#1A1A2E" />
      <Circle cx="44" cy="95" r="1" fill="#00C48C" />
      <Circle cx="50" cy="95" r="1" fill="#FFD700" />
      <Circle cx="56" cy="95" r="1" fill="#FF4757" />
      <Path d="M 32 76 Q 50 72, 68 76" stroke="#4A6CF7" strokeWidth="0.8" fill="none" />
    </G>
  ),
};

const topRobotArmor: AvatarItem = {
  id: 'top_robot_armor',
  slot: 'top',
  nameKz: 'Робот сауыт',
  render: () => (
    <G>
      <TorsoShape fill="#7A8FA8" />
      <Path d="M 30 76 L 30 105 L 70 105 L 70 76" stroke="#3A4A60" strokeWidth="0.6" fill="none" />
      <Circle cx="50" cy="88" r="4" fill="#00C48C" stroke={OUTLINE} strokeWidth="0.8" />
      <Circle cx="50" cy="88" r="1.5" fill="#FFFFFF" />
      <Rect x="38" y="98" width="6" height="3" fill="#3A4A60" />
      <Rect x="56" y="98" width="6" height="3" fill="#3A4A60" />
      <Path d="M 28 80 L 28 100" stroke="#FFD700" strokeWidth="0.6" />
      <Path d="M 72 80 L 72 100" stroke="#FFD700" strokeWidth="0.6" />
    </G>
  ),
};

const topDragonArmor: AvatarItem = {
  id: 'top_dragon_armor',
  slot: 'top',
  nameKz: 'Айдаhар сауыты',
  render: () => (
    <G>
      <TorsoShape fill="#4A1F3C" />
      <Path
        d="M 36 80 L 40 84 L 36 88 Z M 44 84 L 48 88 L 44 92 Z M 52 80 L 56 84 L 52 88 Z M 60 84 L 64 88 L 60 92 Z"
        fill="#7B61FF"
      />
      <Path d="M 30 96 L 70 96" stroke="#FFD700" strokeWidth="1.2" />
      <Polygon
        points="44,100 50,94 56,100 50,108"
        fill="#FFD700"
        stroke={OUTLINE}
        strokeWidth="0.6"
      />
      <Circle cx="50" cy="100" r="1.4" fill="#FF4757" />
    </G>
  ),
};

// ----------------------------------------------------------------------------
// BOTTOMS — shop items
// ----------------------------------------------------------------------------
const bottomSchoolPants: AvatarItem = {
  id: 'bottom_school_pants',
  slot: 'bottom',
  nameKz: 'Мектеп шалбары',
  isDefault: true,
  render: (ctx) =>
    ctx.assistantType === 'bektur' ? bekturBottom.render(ctx) : nazymBottom.render(ctx),
};

const bottomShorts: AvatarItem = {
  id: 'bottom_shorts',
  slot: 'bottom',
  nameKz: 'Шорт',
  render: () => (
    <Path
      d="M 35 108 L 34 117 L 47 117 L 49 112 L 51 112 L 53 117 L 66 117 L 65 108 Z"
      fill="#4A6CF7"
      stroke={OUTLINE}
      strokeWidth="1"
      strokeLinejoin="round"
    />
  ),
};

const bottomJeans: AvatarItem = {
  id: 'bottom_jeans',
  slot: 'bottom',
  nameKz: 'Джинс',
  render: () => <PantsShape fill="#2F4F8A" detail="#D4A95C" />,
};

const bottomSportPants: AvatarItem = {
  id: 'bottom_sport_pants',
  slot: 'bottom',
  nameKz: 'Спорт шалбар',
  render: () => (
    <G>
      <PantsShape fill="#1A1A2E" />
      <Path d="M 38 110 L 36 120" stroke="#FFD700" strokeWidth="0.8" />
      <Path d="M 62 110 L 64 120" stroke="#FFD700" strokeWidth="0.8" />
    </G>
  ),
};

const bottomDarkJeans: AvatarItem = {
  id: 'bottom_dark_jeans',
  slot: 'bottom',
  nameKz: 'Қара джинс',
  render: () => <PantsShape fill="#15161E" detail="#C0C0C0" />,
};

const bottomTraditional: AvatarItem = {
  id: 'bottom_traditional',
  slot: 'bottom',
  nameKz: 'Дәстүрлі шалбар',
  render: () => (
    <G>
      <PantsShape fill="#7A1F3C" />
      <Path d="M 38 112 L 46 120 M 54 120 L 62 112" stroke="#FFD700" strokeWidth="0.8" />
      <Path d="M 40 115 L 42 117 M 58 115 L 60 117" stroke="#FFD700" strokeWidth="0.6" />
    </G>
  ),
};

const bottomLeatherPants: AvatarItem = {
  id: 'bottom_leather_pants',
  slot: 'bottom',
  nameKz: 'Кожаный шалбар',
  render: () => (
    <G>
      <PantsShape fill="#15161E" />
      <Path d="M 40 110 L 40 122" stroke="#3A3A50" strokeWidth="0.5" />
      <Path d="M 60 110 L 60 122" stroke="#3A3A50" strokeWidth="0.5" />
    </G>
  ),
};

const bottomArmorPants: AvatarItem = {
  id: 'bottom_armor_pants',
  slot: 'bottom',
  nameKz: 'Сауыт шалбары',
  render: () => (
    <G>
      <PantsShape fill="#7A8FA8" />
      <Rect x="38" y="112" width="10" height="3" fill="#3A4A60" />
      <Rect x="52" y="112" width="10" height="3" fill="#3A4A60" />
      <Rect x="38" y="117" width="10" height="3" fill="#3A4A60" />
      <Rect x="52" y="117" width="10" height="3" fill="#3A4A60" />
    </G>
  ),
};

// ----------------------------------------------------------------------------
// HATS — shop items
// ----------------------------------------------------------------------------
const hatNone = noneItem('hat_none', 'hat', 'Жоқ');

const hatBaseballCap: AvatarItem = {
  id: 'hat_baseball_cap',
  slot: 'hat',
  nameKz: 'Бейсболка',
  render: () => (
    <G>
      <Path
        d="M 24 28 Q 24 14, 50 14 Q 76 14, 76 28 L 76 30 L 24 30 Z"
        fill="#4A6CF7"
        stroke={OUTLINE}
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <Path
        d="M 76 28 Q 88 28, 90 32 L 76 33 Z"
        fill="#4A6CF7"
        stroke={OUTLINE}
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <Path d="M 46 22 L 54 22 L 50 16 Z" fill="#FFFFFF" />
    </G>
  ),
};

const hatWinter: AvatarItem = {
  id: 'hat_winter',
  slot: 'hat',
  nameKz: 'Қыс шапка',
  render: () => (
    <G>
      <Path
        d="M 24 26 Q 24 8, 50 8 Q 76 8, 76 26 L 76 32 L 24 32 Z"
        fill="#7A1F3C"
        stroke={OUTLINE}
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <Path
        d="M 24 30 L 76 30 L 76 34 L 24 34 Z"
        fill="#F8F8FB"
        stroke={OUTLINE}
        strokeWidth="0.8"
      />
      <Circle cx="50" cy="8" r="4" fill="#F8F8FB" stroke={OUTLINE} strokeWidth="0.6" />
    </G>
  ),
};

const hatTakiya: AvatarItem = {
  id: 'hat_takiya',
  slot: 'hat',
  nameKz: 'Такия',
  render: () => (
    <G>
      <Path
        d="M 30 28 Q 30 14, 50 14 Q 70 14, 70 28 L 70 32 L 30 32 Z"
        fill="#1A1A4E"
        stroke={OUTLINE}
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <Path d="M 38 24 L 50 18 L 62 24" stroke="#FFD700" strokeWidth="0.8" fill="none" />
      <Path d="M 38 28 L 50 22 L 62 28" stroke="#FFD700" strokeWidth="0.8" fill="none" />
      <Circle cx="50" cy="14" r="2" fill="#FFD700" />
    </G>
  ),
};

const hatGrab: AvatarItem = {
  id: 'hat_grab',
  slot: 'hat',
  nameKz: 'Граб-шляпа',
  render: () => (
    <G>
      <Path
        d="M 18 30 Q 50 26, 82 30 L 82 34 L 18 34 Z"
        fill="#1A1A2E"
        stroke={OUTLINE}
        strokeWidth="1"
        strokeLinejoin="round"
      />
      <Path
        d="M 30 30 Q 30 12, 50 10 Q 70 12, 70 30 Z"
        fill="#1A1A2E"
        stroke={OUTLINE}
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <Path d="M 30 26 L 70 26" stroke="#C8102E" strokeWidth="1.6" />
    </G>
  ),
};

const hatBorik: AvatarItem = {
  id: 'hat_borik',
  slot: 'hat',
  nameKz: 'Бөрік',
  render: () => (
    <G>
      <Path
        d="M 24 30 Q 24 6, 50 6 Q 76 6, 76 30 L 76 34 L 24 34 Z"
        fill="#3D2B1F"
        stroke={OUTLINE}
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <Path d="M 28 30 Q 50 24, 72 30" stroke="#5A3F2B" strokeWidth="1" fill="none" />
      <Path d="M 32 22 Q 50 18, 68 22" stroke="#5A3F2B" strokeWidth="0.8" fill="none" />
      <Path
        d="M 46 10 L 50 6 L 54 10 L 50 14 Z"
        fill="#FFD700"
        stroke={OUTLINE}
        strokeWidth="0.6"
      />
    </G>
  ),
};

const hatCrown: AvatarItem = {
  id: 'hat_crown',
  slot: 'hat',
  nameKz: 'Патша тәжі',
  render: () => (
    <G>
      <Path
        d="M 26 28 L 30 14 L 38 22 L 44 10 L 50 22 L 56 10 L 62 22 L 70 14 L 74 28 Z"
        fill="#FFD700"
        stroke={OUTLINE}
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <Path
        d="M 26 28 L 74 28 L 74 32 L 26 32 Z"
        fill="#FFD700"
        stroke={OUTLINE}
        strokeWidth="1.2"
      />
      <Circle cx="50" cy="22" r="2" fill="#FF4757" stroke={OUTLINE} strokeWidth="0.6" />
      <Circle cx="38" cy="24" r="1.4" fill="#4A6CF7" />
      <Circle cx="62" cy="24" r="1.4" fill="#4A6CF7" />
    </G>
  ),
};

const hatSpaceHelmet: AvatarItem = {
  id: 'hat_space_helmet',
  slot: 'hat',
  nameKz: 'Ғарышкер дулыға',
  render: () => (
    <G>
      <Circle
        cx="50"
        cy="38"
        r="28"
        fill="#EFEFF5"
        opacity="0.4"
        stroke={OUTLINE}
        strokeWidth="1.2"
      />
      <Path
        d="M 24 36 Q 24 10, 50 10 Q 76 10, 76 36"
        fill="#7A8FA8"
        stroke={OUTLINE}
        strokeWidth="1.2"
      />
      <Path d="M 30 30 Q 50 26, 70 30" stroke="#4A6CF7" strokeWidth="1" fill="none" />
      <Path d="M 36 24 L 64 24" stroke="#FFD700" strokeWidth="0.8" />
      <Circle cx="42" cy="20" r="1.2" fill="#FF4757" />
    </G>
  ),
};

// ----------------------------------------------------------------------------
// ACCESSORIES — shop items
// ----------------------------------------------------------------------------
const accNone = noneItem('acc_none', 'accessory', 'Жоқ');

const accBook: AvatarItem = {
  id: 'acc_book',
  slot: 'accessory',
  nameKz: 'Кітап',
  render: () => (
    <G>
      <Rect
        x="18"
        y="100"
        width="14"
        height="10"
        rx="1"
        fill="#C8102E"
        stroke={OUTLINE}
        strokeWidth="0.8"
      />
      <Path d="M 25 100 L 25 110" stroke="#FFFFFF" strokeWidth="0.6" />
      <Path d="M 21 105 L 29 105" stroke="#FFD700" strokeWidth="0.5" />
    </G>
  ),
};

const accBracelet: AvatarItem = {
  id: 'acc_bracelet',
  slot: 'accessory',
  nameKz: 'Білезік',
  render: () => (
    <G>
      <Circle cx="26" cy="107" r="5" fill="none" stroke="#4A6CF7" strokeWidth="1.2" />
      <Circle cx="22" cy="107" r="1" fill="#4A6CF7" />
      <Circle cx="30" cy="107" r="1" fill="#4A6CF7" />
      <Circle cx="26" cy="103" r="1" fill="#4A6CF7" />
    </G>
  ),
};

const accGoldChain: AvatarItem = {
  id: 'acc_gold_chain',
  slot: 'accessory',
  nameKz: 'Алтын тізбек',
  render: () => (
    <G>
      <Path d="M 38 72 Q 50 80, 62 72" stroke="#FFD700" strokeWidth="1.6" fill="none" />
      <Path
        d="M 50 80 L 50 86 L 47 90 L 53 90 Z"
        fill="#FFD700"
        stroke={OUTLINE}
        strokeWidth="0.6"
      />
    </G>
  ),
};

const accBackpack: AvatarItem = {
  id: 'acc_backpack',
  slot: 'accessory',
  nameKz: 'Рюкзак',
  render: () => (
    <G>
      <Path
        d="M 32 76 Q 24 78, 22 88 L 22 108 Q 22 112, 26 112 L 30 112 L 30 76 Z"
        fill="#4A6CF7"
        stroke={OUTLINE}
        strokeWidth="0.8"
        strokeLinejoin="round"
        opacity="0.85"
      />
      <Rect x="24" y="92" width="6" height="6" rx="1" fill="#FFD700" />
    </G>
  ),
};

const accVrGlasses: AvatarItem = {
  id: 'acc_vr_glasses',
  slot: 'accessory',
  nameKz: 'VR очки',
  render: () => (
    <G>
      <Rect
        x="30"
        y="38"
        width="40"
        height="10"
        rx="3"
        fill="#1A1A2E"
        stroke={OUTLINE}
        strokeWidth="0.8"
      />
      <Rect x="33" y="40" width="14" height="6" rx="1" fill="#4A6CF7" />
      <Rect x="53" y="40" width="14" height="6" rx="1" fill="#4A6CF7" />
      <Path d="M 25 42 L 30 42 M 70 42 L 75 42" stroke="#1A1A2E" strokeWidth="1.2" />
    </G>
  ),
};

const accGoldMedal: AvatarItem = {
  id: 'acc_gold_medal',
  slot: 'accessory',
  nameKz: 'Алтын медаль',
  render: () => (
    <G>
      <Path d="M 44 70 L 50 86 L 56 70" stroke="#C8102E" strokeWidth="1.2" fill="none" />
      <Circle cx="50" cy="92" r="6" fill="#FFD700" stroke={OUTLINE} strokeWidth="0.8" />
      <Path
        d="M 50 88 L 51.4 91.2 L 55 91.5 L 52 93.8 L 53 97 L 50 95 L 47 97 L 48 93.8 L 45 91.5 L 48.6 91.2 Z"
        fill="#C8102E"
      />
    </G>
  ),
};

const accWings: AvatarItem = {
  id: 'acc_wings',
  slot: 'accessory',
  nameKz: 'Қанат',
  render: () => (
    <G>
      <Path
        d="M 28 78 Q 12 80, 8 100 Q 18 96, 30 92 Z"
        fill="#FFD700"
        stroke={OUTLINE}
        strokeWidth="0.8"
        strokeLinejoin="round"
        opacity="0.9"
      />
      <Path
        d="M 72 78 Q 88 80, 92 100 Q 82 96, 70 92 Z"
        fill="#FFD700"
        stroke={OUTLINE}
        strokeWidth="0.8"
        strokeLinejoin="round"
        opacity="0.9"
      />
      <Path d="M 12 88 L 22 90 M 14 94 L 26 94" stroke="#FFFFFF" strokeWidth="0.5" opacity="0.7" />
      <Path d="M 88 88 L 78 90 M 86 94 L 74 94" stroke="#FFFFFF" strokeWidth="0.5" opacity="0.7" />
    </G>
  ),
};

// ----------------------------------------------------------------------------
// PETS — shop items
// ----------------------------------------------------------------------------
const petNone = noneItem('pet_none', 'pet', 'Жоқ');

const PetShadow: React.FC = () => (
  <Ellipse cx="84" cy="120" rx="9" ry="4" fill="#000" opacity="0.18" />
);

const petFish: AvatarItem = {
  id: 'pet_fish',
  slot: 'pet',
  nameKz: 'Балық',
  render: () => (
    <G>
      <PetShadow />
      <Path
        d="M 76 116 Q 82 110, 90 116 Q 82 122, 76 116 Z"
        fill="#FFD700"
        stroke={OUTLINE}
        strokeWidth="0.8"
      />
      <Path d="M 90 116 L 95 112 L 95 120 Z" fill="#FFD700" stroke={OUTLINE} strokeWidth="0.6" />
      <Circle cx="80" cy="115" r="0.8" fill={OUTLINE} />
    </G>
  ),
};

const petButterfly: AvatarItem = {
  id: 'pet_butterfly',
  slot: 'pet',
  nameKz: 'Шапалақ',
  render: () => (
    <G>
      <Circle cx="84" cy="80" r="1.5" fill={OUTLINE} />
      <Path
        d="M 84 80 Q 76 74, 76 82 Q 78 86, 84 82 Z"
        fill="#4A6CF7"
        stroke={OUTLINE}
        strokeWidth="0.6"
      />
      <Path
        d="M 84 80 Q 92 74, 92 82 Q 90 86, 84 82 Z"
        fill="#FFD700"
        stroke={OUTLINE}
        strokeWidth="0.6"
      />
      <Path
        d="M 84 80 Q 78 84, 78 90 Q 82 88, 84 84 Z"
        fill="#7B61FF"
        stroke={OUTLINE}
        strokeWidth="0.6"
      />
      <Path
        d="M 84 80 Q 90 84, 90 90 Q 86 88, 84 84 Z"
        fill="#FF6B9D"
        stroke={OUTLINE}
        strokeWidth="0.6"
      />
    </G>
  ),
};

const catRender =
  (color: string): AvatarItem['render'] =>
  () => (
    <G>
      <PetShadow />
      <Path
        d="M 78 114 Q 78 106, 84 106 Q 90 106, 90 114 L 90 120 L 78 120 Z"
        fill={color}
        stroke={OUTLINE}
        strokeWidth="0.8"
        strokeLinejoin="round"
      />
      <Path d="M 79 106 L 81 102 L 82 106 Z" fill={color} stroke={OUTLINE} strokeWidth="0.6" />
      <Path d="M 86 106 L 87 102 L 89 106 Z" fill={color} stroke={OUTLINE} strokeWidth="0.6" />
      <Circle cx="82" cy="112" r="0.7" fill={OUTLINE} />
      <Circle cx="87" cy="112" r="0.7" fill={OUTLINE} />
      <Path d="M 83 114 Q 84 115, 85 114" stroke={OUTLINE} strokeWidth="0.5" fill="none" />
    </G>
  );

const petWhiteCat: AvatarItem = {
  id: 'pet_white_cat',
  slot: 'pet',
  nameKz: 'Ақ мысық',
  render: catRender('#F8F8FB'),
};

const petBlackCat: AvatarItem = {
  id: 'pet_black_cat',
  slot: 'pet',
  nameKz: 'Қара мысық',
  render: catRender('#1A1A2E'),
};

const petWolfPup: AvatarItem = {
  id: 'pet_wolf_pup',
  slot: 'pet',
  nameKz: 'Қасқыр күшігі',
  render: () => (
    <G>
      <PetShadow />
      <Path
        d="M 76 114 Q 76 104, 84 104 Q 92 104, 92 114 L 92 120 L 76 120 Z"
        fill="#7A8FA8"
        stroke={OUTLINE}
        strokeWidth="0.8"
        strokeLinejoin="round"
      />
      <Path d="M 77 104 L 79 99 L 81 105 Z" fill="#7A8FA8" stroke={OUTLINE} strokeWidth="0.6" />
      <Path d="M 87 104 L 89 99 L 91 105 Z" fill="#7A8FA8" stroke={OUTLINE} strokeWidth="0.6" />
      <Circle cx="81" cy="111" r="0.7" fill="#FFD700" />
      <Circle cx="87" cy="111" r="0.7" fill="#FFD700" />
      <Path d="M 83 114 L 84 116 L 85 114" stroke={OUTLINE} strokeWidth="0.6" fill="none" />
      <Path d="M 92 118 Q 96 116, 94 112" stroke="#7A8FA8" strokeWidth="1.4" fill="none" />
    </G>
  ),
};

const petRobotFriend: AvatarItem = {
  id: 'pet_robot_friend',
  slot: 'pet',
  nameKz: 'Робот достас',
  render: () => (
    <G>
      <PetShadow />
      <Rect
        x="76"
        y="104"
        width="16"
        height="16"
        rx="2"
        fill="#7A8FA8"
        stroke={OUTLINE}
        strokeWidth="0.8"
      />
      <Rect x="80" y="108" width="3" height="3" fill="#00C48C" />
      <Rect x="85" y="108" width="3" height="3" fill="#00C48C" />
      <Path d="M 80 115 L 88 115" stroke={OUTLINE} strokeWidth="0.6" />
      <Path d="M 82 104 L 82 100 M 86 104 L 86 100" stroke={OUTLINE} strokeWidth="0.6" />
      <Circle cx="82" cy="100" r="1" fill="#FFD700" />
      <Circle cx="86" cy="100" r="1" fill="#FF4757" />
    </G>
  ),
};

const petEagle: AvatarItem = {
  id: 'pet_eagle',
  slot: 'pet',
  nameKz: 'Бүркіт',
  render: () => (
    <G>
      <PetShadow />
      <Path
        d="M 76 116 Q 76 106, 84 104 Q 92 106, 92 116 L 90 120 L 78 120 Z"
        fill="#3D2B1F"
        stroke={OUTLINE}
        strokeWidth="0.8"
        strokeLinejoin="round"
      />
      <Path d="M 84 104 Q 86 100, 90 104" fill="#F8F8FB" stroke={OUTLINE} strokeWidth="0.6" />
      <Path d="M 82 105 L 80 102 L 80 108 Z" fill="#FFD700" stroke={OUTLINE} strokeWidth="0.5" />
      <Circle cx="83" cy="106" r="0.6" fill="#FFD700" />
      <Path d="M 76 110 L 70 108 L 76 114 Z" fill="#3D2B1F" stroke={OUTLINE} strokeWidth="0.6" />
    </G>
  ),
};

const petSnowLeopard: AvatarItem = {
  id: 'pet_snow_leopard',
  slot: 'pet',
  nameKz: 'Барс балапаны',
  render: () => (
    <G>
      <PetShadow />
      <Path
        d="M 76 114 Q 76 104, 84 104 Q 92 104, 92 114 L 92 120 L 76 120 Z"
        fill="#EFEFF5"
        stroke={OUTLINE}
        strokeWidth="0.8"
        strokeLinejoin="round"
      />
      <Path d="M 77 104 L 79 99 L 81 105 Z" fill="#EFEFF5" stroke={OUTLINE} strokeWidth="0.6" />
      <Path d="M 87 104 L 89 99 L 91 105 Z" fill="#EFEFF5" stroke={OUTLINE} strokeWidth="0.6" />
      <Circle cx="80" cy="110" r="0.6" fill="#1A1A2E" />
      <Circle cx="86" cy="113" r="0.5" fill="#1A1A2E" />
      <Circle cx="89" cy="108" r="0.5" fill="#1A1A2E" />
      <Circle cx="82" cy="116" r="0.5" fill="#1A1A2E" />
      <Circle cx="81" cy="111" r="0.7" fill={OUTLINE} />
      <Circle cx="87" cy="111" r="0.7" fill={OUTLINE} />
    </G>
  ),
};

const petDragonChick: AvatarItem = {
  id: 'pet_dragon_chick',
  slot: 'pet',
  nameKz: 'Айдаhар балапаны',
  render: () => (
    <G>
      <PetShadow />
      <Path
        d="M 76 114 Q 76 104, 84 102 Q 92 104, 92 114 L 90 120 L 78 120 Z"
        fill="#7B61FF"
        stroke={OUTLINE}
        strokeWidth="0.8"
        strokeLinejoin="round"
      />
      <Path
        d="M 78 100 L 80 96 L 82 100 Z M 86 100 L 88 96 L 90 100 Z"
        fill="#7B61FF"
        stroke={OUTLINE}
        strokeWidth="0.6"
      />
      <Path
        d="M 76 110 Q 70 106, 68 112 Q 74 112, 76 114 Z"
        fill="#7B61FF"
        stroke={OUTLINE}
        strokeWidth="0.6"
      />
      <Circle cx="81" cy="108" r="0.7" fill="#FFD700" />
      <Circle cx="87" cy="108" r="0.7" fill="#FFD700" />
      <Path d="M 82 114 Q 84 116, 86 114" stroke="#FF4757" strokeWidth="0.6" fill="none" />
      <Path d="M 84 102 L 84 99" stroke="#FFD700" strokeWidth="0.6" />
    </G>
  ),
};

const petPhoenix: AvatarItem = {
  id: 'pet_phoenix',
  slot: 'pet',
  nameKz: 'Феникс балапаны',
  render: () => (
    <G>
      <PetShadow />
      <Path
        d="M 76 114 Q 76 102, 84 100 Q 92 102, 92 114 L 90 120 L 78 120 Z"
        fill="#FF4757"
        stroke={OUTLINE}
        strokeWidth="0.8"
        strokeLinejoin="round"
      />
      <Path
        d="M 84 100 L 80 92 L 84 96 L 88 92 Z"
        fill="#FFD700"
        stroke={OUTLINE}
        strokeWidth="0.6"
      />
      <Path d="M 76 108 L 68 104 L 74 110 Z" fill="#FFA502" stroke={OUTLINE} strokeWidth="0.6" />
      <Path d="M 92 108 L 100 104 L 94 110 Z" fill="#FFA502" stroke={OUTLINE} strokeWidth="0.6" />
      <Circle cx="81" cy="108" r="0.7" fill="#1A1A2E" />
      <Circle cx="87" cy="108" r="0.7" fill="#1A1A2E" />
      <Path d="M 82 113 L 84 115 L 86 113" stroke="#FFD700" strokeWidth="0.6" fill="none" />
    </G>
  ),
};

// ----------------------------------------------------------------------------
// Legacy items kept for backwards compatibility with previously seeded data.
// ----------------------------------------------------------------------------
const capRed: AvatarItem = {
  id: 'cap_red',
  slot: 'hat',
  nameKz: 'Қызыл кепка',
  render: () => (
    <G>
      <Path
        d="M 24 28 Q 24 14, 50 14 Q 76 14, 76 28 L 76 30 L 24 30 Z"
        fill="#E63946"
        stroke={OUTLINE}
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <Path
        d="M 76 28 Q 88 28, 90 32 L 76 33 Z"
        fill="#E63946"
        stroke={OUTLINE}
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <Circle cx="50" cy="22" r="2" fill="#FFFFFF" />
    </G>
  ),
};

const eagleScarf: AvatarItem = {
  id: 'scarf_kk',
  slot: 'accessory',
  nameKz: 'Көк бөрік',
  render: () => (
    <G>
      <Path
        d="M 38 72 Q 50 78, 62 72 L 60 80 Q 50 82, 40 80 Z"
        fill="#2A6FCB"
        stroke={OUTLINE}
        strokeWidth="1"
        strokeLinejoin="round"
      />
    </G>
  ),
};

const petCat: AvatarItem = {
  id: 'pet_cat',
  slot: 'pet',
  nameKz: 'Мысық',
  render: catRender('#F0A95C'),
};

// ----------------------------------------------------------------------------
// Registry
// ----------------------------------------------------------------------------
const ALL_ITEMS: readonly AvatarItem[] = [
  // Defaults
  bekturTop,
  nazymTop,
  bekturBottom,
  nazymBottom,
  // Shop tops
  topSchoolJacket,
  topTshirtWhite,
  topTshirtBlue,
  topHoodieRed,
  topHoodieBlue,
  topHoodieGreen,
  topSportSweatshirt,
  topEthnicShirt,
  topLeatherJacket,
  topChapan,
  topWinterCoat,
  topWarriorUniform,
  topAstronaut,
  topRobotArmor,
  topDragonArmor,
  // Shop bottoms
  bottomSchoolPants,
  bottomShorts,
  bottomJeans,
  bottomSportPants,
  bottomDarkJeans,
  bottomTraditional,
  bottomLeatherPants,
  bottomArmorPants,
  // Shop hats
  hatNone,
  hatBaseballCap,
  hatWinter,
  hatTakiya,
  hatGrab,
  hatBorik,
  hatCrown,
  hatSpaceHelmet,
  // Shop accessories
  accNone,
  accBook,
  accBracelet,
  accGoldChain,
  accBackpack,
  accVrGlasses,
  accGoldMedal,
  accWings,
  // Shop pets
  petNone,
  petFish,
  petButterfly,
  petWhiteCat,
  petBlackCat,
  petWolfPup,
  petRobotFriend,
  petEagle,
  petSnowLeopard,
  petDragonChick,
  petPhoenix,
  // Legacy
  capRed,
  eagleScarf,
  petCat,
];

const itemMap = new Map<string, AvatarItem>(ALL_ITEMS.map((i) => [i.id, i]));

export const getAvatarItem = (id: string | undefined | null): AvatarItem | undefined =>
  id ? itemMap.get(id) : undefined;

export const defaultItemFor = (slot: ItemCategory, assistant: AssistantType): string | null => {
  // Prefer assistant-specific defaults (e.g. bektur tie vs. nazym bow).
  for (const item of ALL_ITEMS) {
    if (item.isDefault && item.slot === slot && item.forAssistant === assistant) {
      return item.id;
    }
  }
  for (const item of ALL_ITEMS) {
    if (item.isDefault && item.slot === slot && !item.forAssistant) {
      return item.id;
    }
  }
  return null;
};

export const allItems = (): readonly AvatarItem[] => ALL_ITEMS;
