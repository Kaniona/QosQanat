// ----------------------------------------------------------------------------
// Achievements (30 total) across 6 categories.
//
// Each achievement is unlocked when a `metric` reaches `threshold`. Metrics are
// read from the user/game state by the achievement engine — see
// evaluateAchievements() at the bottom of this file.
// ----------------------------------------------------------------------------

export type AchievementCategory =
  | 'learning'
  | 'battle'
  | 'collection'
  | 'friends'
  | 'streak'
  | 'special';

export type AchievementMetric =
  | 'tasks_completed'
  | 'perfect_tasks'
  | 'lessons_completed'
  | 'quizzes_completed'
  | 'bosses_defeated'
  | 'level'
  | 'xp_total'
  | 'battles_played'
  | 'battles_won'
  | 'battles_perfect'
  | 'items_owned'
  | 'coins_spent'
  | 'akyl_points'
  | 'friends_count'
  | 'battles_vs_friends'
  | 'current_streak'
  | 'days_active';

export interface Achievement {
  id: string;
  category: AchievementCategory;
  titleKz: string;
  descriptionKz: string;
  icon: string; // emoji
  rewardCoins: number;
  metric: AchievementMetric;
  threshold: number;
}

export const ACHIEVEMENTS: readonly Achievement[] = [
  // ---------- Learning (7) ----------
  {
    id: 'A_LEARN_01',
    category: 'learning',
    titleKz: 'Алғашқы қадам',
    descriptionKz: 'Алғашқы тапсырманы аяқта',
    icon: '🌱',
    rewardCoins: 20,
    metric: 'tasks_completed',
    threshold: 1,
  },
  {
    id: 'A_LEARN_02',
    category: 'learning',
    titleKz: 'Ынталы оқушы',
    descriptionKz: '10 тапсырманы аяқта',
    icon: '📚',
    rewardCoins: 50,
    metric: 'tasks_completed',
    threshold: 10,
  },
  {
    id: 'A_LEARN_03',
    category: 'learning',
    titleKz: 'Жүзжылдықшы',
    descriptionKz: '100 тапсырманы аяқта',
    icon: '🏅',
    rewardCoins: 300,
    metric: 'tasks_completed',
    threshold: 100,
  },
  {
    id: 'A_LEARN_04',
    category: 'learning',
    titleKz: 'Мінсіз оқушы',
    descriptionKz: '5 тапсырманы мінсіз орында',
    icon: '💯',
    rewardCoins: 75,
    metric: 'perfect_tasks',
    threshold: 5,
  },
  {
    id: 'A_LEARN_05',
    category: 'learning',
    titleKz: 'Сабақ шебері',
    descriptionKz: '25 сабақты бітір',
    icon: '🎒',
    rewardCoins: 100,
    metric: 'lessons_completed',
    threshold: 25,
  },
  {
    id: 'A_LEARN_06',
    category: 'learning',
    titleKz: 'Тест маманы',
    descriptionKz: '20 тестті бітір',
    icon: '🧠',
    rewardCoins: 120,
    metric: 'quizzes_completed',
    threshold: 20,
  },
  {
    id: 'A_LEARN_07',
    category: 'learning',
    titleKz: 'Айдаһарды жеңуші',
    descriptionKz: '5 «Боссты» жең',
    icon: '🐉',
    rewardCoins: 250,
    metric: 'bosses_defeated',
    threshold: 5,
  },

  // ---------- Battle (6) ----------
  {
    id: 'A_BATTLE_01',
    category: 'battle',
    titleKz: 'Сыналған сарбаз',
    descriptionKz: 'Бірінші шайқасты ойна',
    icon: '⚔️',
    rewardCoins: 25,
    metric: 'battles_played',
    threshold: 1,
  },
  {
    id: 'A_BATTLE_02',
    category: 'battle',
    titleKz: 'Алғашқы жеңіс',
    descriptionKz: 'Бірінші шайқаста жең',
    icon: '🥇',
    rewardCoins: 40,
    metric: 'battles_won',
    threshold: 1,
  },
  {
    id: 'A_BATTLE_03',
    category: 'battle',
    titleKz: 'Жауынгер',
    descriptionKz: '10 шайқаста жең',
    icon: '🛡️',
    rewardCoins: 150,
    metric: 'battles_won',
    threshold: 10,
  },
  {
    id: 'A_BATTLE_04',
    category: 'battle',
    titleKz: 'Аңыз жауынгер',
    descriptionKz: '50 шайқаста жең',
    icon: '⚜️',
    rewardCoins: 600,
    metric: 'battles_won',
    threshold: 50,
  },
  {
    id: 'A_BATTLE_05',
    category: 'battle',
    titleKz: 'Жанкешті ұрыс',
    descriptionKz: '25 шайқасты ойна',
    icon: '🔥',
    rewardCoins: 200,
    metric: 'battles_played',
    threshold: 25,
  },
  {
    id: 'A_BATTLE_06',
    category: 'battle',
    titleKz: 'Мінсіз жеңіс',
    descriptionKz: 'Бір шайқасты қателеспей жең',
    icon: '🏵️',
    rewardCoins: 150,
    metric: 'battles_perfect',
    threshold: 1,
  },

  // ---------- Collection (5) ----------
  {
    id: 'A_COLL_01',
    category: 'collection',
    titleKz: 'Сәнді бастама',
    descriptionKz: 'Бірінші затты сатып ал',
    icon: '🧢',
    rewardCoins: 20,
    metric: 'items_owned',
    threshold: 1,
  },
  {
    id: 'A_COLL_02',
    category: 'collection',
    titleKz: 'Стиль иесі',
    descriptionKz: '10 түрлі зат жина',
    icon: '👕',
    rewardCoins: 100,
    metric: 'items_owned',
    threshold: 10,
  },
  {
    id: 'A_COLL_03',
    category: 'collection',
    titleKz: 'Гардероб королі',
    descriptionKz: '25 түрлі зат жина',
    icon: '👑',
    rewardCoins: 350,
    metric: 'items_owned',
    threshold: 25,
  },
  {
    id: 'A_COLL_04',
    category: 'collection',
    titleKz: 'Шашушы',
    descriptionKz: '500 тиын жұмса',
    icon: '💸',
    rewardCoins: 50,
    metric: 'coins_spent',
    threshold: 500,
  },
  {
    id: 'A_COLL_05',
    category: 'collection',
    titleKz: 'Білім сақтаушы',
    descriptionKz: '100 ақыл ұпайын жина',
    icon: '🔮',
    rewardCoins: 120,
    metric: 'akyl_points',
    threshold: 100,
  },

  // ---------- Friends (4) ----------
  {
    id: 'A_FRND_01',
    category: 'friends',
    titleKz: 'Алғашқы дос',
    descriptionKz: 'Бірінші досыңды қос',
    icon: '🤝',
    rewardCoins: 30,
    metric: 'friends_count',
    threshold: 1,
  },
  {
    id: 'A_FRND_02',
    category: 'friends',
    titleKz: 'Шағын дос топ',
    descriptionKz: '5 дос жина',
    icon: '👫',
    rewardCoins: 100,
    metric: 'friends_count',
    threshold: 5,
  },
  {
    id: 'A_FRND_03',
    category: 'friends',
    titleKz: 'Танымал тұлға',
    descriptionKz: '20 дос жина',
    icon: '🌟',
    rewardCoins: 400,
    metric: 'friends_count',
    threshold: 20,
  },
  {
    id: 'A_FRND_04',
    category: 'friends',
    titleKz: 'Достық шайқасы',
    descriptionKz: 'Досыңмен 5 рет шайқас',
    icon: '🎮',
    rewardCoins: 120,
    metric: 'battles_vs_friends',
    threshold: 5,
  },

  // ---------- Streak (5) ----------
  {
    id: 'A_STRK_01',
    category: 'streak',
    titleKz: 'Үш күн қатарынан',
    descriptionKz: '3 күн қатарынан кіріп шық',
    icon: '🔥',
    rewardCoins: 50,
    metric: 'current_streak',
    threshold: 3,
  },
  {
    id: 'A_STRK_02',
    category: 'streak',
    titleKz: 'Апта алмасы',
    descriptionKz: '7 күн қатарынан кіріп шық',
    icon: '🏆',
    rewardCoins: 150,
    metric: 'current_streak',
    threshold: 7,
  },
  {
    id: 'A_STRK_03',
    category: 'streak',
    titleKz: 'Екі апта',
    descriptionKz: '14 күн қатарынан кіріп шық',
    icon: '🌠',
    rewardCoins: 300,
    metric: 'current_streak',
    threshold: 14,
  },
  {
    id: 'A_STRK_04',
    category: 'streak',
    titleKz: 'Ай бойы',
    descriptionKz: '30 күн қатарынан кіріп шық',
    icon: '🌙',
    rewardCoins: 1000,
    metric: 'current_streak',
    threshold: 30,
  },
  {
    id: 'A_STRK_05',
    category: 'streak',
    titleKz: 'Жүзжылдық от',
    descriptionKz: '100 күн қатарынан кіріп шық',
    icon: '☄️',
    rewardCoins: 5000,
    metric: 'current_streak',
    threshold: 100,
  },

  // ---------- Special (3) ----------
  {
    id: 'A_SPEC_01',
    category: 'special',
    titleKz: '10-деңгей',
    descriptionKz: '10-деңгейге жет',
    icon: '🎖️',
    rewardCoins: 100,
    metric: 'level',
    threshold: 10,
  },
  {
    id: 'A_SPEC_02',
    category: 'special',
    titleKz: '50-деңгей',
    descriptionKz: '50-деңгейге жет',
    icon: '💫',
    rewardCoins: 750,
    metric: 'level',
    threshold: 50,
  },
  {
    id: 'A_SPEC_03',
    category: 'special',
    titleKz: 'QosQanat Чемпионы',
    descriptionKz: '100-деңгейге жет',
    icon: '🏛️',
    rewardCoins: 5000,
    metric: 'level',
    threshold: 100,
  },
];

const achievementMap = new Map<string, Achievement>(ACHIEVEMENTS.map((a) => [a.id, a]));

export const getAchievement = (id: string): Achievement | undefined => achievementMap.get(id);

export const achievementsByCategory = (category: AchievementCategory): readonly Achievement[] =>
  ACHIEVEMENTS.filter((a) => a.category === category);

// ----------------------------------------------------------------------------
// Engine: given a metrics snapshot and the set of already-unlocked ids, return
// the achievements that have just become eligible. Callers persist them into
// public.user_achievements and grant the rewardCoins.
// ----------------------------------------------------------------------------
export type MetricsSnapshot = Partial<Record<AchievementMetric, number>>;

export const evaluateAchievements = (
  metrics: MetricsSnapshot,
  alreadyUnlocked: ReadonlySet<string>,
): readonly Achievement[] => {
  const newly: Achievement[] = [];
  for (const a of ACHIEVEMENTS) {
    if (alreadyUnlocked.has(a.id)) continue;
    const value = metrics[a.metric] ?? 0;
    if (value >= a.threshold) newly.push(a);
  }
  return newly;
};
