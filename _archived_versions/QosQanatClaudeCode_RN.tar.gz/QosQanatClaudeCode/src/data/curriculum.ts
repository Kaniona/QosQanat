// ----------------------------------------------------------------------------
// Curriculum data — five subjects, each with one or more grade-organized
// modules. Each module is a sequence of nodes the player walks through on the
// MapScreen; each node carries a typed list of Kazakh questions.
//
// Content scope: this file is the *seed* curriculum. Each subject ships with
// at least one fully-fleshed module (8-14 nodes, 4-6 questions each). The
// content engine reads `CURRICULUM` only — adding new modules / nodes is a
// pure append to the constant below, no other code needs to change.
// ----------------------------------------------------------------------------

import type { NodeType } from '@/types';

export type QuestionType = 'multiple_choice' | 'true_false' | 'fill_in_blank' | 'match_pairs';

export interface MultipleChoiceQuestion {
  id: string;
  type: 'multiple_choice';
  questionKz: string;
  options: readonly string[];
  correctIndex: number;
  explanationKz?: string;
}

export interface TrueFalseQuestion {
  id: string;
  type: 'true_false';
  statementKz: string;
  isTrue: boolean;
  explanationKz?: string;
}

export interface FillInBlankQuestion {
  id: string;
  type: 'fill_in_blank';
  sentenceKz: string; // contains a "___" placeholder
  bank: readonly string[]; // distractor pool, includes the correct word
  correctWord: string;
  explanationKz?: string;
}

export interface MatchPair {
  id: string;
  leftKz: string;
  rightKz: string;
}

export interface MatchPairsQuestion {
  id: string;
  type: 'match_pairs';
  promptKz: string;
  pairs: readonly MatchPair[];
}

export type Question =
  | MultipleChoiceQuestion
  | TrueFalseQuestion
  | FillInBlankQuestion
  | MatchPairsQuestion;

export interface CurriculumNode {
  id: string;
  titleKz: string;
  descriptionKz: string;
  type: NodeType;
  order: number;
  xpReward: number;
  coinReward: number;
  akylReward: number;
  questions: readonly Question[];
}

export interface CurriculumModule {
  id: string;
  titleKz: string;
  grade: number;
  descriptionKz: string;
  nodes: readonly CurriculumNode[];
}

export interface Subject {
  id: string;
  nameKz: string;
  icon: string;
  color: string; // primary gradient stop
  colorLight: string; // secondary gradient stop
  descriptionKz: string;
  modules: readonly CurriculumModule[];
}

// ----------------------------------------------------------------------------
// Helpers — reduce repetition for reward shapes by node type.
// ----------------------------------------------------------------------------

const rewardsFor = (type: NodeType): { xp: number; coins: number; akyl: number } => {
  switch (type) {
    case 'lesson':
      return { xp: 50, coins: 10, akyl: 5 };
    case 'quiz':
      return { xp: 80, coins: 20, akyl: 10 };
    case 'boss':
      return { xp: 150, coins: 50, akyl: 25 };
    case 'treasure':
      return { xp: 40, coins: 80, akyl: 15 };
  }
};

interface NodeShorthand {
  id: string;
  titleKz: string;
  descriptionKz: string;
  type: NodeType;
  questions: readonly Question[];
}

const buildNodes = (rows: readonly NodeShorthand[]): readonly CurriculumNode[] =>
  rows.map((row, idx) => {
    const r = rewardsFor(row.type);
    return {
      id: row.id,
      titleKz: row.titleKz,
      descriptionKz: row.descriptionKz,
      type: row.type,
      order: idx + 1,
      xpReward: r.xp,
      coinReward: r.coins,
      akylReward: r.akyl,
      questions: row.questions,
    };
  });

// ============================================================================
// INFORMATICS — flagship subject. Two modules covering the full spec topic list:
//   computers, keyboards, OS, internet, smartphones, Steve Jobs, Bill Gates,
//   internet safety, Excel, AI, Python intro, Kazakhstani IT (Kaspi, Kolesa).
// ============================================================================

const INFORMATICS_GRADE5: readonly NodeShorthand[] = [
  {
    id: 'inf5_n01',
    titleKz: 'Компьютер дегеніміз не?',
    descriptionKz: 'Компьютер — ақпаратты өңдейтін электрондық машина.',
    type: 'lesson',
    questions: [
      {
        id: 'inf5_n01_q1',
        type: 'multiple_choice',
        questionKz: 'Компьютер дегеніміз не?',
        options: ['Ақпаратты өңдейтін машина', 'Ойыншық', 'Кітап', 'Сурет'],
        correctIndex: 0,
        explanationKz: 'Компьютер — деректі сақтап, өңдеп, шығаратын электрондық құрылғы.',
      },
      {
        id: 'inf5_n01_q2',
        type: 'true_false',
        statementKz: 'Компьютер тек ойын ойнау үшін ғана жасалған.',
        isTrue: false,
        explanationKz: 'Компьютер оқу, жұмыс істеу, байланысу үшін де қолданылады.',
      },
      {
        id: 'inf5_n01_q3',
        type: 'multiple_choice',
        questionKz: 'Алғашқы компьютерлер қандай болды?',
        options: [
          'Кішкентай қалта көлемінде',
          'Бүкіл бөлмеге сыятындай үлкен',
          'Қаламсап тәрізді',
          'Көрінбейтін',
        ],
        correctIndex: 1,
      },
      {
        id: 'inf5_n01_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Компьютердің миы — ___ деп аталады.',
        bank: ['процессор', 'экран', 'тінтуір', 'пернетақта'],
        correctWord: 'процессор',
      },
      {
        id: 'inf5_n01_q5',
        type: 'multiple_choice',
        questionKz: 'Қайсысы компьютер емес?',
        options: ['Ноутбук', 'Планшет', 'Қалам', 'Смартфон'],
        correctIndex: 2,
      },
    ],
  },
  {
    id: 'inf5_n02',
    titleKz: 'Компьютердің бөліктері',
    descriptionKz: 'Жүйелік блок, монитор, тінтуір, пернетақта және басқа бөліктер.',
    type: 'lesson',
    questions: [
      {
        id: 'inf5_n02_q1',
        type: 'match_pairs',
        promptKz: 'Бөлік пен оның қызметін сәйкестендір:',
        pairs: [
          { id: 'p1', leftKz: 'Монитор', rightKz: 'Бейне шығарады' },
          { id: 'p2', leftKz: 'Пернетақта', rightKz: 'Мәтін енгізеді' },
          { id: 'p3', leftKz: 'Тінтуір', rightKz: 'Курсорды басқарады' },
          { id: 'p4', leftKz: 'Принтер', rightKz: 'Қағазға басып шығарады' },
        ],
      },
      {
        id: 'inf5_n02_q2',
        type: 'multiple_choice',
        questionKz: 'Монитор қандай құрылғы?',
        options: ['Кіріс', 'Шығыс', 'Сақтау', 'Желілік'],
        correctIndex: 1,
        explanationKz: 'Монитор — бейнені шығаратын құрылғы.',
      },
      {
        id: 'inf5_n02_q3',
        type: 'true_false',
        statementKz: 'Жүйелік блок — компьютердің негізгі бөлігі.',
        isTrue: true,
      },
      {
        id: 'inf5_n02_q4',
        type: 'multiple_choice',
        questionKz: 'Қайсысы шығыс құрылғысы?',
        options: ['Микрофон', 'Тінтуір', 'Принтер', 'Сканер'],
        correctIndex: 2,
      },
      {
        id: 'inf5_n02_q5',
        type: 'fill_in_blank',
        sentenceKz: '___ — бұл деректерді ұзақ уақыт сақтайтын құрылғы.',
        bank: ['Қатты диск', 'Үндеткіш', 'Бейне', 'Қалам'],
        correctWord: 'Қатты диск',
      },
    ],
  },
  {
    id: 'inf5_n03',
    titleKz: 'Пернетақта және оның құпиялары',
    descriptionKz: 'QWERTY орналасу, функционалдық пернелер, тіркесімдер.',
    type: 'lesson',
    questions: [
      {
        id: 'inf5_n03_q1',
        type: 'multiple_choice',
        questionKz: 'Енгізу пернесі қалай аталады?',
        options: ['Esc', 'Tab', 'Enter', 'Shift'],
        correctIndex: 2,
      },
      {
        id: 'inf5_n03_q2',
        type: 'multiple_choice',
        questionKz: 'Бас әріп жазу үшін қандай пернені ұстаймыз?',
        options: ['Ctrl', 'Shift', 'Alt', 'Space'],
        correctIndex: 1,
      },
      {
        id: 'inf5_n03_q3',
        type: 'true_false',
        statementKz: 'F1 пернесі әдетте көмек терезесін ашады.',
        isTrue: true,
      },
      {
        id: 'inf5_n03_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Көшіру үшін ___ + C тіркесімі қолданылады.',
        bank: ['Ctrl', 'Alt', 'Shift', 'Tab'],
        correctWord: 'Ctrl',
      },
      {
        id: 'inf5_n03_q5',
        type: 'match_pairs',
        promptKz: 'Перне мен амалды сәйкестендір:',
        pairs: [
          { id: 'm1', leftKz: 'Ctrl + V', rightKz: 'Қою' },
          { id: 'm2', leftKz: 'Ctrl + Z', rightKz: 'Қайтару' },
          { id: 'm3', leftKz: 'Ctrl + S', rightKz: 'Сақтау' },
          { id: 'm4', leftKz: 'Ctrl + A', rightKz: 'Барлығын таңдау' },
        ],
      },
    ],
  },
  {
    id: 'inf5_n04',
    titleKz: 'Тінтуір мен курсор',
    descriptionKz: 'Сол жақ басу, оң жақ басу, скролл, екі рет басу.',
    type: 'lesson',
    questions: [
      {
        id: 'inf5_n04_q1',
        type: 'multiple_choice',
        questionKz: 'Тінтуірдің оң жақ батырмасы әдетте нені ашады?',
        options: ['Контекстік мәзір', 'Жаңа терезе', 'Принтер', 'Wi-Fi'],
        correctIndex: 0,
      },
      {
        id: 'inf5_n04_q2',
        type: 'true_false',
        statementKz: 'Файлды ашу үшін оны екі рет басу керек.',
        isTrue: true,
      },
      {
        id: 'inf5_n04_q3',
        type: 'multiple_choice',
        questionKz: 'Курсор дегеніміз не?',
        options: ['Экранда жыпылықтап тұратын белгі', 'Қатты диск', 'Желі', 'Үндеткіш'],
        correctIndex: 0,
      },
      {
        id: 'inf5_n04_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Тінтуірдің ___ дөңгелегімен бетті жоғары-төмен жылжытамыз.',
        bank: ['скролл', 'батырма', 'сым', 'шам'],
        correctWord: 'скролл',
      },
    ],
  },
  {
    id: 'inf5_n05',
    titleKz: 'Аппаратты білу — қуат',
    descriptionKz: 'Алғашқы тарауды бекіту тесті.',
    type: 'quiz',
    questions: [
      {
        id: 'inf5_n05_q1',
        type: 'multiple_choice',
        questionKz: 'Қайсы құрылғы кіріс құрылғысы?',
        options: ['Монитор', 'Принтер', 'Микрофон', 'Үндеткіш'],
        correctIndex: 2,
      },
      {
        id: 'inf5_n05_q2',
        type: 'multiple_choice',
        questionKz: 'RAM (жедел жады) не үшін керек?',
        options: [
          'Қазір жұмыс істеп тұрған бағдарламаларды ұстау',
          'Тоқ беру',
          'Сурет шығару',
          'Желіге қосу',
        ],
        correctIndex: 0,
      },
      {
        id: 'inf5_n05_q3',
        type: 'true_false',
        statementKz: 'Процессор неғұрлым жылдам болса, компьютер де солғұрлым жылдам.',
        isTrue: true,
      },
      {
        id: 'inf5_n05_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Бағдарлама тұрақты түрде ___ дискіде сақталады.',
        bank: ['қатты', 'жұмсақ', 'мөлдір', 'ауыр'],
        correctWord: 'қатты',
      },
      {
        id: 'inf5_n05_q5',
        type: 'multiple_choice',
        questionKz: '1 байт нешеуі бит?',
        options: ['4', '8', '16', '32'],
        correctIndex: 1,
      },
    ],
  },
  {
    id: 'inf5_n06',
    titleKz: 'Операциялық жүйелер',
    descriptionKz: 'Windows, macOS, Linux, Android, iOS.',
    type: 'lesson',
    questions: [
      {
        id: 'inf5_n06_q1',
        type: 'match_pairs',
        promptKz: 'ОЖ-ні шығарушы компаниямен сәйкестендір:',
        pairs: [
          { id: 'os1', leftKz: 'Windows', rightKz: 'Microsoft' },
          { id: 'os2', leftKz: 'macOS', rightKz: 'Apple' },
          { id: 'os3', leftKz: 'Android', rightKz: 'Google' },
          { id: 'os4', leftKz: 'Linux', rightKz: 'Linus Torvalds' },
        ],
      },
      {
        id: 'inf5_n06_q2',
        type: 'true_false',
        statementKz: 'Linux — тегін операциялық жүйе.',
        isTrue: true,
      },
      {
        id: 'inf5_n06_q3',
        type: 'multiple_choice',
        questionKz: 'iPhone-да қандай ОЖ орнатылған?',
        options: ['Windows', 'iOS', 'Android', 'Linux'],
        correctIndex: 1,
      },
      {
        id: 'inf5_n06_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Операциялық жүйе компьютердің ___ басқарады.',
        bank: ['ресурстарын', 'желісін', 'түсін', 'дыбысын'],
        correctWord: 'ресурстарын',
      },
    ],
  },
  {
    id: 'inf5_n07',
    titleKz: 'Файлдар мен қалталар',
    descriptionKz: 'Жасау, көшіру, жою, кеңейтім.',
    type: 'lesson',
    questions: [
      {
        id: 'inf5_n07_q1',
        type: 'multiple_choice',
        questionKz: '.docx — қай бағдарламаның файлы?',
        options: ['Excel', 'Word', 'PowerPoint', 'Paint'],
        correctIndex: 1,
      },
      {
        id: 'inf5_n07_q2',
        type: 'match_pairs',
        promptKz: 'Кеңейтім мен файл түрін сәйкестендір:',
        pairs: [
          { id: 'f1', leftKz: '.jpg', rightKz: 'Сурет' },
          { id: 'f2', leftKz: '.mp3', rightKz: 'Музыка' },
          { id: 'f3', leftKz: '.mp4', rightKz: 'Бейне' },
          { id: 'f4', leftKz: '.txt', rightKz: 'Мәтін' },
        ],
      },
      {
        id: 'inf5_n07_q3',
        type: 'true_false',
        statementKz: 'Қалта ішінде басқа қалта болуы мүмкін.',
        isTrue: true,
      },
      {
        id: 'inf5_n07_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Файлды жою үшін ___ батырмасын басу керек.',
        bank: ['Delete', 'Enter', 'Tab', 'Shift'],
        correctWord: 'Delete',
      },
    ],
  },
  {
    id: 'inf5_n08',
    titleKz: '🐉 Бірінші босс: Аппарат шебері',
    descriptionKz: 'Барлық тақырыпты бекітетін шайқас.',
    type: 'boss',
    questions: [
      {
        id: 'inf5_n08_q1',
        type: 'multiple_choice',
        questionKz: 'Қайсысы компьютердің "миы"?',
        options: ['Монитор', 'Процессор', 'Тінтуір', 'Қатты диск'],
        correctIndex: 1,
      },
      {
        id: 'inf5_n08_q2',
        type: 'true_false',
        statementKz: 'Android — Google компаниясы шығарған ОЖ.',
        isTrue: true,
      },
      {
        id: 'inf5_n08_q3',
        type: 'fill_in_blank',
        sentenceKz: '1 килобайт = ___ байт.',
        bank: ['512', '1024', '2048', '100'],
        correctWord: '1024',
      },
      {
        id: 'inf5_n08_q4',
        type: 'multiple_choice',
        questionKz: 'Қайсысы кіріс құрылғысы?',
        options: ['Принтер', 'Сканер', 'Монитор', 'Үндеткіш'],
        correctIndex: 1,
      },
      {
        id: 'inf5_n08_q5',
        type: 'multiple_choice',
        questionKz: 'Қандай тіркесім сақтауды білдіреді?',
        options: ['Ctrl + S', 'Ctrl + N', 'Ctrl + P', 'Ctrl + W'],
        correctIndex: 0,
      },
      {
        id: 'inf5_n08_q6',
        type: 'true_false',
        statementKz: 'Linux операциялық жүйесін Linus Torvalds жасады.',
        isTrue: true,
      },
    ],
  },
  {
    id: 'inf5_n09',
    titleKz: '💎 Қазына: Қауіпсіз парольдер',
    descriptionKz: 'Күшті пароль қалай жасалады?',
    type: 'treasure',
    questions: [
      {
        id: 'inf5_n09_q1',
        type: 'multiple_choice',
        questionKz: 'Қандай пароль ең күшті?',
        options: ['12345', 'password', 'Qq!7nM2#9zL', 'қ-жан'],
        correctIndex: 2,
      },
      {
        id: 'inf5_n09_q2',
        type: 'true_false',
        statementKz: 'Парольді досқа айтуға болады.',
        isTrue: false,
      },
      {
        id: 'inf5_n09_q3',
        type: 'multiple_choice',
        questionKz: 'Қандай таңбалар парольді күшейтеді?',
        options: ['Тек әріп', 'Тек сан', 'Әріп + сан + таңба', 'Бос орын'],
        correctIndex: 2,
      },
      {
        id: 'inf5_n09_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Парольдің ең қысқа ұсынылған ұзындығы ___ таңба.',
        bank: ['4', '6', '8', '12'],
        correctWord: '12',
      },
    ],
  },
  {
    id: 'inf5_n10',
    titleKz: 'Қазақстан IT-ы: Kaspi мен Kolesa',
    descriptionKz: 'Отандық технологиялық компанияларға саяхат.',
    type: 'lesson',
    questions: [
      {
        id: 'inf5_n10_q1',
        type: 'multiple_choice',
        questionKz: 'Kaspi компаниясы қандай саладан басталды?',
        options: ['Банк ісі', 'Газет шығару', 'Спорт', 'Музыка'],
        correctIndex: 0,
        explanationKz: 'Kaspi алдымен банк, кейін IT-супер-апп болды.',
      },
      {
        id: 'inf5_n10_q2',
        type: 'true_false',
        statementKz: 'Kolesa.kz — Қазақстандағы көлік сату алаңы.',
        isTrue: true,
      },
      {
        id: 'inf5_n10_q3',
        type: 'match_pairs',
        promptKz: 'Қазақстандық қызмет пен оның бағытын сәйкестендір:',
        pairs: [
          { id: 'kz1', leftKz: 'Kaspi.kz', rightKz: 'Банк және төлем' },
          { id: 'kz2', leftKz: 'Kolesa.kz', rightKz: 'Көлік сату' },
          { id: 'kz3', leftKz: 'Krisha.kz', rightKz: 'Жылжымайтын мүлік' },
          { id: 'kz4', leftKz: 'Chocofamily', rightKz: 'Жеткізу қызметтері' },
        ],
      },
      {
        id: 'inf5_n10_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Kaspi супер-аппы — банк, ___ және цифрлық қызметтерді біріктіреді.',
        bank: ['базар', 'кітапхана', 'мектеп', 'кино'],
        correctWord: 'базар',
      },
    ],
  },
];

const INFORMATICS_GRADE7: readonly NodeShorthand[] = [
  {
    id: 'inf7_n01',
    titleKz: 'Интернет дегеніміз не?',
    descriptionKz: 'Әлемдік компьютерлік желі қалай жұмыс істейді.',
    type: 'lesson',
    questions: [
      {
        id: 'inf7_n01_q1',
        type: 'multiple_choice',
        questionKz: 'Интернет дегеніміз не?',
        options: ['Бір компьютер', 'Компьютерлердің әлемдік желісі', 'Бағдарлама', 'Кітап'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n01_q2',
        type: 'true_false',
        statementKz: 'Интернет WWW (World Wide Web) деп те аталады.',
        isTrue: true,
      },
      {
        id: 'inf7_n01_q3',
        type: 'multiple_choice',
        questionKz: 'URL деген не?',
        options: ['Сайттың мекенжайы', 'Файл түрі', 'ОЖ', 'Принтер'],
        correctIndex: 0,
      },
      {
        id: 'inf7_n01_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Интернетке қосылу үшін ___ керек.',
        bank: ['провайдер', 'қалам', 'газет', 'үндеткіш'],
        correctWord: 'провайдер',
      },
      {
        id: 'inf7_n01_q5',
        type: 'multiple_choice',
        questionKz: 'HTTP-дегі "S" әрпі (HTTPS) нені білдіреді?',
        options: ['Speed', 'Secure', 'Server', 'Site'],
        correctIndex: 1,
      },
    ],
  },
  {
    id: 'inf7_n02',
    titleKz: 'Браузерлер',
    descriptionKz: 'Chrome, Firefox, Safari, Edge.',
    type: 'lesson',
    questions: [
      {
        id: 'inf7_n02_q1',
        type: 'match_pairs',
        promptKz: 'Браузер мен компанияны сәйкестендір:',
        pairs: [
          { id: 'b1', leftKz: 'Chrome', rightKz: 'Google' },
          { id: 'b2', leftKz: 'Safari', rightKz: 'Apple' },
          { id: 'b3', leftKz: 'Edge', rightKz: 'Microsoft' },
          { id: 'b4', leftKz: 'Firefox', rightKz: 'Mozilla' },
        ],
      },
      {
        id: 'inf7_n02_q2',
        type: 'true_false',
        statementKz: 'Браузер — интернеттегі парақтарды көрсететін бағдарлама.',
        isTrue: true,
      },
      {
        id: 'inf7_n02_q3',
        type: 'multiple_choice',
        questionKz: 'Қандай батырма алдыңғы бетке қайтарады?',
        options: ['↻', '⬅️', '🏠', '⬇️'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n02_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Кейбір браузерлер ___ режимін ұсынады, ол тарихты сақтамайды.',
        bank: ['инкогнито', 'офлайн', 'жұмыс', 'көшіру'],
        correctWord: 'инкогнито',
      },
    ],
  },
  {
    id: 'inf7_n03',
    titleKz: 'Смартфондар',
    descriptionKz: 'Сенсорлы экран, қосымшалар, дүкендер.',
    type: 'lesson',
    questions: [
      {
        id: 'inf7_n03_q1',
        type: 'multiple_choice',
        questionKz: 'iPhone қандай дүкеннен қосымша жүктейді?',
        options: ['Google Play', 'App Store', 'Steam', 'Yandex'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n03_q2',
        type: 'true_false',
        statementKz: 'Алғашқы iPhone 2007 жылы шықты.',
        isTrue: true,
      },
      {
        id: 'inf7_n03_q3',
        type: 'multiple_choice',
        questionKz: 'Қандай датчик смартфонда экранды бұрып ашады?',
        options: ['GPS', 'Гироскоп', 'Микрофон', 'Wi-Fi'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n03_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Android — ___ компаниясының жүйесі.',
        bank: ['Apple', 'Google', 'Samsung', 'Huawei'],
        correctWord: 'Google',
      },
    ],
  },
  {
    id: 'inf7_n04',
    titleKz: 'Стив Джобс',
    descriptionKz: 'Apple негізін салушы, дизайн философиясы.',
    type: 'lesson',
    questions: [
      {
        id: 'inf7_n04_q1',
        type: 'multiple_choice',
        questionKz: 'Стив Джобс қандай компанияны негіздеді?',
        options: ['Microsoft', 'Apple', 'Google', 'IBM'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n04_q2',
        type: 'true_false',
        statementKz: 'Стив Джобс Стив Возняктың серіктесі болды.',
        isTrue: true,
      },
      {
        id: 'inf7_n04_q3',
        type: 'multiple_choice',
        questionKz: 'Apple қай жылы құрылды?',
        options: ['1972', '1976', '1984', '1991'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n04_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Apple-дің бірінші революциялық телефоны — ___.',
        bank: ['iPhone', 'iMac', 'iPad', 'iPod'],
        correctWord: 'iPhone',
      },
      {
        id: 'inf7_n04_q5',
        type: 'multiple_choice',
        questionKz: 'Стив Джобс қандай мультфильм студиясын жетекшілеп, Disney-ге сатты?',
        options: ['DreamWorks', 'Pixar', 'Sony', 'Studio Ghibli'],
        correctIndex: 1,
      },
    ],
  },
  {
    id: 'inf7_n05',
    titleKz: 'Билл Гейтс',
    descriptionKz: 'Microsoft және Windows тарихы.',
    type: 'lesson',
    questions: [
      {
        id: 'inf7_n05_q1',
        type: 'multiple_choice',
        questionKz: 'Билл Гейтс қандай компанияны негіздеді?',
        options: ['Apple', 'Microsoft', 'Tesla', 'IBM'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n05_q2',
        type: 'true_false',
        statementKz: 'Билл Гейтс Microsoft-ты Пол Алленмен бірге құрды.',
        isTrue: true,
      },
      {
        id: 'inf7_n05_q3',
        type: 'multiple_choice',
        questionKz: 'Microsoft қандай танымал офистік пакетті шығарады?',
        options: ['iWork', 'Microsoft Office', 'Google Docs', 'LibreOffice'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n05_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Microsoft компаниясы ___ ОЖ-нің авторы.',
        bank: ['Windows', 'macOS', 'Linux', 'Android'],
        correctWord: 'Windows',
      },
    ],
  },
  {
    id: 'inf7_n06',
    titleKz: 'Тарихи дәуір тесті',
    descriptionKz: 'IT-тың алыбы туралы білімді тексеру.',
    type: 'quiz',
    questions: [
      {
        id: 'inf7_n06_q1',
        type: 'multiple_choice',
        questionKz: 'Қай адам "Think different" ұранын танытты?',
        options: ['Билл Гейтс', 'Стив Джобс', 'Илон Маск', 'Марк Цукерберг'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n06_q2',
        type: 'multiple_choice',
        questionKz: 'Қандай жүйе ашық бастапқы кодты пайдаланады?',
        options: ['Linux', 'Windows', 'iOS', 'macOS'],
        correctIndex: 0,
      },
      {
        id: 'inf7_n06_q3',
        type: 'true_false',
        statementKz: 'Билл Гейтс кейіннен қайырымдылықпен айналысты.',
        isTrue: true,
      },
      {
        id: 'inf7_n06_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Apple-дің штаб-пәтері ___ қаласында орналасқан.',
        bank: ['Cupertino', 'Redmond', 'Mountain View', 'Seattle'],
        correctWord: 'Cupertino',
      },
      {
        id: 'inf7_n06_q5',
        type: 'multiple_choice',
        questionKz: 'Microsoft қай қалада орналасқан?',
        options: ['Redmond', 'Cupertino', 'Berlin', 'Tokyo'],
        correctIndex: 0,
      },
    ],
  },
  {
    id: 'inf7_n07',
    titleKz: 'Интернет қауіпсіздігі',
    descriptionKz: 'Фишинг, парольдер, жеке деректер.',
    type: 'lesson',
    questions: [
      {
        id: 'inf7_n07_q1',
        type: 'true_false',
        statementKz: 'Танымайтын сілтемелерді бассаңыз да қауіпсіз.',
        isTrue: false,
      },
      {
        id: 'inf7_n07_q2',
        type: 'multiple_choice',
        questionKz: 'Фишинг — бұл не?',
        options: ['Балық аулау', 'Жалған хатпен дерек ұрлау', 'Жаңа ойын', 'Wi-Fi түрі'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n07_q3',
        type: 'multiple_choice',
        questionKz: 'Қандай сайтқа сенуге болады?',
        options: ['http://...', 'https://...', 'Кездейсоқ сілтеме', 'Кейіпкер сайты'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n07_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Қос факторлық ___ — есепжазбаны қорғаудың жақсы тәсілі.',
        bank: ['аутентификация', 'жаңарту', 'кескіндеу', 'көшіру'],
        correctWord: 'аутентификация',
      },
      {
        id: 'inf7_n07_q5',
        type: 'true_false',
        statementKz: 'Парольді әр сайтқа бөлек жасаған дұрыс.',
        isTrue: true,
      },
    ],
  },
  {
    id: 'inf7_n08',
    titleKz: 'Excel негіздері',
    descriptionKz: 'Кестелер, формулалар, диаграммалар.',
    type: 'lesson',
    questions: [
      {
        id: 'inf7_n08_q1',
        type: 'multiple_choice',
        questionKz: 'Excel-де формула қандай таңбадан басталады?',
        options: ['#', '=', '!', '*'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n08_q2',
        type: 'multiple_choice',
        questionKz: 'Қандай формула орташа мәнді есептейді?',
        options: ['SUM', 'AVERAGE', 'COUNT', 'MIN'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n08_q3',
        type: 'true_false',
        statementKz: 'Excel-де ұяшықтар әріп пен санмен белгіленеді (мысалы, A1).',
        isTrue: true,
      },
      {
        id: 'inf7_n08_q4',
        type: 'fill_in_blank',
        sentenceKz: 'A1-ден A5-ке дейінгі мәндерді қосу үшін ___ формуласын жазамыз.',
        bank: ['=SUM(A1:A5)', '=AVG(A1:A5)', '=A1+A5', '=COUNT(A1:A5)'],
        correctWord: '=SUM(A1:A5)',
      },
      {
        id: 'inf7_n08_q5',
        type: 'multiple_choice',
        questionKz: 'Қандай Excel құралы деректерді кескіндейді?',
        options: ['Диаграмма', 'Сүзгі', 'Сұрыптау', 'Сілтеме'],
        correctIndex: 0,
      },
    ],
  },
  {
    id: 'inf7_n09',
    titleKz: 'Жасанды интеллект (AI)',
    descriptionKz: 'AI деген не? Нейрондық желілер. Claude, ChatGPT.',
    type: 'lesson',
    questions: [
      {
        id: 'inf7_n09_q1',
        type: 'multiple_choice',
        questionKz: 'AI деген не?',
        options: ['Жаңа ойын', 'Жасанды интеллект', 'Жоғары интернет', 'Бір тіл'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n09_q2',
        type: 'true_false',
        statementKz: 'Нейрондық желілер адам миының жұмысынан үлгі алады.',
        isTrue: true,
      },
      {
        id: 'inf7_n09_q3',
        type: 'multiple_choice',
        questionKz: 'Қандай қызмет — танымал AI ассистенттерінің бірі?',
        options: ['Claude', 'TikTok', 'Excel', 'Photoshop'],
        correctIndex: 0,
      },
      {
        id: 'inf7_n09_q4',
        type: 'fill_in_blank',
        sentenceKz: 'AI ___ деректерге қарап өзін үйретеді.',
        bank: ['үлкен', 'кіші', 'бос', 'жоғалған'],
        correctWord: 'үлкен',
      },
      {
        id: 'inf7_n09_q5',
        type: 'true_false',
        statementKz: 'AI бүкіл шешімді әрқашан дұрыс шығарады.',
        isTrue: false,
      },
    ],
  },
  {
    id: 'inf7_n10',
    titleKz: 'Python тіліне кіріспе',
    descriptionKz: 'Айнымалылар, print, шартты оператор.',
    type: 'lesson',
    questions: [
      {
        id: 'inf7_n10_q1',
        type: 'multiple_choice',
        questionKz: 'Python-да экранға мәтін шығаратын команда?',
        options: ['echo', 'print', 'write', 'show'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n10_q2',
        type: 'fill_in_blank',
        sentenceKz: 'Python-да айнымалы былай жасалады: x ___ 5',
        bank: ['=', '==', ':=', '->'],
        correctWord: '=',
      },
      {
        id: 'inf7_n10_q3',
        type: 'true_false',
        statementKz: 'Python бағдарламалау тілін Гвидо ван Россум жасады.',
        isTrue: true,
      },
      {
        id: 'inf7_n10_q4',
        type: 'multiple_choice',
        questionKz: 'Қайсысы Python-да дұрыс шартты оператор?',
        options: ['if x > 5:', 'when x > 5', 'check x > 5', 'x > 5 then'],
        correctIndex: 0,
      },
      {
        id: 'inf7_n10_q5',
        type: 'match_pairs',
        promptKz: 'Python типі мен мысалын сәйкестендір:',
        pairs: [
          { id: 'py1', leftKz: 'int', rightKz: '42' },
          { id: 'py2', leftKz: 'str', rightKz: '"сәлем"' },
          { id: 'py3', leftKz: 'bool', rightKz: 'True' },
          { id: 'py4', leftKz: 'float', rightKz: '3.14' },
        ],
      },
    ],
  },
  {
    id: 'inf7_n11',
    titleKz: '💎 Қазына: Болашағыңды кодпен жаз',
    descriptionKz: 'Бағдарламашы мамандығының болашағы.',
    type: 'treasure',
    questions: [
      {
        id: 'inf7_n11_q1',
        type: 'multiple_choice',
        questionKz: 'Қандай мамандық алдағы жылдарда сұранысты болады?',
        options: ['Бағдарламашы', 'Жылқышы', 'Бағбан', 'Балықшы'],
        correctIndex: 0,
      },
      {
        id: 'inf7_n11_q2',
        type: 'true_false',
        statementKz: 'IT саласы Қазақстанда қарқынды дамып келеді.',
        isTrue: true,
      },
      {
        id: 'inf7_n11_q3',
        type: 'fill_in_blank',
        sentenceKz: 'Astana Hub — Қазақстандағы ___ инновациялар хабы.',
        bank: ['IT', 'спорт', 'ауыл', 'кино'],
        correctWord: 'IT',
      },
    ],
  },
  {
    id: 'inf7_n12',
    titleKz: '🐉 Үлкен босс: Цифрлық шебер',
    descriptionKz: 'Барлық тақырыпты қамтитын соңғы шайқас.',
    type: 'boss',
    questions: [
      {
        id: 'inf7_n12_q1',
        type: 'multiple_choice',
        questionKz: 'Apple-ді кім негіздеді?',
        options: ['Билл Гейтс', 'Стив Джобс пен Стив Возняк', 'Илон Маск', 'Марк Цукерберг'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n12_q2',
        type: 'multiple_choice',
        questionKz: 'Excel-де A1+B1 қосындысын қалай жазамыз?',
        options: ['SUM(A1,B1)', '=A1+B1', '+A1B1', 'A1+B1='],
        correctIndex: 1,
      },
      {
        id: 'inf7_n12_q3',
        type: 'true_false',
        statementKz: 'Python — жоғары деңгейлі бағдарламалау тілі.',
        isTrue: true,
      },
      {
        id: 'inf7_n12_q4',
        type: 'multiple_choice',
        questionKz: 'Kaspi супер-аппы кімдерге арналған?',
        options: [
          'Тек банктерге',
          'Қарапайым пайдаланушыларға',
          'Тек балаларға',
          'Тек кәсіпкерлерге',
        ],
        correctIndex: 1,
      },
      {
        id: 'inf7_n12_q5',
        type: 'fill_in_blank',
        sentenceKz: 'Қос факторлық қорғаныс — есепжазбаға кіруге қосымша ___ сұрайды.',
        bank: ['код', 'дос', 'қалам', 'ас'],
        correctWord: 'код',
      },
      {
        id: 'inf7_n12_q6',
        type: 'multiple_choice',
        questionKz: 'AI неліктен үлкен деректерді қажет етеді?',
        options: ['Сақтау үшін', 'Өзін үйрету үшін', 'Тазалау үшін', 'Көшіру үшін'],
        correctIndex: 1,
      },
      {
        id: 'inf7_n12_q7',
        type: 'match_pairs',
        promptKz: 'Жетекші мен компанияны сәйкестендір:',
        pairs: [
          { id: 'bs1', leftKz: 'Стив Джобс', rightKz: 'Apple' },
          { id: 'bs2', leftKz: 'Билл Гейтс', rightKz: 'Microsoft' },
          { id: 'bs3', leftKz: 'Илон Маск', rightKz: 'Tesla' },
          { id: 'bs4', leftKz: 'Михаил Ломтадзе', rightKz: 'Kaspi' },
        ],
      },
    ],
  },
];

// ============================================================================
// MATHEMATICS
// ============================================================================

const MATH_GRADE5: readonly NodeShorthand[] = [
  {
    id: 'mth5_n01',
    titleKz: 'Натурал сандар',
    descriptionKz: 'Санау, сан ондықтары, разрядтар.',
    type: 'lesson',
    questions: [
      {
        id: 'mth5_n01_q1',
        type: 'multiple_choice',
        questionKz: 'Қайсысы натурал сан?',
        options: ['−3', '0', '7', '2.5'],
        correctIndex: 2,
      },
      {
        id: 'mth5_n01_q2',
        type: 'fill_in_blank',
        sentenceKz: '347 санында жүздіктер разряды — ___.',
        bank: ['3', '4', '7', '0'],
        correctWord: '3',
      },
      {
        id: 'mth5_n01_q3',
        type: 'true_false',
        statementKz: 'Ең кіші натурал сан — 1.',
        isTrue: true,
      },
      {
        id: 'mth5_n01_q4',
        type: 'multiple_choice',
        questionKz: '1000 нешеуі ондық?',
        options: ['10', '100', '1000', '10000'],
        correctIndex: 1,
      },
    ],
  },
  {
    id: 'mth5_n02',
    titleKz: 'Қосу мен азайту',
    descriptionKz: 'Үлкен сандарды қосу-азайту.',
    type: 'lesson',
    questions: [
      {
        id: 'mth5_n02_q1',
        type: 'multiple_choice',
        questionKz: '125 + 76 = ?',
        options: ['191', '201', '211', '221'],
        correctIndex: 1,
      },
      {
        id: 'mth5_n02_q2',
        type: 'multiple_choice',
        questionKz: '500 − 237 = ?',
        options: ['253', '263', '273', '243'],
        correctIndex: 1,
      },
      {
        id: 'mth5_n02_q3',
        type: 'fill_in_blank',
        sentenceKz: '320 + ___ = 500',
        bank: ['180', '200', '160', '220'],
        correctWord: '180',
      },
      {
        id: 'mth5_n02_q4',
        type: 'true_false',
        statementKz: 'Қосудың орынбасу заңы: a + b = b + a.',
        isTrue: true,
      },
    ],
  },
  {
    id: 'mth5_n03',
    titleKz: 'Көбейту мен бөлу',
    descriptionKz: 'Көбейту кестесінен бастап үлкен сандарға дейін.',
    type: 'lesson',
    questions: [
      {
        id: 'mth5_n03_q1',
        type: 'multiple_choice',
        questionKz: '12 × 8 = ?',
        options: ['96', '86', '108', '94'],
        correctIndex: 0,
      },
      {
        id: 'mth5_n03_q2',
        type: 'multiple_choice',
        questionKz: '144 ÷ 12 = ?',
        options: ['10', '11', '12', '14'],
        correctIndex: 2,
      },
      {
        id: 'mth5_n03_q3',
        type: 'fill_in_blank',
        sentenceKz: '___ × 7 = 56',
        bank: ['7', '8', '6', '9'],
        correctWord: '8',
      },
      {
        id: 'mth5_n03_q4',
        type: 'true_false',
        statementKz: 'Нөлге бөлуге болмайды.',
        isTrue: true,
      },
    ],
  },
  {
    id: 'mth5_n04',
    titleKz: 'Арифметика тесті',
    descriptionKz: 'Алғашқы тарауды бекіту.',
    type: 'quiz',
    questions: [
      {
        id: 'mth5_n04_q1',
        type: 'multiple_choice',
        questionKz: '(15 + 25) × 2 = ?',
        options: ['65', '70', '80', '90'],
        correctIndex: 2,
      },
      {
        id: 'mth5_n04_q2',
        type: 'multiple_choice',
        questionKz: '600 ÷ 6 + 10 = ?',
        options: ['100', '110', '120', '90'],
        correctIndex: 1,
      },
      {
        id: 'mth5_n04_q3',
        type: 'fill_in_blank',
        sentenceKz: '9 × 9 = ___',
        bank: ['72', '81', '91', '99'],
        correctWord: '81',
      },
      {
        id: 'mth5_n04_q4',
        type: 'true_false',
        statementKz: 'Кез келген санды 1-ге көбейтсек, ол өзгермейді.',
        isTrue: true,
      },
    ],
  },
  {
    id: 'mth5_n05',
    titleKz: '🐉 Босс: Сан патшалығы',
    descriptionKz: 'Алғашқы тараудың соңғы шайқасы.',
    type: 'boss',
    questions: [
      {
        id: 'mth5_n05_q1',
        type: 'multiple_choice',
        questionKz: '7 × 8 + 4 = ?',
        options: ['56', '60', '64', '58'],
        correctIndex: 1,
      },
      {
        id: 'mth5_n05_q2',
        type: 'multiple_choice',
        questionKz: '100 − (20 + 35) = ?',
        options: ['35', '40', '45', '55'],
        correctIndex: 2,
      },
      {
        id: 'mth5_n05_q3',
        type: 'fill_in_blank',
        sentenceKz: '___ ÷ 9 = 7',
        bank: ['56', '63', '70', '72'],
        correctWord: '63',
      },
      {
        id: 'mth5_n05_q4',
        type: 'true_false',
        statementKz: 'a × 0 = 0 — кез келген санға дұрыс.',
        isTrue: true,
      },
      {
        id: 'mth5_n05_q5',
        type: 'multiple_choice',
        questionKz: 'Қандай амал бірінші орындалады?',
        options: ['Қосу', 'Көбейту', 'Азайту', 'Бөлу немесе көбейту бірінші'],
        correctIndex: 3,
      },
    ],
  },
  {
    id: 'mth5_n06',
    titleKz: '💎 Қазына: Жұп пен тақ',
    descriptionKz: 'Жұп және тақ сандардың құпиялары.',
    type: 'treasure',
    questions: [
      {
        id: 'mth5_n06_q1',
        type: 'true_false',
        statementKz: 'Жұп сан + жұп сан = жұп сан.',
        isTrue: true,
      },
      {
        id: 'mth5_n06_q2',
        type: 'multiple_choice',
        questionKz: 'Қайсысы тақ сан?',
        options: ['12', '24', '37', '50'],
        correctIndex: 2,
      },
      {
        id: 'mth5_n06_q3',
        type: 'fill_in_blank',
        sentenceKz: 'Тақ сан + тақ сан = ___ сан.',
        bank: ['жұп', 'тақ', 'бөлшек', 'теріс'],
        correctWord: 'жұп',
      },
    ],
  },
];

// ============================================================================
// KAZAKH LANGUAGE
// ============================================================================

const KAZAKH_GRADE5: readonly NodeShorthand[] = [
  {
    id: 'kaz5_n01',
    titleKz: 'Қазақ әліпбиі',
    descriptionKz: 'Әріптер саны, дауысты-дауыссыз.',
    type: 'lesson',
    questions: [
      {
        id: 'kaz5_n01_q1',
        type: 'multiple_choice',
        questionKz: 'Қазақ тілінде қанша әріп бар (кириллица)?',
        options: ['33', '40', '42', '38'],
        correctIndex: 2,
      },
      {
        id: 'kaz5_n01_q2',
        type: 'multiple_choice',
        questionKz: 'Қайсысы дауысты дыбыс?',
        options: ['к', 'а', 'т', 'с'],
        correctIndex: 1,
      },
      {
        id: 'kaz5_n01_q3',
        type: 'true_false',
        statementKz: '"Ы" мен "І" — дауысты дыбыстар.',
        isTrue: true,
      },
      {
        id: 'kaz5_n01_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Қазақ тілінде ___ түрлі үндестік заңы бар.',
        bank: ['буын', 'сөз', 'жер', 'кітап'],
        correctWord: 'буын',
      },
    ],
  },
  {
    id: 'kaz5_n02',
    titleKz: 'Жуан мен жіңішке дауыстылар',
    descriptionKz: 'а, о, ұ, ы — жуан; ә, ө, ү, і, е — жіңішке.',
    type: 'lesson',
    questions: [
      {
        id: 'kaz5_n02_q1',
        type: 'multiple_choice',
        questionKz: 'Қайсысы жуан дауысты?',
        options: ['ә', 'ө', 'ұ', 'і'],
        correctIndex: 2,
      },
      {
        id: 'kaz5_n02_q2',
        type: 'multiple_choice',
        questionKz: 'Қайсысы жіңішке дауысты?',
        options: ['а', 'о', 'у', 'ү'],
        correctIndex: 3,
      },
      {
        id: 'kaz5_n02_q3',
        type: 'true_false',
        statementKz: '"Бала" сөзіндегі дауыстылардың бәрі жуан.',
        isTrue: true,
      },
      {
        id: 'kaz5_n02_q4',
        type: 'match_pairs',
        promptKz: 'Дыбыс пен түрін сәйкестендір:',
        pairs: [
          { id: 'k1', leftKz: 'а', rightKz: 'жуан' },
          { id: 'k2', leftKz: 'ә', rightKz: 'жіңішке' },
          { id: 'k3', leftKz: 'ө', rightKz: 'жіңішке' },
          { id: 'k4', leftKz: 'ұ', rightKz: 'жуан' },
        ],
      },
    ],
  },
  {
    id: 'kaz5_n03',
    titleKz: 'Сөз құрамы',
    descriptionKz: 'Түбір, жұрнақ, жалғау.',
    type: 'lesson',
    questions: [
      {
        id: 'kaz5_n03_q1',
        type: 'multiple_choice',
        questionKz: '"Кітапхана" сөзіндегі түбір қайсысы?',
        options: ['кітап', 'хана', 'тап', 'на'],
        correctIndex: 0,
      },
      {
        id: 'kaz5_n03_q2',
        type: 'true_false',
        statementKz: 'Жұрнақ сөз тудырушы бөлік бола алады.',
        isTrue: true,
      },
      {
        id: 'kaz5_n03_q3',
        type: 'fill_in_blank',
        sentenceKz: '"Балалар" сөзіндегі ___ — көптік жалғау.',
        bank: ['-лар', '-ы', '-да', '-ның'],
        correctWord: '-лар',
      },
      {
        id: 'kaz5_n03_q4',
        type: 'multiple_choice',
        questionKz: '"Үй-ге" сөзіндегі "-ге" — қандай жалғау?',
        options: ['Тәуелдік', 'Көптік', 'Септік', 'Жіктік'],
        correctIndex: 2,
      },
    ],
  },
  {
    id: 'kaz5_n04',
    titleKz: 'Тіл тесті',
    descriptionKz: 'Алғашқы тарау бекіту.',
    type: 'quiz',
    questions: [
      {
        id: 'kaz5_n04_q1',
        type: 'multiple_choice',
        questionKz: 'Дауыссыз дыбыс саны қазақ тілінде шамамен:',
        options: ['9', '17', '25', '28'],
        correctIndex: 2,
      },
      {
        id: 'kaz5_n04_q2',
        type: 'true_false',
        statementKz: '"Мектеп" сөзі жіңішке буынды.',
        isTrue: true,
      },
      {
        id: 'kaz5_n04_q3',
        type: 'fill_in_blank',
        sentenceKz: '"Дос-тар-ым" сөзіндегі "-ым" — ___ жалғау.',
        bank: ['тәуелдік', 'көптік', 'септік', 'жіктік'],
        correctWord: 'тәуелдік',
      },
    ],
  },
  {
    id: 'kaz5_n05',
    titleKz: '🐉 Босс: Тіл алыбы',
    descriptionKz: 'Тіл тарауының бірінші боссы.',
    type: 'boss',
    questions: [
      {
        id: 'kaz5_n05_q1',
        type: 'multiple_choice',
        questionKz: '"Мұғалім" сөзіндегі түбір:',
        options: ['мұға', 'мұғал', 'мұғалім', 'лім'],
        correctIndex: 2,
      },
      {
        id: 'kaz5_n05_q2',
        type: 'true_false',
        statementKz: 'Қазақ тілінде үндестік заңы маңызды.',
        isTrue: true,
      },
      {
        id: 'kaz5_n05_q3',
        type: 'fill_in_blank',
        sentenceKz: '"Қыс-ы" сөзіндегі "-ы" — ___ жалғау.',
        bank: ['тәуелдік', 'көптік', 'жіктік', 'септік'],
        correctWord: 'тәуелдік',
      },
      {
        id: 'kaz5_n05_q4',
        type: 'multiple_choice',
        questionKz: 'Қандай дыбыс жуан да жіңішке де бола алады?',
        options: ['а', 'е', 'у', 'и'],
        correctIndex: 2,
      },
    ],
  },
];

// ============================================================================
// ENGLISH
// ============================================================================

const ENGLISH_GRADE5: readonly NodeShorthand[] = [
  {
    id: 'eng5_n01',
    titleKz: 'Greetings — Сәлемдесу',
    descriptionKz: 'Hello, Hi, Good morning, Good evening.',
    type: 'lesson',
    questions: [
      {
        id: 'eng5_n01_q1',
        type: 'multiple_choice',
        questionKz: '"Сәлем" дегеннің ағылшынша баламасы?',
        options: ['Bye', 'Hello', 'Yes', 'No'],
        correctIndex: 1,
      },
      {
        id: 'eng5_n01_q2',
        type: 'multiple_choice',
        questionKz: '"Good morning" қашан айтылады?',
        options: ['Кешке', 'Таңертең', 'Түнде', 'Түсте'],
        correctIndex: 1,
      },
      {
        id: 'eng5_n01_q3',
        type: 'match_pairs',
        promptKz: 'Ағылшын сөзі мен қазақша баламасын сәйкестендір:',
        pairs: [
          { id: 'g1', leftKz: 'Hello', rightKz: 'Сәлем' },
          { id: 'g2', leftKz: 'Goodbye', rightKz: 'Қош' },
          { id: 'g3', leftKz: 'Thanks', rightKz: 'Рахмет' },
          { id: 'g4', leftKz: 'Sorry', rightKz: 'Кешір' },
        ],
      },
      {
        id: 'eng5_n01_q4',
        type: 'true_false',
        statementKz: '"How are you?" — "Қалың қалай?" дегенді білдіреді.',
        isTrue: true,
      },
    ],
  },
  {
    id: 'eng5_n02',
    titleKz: 'Numbers — Сандар',
    descriptionKz: 'One, two, three, ten, twenty.',
    type: 'lesson',
    questions: [
      {
        id: 'eng5_n02_q1',
        type: 'multiple_choice',
        questionKz: '"Үш" ағылшынша қалай?',
        options: ['Two', 'Three', 'Four', 'Five'],
        correctIndex: 1,
      },
      {
        id: 'eng5_n02_q2',
        type: 'fill_in_blank',
        sentenceKz: '"Жеті" — ___ ағылшынша.',
        bank: ['Six', 'Seven', 'Eight', 'Nine'],
        correctWord: 'Seven',
      },
      {
        id: 'eng5_n02_q3',
        type: 'multiple_choice',
        questionKz: '"Twenty" қазақша:',
        options: ['Он', 'Жиырма', 'Отыз', 'Қырық'],
        correctIndex: 1,
      },
      {
        id: 'eng5_n02_q4',
        type: 'match_pairs',
        promptKz: 'Сан сәйкестендіру:',
        pairs: [
          { id: 'n1', leftKz: 'One', rightKz: 'Бір' },
          { id: 'n2', leftKz: 'Five', rightKz: 'Бес' },
          { id: 'n3', leftKz: 'Ten', rightKz: 'Он' },
          { id: 'n4', leftKz: 'Hundred', rightKz: 'Жүз' },
        ],
      },
    ],
  },
  {
    id: 'eng5_n03',
    titleKz: 'Colors — Түстер',
    descriptionKz: 'Red, blue, green, yellow, black, white.',
    type: 'lesson',
    questions: [
      {
        id: 'eng5_n03_q1',
        type: 'multiple_choice',
        questionKz: '"Қызыл" ағылшынша?',
        options: ['Blue', 'Green', 'Red', 'Yellow'],
        correctIndex: 2,
      },
      {
        id: 'eng5_n03_q2',
        type: 'multiple_choice',
        questionKz: '"Қара" ағылшынша?',
        options: ['White', 'Black', 'Gray', 'Brown'],
        correctIndex: 1,
      },
      {
        id: 'eng5_n03_q3',
        type: 'fill_in_blank',
        sentenceKz: '"Көк" — ___.',
        bank: ['Blue', 'Yellow', 'Pink', 'Green'],
        correctWord: 'Blue',
      },
      {
        id: 'eng5_n03_q4',
        type: 'true_false',
        statementKz: '"Green" — "жасыл" деген сөз.',
        isTrue: true,
      },
    ],
  },
  {
    id: 'eng5_n04',
    titleKz: 'Family — Отбасы',
    descriptionKz: 'Mother, father, sister, brother.',
    type: 'quiz',
    questions: [
      {
        id: 'eng5_n04_q1',
        type: 'multiple_choice',
        questionKz: '"Mother" — ?',
        options: ['Әке', 'Ана', 'Аға', 'Әпке'],
        correctIndex: 1,
      },
      {
        id: 'eng5_n04_q2',
        type: 'match_pairs',
        promptKz: 'Сөз сәйкестендіру:',
        pairs: [
          { id: 'f1', leftKz: 'Father', rightKz: 'Әке' },
          { id: 'f2', leftKz: 'Sister', rightKz: 'Әпке' },
          { id: 'f3', leftKz: 'Brother', rightKz: 'Аға' },
          { id: 'f4', leftKz: 'Grandma', rightKz: 'Әже' },
        ],
      },
      {
        id: 'eng5_n04_q3',
        type: 'multiple_choice',
        questionKz: '"Family" дегеніміз?',
        options: ['Достар', 'Отбасы', 'Көрші', 'Мектеп'],
        correctIndex: 1,
      },
    ],
  },
  {
    id: 'eng5_n05',
    titleKz: '🐉 Босс: English Master',
    descriptionKz: 'Бастапқы тарау боссы.',
    type: 'boss',
    questions: [
      {
        id: 'eng5_n05_q1',
        type: 'multiple_choice',
        questionKz: '"My name is ..." қалай аяқталады?',
        options: ['... a book', '... Aidana', '... red', '... yes'],
        correctIndex: 1,
      },
      {
        id: 'eng5_n05_q2',
        type: 'true_false',
        statementKz: '"Yes" — "Иә" дегенді білдіреді.',
        isTrue: true,
      },
      {
        id: 'eng5_n05_q3',
        type: 'fill_in_blank',
        sentenceKz: '"I am ___ years old." (12)',
        bank: ['twelve', 'eleven', 'ten', 'thirteen'],
        correctWord: 'twelve',
      },
      {
        id: 'eng5_n05_q4',
        type: 'multiple_choice',
        questionKz: '"Thank you" — қазақша?',
        options: ['Кешірім', 'Сау бол', 'Рахмет', 'Сәлем'],
        correctIndex: 2,
      },
    ],
  },
];

// ============================================================================
// PHYSICS
// ============================================================================

const PHYSICS_GRADE7: readonly NodeShorthand[] = [
  {
    id: 'phy7_n01',
    titleKz: 'Физика дегеніміз не?',
    descriptionKz: 'Табиғат заңдары туралы ғылым.',
    type: 'lesson',
    questions: [
      {
        id: 'phy7_n01_q1',
        type: 'multiple_choice',
        questionKz: 'Физика нені зерттейді?',
        options: ['Тірі организмдер', 'Табиғат заңдары', 'Сөздер', 'Тарих'],
        correctIndex: 1,
      },
      {
        id: 'phy7_n01_q2',
        type: 'true_false',
        statementKz: 'Гравитация — физикалық құбылыс.',
        isTrue: true,
      },
      {
        id: 'phy7_n01_q3',
        type: 'multiple_choice',
        questionKz: 'Жарық физикасы қандай саланы зерттейді?',
        options: ['Механика', 'Оптика', 'Термодинамика', 'Электр'],
        correctIndex: 1,
      },
      {
        id: 'phy7_n01_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Уақыт өлшем бірлігі — ___.',
        bank: ['секунд', 'метр', 'грамм', 'ампер'],
        correctWord: 'секунд',
      },
    ],
  },
  {
    id: 'phy7_n02',
    titleKz: 'Жылдамдық',
    descriptionKz: 'v = s / t формуласы.',
    type: 'lesson',
    questions: [
      {
        id: 'phy7_n02_q1',
        type: 'multiple_choice',
        questionKz: 'Жылдамдықтың өлшем бірлігі (SI)?',
        options: ['кг', 'м/с', 'Н', 'Дж'],
        correctIndex: 1,
      },
      {
        id: 'phy7_n02_q2',
        type: 'multiple_choice',
        questionKz: '120 км/сағ-ты м/с-қа айналдыр (шамамен):',
        options: ['12', '20', '33', '50'],
        correctIndex: 2,
      },
      {
        id: 'phy7_n02_q3',
        type: 'fill_in_blank',
        sentenceKz: '100 м-ді 20 с-та жүзіп өткен, жылдамдық = ___ м/с.',
        bank: ['2', '4', '5', '10'],
        correctWord: '5',
      },
      {
        id: 'phy7_n02_q4',
        type: 'true_false',
        statementKz: 'Жылдамдық = жол / уақыт.',
        isTrue: true,
      },
    ],
  },
  {
    id: 'phy7_n03',
    titleKz: 'Күштер',
    descriptionKz: 'Ньютон заңдары, ауырлық күші.',
    type: 'lesson',
    questions: [
      {
        id: 'phy7_n03_q1',
        type: 'multiple_choice',
        questionKz: 'Күштің өлшем бірлігі?',
        options: ['Ампер', 'Джоуль', 'Ньютон', 'Ватт'],
        correctIndex: 2,
      },
      {
        id: 'phy7_n03_q2',
        type: 'multiple_choice',
        questionKz: 'Жерде ауырлық үдеуі шамамен қанша?',
        options: ['5 м/с²', '7 м/с²', '9.8 м/с²', '20 м/с²'],
        correctIndex: 2,
      },
      {
        id: 'phy7_n03_q3',
        type: 'true_false',
        statementKz: 'Ньютонның бірінші заңы инерция заңы деп аталады.',
        isTrue: true,
      },
      {
        id: 'phy7_n03_q4',
        type: 'fill_in_blank',
        sentenceKz: 'F = m · ___ — Ньютонның екінші заңы.',
        bank: ['a', 'v', 's', 't'],
        correctWord: 'a',
      },
    ],
  },
  {
    id: 'phy7_n04',
    titleKz: 'Энергия',
    descriptionKz: 'Кинетикалық, потенциалдық энергия.',
    type: 'quiz',
    questions: [
      {
        id: 'phy7_n04_q1',
        type: 'multiple_choice',
        questionKz: 'Энергияның өлшем бірлігі?',
        options: ['Джоуль', 'Ньютон', 'Метр', 'Ом'],
        correctIndex: 0,
      },
      {
        id: 'phy7_n04_q2',
        type: 'true_false',
        statementKz: 'Қозғалыс энергиясы — кинетикалық энергия деп аталады.',
        isTrue: true,
      },
      {
        id: 'phy7_n04_q3',
        type: 'multiple_choice',
        questionKz: 'Биіктікке көтерілген дененің энергиясы — ?',
        options: ['Кинетикалық', 'Потенциалдық', 'Жылулық', 'Жарық'],
        correctIndex: 1,
      },
      {
        id: 'phy7_n04_q4',
        type: 'fill_in_blank',
        sentenceKz: 'Энергия сақталу заңы: жалпы энергия ___.',
        bank: ['жоғалмайды', 'өседі', 'азаяды', 'жоғалады'],
        correctWord: 'жоғалмайды',
      },
    ],
  },
  {
    id: 'phy7_n05',
    titleKz: '🐉 Босс: Физика күші',
    descriptionKz: 'Бастапқы физика боссы.',
    type: 'boss',
    questions: [
      {
        id: 'phy7_n05_q1',
        type: 'multiple_choice',
        questionKz: '60 км/сағ — м/с-та шамамен:',
        options: ['10', '17', '20', '30'],
        correctIndex: 1,
      },
      { id: 'phy7_n05_q2', type: 'true_false', statementKz: 'Күш — векторлық шама.', isTrue: true },
      {
        id: 'phy7_n05_q3',
        type: 'fill_in_blank',
        sentenceKz: 'Қуат = ___ / уақыт.',
        bank: ['жұмыс', 'күш', 'масса', 'жол'],
        correctWord: 'жұмыс',
      },
      {
        id: 'phy7_n05_q4',
        type: 'multiple_choice',
        questionKz: 'Қайсысы — энергияның түрі емес?',
        options: ['Кинетикалық', 'Потенциалдық', 'Тауарлық', 'Жылулық'],
        correctIndex: 2,
      },
      {
        id: 'phy7_n05_q5',
        type: 'match_pairs',
        promptKz: 'Шама мен өлшем бірлігін сәйкестендір:',
        pairs: [
          { id: 'ph1', leftKz: 'Күш', rightKz: 'Ньютон' },
          { id: 'ph2', leftKz: 'Жұмыс', rightKz: 'Джоуль' },
          { id: 'ph3', leftKz: 'Қуат', rightKz: 'Ватт' },
          { id: 'ph4', leftKz: 'Уақыт', rightKz: 'Секунд' },
        ],
      },
    ],
  },
];

// ============================================================================
// CURRICULUM
// ============================================================================

export const CURRICULUM: readonly Subject[] = [
  {
    id: 'mathematics',
    nameKz: 'Математика',
    icon: '🧮',
    color: '#4A6CF7',
    colorLight: '#7B9BFF',
    descriptionKz: 'Сандар әлеміндегі шытырман.',
    modules: [
      {
        id: 'math_g5',
        titleKz: '5-сынып: Сан патшалығы',
        grade: 5,
        descriptionKz: 'Натурал сандар, амалдар, бөлшектердің кіріспесі.',
        nodes: buildNodes(MATH_GRADE5),
      },
    ],
  },
  {
    id: 'kazakh',
    nameKz: 'Қазақ тілі',
    icon: '📚',
    color: '#00C48C',
    colorLight: '#3DDC97',
    descriptionKz: 'Ана тілінің құпиялары.',
    modules: [
      {
        id: 'kaz_g5',
        titleKz: '5-сынып: Тіл байлығы',
        grade: 5,
        descriptionKz: 'Әліпби, дыбыстар, сөз құрамы.',
        nodes: buildNodes(KAZAKH_GRADE5),
      },
    ],
  },
  {
    id: 'english',
    nameKz: 'Ағылшын тілі',
    icon: '🌎',
    color: '#FF4757',
    colorLight: '#FF6B7B',
    descriptionKz: 'English is the world language.',
    modules: [
      {
        id: 'eng_g5',
        titleKz: '5-сынып: First steps in English',
        grade: 5,
        descriptionKz: 'Greetings, numbers, colors, family.',
        nodes: buildNodes(ENGLISH_GRADE5),
      },
    ],
  },
  {
    id: 'physics',
    nameKz: 'Физика',
    icon: '⚛️',
    color: '#FFA502',
    colorLight: '#FFB733',
    descriptionKz: 'Дүниенің іргелі заңдары.',
    modules: [
      {
        id: 'phy_g7',
        titleKz: '7-сынып: Қозғалыс пен күш',
        grade: 7,
        descriptionKz: 'Жылдамдық, күш, энергия.',
        nodes: buildNodes(PHYSICS_GRADE7),
      },
    ],
  },
  {
    id: 'informatics',
    nameKz: 'Информатика',
    icon: '💻',
    color: '#607D8B',
    colorLight: '#90A4AE',
    descriptionKz: 'Цифрлық әлемге саяхат.',
    modules: [
      {
        id: 'inf_g5',
        titleKz: '5-сынып: Цифрлық бастамалар',
        grade: 5,
        descriptionKz: 'Компьютер, пернетақта, ОЖ, файлдар.',
        nodes: buildNodes(INFORMATICS_GRADE5),
      },
      {
        id: 'inf_g7',
        titleKz: '7-сынып: Сандық әлем',
        grade: 7,
        descriptionKz: 'Интернет, смартфондар, AI, Python, Kaspi.',
        nodes: buildNodes(INFORMATICS_GRADE7),
      },
    ],
  },
];

// ----------------------------------------------------------------------------
// Lookup helpers
// ----------------------------------------------------------------------------

const subjectIndex = new Map<string, Subject>(CURRICULUM.map((s) => [s.id, s]));

export const getSubject = (subjectId: string): Subject | undefined => subjectIndex.get(subjectId);

export const getModule = (subjectId: string, moduleId: string): CurriculumModule | undefined => {
  const s = subjectIndex.get(subjectId);
  return s?.modules.find((m) => m.id === moduleId);
};

export const getNode = (
  subjectId: string,
  moduleId: string,
  nodeId: string,
): CurriculumNode | undefined => {
  const m = getModule(subjectId, moduleId);
  return m?.nodes.find((n) => n.id === nodeId);
};

// Total number of nodes across all modules of a subject — used for "X / Y" labels.
export const countSubjectNodes = (subjectId: string): number => {
  const s = subjectIndex.get(subjectId);
  if (!s) return 0;
  return s.modules.reduce((acc, m) => acc + m.nodes.length, 0);
};

// Flat, in-display-order list of (module, node) pairs for a subject — used by
// the MapScreen and progression logic (the next node unlocks after the prior
// completes regardless of which module boundary lies between them).
export interface FlatNodeEntry {
  module: CurriculumModule;
  node: CurriculumNode;
  globalOrder: number; // 1-based position in the full subject sequence
}

export const flattenSubject = (subjectId: string): readonly FlatNodeEntry[] => {
  const s = subjectIndex.get(subjectId);
  if (!s) return [];
  const out: FlatNodeEntry[] = [];
  let order = 0;
  for (const module of s.modules) {
    for (const node of module.nodes) {
      order += 1;
      out.push({ module, node, globalOrder: order });
    }
  }
  return out;
};
