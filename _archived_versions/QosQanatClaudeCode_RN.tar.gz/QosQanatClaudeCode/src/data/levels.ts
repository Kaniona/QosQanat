// ----------------------------------------------------------------------------
// Level table (1..100) with Kazakh titles.
//
// XP curve:
//   xpRequired(n) = (n-1)*100 + (n-1)^2 * 10
//   - This is the TOTAL XP needed to *reach* level n from level 1.
//   - Level 1 starts at 0 XP, level 2 needs 110 XP, level 3 needs 240, etc.
//
// Coin bonus on level-up: coins = level * 20
// ----------------------------------------------------------------------------

export const MAX_LEVEL = 100;

export interface LevelInfo {
  level: number;
  title: string; // Kazakh title
  xpRequired: number; // cumulative XP to enter this level
  xpForNext: number; // delta XP between this level and next (0 at max)
  coinReward: number; // coins granted when reaching this level
}

const TITLE_RANGES: readonly { min: number; max: number; title: string }[] = [
  { min: 1, max: 5, title: 'Жас оқушы' },
  { min: 6, max: 10, title: 'Білімгер' },
  { min: 11, max: 15, title: 'Ақылды оқушы' },
  { min: 16, max: 20, title: 'Білімдар' },
  { min: 21, max: 30, title: 'Данышпан шәкірт' },
  { min: 31, max: 40, title: 'Озық оқушы' },
  { min: 41, max: 50, title: 'Білімнің шебері' },
  { min: 51, max: 60, title: 'Ғалым шәкірт' },
  { min: 61, max: 75, title: 'Данышпан' },
  { min: 76, max: 90, title: 'Ұлы оқушы' },
  { min: 91, max: 99, title: 'Легенда' },
  { min: 100, max: 100, title: 'QosQanat Чемпионы' },
];

const titleForLevel = (level: number): string => {
  for (const range of TITLE_RANGES) {
    if (level >= range.min && level <= range.max) return range.title;
  }
  return TITLE_RANGES[0].title;
};

export const xpRequiredFor = (level: number): number => {
  if (level <= 1) return 0;
  const n = level - 1;
  return n * 100 + n * n * 10;
};

const buildTable = (): readonly LevelInfo[] => {
  const table: LevelInfo[] = [];
  for (let level = 1; level <= MAX_LEVEL; level += 1) {
    const xpRequired = xpRequiredFor(level);
    const xpForNext = level < MAX_LEVEL ? xpRequiredFor(level + 1) - xpRequired : 0;
    table.push({
      level,
      title: titleForLevel(level),
      xpRequired,
      xpForNext,
      coinReward: level * 20,
    });
  }
  return table;
};

export const LEVELS: readonly LevelInfo[] = buildTable();

export const getLevelInfo = (level: number): LevelInfo => {
  const clamped = Math.max(1, Math.min(MAX_LEVEL, Math.floor(level)));
  return LEVELS[clamped - 1];
};

// Highest level whose xpRequired threshold the given total XP has crossed.
export const calculateLevel = (totalXp: number): number => {
  const xp = Math.max(0, Math.floor(totalXp));
  // Linear scan is fine for n=100; keeps the code obvious.
  let result = 1;
  for (let level = 1; level <= MAX_LEVEL; level += 1) {
    if (xp >= LEVELS[level - 1].xpRequired) result = level;
    else break;
  }
  return result;
};

// Convenience: given totalXp, return progress within the current level and
// how much more XP is needed to advance.
export interface LevelProgress {
  level: number;
  title: string;
  xpIntoLevel: number; // XP earned since reaching `level`
  xpForNextLevel: number; // total XP needed to move from `level` to `level+1`
  xpToNextLevel: number; // remaining XP to next level (0 at MAX_LEVEL)
  progress: number; // 0..1 fraction of current bar filled
  coinReward: number;
}

export const getLevelProgress = (totalXp: number): LevelProgress => {
  const level = calculateLevel(totalXp);
  const info = getLevelInfo(level);
  const xpIntoLevel = Math.max(0, totalXp - info.xpRequired);
  const xpForNextLevel = info.xpForNext;
  const xpToNextLevel = xpForNextLevel === 0 ? 0 : Math.max(0, xpForNextLevel - xpIntoLevel);
  const progress = xpForNextLevel === 0 ? 1 : Math.min(1, xpIntoLevel / xpForNextLevel);
  return {
    level,
    title: info.title,
    xpIntoLevel,
    xpForNextLevel,
    xpToNextLevel,
    progress,
    coinReward: info.coinReward,
  };
};
