import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';

// ----------------------------------------------------------------------------
// Settings store
//
// Client-only preferences (language, sound, vibration, notifications, etc.).
// Persisted in AsyncStorage under the key `qosqanat:settings` so they survive
// app restarts but stay on-device (the schema reserves a `users` row for the
// player's economy + identity only).
// ----------------------------------------------------------------------------

export type Language = 'kk' | 'ru';

export interface Settings {
  language: Language;
  sound: boolean;
  vibration: boolean;
  animations: boolean;
  darkMode: boolean;
  notifyFriendRequests: boolean;
  notifyBattleInvites: boolean;
  notifyQuestComplete: boolean;
  notifyStreakReminder: boolean;
  streakReminderHour: number; // 0..23
  onboarded: boolean; // welcome tour complete?
}

const DEFAULTS: Settings = {
  language: 'kk',
  sound: true,
  vibration: true,
  animations: true,
  darkMode: true,
  notifyFriendRequests: true,
  notifyBattleInvites: true,
  notifyQuestComplete: true,
  notifyStreakReminder: true,
  streakReminderHour: 19,
  onboarded: false,
};

const STORAGE_KEY = 'qosqanat:settings';

interface SettingsState extends Settings {
  hydrated: boolean;
  hydrate: () => Promise<void>;
  setSetting: <K extends keyof Settings>(key: K, value: Settings[K]) => Promise<void>;
  resetSettings: () => Promise<void>;
}

const persist = async (state: Settings): Promise<void> => {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Soft-fail: persistence is best-effort.
  }
};

export const useSettingsStore = create<SettingsState>((set, get) => ({
  ...DEFAULTS,
  hydrated: false,

  hydrate: async () => {
    if (get().hydrated) return;
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<Settings>;
        set({ ...DEFAULTS, ...parsed, hydrated: true });
        return;
      }
    } catch {
      // ignore
    }
    set({ hydrated: true });
  },

  setSetting: async (key, value) => {
    set({ [key]: value } as Partial<SettingsState>);
    const snapshot: Settings = {
      language: get().language,
      sound: get().sound,
      vibration: get().vibration,
      animations: get().animations,
      darkMode: get().darkMode,
      notifyFriendRequests: get().notifyFriendRequests,
      notifyBattleInvites: get().notifyBattleInvites,
      notifyQuestComplete: get().notifyQuestComplete,
      notifyStreakReminder: get().notifyStreakReminder,
      streakReminderHour: get().streakReminderHour,
      onboarded: get().onboarded,
    };
    await persist(snapshot);
  },

  resetSettings: async () => {
    set({ ...DEFAULTS, hydrated: true });
    await persist(DEFAULTS);
  },
}));
