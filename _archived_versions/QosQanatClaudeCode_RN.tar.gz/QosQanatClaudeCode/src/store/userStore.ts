import { create } from 'zustand';

import { supabase } from '@/services/supabase';
import type { User } from '@/types';

interface UserState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;

  setUser: (user: User | null) => void;
  updateUser: (patch: Partial<User>) => void;
  /** @deprecated kept for backwards compatibility — use updateUser */
  patchUser: (patch: Partial<User>) => void;
  loadUser: () => Promise<User | null>;
  logout: () => Promise<void>;
  clear: () => void;
}

export const useUserStore = create<UserState>((set, get) => ({
  user: null,
  isLoading: false,
  isAuthenticated: false,

  setUser: (user) => { set({ user, isAuthenticated: !!user }); },

  updateUser: (patch) =>
    { set((state) => ({
      user: state.user ? { ...state.user, ...patch } : null,
    })); },

  patchUser: (patch) => { get().updateUser(patch); },

  loadUser: async () => {
    set({ isLoading: true });
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const session = sessionData.session;
      if (!session) {
        set({ user: null, isAuthenticated: false });
        return null;
      }
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', session.user.id)
        .maybeSingle();
      if (error) throw error;
      const user = (data as User | null) ?? null;
      set({ user, isAuthenticated: !!user });
      return user;
    } finally {
      set({ isLoading: false });
    }
  },

  logout: async () => {
    await supabase.auth.signOut();
    set({ user: null, isAuthenticated: false });
  },

  clear: () => { set({ user: null, isAuthenticated: false }); },
}));
