import { create } from 'zustand';

import { calculateLevel, getLevelInfo, getLevelProgress, MAX_LEVEL } from '@/data/levels';
import { milestoneFor } from '@/data/quests';
import { supabase } from '@/services/supabase';
import type { User } from '@/types';

import { useUserStore } from './userStore';

// ----------------------------------------------------------------------------
// Game store
//
// Source-of-truth for the player's economy / progression on the client:
//   level, xp (cumulative), xpToNextLevel, coins, akylPoints, streak.
//
// All mutating actions optimistically update local state, then PATCH the
// corresponding fields on public.users in Supabase, and finally mirror the
// change into userStore so the User object stays consistent for UI that reads
// from useUserStore.
//
// If a Supabase write fails the local state is *not* rolled back — the next
// loadUser/setGameState will re-hydrate from server truth. We prefer this over
// a flicker on the UI for a transient network error.
// ----------------------------------------------------------------------------

export interface LevelUpResult {
  leveledUp: boolean;
  fromLevel: number;
  toLevel: number;
  coinReward: number; // coins awarded by the level bonus
  title: string;
}

export interface StreakResult {
  continued: boolean; // false = streak reset to 1
  streak: number;
  milestoneReward: number; // 0 if no milestone reached this update
  milestoneTitleKz?: string;
}

interface GameState {
  level: number;
  xp: number; // total cumulative XP
  xpToNextLevel: number; // remaining XP to reach next level
  coins: number;
  akylPoints: number;
  currentStreak: number;
  longestStreak: number;
  lastLoginDate: string | null; // YYYY-MM-DD

  // Set whenever `addXP()` / `levelUp()` results in `leveledUp === true`.
  // A global LevelUpModal subscribes to this and renders an overlay; the
  // overlay then calls `clearPendingLevelUp()` once dismissed.
  pendingLevelUp: LevelUpResult | null;

  setGameState: (user: User) => void;
  addXP: (amount: number) => Promise<LevelUpResult>;
  addCoins: (amount: number) => Promise<void>;
  addAkylPoints: (amount: number) => Promise<void>;
  spendCoins: (amount: number) => Promise<boolean>;
  levelUp: (toLevel: number) => Promise<LevelUpResult>;
  checkStreak: () => Promise<StreakResult>;
  clearPendingLevelUp: () => void;
  reset: () => void;
}

const todayISO = (): string => {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
};

const daysBetween = (from: string, to: string): number => {
  const a = new Date(`${from}T00:00:00Z`).getTime();
  const b = new Date(`${to}T00:00:00Z`).getTime();
  return Math.round((b - a) / 86_400_000);
};

const persistUserPatch = async (patch: Partial<User>): Promise<void> => {
  const user = useUserStore.getState().user;
  if (!user) return;
  const { error } = await supabase.from('users').update(patch).eq('id', user.id);
  if (error) throw error;
  useUserStore.getState().updateUser(patch);
};

export const useGameStore = create<GameState>((set, get) => ({
  level: 1,
  xp: 0,
  xpToNextLevel: getLevelInfo(1).xpForNext,
  coins: 0,
  akylPoints: 0,
  currentStreak: 0,
  longestStreak: 0,
  lastLoginDate: null,
  pendingLevelUp: null,

  setGameState: (user) => {
    const progress = getLevelProgress(user.xp);
    set({
      level: user.level,
      xp: user.xp,
      xpToNextLevel: progress.xpToNextLevel,
      coins: user.coins,
      akylPoints: user.akyl_points,
      currentStreak: user.current_streak,
      longestStreak: user.longest_streak,
      lastLoginDate: user.last_login_date ?? null,
    });
  },

  addXP: async (amount) => {
    if (amount <= 0) {
      const cur = get();
      return {
        leveledUp: false,
        fromLevel: cur.level,
        toLevel: cur.level,
        coinReward: 0,
        title: getLevelInfo(cur.level).title,
      };
    }

    const fromLevel = get().level;
    const newXp = get().xp + amount;
    const toLevel = calculateLevel(newXp);
    const leveledUp = toLevel > fromLevel;

    // Sum coin bonuses for every level the player crossed in one go.
    let coinReward = 0;
    if (leveledUp) {
      for (let lvl = fromLevel + 1; lvl <= toLevel; lvl += 1) {
        coinReward += getLevelInfo(lvl).coinReward;
      }
    }

    const newCoins = get().coins + coinReward;
    const progress = getLevelProgress(newXp);

    set({
      xp: newXp,
      level: toLevel,
      xpToNextLevel: progress.xpToNextLevel,
      coins: newCoins,
    });

    const patch: Partial<User> = { xp: newXp, level: toLevel };
    if (coinReward > 0) patch.coins = newCoins;
    await persistUserPatch(patch);

    const result: LevelUpResult = {
      leveledUp,
      fromLevel,
      toLevel,
      coinReward,
      title: getLevelInfo(toLevel).title,
    };
    if (leveledUp) set({ pendingLevelUp: result });
    return result;
  },

  addCoins: async (amount) => {
    if (amount === 0) return;
    const newCoins = Math.max(0, get().coins + amount);
    set({ coins: newCoins });
    await persistUserPatch({ coins: newCoins });
  },

  addAkylPoints: async (amount) => {
    if (amount === 0) return;
    const newAkyl = Math.max(0, get().akylPoints + amount);
    set({ akylPoints: newAkyl });
    await persistUserPatch({ akyl_points: newAkyl });
  },

  spendCoins: async (amount) => {
    if (amount <= 0) return true;
    if (get().coins < amount) return false;
    const newCoins = get().coins - amount;
    set({ coins: newCoins });
    try {
      await persistUserPatch({ coins: newCoins });
    } catch (err) {
      // Roll back local cache on failure; spending is the one case where a
      // mismatched balance is more dangerous than a UI flicker.
      set({ coins: newCoins + amount });
      throw err;
    }
    return true;
  },

  levelUp: async (toLevel) => {
    const fromLevel = get().level;
    const clamped = Math.max(1, Math.min(MAX_LEVEL, Math.floor(toLevel)));
    if (clamped <= fromLevel) {
      return {
        leveledUp: false,
        fromLevel,
        toLevel: fromLevel,
        coinReward: 0,
        title: getLevelInfo(fromLevel).title,
      };
    }
    let coinReward = 0;
    for (let lvl = fromLevel + 1; lvl <= clamped; lvl += 1) {
      coinReward += getLevelInfo(lvl).coinReward;
    }
    const minXp = getLevelInfo(clamped).xpRequired;
    const newXp = Math.max(get().xp, minXp);
    const newCoins = get().coins + coinReward;
    const progress = getLevelProgress(newXp);

    set({
      level: clamped,
      xp: newXp,
      xpToNextLevel: progress.xpToNextLevel,
      coins: newCoins,
    });

    await persistUserPatch({ level: clamped, xp: newXp, coins: newCoins });

    const result: LevelUpResult = {
      leveledUp: true,
      fromLevel,
      toLevel: clamped,
      coinReward,
      title: getLevelInfo(clamped).title,
    };
    set({ pendingLevelUp: result });
    return result;
  },

  clearPendingLevelUp: () => { set({ pendingLevelUp: null }); },

  checkStreak: async () => {
    const today = todayISO();
    const last = get().lastLoginDate;
    let continued = true;
    let nextStreak = 1;

    if (!last) {
      nextStreak = 1;
    } else {
      const diff = daysBetween(last, today);
      if (diff === 0) {
        // Already counted today — no change, no milestone.
        return { continued: true, streak: get().currentStreak, milestoneReward: 0 };
      }
      if (diff === 1) {
        nextStreak = get().currentStreak + 1;
        continued = true;
      } else {
        nextStreak = 1;
        continued = false;
      }
    }

    const newLongest = Math.max(get().longestStreak, nextStreak);
    const milestone = milestoneFor(nextStreak);
    const milestoneReward = milestone?.rewardCoins ?? 0;
    const newCoins = get().coins + milestoneReward;

    set({
      currentStreak: nextStreak,
      longestStreak: newLongest,
      lastLoginDate: today,
      coins: newCoins,
    });

    const patch: Partial<User> = {
      current_streak: nextStreak,
      longest_streak: newLongest,
      last_login_date: today,
    };
    if (milestoneReward > 0) patch.coins = newCoins;
    await persistUserPatch(patch);

    return {
      continued,
      streak: nextStreak,
      milestoneReward,
      milestoneTitleKz: milestone?.titleKz,
    };
  },

  reset: () =>
    { set({
      level: 1,
      xp: 0,
      xpToNextLevel: getLevelInfo(1).xpForNext,
      coins: 0,
      akylPoints: 0,
      currentStreak: 0,
      longestStreak: 0,
      lastLoginDate: null,
      pendingLevelUp: null,
    }); },
}));
