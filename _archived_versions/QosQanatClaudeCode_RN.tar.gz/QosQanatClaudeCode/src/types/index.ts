export type AssistantType = 'bektur' | 'nazym';
export type NodeType = 'lesson' | 'quiz' | 'boss' | 'treasure';
export type ItemCategory = 'top' | 'bottom' | 'hat' | 'accessory' | 'pet';
export type Rarity = 'common' | 'rare' | 'epic' | 'legendary';

export interface User {
  id: string;
  qosqanat_id: string;
  full_name: string;
  phone: string;
  iin: string;
  city: string;
  school: string;
  grade: number;
  assistant_type: AssistantType;
  level: number;
  xp: number;
  coins: number;
  akyl_points: number;
  current_streak: number;
  longest_streak: number;
  last_login_date: string | null;
  total_tasks_completed: number;
  total_battles_won: number;
  total_battles_played: number;
  created_at: string;
}

export interface TaskNode {
  id: string;
  subject_id: string;
  module_id: string;
  title_kz: string;
  description_kz: string;
  type: NodeType;
  xp_reward: number;
  coin_reward: number;
  akyl_reward: number;
  order: number;
}

export interface ShopItem {
  id: string;
  name_kz: string;
  category: ItemCategory;
  price: number;
  level_required: number;
  rarity: Rarity;
  is_default: boolean;
  for_assistant?: AssistantType;
}

export interface Quest {
  id: string;
  title_kz: string;
  description_kz: string;
  target: number;
  reward_coins: number;
  reward_xp: number;
  reward_akyl: number;
  icon: string;
}

export interface Achievement {
  id: string;
  title_kz: string;
  description_kz: string;
  icon: string;
  reward_coins: number;
}
