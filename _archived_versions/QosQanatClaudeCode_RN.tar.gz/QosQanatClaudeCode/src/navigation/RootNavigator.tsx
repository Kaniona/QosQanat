import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';

import BattleResultScreen from '@/screens/Battle/BattleResultScreen';
import BattleScreen from '@/screens/Battle/BattleScreen';
import BattleSetupScreen from '@/screens/Battle/BattleSetupScreen';
import BattleWaitingScreen from '@/screens/Battle/BattleWaitingScreen';
import MapScreen from '@/screens/learn/MapScreen';
import ResultScreen from '@/screens/learn/ResultScreen';
import TaskScreen from '@/screens/learn/TaskScreen';
import SettingsScreen from '@/screens/Profile/SettingsScreen';
import RatingScreen from '@/screens/Rating/RatingScreen';
import { loadSessionUser } from '@/services/auth';
import { useGameStore } from '@/store/gameStore';
import { useSettingsStore } from '@/store/settingsStore';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, spacing } from '@/theme';

import AuthNavigator from './AuthNavigator';
import MainNavigator from './MainNavigator';
import type { MainStackParamList } from './types';

// ---- Push / modal screens that sit on top of the bottom-tab navigator ----

// ----------------------------------------------------------------------------
// RootNavigator
//
// Reads `userStore.isAuthenticated` and switches between AuthNavigator
// (registration flow) and MainStackNavigator (post-login flow). The session
// is loaded once on mount via `loadSessionUser()` so a previously-signed-in
// user lands directly inside MainStackNavigator.
//
// On first launch we also read the `onboarded` flag from settingsStore —
// when an authenticated user hasn't completed onboarding yet we surface
// AuthNavigator (which lands at the Onboarding screen) instead of the tab nav.
// The onboarding screen sets the flag + grants the welcome coins itself.
// ----------------------------------------------------------------------------

const Stack = createNativeStackNavigator<MainStackParamList>();

const MainStackNavigator: React.FC = () => (
  <Stack.Navigator
    initialRouteName="Main"
    screenOptions={{ headerShown: false, animation: 'slide_from_right' }}
  >
    <Stack.Screen name="Main" component={MainNavigator} options={{ animation: 'fade' }} />
    <Stack.Screen name="Map" component={MapScreen} />
    <Stack.Screen
      name="Task"
      component={TaskScreen}
      options={{ animation: 'slide_from_bottom', gestureEnabled: false }}
    />
    <Stack.Screen
      name="Result"
      component={ResultScreen}
      options={{ animation: 'fade', gestureEnabled: false }}
    />
    <Stack.Screen name="Rating" component={RatingScreen} />
    <Stack.Screen name="Settings" component={SettingsScreen} />
    <Stack.Screen name="BattleSetup" component={BattleSetupScreen} />
    <Stack.Screen
      name="BattleWaiting"
      component={BattleWaitingScreen}
      options={{ animation: 'fade', gestureEnabled: false }}
    />
    <Stack.Screen
      name="Battle"
      component={BattleScreen}
      options={{ animation: 'fade', gestureEnabled: false }}
    />
    <Stack.Screen
      name="BattleResult"
      component={BattleResultScreen}
      options={{ animation: 'fade', gestureEnabled: false }}
    />
  </Stack.Navigator>
);

// ----------------------------------------------------------------------------
// Boot loader — silent splash with a centered spinner while we hydrate
// session + settings + onboarded flag.
// ----------------------------------------------------------------------------

const BootScreen: React.FC = () => (
  <View style={styles.boot}>
    <Text style={styles.bootBrand}>QosQanat</Text>
    <ActivityIndicator color={colors.white} size="large" />
    <Text style={styles.bootHint}>Жүктелуде...</Text>
  </View>
);

// ----------------------------------------------------------------------------
// RootNavigator
// ----------------------------------------------------------------------------

interface Props {
  /** Set to true once the global session loader has finished. */
  ready: boolean;
}

const RootNavigator: React.FC<Props> = ({ ready }) => {
  const isAuthenticated = useUserStore((s) => s.isAuthenticated);
  const user = useUserStore((s) => s.user);
  const onboarded = useSettingsStore((s) => s.onboarded);
  const setGameState = useGameStore((s) => s.setGameState);

  // Mirror the user's economy into gameStore the moment we have one.
  useEffect(() => {
    if (user) setGameState(user);
  }, [user, setGameState]);

  if (!ready) return <BootScreen />;
  if (!isAuthenticated || !onboarded) return <AuthNavigator />;
  return <MainStackNavigator />;
};

// ----------------------------------------------------------------------------
// Bootstrap hook — used by App.tsx to drive `<RootNavigator ready=...>`.
// ----------------------------------------------------------------------------

export const useRootBootstrap = (): { ready: boolean } => {
  const [ready, setReady] = useState(false);
  const hydrateSettings = useSettingsStore((s) => s.hydrate);

  useEffect(() => {
    let cancelled = false;
    const boot = async () => {
      try {
        await Promise.all([loadSessionUser(), hydrateSettings()]);
      } catch {
        // soft-fail; user lands on Welcome
      } finally {
        if (!cancelled) setReady(true);
      }
    };
    void boot();
    return () => {
      cancelled = true;
    };
  }, [hydrateSettings]);

  return { ready };
};

const styles = StyleSheet.create({
  boot: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1A1A4E',
    gap: spacing.md,
  },
  bootBrand: {
    color: colors.gold,
    fontSize: fontSize.huge,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 2,
    marginBottom: spacing.md,
  },
  bootHint: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
  },
});

export default RootNavigator;
