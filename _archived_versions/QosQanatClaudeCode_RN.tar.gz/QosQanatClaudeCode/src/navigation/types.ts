import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import type { NavigatorScreenParams } from '@react-navigation/native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

// ----------------------------------------------------------------------------
// Navigation parameter types
// ----------------------------------------------------------------------------
//
// Architecture:
//
//   RootNavigator (gated by userStore.isAuthenticated)
//   ├── AuthNavigator         (when NOT authenticated)
//   │     Splash → Welcome → Register → AssistantSelect → Onboarding
//   └── MainNavigator         (when authenticated, native stack)
//         Main (bottom tabs)  Home | Learn | Shop | Friends | Profile
//         + Modal/push screens:
//             Map, Task, Result, Rating, Settings,
//             BattleSetup, BattleWaiting, Battle, BattleResult
//
// `AuthStackParamList` is intentionally kept as a flat union of every
// reachable route in the app — every screen already imports it for its
// `useNavigation<NativeStackNavigationProp<AuthStackParamList>>()` typing,
// and re-typing each call site for the split navigators would create a lot
// of low-value churn. At runtime each individual navigator only registers
// a subset of these routes, and React Navigation will walk up parents to
// find the matching one.
// ----------------------------------------------------------------------------

export interface ResultParams {
  subjectId: string;
  moduleId: string;
  nodeId: string;
  scorePercent: number; // 0..100
  correctCount: number;
  totalQuestions: number;
  heartsLeft: number;
}

// ---- Auth flow (registration + onboarding) ---------------------------------

export interface AuthFlowParamList {
  Splash: undefined;
  Welcome: undefined;
  Register: undefined;
  AssistantSelect: undefined;
  Onboarding: undefined;
}

// ---- Main bottom-tab navigator --------------------------------------------

export interface MainTabParamList {
  Home: undefined;
  Learn: undefined;
  Shop: undefined;
  Friends: undefined;
  Profile: undefined;
}

// ---- Main stack (tabs + push/modal screens) -------------------------------

export interface MainStackParamList {
  Main: NavigatorScreenParams<MainTabParamList>;
  Map: { subjectId: string };
  Task: { subjectId: string; moduleId: string; nodeId: string };
  Result: ResultParams;
  Rating: undefined;
  Settings: undefined;
  BattleSetup: { opponentId: string };
  BattleWaiting: { battleId: string; role: 'challenger' | 'opponent' };
  Battle: { battleId: string };
  BattleResult: { battleId: string };
}

// ---- Flat union (legacy alias used by screens for type-safe navigate) -----

export type AuthStackParamList = AuthFlowParamList & MainStackParamList & MainTabParamList;

// ---- Screen props helpers --------------------------------------------------

// `AuthScreenProps` retains its name (legacy callers across the codebase use
// it) but is typed against the flat union so any screen — Splash, Map, Task,
// Settings — can call `navigate('Whatever', params)` without type errors.
export type AuthScreenProps<T extends keyof AuthStackParamList> = NativeStackScreenProps<
  AuthStackParamList,
  T
>;

export type AuthFlowScreenProps<T extends keyof AuthFlowParamList> = NativeStackScreenProps<
  AuthFlowParamList,
  T
>;

export type MainStackScreenProps<T extends keyof MainStackParamList> = NativeStackScreenProps<
  MainStackParamList,
  T
>;

export type MainTabScreenProps<T extends keyof MainTabParamList> = BottomTabScreenProps<
  MainTabParamList,
  T
>;

// Global augmentation so `useNavigation()` (no generic) returns the union.
declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace ReactNavigation {
    interface RootParamList extends AuthStackParamList {}
  }
}
