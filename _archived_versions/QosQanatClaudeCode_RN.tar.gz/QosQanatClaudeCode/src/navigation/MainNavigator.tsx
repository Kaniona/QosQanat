import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import React from 'react';

import QTabBar from '@/components/UI/QTabBar';
import FriendsScreen from '@/screens/Friends/FriendsScreen';
import LearnScreen from '@/screens/learn/LearnScreen';
import HomeScreen from '@/screens/main/HomeScreen';
import ShopScreen from '@/screens/main/ShopScreen';
import ProfileScreen from '@/screens/Profile/ProfileScreen';

import type { MainTabParamList } from './types';

// ----------------------------------------------------------------------------
// MainNavigator — the 5-tab bottom navigator the player sees after login.
// Custom tab bar lives in `components/UI/QTabBar.tsx`.
// ----------------------------------------------------------------------------

const Tab = createBottomTabNavigator<MainTabParamList>();

const MainNavigator: React.FC = () => {
  return (
    <Tab.Navigator
      initialRouteName="Home"
      screenOptions={{
        headerShown: false,
        tabBarHideOnKeyboard: true,
      }}
      tabBar={(props) => <QTabBar {...props} />}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Learn" component={LearnScreen} />
      <Tab.Screen name="Shop" component={ShopScreen} />
      <Tab.Screen name="Friends" component={FriendsScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
};

export default MainNavigator;
