import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';


import AssistantSelectScreen from '@/screens/Auth/AssistantSelectScreen';
import OnboardingScreen from '@/screens/Auth/OnboardingScreen';
import RegisterScreen from '@/screens/Auth/RegisterScreen';
import SplashScreen from '@/screens/Auth/SplashScreen';
import WelcomeScreen from '@/screens/Auth/WelcomeScreen';

import type { AuthFlowParamList } from './types';

// ----------------------------------------------------------------------------
// AuthNavigator
//
// Splash → Welcome → Register → AssistantSelect → Onboarding (first run only).
// RootNavigator decides whether this navigator or MainNavigator is shown,
// based on `userStore.isAuthenticated` + the onboarded flag.
// ----------------------------------------------------------------------------

const Stack = createNativeStackNavigator<AuthFlowParamList>();

const AuthNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      initialRouteName="Splash"
      screenOptions={{ headerShown: false, animation: 'fade' }}
    >
      <Stack.Screen name="Splash" component={SplashScreen} />
      <Stack.Screen name="Welcome" component={WelcomeScreen} />
      <Stack.Screen
        name="Register"
        component={RegisterScreen}
        options={{ animation: 'slide_from_right' }}
      />
      <Stack.Screen
        name="AssistantSelect"
        component={AssistantSelectScreen}
        options={{ animation: 'slide_from_bottom' }}
      />
      <Stack.Screen
        name="Onboarding"
        component={OnboardingScreen}
        options={{ animation: 'fade', gestureEnabled: false }}
      />
    </Stack.Navigator>
  );
};

export default AuthNavigator;
