// ----------------------------------------------------------------------------
// Voice service
//
// Bundles:
//   * TTS via expo-speech (always available)
//   * STT via @react-native-voice/voice (OPTIONAL — requires a dev build, the
//     module is loaded lazily and gracefully unavailable on Expo Go)
//   * Intent dispatcher that turns a recognised utterance into a side-effect
//     (navigation, TTS info reply, external app launch, AI placeholder).
//
// All user-facing strings are Kazakh. The TTS layer always speaks `kk-KZ`.
// Bektur is voiced at pitch 1.1 (lower-pitched boy), Nazym at pitch 1.3
// (lighter-pitched girl) — both at slightly slower rate so the synthesizer
// pronounces Kazakh affixes more clearly.
// ----------------------------------------------------------------------------

import * as Speech from 'expo-speech';
import { Linking, Platform } from 'react-native';

import {
  matchCommand,
  type InfoKey,
  type VoiceIntent,
  type VoiceRoute,
} from '@/config/voiceCommands';
import { getFriends, getLeaderboard } from '@/services/api';
import { useGameStore } from '@/store/gameStore';
import { useUserStore } from '@/store/userStore';
import type { AssistantType } from '@/types';

// ---- TTS -------------------------------------------------------------------

interface VoiceProfile {
  language: string;
  pitch: number;
  rate: number;
}

const TTS_PROFILES: Record<AssistantType, VoiceProfile> = {
  bektur: { language: 'kk-KZ', pitch: 1.1, rate: 0.95 },
  nazym: { language: 'kk-KZ', pitch: 1.3, rate: 0.96 },
};

export interface SpeakOptions {
  onStart?: () => void;
  onDone?: () => void;
  onError?: (err: unknown) => void;
}

// Speak Kazakh text using the player's assistant voice profile. Cancels any
// utterance already in flight so consecutive `speak()` calls feel snappy.
export const speak = (
  text: string,
  assistantType: AssistantType,
  opts: SpeakOptions = {},
): void => {
  try {
    void Speech.stop();
  } catch {
    // ignore
  }
  const profile = TTS_PROFILES[assistantType] ?? TTS_PROFILES.bektur;
  Speech.speak(text, {
    language: profile.language,
    pitch: profile.pitch,
    rate: profile.rate,
    onStart: opts.onStart,
    onDone: opts.onDone,
    onError: opts.onError,
  });
};

export const stopSpeaking = (): void => {
  try {
    void Speech.stop();
  } catch {
    // ignore — expo-speech throws on web sometimes
  }
};

// ---- STT (optional, runtime-loaded) ---------------------------------------
//
// `@react-native-voice/voice` is not bundled with Expo Go. We lazy-require
// it so the rest of the voice surface still works on managed Expo: if the
// module isn't present, `startListening()` resolves into an "unavailable"
// status the UI surfaces as a Kazakh message.
//
// To enable real STT in production:
//   1. Run `npx expo install @react-native-voice/voice` AND `expo-dev-client`.
//   2. Re-build with EAS (`npx expo run:android` / `:ios`) or `eas build`.
//   3. Grant microphone + speech-recognition permissions when prompted.

interface VoiceModuleApi {
  start: (locale: string) => Promise<void>;
  stop: () => Promise<void>;
  destroy: () => Promise<void>;
  removeAllListeners: () => void;
  onSpeechResults: ((e: { value?: readonly string[] }) => void) | null;
  onSpeechPartialResults: ((e: { value?: readonly string[] }) => void) | null;
  onSpeechError: ((e: { error?: { message?: string } }) => void) | null;
  onSpeechEnd: (() => void) | null;
  isAvailable: () => Promise<number | boolean>;
}

let voiceModule: VoiceModuleApi | null | undefined;

const loadVoiceModule = (): VoiceModuleApi | null => {
  if (voiceModule !== undefined) return voiceModule;
  try {
    // The require is wrapped in a function so bundlers that statically inspect
    // imports (Metro) don't try to resolve it at build time when the package
    // is absent.
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const m = require('@react-native-voice/voice') as { default?: VoiceModuleApi } & VoiceModuleApi;
    voiceModule = (m.default ?? m);
  } catch {
    voiceModule = null;
  }
  return voiceModule;
};

export type ListenStatus =
  | 'starting'
  | 'listening'
  | 'final'
  | 'error'
  | 'unavailable'
  | 'cancelled';

export interface ListenCallbacks {
  onStatus?: (status: ListenStatus, message?: string) => void;
  onPartial?: (text: string) => void;
  onFinal?: (text: string) => void;
  onError?: (errorKz: string) => void;
}

export interface ListenHandle {
  stop: () => Promise<void>;
  cancel: () => Promise<void>;
  available: boolean;
}

const KZ_NOT_AVAILABLE =
  'Дауысты тану үшін арнайы dev-build керек. Қазір тек басу арқылы пайдаланыңыз.';
const KZ_PERMISSION_DENIED = 'Микрофонға рұқсат берілмеген. Баптауларда рұқсат беріңіз.';
const KZ_TIMEOUT = 'Сізді ести алмадым. Қайта көріңіз.';
const KZ_GENERIC_ERROR = 'Қателік шықты. Қайта көріңіз.';

const mapVoiceError = (raw: string | undefined): string => {
  if (!raw) return KZ_GENERIC_ERROR;
  const r = raw.toLowerCase();
  if (r.includes('permission') || r.includes('denied')) return KZ_PERMISSION_DENIED;
  if (r.includes('no match') || r.includes('no speech')) return KZ_TIMEOUT;
  return KZ_GENERIC_ERROR;
};

// Begin a single recognition session. Returns a handle the caller can use to
// stop/cancel mid-stream. Auto-times-out after `timeoutMs` (default 7000).
export const startListening = async (
  cbs: ListenCallbacks,
  timeoutMs = 7000,
): Promise<ListenHandle> => {
  const mod = loadVoiceModule();
  if (!mod) {
    cbs.onStatus?.('unavailable', KZ_NOT_AVAILABLE);
    cbs.onError?.(KZ_NOT_AVAILABLE);
    return {
      stop: () => Promise.resolve(),
      cancel: () => Promise.resolve(),
      available: false,
    };
  }

  // Wire the module's event callbacks once for this session.
  let lastFinal = '';
  let stopped = false;
  let timer: ReturnType<typeof setTimeout> | null = null;

  const cleanup = (): void => {
    if (timer) clearTimeout(timer);
    mod.removeAllListeners();
  };

  mod.onSpeechResults = (e) => {
    const text = e.value?.[0] ?? '';
    if (text) lastFinal = text;
  };
  mod.onSpeechPartialResults = (e) => {
    const text = e.value?.[0] ?? '';
    if (text) cbs.onPartial?.(text);
  };
  mod.onSpeechError = (e) => {
    const message = mapVoiceError(e.error?.message);
    cbs.onStatus?.('error', message);
    cbs.onError?.(message);
    cleanup();
  };
  mod.onSpeechEnd = () => {
    if (stopped) return;
    stopped = true;
    cleanup();
    if (lastFinal) {
      cbs.onStatus?.('final');
      cbs.onFinal?.(lastFinal);
    } else {
      cbs.onStatus?.('error', KZ_TIMEOUT);
      cbs.onError?.(KZ_TIMEOUT);
    }
  };

  try {
    cbs.onStatus?.('starting');
    await mod.start('kk-KZ');
    cbs.onStatus?.('listening');
    timer = setTimeout(() => {
      if (stopped) return;
      stopped = true;
      void mod.stop();
      cleanup();
      if (lastFinal) {
        cbs.onStatus?.('final');
        cbs.onFinal?.(lastFinal);
      } else {
        cbs.onStatus?.('error', KZ_TIMEOUT);
        cbs.onError?.(KZ_TIMEOUT);
      }
    }, timeoutMs);
  } catch (err) {
    const message = mapVoiceError(err instanceof Error ? err.message : String(err));
    cbs.onStatus?.('error', message);
    cbs.onError?.(message);
    cleanup();
  }

  return {
    available: true,
    stop: async () => {
      if (stopped) return;
      stopped = true;
      try {
        await mod.stop();
      } catch {
        // ignore
      }
      cleanup();
    },
    cancel: async () => {
      if (stopped) return;
      stopped = true;
      try {
        await mod.destroy();
      } catch {
        // ignore
      }
      cleanup();
      cbs.onStatus?.('cancelled');
    },
  };
};

// ---- Dispatcher ------------------------------------------------------------

export interface ResolvedReply {
  spokenKz: string;
  // For navigation/external intents the resolver returns the side-effect
  // information so the caller (overlay) can run it once TTS settles.
  action?: { type: 'navigate'; route: VoiceRoute } | { type: 'open_url'; url: string };
}

interface InfoContext {
  rank?: number; // current user's global rank if known
  friendCount?: number;
}

const resolveInfo = (key: InfoKey, template: string, ctx: InfoContext): string => {
  const user = useUserStore.getState().user;
  const game = useGameStore.getState();
  let primary = '0';
  let secondary = '';
  switch (key) {
    case 'level':
      primary = String(game.level ?? user?.level ?? 1);
      break;
    case 'coins':
      primary = String(game.coins);
      break;
    case 'akyl':
      primary = String(game.akylPoints);
      secondary = ctx.rank ? String(ctx.rank) : '';
      break;
    case 'streak':
      primary = String(game.currentStreak);
      break;
    case 'friends_count':
      primary = String(ctx.friendCount ?? 0);
      break;
  }
  let out = template.replace('{N}', primary);
  if (secondary) {
    out = out.replace('{M}', secondary);
  } else {
    // Strip the trailing "...{M}-орындасыз." clause if rank is unknown.
    out = out.replace(/,\s*[^.]*\{M\}[^.]*\./, '.');
  }
  return out;
};

// AI placeholder — friendly Kazakh reply per assistant personality.
// Replace with an actual Anthropic call once the API key is wired.
export const aiRespond = (query: string, assistantType: AssistantType): string => {
  const opener = assistantType === 'nazym' ? 'Қызық сұрақ екен!' : 'Сұрағыңыз қызық.';
  // Trim the placeholder reference to `query` so it never gets discarded.
  const tail =
    query.trim().length > 0
      ? ' Бұл сұраққа кейінірек жауап бере аламын!'
      : ' Маған бір нәрсе сұраңыз!';
  return opener + tail;
};

// Resolve an intent (matched or fallback) into a spoken reply + optional side
// effect. The overlay calls `speak()` itself so we don't tie the dispatcher
// to TTS — handy if the same flow runs from a Quick Action later.
export const resolveIntent = async (
  intent: VoiceIntent,
  assistantType: AssistantType,
): Promise<ResolvedReply> => {
  switch (intent.kind) {
    case 'navigation':
      return {
        spokenKz: intent.responseKz,
        action: { type: 'navigate', route: intent.route },
      };
    case 'external':
      return {
        spokenKz: intent.responseKz,
        action: { type: 'open_url', url: intent.url },
      };
    case 'info': {
      const ctx: InfoContext = {};
      if (intent.infoKey === 'akyl') {
        try {
          const board = await getLeaderboard('global', 200);
          const me = useUserStore.getState().user?.id;
          const row = board.find((b) => b.id === me);
          if (row) ctx.rank = row.rank;
        } catch {
          // soft-fail — template strips the rank clause when missing
        }
      }
      if (intent.infoKey === 'friends_count') {
        try {
          const fs = await getFriends();
          ctx.friendCount = fs.length;
        } catch {
          ctx.friendCount = 0;
        }
      }
      return { spokenKz: resolveInfo(intent.infoKey, intent.responseTemplateKz, ctx) };
    }
    case 'ai_query':
      return { spokenKz: aiRespond(intent.rawText, assistantType) };
    case 'unknown':
      return {
        spokenKz:
          assistantType === 'nazym'
            ? 'Кешіріңіз, түсінбедім. Қайталап айтыңызшы.'
            : 'Кешіріңіз, түсінбедім. Қайталап көріңіз.',
      };
  }
};

// Convenience helper used by the VoiceButton overlay: parse → resolve → return.
export const parseAndResolve = async (
  utterance: string,
  assistantType: AssistantType,
): Promise<{ intent: VoiceIntent; reply: ResolvedReply }> => {
  const intent = matchCommand(utterance);
  const reply = await resolveIntent(intent, assistantType);
  return { intent, reply };
};

// ---- Linking helpers -------------------------------------------------------

export const openExternalUrl = async (url: string, fallbackWebUrl?: string): Promise<boolean> => {
  try {
    const can = await Linking.canOpenURL(url);
    if (can) {
      await Linking.openURL(url);
      return true;
    }
  } catch {
    // ignore — try fallback
  }
  if (fallbackWebUrl) {
    try {
      await Linking.openURL(fallbackWebUrl);
      return true;
    } catch {
      return false;
    }
  }
  return false;
};

// Per-platform fallbacks for the canonical voice commands. The dispatcher
// returns the canonical scheme; the overlay calls this resolver so iOS/Android
// quirks (camera/calculator schemes) are isolated here.
export const resolveFallbackUrl = (url: string): string | undefined => {
  if (url.startsWith('whatsapp://')) return 'https://web.whatsapp.com/';
  if (url.startsWith('instagram://')) return 'https://www.instagram.com/';
  if (url.startsWith('tiktok://')) return 'https://www.tiktok.com/';
  if (url.startsWith('tg://')) return 'https://web.telegram.org/';
  if (url.startsWith('camera://')) {
    // No universal web fallback; null tells the caller to surface a hint.
    return undefined;
  }
  if (url.startsWith('calculator://')) return undefined;
  return undefined;
};

// ---- Permission helper ----------------------------------------------------
// On both platforms `@react-native-voice/voice` will prompt the user the first
// time `start()` is called. We provide a tiny pre-check so the UI can show a
// Kazakh rationale dialog before triggering the OS prompt.

export interface PermissionStatus {
  available: boolean; // module present at all
  hint: string; // Kazakh rationale to show before prompting
}

export const checkVoiceAvailability = (): PermissionStatus => {
  const mod = loadVoiceModule();
  if (!mod) {
    return {
      available: false,
      hint: KZ_NOT_AVAILABLE,
    };
  }
  return {
    available: true,
    hint:
      Platform.OS === 'ios'
        ? 'Дауысты тану үшін микрофон мен сөйлеуді тану рұқсаты керек.'
        : 'Дауысты тану үшін микрофон рұқсаты керек.',
  };
};

// Exposed constants the UI may read for status text.
export const VOICE_KZ = {
  notAvailable: KZ_NOT_AVAILABLE,
  permissionDenied: KZ_PERMISSION_DENIED,
  timeout: KZ_TIMEOUT,
  genericError: KZ_GENERIC_ERROR,
};
