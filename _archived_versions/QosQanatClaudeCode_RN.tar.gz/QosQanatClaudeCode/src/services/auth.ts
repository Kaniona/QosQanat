import { useUserStore } from '@/store/userStore';
import type { AssistantType, User } from '@/types';
import { toCanonicalKzPhone, digitsOnly } from '@/utils/phoneFormat';

import { supabase } from './supabase';

export interface RegisterPayload {
  fullName: string;
  phone: string; // any format; will be canonicalised
  iin: string; // 12 digits
  city: string;
  school: string;
  grade: number;
}

// Synthesises an email from the canonical phone number, since the auth flow
// uses Supabase email auth (no SMS OTP yet). The IIN doubles as the password.
const phoneToEmail = (phone: string): string => `${toCanonicalKzPhone(phone)}@qosqanat.app`;

export const registerUser = async (payload: RegisterPayload): Promise<User> => {
  const email = phoneToEmail(payload.phone);
  const password = digitsOnly(payload.iin);
  const canonicalPhone = toCanonicalKzPhone(payload.phone);

  const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
    email,
    password,
  });
  if (signUpError) throw signUpError;
  const authUser = signUpData.user;
  if (!authUser) throw new Error('Auth user was not created');

  const { data: qosqanatId, error: rpcError } = await supabase.rpc('generate_qosqanat_id');
  if (rpcError) throw rpcError;
  if (!qosqanatId) throw new Error('QQ-ID generation failed');

  const { data: inserted, error: insertError } = await supabase
    .from('users')
    .insert({
      id: authUser.id,
      qosqanat_id: qosqanatId,
      full_name: payload.fullName.trim(),
      phone: canonicalPhone,
      iin: digitsOnly(payload.iin),
      city: payload.city,
      school: payload.school.trim(),
      grade: payload.grade,
    })
    .select('*')
    .single();
  if (insertError) throw insertError;

  useUserStore.getState().setUser(inserted as User);
  return inserted as User;
};

export const setAssistant = async (assistant: AssistantType): Promise<void> => {
  const current = useUserStore.getState().user;
  if (!current) throw new Error('No user in store');
  const { error } = await supabase
    .from('users')
    .update({ assistant_type: assistant })
    .eq('id', current.id);
  if (error) throw error;
  useUserStore.getState().updateUser({ assistant_type: assistant });
};

export const loadSessionUser = async (): Promise<User | null> => {
  const { data: sessionData } = await supabase.auth.getSession();
  const session = sessionData.session;
  if (!session) return null;
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', session.user.id)
    .maybeSingle();
  if (error) throw error;
  if (data) useUserStore.getState().setUser(data as User);
  return (data as User | null) ?? null;
};

export const signOut = async (): Promise<void> => {
  await supabase.auth.signOut();
  useUserStore.getState().clear();
};
