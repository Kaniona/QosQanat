// ----------------------------------------------------------------------------
// Client-side API layer for QosQanat.
//
// All Supabase calls live here per project rules. UI components import the
// typed helpers below; they never touch the supabase client directly.
// ----------------------------------------------------------------------------

import type { RealtimeChannel } from '@supabase/supabase-js';

import { ACHIEVEMENTS, type Achievement } from '@/data/achievements';
import { CURRICULUM } from '@/data/curriculum';
import { DAILY_QUESTS, type Quest } from '@/data/quests';
import { DEFAULT_OWNED_IDS, getShopItem } from '@/data/shopItems';
import { useUserStore } from '@/store/userStore';
import type { AssistantType, ItemCategory } from '@/types';

import { supabase } from './supabase';

export type DailyQuestStatus = 'active' | 'completed' | 'claimed';

export interface DailyQuestRow {
  id: string;
  user_id: string;
  quest_id: string;
  date: string;
  status: DailyQuestStatus;
  progress: number;
  target: number;
  completed_at: string | null;
  claimed_at: string | null;
}

export interface DailyQuestState extends DailyQuestRow {
  quest: Quest;
}

export interface UnlockedAchievement {
  achievement: Achievement;
  unlocked_at: string;
}

const DAILY_SLATE_SIZE = 3;

const todayISO = (): string => {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
};

const dayIndexInYear = (): number => {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 0).getTime();
  return Math.floor((now.getTime() - start) / 86_400_000);
};

// Today's deterministic 3-quest slate — same for the whole day, rotates daily.
const pickQuestSlateForToday = (): readonly Quest[] => {
  const dayIndex = dayIndexInYear();
  const len = DAILY_QUESTS.length;
  const slate: Quest[] = [];
  for (let i = 0; i < DAILY_SLATE_SIZE; i += 1) {
    slate.push(DAILY_QUESTS[(dayIndex + i) % len]);
  }
  return slate;
};

const currentUserId = (): string | null => useUserStore.getState().user?.id ?? null;

// Reads today's daily-quest rows for the current user. If today's slate hasn't
// been seeded yet (first visit of the day) it inserts the missing rows.
export const ensureTodayQuests = async (): Promise<readonly DailyQuestState[]> => {
  const userId = currentUserId();
  if (!userId) return [];
  const today = todayISO();

  const { data, error } = await supabase
    .from('daily_quests')
    .select('*')
    .eq('user_id', userId)
    .eq('date', today);
  if (error) throw error;

  const rows = (data ?? []) as DailyQuestRow[];
  const slate = pickQuestSlateForToday();
  const missing = slate.filter((q) => !rows.some((r) => r.quest_id === q.id));

  if (missing.length > 0) {
    const toInsert = missing.map((q) => ({
      user_id: userId,
      quest_id: q.id,
      date: today,
      status: 'active',
      progress: 0,
      target: q.target,
    }));
    const { data: inserted, error: insertErr } = await supabase
      .from('daily_quests')
      .insert(toInsert)
      .select('*');
    if (insertErr) throw insertErr;
    rows.push(...((inserted ?? []) as DailyQuestRow[]));
  }

  return slate
    .map<DailyQuestState | null>((q) => {
      const row = rows.find((r) => r.quest_id === q.id);
      return row ? { ...row, quest: q } : null;
    })
    .filter((x): x is DailyQuestState => x !== null);
};

export const claimDailyQuest = async (rowId: string): Promise<void> => {
  const userId = currentUserId();
  if (!userId) throw new Error('No active user');
  const { error } = await supabase
    .from('daily_quests')
    .update({ status: 'claimed', claimed_at: new Date().toISOString() })
    .eq('id', rowId)
    .eq('user_id', userId);
  if (error) throw error;
};

export const getUnreadNotificationCount = async (): Promise<number> => {
  const userId = currentUserId();
  if (!userId) return 0;
  const { count, error } = await supabase
    .from('notifications')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('is_read', false);
  if (error) throw error;
  return count ?? 0;
};

// ----------------------------------------------------------------------------
// Task progress (learning map nodes)
// ----------------------------------------------------------------------------

export type NodeProgressStatus = 'locked' | 'available' | 'completed' | 'mastered';

export interface TaskProgressRow {
  id: string;
  user_id: string;
  subject_id: string;
  module_id: string;
  node_id: string;
  status: NodeProgressStatus;
  best_score: number;
  attempts: number;
  xp_earned: number;
  coins_earned: number;
  akyl_earned: number;
  completed_at: string | null;
  created_at: string;
}

// Pulls every progress row the player has for one subject. The MapScreen indexes
// by node_id to decide each circle's visual state.
export const getSubjectProgress = async (
  subjectId: string,
): Promise<ReadonlyMap<string, TaskProgressRow>> => {
  const userId = currentUserId();
  const out = new Map<string, TaskProgressRow>();
  if (!userId) return out;
  const { data, error } = await supabase
    .from('task_progress')
    .select('*')
    .eq('user_id', userId)
    .eq('subject_id', subjectId);
  if (error) throw error;
  for (const row of (data ?? []) as TaskProgressRow[]) {
    out.set(row.node_id, row);
  }
  return out;
};

// Aggregate counts used by the subject-card progress label on LearnScreen.
export interface SubjectProgressSummary {
  completed: number;
  mastered: number;
}

export const getSubjectProgressSummary = async (
  subjectId: string,
): Promise<SubjectProgressSummary> => {
  const map = await getSubjectProgress(subjectId);
  let completed = 0;
  let mastered = 0;
  for (const row of map.values()) {
    if (row.status === 'completed' || row.status === 'mastered') completed += 1;
    if (row.status === 'mastered') mastered += 1;
  }
  return { completed, mastered };
};

export interface CompleteNodePayload {
  subjectId: string;
  moduleId: string;
  nodeId: string;
  scorePercent: number; // 0..100
  xpReward: number;
  coinReward: number;
  akylReward: number;
}

export interface CompleteNodeResult {
  status: NodeProgressStatus;
  bestScore: number;
  isFirstClear: boolean;
}

// Upserts a task_progress row marking the node as completed/mastered. Returns
// whether this is the first time the player has cleared this node — callers use
// that to decide whether to grant rewards (only on first clear).
export const completeNode = async (payload: CompleteNodePayload): Promise<CompleteNodeResult> => {
  const userId = currentUserId();
  if (!userId) throw new Error('No active user');

  const { data: existingData, error: selectErr } = await supabase
    .from('task_progress')
    .select('*')
    .eq('user_id', userId)
    .eq('subject_id', payload.subjectId)
    .eq('module_id', payload.moduleId)
    .eq('node_id', payload.nodeId)
    .maybeSingle();
  if (selectErr) throw selectErr;
  const existing = existingData as TaskProgressRow | null;

  const isFirstClear =
    !existing || (existing.status !== 'completed' && existing.status !== 'mastered');
  const newStatus: NodeProgressStatus = payload.scorePercent >= 100 ? 'mastered' : 'completed';
  const bestScore = Math.max(existing?.best_score ?? 0, Math.round(payload.scorePercent));
  const attempts = (existing?.attempts ?? 0) + 1;
  const grantedXp = isFirstClear ? payload.xpReward : 0;
  const grantedCoins = isFirstClear ? payload.coinReward : 0;
  const grantedAkyl = isFirstClear ? payload.akylReward : 0;
  const xpEarned = (existing?.xp_earned ?? 0) + grantedXp;
  const coinsEarned = (existing?.coins_earned ?? 0) + grantedCoins;
  const akylEarned = (existing?.akyl_earned ?? 0) + grantedAkyl;

  const upsertRow = {
    user_id: userId,
    subject_id: payload.subjectId,
    module_id: payload.moduleId,
    node_id: payload.nodeId,
    status: newStatus,
    best_score: bestScore,
    attempts,
    xp_earned: xpEarned,
    coins_earned: coinsEarned,
    akyl_earned: akylEarned,
    completed_at: existing?.completed_at ?? new Date().toISOString(),
  };

  const { error: upsertErr } = await supabase
    .from('task_progress')
    .upsert(upsertRow, { onConflict: 'user_id,subject_id,module_id,node_id' });
  if (upsertErr) throw upsertErr;

  return { status: newStatus, bestScore, isFirstClear };
};

// ----------------------------------------------------------------------------
// Shop — inventory and equipment
// ----------------------------------------------------------------------------

export interface InventoryRow {
  id: string;
  item_id: string;
  purchased_at: string;
  purchase_price: number;
}

export interface EquipmentRow {
  id: string;
  slot: ItemCategory;
  item_id: string;
  equipped_at: string;
}

// Returns the IDs of every item the player owns. Every default ("free") item
// is implicitly owned even when no inventory row exists so the user always has
// a baseline wardrobe to equip.
export const getInventory = async (): Promise<ReadonlySet<string>> => {
  const owned = new Set<string>(DEFAULT_OWNED_IDS);
  const userId = currentUserId();
  if (!userId) return owned;
  const { data, error } = await supabase
    .from('user_inventory')
    .select('item_id')
    .eq('user_id', userId);
  if (error) throw error;
  for (const row of (data ?? []) as Pick<InventoryRow, 'item_id'>[]) {
    owned.add(row.item_id);
  }
  return owned;
};

// Returns currently equipped item per slot. Slots without a row are absent.
export const getEquipment = async (): Promise<Partial<Record<ItemCategory, string>>> => {
  const result: Partial<Record<ItemCategory, string>> = {};
  const userId = currentUserId();
  if (!userId) return result;
  const { data, error } = await supabase
    .from('user_equipment')
    .select('slot, item_id')
    .eq('user_id', userId);
  if (error) throw error;
  for (const row of (data ?? []) as Pick<EquipmentRow, 'slot' | 'item_id'>[]) {
    result[row.slot] = row.item_id;
  }
  return result;
};

export type PurchaseFailureReason =
  | 'not_found'
  | 'already_owned'
  | 'level_locked'
  | 'insufficient_coins';

export interface PurchaseSuccess {
  ok: true;
  itemId: string;
  pricePaid: number;
}

export interface PurchaseFailure {
  ok: false;
  reason: PurchaseFailureReason;
}

export type PurchaseResult = PurchaseSuccess | PurchaseFailure;

// Inserts a row into user_inventory. The caller is responsible for spending
// coins via the game store; this function only handles the inventory write.
// Returns 'already_owned' silently if the row already exists.
export const purchaseItem = async (itemId: string): Promise<void> => {
  const userId = currentUserId();
  if (!userId) throw new Error('No active user');
  const item = getShopItem(itemId);
  if (!item) throw new Error(`Unknown shop item: ${itemId}`);
  const { error } = await supabase.from('user_inventory').insert({
    user_id: userId,
    item_id: itemId,
    purchase_price: item.price,
  });
  // Ignore duplicate-key races so the UI can recover gracefully.
  if (error && error.code !== '23505') throw error;
};

// Upserts the equipment row for the item's slot.
export const equipItem = async (itemId: string): Promise<void> => {
  const userId = currentUserId();
  if (!userId) throw new Error('No active user');
  const item = getShopItem(itemId);
  if (!item) throw new Error(`Unknown shop item: ${itemId}`);
  const { error } = await supabase.from('user_equipment').upsert(
    {
      user_id: userId,
      slot: item.category,
      item_id: itemId,
      equipped_at: new Date().toISOString(),
    },
    { onConflict: 'user_id,slot' },
  );
  if (error) throw error;
};

// ----------------------------------------------------------------------------
// Friends
// ----------------------------------------------------------------------------
//
// The friendships table is bidirectional: one row per pair, status in
// {pending, accepted, blocked}. The RLS users-select policy hides non-friends,
// so search-by-id and incoming-request listing both go through SECURITY DEFINER
// RPCs (see SUPABASE_SETUP.sql) that return a projected, safe view of the
// other user.
// ----------------------------------------------------------------------------

export interface PublicUserProfile {
  id: string;
  qosqanat_id: string;
  full_name: string;
  city: string;
  school: string;
  grade: number;
  assistant_type: AssistantType | null;
  level: number;
  akyl_points: number;
}

export type FriendshipStatus = 'pending' | 'accepted' | 'blocked';

export interface FriendshipRow {
  id: string;
  user_a_id: string;
  user_b_id: string;
  status: FriendshipStatus;
  initiated_by: string;
  created_at: string;
  accepted_at: string | null;
}

export interface FriendEntry extends PublicUserProfile {
  friendship_id: string;
  accepted_at: string | null;
}

export interface FriendRequestEntry extends PublicUserProfile {
  friendship_id: string;
  created_at: string;
}

const normalizeQqId = (raw: string): string => raw.trim().toUpperCase().replace(/\s+/g, '');

// Find a single user by their QQ-XXXXXXXXX identifier. Bypasses the users
// RLS via RPC so non-friends are still discoverable for friend requests.
export const searchUserById = async (qqId: string): Promise<PublicUserProfile | null> => {
  const id = normalizeQqId(qqId);
  if (!id) return null;
  const { data, error } = await supabase.rpc('search_user_by_qq_id', { p_qq_id: id });
  if (error) throw error;
  const rows = (data ?? []) as PublicUserProfile[];
  return rows[0] ?? null;
};

// Send a friend request — inserts a pending friendships row. The functional
// uq_friendships_pair index protects against duplicate (A,B)/(B,A) entries.
export const sendFriendRequest = async (targetUserId: string): Promise<void> => {
  const me = currentUserId();
  if (!me) throw new Error('No active user');
  if (me === targetUserId) throw new Error('Cannot befriend self');
  // user_a_id/user_b_id are ordered (LEAST/GREATEST) so the unique index works.
  const [userA, userB] = me < targetUserId ? [me, targetUserId] : [targetUserId, me];
  const { error } = await supabase.from('friendships').insert({
    user_a_id: userA,
    user_b_id: userB,
    status: 'pending',
    initiated_by: me,
  });
  if (error) throw error;
};

export const acceptFriendRequest = async (friendshipId: string): Promise<void> => {
  const me = currentUserId();
  if (!me) throw new Error('No active user');
  const { error } = await supabase
    .from('friendships')
    .update({ status: 'accepted', accepted_at: new Date().toISOString() })
    .eq('id', friendshipId);
  if (error) throw error;
};

export const declineFriendRequest = async (friendshipId: string): Promise<void> => {
  const { error } = await supabase.from('friendships').delete().eq('id', friendshipId);
  if (error) throw error;
};

// Identical to decline server-side — present as a distinct name for clarity
// (cancel is invoked by the *sender* on an outgoing pending request).
export const cancelFriendRequest = declineFriendRequest;

export const removeFriend = declineFriendRequest;

// Accepted friends. Fetches the friendship rows, then pulls the other user's
// profile via the users RLS self-or-friend SELECT policy.
export const getFriends = async (): Promise<readonly FriendEntry[]> => {
  const me = currentUserId();
  if (!me) return [];
  const { data: fRows, error: fErr } = await supabase
    .from('friendships')
    .select('id, user_a_id, user_b_id, accepted_at')
    .eq('status', 'accepted')
    .or(`user_a_id.eq.${me},user_b_id.eq.${me}`);
  if (fErr) throw fErr;
  const rows = (fRows ?? []) as {
    id: string;
    user_a_id: string;
    user_b_id: string;
    accepted_at: string | null;
  }[];
  if (rows.length === 0) return [];
  const otherIds = rows.map((r) => (r.user_a_id === me ? r.user_b_id : r.user_a_id));
  const { data: uRows, error: uErr } = await supabase
    .from('users')
    .select('id, qosqanat_id, full_name, city, school, grade, assistant_type, level, akyl_points')
    .in('id', otherIds);
  if (uErr) throw uErr;
  const userMap = new Map<string, PublicUserProfile>(
    ((uRows ?? []) as PublicUserProfile[]).map((u) => [u.id, u]),
  );
  return rows
    .map<FriendEntry | null>((r) => {
      const otherId = r.user_a_id === me ? r.user_b_id : r.user_a_id;
      const profile = userMap.get(otherId);
      if (!profile) return null;
      return { ...profile, friendship_id: r.id, accepted_at: r.accepted_at };
    })
    .filter((x): x is FriendEntry => x !== null);
};

export const getIncomingFriendRequests = async (): Promise<readonly FriendRequestEntry[]> => {
  const { data, error } = await supabase.rpc('get_incoming_friend_requests');
  if (error) throw error;
  return (
    (data ?? []) as {
      friendship_id: string;
      user_id: string;
      qosqanat_id: string;
      full_name: string;
      city: string;
      school: string;
      grade: number;
      assistant_type: AssistantType | null;
      level: number;
      akyl_points: number;
      created_at: string;
    }[]
  ).map((r) => ({
    id: r.user_id,
    qosqanat_id: r.qosqanat_id,
    full_name: r.full_name,
    city: r.city,
    school: r.school,
    grade: r.grade,
    assistant_type: r.assistant_type,
    level: r.level,
    akyl_points: r.akyl_points,
    friendship_id: r.friendship_id,
    created_at: r.created_at,
  }));
};

export const getOutgoingFriendRequests = async (): Promise<readonly FriendRequestEntry[]> => {
  const { data, error } = await supabase.rpc('get_outgoing_friend_requests');
  if (error) throw error;
  return (
    (data ?? []) as {
      friendship_id: string;
      user_id: string;
      qosqanat_id: string;
      full_name: string;
      city: string;
      school: string;
      grade: number;
      assistant_type: AssistantType | null;
      level: number;
      akyl_points: number;
      created_at: string;
    }[]
  ).map((r) => ({
    id: r.user_id,
    qosqanat_id: r.qosqanat_id,
    full_name: r.full_name,
    city: r.city,
    school: r.school,
    grade: r.grade,
    assistant_type: r.assistant_type,
    level: r.level,
    akyl_points: r.akyl_points,
    friendship_id: r.friendship_id,
    created_at: r.created_at,
  }));
};

// Single profile (friend or self). Used by the battle screens to show the
// opponent's name/avatar before the joined battle row arrives.
export const getUserPublicProfile = async (userId: string): Promise<PublicUserProfile | null> => {
  const { data, error } = await supabase
    .from('users')
    .select('id, qosqanat_id, full_name, city, school, grade, assistant_type, level, akyl_points')
    .eq('id', userId)
    .maybeSingle();
  if (error) throw error;
  return (data) ?? null;
};

// ----------------------------------------------------------------------------
// Online presence
// ----------------------------------------------------------------------------
// A global Presence channel marks the current user as online. Other clients
// read the channel's state to render a green "online dot" on friend cards.
// ----------------------------------------------------------------------------

export const subscribeOnlinePresence = (
  onChange: (onlineIds: ReadonlySet<string>) => void,
): (() => void) => {
  const me = currentUserId();
  if (!me) return () => undefined;
  const channel = supabase.channel('online_users', {
    config: { presence: { key: me } },
  });
  const emit = () => {
    const state = channel.presenceState();
    const ids = new Set<string>(Object.keys(state));
    onChange(ids);
  };
  channel
    .on('presence', { event: 'sync' }, emit)
    .on('presence', { event: 'join' }, emit)
    .on('presence', { event: 'leave' }, emit)
    .subscribe((status) => {
      if (status === 'SUBSCRIBED') {
        void channel.track({ online_at: new Date().toISOString() });
      }
    });
  return () => {
    void channel.untrack();
    void supabase.removeChannel(channel);
  };
};

// ----------------------------------------------------------------------------
// Battle
// ----------------------------------------------------------------------------

export type BattleStatus = 'pending' | 'accepted' | 'in_progress' | 'completed' | 'cancelled';
export type BattleQuestionCount = 15 | 20 | 25 | 40 | 50;

export interface BattleQuestion {
  id: string;
  subjectId: string;
  subjectNameKz: string;
  questionKz: string;
  options: readonly string[];
  correctIndex: number;
  explanationKz?: string;
}

export interface BattleAnswer {
  questionIndex: number;
  answerIndex: number | null; // null = timed out / no answer
  isCorrect: boolean;
  answeredAtMs: number; // ms since question started
}

export interface BattleRow {
  id: string;
  challenger_id: string;
  opponent_id: string;
  question_count: number;
  subject_filter: string | null;
  status: BattleStatus;
  challenger_score: number;
  opponent_score: number;
  winner_id: string | null;
  questions_data: BattleQuestion[];
  challenger_answers: BattleAnswer[];
  opponent_answers: BattleAnswer[];
  started_at: string | null;
  ended_at: string | null;
  created_at: string;
}

// ---- Question pool (built from CURRICULUM, multiple-choice with 4 options) ---

interface BattlePoolEntry {
  subjectId: string;
  subjectNameKz: string;
  question: BattleQuestion;
}

const BATTLE_POOL: readonly BattlePoolEntry[] = (() => {
  const out: BattlePoolEntry[] = [];
  for (const subject of CURRICULUM) {
    for (const module of subject.modules) {
      for (const node of module.nodes) {
        for (const q of node.questions) {
          if (q.type !== 'multiple_choice') continue;
          if (q.options.length !== 4) continue;
          const battleQ: BattleQuestion = {
            id: q.id,
            subjectId: subject.id,
            subjectNameKz: subject.nameKz,
            questionKz: q.questionKz,
            options: q.options,
            correctIndex: q.correctIndex,
            explanationKz: q.explanationKz,
          };
          out.push({ subjectId: subject.id, subjectNameKz: subject.nameKz, question: battleQ });
        }
      }
    }
  }
  return out;
})();

export interface BattleSubjectOption {
  id: string;
  nameKz: string;
  icon: string;
  available: number;
}

export const BATTLE_SUBJECTS: readonly BattleSubjectOption[] = CURRICULUM.map((s) => ({
  id: s.id,
  nameKz: s.nameKz,
  icon: s.icon,
  available: BATTLE_POOL.filter((p) => p.subjectId === s.id).length,
})).filter((s) => s.available > 0);

const shuffle = <T>(arr: readonly T[]): T[] => {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

// Pick `n` questions for a battle. If `subjectId` is null all subjects are eligible.
// When the pool is smaller than `n` we cycle through it again with a fresh shuffle.
export const pickBattleQuestions = (
  n: number,
  subjectId: string | null,
): readonly BattleQuestion[] => {
  const pool = subjectId ? BATTLE_POOL.filter((p) => p.subjectId === subjectId) : BATTLE_POOL;
  if (pool.length === 0) return [];
  const out: BattleQuestion[] = [];
  while (out.length < n) {
    for (const item of shuffle(pool)) {
      out.push(item.question);
      if (out.length >= n) break;
    }
  }
  return out;
};

export interface CreateBattlePayload {
  opponentId: string;
  questionCount: BattleQuestionCount;
  subjectId: string | null;
}

export const createBattle = async (payload: CreateBattlePayload): Promise<BattleRow> => {
  const me = currentUserId();
  if (!me) throw new Error('No active user');
  if (me === payload.opponentId) throw new Error('Cannot battle self');
  const questions = pickBattleQuestions(payload.questionCount, payload.subjectId);
  if (questions.length === 0) throw new Error('No questions available');
  const { data, error } = await supabase
    .from('battles')
    .insert({
      challenger_id: me,
      opponent_id: payload.opponentId,
      question_count: payload.questionCount,
      subject_filter: payload.subjectId,
      status: 'pending',
      questions_data: questions,
    })
    .select('*')
    .single();
  if (error) throw error;
  // Fire-and-forget notification — RPC bypasses RLS on notifications.
  try {
    await supabase.rpc('send_battle_notification', { p_battle_id: (data as BattleRow).id });
  } catch {
    // Soft-fail: the realtime subscription is the live channel anyway.
  }
  return data as BattleRow;
};

export const acceptBattle = async (battleId: string): Promise<void> => {
  const { error } = await supabase
    .from('battles')
    .update({ status: 'in_progress', started_at: new Date().toISOString() })
    .eq('id', battleId);
  if (error) throw error;
};

export const cancelBattle = async (battleId: string): Promise<void> => {
  const { error } = await supabase
    .from('battles')
    .update({ status: 'cancelled', ended_at: new Date().toISOString() })
    .eq('id', battleId);
  if (error) throw error;
};

export const getBattle = async (battleId: string): Promise<BattleRow | null> => {
  const { data, error } = await supabase
    .from('battles')
    .select('*')
    .eq('id', battleId)
    .maybeSingle();
  if (error) throw error;
  return (data as BattleRow | null) ?? null;
};

// Persist a single answer + cumulative score. Each player only writes to their
// own jsonb column so concurrent submissions from both sides do not collide.
export interface SubmitBattleAnswerPayload {
  battleId: string;
  role: 'challenger' | 'opponent';
  answers: readonly BattleAnswer[];
  score: number;
}

export const submitBattleAnswer = async (payload: SubmitBattleAnswerPayload): Promise<void> => {
  const patch =
    payload.role === 'challenger'
      ? { challenger_answers: payload.answers, challenger_score: payload.score }
      : { opponent_answers: payload.answers, opponent_score: payload.score };
  const { error } = await supabase.from('battles').update(patch).eq('id', payload.battleId);
  if (error) throw error;
};

// Marks a battle as completed, computes the winner, and updates total counters
// on the *current user's* row (each player updates their own counters).
export const finalizeBattle = async (battleId: string): Promise<BattleRow | null> => {
  const me = currentUserId();
  if (!me) return null;
  const row = await getBattle(battleId);
  if (!row) return null;
  let winnerId: string | null;
  if (row.challenger_score > row.opponent_score) winnerId = row.challenger_id;
  else if (row.opponent_score > row.challenger_score) winnerId = row.opponent_id;
  else winnerId = null; // tie
  if (row.status !== 'completed') {
    const { error } = await supabase
      .from('battles')
      .update({
        status: 'completed',
        winner_id: winnerId,
        ended_at: new Date().toISOString(),
      })
      .eq('id', battleId);
    if (error) throw error;
  }
  return { ...row, status: 'completed', winner_id: winnerId };
};

export interface BattleResultSummary {
  battle: BattleRow;
  myRole: 'challenger' | 'opponent';
  myScore: number;
  opponentScore: number;
  outcome: 'win' | 'loss' | 'tie';
  totalQuestions: number;
}

export const getBattleResult = async (battleId: string): Promise<BattleResultSummary | null> => {
  const me = currentUserId();
  if (!me) return null;
  const battle = await getBattle(battleId);
  if (!battle) return null;
  const myRole: 'challenger' | 'opponent' = battle.challenger_id === me ? 'challenger' : 'opponent';
  const myScore = myRole === 'challenger' ? battle.challenger_score : battle.opponent_score;
  const opponentScore = myRole === 'challenger' ? battle.opponent_score : battle.challenger_score;
  let outcome: 'win' | 'loss' | 'tie';
  if (myScore > opponentScore) outcome = 'win';
  else if (opponentScore > myScore) outcome = 'loss';
  else outcome = 'tie';
  return {
    battle,
    myRole,
    myScore,
    opponentScore,
    outcome,
    totalQuestions: battle.question_count,
  };
};

// Increment the player's battle counters on their users row. Called from the
// result screen once per player, only for completed (non-cancelled) battles.
export const incrementBattleStats = async (won: boolean): Promise<void> => {
  const user = useUserStore.getState().user;
  if (!user) return;
  const nextPlayed = (user.total_battles_played ?? 0) + 1;
  const nextWon = (user.total_battles_won ?? 0) + (won ? 1 : 0);
  const { error } = await supabase
    .from('users')
    .update({ total_battles_played: nextPlayed, total_battles_won: nextWon })
    .eq('id', user.id);
  if (error) throw error;
  useUserStore
    .getState()
    .updateUser({ total_battles_played: nextPlayed, total_battles_won: nextWon });
};

// ---- Realtime subscription for a single battle ----
// Combines:
//   * Postgres change events on the battles row (status / both score columns).
//   * Broadcast pings the peers send each other to flash their answer instantly,
//     before the DB roundtrip completes.

export interface BattleAnswerPing {
  role: 'challenger' | 'opponent';
  questionIndex: number;
  isCorrect: boolean;
  scoreAfter: number;
}

export interface BattleSubscriptionCallbacks {
  onRow?: (row: BattleRow) => void;
  onAnswerPing?: (ping: BattleAnswerPing) => void;
}

export interface BattleSubscription {
  channel: RealtimeChannel;
  broadcastAnswer: (ping: BattleAnswerPing) => Promise<void>;
  unsubscribe: () => void;
}

export const subscribeBattle = (
  battleId: string,
  callbacks: BattleSubscriptionCallbacks,
): BattleSubscription => {
  const channel = supabase.channel(`battle:${battleId}`, {
    config: { broadcast: { self: false } },
  });
  channel.on(
    'postgres_changes',
    { event: 'UPDATE', schema: 'public', table: 'battles', filter: `id=eq.${battleId}` },
    (payload) => {
      if (callbacks.onRow) callbacks.onRow(payload.new as BattleRow);
    },
  );
  channel.on('broadcast', { event: 'answer' }, (msg) => {
    if (callbacks.onAnswerPing) {
      callbacks.onAnswerPing(msg.payload as BattleAnswerPing);
    }
  });
  channel.subscribe();
  return {
    channel,
    broadcastAnswer: async (ping) => {
      await channel.send({ type: 'broadcast', event: 'answer', payload: ping });
    },
    unsubscribe: () => {
      void supabase.removeChannel(channel);
    },
  };
};

// Subscribe to changes on any battle whose opponent_id is the current user.
// Used by the home / friends screens to auto-route into BattleWaiting when a
// new pending invite arrives.
export const subscribeIncomingBattleInvites = (
  onInvite: (battle: BattleRow) => void,
): (() => void) => {
  const me = currentUserId();
  if (!me) return () => undefined;
  const channel = supabase.channel(`battle_invites:${me}`);
  channel.on(
    'postgres_changes',
    {
      event: 'INSERT',
      schema: 'public',
      table: 'battles',
      filter: `opponent_id=eq.${me}`,
    },
    (payload) => {
      const row = payload.new as BattleRow;
      if (row.status === 'pending') onInvite(row);
    },
  );
  channel.subscribe();
  return () => {
    void supabase.removeChannel(channel);
  };
};

export const getRecentAchievements = async (limit = 6): Promise<readonly UnlockedAchievement[]> => {
  const userId = currentUserId();
  if (!userId) return [];
  const { data, error } = await supabase
    .from('user_achievements')
    .select('achievement_id, unlocked_at')
    .eq('user_id', userId)
    .order('unlocked_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  const rows = (data ?? []) as { achievement_id: string; unlocked_at: string }[];
  const map = new Map(ACHIEVEMENTS.map((a) => [a.id, a]));
  return rows
    .map<UnlockedAchievement | null>((r) => {
      const a = map.get(r.achievement_id);
      return a ? { achievement: a, unlocked_at: r.unlocked_at } : null;
    })
    .filter((x): x is UnlockedAchievement => x !== null);
};

// All achievement ids the user has unlocked. Used by the achievements grid
// on the profile screen to grey out locked entries.
export const getUnlockedAchievementIds = async (): Promise<ReadonlySet<string>> => {
  const userId = currentUserId();
  const out = new Set<string>();
  if (!userId) return out;
  const { data, error } = await supabase
    .from('user_achievements')
    .select('achievement_id')
    .eq('user_id', userId);
  if (error) throw error;
  for (const row of (data ?? []) as { achievement_id: string }[]) {
    out.add(row.achievement_id);
  }
  return out;
};

// ----------------------------------------------------------------------------
// Leaderboard
// ----------------------------------------------------------------------------

export type LeaderboardScope = 'global' | 'city' | 'school' | 'friends';

export interface LeaderboardEntry extends PublicUserProfile {
  rank: number;
}

// Compute the rank list for a given scope. For 'friends' we compose the list
// in JS (friends + self) and rank by akyl_points. The other scopes hit the
// get_leaderboard SECURITY DEFINER RPC.
export const getLeaderboard = async (
  scope: LeaderboardScope,
  limit = 100,
): Promise<readonly LeaderboardEntry[]> => {
  if (scope === 'friends') {
    const me = useUserStore.getState().user;
    if (!me) return [];
    const friends = await getFriends();
    const combined: PublicUserProfile[] = [
      {
        id: me.id,
        qosqanat_id: me.qosqanat_id,
        full_name: me.full_name,
        city: me.city,
        school: me.school,
        grade: me.grade,
        assistant_type: me.assistant_type,
        level: me.level,
        akyl_points: me.akyl_points,
      },
      ...friends.map((f) => ({
        id: f.id,
        qosqanat_id: f.qosqanat_id,
        full_name: f.full_name,
        city: f.city,
        school: f.school,
        grade: f.grade,
        assistant_type: f.assistant_type,
        level: f.level,
        akyl_points: f.akyl_points,
      })),
    ];
    combined.sort((a, b) => b.akyl_points - a.akyl_points || b.level - a.level);
    return combined.slice(0, limit).map((u, i) => ({ ...u, rank: i + 1 }));
  }
  const { data, error } = await supabase.rpc('get_leaderboard', {
    p_scope: scope,
    p_limit: limit,
  });
  if (error) throw error;
  return (
    (data ?? []) as {
      id: string;
      qosqanat_id: string;
      full_name: string;
      city: string;
      school: string;
      grade: number;
      assistant_type: AssistantType | null;
      level: number;
      akyl_points: number;
      rank: number;
    }[]
  ).map((r) => ({
    id: r.id,
    qosqanat_id: r.qosqanat_id,
    full_name: r.full_name,
    city: r.city,
    school: r.school,
    grade: r.grade,
    assistant_type: r.assistant_type,
    level: r.level,
    akyl_points: r.akyl_points,
    rank: r.rank,
  }));
};

export const getSchoolUserCount = async (): Promise<number> => {
  const { data, error } = await supabase.rpc('count_users_at_my_school');
  if (error) throw error;
  return (data as number | null) ?? 0;
};

// ----------------------------------------------------------------------------
// Activity & recent battles (profile screen)
// ----------------------------------------------------------------------------

export interface ActivityDay {
  date: string; // YYYY-MM-DD
  count: number; // total tasks + battles completed that day
}

// Returns counts per calendar day for the past `days` days (inclusive of today).
// Reads from task_progress.completed_at and battles.ended_at — both are RLS-
// scoped to the current user.
export const getActivityMap = async (days = 119): Promise<readonly ActivityDay[]> => {
  const me = currentUserId();
  const buckets = new Map<string, number>();
  const today = new Date();
  for (let i = 0; i < days; i += 1) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    buckets.set(key, 0);
  }
  if (!me) {
    return Array.from(buckets, ([date, count]) => ({ date, count })).reverse();
  }
  const since = new Date(today);
  since.setDate(since.getDate() - days + 1);
  const sinceISO = since.toISOString();

  const [{ data: tp }, { data: bt }] = await Promise.all([
    supabase
      .from('task_progress')
      .select('completed_at')
      .eq('user_id', me)
      .gte('completed_at', sinceISO),
    supabase
      .from('battles')
      .select('ended_at, challenger_id, opponent_id')
      .or(`challenger_id.eq.${me},opponent_id.eq.${me}`)
      .gte('ended_at', sinceISO)
      .not('ended_at', 'is', null),
  ]);

  const bump = (iso: string | null) => {
    if (!iso) return;
    const key = iso.slice(0, 10);
    if (buckets.has(key)) buckets.set(key, (buckets.get(key) ?? 0) + 1);
  };
  for (const row of (tp ?? []) as { completed_at: string | null }[]) bump(row.completed_at);
  for (const row of (bt ?? []) as { ended_at: string | null }[]) bump(row.ended_at);

  // Reverse so oldest day comes first — that's the order the grid renders.
  return Array.from(buckets, ([date, count]) => ({ date, count })).reverse();
};

// ---- Recent battles ----

export interface RecentBattleEntry {
  battleId: string;
  endedAt: string;
  opponent: PublicUserProfile;
  myScore: number;
  opponentScore: number;
  outcome: 'win' | 'loss' | 'tie';
  totalQuestions: number;
}

export const getRecentBattles = async (limit = 5): Promise<readonly RecentBattleEntry[]> => {
  const me = currentUserId();
  if (!me) return [];
  const { data, error } = await supabase
    .from('battles')
    .select(
      'id, challenger_id, opponent_id, challenger_score, opponent_score, winner_id, question_count, ended_at, status',
    )
    .or(`challenger_id.eq.${me},opponent_id.eq.${me}`)
    .eq('status', 'completed')
    .order('ended_at', { ascending: false, nullsFirst: false })
    .limit(limit);
  if (error) throw error;
  const rows = (data ?? []) as {
    id: string;
    challenger_id: string;
    opponent_id: string;
    challenger_score: number;
    opponent_score: number;
    winner_id: string | null;
    question_count: number;
    ended_at: string | null;
  }[];
  if (rows.length === 0) return [];
  const otherIds = rows.map((r) => (r.challenger_id === me ? r.opponent_id : r.challenger_id));
  const uniqueIds = Array.from(new Set(otherIds));
  const { data: uRows, error: uErr } = await supabase
    .from('users')
    .select('id, qosqanat_id, full_name, city, school, grade, assistant_type, level, akyl_points')
    .in('id', uniqueIds);
  if (uErr) throw uErr;
  const userMap = new Map<string, PublicUserProfile>(
    ((uRows ?? []) as PublicUserProfile[]).map((u) => [u.id, u]),
  );
  return rows
    .map<RecentBattleEntry | null>((r) => {
      const oppId = r.challenger_id === me ? r.opponent_id : r.challenger_id;
      const opp = userMap.get(oppId);
      if (!opp) return null;
      const myScore = r.challenger_id === me ? r.challenger_score : r.opponent_score;
      const opponentScore = r.challenger_id === me ? r.opponent_score : r.challenger_score;
      let outcome: 'win' | 'loss' | 'tie';
      if (r.winner_id === me) outcome = 'win';
      else if (r.winner_id === null) outcome = 'tie';
      else outcome = 'loss';
      return {
        battleId: r.id,
        endedAt: r.ended_at ?? '',
        opponent: opp,
        myScore,
        opponentScore,
        outcome,
        totalQuestions: r.question_count,
      };
    })
    .filter((x): x is RecentBattleEntry => x !== null);
};
