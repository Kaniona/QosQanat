import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { Pressable, Text, StyleSheet, ActivityIndicator, ViewStyle } from 'react-native';
import Animated, { useSharedValue, useAnimatedStyle, withSpring } from 'react-native-reanimated';

import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

interface Props {
  title: string;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  gradientColors?: readonly [string, string];
  style?: ViewStyle;
  testID?: string;
}

const DEFAULT_COLORS: readonly [string, string] = [colors.primary, colors.secondary];

const GradientButton: React.FC<Props> = ({
  title,
  onPress,
  disabled = false,
  loading = false,
  gradientColors = DEFAULT_COLORS,
  style,
  testID,
}) => {
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const isInactive = disabled || loading;

  return (
    <Pressable
      testID={testID}
      onPressIn={() => {
        if (!isInactive) scale.value = withSpring(0.96, { damping: 14 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 14 });
      }}
      onPress={onPress}
      disabled={isInactive}
    >
      <Animated.View style={[animatedStyle, isInactive && styles.inactive, style]}>
        <LinearGradient
          colors={gradientColors}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.button}
        >
          {loading ? (
            <ActivityIndicator color={colors.white} />
          ) : (
            <Text style={styles.text}>{title}</Text>
          )}
        </LinearGradient>
      </Animated.View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  button: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.lg,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 56,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 6,
  },
  text: {
    color: colors.white,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.bold,
    letterSpacing: 0.3,
  },
  inactive: {
    opacity: 0.5,
  },
});

export default GradientButton;
