import React from 'react';
import Svg, { Path, Circle, Defs, LinearGradient, Stop } from 'react-native-svg';

import { colors } from '@/theme';

interface Props {
  size?: number;
}

const Logo: React.FC<Props> = ({ size = 140 }) => {
  return (
    <Svg width={size} height={size * 0.66} viewBox="0 0 120 80">
      <Defs>
        <LinearGradient id="wingGrad" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor={colors.white} stopOpacity="1" />
          <Stop offset="1" stopColor={colors.white} stopOpacity="0.75" />
        </LinearGradient>
      </Defs>
      <Path d="M 60 42 Q 32 18, 8 30 Q 6 44, 22 52 Q 40 56, 60 42 Z" fill="url(#wingGrad)" />
      <Path d="M 60 42 Q 88 18, 112 30 Q 114 44, 98 52 Q 80 56, 60 42 Z" fill="url(#wingGrad)" />
      <Circle cx="60" cy="42" r="9" fill={colors.gold} />
      <Circle cx="60" cy="42" r="4" fill="#1A1A4E" />
    </Svg>
  );
};

export default Logo;
