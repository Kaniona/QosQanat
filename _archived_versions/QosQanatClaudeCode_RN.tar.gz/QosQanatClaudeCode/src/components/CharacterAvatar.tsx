import React from 'react';
import Svg, { Circle, Defs, LinearGradient, Path, Rect, Stop, Ellipse } from 'react-native-svg';

import { colors } from '@/theme';
import type { AssistantType } from '@/types';

interface Props {
  type: AssistantType;
  size?: number;
}

const SKIN = '#F8C8A8';
const HAIR = '#1F1A33';
const MOUTH = '#1A1A4E';

const CharacterAvatar: React.FC<Props> = ({ type, size = 160 }) => {
  const isBektur = type === 'bektur';
  const main = isBektur ? colors.bekturColor : colors.nazymColor;
  const accent = isBektur ? '#7B9BFF' : '#FFB0CC';
  const gradId = `auraGrad-${type}`;

  return (
    <Svg width={size} height={size * 1.25} viewBox="0 0 100 125">
      <Defs>
        <LinearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor={main} stopOpacity="0.35" />
          <Stop offset="1" stopColor={main} stopOpacity="0.05" />
        </LinearGradient>
      </Defs>

      {/* Aura background */}
      <Circle cx="50" cy="55" r="48" fill={`url(#${gradId})`} />

      {/* Body / shirt */}
      <Path d="M 22 122 Q 22 90, 50 88 Q 78 90, 78 122 Z" fill={main} />
      <Rect x="44" y="78" width="12" height="14" rx="3" fill={SKIN} />

      {/* Head */}
      <Circle cx="50" cy="50" r="26" fill={SKIN} />

      {/* Hair */}
      {isBektur ? (
        <Path
          d="M 24 50 Q 26 24, 50 24 Q 74 24, 76 50 Q 70 38, 50 36 Q 30 38, 24 50 Z"
          fill={HAIR}
        />
      ) : (
        <>
          <Path
            d="M 22 56 Q 22 22, 50 22 Q 78 22, 78 56 Q 72 40, 50 38 Q 28 40, 22 56 Z"
            fill={HAIR}
          />
          <Ellipse cx="18" cy="72" rx="6" ry="14" fill={HAIR} />
          <Ellipse cx="82" cy="72" rx="6" ry="14" fill={HAIR} />
          <Circle cx="32" cy="34" r="4" fill={accent} />
        </>
      )}

      {/* Cheeks */}
      <Circle cx="36" cy="58" r="3" fill={accent} opacity="0.55" />
      <Circle cx="64" cy="58" r="3" fill={accent} opacity="0.55" />

      {/* Eyes */}
      <Circle cx="41" cy="52" r="2.8" fill={MOUTH} />
      <Circle cx="59" cy="52" r="2.8" fill={MOUTH} />
      <Circle cx="42" cy="51" r="0.9" fill={colors.white} />
      <Circle cx="60" cy="51" r="0.9" fill={colors.white} />

      {/* Smile */}
      <Path
        d="M 42 64 Q 50 70, 58 64"
        stroke={MOUTH}
        strokeWidth="2"
        strokeLinecap="round"
        fill="none"
      />
    </Svg>
  );
};

export default CharacterAvatar;
