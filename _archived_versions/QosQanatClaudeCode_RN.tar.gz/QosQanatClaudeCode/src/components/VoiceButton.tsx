import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, {
  Easing,
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';

import AvatarDisplay from '@/components/Avatar/AvatarDisplay';
import { VOICE_HELP } from '@/config/voiceCommands';
import type { AuthStackParamList } from '@/navigation/types';
import {
  checkVoiceAvailability,
  openExternalUrl,
  parseAndResolve,
  resolveFallbackUrl,
  speak,
  startListening,
  stopSpeaking,
  type ListenHandle,
} from '@/services/voice';
import { useSettingsStore } from '@/store/settingsStore';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import type { AssistantType } from '@/types';

type Nav = NativeStackNavigationProp<AuthStackParamList>;

const KZ = {
  fabA11y: 'Дауыстық көмекші',
  say: 'Айт!',
  starting: 'Тыңдаймын...',
  listening: 'Сөйлеңіз...',
  thinking: 'Ойлап жатырмын...',
  defaultPrompt: 'Сұрағыңызды айтыңыз немесе командаларды таңдаңыз:',
  permissionsTitle: 'Дауысты тану',
  permissionsBody: (h: string) => h,
  cancel: 'Болдырмау',
  hold: 'Қайта тыңдау',
  close: 'Жабу',
  helpTitle: 'Не айтуға болады?',
  cantOpen: 'Бұл қолданбаны аша алмадым. Орнатылған ба?',
  busy: 'Тоса тұрыңыз...',
};

interface VoiceButtonProps {
  /** Distance from the bottom edge of the screen for the FAB. */
  bottomOffset: number;
  /** Optional override for the accent color (defaults by assistant). */
  color?: string;
}

const assistantOrDefault = (t: AssistantType | null | undefined): AssistantType => t ?? 'bektur';

// ----------------------------------------------------------------------------
// FAB — opens the overlay.
// ----------------------------------------------------------------------------

interface FabProps {
  color: string;
  onPress: () => void;
  bottom: number;
}

const Fab: React.FC<FabProps> = ({ color, onPress, bottom }) => {
  const pulse = useSharedValue(0);
  const pressScale = useSharedValue(1);

  useEffect(() => {
    pulse.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1100, easing: Easing.inOut(Easing.quad) }),
        withTiming(0, { duration: 1100, easing: Easing.inOut(Easing.quad) }),
      ),
      -1,
      false,
    );
    return () => { cancelAnimation(pulse); };
  }, [pulse]);

  const ringStyle = useAnimatedStyle(() => ({
    transform: [{ scale: 1 + pulse.value * 0.5 }],
    opacity: 0.55 * (1 - pulse.value),
  }));
  const buttonStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pressScale.value * (1 + pulse.value * 0.04) }],
  }));

  return (
    <View pointerEvents="box-none" style={[styles.fabWrap, { bottom }]}>
      <Animated.View style={[styles.fabRing, { backgroundColor: color }, ringStyle]} />
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={KZ.fabA11y}
        onPressIn={() => {
          pressScale.value = withSpring(0.9, { damping: 14, stiffness: 240 });
        }}
        onPressOut={() => {
          pressScale.value = withSpring(1, { damping: 12, stiffness: 200 });
        }}
        onPress={onPress}
      >
        <Animated.View style={[styles.fabButton, { backgroundColor: color }, buttonStyle]}>
          <Text style={styles.fabIcon}>🎤</Text>
        </Animated.View>
      </Pressable>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Waveform — 5 bars that bounce while listening.
// ----------------------------------------------------------------------------

const Waveform: React.FC<{ active: boolean; color: string }> = ({ active, color }) => {
  const bars = [0, 1, 2, 3, 4];
  return (
    <View style={styles.waveRow}>
      {bars.map((i) => (
        <WaveBar key={i} index={i} active={active} color={color} />
      ))}
    </View>
  );
};

const WaveBar: React.FC<{ index: number; active: boolean; color: string }> = ({
  index,
  active,
  color,
}) => {
  const h = useSharedValue(8);
  useEffect(() => {
    if (!active) {
      cancelAnimation(h);
      h.value = withTiming(8, { duration: 180 });
      return;
    }
    h.value = withRepeat(
      withSequence(
        withTiming(8 + Math.random() * 26 + index * 2, {
          duration: 280 + index * 40,
          easing: Easing.inOut(Easing.quad),
        }),
        withTiming(10, { duration: 280 + index * 40, easing: Easing.inOut(Easing.quad) }),
      ),
      -1,
      true,
    );
    return () => { cancelAnimation(h); };
  }, [active, h, index]);
  const style = useAnimatedStyle(() => ({ height: h.value }));
  return (
    <Animated.View
      style={[styles.waveBar, { backgroundColor: color }, style]}
    />
  );
};

// ----------------------------------------------------------------------------
// Lip-sync — fakes mouth movement by oscillating a "talking" pip below the
// avatar. AvatarBase has no mouth-open state to drive natively, so we render
// a small dot pulsing in size while speaking.
// ----------------------------------------------------------------------------

const Mouth: React.FC<{ active: boolean; color: string }> = ({ active, color }) => {
  const scale = useSharedValue(0);
  useEffect(() => {
    if (!active) {
      cancelAnimation(scale);
      scale.value = withTiming(0, { duration: 180 });
      return;
    }
    scale.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 140, easing: Easing.inOut(Easing.quad) }),
        withTiming(0.35, { duration: 140, easing: Easing.inOut(Easing.quad) }),
        withTiming(0.9, { duration: 140, easing: Easing.inOut(Easing.quad) }),
        withTiming(0.5, { duration: 140, easing: Easing.inOut(Easing.quad) }),
      ),
      -1,
      false,
    );
    return () => { cancelAnimation(scale); };
  }, [active, scale]);
  const style = useAnimatedStyle(() => ({
    transform: [{ scale: 0.4 + scale.value * 0.9 }],
    opacity: 0.6 + scale.value * 0.4,
  }));
  return <Animated.View style={[styles.mouthDot, { backgroundColor: color }, style]} />;
};

// ----------------------------------------------------------------------------
// Avatar tile with glowing ring.
// ----------------------------------------------------------------------------

interface AvatarTileProps {
  assistant: AssistantType;
  speaking: boolean;
  listening: boolean;
  color: string;
}

const AvatarTile: React.FC<AvatarTileProps> = ({ assistant, speaking, listening, color }) => {
  const pulse = useSharedValue(0);
  useEffect(() => {
    pulse.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 900, easing: Easing.inOut(Easing.quad) }),
        withTiming(0, { duration: 900, easing: Easing.inOut(Easing.quad) }),
      ),
      -1,
    );
    return () => { cancelAnimation(pulse); };
  }, [pulse]);
  const glow = useAnimatedStyle(() => ({
    opacity: 0.35 + pulse.value * 0.5,
    transform: [{ scale: 1 + pulse.value * 0.12 }],
  }));
  return (
    <View style={styles.avatarTile}>
      <Animated.View
        style={[styles.avatarGlow, { backgroundColor: color, shadowColor: color }, glow]}
      />
      <AvatarDisplay
        assistantType={assistant}
        action={speaking ? 'celebrate' : listening ? 'thinking' : 'idle'}
        size={160}
      />
      <View style={styles.mouthWrap}>
        <Mouth active={speaking} color={color} />
      </View>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Voice overlay (modal)
// ----------------------------------------------------------------------------

type Phase = 'idle' | 'starting' | 'listening' | 'thinking' | 'speaking' | 'error';

interface OverlayProps {
  visible: boolean;
  assistant: AssistantType;
  accent: string;
  onClose: () => void;
}

const Overlay: React.FC<OverlayProps> = ({ visible, assistant, accent, onClose }) => {
  const nav = useNavigation<Nav>();
  const animationsEnabled = useSettingsStore((s) => s.animations);

  const [phase, setPhase] = useState<Phase>('idle');
  const [transcript, setTranscript] = useState('');
  const [reply, setReply] = useState('');
  const [busy, setBusy] = useState(false);
  const listenHandle = useRef<ListenHandle | null>(null);
  const closingRef = useRef(false);

  const bubbleScale = useSharedValue(0);
  const bubbleOpacity = useSharedValue(0);

  // Show the response bubble whenever there is text in `reply`.
  useEffect(() => {
    if (reply) {
      bubbleOpacity.value = withTiming(1, { duration: 200 });
      bubbleScale.value = withSpring(1, { damping: 12, stiffness: 220 });
    } else {
      bubbleOpacity.value = withTiming(0, { duration: 160 });
      bubbleScale.value = withTiming(0.85, { duration: 160 });
    }
  }, [reply, bubbleOpacity, bubbleScale]);

  const bubbleStyle = useAnimatedStyle(() => ({
    opacity: bubbleOpacity.value,
    transform: [{ scale: bubbleScale.value }],
  }));

  // Hard reset everything on close.
  useEffect(() => {
    if (visible) {
      closingRef.current = false;
      setTranscript('');
      setReply('');
      setPhase('idle');
      // Auto-start listening when the overlay opens — feels like Siri.
      void beginListen();
    } else {
      closingRef.current = true;
      stopSpeaking();
      if (listenHandle.current) {
        void listenHandle.current.cancel();
        listenHandle.current = null;
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible]);

  const runIntent = useCallback(
    async (utterance: string) => {
      setBusy(true);
      setPhase('thinking');
      try {
        const { reply: resolved } = await parseAndResolve(utterance, assistant);
        setReply(resolved.spokenKz);
        setPhase('speaking');
        speak(resolved.spokenKz, assistant, {
          onDone: () => {
            if (closingRef.current) return;
            setPhase('idle');
            // Side-effects fire AFTER the TTS sentence finishes so the user
            // hears the confirmation before the screen transitions.
            if (resolved.action?.type === 'navigate') {
              const route = resolved.action.route;
              onClose();
              // Cast through `as never` because the union of route names is
              // wider than any single overload of `navigate()`.
              setTimeout(() => { nav.navigate(route as never); }, 200);
            } else if (resolved.action?.type === 'open_url') {
              const target = resolved.action.url;
              const fallback = resolveFallbackUrl(target);
              void openExternalUrl(target, fallback).then((ok) => {
                if (!ok) {
                  Alert.alert(KZ.cantOpen);
                }
              });
              onClose();
            }
          },
        });
      } finally {
        setBusy(false);
      }
    },
    [assistant, nav, onClose],
  );

  const beginListen = useCallback(async () => {
    if (busy) return;
    const status = checkVoiceAvailability();
    if (!status.available) {
      setReply(status.hint);
      setPhase('error');
      speak(status.hint, assistant);
      return;
    }
    setTranscript('');
    setReply('');
    setPhase('starting');
    listenHandle.current = await startListening(
      {
        onStatus: (s, msg) => {
          if (closingRef.current) return;
          if (s === 'starting') setPhase('starting');
          else if (s === 'listening') setPhase('listening');
          else if (s === 'error' && msg) {
            setReply(msg);
            setPhase('error');
          }
        },
        onPartial: (text) => {
          if (closingRef.current) return;
          setTranscript(text);
        },
        onFinal: (text) => {
          if (closingRef.current) return;
          setTranscript(text);
          void runIntent(text);
        },
        onError: (errKz) => {
          if (closingRef.current) return;
          setReply(errKz);
          setPhase('error');
          speak(errKz, assistant);
        },
      },
      7000,
    );
  }, [assistant, busy, runIntent]);

  // Tapping an example phrase simulates as if the user spoke it. This makes
  // the overlay useful even on Expo Go where STT isn't available.
  const handleExamplePress = useCallback(
    (phrase: string) => {
      if (busy) return;
      setTranscript(phrase);
      void runIntent(phrase);
    },
    [busy, runIntent],
  );

  const statusText = useMemo(() => {
    switch (phase) {
      case 'starting':
        return KZ.starting;
      case 'listening':
        return KZ.listening;
      case 'thinking':
        return KZ.thinking;
      case 'speaking':
        return '';
      case 'error':
        return '';
      default:
        return KZ.say;
    }
  }, [phase]);

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <LinearGradient
          colors={['rgba(10,10,30,0.92)', 'rgba(20,20,60,0.96)'] as readonly [string, string]}
          style={StyleSheet.absoluteFill}
        />
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />

        <View style={styles.overlayContent} pointerEvents="box-none">
          {/* Speech bubble (above the avatar) */}
          {reply ? (
            <Animated.View style={[styles.bubble, bubbleStyle]}>
              <Text style={styles.bubbleText}>{reply}</Text>
              <View style={styles.bubbleTail} />
            </Animated.View>
          ) : null}

          {/* Avatar */}
          <AvatarTile
            assistant={assistant}
            speaking={phase === 'speaking' && animationsEnabled}
            listening={phase === 'listening'}
            color={accent}
          />

          {/* Status + waveform */}
          <View style={styles.statusRow}>
            <Text style={[styles.statusText, { color: accent }]}>{statusText}</Text>
            <Waveform active={phase === 'listening' || phase === 'starting'} color={accent} />
          </View>

          {/* Live transcript */}
          {transcript ? (
            <View style={styles.transcriptBox}>
              <Text style={styles.transcriptText}>{`"${transcript}"`}</Text>
            </View>
          ) : null}

          {/* Help / examples */}
          {phase === 'idle' || phase === 'error' ? (
            <View style={styles.helpBox}>
              <Text style={styles.helpTitle}>{KZ.helpTitle}</Text>
              <ScrollView style={styles.helpScroll}>
                {VOICE_HELP.map((g) => (
                  <View key={g.titleKz} style={{ marginBottom: spacing.sm }}>
                    <Text style={styles.helpGroupTitle}>{g.titleKz}</Text>
                    <View style={styles.helpChips}>
                      {g.examples.map((ex) => (
                        <Pressable
                          key={ex}
                          onPress={() => { handleExamplePress(ex); }}
                          style={styles.helpChip}
                          disabled={busy}
                        >
                          <Text style={styles.helpChipText}>{`"${ex}"`}</Text>
                        </Pressable>
                      ))}
                    </View>
                  </View>
                ))}
              </ScrollView>
            </View>
          ) : null}

          {/* Controls */}
          <View style={styles.controlsRow}>
            <Pressable style={styles.controlBtn} onPress={onClose}>
              <Text style={styles.controlBtnText}>{KZ.close}</Text>
            </Pressable>
            <Pressable
              style={[styles.controlBtn, { backgroundColor: accent, borderColor: accent }]}
              onPress={() => void beginListen()}
              disabled={busy}
            >
              <Text style={[styles.controlBtnText, { color: colors.white }]}>
                {busy ? KZ.busy : `🎤 ${KZ.hold}`}
              </Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
};

// ----------------------------------------------------------------------------
// Public component
// ----------------------------------------------------------------------------

const VoiceButton: React.FC<VoiceButtonProps> = ({ bottomOffset, color }) => {
  const user = useUserStore((s) => s.user);
  const assistant = assistantOrDefault(user?.assistant_type);
  const [open, setOpen] = useState(false);

  const accent = color ?? (assistant === 'nazym' ? colors.nazymColor : colors.bekturColor);

  return (
    <>
      <Fab color={accent} onPress={() => { setOpen(true); }} bottom={bottomOffset} />
      <Overlay
        visible={open}
        assistant={assistant}
        accent={accent}
        onClose={() => { setOpen(false); }}
      />
    </>
  );
};

// ----------------------------------------------------------------------------
// Styles
// ----------------------------------------------------------------------------

const FAB_SIZE = 64;

const styles = StyleSheet.create({
  waveBar: {
    width: 6,
    marginHorizontal: 3,
    borderRadius: 3,
  },
  helpScroll: {
    maxHeight: 180,
  },
  fabWrap: {
    position: 'absolute',
    right: spacing.md,
    width: FAB_SIZE,
    height: FAB_SIZE,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fabRing: {
    position: 'absolute',
    width: FAB_SIZE,
    height: FAB_SIZE,
    borderRadius: FAB_SIZE / 2,
  },
  fabButton: {
    width: FAB_SIZE,
    height: FAB_SIZE,
    borderRadius: FAB_SIZE / 2,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.35,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
  fabIcon: { fontSize: 28 },

  backdrop: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  overlayContent: {
    width: '90%',
    maxWidth: 420,
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.lg,
  },

  // ---- Bubble ----
  bubble: {
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderRadius: radius.lg,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    maxWidth: '95%',
    shadowColor: '#000',
    shadowOpacity: 0.4,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
  },
  bubbleText: {
    color: colors.text,
    fontSize: fontSize.md,
    fontWeight: fontWeight.bold,
    lineHeight: 22,
    textAlign: 'center',
  },
  bubbleTail: {
    position: 'absolute',
    bottom: -8,
    left: '50%',
    marginLeft: -8,
    width: 0,
    height: 0,
    borderLeftWidth: 8,
    borderRightWidth: 8,
    borderTopWidth: 10,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderTopColor: 'rgba(255,255,255,0.95)',
  },

  // ---- Avatar ----
  avatarTile: {
    width: 200,
    height: 200,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  avatarGlow: {
    position: 'absolute',
    width: 220,
    height: 220,
    borderRadius: 110,
    shadowOpacity: 0.6,
    shadowRadius: 28,
    shadowOffset: { width: 0, height: 0 },
    opacity: 0.4,
  },
  mouthWrap: {
    position: 'absolute',
    bottom: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mouthDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
  },

  // ---- Status + waveform ----
  statusRow: {
    alignItems: 'center',
    gap: spacing.sm,
  },
  statusText: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 0.5,
  },
  waveRow: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 40,
  },

  // ---- Transcript ----
  transcriptBox: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
    maxWidth: '95%',
  },
  transcriptText: {
    color: colors.white,
    fontSize: fontSize.md,
    fontStyle: 'italic',
    textAlign: 'center',
  },

  // ---- Help ----
  helpBox: {
    backgroundColor: 'rgba(0,0,0,0.35)',
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    width: '100%',
  },
  helpTitle: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.extrabold,
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: spacing.sm,
  },
  helpGroupTitle: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 11,
    fontWeight: fontWeight.bold,
    marginBottom: 4,
  },
  helpChips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  helpChip: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 6,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: radius.full,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  helpChipText: {
    color: colors.white,
    fontSize: 12,
    fontWeight: fontWeight.semibold,
  },

  // ---- Controls ----
  controlsRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    width: '100%',
  },
  controlBtn: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  controlBtnText: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
  },
});

export default VoiceButton;
