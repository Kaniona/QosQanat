import { LinearGradient } from 'expo-linear-gradient';
import React, { useEffect } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';

import type { DailyQuestState } from '@/services/api';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

interface Props {
  state: DailyQuestState;
  onClaim: (state: DailyQuestState) => void;
}

const CARD_W = 160;
const CARD_H = 120;
const KZ_CLAIM = 'Алу';
const KZ_DONE = 'Аяқталды';

const QuestCard: React.FC<Props> = ({ state, onClaim }) => {
  const { quest, progress, target, status } = state;
  const ratio = Math.min(1, progress / Math.max(1, target));
  const isClaimable = status === 'completed';
  const isClaimed = status === 'claimed';

  const fill = useSharedValue(0);
  const glow = useSharedValue(0);
  const pressScale = useSharedValue(1);

  useEffect(() => {
    fill.value = withTiming(ratio, { duration: 700, easing: Easing.out(Easing.cubic) });
  }, [ratio, fill]);

  useEffect(() => {
    if (isClaimable) {
      glow.value = withRepeat(
        withSequence(
          withTiming(1, { duration: 800, easing: Easing.inOut(Easing.quad) }),
          withTiming(0, { duration: 800, easing: Easing.inOut(Easing.quad) }),
        ),
        -1,
        false,
      );
    } else {
      glow.value = withTiming(0, { duration: 200 });
    }
  }, [isClaimable, glow]);

  const fillStyle = useAnimatedStyle(() => ({
    width: `${fill.value * 100}%`,
  }));

  const borderStyle = useAnimatedStyle(() => ({
    borderColor: isClaimable
      ? `rgba(0, 196, 140, ${0.7 + glow.value * 0.3})`
      : isClaimed
        ? 'rgba(156, 163, 175, 0.4)'
        : colors.border,
    shadowOpacity: isClaimable ? 0.25 + glow.value * 0.35 : 0,
  }));

  const claimStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pressScale.value }],
  }));

  const onPressIn = () => {
    pressScale.value = withSpring(0.94, { damping: 14, stiffness: 240 });
  };
  const onPressOut = () => {
    pressScale.value = withSpring(1, { damping: 12, stiffness: 200 });
  };

  return (
    <Animated.View style={[styles.card, borderStyle]}>
      <View style={styles.row}>
        <Text style={styles.icon}>{quest.icon}</Text>
        <Text style={styles.title} numberOfLines={2}>
          {quest.titleKz}
        </Text>
      </View>

      <View style={styles.progressWrap}>
        <View style={styles.progressTrack}>
          <Animated.View style={[styles.progressFill, fillStyle]}>
            <LinearGradient
              colors={
                isClaimed
                  ? (['#9CA3AF', '#9CA3AF'] as readonly [string, string])
                  : isClaimable
                    ? ([colors.success, '#3DDC97'] as readonly [string, string])
                    : ([colors.primary, colors.secondary] as readonly [string, string])
              }
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={StyleSheet.absoluteFill}
            />
          </Animated.View>
        </View>
        <Text style={styles.progressLabel}>
          {progress}/{target}
        </Text>
      </View>

      <View style={styles.footer}>
        <View style={styles.rewards}>
          {quest.rewardCoins > 0 ? (
            <Text style={styles.rewardText}>🪙 {quest.rewardCoins}</Text>
          ) : null}
          {quest.rewardXp > 0 ? <Text style={styles.rewardText}>✨ {quest.rewardXp}</Text> : null}
          {quest.rewardAkyl > 0 ? (
            <Text style={styles.rewardText}>🔮 {quest.rewardAkyl}</Text>
          ) : null}
        </View>

        {isClaimable ? (
          <Pressable
            onPressIn={onPressIn}
            onPressOut={onPressOut}
            onPress={() => { onClaim(state); }}
            style={styles.claimPressable}
          >
            <Animated.View style={[styles.claimButton, claimStyle]}>
              <Text style={styles.claimText}>{KZ_CLAIM}</Text>
            </Animated.View>
          </Pressable>
        ) : isClaimed ? (
          <View style={[styles.claimButton, styles.claimedButton]}>
            <Text style={styles.claimedText}>{KZ_DONE}</Text>
          </View>
        ) : null}
      </View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  card: {
    width: CARD_W,
    height: CARD_H,
    backgroundColor: colors.white,
    borderRadius: radius.md,
    padding: spacing.sm + 2,
    borderWidth: 2,
    shadowColor: colors.success,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 10,
    elevation: 3,
    justifyContent: 'space-between',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 6,
  },
  icon: {
    fontSize: 22,
  },
  title: {
    flex: 1,
    color: colors.text,
    fontSize: fontSize.xs + 1,
    fontWeight: fontWeight.bold,
    lineHeight: 15,
  },
  progressWrap: {
    gap: 2,
  },
  progressTrack: {
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.border,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressLabel: {
    color: colors.textLight,
    fontSize: 10,
    fontWeight: fontWeight.semibold,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  rewards: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 4,
    flex: 1,
  },
  rewardText: {
    color: colors.text,
    fontSize: 10,
    fontWeight: fontWeight.semibold,
  },
  claimPressable: {
    marginLeft: 4,
  },
  claimButton: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: colors.success,
  },
  claimedButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: colors.textLight,
  },
  claimText: {
    color: colors.white,
    fontSize: 11,
    fontWeight: fontWeight.bold,
  },
  claimedText: {
    color: colors.textLight,
    fontSize: 10,
    fontWeight: fontWeight.semibold,
  },
});

export default React.memo(QuestCard);
