import React, { useEffect, useRef, useState } from 'react';
import { StyleSheet, Text } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withSpring,
  withTiming,
  Easing,
} from 'react-native-reanimated';

import { colors, fontSize, fontWeight } from '@/theme';

interface Props {
  value: number;
  icon: string;
  color?: string;
  pillColor?: string;
}

const STEP_MS = 40;
const STEPS = 14;

// Counter pill used in the home-screen header. When the underlying `value`
// changes we (a) tick the displayed digits up/down over ~550ms, and (b) pop
// the scale + briefly flash the icon to draw the eye.
const AnimatedCounter: React.FC<Props> = ({
  value,
  icon,
  color = colors.text,
  pillColor = 'rgba(255,255,255,0.18)',
}) => {
  const scale = useSharedValue(1);
  const glow = useSharedValue(0);
  const prevValue = useRef(value);
  const [displayed, setDisplayed] = useState(value);

  useEffect(() => {
    if (value === prevValue.current) return;
    const from = prevValue.current;
    const to = value;
    prevValue.current = to;

    scale.value = withSequence(
      withSpring(1.25, { damping: 6, stiffness: 220 }),
      withSpring(1, { damping: 10, stiffness: 160 }),
    );
    glow.value = withSequence(
      withTiming(1, { duration: 200, easing: Easing.out(Easing.quad) }),
      withTiming(0, { duration: 600, easing: Easing.in(Easing.quad) }),
    );

    let i = 0;
    const id = setInterval(() => {
      i += 1;
      if (i >= STEPS) {
        setDisplayed(to);
        clearInterval(id);
        return;
      }
      const next = Math.round(from + ((to - from) * i) / STEPS);
      setDisplayed(next);
    }, STEP_MS);

    return () => { clearInterval(id); };
  }, [value, scale, glow]);

  const pillStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const iconStyle = useAnimatedStyle(() => ({
    opacity: 0.85 + glow.value * 0.15,
    transform: [{ scale: 1 + glow.value * 0.3 }],
  }));

  return (
    <Animated.View style={[styles.pill, { backgroundColor: pillColor }, pillStyle]}>
      <Animated.Text style={[styles.icon, iconStyle]}>{icon}</Animated.Text>
      <Text style={[styles.value, { color }]}>{displayed}</Text>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
  },
  icon: {
    fontSize: 14,
  },
  value: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.bold,
    minWidth: 24,
    textAlign: 'left',
  },
});

export default AnimatedCounter;
