import React, { useEffect } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';

import { fontSize, fontWeight, spacing } from '@/theme';

export type RewardKind = 'xp' | 'coins' | 'akyl';

interface Props {
  amount: number;
  kind: RewardKind;
  onDone?: () => void;
}

const COLORS: Record<RewardKind, string> = {
  xp: '#00C48C', // success green
  coins: '#FFD700', // gold
  akyl: '#7B61FF', // secondary purple
};

const LABELS: Record<RewardKind, string> = {
  xp: 'XP',
  coins: 'тиын',
  akyl: 'ақыл',
};

const ICONS: Record<RewardKind, string> = {
  xp: '✨',
  coins: '🪙',
  akyl: '🔮',
};

const RewardToast: React.FC<Props> = ({ amount, kind, onDone }) => {
  const translateY = useSharedValue(20);
  const opacity = useSharedValue(0);
  const scale = useSharedValue(0.7);

  useEffect(() => {
    opacity.value = withTiming(1, { duration: 180 });
    scale.value = withSpring(1, { damping: 9, stiffness: 220 });
    translateY.value = withSequence(
      withSpring(-12, { damping: 12, stiffness: 220 }),
      withTiming(-44, { duration: 700, easing: Easing.out(Easing.cubic) }),
    );

    const handleFinished = () => {
      if (onDone) onDone();
    };

    opacity.value = withDelay(
      700,
      withTiming(0, { duration: 400, easing: Easing.in(Easing.quad) }, (finished) => {
        if (finished) scheduleOnRN(handleFinished);
      }),
    );
  }, [opacity, scale, translateY, onDone]);

  const style = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateY: translateY.value }, { scale: scale.value }],
  }));

  const sign = amount >= 0 ? '+' : '';
  const color = COLORS[kind];

  return (
    <Animated.View style={[styles.wrap, style]} pointerEvents="none">
      <View style={[styles.pill, { borderColor: color, shadowColor: color }]}>
        <Text style={styles.icon}>{ICONS[kind]}</Text>
        <Text style={[styles.amount, { color }]}>
          {sign}
          {amount}
        </Text>
        <Text style={[styles.label, { color }]}>{LABELS[kind]}</Text>
      </View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  wrap: {
    alignSelf: 'center',
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(20,18,46,0.85)',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 999,
    borderWidth: 1.5,
    gap: 6,
    shadowOpacity: 0.6,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 0 },
    elevation: 6,
  },
  icon: {
    fontSize: fontSize.lg,
  },
  amount: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
  },
  label: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
    opacity: 0.85,
  },
});

export default RewardToast;
