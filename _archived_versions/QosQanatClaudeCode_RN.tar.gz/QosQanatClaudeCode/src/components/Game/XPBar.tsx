import { LinearGradient } from 'expo-linear-gradient';
import React, { useEffect } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Animated, {
  Easing,
  interpolateColor,
  useAnimatedStyle,
  useDerivedValue,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';

import { getLevelProgress } from '@/data/levels';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

interface Props {
  totalXp: number;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
}

const HEIGHTS = { sm: 8, md: 14, lg: 20 } as const;
const BADGE_SIZE = { sm: 22, md: 30, lg: 38 } as const;

const XPBar: React.FC<Props> = ({ totalXp, size = 'md', showLabel = true }) => {
  const { level, xpIntoLevel, xpForNextLevel, progress } = getLevelProgress(totalXp);

  const fillProgress = useSharedValue(0);
  const glowPulse = useSharedValue(0);

  useEffect(() => {
    fillProgress.value = withTiming(progress, {
      duration: 800,
      easing: Easing.out(Easing.cubic),
    });
  }, [progress, fillProgress]);

  useEffect(() => {
    glowPulse.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 900, easing: Easing.inOut(Easing.quad) }),
        withTiming(0, { duration: 900, easing: Easing.inOut(Easing.quad) }),
      ),
      -1,
      false,
    );
  }, [glowPulse]);

  const fillStyle = useAnimatedStyle(() => ({
    width: `${fillProgress.value * 100}%`,
  }));

  // Position the glowing dot at the end of the fill.
  const dotStyle = useAnimatedStyle(() => ({
    left: `${fillProgress.value * 100}%`,
    opacity: progress > 0 ? 1 : 0,
    transform: [{ translateX: -BADGE_SIZE[size] / 4 }, { scale: 1 + glowPulse.value * 0.18 }],
  }));

  const dotInner = useDerivedValue(() =>
    interpolateColor(glowPulse.value, [0, 1], [colors.gold, '#FFFFFF']),
  );
  const dotInnerStyle = useAnimatedStyle(() => ({ backgroundColor: dotInner.value }));

  const height = HEIGHTS[size];
  const badge = BADGE_SIZE[size];

  return (
    <View style={styles.wrap}>
      <View style={[styles.badge, { width: badge, height: badge, borderRadius: badge / 2 }]}>
        <LinearGradient
          colors={[colors.gold, '#FFB347'] as readonly [string, string]}
          style={[StyleSheet.absoluteFill, { borderRadius: badge / 2 }]}
        />
        <Text style={[styles.badgeText, size === 'sm' && { fontSize: 11 }]}>{level}</Text>
      </View>

      <View style={[styles.track, { height, borderRadius: height / 2 }]}>
        <Animated.View style={[styles.fill, { borderRadius: height / 2 }, fillStyle]}>
          <LinearGradient
            colors={[colors.primary, colors.secondary] as readonly [string, string]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={[StyleSheet.absoluteFill, { borderRadius: height / 2 }]}
          />
        </Animated.View>
        <Animated.View
          style={[
            styles.dot,
            {
              width: height + 6,
              height: height + 6,
              borderRadius: (height + 6) / 2,
              top: -3,
            },
            dotStyle,
          ]}
        >
          <Animated.View
            style={[
              styles.dotInner,
              {
                width: height + 2,
                height: height + 2,
                borderRadius: (height + 2) / 2,
              },
              dotInnerStyle,
            ]}
          />
        </Animated.View>
      </View>

      {showLabel ? (
        <Text style={styles.label}>
          {xpIntoLevel} / {xpForNextLevel} XP
        </Text>
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    width: '100%',
  },
  badge: {
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    shadowColor: colors.gold,
    shadowOpacity: 0.5,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 0 },
    elevation: 4,
  },
  badgeText: {
    color: colors.text,
    fontWeight: fontWeight.extrabold,
    fontSize: fontSize.sm,
  },
  track: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.18)',
    overflow: 'visible',
    justifyContent: 'center',
  },
  fill: {
    height: '100%',
    overflow: 'hidden',
  },
  dot: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.gold,
    shadowOpacity: 0.9,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
    elevation: 8,
  },
  dotInner: {
    backgroundColor: colors.gold,
  },
  label: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: fontSize.xs,
    fontWeight: fontWeight.semibold,
    minWidth: 70,
    textAlign: 'right',
  },
});

export default XPBar;
