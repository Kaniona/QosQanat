import { LinearGradient } from 'expo-linear-gradient';
import React, { useEffect, useState } from 'react';
import { Dimensions, Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, {
  Easing,
  cancelAnimation,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';

import { getLevelInfo } from '@/data/levels';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

interface Props {
  visible: boolean;
  fromLevel: number;
  toLevel: number;
  coinReward: number;
  onClose: () => void;
}

const KZ = {
  title: 'Деңгей көтерілді!',
  yourTitle: 'Атағың',
  coinsReward: 'Сыйақы',
  confirm: 'Керемет! ✓',
};

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');
const CONFETTI_COUNT = 32;

const CONFETTI_COLORS = ['#FFD700', '#4A6CF7', '#7B61FF', '#FF6B9D', '#00C48C', '#FF4757'];

interface ConfettiProps {
  delay: number;
  startX: number;
  color: string;
  size: number;
  rotateTo: number;
}

const ConfettiPiece: React.FC<ConfettiProps> = ({ delay, startX, color, size, rotateTo }) => {
  const translateY = useSharedValue(-40);
  const translateX = useSharedValue(0);
  const rotate = useSharedValue(0);
  const opacity = useSharedValue(0);

  useEffect(() => {
    const fallDistance = SCREEN_H * 0.7 + Math.random() * SCREEN_H * 0.2;
    const drift = (Math.random() - 0.5) * 120;
    const duration = 1800 + Math.random() * 1400;

    opacity.value = withDelay(delay, withTiming(1, { duration: 120 }));
    translateY.value = withDelay(
      delay,
      withTiming(fallDistance, { duration, easing: Easing.in(Easing.quad) }),
    );
    translateX.value = withDelay(
      delay,
      withTiming(drift, { duration, easing: Easing.inOut(Easing.quad) }),
    );
    rotate.value = withDelay(delay, withTiming(rotateTo, { duration, easing: Easing.linear }));

    return () => {
      cancelAnimation(translateY);
      cancelAnimation(translateX);
      cancelAnimation(rotate);
      cancelAnimation(opacity);
    };
  }, [delay, rotateTo, opacity, translateX, translateY, rotate]);

  const style = useAnimatedStyle(() => ({
    transform: [
      { translateY: translateY.value },
      { translateX: translateX.value },
      { rotate: `${rotate.value}deg` },
    ],
    opacity: opacity.value,
  }));

  return (
    <Animated.View
      pointerEvents="none"
      style={[
        styles.confetti,
        {
          left: startX,
          width: size,
          height: size * 1.6,
          backgroundColor: color,
        },
        style,
      ]}
    />
  );
};

const Crown: React.FC<{ active: boolean }> = ({ active }) => {
  const rotate = useSharedValue(0);
  const scale = useSharedValue(0);

  useEffect(() => {
    if (active) {
      scale.value = withSequence(
        withSpring(1.2, { damping: 6, stiffness: 180 }),
        withSpring(1, { damping: 10, stiffness: 180 }),
      );
      rotate.value = withRepeat(
        withSequence(
          withTiming(8, { duration: 1200, easing: Easing.inOut(Easing.quad) }),
          withTiming(-8, { duration: 1200, easing: Easing.inOut(Easing.quad) }),
        ),
        -1,
        true,
      );
    } else {
      scale.value = withTiming(0, { duration: 200 });
      cancelAnimation(rotate);
      rotate.value = 0;
    }
  }, [active, rotate, scale]);

  const style = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }, { rotate: `${rotate.value}deg` }],
  }));
  return (
    <Animated.Text style={[styles.crown, style]} pointerEvents="none">
      👑
    </Animated.Text>
  );
};

const LevelUpModal: React.FC<Props> = ({ visible, fromLevel, toLevel, coinReward, onClose }) => {
  const overlay = useSharedValue(0);
  const card = useSharedValue(0.3);
  const cardOpacity = useSharedValue(0);

  // Animated level count up
  const [displayedLevel, setDisplayedLevel] = useState(fromLevel);
  const [coinDisplay, setCoinDisplay] = useState(0);

  const title = getLevelInfo(toLevel).title;

  useEffect(() => {
    if (!visible) {
      overlay.value = 0;
      card.value = 0.3;
      cardOpacity.value = 0;
      setDisplayedLevel(fromLevel);
      setCoinDisplay(0);
      return;
    }

    overlay.value = withTiming(1, { duration: 280, easing: Easing.out(Easing.quad) });
    cardOpacity.value = withTiming(1, { duration: 240 });
    card.value = withSequence(
      withTiming(1.1, { duration: 360, easing: Easing.out(Easing.back(1.5)) }),
      withSpring(1, { damping: 12, stiffness: 180 }),
    );

    // Level number count-up after a short pause.
    const levelTimer = setTimeout(() => {
      const steps = Math.max(1, toLevel - fromLevel);
      const stepMs = Math.min(220, 800 / steps);
      let current = fromLevel;
      const interval = setInterval(() => {
        current += 1;
        setDisplayedLevel(current);
        if (current >= toLevel) clearInterval(interval);
      }, stepMs);
    }, 500);

    // Coin reward count-up.
    const coinTimer = setTimeout(() => {
      if (coinReward <= 0) return;
      const steps = 22;
      const inc = Math.max(1, Math.ceil(coinReward / steps));
      let current = 0;
      const interval = setInterval(() => {
        current = Math.min(coinReward, current + inc);
        setCoinDisplay(current);
        if (current >= coinReward) clearInterval(interval);
      }, 30);
    }, 900);

    return () => {
      clearTimeout(levelTimer);
      clearTimeout(coinTimer);
    };
  }, [visible, fromLevel, toLevel, coinReward, overlay, card, cardOpacity]);

  const overlayStyle = useAnimatedStyle(() => ({ opacity: overlay.value }));
  const cardStyle = useAnimatedStyle(() => ({
    opacity: cardOpacity.value,
    transform: [{ scale: card.value }],
  }));

  const handleClose = () => {
    overlay.value = withTiming(0, { duration: 220 });
    cardOpacity.value = withTiming(0, { duration: 220 });
    card.value = withTiming(0.6, { duration: 220 }, (finished) => {
      if (finished) runOnJS(onClose)();
    });
  };

  return (
    <Modal transparent visible={visible} onRequestClose={handleClose} animationType="none">
      <Animated.View style={[styles.overlay, overlayStyle]}>
        <LinearGradient
          colors={['rgba(14,11,51,0.92)', 'rgba(26,26,78,0.95)'] as readonly [string, string]}
          style={StyleSheet.absoluteFill}
        />

        {Array.from({ length: CONFETTI_COUNT }, (_, i) => (
          <ConfettiPiece
            key={i}
            delay={i * 35}
            startX={Math.random() * SCREEN_W}
            color={CONFETTI_COLORS[i % CONFETTI_COLORS.length]}
            size={6 + Math.random() * 6}
            rotateTo={(Math.random() > 0.5 ? 1 : -1) * (360 + Math.random() * 360)}
          />
        ))}

        <Animated.View style={[styles.card, cardStyle]}>
          <LinearGradient
            colors={['#2A2462', '#1A1A4E'] as readonly [string, string]}
            style={[StyleSheet.absoluteFill, { borderRadius: radius.xl }]}
          />

          <Crown active={visible} />

          <Text style={styles.headline}>{KZ.title}</Text>

          <View style={styles.levelBlock}>
            <Text style={styles.levelLabel}>Деңгей</Text>
            <Text style={styles.levelNumber}>{displayedLevel}</Text>
          </View>

          <View style={styles.titleBlock}>
            <Text style={styles.titleLabel}>{KZ.yourTitle}</Text>
            <Text style={styles.titleValue}>{title}</Text>
          </View>

          {coinReward > 0 ? (
            <View style={styles.coinRow}>
              <Text style={styles.coinEmoji}>🪙</Text>
              <Text style={styles.coinAmount}>+{coinDisplay}</Text>
              <Text style={styles.coinLabel}>{KZ.coinsReward}</Text>
            </View>
          ) : null}

          <Pressable
            onPress={handleClose}
            style={({ pressed }) => [styles.cta, pressed && { opacity: 0.85 }]}
          >
            <LinearGradient
              colors={[colors.gold, '#FFB347'] as readonly [string, string]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.ctaGrad}
            >
              <Text style={styles.ctaText}>{KZ.confirm}</Text>
            </LinearGradient>
          </Pressable>
        </Animated.View>
      </Animated.View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
  },
  card: {
    width: '100%',
    maxWidth: 380,
    paddingVertical: spacing.xl,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.xl,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    overflow: 'hidden',
  },
  crown: {
    fontSize: 64,
    marginBottom: spacing.sm,
  },
  headline: {
    color: colors.gold,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
    textAlign: 'center',
    marginBottom: spacing.md,
    textShadowColor: 'rgba(255,215,0,0.6)',
    textShadowRadius: 12,
  },
  levelBlock: {
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  levelLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
    marginBottom: 2,
  },
  levelNumber: {
    color: colors.white,
    fontSize: fontSize.huge + 14,
    fontWeight: fontWeight.extrabold,
    lineHeight: fontSize.huge + 18,
  },
  titleBlock: {
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  titleLabel: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: fontSize.xs,
    fontWeight: fontWeight.semibold,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  titleValue: {
    color: colors.white,
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
    marginTop: 2,
  },
  coinRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(255,215,0,0.12)',
    borderColor: 'rgba(255,215,0,0.4)',
    borderWidth: 1,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.full,
    marginBottom: spacing.lg,
  },
  coinEmoji: { fontSize: fontSize.lg },
  coinAmount: {
    color: colors.gold,
    fontSize: fontSize.xl,
    fontWeight: fontWeight.extrabold,
  },
  coinLabel: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
  },
  cta: {
    width: '100%',
    borderRadius: radius.full,
    overflow: 'hidden',
  },
  ctaGrad: {
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  ctaText: {
    color: colors.text,
    fontSize: fontSize.lg,
    fontWeight: fontWeight.extrabold,
  },
  confetti: {
    position: 'absolute',
    top: 0,
    borderRadius: 2,
  },
});

export default LevelUpModal;
