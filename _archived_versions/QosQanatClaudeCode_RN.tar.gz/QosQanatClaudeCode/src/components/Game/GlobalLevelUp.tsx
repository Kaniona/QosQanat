import React from 'react';

import { useGameStore } from '@/store/gameStore';

import LevelUpModal from './LevelUpModal';

// ----------------------------------------------------------------------------
// GlobalLevelUp
//
// Mounted once at the App root. Subscribes to gameStore.pendingLevelUp — any
// addXP() / levelUp() call that crosses a level boundary populates that state
// and this overlay pops automatically, no matter which screen the player is
// on. Dismissing the modal clears the field so the next level-up will fire.
// ----------------------------------------------------------------------------

const GlobalLevelUp: React.FC = () => {
  const pending = useGameStore((s) => s.pendingLevelUp);
  const clearPending = useGameStore((s) => s.clearPendingLevelUp);

  if (!pending?.leveledUp) return null;

  return (
    <LevelUpModal
      visible
      fromLevel={pending.fromLevel}
      toLevel={pending.toLevel}
      coinReward={pending.coinReward}
      onClose={clearPending}
    />
  );
};

export default GlobalLevelUp;
