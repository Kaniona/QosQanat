import type { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useEffect, useMemo } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { getIncomingFriendRequests, getUnreadNotificationCount } from '@/services/api';
import { useUserStore } from '@/store/userStore';
import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

// ----------------------------------------------------------------------------
// QTabBar
//
// Custom bottom tab bar for the Main navigator:
//   Home (Бастаy) | Learn (Оқу) | Shop (Дүкен, raised) | Friends (Достар) | Profile (Профиль)
//
// * Middle tab (Shop) is rendered as a raised circular gold FAB-style button
//   that floats above the bar.
// * Active tab scales to 1.2 with a gold accent.
// * Friends tab shows a red notification badge with the count of unread
//   notifications + pending incoming friend requests.
// * Bar has rounded top corners, white background, soft shadow.
// ----------------------------------------------------------------------------

type TabKey = 'Home' | 'Learn' | 'Shop' | 'Friends' | 'Profile';

interface TabSpec {
  key: TabKey;
  labelKz: string;
  icon: string;
}

const TABS: readonly TabSpec[] = [
  { key: 'Home', labelKz: 'Бастау', icon: '🏠' },
  { key: 'Learn', labelKz: 'Оқу', icon: '📚' },
  { key: 'Shop', labelKz: 'Дүкен', icon: '🛍️' },
  { key: 'Friends', labelKz: 'Достар', icon: '👥' },
  { key: 'Profile', labelKz: 'Профиль', icon: '👤' },
];

// Width factor of the middle (raised) button. Bigger looks more SiriShortcut-y.
const RAISED_DIAMETER = 64;

// ----------------------------------------------------------------------------
// Hook: poll the Friends badge count.
// ----------------------------------------------------------------------------

const useFriendsBadge = (): number => {
  const userId = useUserStore((s) => s.user?.id);
  const [count, setCount] = React.useState(0);

  useEffect(() => {
    if (!userId) {
      setCount(0);
      return;
    }
    let cancelled = false;
    const tick = async () => {
      try {
        const [notif, reqs] = await Promise.all([
          getUnreadNotificationCount(),
          getIncomingFriendRequests(),
        ]);
        if (!cancelled) setCount(notif + reqs.length);
      } catch {
        // soft-fail
      }
    };
    void tick();
    const id = setInterval(() => void tick(), 60_000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [userId]);

  return count;
};

// ----------------------------------------------------------------------------
// Regular tab button
// ----------------------------------------------------------------------------

interface TabItemProps {
  spec: TabSpec;
  active: boolean;
  onPress: () => void;
  badgeCount?: number;
}

const TabItem: React.FC<TabItemProps> = React.memo(({ spec, active, onPress, badgeCount }) => {
  const scale = useSharedValue(active ? 1.2 : 1);
  const lift = useSharedValue(active ? -4 : 0);

  useEffect(() => {
    scale.value = withSpring(active ? 1.2 : 1, { damping: 12, stiffness: 220 });
    lift.value = withSpring(active ? -4 : 0, { damping: 14, stiffness: 200 });
  }, [active, scale, lift]);

  const iconStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }, { translateY: lift.value }],
  }));

  return (
    <Pressable
      onPress={onPress}
      style={styles.tabItem}
      accessibilityRole="button"
      accessibilityLabel={spec.labelKz}
      accessibilityState={{ selected: active }}
    >
      <Animated.View style={[styles.iconWrap, iconStyle]}>
        <Text style={[styles.icon, active && styles.iconActive]}>{spec.icon}</Text>
        {badgeCount && badgeCount > 0 ? (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{badgeCount > 9 ? '9+' : badgeCount}</Text>
          </View>
        ) : null}
      </Animated.View>
      <Text style={[styles.label, active && styles.labelActive]} numberOfLines={1}>
        {spec.labelKz}
      </Text>
      {active ? <View style={styles.activeDot} /> : null}
    </Pressable>
  );
});

// ----------------------------------------------------------------------------
// Raised middle (Shop) button
// ----------------------------------------------------------------------------

interface RaisedItemProps {
  spec: TabSpec;
  active: boolean;
  onPress: () => void;
}

const RaisedItem: React.FC<RaisedItemProps> = React.memo(({ spec, active, onPress }) => {
  const pressScale = useSharedValue(1);
  const lift = useSharedValue(0);

  useEffect(() => {
    lift.value = withTiming(active ? -4 : 0, { duration: 220 });
  }, [active, lift]);

  const style = useAnimatedStyle(() => ({
    transform: [{ scale: pressScale.value }, { translateY: lift.value }],
  }));

  return (
    <View style={styles.raisedSlot} pointerEvents="box-none">
      <Animated.View style={[styles.raisedWrap, style]}>
        <Pressable
          onPressIn={() => {
            pressScale.value = withSpring(0.92, { damping: 14, stiffness: 240 });
          }}
          onPressOut={() => {
            pressScale.value = withSpring(1, { damping: 12, stiffness: 200 });
          }}
          onPress={onPress}
          accessibilityRole="button"
          accessibilityLabel={spec.labelKz}
        >
          <View style={[styles.raisedBtn, active && styles.raisedBtnActive]}>
            <LinearGradient
              colors={
                active
                  ? ([colors.gold, '#FFB84A'] as readonly [string, string])
                  : ([colors.primary, colors.secondary] as readonly [string, string])
              }
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            <Text style={styles.raisedIcon}>{spec.icon}</Text>
          </View>
        </Pressable>
        <Text style={[styles.raisedLabel, active && styles.raisedLabelActive]}>{spec.labelKz}</Text>
      </Animated.View>
    </View>
  );
});

// ----------------------------------------------------------------------------
// QTabBar
// ----------------------------------------------------------------------------

const QTabBar: React.FC<BottomTabBarProps> = ({ state, descriptors, navigation }) => {
  const insets = useSafeAreaInsets();
  const friendsBadge = useFriendsBadge();

  // Map the bottom-tabs route order to our static TABS list; we fall back to
  // the React Navigation state for the actual `active` index.
  const items = useMemo(
    () =>
      TABS.map((spec) => {
        const routeIndex = state.routes.findIndex((r) => r.name === spec.key);
        return { spec, routeIndex };
      }),
    [state.routes],
  );

  const activeRouteName = state.routes[state.index]?.name as TabKey | undefined;

  const handlePress = (routeIndex: number, key: string) => {
    const route = state.routes[routeIndex];
    if (!route) return;
    const event = navigation.emit({
      type: 'tabPress',
      target: route.key,
      canPreventDefault: true,
    });
    if (!event.defaultPrevented && state.index !== routeIndex) {
      navigation.navigate(route.name);
    }
    // Silence unused-var
    void descriptors;
    void key;
  };

  return (
    <View style={[styles.outer, { paddingBottom: insets.bottom }]} pointerEvents="box-none">
      <View style={styles.barShadow} />
      <View style={styles.bar}>
        {items.map(({ spec, routeIndex }) => {
          if (routeIndex < 0) return <View key={spec.key} style={styles.tabItem} />;
          const active = activeRouteName === spec.key;
          if (spec.key === 'Shop') {
            return (
              <RaisedItem
                key={spec.key}
                spec={spec}
                active={active}
                onPress={() => { handlePress(routeIndex, spec.key); }}
              />
            );
          }
          return (
            <TabItem
              key={spec.key}
              spec={spec}
              active={active}
              badgeCount={spec.key === 'Friends' ? friendsBadge : undefined}
              onPress={() => { handlePress(routeIndex, spec.key); }}
            />
          );
        })}
      </View>
    </View>
  );
};

// ----------------------------------------------------------------------------
// Styles
// ----------------------------------------------------------------------------

const styles = StyleSheet.create({
  outer: {
    backgroundColor: colors.white,
  },
  barShadow: {
    // Soft drop shadow above the bar.
    position: 'absolute',
    top: -12,
    left: 0,
    right: 0,
    height: 12,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOpacity: 0.08,
        shadowRadius: 12,
        shadowOffset: { width: 0, height: -4 },
      },
      android: { elevation: 12 },
      default: {},
    }),
  },
  bar: {
    flexDirection: 'row',
    backgroundColor: colors.white,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    paddingTop: spacing.sm,
    paddingHorizontal: spacing.sm,
    minHeight: 68,
    alignItems: 'flex-start',
    justifyContent: 'space-around',
  },
  // ---- Regular tab ----
  tabItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 4,
  },
  iconWrap: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  icon: {
    fontSize: 22,
    opacity: 0.55,
  },
  iconActive: {
    opacity: 1,
  },
  label: {
    fontSize: 11,
    color: colors.textLight,
    fontWeight: fontWeight.semibold,
    marginTop: 2,
  },
  labelActive: {
    color: colors.gold,
    fontWeight: fontWeight.extrabold,
  },
  activeDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.gold,
    marginTop: 2,
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: -8,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 4,
    backgroundColor: colors.danger,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.white,
  },
  badgeText: {
    color: colors.white,
    fontSize: 10,
    fontWeight: fontWeight.extrabold,
  },
  // ---- Raised middle tab ----
  raisedSlot: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  raisedWrap: {
    alignItems: 'center',
    marginTop: -28,
  },
  raisedBtn: {
    width: RAISED_DIAMETER,
    height: RAISED_DIAMETER,
    borderRadius: RAISED_DIAMETER / 2,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    borderWidth: 4,
    borderColor: colors.white,
    ...Platform.select({
      ios: {
        shadowColor: colors.primary,
        shadowOpacity: 0.45,
        shadowRadius: 12,
        shadowOffset: { width: 0, height: 6 },
      },
      android: { elevation: 10 },
      default: {},
    }),
  },
  raisedBtnActive: {
    ...Platform.select({
      ios: {
        shadowColor: colors.gold,
      },
      default: {},
    }),
  },
  raisedIcon: {
    fontSize: 28,
    color: colors.white,
  },
  raisedLabel: {
    fontSize: 11,
    color: colors.textLight,
    fontWeight: fontWeight.semibold,
    marginTop: 4,
  },
  raisedLabelActive: {
    color: colors.gold,
    fontWeight: fontWeight.extrabold,
  },
});

// Silence the unused `fontSize` import if styles are tree-shaken.
void fontSize;

export default QTabBar;
