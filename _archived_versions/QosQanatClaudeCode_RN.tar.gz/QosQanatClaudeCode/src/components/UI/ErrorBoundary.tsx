import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';

// ----------------------------------------------------------------------------
// ErrorBoundary
//
// Catches render-time errors anywhere below it and shows a Kazakh fallback
// instead of a white screen. The reset button forces a re-mount of children.
// ----------------------------------------------------------------------------

interface Props {
  children: React.ReactNode;
}

interface State {
  error: Error | null;
  resetKey: number;
}

const KZ = {
  title: 'Қателік шықты 😔',
  body: 'Қолданба күтпеген жағдайда тоқтады. Қайта жүктеп көріңіз — деректеріңіз сақталады.',
  retry: 'Қайта жүктеу',
};

class ErrorBoundary extends React.Component<Props, State> {
  state: State = { error: null, resetKey: 0 };

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo): void {
    // Surface to whatever crash reporter the app uses; today just the console.
     
    console.error('[QosQanat] Unhandled render error', error, info);
  }

  handleRetry = (): void => {
    this.setState((s) => ({ error: null, resetKey: s.resetKey + 1 }));
  };

  render(): React.ReactNode {
    if (this.state.error) {
      return (
        <View style={styles.root}>
          <Text style={styles.title}>{KZ.title}</Text>
          <Text style={styles.body}>{KZ.body}</Text>
          <Pressable style={styles.btn} onPress={this.handleRetry}>
            <Text style={styles.btnText}>{KZ.retry}</Text>
          </Pressable>
        </View>
      );
    }
    // The resetKey ensures children re-mount cleanly after a retry.
    return <React.Fragment key={this.state.resetKey}>{this.props.children}</React.Fragment>;
  }
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#1A1A4E',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
    gap: spacing.md,
  },
  title: {
    color: colors.white,
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.extrabold,
    textAlign: 'center',
  },
  body: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: fontSize.md,
    textAlign: 'center',
    lineHeight: 22,
  },
  btn: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    backgroundColor: colors.primary,
  },
  btnText: {
    color: colors.white,
    fontSize: fontSize.md,
    fontWeight: fontWeight.extrabold,
  },
});

export default ErrorBoundary;
