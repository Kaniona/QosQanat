import React from 'react';
import { Circle, G, Path } from 'react-native-svg';

export type Expression = 'neutral' | 'happy' | 'sad' | 'surprised' | 'thinking' | 'celebrate';

interface FaceLayerProps {
  expression: Expression;
  eyesClosed?: boolean;
}

const EYE = '#1A1A2E';
const MOUTH = '#1A1A2E';
const BLUSH = '#FF8FA3';
const MOUTH_OPEN = '#A8324B';
const HIGHLIGHT = '#FFFFFF';

// ----------------------------------------------------------------------------
// FaceLayer — all eye/mouth/eyebrow combinations for one expression.
// Lives at avatar viewBox space (100x125), centred on the head at cy~40.
// eyesClosed forces happy-arc closed eyes regardless of the expression.
// ----------------------------------------------------------------------------

const Eyes: React.FC<{ expression: Expression; eyesClosed: boolean }> = ({
  expression,
  eyesClosed,
}) => {
  if (eyesClosed) {
    return (
      <G>
        <Path
          d="M 38 42 Q 42 45, 46 42"
          stroke={EYE}
          strokeWidth="1.6"
          fill="none"
          strokeLinecap="round"
        />
        <Path
          d="M 54 42 Q 58 45, 62 42"
          stroke={EYE}
          strokeWidth="1.6"
          fill="none"
          strokeLinecap="round"
        />
      </G>
    );
  }
  switch (expression) {
    case 'happy':
    case 'celebrate':
      return (
        <G>
          <Path
            d="M 38 43 Q 42 38, 46 43"
            stroke={EYE}
            strokeWidth="1.8"
            fill="none"
            strokeLinecap="round"
          />
          <Path
            d="M 54 43 Q 58 38, 62 43"
            stroke={EYE}
            strokeWidth="1.8"
            fill="none"
            strokeLinecap="round"
          />
        </G>
      );
    case 'sad':
      return (
        <G>
          <Path
            d="M 38 42 Q 42 46, 46 44"
            stroke={EYE}
            strokeWidth="1.5"
            fill="none"
            strokeLinecap="round"
          />
          <Path
            d="M 54 44 Q 58 46, 62 42"
            stroke={EYE}
            strokeWidth="1.5"
            fill="none"
            strokeLinecap="round"
          />
        </G>
      );
    case 'surprised':
      return (
        <G>
          <Circle cx="42" cy="42" r="3.4" fill={EYE} />
          <Circle cx="58" cy="42" r="3.4" fill={EYE} />
          <Circle cx="42.7" cy="41" r="1" fill={HIGHLIGHT} />
          <Circle cx="58.7" cy="41" r="1" fill={HIGHLIGHT} />
        </G>
      );
    case 'thinking':
      return (
        <G>
          <Circle cx="42" cy="42" r="2.4" fill={EYE} />
          <Path
            d="M 54 42 Q 58 44, 62 42"
            stroke={EYE}
            strokeWidth="1.6"
            fill="none"
            strokeLinecap="round"
          />
          <Circle cx="42.6" cy="41.2" r="0.8" fill={HIGHLIGHT} />
        </G>
      );
    case 'neutral':
    default:
      return (
        <G>
          <Circle cx="42" cy="42" r="2.6" fill={EYE} />
          <Circle cx="58" cy="42" r="2.6" fill={EYE} />
          <Circle cx="42.7" cy="41.2" r="0.9" fill={HIGHLIGHT} />
          <Circle cx="58.7" cy="41.2" r="0.9" fill={HIGHLIGHT} />
        </G>
      );
  }
};

const Eyebrows: React.FC<{ expression: Expression }> = ({ expression }) => {
  switch (expression) {
    case 'celebrate':
    case 'surprised':
      return (
        <G>
          <Path
            d="M 38 33 Q 42 31, 46 33"
            stroke={EYE}
            strokeWidth="1.4"
            fill="none"
            strokeLinecap="round"
          />
          <Path
            d="M 54 33 Q 58 31, 62 33"
            stroke={EYE}
            strokeWidth="1.4"
            fill="none"
            strokeLinecap="round"
          />
        </G>
      );
    case 'sad':
      return (
        <G>
          <Path
            d="M 38 35 Q 42 38, 46 36"
            stroke={EYE}
            strokeWidth="1.3"
            fill="none"
            strokeLinecap="round"
          />
          <Path
            d="M 54 36 Q 58 38, 62 35"
            stroke={EYE}
            strokeWidth="1.3"
            fill="none"
            strokeLinecap="round"
          />
        </G>
      );
    case 'thinking':
      return (
        <G>
          <Path
            d="M 38 38 Q 42 36, 46 36"
            stroke={EYE}
            strokeWidth="1.2"
            fill="none"
            strokeLinecap="round"
          />
          <Path d="M 54 32 L 62 34" stroke={EYE} strokeWidth="1.5" strokeLinecap="round" />
        </G>
      );
    case 'happy':
    case 'neutral':
    default:
      return (
        <G>
          <Path
            d="M 38 36 Q 42 35, 46 36"
            stroke={EYE}
            strokeWidth="1.2"
            fill="none"
            strokeLinecap="round"
          />
          <Path
            d="M 54 36 Q 58 35, 62 36"
            stroke={EYE}
            strokeWidth="1.2"
            fill="none"
            strokeLinecap="round"
          />
        </G>
      );
  }
};

const Mouth: React.FC<{ expression: Expression }> = ({ expression }) => {
  switch (expression) {
    case 'happy':
      return (
        <Path
          d="M 43 52 Q 50 58, 57 52"
          stroke={MOUTH}
          strokeWidth="1.8"
          fill="none"
          strokeLinecap="round"
        />
      );
    case 'celebrate':
      return (
        <G>
          <Path
            d="M 42 52 Q 50 62, 58 52 Q 58 56, 50 58 Q 42 56, 42 52 Z"
            fill={MOUTH_OPEN}
            stroke={MOUTH}
            strokeWidth="1.2"
            strokeLinejoin="round"
          />
        </G>
      );
    case 'sad':
      return (
        <Path
          d="M 43 56 Q 50 51, 57 56"
          stroke={MOUTH}
          strokeWidth="1.5"
          fill="none"
          strokeLinecap="round"
        />
      );
    case 'surprised':
      return <Circle cx="50" cy="55" r="3" fill={MOUTH_OPEN} stroke={MOUTH} strokeWidth="0.8" />;
    case 'thinking':
      return (
        <Path
          d="M 46 54 Q 52 55, 56 53"
          stroke={MOUTH}
          strokeWidth="1.5"
          fill="none"
          strokeLinecap="round"
        />
      );
    case 'neutral':
    default:
      return (
        <Path
          d="M 45 53 Q 50 55, 55 53"
          stroke={MOUTH}
          strokeWidth="1.5"
          fill="none"
          strokeLinecap="round"
        />
      );
  }
};

const Blush: React.FC = () => (
  <G>
    <Circle cx="36" cy="48" r="3" fill={BLUSH} opacity="0.5" />
    <Circle cx="64" cy="48" r="3" fill={BLUSH} opacity="0.5" />
  </G>
);

const FaceLayer: React.FC<FaceLayerProps> = ({ expression, eyesClosed = false }) => {
  return (
    <G>
      <Eyebrows expression={expression} />
      <Eyes expression={expression} eyesClosed={eyesClosed} />
      <Blush />
      <Mouth expression={expression} />
    </G>
  );
};

export default FaceLayer;
