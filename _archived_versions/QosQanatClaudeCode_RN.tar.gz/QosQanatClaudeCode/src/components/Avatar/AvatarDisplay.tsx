import React, { useEffect, useRef, useState } from 'react';
import Animated, {
  Easing,
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';

import type { AssistantType } from '@/types';

import AvatarBase, { type EquippedItems } from './AvatarBase';
import type { Expression } from './expressions';

export type AvatarAction = 'idle' | 'celebrate' | 'sad' | 'thinking';

interface Props {
  assistantType: AssistantType;
  equippedItems?: EquippedItems;
  action?: AvatarAction;
  size?: number;
  expressionOverride?: Expression; // pin a specific expression regardless of action
}

const actionToExpression = (action: AvatarAction): Expression => {
  switch (action) {
    case 'celebrate':
      return 'celebrate';
    case 'sad':
      return 'sad';
    case 'thinking':
      return 'thinking';
    case 'idle':
    default:
      return 'neutral';
  }
};

const AvatarDisplay: React.FC<Props> = ({
  assistantType,
  equippedItems,
  action = 'idle',
  size = 160,
  expressionOverride,
}) => {
  const translateY = useSharedValue(0);
  const scale = useSharedValue(1);
  const rotateDeg = useSharedValue(0);

  const [eyesClosed, setEyesClosed] = useState(false);
  const blinkTimers = useRef<{
    next?: ReturnType<typeof setTimeout>;
    close?: ReturnType<typeof setTimeout>;
  }>({});

  // Drive the wrapper transforms based on the current action.
  useEffect(() => {
    cancelAnimation(translateY);
    cancelAnimation(scale);
    cancelAnimation(rotateDeg);

    if (action === 'idle') {
      translateY.value = withRepeat(
        withSequence(
          withTiming(-4, { duration: 2000, easing: Easing.inOut(Easing.quad) }),
          withTiming(0, { duration: 2000, easing: Easing.inOut(Easing.quad) }),
        ),
        -1,
        true,
      );
      scale.value = withTiming(1, { duration: 300 });
      rotateDeg.value = withTiming(0, { duration: 300 });
      return;
    }

    if (action === 'celebrate') {
      translateY.value = withSequence(
        withTiming(-22, { duration: 260, easing: Easing.out(Easing.cubic) }),
        withSpring(0, { damping: 6, stiffness: 220, mass: 1 }),
      );
      scale.value = withSequence(
        withTiming(1.18, { duration: 220, easing: Easing.out(Easing.cubic) }),
        withSpring(1, { damping: 8, stiffness: 220 }),
      );
      rotateDeg.value = withTiming(0, { duration: 300 });
      return;
    }

    if (action === 'sad') {
      translateY.value = withSpring(5, { damping: 14, stiffness: 120 });
      scale.value = withSpring(0.97, { damping: 14 });
      rotateDeg.value = withTiming(0, { duration: 300 });
      return;
    }

    if (action === 'thinking') {
      translateY.value = withTiming(0, { duration: 300 });
      scale.value = withTiming(1, { duration: 300 });
      rotateDeg.value = withRepeat(
        withSequence(
          withTiming(-5, { duration: 1500, easing: Easing.inOut(Easing.quad) }),
          withTiming(5, { duration: 1500, easing: Easing.inOut(Easing.quad) }),
        ),
        -1,
        true,
      );
    }
  }, [action, translateY, scale, rotateDeg]);

  // Occasional blink — only during idle. Random interval 2.5–5.5s, eye-closed 120ms.
  useEffect(() => {
    if (action !== 'idle') {
      setEyesClosed(false);
      return;
    }
    const scheduleNext = () => {
      const wait = 2500 + Math.random() * 3000;
      blinkTimers.current.next = setTimeout(() => {
        setEyesClosed(true);
        blinkTimers.current.close = setTimeout(() => {
          setEyesClosed(false);
          scheduleNext();
        }, 120);
      }, wait);
    };
    scheduleNext();
    return () => {
      if (blinkTimers.current.next) clearTimeout(blinkTimers.current.next);
      if (blinkTimers.current.close) clearTimeout(blinkTimers.current.close);
    };
  }, [action]);

  const wrapperStyle = useAnimatedStyle(() => ({
    transform: [
      { translateY: translateY.value },
      { scale: scale.value },
      { rotate: `${rotateDeg.value}deg` },
    ],
  }));

  const expression: Expression = expressionOverride ?? actionToExpression(action);

  return (
    <Animated.View style={wrapperStyle}>
      <AvatarBase
        assistantType={assistantType}
        equippedItems={equippedItems}
        expression={expression}
        eyesClosed={eyesClosed}
        size={size}
      />
    </Animated.View>
  );
};

export default AvatarDisplay;
