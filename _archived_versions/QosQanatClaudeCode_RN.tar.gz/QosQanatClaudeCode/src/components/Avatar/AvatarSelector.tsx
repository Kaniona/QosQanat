import { LinearGradient } from 'expo-linear-gradient';
import React, { useEffect } from 'react';
import { Pressable, StyleSheet, Text, View, Dimensions } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';

import { colors, fontSize, fontWeight, radius, spacing } from '@/theme';
import type { AssistantType } from '@/types';

import AvatarDisplay from './AvatarDisplay';

interface AssistantOption {
  type: AssistantType;
  name: string;
  tagline: string;
}

interface Props {
  options?: readonly AssistantOption[];
  selected: AssistantType | null;
  onSelect: (type: AssistantType) => void;
  cardWidth?: number;
}

const DEFAULT_OPTIONS: readonly AssistantOption[] = [
  { type: 'bektur', name: 'Бектұр', tagline: 'Қайрат берер, мадақтар, бірге оқиды!' },
  { type: 'nazym', name: 'Назым', tagline: 'Мейірімді, ақылды, сенімді жолдас!' },
];

const SCREEN_W = Dimensions.get('window').width;

interface CardProps extends AssistantOption {
  selected: boolean;
  faded: boolean;
  onPress: () => void;
  width: number;
}

const Card: React.FC<CardProps> = ({ type, name, tagline, selected, faded, onPress, width }) => {
  const scale = useSharedValue(1);
  const glow = useSharedValue(0);

  useEffect(() => {
    scale.value = withSpring(selected ? 1.05 : faded ? 0.97 : 1, { damping: 14, stiffness: 110 });
    glow.value = withTiming(selected ? 1 : 0, { duration: 280 });
  }, [selected, faded, scale, glow]);

  const cardStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: faded ? 0.6 : 1,
  }));

  const glowStyle = useAnimatedStyle(() => ({ opacity: glow.value }));

  const tint = type === 'bektur' ? colors.bekturColor : colors.nazymColor;

  return (
    <Pressable onPress={onPress} style={{ width }}>
      <Animated.View style={[styles.card, cardStyle]}>
        <Animated.View style={[styles.glow, glowStyle]} pointerEvents="none" />
        <LinearGradient
          colors={['rgba(255,255,255,0.18)', 'rgba(255,255,255,0.04)'] as readonly [string, string]}
          style={styles.cardInner}
        >
          <View style={[styles.avatarWrap, { backgroundColor: `${tint}22` }]}>
            <AvatarDisplay
              assistantType={type}
              action={selected ? 'celebrate' : 'idle'}
              size={width * 0.7}
            />
          </View>
          <Text style={styles.name}>{name}</Text>
          <Text style={styles.tagline}>{tagline}</Text>
        </LinearGradient>
      </Animated.View>
    </Pressable>
  );
};

const AvatarSelector: React.FC<Props> = ({
  options = DEFAULT_OPTIONS,
  selected,
  onSelect,
  cardWidth,
}) => {
  const width = cardWidth ?? (SCREEN_W - spacing.lg * 2 - spacing.md) / 2;
  return (
    <View style={styles.row}>
      {options.map((opt) => (
        <Card
          key={opt.type}
          type={opt.type}
          name={opt.name}
          tagline={opt.tagline}
          width={width}
          selected={selected === opt.type}
          faded={selected !== null && selected !== opt.type}
          onPress={() => { onSelect(opt.type); }}
        />
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: spacing.md,
    width: '100%',
  },
  card: {
    borderRadius: radius.xl,
    overflow: 'visible',
  },
  glow: {
    position: 'absolute',
    top: -4,
    left: -4,
    right: -4,
    bottom: -4,
    borderRadius: radius.xl + 4,
    borderWidth: 2.5,
    borderColor: colors.gold,
    shadowColor: colors.gold,
    shadowOpacity: 0.6,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 0 },
    elevation: 12,
  },
  cardInner: {
    padding: spacing.md,
    borderRadius: radius.xl,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  avatarWrap: {
    borderRadius: radius.xl,
    padding: spacing.sm,
    marginBottom: spacing.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  name: {
    color: colors.white,
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
    marginBottom: spacing.xs,
  },
  tagline: {
    color: 'rgba(255,255,255,0.78)',
    fontSize: fontSize.sm,
    textAlign: 'center',
    lineHeight: 18,
  },
});

export default AvatarSelector;
