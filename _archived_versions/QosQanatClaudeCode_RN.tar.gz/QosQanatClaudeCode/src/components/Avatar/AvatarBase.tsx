import React from 'react';
import Svg, { Circle, Ellipse, G, Path, Rect } from 'react-native-svg';

import { defaultItemFor, getAvatarItem, type AvatarItemCtx } from '@/data/avatarItems';
import type { AssistantType, ItemCategory } from '@/types';

import FaceLayer, { type Expression } from './expressions';

export type EquippedItems = Partial<Record<ItemCategory, string>>;

interface Props {
  assistantType: AssistantType;
  equippedItems?: EquippedItems;
  expression?: Expression;
  eyesClosed?: boolean;
  size?: number;
}

// ----------------------------------------------------------------------------
// Layer order (back → front), matching the Task 4 spec:
//   1 pet           2 shadow        3 body (skin)
//   4 bottom        5 shoes         6 top
//   7 neck access.  8 face          9 hair
//  10 hat          11 face access.
//
// The "accessory" item category covers both neck and face accessories — we
// route any accessory item to whichever of layers 7 / 11 makes sense based on
// where it draws (currently treated as neck on layer 7; face-overlay items
// like glasses would be added to layer 11 with a new `subSlot` field later).
// ----------------------------------------------------------------------------

const VB_W = 100;
const VB_H = 125;

const SKIN_BEKTUR = '#E8B080';
const SKIN_NAZYM = '#F7CFAC';
const HAIR_COLOR = '#1A1A2E';
const OUTLINE = '#0E0B26';
const SHOE_BLACK = '#1A1A2E';
const ACCENT_NAZYM = '#FFB0CC';

interface BodyProps {
  skin: string;
}

const BodyLayer: React.FC<BodyProps> = ({ skin }) => (
  <G>
    {/* Legs (skin under pants/skirt) */}
    <Rect
      x="40"
      y="104"
      width="8"
      height="18"
      rx="3"
      fill={skin}
      stroke={OUTLINE}
      strokeWidth="0.9"
    />
    <Rect
      x="52"
      y="104"
      width="8"
      height="18"
      rx="3"
      fill={skin}
      stroke={OUTLINE}
      strokeWidth="0.9"
    />
    {/* Arms */}
    <Path
      d="M 30 76 Q 22 90, 24 106 L 30 108 Q 34 94, 34 78 Z"
      fill={skin}
      stroke={OUTLINE}
      strokeWidth="0.9"
      strokeLinejoin="round"
    />
    <Path
      d="M 70 76 Q 78 90, 76 106 L 70 108 Q 66 94, 66 78 Z"
      fill={skin}
      stroke={OUTLINE}
      strokeWidth="0.9"
      strokeLinejoin="round"
    />
    {/* Hands */}
    <Circle cx="26" cy="107" r="4" fill={skin} stroke={OUTLINE} strokeWidth="0.9" />
    <Circle cx="74" cy="107" r="4" fill={skin} stroke={OUTLINE} strokeWidth="0.9" />
    {/* Torso (skin, covered by shirt) */}
    <Path
      d="M 32 74 Q 32 94, 34 105 L 66 105 Q 68 94, 68 74 L 60 70 L 50 76 L 40 70 Z"
      fill={skin}
      stroke={OUTLINE}
      strokeWidth="0.9"
      strokeLinejoin="round"
    />
    {/* Neck */}
    <Rect x="46" y="60" width="8" height="10" fill={skin} stroke={OUTLINE} strokeWidth="0.9" />
    {/* Head */}
    <Circle cx="50" cy="40" r="24" fill={skin} stroke={OUTLINE} strokeWidth="1.2" />
    {/* Ears */}
    <Ellipse cx="26" cy="42" rx="3" ry="5" fill={skin} stroke={OUTLINE} strokeWidth="0.9" />
    <Ellipse cx="74" cy="42" rx="3" ry="5" fill={skin} stroke={OUTLINE} strokeWidth="0.9" />
  </G>
);

const ShadowLayer: React.FC = () => (
  <Ellipse cx="50" cy="124" rx="24" ry="2.5" fill="#000" opacity="0.18" />
);

const ShoesLayer: React.FC = () => (
  <G>
    <Path
      d="M 38 119 L 38 122 Q 38 124, 41 124 L 50 124 L 50 119 Z"
      fill={SHOE_BLACK}
      stroke={OUTLINE}
      strokeWidth="0.8"
      strokeLinejoin="round"
    />
    <Path
      d="M 50 119 L 50 124 L 59 124 Q 62 124, 62 122 L 62 119 Z"
      fill={SHOE_BLACK}
      stroke={OUTLINE}
      strokeWidth="0.8"
      strokeLinejoin="round"
    />
  </G>
);

const HairLayerBektur: React.FC = () => (
  <G>
    {/* Short messy cap */}
    <Path
      d="M 26 38 Q 26 18, 50 16 Q 74 18, 74 38 Q 72 32, 66 30 Q 60 36, 52 32 Q 44 36, 38 30 Q 30 32, 26 38 Z"
      fill={HAIR_COLOR}
      stroke={OUTLINE}
      strokeWidth="1"
      strokeLinejoin="round"
    />
    {/* Side fringe over right brow */}
    <Path d="M 38 30 Q 44 26, 50 30 L 46 34 Z" fill={HAIR_COLOR} />
  </G>
);

const HairLayerNazym: React.FC = () => (
  <G>
    {/* Bob outline (covers crown, sides and back to chin level) */}
    <Path
      d="M 22 44 Q 22 14, 50 14 Q 78 14, 78 44 L 78 60 Q 76 64, 72 64 L 70 50 Q 68 36, 50 36 Q 32 36, 30 50 L 28 64 Q 24 64, 22 60 Z"
      fill={HAIR_COLOR}
      stroke={OUTLINE}
      strokeWidth="1"
      strokeLinejoin="round"
    />
    {/* Bangs */}
    <Path
      d="M 30 32 Q 38 22, 50 26 Q 62 22, 70 32 Q 60 32, 50 30 Q 40 32, 30 32 Z"
      fill={HAIR_COLOR}
    />
    {/* Pink bow accent on left side */}
    <Path
      d="M 70 26 L 75 22 L 75 30 Z M 70 26 L 75 30 L 75 22 Z"
      fill={ACCENT_NAZYM}
      stroke={OUTLINE}
      strokeWidth="0.6"
      strokeLinejoin="round"
    />
    <Circle cx="72.5" cy="26" r="1.4" fill="#C8336B" />
  </G>
);

// ----------------------------------------------------------------------------
// AvatarBase
// ----------------------------------------------------------------------------

const AvatarBase: React.FC<Props> = ({
  assistantType,
  equippedItems,
  expression = 'neutral',
  eyesClosed = false,
  size = 160,
}) => {
  const isBektur = assistantType === 'bektur';
  const skin = isBektur ? SKIN_BEKTUR : SKIN_NAZYM;

  const ctx: AvatarItemCtx = { assistantType };

  const topId = equippedItems?.top ?? defaultItemFor('top', assistantType);
  const bottomId = equippedItems?.bottom ?? defaultItemFor('bottom', assistantType);
  const hatId = equippedItems?.hat ?? null;
  const accessoryId = equippedItems?.accessory ?? null;
  const petId = equippedItems?.pet ?? null;

  const topItem = getAvatarItem(topId);
  const bottomItem = getAvatarItem(bottomId);
  const hatItem = getAvatarItem(hatId);
  const accessoryItem = getAvatarItem(accessoryId);
  const petItem = getAvatarItem(petId);

  return (
    <Svg width={size} height={size * (VB_H / VB_W)} viewBox={`0 0 ${VB_W} ${VB_H}`}>
      {/* Layer 1: pet */}
      {petItem ? petItem.render(ctx) : null}

      {/* Layer 2: shadow */}
      <ShadowLayer />

      {/* Layer 3: body */}
      <BodyLayer skin={skin} />

      {/* Layer 4: bottom */}
      {bottomItem ? bottomItem.render(ctx) : null}

      {/* Layer 5: shoes */}
      <ShoesLayer />

      {/* Layer 6: top */}
      {topItem ? topItem.render(ctx) : null}

      {/* Layer 7: neck accessory (uses the accessory item slot) */}
      {accessoryItem ? accessoryItem.render(ctx) : null}

      {/* Layer 8: face */}
      <FaceLayer expression={expression} eyesClosed={eyesClosed} />

      {/* Layer 9: hair */}
      {isBektur ? <HairLayerBektur /> : <HairLayerNazym />}

      {/* Layer 10: hat */}
      {hatItem ? hatItem.render(ctx) : null}

      {/* Layer 11: face accessory — reserved for future glasses/mask items.
          Add a `subSlot: 'face'` flag to AvatarItem to route here. */}
    </Svg>
  );
};

export default AvatarBase;
