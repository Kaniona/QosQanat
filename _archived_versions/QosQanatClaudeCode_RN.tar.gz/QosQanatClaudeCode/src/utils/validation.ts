import { digitsOnly, toCanonicalKzPhone } from './phoneFormat';

export const isValidFullName = (value: string): boolean => {
  const parts = value
    .trim()
    .split(/\s+/)
    .filter((p) => p.length >= 2);
  return parts.length >= 2;
};

export const isValidKzPhone = (value: string): boolean => {
  return toCanonicalKzPhone(value).length === 11;
};

export const isValidIin = (value: string): boolean => {
  return digitsOnly(value).length === 12;
};

export const isValidSchool = (value: string): boolean => value.trim().length >= 2;

export const isValidGrade = (value: number | null): boolean =>
  value !== null && value >= 1 && value <= 11;

export const isValidCity = (value: string): boolean => value.trim().length > 0;
