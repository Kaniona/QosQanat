// Returns only the digit characters in `input`.
export const digitsOnly = (input: string): string => input.replace(/\D/g, '');

// Formats an in-progress phone number to the Kazakhstan mask "+7 (XXX) XXX-XX-XX".
// The input may already contain formatting characters; only the digits are used.
// Leading "8" is normalised to "7"; the leading "7" is omitted from the input
// region because the mask always renders "+7 ".
export const formatKzPhone = (input: string): string => {
  let raw = digitsOnly(input);
  if (raw.startsWith('8')) raw = '7' + raw.slice(1);
  if (raw.startsWith('7')) raw = raw.slice(1);
  raw = raw.slice(0, 10);

  let out = '+7';
  if (raw.length > 0) out += ' (' + raw.slice(0, 3);
  if (raw.length >= 3) out += ')';
  if (raw.length > 3) out += ' ' + raw.slice(3, 6);
  if (raw.length > 6) out += '-' + raw.slice(6, 8);
  if (raw.length > 8) out += '-' + raw.slice(8, 10);
  return out;
};

// Returns 11-digit canonical form starting with 7, e.g. "77011234567".
export const toCanonicalKzPhone = (input: string): string => {
  let raw = digitsOnly(input);
  if (raw.startsWith('8')) raw = '7' + raw.slice(1);
  if (!raw.startsWith('7')) raw = '7' + raw;
  return raw.slice(0, 11);
};

// Masks a canonical phone for display, e.g. "+7 (777) ***-**-67".
export const maskKzPhone = (input: string): string => {
  const raw = toCanonicalKzPhone(input);
  if (raw.length < 11) return formatKzPhone(input);
  const a = raw.slice(1, 4);
  const last = raw.slice(9, 11);
  return `+7 (${a}) ***-**-${last}`;
};

// Masks an IIN: shows first 4 and last 2, hides the rest, e.g. "1234*****67".
export const maskIin = (iin: string): string => {
  const raw = digitsOnly(iin);
  if (raw.length !== 12) return raw;
  return raw.slice(0, 4) + '******' + raw.slice(10, 12);
};
