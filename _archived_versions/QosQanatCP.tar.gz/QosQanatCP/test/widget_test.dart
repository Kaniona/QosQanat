import 'package:flutter_test/flutter_test.dart';
import 'package:qos_qanat/main.dart';
import 'package:qos_qanat/data/store/app_store.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('QosQanat opens registration screen', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final store = AppStore(prefs);
    await store.load();

    await tester.pumpWidget(QosQanatApp(store: store));

    expect(find.text('QosQanat'), findsOneWidget);
    
    // Tap the Welcome "Бастау 🪽" button to navigate to the form page
    await tester.tap(find.text('Бастау 🪽'));
    await tester.pumpAndSettle();

    expect(find.text('Оқушыны тіркеу'), findsOneWidget);
  });
}
