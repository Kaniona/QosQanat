# QosQanat (ҚосҚанат) 🪽

QosQanat is a premium, high-fidelity gamified AI educational companion app designed to empower Kazakhstani youth with wisdom (**Ақыл**), competitive peer battles (**Aqyl Battle**), character customisation shop, voice assistant learning companions, achievements, and dynamic interactive study maps.

---

## 🚀 Key Feature Modules

1. **Social & Friend System (`lib/screens/friends/`)**
   * **Three Tab Layout**: Accepted friends (**Достарым**), pending/incoming request lists (**Өтінімдер**), and user lookup (**Іздеу**).
   * **QQ-ID Search**: High-fidelity user lookup card with status indicators, level badges, and "дос қос" invite loops.

2. **Interactive Battle Arena (`lib/screens/battle/`)**
   * **Battle Setup**: Challenger configurations for question count and topic categories.
   * **Simulated Matchmaker**: Sword clashing entrance animations, real-time split score screens, ticking 10s gameplay countdowns, and double wisdom rewards.

3. **Leaderboard Scope (`lib/screens/rating/`)**
   * **4 Tab Pillars**: Global (**Жалпы**), Friends (**Достарым**), School (**Мектебім**), and City (**Қалам**).
   * **Crown Podiums**: 1st, 2nd, and 3rd ranks with custom colored podium cards, fire emojis, highlighted user rows, and sticky bottom rank views.

4. **Onboarding & Multi-Step Registration (`lib/screens/registration/`)**
   * High-contrast step walkthroughs featuring automatic checking of full name, phone number, and school.
   * Selection of personal voice learning companions (**Бектүр / Назым**).
   * Celebratory confetti animation bursts and an automatic grant of **100 welcome coins**.

5. **Settings & Custom Tabs (`lib/screens/settings/`)**
   * Push notification simulation preferences, local sound effects toggles, Kazakh/Russian language selectors, and app deletion dialogs.
   * Sleek custom bottom navigation bar with a raised, glowing middle tab for **Оқу** and dynamic pending request badges.

---

## 🛠️ Running the Application

### 📦 Installation
```bash
# Get all pub dependencies
flutter pub get
```

### 📱 Launch App
Ensure you have a connected device or emulator running:
```bash
flutter run
```

### 🧪 Run Static Verification
To ensure pristine type safety and compilation:
```bash
flutter analyze
```

---

## 🎛️ NDK Compilation Solutions (Fixed)

The project leverages a robust subproject NDK configuration block inside `android/build.gradle.kts` to safely force the usage of a complete and valid local NDK (`27.0.12077973`), resolving standard malformed `CXX1101` exceptions:

```kotlin
subprojects {
    val configureNdk: Project.() -> Unit = {
        val android = extensions.findByName("android")
        if (android != null) {
            (android as? com.android.build.gradle.BaseExtension)?.ndkVersion = "27.0.12077973"
        }
    }
    if (state.executed) {
        configureNdk()
    } else {
        afterEvaluate {
            configureNdk()
        }
    }
}
```
