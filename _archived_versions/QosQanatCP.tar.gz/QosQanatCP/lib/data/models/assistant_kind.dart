import 'package:flutter/material.dart';

/// Assistant type enum
enum AssistantKind { bektur, nazym }

/// Extension with display info for each assistant
extension AssistantInfo on AssistantKind {
  String get displayName =>
      this == AssistantKind.bektur ? 'Бектұр' : 'Назым';

  String get role => this == AssistantKind.bektur
      ? 'Сабырлы стратег, математика мен логикаға жақын.'
      : 'Шабыт беретін гид, тілдер мен креатив тапсырмаларға жақын.';

  String get greeting => this == AssistantKind.bektur
      ? 'Сәлем! Мен Бектұр, сенің ақылды серігіңмін. Бірге оқып, жеңіске жетеміз!'
      : 'Сәлем! Мен Назым, сенің шабытты жолсерігіңмін. Бірге жаңалық ашамыз!';

  Color get color => this == AssistantKind.bektur
      ? const Color(0xFF2D7FF9)
      : const Color(0xFFE91E78);

  Color get accent => this == AssistantKind.bektur
      ? const Color(0xFF0CEBAB)
      : const Color(0xFFFF9100);

  Color get hairColor => this == AssistantKind.bektur
      ? const Color(0xFF1A1A2E)
      : const Color(0xFF3D1F00);

  IconData get icon =>
      this == AssistantKind.bektur ? Icons.psychology_alt : Icons.auto_awesome;

  LinearGradient get gradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [color, accent],
      );
}
