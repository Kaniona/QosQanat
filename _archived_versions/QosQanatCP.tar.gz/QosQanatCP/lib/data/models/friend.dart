import 'dart:math';
import '../../core/constants.dart';

/// Friend request status
enum FriendRequestStatus {
  accepted,
  pendingIncoming,
  pendingOutgoing,
}

/// Friend model with request status and avatar support
class Friend {
  const Friend({
    required this.qqId,
    required this.name,
    required this.city,
    required this.wisdom,
    this.level = 1,
    this.isOnline = false,
    this.avatarEmoji = '🧑‍🎓',
    this.requestStatus = FriendRequestStatus.accepted,
  });

  final String qqId;
  final String name;
  final String city;
  final int wisdom; // akyl points
  final int level;
  final bool isOnline;
  final String avatarEmoji;
  final FriendRequestStatus requestStatus;

  /// Convenience alias for wisdom
  int get akylPoints => wisdom;

  /// Copy with new status
  Friend copyWith({
    String? qqId,
    String? name,
    String? city,
    int? wisdom,
    int? level,
    bool? isOnline,
    String? avatarEmoji,
    FriendRequestStatus? requestStatus,
  }) {
    return Friend(
      qqId: qqId ?? this.qqId,
      name: name ?? this.name,
      city: city ?? this.city,
      wisdom: wisdom ?? this.wisdom,
      level: level ?? this.level,
      isOnline: isOnline ?? this.isOnline,
      avatarEmoji: avatarEmoji ?? this.avatarEmoji,
      requestStatus: requestStatus ?? this.requestStatus,
    );
  }

  Map<String, dynamic> toJson() => {
        'qqId': qqId,
        'name': name,
        'city': city,
        'wisdom': wisdom,
        'level': level,
        'isOnline': isOnline,
        'avatarEmoji': avatarEmoji,
        'requestStatus': requestStatus.name,
      };

  factory Friend.fromJson(Map<String, dynamic> data) {
    return Friend(
      qqId: data['qqId'] as String? ?? AppConstants.generateQqId(),
      name: data['name'] as String? ?? 'Дос',
      city: data['city'] as String? ?? 'Қазақстан',
      wisdom: data['wisdom'] as int? ?? 90,
      level: data['level'] as int? ?? 1,
      isOnline: data['isOnline'] as bool? ?? false,
      avatarEmoji: data['avatarEmoji'] as String? ?? '🧑‍🎓',
      requestStatus: FriendRequestStatus.values.firstWhere(
        (e) => e.name == data['requestStatus'],
        orElse: () => FriendRequestStatus.accepted,
      ),
    );
  }

  /// Random avatar emoji from a curated pool
  static String randomAvatarEmoji() {
    const emojis = [
      '🧑‍🎓', '👦', '👧', '🦸', '🦹', '🧙', '🧑‍🚀',
      '🧑‍💻', '🧑‍🔬', '🧑‍🎨', '🧑‍🏫', '🦊', '🐺',
      '🦅', '🐉', '🦁', '🐯', '🦄',
    ];
    return emojis[Random().nextInt(emojis.length)];
  }
}
