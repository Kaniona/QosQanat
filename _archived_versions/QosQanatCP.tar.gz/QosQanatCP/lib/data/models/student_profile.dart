import '../../core/constants.dart';

/// Student profile data
class StudentProfile {
  const StudentProfile({
    required this.qqId,
    required this.fullName,
    required this.phone,
    required this.iin,
    required this.city,
    required this.school,
    this.grade = 5,
  });

  final String qqId;
  final String fullName;
  final String phone;
  final String iin;
  final String city;
  final String school;
  final int grade;

  Map<String, dynamic> toJson() => {
        'qqId': qqId,
        'fullName': fullName,
        'phone': phone,
        'iin': iin,
        'city': city,
        'school': school,
        'grade': grade,
      };

  factory StudentProfile.fromJson(Map<String, dynamic> data) {
    return StudentProfile(
      qqId: data['qqId'] as String? ?? AppConstants.generateQqId(),
      fullName: data['fullName'] as String? ?? '',
      phone: data['phone'] as String? ?? '',
      iin: data['iin'] as String? ?? '',
      city: data['city'] as String? ?? '',
      school: data['school'] as String? ?? '',
      grade: data['grade'] as int? ?? 5,
    );
  }
}
