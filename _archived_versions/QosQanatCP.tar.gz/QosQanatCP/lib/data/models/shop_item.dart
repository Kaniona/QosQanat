import 'package:flutter/material.dart';

/// Rarity tier for shop items
enum Rarity { common, rare, epic, legendary }

extension RarityInfo on Rarity {
  String get label {
    switch (this) {
      case Rarity.common:
        return 'Кәдімгі';
      case Rarity.rare:
        return 'Сирек';
      case Rarity.epic:
        return 'Эпик';
      case Rarity.legendary:
        return 'Легенда';
    }
  }

  Color get color {
    switch (this) {
      case Rarity.common:
        return const Color(0xFF90A4AE);
      case Rarity.rare:
        return const Color(0xFF42A5F5);
      case Rarity.epic:
        return const Color(0xFFAB47BC);
      case Rarity.legendary:
        return const Color(0xFFFFD600);
    }
  }
}

/// Shop item model
class ShopItem {
  const ShopItem({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
    required this.coinPrice,
    required this.description,
    required this.unlockLevel,
    required this.previewImage,
    required this.icon,
    required this.color,
    this.rarity = Rarity.common,
  });

  final String id;
  final String name;
  final String category;
  final int price;
  final int coinPrice;
  final String description;
  final int unlockLevel;
  final String previewImage;
  final IconData icon;
  final Color color;
  final Rarity rarity;
}
