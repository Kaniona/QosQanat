/// Study lesson node on the map
class LessonNode {
  const LessonNode({
    required this.id,
    required this.title,
    required this.subject,
    required this.question,
    required this.options,
    required this.correctIndex,
    required this.wisdomReward,
    required this.expReward,
    this.explanation = '',
    this.isBoss = false,
    this.timeLimit = 30,
  });

  final int id;
  final String title;
  final String subject;
  final String question;
  final List<String> options;
  final int correctIndex;
  final int wisdomReward;
  final int expReward;
  final String explanation;
  final bool isBoss;
  final int timeLimit; // seconds
}
