enum CurriculumNodeType {
  lesson,
  quiz,
  boss,
  treasure,
}

enum TaskType {
  multipleChoice,
  fillBlank,
  matchPairs,
  trueFalse,
}

/// Task question detail
class TaskQuestion {
  const TaskQuestion({
    required this.type,
    required this.questionText,
    this.options = const [],
    this.correctString = '',
    this.correctIndex = 0,
    this.matchingPairs = const {},
    this.explanation = '',
  });

  final TaskType type;
  final String questionText;
  final List<String> options;
  final String correctString;
  final int correctIndex;
  final Map<String, String> matchingPairs;
  final String explanation;
}

/// A node on the learning map
class CurriculumNode {
  const CurriculumNode({
    required this.id,
    required this.title,
    required this.type,
    required this.xpReward,
    required this.coinReward,
    required this.akylReward,
    required this.questions,
  });

  final String id;
  final String title;
  final CurriculumNodeType type;
  final int xpReward;
  final int coinReward;
  final int akylReward;
  final List<TaskQuestion> questions;
}

/// Chapter grouping nodes
class Chapter {
  const Chapter({
    required this.id,
    required this.name,
    required this.nodes,
  });

  final String id;
  final String name;
  final List<CurriculumNode> nodes;
}

/// Subject grouping chapters
class Subject {
  const Subject({
    required this.id,
    required this.name,
    required this.icon,
    required this.colorHex,
    required this.chapters,
  });

  final String id;
  final String name;
  final String icon;
  final String colorHex;
  final List<Chapter> chapters;
}
