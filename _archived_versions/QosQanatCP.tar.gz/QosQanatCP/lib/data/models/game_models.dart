/// Battle result between player and friend
class BattleResult {
  const BattleResult({
    required this.friendName,
    required this.myScore,
    required this.friendScore,
    required this.won,
    required this.totalQuestions,
  });

  final String friendName;
  final int myScore;
  final int friendScore;
  final bool won;
  final int totalQuestions;

  double get myAccuracy => totalQuestions > 0 ? myScore / totalQuestions : 0;
  double get friendAccuracy =>
      totalQuestions > 0 ? friendScore / totalQuestions : 0;
}

/// Lesson completion reward
class LessonReward {
  const LessonReward({
    required this.wisdom,
    required this.exp,
    required this.coins,
    required this.leveledUp,
  });

  final int wisdom;
  final int exp;
  final int coins;
  final bool leveledUp;
}

/// Quest progress model
class Quest {
  const Quest({
    required this.title,
    required this.progress,
    required this.total,
    required this.reward,
    required this.icon,
  });

  final String title;
  final int progress;
  final int total;
  final String reward;
  final String icon;

  bool get complete => progress >= total;
  double get percentage => total > 0 ? (progress / total).clamp(0.0, 1.0) : 0;
}

/// Achievement badge
class Achievement {
  const Achievement({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    this.unlocked = false,
  });

  final String id;
  final String title;
  final String description;
  final String icon;
  final bool unlocked;
}

/// A single battle question for the live battle screen
class BattleQuestion {
  const BattleQuestion({
    required this.question,
    required this.options,
    required this.correctIndex,
    required this.subject,
  });

  final String question;
  final List<String> options;
  final int correctIndex;
  final String subject;
}

/// Live battle state tracker
class LiveBattleState {
  LiveBattleState({
    required this.battleId,
    required this.questions,
    required this.opponentName,
    required this.opponentEmoji,
    required this.opponentLevel,
    required this.opponentWisdom,
  });

  final String battleId;
  final List<BattleQuestion> questions;
  final String opponentName;
  final String opponentEmoji;
  final int opponentLevel;
  final int opponentWisdom;

  int currentQuestionIndex = 0;
  int myScore = 0;
  int opponentScore = 0;
  int myTimeBonus = 0;
  int opponentTimeBonus = 0;

  bool get isFinished => currentQuestionIndex >= questions.length;
  BattleQuestion get currentQuestion => questions[currentQuestionIndex];
  int get totalQuestions => questions.length;

  /// Calculate winner akyl reward (2x for winner)
  int get winnerAkylReward {
    final baseReward = totalQuestions;
    return baseReward * 2;
  }

  int get loserAkylReward {
    return (totalQuestions * 0.5).round();
  }
}
