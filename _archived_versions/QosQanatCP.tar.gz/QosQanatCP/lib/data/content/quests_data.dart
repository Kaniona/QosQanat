import '../models/game_models.dart';
import '../store/app_store.dart';

/// Configuration & Dynamic Evaluator for QosQanat Quests
class QuestsData {
  QuestsData._();

  /// Dynamically computes active quests based on store statistics.
  /// This evaluates quest progress in real-time, giving exact Kazakh translations and proper badges/rewards.
  static List<Quest> getActiveQuests(AppStore store) {
    return [
      Quest(
        title: 'Күнделікті кіру',
        progress: store.profile != null ? 1 : 0,
        total: 1,
        reward: '🪙 10',
        icon: '🔑',
      ),
      Quest(
        title: '3 күн қатарынан кіру',
        progress: store.streak,
        total: 3,
        reward: '🪙 50',
        icon: '🔥',
      ),
      Quest(
        title: '7 күн қатарынан кіру',
        progress: store.streak,
        total: 7,
        reward: '🪙 150 + 🏅',
        icon: '⭐',
      ),
      Quest(
        title: '5 тапсырма орындау',
        progress: store.todayTasks,
        total: 5,
        reward: '🪙 30 + ⚡ 50',
        icon: '📚',
      ),
      Quest(
        title: '7 тапсырма қатарынан дұрыс',
        progress: store.correctStreak,
        total: 7,
        reward: '🪙 100',
        icon: '⚡',
      ),
      Quest(
        title: 'Досыңмен батл ойна',
        progress: store.todayBattles,
        total: 1,
        reward: '🪙 20',
        icon: '⚔️',
      ),
      Quest(
        title: 'Дүкеннен зат сатып ал',
        progress: store.ownedItems.length - 1, // Subtract starter jacket
        total: 1,
        reward: '🪙 15',
        icon: '🛒',
      ),
    ];
  }
}
