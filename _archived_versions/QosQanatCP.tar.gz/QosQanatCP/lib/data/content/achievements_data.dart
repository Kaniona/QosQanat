import '../models/game_models.dart';

/// Predefined list of achievements with circular Kazakh-themed icons/emojis
final List<Achievement> allAchievements = [
  const Achievement(
    id: 'first-task',
    title: 'Алғашқы қадам',
    description: 'Алғашқы тапсырманы орындады',
    icon: '🚀',
  ),
  const Achievement(
    id: 'ten-tasks',
    title: 'Білімқор',
    description: '10 тапсырманы сәтті аяқтады',
    icon: '📚',
  ),
  const Achievement(
    id: 'first-battle',
    title: 'Жеңімпаз',
    description: 'Алғашқы батл жеңісі',
    icon: '🏆',
  ),
  const Achievement(
    id: 'ten-battles',
    title: 'Батыр',
    description: '10 батл жеңісі',
    icon: '⚔️',
  ),
  const Achievement(
    id: 'five-friends',
    title: 'Танымал',
    description: '5 дос қосты',
    icon: '🤝',
  ),
  const Achievement(
    id: 'streak-7',
    title: 'Дәйекті',
    description: '7 күн қатарынан оқу',
    icon: '🔥',
  ),
  const Achievement(
    id: 'rich-1000',
    title: 'Бай',
    description: '1000 тиын жинады',
    icon: '🪙',
  ),
  const Achievement(
    id: 'level-10',
    title: 'Чемпион',
    description: '10-деңгейге жетті',
    icon: '🌟',
  ),
  const Achievement(
    id: 'all-subjects',
    title: 'Барлық пән',
    description: 'Әр пәннен тапсырма орындады',
    icon: '🎓',
  ),
];
