import '../models/curriculum.dart';

/// Full static curriculum data for Kazakhstan Grades 5-9
/// Consists of 5 Subjects × 3 Chapters × 5 Nodes = 75 Nodes total.
/// Contains genuine curriculum tasks and multiple interactive question formats.
final List<Subject> curriculum = [
  // =========================================================================
  // 1. МАТЕМАТИКА (🔢)
  // =========================================================================
  const Subject(
    id: 'math',
    name: 'Математика',
    icon: '🔢',
    colorHex: '#4A90E2',
    chapters: [
      Chapter(
        id: 'math_c1',
        name: '1-тарау: Жай және ондық бөлшектер',
        nodes: [
          CurriculumNode(
            id: 'm1',
            title: 'Жай бөлшектерді қосу',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: '1/3 + 1/6 қосындысын табыңыз:',
                options: ['1/9', '2/9', '1/2', '3/6'],
                correctIndex: 2,
                explanation: 'Ортақ бөлімге келтіреміз: 1/3 = 2/6. Олай болса, 2/6 + 1/6 = 3/6 = 1/2.',
              ),
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: '3/4 бөлшегі 5/8 бөлшегінен үлкен. Осы тұжырым ақиқат па?',
                correctString: 'Шындық',
                explanation: '3/4 = 6/8. 6/8 > 5/8 болғандықтан, бұл тұжырым ақиқат.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'm2',
            title: 'Аралас сандарды салыстыру',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: '2 бүтін 1/2 саны бұрыс бөлшек түрінде жазылса, алымында неше болады?',
                options: ['3', '4', '5', '6'],
                correctString: '5',
                explanation: 'Аралас санды бұрыс бөлшекке айналдыру үшін: 2 × 2 + 1 = 5. Демек, бөлшек 5/2 болады.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'm3',
            title: 'Бөлшектерді көбейту',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.matchPairs,
                questionText: 'Бөлшектер мен олардың көбейтінділерін сәйкестендіріңіз:',
                matchingPairs: {
                  '1/2 × 1/3': '1/6',
                  '2/5 × 5/4': '1/2',
                  '3/7 × 7/3': '1',
                  '4/9 × 3/2': '2/3',
                },
                explanation: 'Көбейту кезінде алымын алымына, бөлімін бөліміне көбейтеміз және қысқартамыз.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'm4',
            title: 'Бөлшектер қазынасы',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: '0.25 бөлшегі жай бөлшек түрінде қалай жазылады?',
                options: ['1/2', '1/3', '1/4', '1/5'],
                correctIndex: 2,
                explanation: '0.25 = 25/100 = 1/4.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'm5',
            title: 'Бөлшектер шайқасы',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Санның 3/4 бөлігі 120-ға тең болса, санның өзін табыңыз:',
                options: ['90', '160', '180', '200'],
                correctIndex: 1,
                explanation: 'Санды табу үшін бөлігіне бөлеміз: 120 / (3/4) = 120 × 4/3 = 160.',
              ),
            ],
          ),
        ],
      ),
      Chapter(
        id: 'math_c2',
        name: '2-тарау: Теңдеулер мен пропорциялар',
        nodes: [
          CurriculumNode(
            id: 'm6',
            title: 'Қарапайым теңдеулер',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: '3x - 7 = 14 теңдеуінің түбірін табыңыз:',
                options: ['5', '6', '7', '8'],
                correctIndex: 2,
                explanation: '3x = 14 + 7 => 3x = 21 => x = 7.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'm7',
            title: 'Пропорция қасиеті',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: 'Пропорцияның шеткі мүшелерінің көбейтіндісі оның ортаңғы мүшелерінің көбейтіндісіне тең. Бұл тұжырым дұрыс па?',
                correctString: 'Шындық',
                explanation: 'Бұл пропорцияның негізгі қасиеті: a/b = c/d болса, ad = bc.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'm8',
            title: 'Теңдеу құрастыру',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: 'Ойлаған санды 3-ке көбейтіп 5-ті қосқанда 26 шықты. Ойлаған санды табыңыз:',
                options: ['5', '6', '7', '8'],
                correctString: '7',
                explanation: '3x + 5 = 26 => 3x = 21 => x = 7.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'm9',
            title: 'Алтын пропорция',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: '2:x = 6:15 пропорциясынан x-ті табыңыз:',
                options: ['3', '5', '6', '10'],
                correctIndex: 1,
                explanation: 'Пропорция қасиеті бойынша: 6x = 2 × 15 => 6x = 30 => x = 5.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'm10',
            title: 'Теңдеулер патшалығы',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Екі санның қосындысы 40, ал олардың айырмасы 10-ға тең. Үлкен санды табыңыз:',
                options: ['15', '20', '25', '30'],
                correctIndex: 2,
                explanation: 'Жүйе құрамыз: x+y=40, x-y=10. Қосамыз: 2x = 50 => x = 25. Кіші сан y = 15.',
              ),
            ],
          ),
        ],
      ),
      Chapter(
        id: 'math_c3',
        name: '3-тарау: Пайыздар және статистика',
        nodes: [
          CurriculumNode(
            id: 'm11',
            title: 'Пайызды табу',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: '500-дің 12%-ы нешеге тең?',
                options: ['40', '50', '60', '70'],
                correctIndex: 2,
                explanation: '500 × 12 / 100 = 60.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'm12',
            title: 'Арифметикалық орта',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: '12, 15, 18, 23 сандарының арифметикалық ортасын табыңыз:',
                options: ['16', '17', '18', '19'],
                correctIndex: 1,
                explanation: '(12 + 15 + 18 + 23) / 4 = 68 / 4 = 17.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'm13',
            title: 'Пайыздық өсім',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: 'Тауар бағасы 2000 теңгеден 2500 теңгеге қымбаттады. Баға неше пайызға өсті?',
                options: ['15', '20', '25', '30'],
                correctString: '25',
                explanation: 'Өсім: 500 теңге. Пайызы: (500 / 2000) × 100% = 25%.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'm14',
            title: 'Статистикалық сандықтар',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: 'Сандар қатарының медианасын табу үшін оларды міндетті түрде өсу ретімен орналастыру керек пе?',
                correctString: 'Шындық',
                explanation: 'Медиана - өсу немесе кему ретімен орналасқан сандар тізбегінің ортасындағы сан.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'm15',
            title: 'Пайыздардың соңғы бекінісі',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Сыныптағы 20 оқушының 60%-ы ұлдар. Қалған оқушылар қыздар болса, қыздар саны қанша?',
                options: ['6', '8', '10', '12'],
                correctIndex: 1,
                explanation: 'Қыздар пайызы: 40%. 20 оқушының 40%-ы = 20 × 0.4 = 8 қыз.',
              ),
            ],
          ),
        ],
      ),
    ],
  ),

  // =========================================================================
  // 2. ҚАЗАҚ ТІЛІ (✍️)
  // =========================================================================
  const Subject(
    id: 'kazakh',
    name: 'Қазақ тілі',
    icon: '✍️',
    colorHex: '#00E676',
    chapters: [
      Chapter(
        id: 'kaz_c1',
        name: '1-тарау: Фонетика және орфография',
        nodes: [
          CurriculumNode(
            id: 'k1',
            title: 'Дауысты дыбыстар классификациясы',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Төмендегілердің ішінен жіңішке дауысты дыбыстар қатарын табыңыз:',
                options: ['а, о, ұ, ы', 'ә, е, ө, ү', 'ы, і, е, а', 'у, и, ю, я'],
                correctIndex: 1,
                explanation: 'ә, е, ө, ү дыбыстары - қазақ тіліндегі жіңішке дауыстылар.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'k2',
            title: 'Буын түрлері',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.matchPairs,
                questionText: 'Сөздер мен олардың буын түрлерін сәйкестендіріңіз:',
                matchingPairs: {
                  'Аш': 'Тұйық буын',
                  'Мек-теп': 'Бітеу буын',
                  'Ба-ла': 'Ашық буын',
                  'А-та': 'Аралас буындар',
                },
                explanation: 'Ашық буын дауысты дыбыспен аяқталады, тұйық буын дауыстыдан басталып дауыссызға бітеді, бітеу буын дауыссыздан басталып дауыссызға бітеді.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'k3',
            title: 'Үндестік заңы',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: 'Қазақ тіліндегі үндестік заңының екінші атауы қалай?',
                options: ['Сингармонизм', 'Ассимиляция', 'Диссимиляция', 'Фонема'],
                correctString: 'Сингармонизм',
                explanation: 'Үндестік заңы сингармонизм деп аталады, ол сөз ішіндегі дыбыстардың біркелкі жуан не жіңішке болып келуі.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'k4',
            title: 'Дыбыстар қазынасы',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: '«у» дыбысы сөзде тек дауысты болады. Осы пікір дұрыс па?',
                correctString: 'Жалған',
                explanation: '«у» дыбысы дауыстыдан кейін немесе бұрын келсе дауыссыз (мысалы, тау), ал дауыссыз дыбыстардың ортасында келсе дауысты (мысалы, су).',
              ),
            ],
          ),
          CurriculumNode(
            id: 'k5',
            title: 'Фонетикалық Арена',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Қай сөзде ілгерінді ықпал байқалады?',
                options: ['көзқарас', 'басшы', 'көк майса', 'балалар'],
                correctIndex: 3,
                explanation: 'бала + лар => балалар. Бірінші сөздің соңғы дыбысы екінші сөздің басқы дыбысына әсер етуі ілгерінді ықпал.',
              ),
            ],
          ),
        ],
      ),
      Chapter(
        id: 'kaz_c2',
        name: '2-тарау: Лексика және фразеология',
        nodes: [
          CurriculumNode(
            id: 'k6',
            title: 'Синонимдер мен антонимдер',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: '«Сұлу» сөзінің синонимін табыңыз:',
                options: ['Әдемі', 'Ақылды', 'Қорқақ', 'Кішіпейіл'],
                correctIndex: 0,
                explanation: 'Сұлу мен әдемі - мағыналас синоним сөздер.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'k7',
            title: 'Омонимдер сыры',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: 'Жазылуы бірдей, бірақ мағынасы мүлдем басқа сөздер омонимдер деп аталады.',
                correctString: 'Шындық',
                explanation: 'Мысалы, «жаз» (мезгіл немесе жазу әрекеті). Бұл омонимге мысал.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'k8',
            title: 'Тұрақты тіркестер',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: '«Төбесі көкке жету» фразеологизмінің мағынасы қандай?',
                options: ['Қатты қуану', 'Қорқу', 'Мұңаю', 'Өкіну'],
                correctString: 'Қатты қуану',
                explanation: '«Төбесі көкке жету» тұрақты тіркесі ерекше қуануды немесе мәз болуды білдіреді.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'k9',
            title: 'Сөздер қоймасы',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: '«Қоян жүрек» тіркесінің мағынасы не?',
                options: ['Батыр', 'Қорқақ', 'Жүйрік', 'Ақылды'],
                correctIndex: 1,
                explanation: 'Қоян секілді қорқақ адамды «қоян жүрек» деп айтады.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'k10',
            title: 'Лексикалық патшалық',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Басқа тілден енген сөздер қалай аталады?',
                options: ['Диалект сөздер', 'Көнерген сөздер', 'Кірме сөздер', 'Неологизмдер'],
                correctIndex: 2,
                explanation: 'Өзге тілдерден қабылданып, сөздік құрамға қосылған сөздер кірме сөздер деп аталады.',
              ),
            ],
          ),
        ],
      ),
      Chapter(
        id: 'kaz_c3',
        name: '3-тарау: Морфология (Сөз таптары)',
        nodes: [
          CurriculumNode(
            id: 'k11',
            title: 'Зат есім жалғаулары',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Зат есімнің көптік жалғаулары қайсы?',
                options: ['-ны/-ні, -ты/-ті', '-лар/-лер, -дар/-дер, -тар/-тер', '-ым/-ім, -ың/-ің', '-қа/-ке, -ға/-ге'],
                correctIndex: 1,
                explanation: '-лар/-лер және оның нұсқалары - қазақ тіліндегі көптік жалғаулары.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'k12',
            title: 'Сын есім шырайлары',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: '«Ең биік» сөзі күшейтпелі шырайға жатады. Бұл дұрыс па?',
                correctString: 'Шындық',
                explanation: 'Сын есімнің алдына «ең», «өте», «аса» шырай шығарушы сөздері қосылса, ол күшейтпелі шырай болады.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'k13',
            title: 'Есімдіктер жіктелуі',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: '«Мен, сен, ол» есімдіктері есімдіктің қай түріне жатады?',
                options: ['Жіктеу есімдігі', 'Сұрау есімдігі', 'Сілтеу есімдігі', 'Өздік есімдігі'],
                correctString: 'Жіктеу есімдігі',
                explanation: 'Жақты білдіретін мен, сен, біз, сіз, олар жіктеу есімдіктері болып табылады.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'k14',
            title: 'Морфологиялық сандықтар',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Қимылдың атауын білдіретін сөздер қалай аталады?',
                options: ['Зат есім', 'Етістік', 'Үстеу', 'Шылау'],
                correctIndex: 1,
                explanation: 'Заттың қимылын, іс-әрекетін білдіретін сөз табы - етістік.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'k15',
            title: 'Сөз таптарының соңғы бекінісі',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Заттың санын білдіретін сөз табы қайсы?',
                options: ['Зат есім', 'Сан есім', 'Сын есім', 'Есімдік'],
                correctIndex: 1,
                explanation: 'Сан есім заттың санын, мөлшерін білдіреді, «қанша?», «неше?» сұрақтарына жауап береді.',
              ),
            ],
          ),
        ],
      ),
    ],
  ),

  // =========================================================================
  // 3. АҒЫЛШЫН ТІЛІ (🇬🇧)
  // =========================================================================
  const Subject(
    id: 'english',
    name: 'Ағылшын тілі',
    icon: '🇬🇧',
    colorHex: '#FF2D78',
    chapters: [
      Chapter(
        id: 'eng_c1',
        name: 'Chapter 1: Tenses & Grammar Basis',
        nodes: [
          CurriculumNode(
            id: 'e1',
            title: 'Present Simple vs Continuous',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Listen! The birds ___ in the garden.',
                options: ['sing', 'are singing', 'sings', 'sang'],
                correctIndex: 1,
                explanation: 'The marker "Listen!" indicates an action happening right now (Present Continuous). We use: are singing.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'e2',
            title: 'Past Simple Irregular Verbs',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.matchPairs,
                questionText: 'Match English verbs with their Past Simple form:',
                matchingPairs: {
                  'go': 'went',
                  'buy': 'bought',
                  'see': 'saw',
                  'write': 'wrote',
                },
                explanation: 'These are common irregular verbs in English that must be memorized.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'e3',
            title: 'Modals of Ability',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: 'Which modal verb is used to show physical ability?',
                options: ['should', 'must', 'can', 'may'],
                correctString: 'can',
                explanation: '"Can" represents mental or physical ability in present tense.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'e4',
            title: 'English Chest',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: '"I have went to London twice" is a correct Present Perfect sentence.',
                correctString: 'Жалған',
                explanation: 'The third form of the verb "go" is "gone". The correct sentence is "I have gone to London twice".',
              ),
            ],
          ),
          CurriculumNode(
            id: 'e5',
            title: 'Grammar Arena',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'If it ___ tomorrow, we will stay at home.',
                options: ['rains', 'will rain', 'rain', 'rained'],
                correctIndex: 0,
                explanation: 'In conditional type 1, we use Present Simple in the if-clause: "If it rains".',
              ),
            ],
          ),
        ],
      ),
      Chapter(
        id: 'eng_c2',
        name: 'Chapter 2: Nouns, Articles & Pronouns',
        nodes: [
          CurriculumNode(
            id: 'e6',
            title: 'Definite vs Indefinite Articles',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'I bought ___ apple yesterday. ___ apple was delicious.',
                options: ['a / The', 'an / The', 'an / A', 'the / An'],
                correctIndex: 1,
                explanation: 'We use "an" for indefinite singular vowel sounds, and "the" when referring to it a second time.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'e7',
            title: 'Plural Exceptions',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: 'The plural form of "child" is "childrens". Is this statement true?',
                correctString: 'Жалған',
                explanation: 'The plural of "child" is "children". Adding "s" is a common error.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'e8',
            title: 'Relative Pronouns',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: 'The boy ___ is wearing a red hat is my brother.',
                options: ['which', 'who', 'whose', 'where'],
                correctString: 'who',
                explanation: 'We use "who" to refer to people in relative clauses.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'e9',
            title: 'Pronoun Chest',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Choose the correct plural form of the word "mouse":',
                options: ['mouses', 'mice', 'mices', 'mouse'],
                correctIndex: 1,
                explanation: 'The plural form of "mouse" is "mice". This is an irregular noun.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'e10',
            title: 'Nouns Final Boss',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Which of the following is an uncountable noun?',
                options: ['Apple', 'Water', 'Book', 'Chair'],
                correctIndex: 1,
                explanation: '"Water" is liquid and cannot be counted unless placed in containers.',
              ),
            ],
          ),
        ],
      ),
      Chapter(
        id: 'eng_c3',
        name: 'Chapter 3: Adjectives & Comparisons',
        nodes: [
          CurriculumNode(
            id: 'e11',
            title: 'Comparative Adjectives',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'This laptop is ___ than my old one.',
                options: ['fast', 'faster', 'more fast', 'fastest'],
                correctIndex: 1,
                explanation: 'For short 1-syllable adjectives we add -er: "faster".',
              ),
            ],
          ),
          CurriculumNode(
            id: 'e12',
            title: 'Irregular Adjectives',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: 'The comparative form of "bad" is "worse". Is this true?',
                correctString: 'Шындық',
                explanation: 'Good becomes better, bad becomes worse. These are irregular comparative forms.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'e13',
            title: 'Superlatives',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: 'Mount Everest is the ___ mountain in the world.',
                options: ['high', 'higher', 'highest', 'more high'],
                correctString: 'highest',
                explanation: 'For short adjectives, the superlative is formed by adding -est: "the highest".',
              ),
            ],
          ),
          CurriculumNode(
            id: 'e14',
            title: 'Adjectives Chest',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'What is the comparative form of "beautiful"?',
                options: ['beautifuler', 'more beautiful', 'most beautiful', 'less beautifuler'],
                correctIndex: 1,
                explanation: 'For long adjectives we use "more" + adjective: "more beautiful".',
              ),
            ],
          ),
          CurriculumNode(
            id: 'e15',
            title: 'Adjectives Final Boss',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Choose the correct superlative of "good":',
                options: ['goodest', 'better', 'best', 'most good'],
                correctIndex: 2,
                explanation: 'Good -> Better (Comparative) -> Best (Superlative).',
              ),
            ],
          ),
        ],
      ),
    ],
  ),

  // =========================================================================
  // 4. ФИЗИКА (⚛️)
  // =========================================================================
  const Subject(
    id: 'physics',
    name: 'Физика',
    icon: '⚛️',
    colorHex: '#9C27B0',
    chapters: [
      Chapter(
        id: 'phy_c1',
        name: '1-тарау: Кинематика және Динамика',
        nodes: [
          CurriculumNode(
            id: 'p1',
            title: 'Жылдамдық пен орын ауыстыру',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Орын ауыстыруды уақытқа бөлгенде қандай физикалық шама шығады?',
                options: ['Жол', 'Үдеу', 'Жылдамдық', 'Күш'],
                correctIndex: 2,
                explanation: 'Жылдамдық = Орын ауыстыру / Уақыт (v = s/t).',
              ),
            ],
          ),
          CurriculumNode(
            id: 'p2',
            title: 'Ньютонның екінші заңы',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: 'Ньютонның 2-заңы F=ma формуласымен жазылады. Бұл дұрыс па?',
                correctString: 'Шындық',
                explanation: 'Ньютонның екінші заңы бойынша денеге әсер ететін теңәсерлі күш оның массасы мен үдеуінің көбейтіндісіне тең.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'p3',
            title: 'Күш түрлері',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: 'Денелердің бір-біріне тартылу күші қалай аталады?',
                options: ['Бүкіләлемдік тартылыс күші', 'Серпімділік күші', 'Үйкеліс күші', 'Қысым күші'],
                correctString: 'Бүкіләлемдік тартылыс күші',
                explanation: 'Массалары бар кез келген екі дененің арасында тартылыс (гравитациялық) күші әрекет етеді.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'p4',
            title: 'Кинематика сандығы',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Еркін түсу үдеуінің мәні Жер бетінде шамамен қаншаға тең?',
                options: ['9.8 м/с²', '5.5 м/с²', '1.6 м/с²', '100 м/с²'],
                correctIndex: 0,
                explanation: 'Еркін түсу үдеуі (g) Жер бетінде ≈ 9.8 м/с² (немесе есептеулерде 10 м/с²).',
              ),
            ],
          ),
          CurriculumNode(
            id: 'p5',
            title: 'Динамика Аренасы',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Массасы 5 кг денеге 20 Н күш әсер етсе, ол қандай үдеумен қозғалады?',
                options: ['2 м/с²', '4 м/с²', '10 м/с²', '100 м/с²'],
                correctIndex: 1,
                explanation: 'a = F / m = 20 / 5 = 4 м/с².',
              ),
            ],
          ),
        ],
      ),
      Chapter(
        id: 'phy_c2',
        name: '2-тарау: Термодинамика және молекулалық физика',
        nodes: [
          CurriculumNode(
            id: 'p6',
            title: 'Жылу берілу түрлері',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.matchPairs,
                questionText: 'Терминдер мен сипаттамаларды сәйкестендіріңіз:',
                matchingPairs: {
                  'Жылуөткізгіштік': 'Бөлшектердің соқтығысуымен',
                  'Конвекция': 'Сұйық не газ ағынымен',
                  'Сәулелену': 'Электромагниттік толқынмен',
                  'Жылу мөлшері': 'Q шамасымен өлшенеді',
                },
                explanation: 'Бұл термодинамикадағы жылу алмасудың үш негізгі түрі мен сипаттамасы.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'p7',
            title: 'Агрегаттық күйлер ауысуы',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: 'Сұйықтықтың буға айналу процесі конденсация деп аталады.',
                correctString: 'Жалған',
                explanation: 'Буға айналу булану деп аталады. Ал будың сұйықтыққа айналуы - конденсация.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'p8',
            title: 'Абсолют нөл',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: 'Абсолют нөл температура Цельсий шкаласы бойынша неше градусқа тең?',
                options: ['0', '-100', '-273', '-373'],
                correctString: '-273',
                explanation: 'Кельвин шкаласының 0 К нүктесі Цельсий бойынша -273.15 °C-қа сәйкес келеді.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'p9',
            title: 'Жылулық сандықтар',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Меншікті жылу сыйымдылығының өлшем бірлігі қайсы?',
                options: ['Дж/кг', 'Дж/(кг·К)', 'Вт/м', 'Н/м'],
                correctIndex: 1,
                explanation: 'Меншікті жылу сыйымдылығы c = Q / (m·ΔT) болғандықтан, оның бірлігі Дж/(кг·К) немесе Дж/(кг·°C).',
              ),
            ],
          ),
          CurriculumNode(
            id: 'p10',
            title: 'Жылулық Арена',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Термодинамиканың бірінші заңы қандай заңның негізінде тұр?',
                options: ['Инерция заңы', 'Энергияның сақталу заңы', 'Архимед заңы', 'Паскаль заңы'],
                correctIndex: 1,
                explanation: 'Термодинамиканың бірінші заңы - жылулық процестер үшін энергияның сақталу және айналу заңы.',
              ),
            ],
          ),
        ],
      ),
      Chapter(
        id: 'phy_c3',
        name: '3-тарау: Электродинамика',
        nodes: [
          CurriculumNode(
            id: 'p11',
            title: 'Кулон заңы',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Электр зарядының өлшем бірлігі қандай?',
                options: ['Вольт', 'Ампер', 'Кулон', 'Ом'],
                correctIndex: 2,
                explanation: 'Электр заряды Кулонмен (Кл) өлшенеді.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'p12',
            title: 'Тізбек бөлігі үшін Ом заңы',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: 'Ом заңы бойынша ток күші кернеуге тура пропорционал, ал кедергіге кері пропорционал. Бұл тұжырым дұрыс па?',
                correctString: 'Шындық',
                explanation: 'I = U/R формулысы осы Ом заңын білдіреді.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'p13',
            title: 'Кедергілерді қосу',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: 'Тізбектей қосқан кезде жалпы кедергі қалай табылады?',
                options: ['Көбейтіндімен', 'Қосындымен', 'Бөліндімен', 'Кері мәндерімен'],
                correctString: 'Қосындымен',
                explanation: 'Кедергілерді тізбектей қосқан кезде олардың жалпы кедергісі R = R1 + R2 қосындысына тең болады.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'p14',
            title: 'Электрлік сандықтар',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Ток күшін өлшейтін құрал қалай аталады?',
                options: ['Вольтметр', 'Амперметр', 'Омметр', 'Барометр'],
                correctIndex: 1,
                explanation: 'Амперметр тізбекке тізбектей қосылып, ток күшін өлшейді.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'p15',
            title: 'Токтардың соңғы бекінісі',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Электр тогының қуаты қандай формуламен есептеледі?',
                options: ['P = UI', 'P = U/I', 'P = I/U', 'P = Fv'],
                correctIndex: 0,
                explanation: 'Қуат кернеу мен ток күшінің көбейтіндісіне тең (P = UI). Бірлігі - Ватт.',
              ),
            ],
          ),
        ],
      ),
    ],
  ),

  // =========================================================================
  // 5. ҚАЗАҚСТАН ТАРИХЫ (🏛️)
  // =========================================================================
  const Subject(
    id: 'history',
    name: 'Тарих',
    icon: '🏛️',
    colorHex: '#FFAB00',
    chapters: [
      Chapter(
        id: 'his_c1',
        name: '1-тарау: Сақ дәуірінен Қазақ хандығына дейін',
        nodes: [
          CurriculumNode(
            id: 'h1',
            title: 'Ежелгі Сақ тайпалары',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Сақ патшайымы Томиристің парсы патшасын жеңген шайқасы қай жылы болды?',
                options: ['Б.з.б. 530 ж', 'Б.з.б. 490 ж', 'Б.з.б. 328 ж', '530 ж'],
                correctIndex: 0,
                explanation: 'Б.з.б. 530 жылы Томирис сақтарды бастап парсы патшасы Кирді жеңді.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'h2',
            title: 'Алтын Адам құпиясы',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: 'Алтын адам Есік қорғанынан табылды. Бұл пікір дұрыс па?',
                correctString: 'Шындық',
                explanation: '1969 жылы Кемал Ақышев басқарған экспедиция Есік қорғанынан Алтын адамды тапты.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'h3',
            title: 'Ұлы қоныс аудару',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: 'Еуропаға жорық жасап, Ұлы қоныс аударуды қыздырған ғұн басшысы кім?',
                options: ['Аттила', 'Мөде', 'Білге қаған', 'Томирис'],
                correctString: 'Аттила',
                explanation: 'Еділ (Аттила) қаған ғұндарды бастап Еуропаға дейін барып, Римді сескендірді.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'h4',
            title: 'Қорғандар қазынасы',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Қазақстан аумағындағы алғашқы патриархалды мемлекеттік бірлестік:',
                options: ['Үйсіндер', 'Қаңлылар', 'Сақтар', 'Ғұндар'],
                correctIndex: 2,
                explanation: 'Сақ тайпалық одақтары ерте темір дәуірінде алғашқы ірі бірлестіктерді құрды.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'h5',
            title: 'Хандықтар Аренасы',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Қазақ хандығының негізін қалаған сұлтандар кімдер?',
                options: ['Керей мен Жәнібек', 'Қасым мен Хақназар', 'Әбілқайыр мен Абылай', 'Тәуке мен Есім'],
                correctIndex: 0,
                explanation: '1465 жылы Керей мен Жәнібек сұлтандар Шу өңірінде Қазақ хандығының туын тікті.',
              ),
            ],
          ),
        ],
      ),
      Chapter(
        id: 'his_c2',
        name: '2-тарау: Қазақ хандығы және Абылай хан дәуірі',
        nodes: [
          CurriculumNode(
            id: 'h6',
            title: 'Қасым ханның қасқа жолы',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Қазақ хандығының қуатын арттырып, заңдар жинағын шығарған Қасым ханның заңы қалай аталды?',
                options: ['Қасқа жолы', 'Ескі жолы', 'Жеті жарғы', 'Тура жолы'],
                correctIndex: 0,
                explanation: 'Қасым ханның тұсындағы заңдар жинағы «Қасым ханның қасқа жолы» деп аталады.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'h7',
            title: 'Есім ханның ескі жолы',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: '«Жеті жарғы» заңдар жинағы Тәуке ханның тұсында қабылданды.',
                correctString: 'Шындық',
                explanation: 'Тәуке хан үш жүздің билерін жинап, әйгілі «Жеті жарғы» заңдар жинағын бекітті.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'h8',
            title: 'Жоңғар шапқыншылығы',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: '1723 жылғы қазақ тарихындағы үлкен қасірет қалай аталады?',
                options: ['Ақтабан шұбырынды', 'Аңырақай шайқасы', 'Бұланты шайқасы', 'Қалмақ қырғыны'],
                correctString: 'Ақтабан шұбырынды',
                explanation: '1723 жылы жоңғарлар кенеттен шауып, қазақтар «Ақтабан шұбырынды, Алқакөл сұлама» апатына ұшырады.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'h9',
            title: 'Шайқастар сандығы',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Қазақ жасақтары жоңғарларды біржола талқандаған әйгілі шайқас:',
                options: ['Аңырақай шайқасы', 'Бұланты шайқасы', 'Ордабасы жиыны', 'Бұланты мен Аңырақай'],
                correctIndex: 3,
                explanation: 'Бұланты (1727 ж) және Аңырақай (1729 ж) шайқастары қазақтардың жоңғарларды жеңген ұлы шайқастары.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'h10',
            title: 'Абылай хан Аренасы',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Абылай ханның шын есімі кім болған?',
                options: ['Әбілмансұр', 'Сабалақ', 'Әбілқайыр', 'Жәнібек'],
                correctIndex: 0,
                explanation: 'Абылайдың жастық шақтағы есімі - Әбілмансұр. Сабалақ деп кейіннен лақап атпен атап кеткен.',
              ),
            ],
          ),
        ],
      ),
      Chapter(
        id: 'his_c3',
        name: '3-тарау: 20-ғасырдағы Қазақстан және Алаш Орда',
        nodes: [
          CurriculumNode(
            id: 'h11',
            title: 'Алаш қозғалысы',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: '1917 жылы құрылған ұлттық Алаш партиясының төрағасы кім болды?',
                options: ['Әлихан Бөкейханов', 'Ахмет Байтұрсынов', 'Міржақып Дулатов', 'Мұстафа Шоқай'],
                correctIndex: 0,
                explanation: 'Алаш үкіметі мен партиясының жетекшісі - Әлихан Бөкейханов.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'h12',
            title: 'Қазақ зиялылары',
            type: CurriculumNodeType.lesson,
            xpReward: 30, coinReward: 10, akylReward: 5,
            questions: [
              TaskQuestion(
                type: TaskType.trueFalse,
                questionText: '«Оян, қазақ!» өлеңдер жинағының авторы - Міржақып Дулатов.',
                correctString: 'Шындық',
                explanation: '1909 жылы Міржақып Дулатов халықты оятуға бағытталған «Оян, қазақ!» кітабын жарыққа шығарды.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'h13',
            title: 'Тұңғыш Конституция',
            type: CurriculumNodeType.quiz,
            xpReward: 35, coinReward: 12, akylReward: 6,
            questions: [
              TaskQuestion(
                type: TaskType.fillBlank,
                questionText: 'Тәуелсіз Қазақстанның қазіргі Конституциясы қай жылы қабылданды?',
                options: ['1991', '1993', '1995', '2000'],
                correctString: '1995',
                explanation: 'Конституция 1995 жылы 30 тамызда бүкілхалықтық референдумда қабылданды.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'h14',
            title: 'Тәуелсіздік сандықтары',
            type: CurriculumNodeType.treasure,
            xpReward: 80, coinReward: 50, akylReward: 15,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Қазақстан Республикасының тұңғыш теңгесі айналымға қай жылы енгізілді?',
                options: ['1991 ж', '1993 ж', '1995 ж', '1998 ж'],
                correctIndex: 1,
                explanation: 'Ұлттық валюта - Теңге 1993 жылы 15 қарашада ресми айналымға енді.',
              ),
            ],
          ),
          CurriculumNode(
            id: 'h15',
            title: 'Алаштың соңғы бекінісі',
            type: CurriculumNodeType.boss,
            xpReward: 100, coinReward: 40, akylReward: 25,
            questions: [
              TaskQuestion(
                type: TaskType.multipleChoice,
                questionText: 'Қазақ КСР-інің толық егемендігі туралы Декларация қай күні жарияланды?',
                options: ['1990 жылы 25 қазанда', '1991 жылы 16 желтоқсанда', '1993 жылы 28 қаңтарда', '1995 жылы 30 тамызда'],
                correctIndex: 0,
                explanation: '1990 жылы 25 қазанда Мемлекеттік егемендік туралы Декларация қабылданып, тәуелсіздікке жол ашылды.',
              ),
            ],
          ),
        ],
      ),
    ],
  ),
];
