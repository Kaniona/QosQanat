import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/constants.dart';
import '../models/assistant_kind.dart';
export '../models/assistant_kind.dart';
import '../models/friend.dart';
import '../models/game_models.dart';
import '../models/lesson_node.dart';
import '../models/shop_item.dart';
import '../content/shop_data.dart';
import '../models/student_profile.dart';
import '../../core/config/levels.dart';
import '../content/quiz_data.dart';

import '../models/curriculum.dart';

/// Central state store for QosQanat
class AppStore extends ChangeNotifier {
  AppStore(this._prefs);

  static const _stateKey = 'qos_qanat_state_v2';
  final SharedPreferences _prefs;

  StudentProfile? profile;
  AssistantKind assistant = AssistantKind.bektur;

  int wisdom = 120;
  int coins = 80;
  int exp = 45;
  int level = 1;
  int streak = 1;
  int completedTasks = 0;
  int todayTasks = 0;
  int todayBattles = 0;
  int todayMiniGames = 0;
  int battlesWon = 0;
  int correctStreak = 0;
  String lastLoginDay = AppConstants.dateKey(DateTime.now());

  final Set<int> completedLessons = <int>{};
  final Set<String> completedCurriculumNodes = <String>{};
  final Set<String> ownedItems = <String>{'base-jacket', 'base-pants'};
  final Set<String> equippedItems = <String>{'base-jacket', 'base-pants'};
  final Set<String> ownedPets = <String>{};
  final Set<String> ownedBackgrounds = <String>{'bg-default'};
  final List<Friend> friends = <Friend>[];
  final List<BattleResult> battleHistory = <BattleResult>[];
  final Set<String> unlockedAchievements = <String>{};
  String equippedBackground = 'bg-default';
  String? equippedPet;

  bool leveledUpThisSession = false;
  int previousLevel = 1;

  int get expForNextLevel => LevelConfig.xpRequiredForLevel(level);
  double get levelProgress => expForNextLevel == 0 ? 0 : exp / expForNextLevel;
  String get league => AppConstants.getLeague(wisdom);

  // ── FRIENDS FILTERING ───────────────────────────────────────────────────

  /// Friends with accepted status
  List<Friend> get acceptedFriends =>
      friends.where((f) => f.requestStatus == FriendRequestStatus.accepted).toList();

  /// Incoming friend requests (they sent to us)
  List<Friend> get incomingRequests =>
      friends.where((f) => f.requestStatus == FriendRequestStatus.pendingIncoming).toList();

  /// Outgoing friend requests (we sent to them)
  List<Friend> get outgoingRequests =>
      friends.where((f) => f.requestStatus == FriendRequestStatus.pendingOutgoing).toList();

  // ── FRIEND REQUEST MANAGEMENT ──────────────────────────────────────────

  /// Simulate searching for a user by QQ-ID (offline returns a random user)
  Friend? searchFriendByQqId(String qqId) {
    final n = qqId.trim().toUpperCase();
    if (!RegExp(r'^QQ-[0-9]{9}$').hasMatch(n)) return null;
    if (profile?.qqId == n) return null; // Can't add yourself

    // Check if already in friends list
    final existing = friends.cast<Friend?>().firstWhere(
      (f) => f!.qqId == n,
      orElse: () => null,
    );
    if (existing != null) return existing;

    // Simulate finding a user
    final r = Random();
    return Friend(
      qqId: n,
      name: AppConstants.randomName(),
      city: AppConstants.cities[r.nextInt(AppConstants.cities.length)],
      wisdom: 90 + r.nextInt(420),
      level: 1 + r.nextInt(15),
      isOnline: r.nextBool(),
      avatarEmoji: Friend.randomAvatarEmoji(),
      requestStatus: FriendRequestStatus.accepted, // Not yet in list
    );
  }

  /// Send a friend request (adds with pendingOutgoing status)
  bool sendFriendRequest(String qqId) {
    final n = qqId.trim().toUpperCase();
    if (!RegExp(r'^QQ-[0-9]{9}$').hasMatch(n)) return false;
    if (profile?.qqId == n || friends.any((f) => f.qqId == n)) return false;

    final r = Random();
    friends.add(Friend(
      qqId: n,
      name: AppConstants.randomName(),
      city: AppConstants.cities[r.nextInt(AppConstants.cities.length)],
      wisdom: 90 + r.nextInt(320),
      level: 1 + r.nextInt(12),
      isOnline: r.nextBool(),
      avatarEmoji: Friend.randomAvatarEmoji(),
      requestStatus: FriendRequestStatus.pendingOutgoing,
    ));

    // Simulate: after a short time, auto-accept (for offline demo)
    Future.delayed(const Duration(seconds: 5), () {
      final idx = friends.indexWhere((f) => f.qqId == n);
      if (idx != -1 && friends[idx].requestStatus == FriendRequestStatus.pendingOutgoing) {
        friends[idx] = friends[idx].copyWith(requestStatus: FriendRequestStatus.accepted);
        _commit();
      }
    });

    _commit();
    return true;
  }

  /// Send friend request with known friend data
  bool sendFriendRequestWithData(Friend friend) {
    if (profile?.qqId == friend.qqId || friends.any((f) => f.qqId == friend.qqId)) return false;

    friends.add(friend.copyWith(requestStatus: FriendRequestStatus.pendingOutgoing));

    // Simulate auto-accept for offline demo
    Future.delayed(const Duration(seconds: 5), () {
      final idx = friends.indexWhere((f) => f.qqId == friend.qqId);
      if (idx != -1 && friends[idx].requestStatus == FriendRequestStatus.pendingOutgoing) {
        friends[idx] = friends[idx].copyWith(requestStatus: FriendRequestStatus.accepted);
        _commit();
      }
    });

    _commit();
    return true;
  }

  /// Accept an incoming friend request
  bool acceptFriendRequest(String qqId) {
    final idx = friends.indexWhere(
      (f) => f.qqId == qqId && f.requestStatus == FriendRequestStatus.pendingIncoming,
    );
    if (idx == -1) return false;
    friends[idx] = friends[idx].copyWith(requestStatus: FriendRequestStatus.accepted);
    _commit();
    return true;
  }

  /// Decline / cancel a friend request
  bool declineFriendRequest(String qqId) {
    final idx = friends.indexWhere(
      (f) => f.qqId == qqId &&
          (f.requestStatus == FriendRequestStatus.pendingIncoming ||
           f.requestStatus == FriendRequestStatus.pendingOutgoing),
    );
    if (idx == -1) return false;
    friends.removeAt(idx);
    _commit();
    return true;
  }

  // ── BATTLE QUESTION GENERATION ─────────────────────────────────────────

  /// Generate N random battle questions from the quiz pool
  List<BattleQuestion> generateBattleQuestions(int count, {String? subject}) {
    var pool = battleQuestions.toList();

    // Filter by subject if specified
    if (subject != null && subject.isNotEmpty && subject != 'Барлық пәндер') {
      pool = pool.where((q) => q.subject == subject).toList();
    }

    // Shuffle and pick
    pool.shuffle(Random());

    // If pool is smaller than requested count, repeat questions
    final questions = <BattleQuestion>[];
    for (var i = 0; i < count; i++) {
      final q = pool[i % pool.length];
      questions.add(BattleQuestion(
        question: q.question,
        options: q.options,
        correctIndex: q.correctIndex,
        subject: q.subject,
      ));
    }
    return questions;
  }

  /// Create a LiveBattleState for an opponent
  LiveBattleState createBattleState(Friend opponent, int questionCount, {String? subject}) {
    return LiveBattleState(
      battleId: 'battle_${DateTime.now().millisecondsSinceEpoch}',
      questions: generateBattleQuestions(questionCount, subject: subject),
      opponentName: opponent.name,
      opponentEmoji: opponent.avatarEmoji,
      opponentLevel: opponent.level,
      opponentWisdom: opponent.wisdom,
    );
  }

  /// Finalize battle and apply rewards
  BattleResult finalizeBattle(LiveBattleState state) {
    final won = state.myScore > state.opponentScore;
    todayBattles++;

    if (won) {
      final akylReward = state.winnerAkylReward;
      wisdom += akylReward;
      exp += 14 + state.myTimeBonus;
      coins += 12 + (state.totalQuestions ~/ 5);
      battlesWon++;
      _levelUpIfNeeded();
    } else {
      wisdom += state.loserAkylReward;
      exp += 6;
    }

    final result = BattleResult(
      friendName: state.opponentName,
      myScore: state.myScore,
      friendScore: state.opponentScore,
      won: won,
      totalQuestions: state.totalQuestions,
    );
    battleHistory.insert(0, result);
    if (battleHistory.length > 20) battleHistory.removeLast();
    _checkAchievements();
    _commit();
    return result;
  }

  // ── LEGACY METHODS (preserved for compatibility) ───────────────────────

  Future<void> load() async {
    final raw = _prefs.getString(_stateKey);
    if (raw == null) return;
    final d = jsonDecode(raw) as Map<String, dynamic>;
    final profileData = d['profile'];
    if (profileData is Map<String, dynamic>) {
      profile = StudentProfile.fromJson(profileData);
    }
    assistant = AssistantKind.values.firstWhere(
      (e) => e.name == d['assistant'],
      orElse: () => AssistantKind.bektur,
    );
    wisdom = d['wisdom'] as int? ?? wisdom;
    coins = d['coins'] as int? ?? coins;
    exp = d['exp'] as int? ?? exp;
    level = d['level'] as int? ?? level;
    streak = d['streak'] as int? ?? streak;
    completedTasks = d['completedTasks'] as int? ?? completedTasks;
    todayTasks = d['todayTasks'] as int? ?? todayTasks;
    todayBattles = d['todayBattles'] as int? ?? todayBattles;
    todayMiniGames = d['todayMiniGames'] as int? ?? todayMiniGames;
    battlesWon = d['battlesWon'] as int? ?? battlesWon;
    correctStreak = d['correctStreak'] as int? ?? correctStreak;
    lastLoginDay = d['lastLoginDay'] as String? ?? lastLoginDay;
    equippedBackground = d['equippedBackground'] as String? ?? 'bg-default';
    equippedPet = d['equippedPet'] as String?;

    completedLessons..clear()..addAll((d['completedLessons'] as List? ?? []).whereType<int>());
    completedCurriculumNodes..clear()..addAll((d['completedCurriculumNodes'] as List? ?? []).whereType<String>());
    ownedItems..clear()..addAll((d['ownedItems'] as List? ?? ['base-jacket', 'base-pants']).whereType<String>());
    equippedItems..clear()..addAll((d['equippedItems'] as List? ?? ['base-jacket', 'base-pants']).whereType<String>());
    ownedPets..clear()..addAll((d['ownedPets'] as List? ?? []).whereType<String>());
    ownedBackgrounds..clear()..addAll((d['ownedBackgrounds'] as List? ?? ['bg-default']).whereType<String>());
    friends..clear()..addAll((d['friends'] as List? ?? []).whereType<Map<String, dynamic>>().map(Friend.fromJson));
    unlockedAchievements..clear()..addAll((d['achievements'] as List? ?? []).whereType<String>());
    battleHistory.clear();
    for (final h in (d['battleHistory'] as List? ?? [])) {
      if (h is Map<String, dynamic>) {
        battleHistory.add(BattleResult(
          friendName: h['friendName'] as String? ?? '',
          myScore: h['myScore'] as int? ?? 0,
          friendScore: h['friendScore'] as int? ?? 0,
          won: h['won'] as bool? ?? false,
          totalQuestions: h['totalQuestions'] as int? ?? 15,
        ));
      }
    }
    _applyDailyLogin();
  }

  void register({
    required String fullName,
    required String phone,
    required String iin,
    required String city,
    required String school,
    required AssistantKind selectedAssistant,
  }) {
    profile = StudentProfile(
      qqId: AppConstants.generateQqId(), fullName: fullName,
      phone: phone, iin: iin, city: city, school: school,
    );
    assistant = selectedAssistant;
    wisdom = 120; coins = 180; exp = 45; level = 1; streak = 1;
    completedTasks = 0; todayTasks = 0; todayBattles = 0;
    todayMiniGames = 0; battlesWon = 0; correctStreak = 0;
    lastLoginDay = AppConstants.dateKey(DateTime.now());
    completedLessons.clear();
    ownedItems..clear()..add('base-jacket');
    equippedItems..clear()..add('base-jacket');
    ownedPets.clear(); equippedPet = null;
    ownedBackgrounds..clear()..add('bg-default');
    equippedBackground = 'bg-default';
    friends..clear()..addAll(_starterFriends(city));
    battleHistory.clear(); unlockedAchievements.clear();
    _commit();
  }

  LessonReward completeLesson(LessonNode lesson) {
    if (completedLessons.contains(lesson.id)) {
      return const LessonReward(wisdom: 0, exp: 0, coins: 0, leveledUp: false);
    }
    completedLessons.add(lesson.id);
    wisdom += lesson.wisdomReward;
    exp += lesson.expReward;
    completedTasks++; todayTasks++; correctStreak++;
    int bonusCoins = 0;
    if (correctStreak >= 5) bonusCoins += 20;
    if (correctStreak >= 10) bonusCoins += 30;
    if (completedLessons.length % 5 == 0) bonusCoins += 50;
    if (lesson.isBoss) bonusCoins += 100;
    final beforeLevel = level;
    _levelUpIfNeeded();
    final levelUp = level > beforeLevel;
    final coinReward = (levelUp ? 60 : 0) + bonusCoins;
    coins += coinReward;
    _checkAchievements(); _commit();
    return LessonReward(wisdom: lesson.wisdomReward, exp: lesson.expReward, coins: coinReward, leveledUp: levelUp);
  }

  void recordWrongAnswer() { correctStreak = 0; exp += 2; _commit(); }

  bool buy(ShopItem item) {
    final Set<String> targetSet;
    if (item.category == 'Питомец') { targetSet = ownedPets; }
    else if (item.category == 'Фон') { targetSet = ownedBackgrounds; }
    else { targetSet = ownedItems; }
    if (targetSet.contains(item.id) || coins < item.price) return false;
    coins -= item.price; targetSet.add(item.id); _commit(); return true;
  }

  void equipItem(String id) {
    if (ownedItems.contains(id)) {
      final item = allShopItems.firstWhere(
        (x) => x.id == id,
        orElse: () => const ShopItem(id: '', name: '', category: '', price: 0, coinPrice: 0, description: '', unlockLevel: 1, previewImage: '', icon: Icons.error, color: Colors.transparent),
      );
      if (item.id.isEmpty) return;

      // Remove any equipped item in the same category slot
      equippedItems.removeWhere((equippedId) {
        final eqItem = allShopItems.firstWhere(
          (x) => x.id == equippedId,
          orElse: () => const ShopItem(id: '', name: '', category: '', price: 0, coinPrice: 0, description: '', unlockLevel: 1, previewImage: '', icon: Icons.error, color: Colors.transparent),
        );
        return eqItem.category == item.category;
      });

      if (id != 'no-hat' && id != 'no-accessory') {
        equippedItems.add(id);
      }
      _commit();
    }
  }

  void unequipItem(String id) {
    if (id != 'base-jacket' && id != 'base-pants') {
      equippedItems.remove(id);
      _commit();
    }
  }

  void equipPet(String id) {
    if (ownedPets.contains(id) || id == 'no-pet') {
      equippedPet = (id == 'no-pet') ? null : id;
      _commit();
    }
  }

  void equipBackground(String id) {
    if (ownedBackgrounds.contains(id)) {
      equippedBackground = id;
      _commit();
    }
  }

  bool addFriendById(String qqId) {
    final n = qqId.trim().toUpperCase();
    if (!RegExp(r'^QQ-[0-9]{9}$').hasMatch(n)) return false;
    if (profile?.qqId == n || friends.any((f) => f.qqId == n)) return false;
    final r = Random();
    friends.add(Friend(qqId: n, name: AppConstants.randomName(),
      city: AppConstants.cities[r.nextInt(AppConstants.cities.length)],
      wisdom: 90 + r.nextInt(320), level: 1 + r.nextInt(12), isOnline: r.nextBool(),
      avatarEmoji: Friend.randomAvatarEmoji()));
    _commit(); return true;
  }

  BattleResult startBattle(Friend friend, int questionCount) {
    final r = Random();
    final myC = (0.46 + wisdom / 1800).clamp(.46, .92);
    final fC = (0.40 + friend.wisdom / 1900).clamp(.40, .90);
    var my = 0, fr = 0;
    for (var i = 0; i < questionCount; i++) {
      if (r.nextDouble() < myC) my++;
      if (r.nextDouble() < fC) fr++;
    }
    if (my == fr) my++;
    final won = my > fr;
    todayBattles++;
    if (won) { wisdom += 8; exp += 14; coins += 12; battlesWon++; _levelUpIfNeeded(); } else { exp += 6; }
    final result = BattleResult(friendName: friend.name, myScore: min(my, questionCount),
      friendScore: min(fr, questionCount), won: won, totalQuestions: questionCount);
    battleHistory.insert(0, result);
    if (battleHistory.length > 20) battleHistory.removeLast();
    _checkAchievements(); _commit(); return result;
  }

  void rewardMiniGame({required bool correct}) {
    todayMiniGames++;
    if (correct) { wisdom += 3; exp += 7; correctStreak++; _levelUpIfNeeded(); }
    else { exp += 2; correctStreak = 0; }
    _commit();
  }

  void resetProfile() { profile = null; unawaited(_prefs.remove(_stateKey)); notifyListeners(); }

  Map<String, dynamic> toJson() => {
    'profile': profile?.toJson(), 'assistant': assistant.name,
    'wisdom': wisdom, 'coins': coins, 'exp': exp, 'level': level,
    'streak': streak, 'completedTasks': completedTasks,
    'todayTasks': todayTasks, 'todayBattles': todayBattles,
    'todayMiniGames': todayMiniGames, 'battlesWon': battlesWon,
    'correctStreak': correctStreak, 'lastLoginDay': lastLoginDay,
    'completedLessons': completedLessons.toList(),
    'completedCurriculumNodes': completedCurriculumNodes.toList(),
    'ownedItems': ownedItems.toList(), 'equippedItems': equippedItems.toList(),
    'ownedPets': ownedPets.toList(), 'ownedBackgrounds': ownedBackgrounds.toList(),
    'equippedBackground': equippedBackground, 'equippedPet': equippedPet,
    'friends': friends.map((f) => f.toJson()).toList(),
    'achievements': unlockedAchievements.toList(),
    'battleHistory': battleHistory.map((b) => {
      'friendName': b.friendName, 'myScore': b.myScore,
      'friendScore': b.friendScore, 'won': b.won, 'totalQuestions': b.totalQuestions,
    }).toList(),
  };

  Future<void> save() async { await _prefs.setString(_stateKey, jsonEncode(toJson())); }

  void addXP(int amount) {
    exp += amount;
    _levelUpIfNeeded();
    _commit();
  }

  void addCoins(int amount) {
    coins += amount;
    _commit();
  }

  void addAkylPoints(int amount) {
    wisdom += amount;
    _checkAchievements();
    _commit();
  }

  void checkStreak() {
    _applyDailyLogin();
    _commit();
  }

  void completeQuest(String questId, int coinReward, int xpReward) {
    addCoins(coinReward);
    addXP(xpReward);
  }

  LessonReward completeCurriculumNode(CurriculumNode node) {
    if (completedCurriculumNodes.contains(node.id)) {
      return const LessonReward(wisdom: 0, exp: 0, coins: 0, leveledUp: false);
    }
    completedCurriculumNodes.add(node.id);
    wisdom += node.akylReward;
    exp += node.xpReward;
    completedTasks++; todayTasks++; correctStreak++;

    int bonusCoins = 0;
    if (correctStreak >= 5) bonusCoins += 20;
    if (correctStreak >= 10) bonusCoins += 30;
    if (completedCurriculumNodes.length % 5 == 0) bonusCoins += 50;
    if (node.type == CurriculumNodeType.boss) bonusCoins += 100;
    if (node.type == CurriculumNodeType.treasure) bonusCoins += 150;

    final beforeLevel = level;
    _levelUpIfNeeded();
    final levelUp = level > beforeLevel;
    final coinReward = node.coinReward + (levelUp ? 60 : 0) + bonusCoins;
    coins += coinReward;

    _checkAchievements();
    _commit();

    return LessonReward(
      wisdom: node.akylReward,
      exp: node.xpReward,
      coins: coinReward,
      leveledUp: levelUp,
    );
  }

  void _levelUpIfNeeded() {
    final beforeLevel = level;
    while (exp >= expForNextLevel) {
      exp -= expForNextLevel;
      level++;
      coins += LevelConfig.coinsRewardForLevel(level);
    }
    if (level > beforeLevel) {
      previousLevel = beforeLevel;
      leveledUpThisSession = true;
    }
  }

  void _applyDailyLogin() {
    final today = DateTime.now();
    final todayKey = AppConstants.dateKey(today);
    if (lastLoginDay == todayKey || profile == null) return;
    final previous = DateTime.tryParse(lastLoginDay);
    if (previous != null && today.difference(previous).inDays == 1) { streak++; } else { streak = 1; }
    todayTasks = 0; todayBattles = 0; todayMiniGames = 0;
    lastLoginDay = todayKey;
    if (streak == 3) coins += 50;
    if (streak == 7) coins += 100;
    if (streak == 14) coins += 200;
    if (streak == 30) coins += 500;
    unawaited(save());
  }

  void _checkAchievements() {
    final acceptedFriendsCount = friends.where((f) => f.requestStatus == FriendRequestStatus.accepted).length;
    final totalTasks = completedLessons.length + completedCurriculumNodes.length;

    final checks = <String, bool>{
      'first-task': totalTasks >= 1,
      'ten-tasks': totalTasks >= 10,
      'first-battle': battlesWon >= 1,
      'ten-battles': battlesWon >= 10,
      'five-friends': acceptedFriendsCount >= 5,
      'streak-7': streak >= 7,
      'rich-1000': coins >= 1000,
      'level-10': level >= 10,
      'all-subjects': totalTasks >= 8,
    };
    for (final e in checks.entries) {
      if (e.value) unlockedAchievements.add(e.key);
    }
  }

  void _commit() { unawaited(save()); notifyListeners(); }
}

List<Friend> _starterFriends(String city) => [
  Friend(qqId: AppConstants.generateQqId(), name: 'Айзере', city: city, wisdom: 210, level: 3, isOnline: true, avatarEmoji: '👧'),
  Friend(qqId: AppConstants.generateQqId(), name: 'Ерасыл', city: 'Астана', wisdom: 260, level: 4, isOnline: false, avatarEmoji: '👦'),
  Friend(qqId: AppConstants.generateQqId(), name: 'Медина', city: 'Алматы', wisdom: 180, level: 2, isOnline: true, avatarEmoji: '🧑‍🎓'),
  // Simulated incoming requests for demo
  Friend(qqId: AppConstants.generateQqId(), name: 'Дәмір', city: 'Шымкент', wisdom: 150, level: 2, isOnline: true, avatarEmoji: '🦸', requestStatus: FriendRequestStatus.pendingIncoming),
  Friend(qqId: AppConstants.generateQqId(), name: 'Томирис', city: 'Тараз', wisdom: 310, level: 5, isOnline: false, avatarEmoji: '🦹', requestStatus: FriendRequestStatus.pendingIncoming),
];
