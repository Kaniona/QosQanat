import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'core/theme/app_theme.dart';
import 'data/store/app_store.dart';
import 'screens/splash/splash_screen.dart';
import 'services/supabase_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Supabase (non-blocking — app works offline if this fails)
  await SupabaseService.instance.initialize();

  final prefs = await SharedPreferences.getInstance();
  final store = AppStore(prefs);
  await store.load();
  runApp(QosQanatApp(store: store));
}

class QosQanatApp extends StatelessWidget {
  const QosQanatApp({required this.store, super.key});

  final AppStore store;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'QosQanat',
          theme: AppTheme.dark, // Premium dark-first gaming theme
          darkTheme: AppTheme.dark,
          themeMode: ThemeMode.dark,
          home: SplashScreen(store: store),
        );
      },
    );
  }
}
