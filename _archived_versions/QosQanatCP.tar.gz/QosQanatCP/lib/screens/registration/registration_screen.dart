import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/constants.dart';
import '../../core/theme/design_system.dart';
import '../../data/models/assistant_kind.dart';
import '../../data/store/app_store.dart';
import '../../widgets/avatar/avatar_selector.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';
import '../../widgets/particle_background.dart';
import '../shell/shell_screen.dart';

/// Complete, world-class multi-step onboarding and registration flow
/// Steps:
/// 0. Welcome Splash (Greetings, taglines, start trigger)
/// 1. Personal Form (IIN check, city dropdown, school name, animated progress)
/// 2. Assistant Selection (Bektur/Nazym choice, custom celebration confetti explosion)
class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({required this.store, super.key});

  final AppStore store;

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen>
    with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  int _currentStep = 0;

  // Form states
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _iinController = TextEditingController();
  final _cityController = TextEditingController();
  final _schoolController = TextEditingController();

  AssistantKind _selectedAssistant = AssistantKind.bektur;

  // Confetti particles states
  late AnimationController _confettiController;
  bool _isCelebrating = false;
  final List<_ConfettiParticle> _particles = [];
  final Random _random = Random();

  @override
  void initState() {
    super.initState();

    _confettiController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..addStatusListener((status) {
        if (status == AnimationStatus.completed) {
          setState(() {
            _isCelebrating = false;
          });
          // Complete Registration!
          widget.store.register(
            fullName: _fullNameController.text.trim(),
            phone: _phoneController.text.trim(),
            iin: _iinController.text.trim(),
            city: _cityController.text.trim(),
            school: _schoolController.text.trim(),
            selectedAssistant: _selectedAssistant,
          );
        }
      });
  }

  void _generateConfetti() {
    _particles.clear();
    final colors = [
      DesignSystem.kazakhGold,
      DesignSystem.kazakhSkyBlue,
      Colors.pinkAccent,
      Colors.greenAccent,
      Colors.purpleAccent,
      Colors.orangeAccent,
    ];

    for (int i = 0; i < 70; i++) {
      final angle = _random.nextDouble() * pi * 2;
      final speed = 50.0 + _random.nextDouble() * 180.0;
      _particles.add(_ConfettiParticle(
        color: colors[_random.nextInt(colors.length)],
        angle: angle,
        speed: speed,
        size: 6.0 + _random.nextDouble() * 8.0,
        rotationSpeed: _random.nextDouble() * 4.0 + 1.0,
      ));
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    _fullNameController.dispose();
    _phoneController.dispose();
    _iinController.dispose();
    _cityController.dispose();
    _schoolController.dispose();
    _confettiController.dispose();
    super.dispose();
  }

  void _nextStep() {
    if (_currentStep == 0) {
      _animateToPage(1);
    } else if (_currentStep == 1) {
      if (_formKey.currentState!.validate()) {
        _animateToPage(2);
      }
    }
  }

  void _prevStep() {
    if (_currentStep > 0) {
      _animateToPage(_currentStep - 1);
    }
  }

  void _animateToPage(int page) {
    setState(() {
      _currentStep = page;
    });
    _pageController.animateToPage(
      page,
      duration: DesignSystem.durationStandard,
      curve: DesignSystem.smoothCurve,
    );
  }

  void _confirmSelection() {
    _generateConfetti();
    setState(() {
      _isCelebrating = true;
    });
    _confettiController.reset();
    _confettiController.forward();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DesignSystem.kazakhDeepBlue,
      body: ParticleBackground(
        child: SafeArea(
          child: Stack(
            children: [
              Column(
                children: [
                  const SizedBox(height: 16),
                  if (_currentStep > 0) _buildProgressBar(),
                  Expanded(
                    child: PageView(
                      controller: _pageController,
                      physics: const NeverScrollableScrollPhysics(),
                      children: [
                        _buildStepWelcome(),
                        _buildStepForm(),
                        _buildStepAssistant(),
                      ],
                    ),
                  ),
                ],
              ),

              // Confetti overlays
              if (_isCelebrating)
                Positioned.fill(
                  child: IgnorePointer(
                    child: AnimatedBuilder(
                      animation: _confettiController,
                      builder: (context, child) {
                        return CustomPaint(
                          painter: _ConfettiPainter(
                            particles: _particles,
                            progress: _confettiController.value,
                          ),
                        );
                      },
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ───────────────────────────────────────────────────────────────────────────
  // UI STEP BUILDERS
  // ───────────────────────────────────────────────────────────────────────────

  Widget _buildProgressBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                _currentStep == 1 ? '1 / 2: Жеке деректер 📝' : '2 / 2: Ассистент таңдау 🪽',
                style: DesignSystem.labelMedium.copyWith(color: DesignSystem.steppeSilver),
              ),
              Text(
                '${(_currentStep * 50)}%',
                style: DesignSystem.labelMedium.copyWith(color: DesignSystem.kazakhSkyBlue, fontWeight: FontWeight.w900),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Container(
              height: 6,
              color: DesignSystem.kazakhDeepBlue,
              child: Stack(
                children: [
                  AnimatedFractionallySizedBox(
                    duration: DesignSystem.durationStandard,
                    curve: DesignSystem.smoothCurve,
                    widthFactor: _currentStep == 1 ? 0.5 : 1.0,
                    child: Container(
                      decoration: const BoxDecoration(
                        gradient: DesignSystem.kazakhFlagGradient,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepWelcome() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Glowing winged Shanyrak icon
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: DesignSystem.kazakhSkyBlue.withValues(alpha: 0.15),
                shape: BoxShape.circle,
                border: Border.all(color: DesignSystem.kazakhSkyBlue, width: 2),
                boxShadow: DesignSystem.neonBlueGlow,
              ),
              child: const Icon(
                Icons.school,
                color: DesignSystem.kazakhSkyBlue,
                size: 72,
              ),
            ),
            const SizedBox(height: 32),
            Text(
              AppConstants.appName,
              style: DesignSystem.displayLarge.copyWith(fontSize: 48, letterSpacing: -1.0),
            ),
            const SizedBox(height: 8),
            Text(
              AppConstants.tagline,
              textAlign: TextAlign.center,
              style: DesignSystem.bodyMedium.copyWith(
                color: DesignSystem.steppeSilver,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 48),
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 300),
              child: GlowButton(
                label: 'Бастау 🪽',
                color: DesignSystem.kazakhSkyBlue,
                glowColor: DesignSystem.kazakhSkyBlue.withValues(alpha: 0.4),
                onPressed: _nextStep,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepForm() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: Column(
            children: [
              GlassCard(
                borderGradient: DesignSystem.kazakhFlagGradient,
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Жеке тіркелу картасы',
                        style: DesignSystem.headingLarge.copyWith(fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Деректеріңізді толтырып, оқу саяхатыңызды реттеңіз.',
                        style: DesignSystem.bodySmall,
                      ),
                      const SizedBox(height: 20),
                      _buildTextField(
                        controller: _fullNameController,
                        label: 'Аты-жөніңіз (Толық)',
                        icon: Icons.person_outline,
                      ),
                      const SizedBox(height: 12),
                      _buildTextField(
                        controller: _phoneController,
                        label: 'Телефон нөміріңіз',
                        icon: Icons.phone_android_outlined,
                        keyboardType: TextInputType.phone,
                      ),
                      const SizedBox(height: 12),
                      _buildTextField(
                        controller: _iinController,
                        label: 'ЖСН (12 сан)',
                        icon: Icons.badge_outlined,
                        keyboardType: TextInputType.number,
                        validator: (v) {
                          final text = v?.trim() ?? '';
                          if (!RegExp(r'^[0-9]{12}$').hasMatch(text)) {
                            return 'ЖСН 12 саннан тұруы қажет';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 12),
                      _buildDropdownCity(),
                      const SizedBox(height: 12),
                      _buildTextField(
                        controller: _schoolController,
                        label: 'Мектебіңіз (мысалы: №178 лицей)',
                        icon: Icons.apartment_outlined,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _prevStep,
                      child: const Text('Артқа'),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: GlowButton(
                      label: 'Жалғастыру ➡️',
                      color: DesignSystem.kazakhSkyBlue,
                      onPressed: _nextStep,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStepAssistant() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 700),
          child: Column(
            children: [
              Text(
                'Ақылды ассистент таңдау 🪽',
                style: DesignSystem.displayMedium.copyWith(fontSize: 24, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 6),
              Text(
                'Ассистент оқу барысында сізге жол көрсетіп, көмектеседі.',
                style: DesignSystem.bodySmall,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              AvatarSelector(
                selectedAssistant: _selectedAssistant,
                onChanged: (kind) {
                  setState(() {
                    _selectedAssistant = kind;
                  });
                },
              ),
              const SizedBox(height: 32),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _prevStep,
                      child: const Text('Артқа'),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: TweenAnimationBuilder<double>(
                      tween: Tween<double>(begin: 0.0, end: 1.0),
                      duration: DesignSystem.durationSpring,
                      builder: (context, scale, child) {
                        return Transform.scale(
                          scale: scale,
                          child: GlowButton(
                            label: 'Таңдадым! 🪽',
                            color: DesignSystem.kazakhGold,
                            glowColor: DesignSystem.kazakhGold.withValues(alpha: 0.4),
                            onPressed: _confirmSelection,
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      style: DesignSystem.bodyLarge.copyWith(color: Colors.white),
      validator: validator ??
          (v) => (v ?? '').trim().isEmpty ? 'Осы өрісті толтырыңыз' : null,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
      ),
    );
  }

  Widget _buildDropdownCity() {
    return DropdownButtonFormField<String>(
      value: _cityController.text.isEmpty ? null : _cityController.text,
      decoration: const InputDecoration(
        labelText: 'Қала немесе облыс',
        prefixIcon: Icon(Icons.location_city_outlined),
      ),
      style: DesignSystem.bodyLarge.copyWith(color: Colors.white),
      validator: (v) => v == null ? 'Қаланы таңдаңыз' : null,
      items: AppConstants.cities.map((city) {
        return DropdownMenuItem(
          value: city,
          child: Text(
            city,
            style: const TextStyle(color: Colors.white),
          ),
        );
      }).toList(),
      onChanged: (v) {
        setState(() {
          _cityController.text = v ?? '';
        });
      },
    );
  }
}

// ───────────────────────────────────────────────────────────────────────────
// CUSTOM LIGHTWEIGHT CONFETTI PARTICLE EMITTER
// ───────────────────────────────────────────────────────────────────────────

class _ConfettiParticle {
  _ConfettiParticle({
    required this.color,
    required this.angle,
    required this.speed,
    required this.size,
    required this.rotationSpeed,
  });

  final Color color;
  final double angle;
  final double speed;
  final double size;
  final double rotationSpeed;
}

class _ConfettiPainter extends CustomPainter {
  _ConfettiPainter({required this.particles, required this.progress});

  final List<_ConfettiParticle> particles;
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height * 0.7);

    for (final p in particles) {
      final double distance = p.speed * progress;
      // Parabolic path with gravity pulling particles down
      final double gravityOffset = 240.0 * progress * progress;

      final double x = center.dx + cos(p.angle) * distance;
      final double y = center.dy + sin(p.angle) * distance + gravityOffset;

      if (x < 0 || x > size.width || y > size.height) continue;

      final paint = Paint()
        ..color = p.color.withValues(alpha: (1.0 - progress).clamp(0.0, 1.0))
        ..style = PaintingStyle.fill;

      // Draw rotating confetti rectangles
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(progress * pi * p.rotationSpeed);

      final rect = Rect.fromCenter(
        center: Offset.zero,
        width: p.size,
        height: p.size * 0.6,
      );

      // Randomly draw squares or circles
      if (p.size.toInt() % 2 == 0) {
        canvas.drawRect(rect, paint);
      } else {
        canvas.drawOval(rect, paint);
      }
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
