import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/store/app_store.dart';
import '../../data/content/quests_data.dart';
import '../../data/models/game_models.dart';
import '../../widgets/animated_counter.dart';
import '../../widgets/app_page.dart';
import '../../widgets/assistant_avatar.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';
import '../../widgets/xp_bar.dart';
import '../rating/rating_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    required this.store,
    required this.onNavigate,
    super.key,
  });

  final AppStore store;
  final ValueChanged<int> onNavigate;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    // Looping idle animation for assistant avatar pulse
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.96, end: 1.04).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  String _getTimeGreeting() {
    final hour = DateTime.now().hour;
    if (hour >= 5 && hour < 12) {
      return 'Қайырлы таң';
    } else if (hour >= 12 && hour < 18) {
      return 'Қайырлы күн';
    } else {
      return 'Кеш жарық';
    }
  }

  @override
  Widget build(BuildContext context) {
    final profile = widget.store.profile!;
    final firstName = profile.fullName.split(' ').first;
    final color = widget.store.assistant.color;
    final quests = QuestsData.getActiveQuests(widget.store);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AppPage(
        title: '${_getTimeGreeting()}, $firstName! 🪽',
        subtitle: 'Бүгін ${widget.store.assistant.displayName} сенімен бірге білім шыңына саяхаттайды.',
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. Premium Top Stats Bar
              _buildTopStatsBar(),
              const SizedBox(height: 16),

              // 2. Animated Floating Assistant Avatar Card
              _buildAssistantCard(context, color),
              const SizedBox(height: 16),

              // 3. Quick Action Buttons Row
              _buildQuickActionsRow(context, color),
              const SizedBox(height: 20),

              // 4. Daily Quests Title & Horizontal Scroll Cards
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Күнделікті квесттер 🎯', style: AppTypography.headingMedium),
                  Text(
                    '${quests.where((q) => q.complete).length}/${quests.length} аяқталды',
                    style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              _buildHorizontalQuests(quests),
              const SizedBox(height: 20),

              // 5. Recent Activity Feed
              const Text('Соңғы әрекеттер 📜', style: AppTypography.headingMedium),
              const SizedBox(height: 8),
              _buildActivityFeed(),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopStatsBar() {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatsItem('Тиын', '${widget.store.coins}', '🪙', AppColors.coin),
              Container(width: 1, height: 30, color: AppColors.glassBorder),
              _buildStatsItem('Ақыл', '${widget.store.wisdom}', '💎', AppColors.wisdom),
              Container(width: 1, height: 30, color: AppColors.glassBorder),
              _buildStatsItem('Деңгей', 'Lvl ${widget.store.level}', '⭐', AppColors.exp),
              Container(width: 1, height: 30, color: AppColors.glassBorder),
              _buildStatsItem('Streak', '${widget.store.streak} күн', '🔥', AppColors.warning),
            ],
          ),
          const SizedBox(height: 10),
          XPBar(
            currentXp: widget.store.exp,
            xpForNextLevel: widget.store.expForNextLevel,
            level: widget.store.level,
          ),
        ],
      ),
    );
  }

  Widget _buildStatsItem(String label, String value, String emoji, Color accentColor) {
    return Column(
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 14)),
            const SizedBox(width: 4),
            Text(
              value,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                color: Colors.white,
              ),
            ),
          ],
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: AppTypography.bodySmall.copyWith(fontSize: 9),
        ),
      ],
    );
  }

  Widget _buildAssistantCard(BuildContext context, Color color) {
    return GlassCard(
      borderGradient: widget.store.assistant.gradient,
      child: Row(
        children: [
          // Clicking assistant triggers greeting bubble
          GestureDetector(
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(widget.store.assistant.greeting),
                  backgroundColor: color,
                  duration: const Duration(seconds: 3),
                ),
              );
            },
            child: ScaleTransition(
              scale: _pulseAnimation,
              child: AssistantAvatar(
                assistant: widget.store.assistant,
                size: 110,
                equippedItems: widget.store.equippedItems,
                equippedPet: widget.store.equippedPet,
                equippedBackground: widget.store.equippedBackground,
                mood: widget.store.correctStreak >= 4 ? 'celebrating' : 'happy',
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${widget.store.assistant.displayName}: Дайынбыз! ⚡',
                  style: AppTypography.headingMedium.copyWith(color: color, fontSize: 16),
                ),
                const SizedBox(height: 4),
                Text(
                  'Білім картасынан өтіп, Ақыл ұпайын жина және Aqyl Battle-да достарыңды жең!',
                  style: AppTypography.bodySmall.copyWith(color: Colors.white70, fontSize: 11),
                ),
                const SizedBox(height: 10),
                // Daily Streak Indicator Card
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.warning.withValues(alpha: .12),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.warning.withValues(alpha: .3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('🔥 ', style: TextStyle(fontSize: 12)),
                      Text(
                        'Жалғасқан күндер: ${widget.store.streak} күн',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: AppColors.warning,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionsRow(BuildContext context, Color color) {
    return Row(
      children: [
        // 1. Оқу бастау (Navigate to Study tab - index 2)
        Expanded(
          child: GlowButton(
            label: 'Оқу бастау 🗺️',
            height: 46,
            borderRadius: 12,
            color: color,
            onPressed: () => widget.onNavigate(2),
          ),
        ),
        const SizedBox(width: 8),
        // 2. Батл (Navigate to Friends tab - index 3)
        Expanded(
          child: GlowButton(
            label: 'Батл ⚔️',
            height: 46,
            borderRadius: 12,
            color: AppColors.neonMagenta,
            onPressed: () => widget.onNavigate(3),
          ),
        ),
        const SizedBox(width: 8),
        // 3. Рейтинг (Navigates to Rating Screen - index 5 in shell routing)
        Expanded(
          child: GlowButton(
            label: 'Рейтинг 🏆',
            height: 46,
            borderRadius: 12,
            color: AppColors.neonGold,
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => RatingScreen(store: widget.store),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildHorizontalQuests(List<Quest> quests) {
    if (quests.isEmpty) {
      return const SizedBox(
        height: 80,
        child: Center(
          child: Text('Бүгінгі квесттер орындалды! 🎉'),
        ),
      );
    }

    return SizedBox(
      height: 96,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: quests.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final q = quests[index];
          final completed = q.complete;

          return Container(
            width: 200,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: completed
                  ? AppColors.success.withValues(alpha: .08)
                  : AppColors.bgDarkCard,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: completed ? AppColors.success : AppColors.glassBorder,
                width: completed ? 1.5 : 0.8,
              ),
            ),
            child: Row(
              children: [
                // Icon circle
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: completed
                        ? AppColors.success.withValues(alpha: .2)
                        : AppColors.bgDarkSurface,
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(q.icon, style: const TextStyle(fontSize: 16)),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        q.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: completed ? AppColors.success : Colors.white,
                          decoration: completed ? TextDecoration.lineThrough : null,
                        ),
                      ),
                      const SizedBox(height: 4),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(3),
                        child: LinearProgressIndicator(
                          value: q.percentage,
                          minHeight: 4,
                          backgroundColor: AppColors.bgDarkSurface,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            completed ? AppColors.success : AppColors.neonGold,
                          ),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '${q.progress}/${q.total}',
                            style: AppTypography.bodySmall.copyWith(fontSize: 9),
                          ),
                          Text(
                            q.reward,
                            style: TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.w900,
                              color: AppColors.coin,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildActivityFeed() {
    final logs = [
      _ActivityLog('Тапсырма аяқталды!', 'Математика: Сандар сырынан өттің.', '📚', '10 мин бұрын', AppColors.neonCyan),
      _ActivityLog('Aqyl Battle жеңісі! 🏆', 'Айзерені жеңіп, +2x Ақыл ұпайын алдың.', '⚔️', '2 сағ бұрын', AppColors.neonMagenta),
      _ActivityLog('Жаңа киім сатып алынды!', 'Дүкеннен ассистентке тәж алдың.', '👑', 'Кеше', AppColors.neonGold),
    ];

    return GlassCard(
      child: Column(
        children: List.generate(logs.length, (index) {
          final log = logs[index];
          return Padding(
            padding: EdgeInsets.only(bottom: index == logs.length - 1 ? 0 : 12),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: log.color.withValues(alpha: .12),
                    shape: BoxShape.circle,
                  ),
                  child: Text(log.emoji, style: const TextStyle(fontSize: 16)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        log.title,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.white),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        log.desc,
                        style: AppTypography.bodySmall.copyWith(fontSize: 10),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  log.time,
                  style: AppTypography.bodySmall.copyWith(fontSize: 9, color: AppColors.textMuted),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

class _ActivityLog {
  _ActivityLog(this.title, this.desc, this.emoji, this.time, this.color);
  final String title;
  final String desc;
  final String emoji;
  final String time;
  final Color color;
}
