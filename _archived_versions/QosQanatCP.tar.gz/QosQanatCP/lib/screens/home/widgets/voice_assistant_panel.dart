import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../data/store/app_store.dart';
import '../../../services/voice_service.dart';
import '../../../widgets/glass_card.dart';
import '../../../widgets/glow_button.dart';

class VoiceAssistantPanel extends StatefulWidget {
  const VoiceAssistantPanel({
    required this.store,
    required this.onNavigate,
    super.key,
  });

  final AppStore store;
  final ValueChanged<int> onNavigate;

  @override
  State<VoiceAssistantPanel> createState() => _VoiceAssistantPanelState();
}

class _VoiceAssistantPanelState extends State<VoiceAssistantPanel> {
  final VoiceService _voice = VoiceService.instance;
  bool _isListening = false;
  String _voiceText = 'Ассистентпен сөйлесу үшін сұрақ белгісін немесе микрофонды басыңыз...';
  String _assistantReply = 'Ассистент жауабы осында көрсетіледі...';

  @override
  void initState() {
    super.initState();
    _voice.init();
  }

  void _speakIntroduction() {
    final reply = widget.store.assistant.greeting;
    setState(() => _assistantReply = reply);
    _voice.speak(reply);
  }

  void _processVoiceInput(String text) {
    final clean = text.toLowerCase();
    String reply = '';
    int? navigateTarget;

    if (clean.contains('карта') || clean.contains('оқу') || clean.contains('сабақ')) {
      reply = 'Жарайды! Білім картасын ашамын. Қанатты қағып оқуға кірісейік!';
      navigateTarget = 2;
    } else if (clean.contains('дүкен') || clean.contains('shop') || clean.contains('киім')) {
      reply = 'Керемет! Дүкен бөлімін ашамын. Кейіпкеріңізді безендіріңіз!';
      navigateTarget = 3;
    } else if (clean.contains('рейтинг') || clean.contains('лига') || clean.contains('көшбасшы')) {
      reply = 'Талпынысыңыз жақсы! Көшбасшылар тізімін ашамын.';
      navigateTarget = 1;
    } else if (clean.contains('дос') || clean.contains('батл') || clean.contains('battle')) {
      reply = 'Достар мен Ақыл батл бөлімі ашылды. Батлға дайынсыз ба?';
      navigateTarget = 4;
    } else if (clean.contains('профиль') || clean.contains('жеке') || clean.contains('менің')) {
      reply = 'Сіздің профиліңізді ашамын. Жетістіктеріңіз керемет!';
      navigateTarget = 5;
    } else if (clean.contains('ойын') || clean.contains('мини') || clean.contains('game')) {
      reply = 'Мини ойындар бөлімі ашылды. Миымызды жаттықтырайық!';
      navigateTarget = 6;
    } else if (clean.contains('youtube') || clean.contains('ютуб')) {
      reply = 'Қазақша білімдік YouTube каналды сыртқы браузерде ашамын...';
      _launchUrl('https://www.youtube.com');
    } else if (clean.contains('whatsapp') || clean.contains('ватсап')) {
      reply = 'Мұғалімнің қолдау көрсету нөмірін ашамын...';
      _launchUrl('https://wa.me/77000000000');
    } else {
      reply = 'Түсінбедім, бірақ жақсы талпыныс! Екі қанатты бірге қағайық: "Карта", "Shop", "Рейтинг", "Достар" немесе "Ойындар" деп айтып көріңіз.';
    }

    setState(() {
      _voiceText = 'Айтылған команда: "$text"';
      _assistantReply = reply;
    });

    _voice.speak(reply);

    if (navigateTarget != null) {
      Future.delayed(const Duration(milliseconds: 2400), () {
        if (mounted) widget.onNavigate(navigateTarget!);
      });
    }
  }

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  void _toggleListening() async {
    if (_isListening) {
      await _voice.stopListening();
      setState(() => _isListening = false);
    } else {
      setState(() {
        _voiceText = 'Тыңдап тұрмын...';
        _assistantReply = '...';
      });

      await _voice.listen(
        onResult: (text) {
          if (text.isNotEmpty) {
            _processVoiceInput(text);
          }
        },
        onListeningStateChanged: (state) {
          setState(() => _isListening = state);
        },
        onError: (err) {
          setState(() {
            _voiceText = 'Қате: Дауыс анықталмады.';
            _assistantReply = 'Қайталап микрофонды басыңыз немесе "Карта аш" деп айтыңыз.';
            _isListening = false;
          });
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.store.assistant.color;

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.mic, color: color, size: 28),
              const SizedBox(width: 8),
              Text(
                'AI Дауыстық Ассистент',
                style: AppTypography.headingMedium.copyWith(color: color),
              ),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.info_outline, color: AppColors.textMuted),
                onPressed: _speakIntroduction,
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            _voiceText,
            style: AppTypography.bodyMedium,
          ),
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.bgDarkSurface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.glassBorder),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  widget.store.assistant.icon,
                  color: widget.store.assistant.accent,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _assistantReply,
                    style: AppTypography.bodySmall.copyWith(
                      color: AppColors.textPrimary,
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: GlowButton(
                  label: _isListening ? 'Тыңдап тұрмын...' : 'Ассистентпен сөйлесу 🎙️',
                  color: _isListening ? AppColors.neonMagenta : color,
                  glowColor: _isListening
                      ? AppColors.neonMagenta.withValues(alpha: .5)
                      : widget.store.assistant.accent.withValues(alpha: .5),
                  onPressed: _toggleListening,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
