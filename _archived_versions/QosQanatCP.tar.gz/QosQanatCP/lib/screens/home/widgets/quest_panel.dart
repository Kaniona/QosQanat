import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../data/models/game_models.dart';
import '../../../data/store/app_store.dart';
import '../../../data/content/quests_data.dart';
import '../../../widgets/glass_card.dart';

class QuestPanel extends StatelessWidget {
  const QuestPanel({required this.store, super.key});

  final AppStore store;

  @override
  Widget build(BuildContext context) {
    final quests = QuestsData.getActiveQuests(store);

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.assignment, color: AppColors.neonGold, size: 28),
              const SizedBox(width: 8),
              const Text(
                'Күнделікті Квесттер',
                style: AppTypography.headingMedium,
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.neonGold.withValues(alpha: .15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.neonGold.withValues(alpha: .4)),
                ),
                child: Text(
                  'Сыйлықтар 🎁',
                  style: AppTypography.labelSmall.copyWith(color: AppColors.neonGold),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: quests.length,
            separatorBuilder: (context, index) => const Divider(height: 16),
            itemBuilder: (context, index) {
              final q = quests[index];
              return _buildQuestRow(context, q);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildQuestRow(BuildContext context, Quest quest) {
    final completed = quest.complete;

    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: completed
                ? AppColors.success.withValues(alpha: .15)
                : AppColors.bgDarkSurface,
            shape: BoxShape.circle,
            border: Border.all(
              color: completed ? AppColors.success : AppColors.glassBorder,
              width: 1.5,
            ),
          ),
          child: Center(
            child: Text(
              quest.icon,
              style: const TextStyle(fontSize: 18),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                quest.title,
                style: AppTypography.bodyMedium.copyWith(
                  color: completed ? AppColors.textPrimary : AppColors.textSecondary,
                  fontWeight: completed ? FontWeight.w700 : FontWeight.w500,
                  decoration: completed ? TextDecoration.lineThrough : null,
                ),
              ),
              const SizedBox(height: 6),
              // Simple Progress indicator
              Row(
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: quest.percentage,
                        minHeight: 5,
                        backgroundColor: AppColors.bgDarkSurface,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          completed ? AppColors.success : AppColors.neonGold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    '${quest.progress}/${quest.total}',
                    style: AppTypography.labelSmall.copyWith(
                      color: completed ? AppColors.success : AppColors.textMuted,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        // Reward indicator
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: completed
                ? AppColors.success.withValues(alpha: .2)
                : AppColors.bgDarkSurface,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: completed ? AppColors.success : AppColors.glassBorder,
            ),
          ),
          child: Text(
            quest.reward,
            style: AppTypography.labelSmall.copyWith(
              color: completed ? AppColors.success : AppColors.coin,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ],
    );
  }
}
