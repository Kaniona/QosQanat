import 'dart:async';
import 'package:flutter/material.dart';

import '../../core/constants.dart';
import '../../core/theme/design_system.dart';
import '../../data/store/app_store.dart';
import '../../screens/registration/registration_screen.dart';
import '../../screens/shell/shell_screen.dart';
import '../../widgets/particle_background.dart';

/// Premium animated splash screen for QosQanat
/// Shows logo + tagline with staggered animations, then routes based on auth state.
class SplashScreen extends StatefulWidget {
  const SplashScreen({required this.store, super.key});

  final AppStore store;

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoController;
  late AnimationController _textController;
  late AnimationController _pulseController;
  late AnimationController _buttonController;

  late Animation<double> _logoScale;
  late Animation<double> _logoOpacity;
  late Animation<double> _taglineOpacity;
  late Animation<Offset> _taglineSlide;
  late Animation<double> _pulseGlow;
  late Animation<double> _buttonOpacity;

  bool _navigated = false;

  @override
  void initState() {
    super.initState();

    // Logo entrance: scale + fade
    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _logoScale = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _logoController, curve: Curves.easeOutBack),
    );
    _logoOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _logoController,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOut),
      ),
    );

    // Tagline entrance: slide up + fade
    _textController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _taglineOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _textController, curve: Curves.easeOut),
    );
    _taglineSlide = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _textController, curve: Curves.easeOutCubic),
    );

    // Continuous pulse glow on logo
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
    _pulseGlow = Tween<double>(begin: 8.0, end: 24.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    // Button fade-in
    _buttonController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _buttonOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _buttonController, curve: Curves.easeOut),
    );

    // Stagger the animations
    _logoController.forward();
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _textController.forward();
    });
    Future.delayed(const Duration(milliseconds: 1200), () {
      if (mounted) _buttonController.forward();
    });

    // Auto-navigate after 2.8s
    Future.delayed(const Duration(milliseconds: 2800), _navigate);
  }

  void _navigate() {
    if (_navigated || !mounted) return;
    _navigated = true;

    final destination = widget.store.profile == null
        ? RegistrationScreen(store: widget.store)
        : QosQanatShell(store: widget.store);

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 600),
        pageBuilder: (context, animation, secondaryAnimation) => destination,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(
            opacity: animation,
            child: ScaleTransition(
              scale: Tween<double>(begin: 0.95, end: 1.0).animate(
                CurvedAnimation(parent: animation, curve: Curves.easeOut),
              ),
              child: child,
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _logoController.dispose();
    _textController.dispose();
    _pulseController.dispose();
    _buttonController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DesignSystem.kazakhDeepBlue,
      body: ParticleBackground(
        child: SafeArea(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Spacer(flex: 3),

                // ── Animated Logo ──
                AnimatedBuilder(
                  animation: Listenable.merge([_logoController, _pulseController]),
                  builder: (context, _) {
                    return Opacity(
                      opacity: _logoOpacity.value,
                      child: Transform.scale(
                        scale: _logoScale.value,
                        child: Container(
                          width: 120,
                          height: 120,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                DesignSystem.kazakhSkyBlue,
                                Color(0xFF0284C7),
                              ],
                            ),
                            border: Border.all(
                              color: DesignSystem.kazakhGold.withValues(alpha: 0.6),
                              width: 2.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: DesignSystem.kazakhSkyBlue.withValues(alpha: 0.5),
                                blurRadius: _pulseGlow.value,
                                spreadRadius: 2,
                              ),
                              BoxShadow(
                                color: DesignSystem.kazakhGold.withValues(alpha: 0.2),
                                blurRadius: _pulseGlow.value * 0.6,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Text(
                              '🪽',
                              style: TextStyle(fontSize: 52),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),

                const SizedBox(height: 32),

                // ── App Name ──
                AnimatedBuilder(
                  animation: _logoController,
                  builder: (context, _) {
                    return Opacity(
                      opacity: _logoOpacity.value,
                      child: ShaderMask(
                        shaderCallback: (bounds) =>
                            DesignSystem.kazakhFlagGradient.createShader(bounds),
                        child: Text(
                          AppConstants.appName,
                          style: DesignSystem.displayLarge.copyWith(
                            fontSize: 52,
                            letterSpacing: -1.5,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    );
                  },
                ),

                const SizedBox(height: 12),

                // ── Tagline ──
                AnimatedBuilder(
                  animation: _textController,
                  builder: (context, _) {
                    return SlideTransition(
                      position: _taglineSlide,
                      child: Opacity(
                        opacity: _taglineOpacity.value,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 40),
                          child: Text(
                            AppConstants.tagline,
                            textAlign: TextAlign.center,
                            style: DesignSystem.bodyMedium.copyWith(
                              fontSize: 16,
                              color: DesignSystem.steppeSilver,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),

                const SizedBox(height: 48),

                // ── Tap to skip / loading indicator ──
                AnimatedBuilder(
                  animation: _buttonController,
                  builder: (context, _) {
                    return Opacity(
                      opacity: _buttonOpacity.value,
                      child: GestureDetector(
                        onTap: _navigate,
                        child: Column(
                          children: [
                            SizedBox(
                              width: 28,
                              height: 28,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.5,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  DesignSystem.kazakhSkyBlue.withValues(alpha: 0.7),
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'Жүктелуде...',
                              style: DesignSystem.bodySmall.copyWith(
                                color: DesignSystem.steppeSilver.withValues(alpha: 0.6),
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),

                const Spacer(flex: 2),

                // ── Bottom branding ──
                AnimatedBuilder(
                  animation: _textController,
                  builder: (context, _) {
                    return Opacity(
                      opacity: _taglineOpacity.value * 0.5,
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 24),
                        child: Text(
                          'QosQanat © 2024–2026',
                          style: DesignSystem.bodySmall.copyWith(
                            fontSize: 11,
                            color: DesignSystem.steppeSilver.withValues(alpha: 0.3),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
