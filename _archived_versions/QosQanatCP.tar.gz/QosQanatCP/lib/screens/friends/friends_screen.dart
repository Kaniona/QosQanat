import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/models/friend.dart';
import '../../data/models/game_models.dart';
import '../../data/store/app_store.dart';
import '../../widgets/app_page.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';
import '../battle/battle_setup_screen.dart';

class FriendsScreen extends StatefulWidget {
  const FriendsScreen({required this.store, super.key});
  final AppStore store;

  @override
  State<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _searchController = TextEditingController();
  Friend? _searchResult;
  bool _searching = false;
  bool _requestSent = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _performSearch() {
    final text = _searchController.text.trim().toUpperCase();
    setState(() { _searching = true; _requestSent = false; });
    Future.delayed(const Duration(milliseconds: 600), () {
      if (!mounted) return;
      setState(() {
        _searchResult = widget.store.searchFriendByQqId(text);
        _searching = false;
      });
    });
  }

  void _sendRequest() {
    if (_searchResult == null) return;
    final ok = widget.store.sendFriendRequestWithData(_searchResult!);
    setState(() { _requestSent = ok; });
    if (ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Дос сұранысы жіберілді! 🤝')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AppPage(
        title: 'Достар & Батл ⚔️',
        subtitle: 'Достарыңызбен Ақыл жарысын бастаңыз',
        child: Column(
          children: [
            // Tab bar
            Container(
              decoration: BoxDecoration(
                color: AppColors.bgDarkCard.withValues(alpha: .6),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.glassBorder, width: 0.5),
              ),
              child: TabBar(
                controller: _tabController,
                onTap: (_) => setState(() {}),
                indicatorSize: TabBarIndicatorSize.tab,
                indicator: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: widget.store.assistant.color.withValues(alpha: .2),
                  border: Border.all(color: widget.store.assistant.color.withValues(alpha: .4)),
                ),
                dividerHeight: 0,
                labelStyle: AppTypography.labelLarge,
                unselectedLabelStyle: AppTypography.bodyMedium,
                labelColor: AppColors.textPrimary,
                unselectedLabelColor: AppColors.textMuted,
                tabs: [
                  Tab(text: 'Достарым (${widget.store.acceptedFriends.length})'),
                  Tab(text: 'Өтінімдер (${widget.store.incomingRequests.length})'),
                  const Tab(text: 'Іздеу 🔍'),
                ],
              ),
            ),
            const SizedBox(height: 16),
            // Tab content
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              child: _buildTabContent(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTabContent() {
    switch (_tabController.index) {
      case 0: return _buildFriendsTab();
      case 1: return _buildRequestsTab();
      case 2: return _buildSearchTab();
      default: return _buildFriendsTab();
    }
  }

  // ── TAB 1: ДОСТАРЫМ ──
  Widget _buildFriendsTab() {
    final accepted = widget.store.acceptedFriends;
    return Column(
      key: const ValueKey('friends'),
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (accepted.isEmpty)
          const GlassCard(child: Center(child: Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Text('Әзірге достарыңыз жоқ.\nІздеу табында жаңа достар қосыңыз! 🔍',
              textAlign: TextAlign.center, style: AppTypography.bodyMedium),
          )))
        else
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: accepted.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) => _buildFriendCard(accepted[i]),
          ),
        const SizedBox(height: 24),
        // Battle history
        Text('Батл тарихы', style: AppTypography.headingMedium),
        const SizedBox(height: 8),
        widget.store.battleHistory.isEmpty
          ? const GlassCard(child: Center(child: Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Text('Батлдар әлі болмаған...', style: AppTypography.bodyMedium),
            )))
          : ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: widget.store.battleHistory.length,
              separatorBuilder: (_, __) => const SizedBox(height: 6),
              itemBuilder: (_, i) => _buildHistoryCard(widget.store.battleHistory[i]),
            ),
      ],
    );
  }

  Widget _buildFriendCard(Friend friend) {
    return GlassCard(
      child: Row(
        children: [
          // Avatar
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: AppColors.bgDarkSurface,
              shape: BoxShape.circle,
              border: Border.all(
                color: friend.isOnline ? AppColors.success : AppColors.textMuted,
                width: 2,
              ),
            ),
            child: Center(child: Text(friend.avatarEmoji, style: const TextStyle(fontSize: 22))),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Text(friend.name, style: AppTypography.headingSmall),
                  const SizedBox(width: 6),
                  Container(
                    width: 8, height: 8,
                    decoration: BoxDecoration(
                      color: friend.isOnline ? AppColors.success : AppColors.textMuted,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(friend.isOnline ? 'Online' : 'Offline',
                    style: AppTypography.labelSmall.copyWith(
                      color: friend.isOnline ? AppColors.success : AppColors.textMuted)),
                ]),
                Text('Lvl ${friend.level} • 💎 ${friend.wisdom} Ақыл • ${friend.city}',
                  style: AppTypography.bodySmall),
              ],
            ),
          ),
          GlowButton(
            label: 'Батл шақыр! ⚔️',
            height: 36, borderRadius: 8,
            color: AppColors.neonMagenta,
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => BattleSetupScreen(store: widget.store, opponent: friend),
              ));
            },
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryCard(BattleResult log) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(children: [
        Icon(log.won ? Icons.emoji_events : Icons.close,
          color: log.won ? AppColors.neonGold : AppColors.error, size: 24),
        const SizedBox(width: 10),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${log.friendName}-мен Батл', style: AppTypography.headingSmall),
            Text('${log.totalQuestions} сұрақ', style: AppTypography.bodySmall),
          ],
        )),
        Text('${log.myScore} : ${log.friendScore}',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold,
            color: log.won ? AppColors.success : AppColors.error)),
      ]),
    );
  }

  // ── TAB 2: ӨТІНІМДЕР ──
  Widget _buildRequestsTab() {
    final incoming = widget.store.incomingRequests;
    final outgoing = widget.store.outgoingRequests;
    return Column(
      key: const ValueKey('requests'),
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Келген өтінімдер', style: AppTypography.headingMedium),
        const SizedBox(height: 8),
        if (incoming.isEmpty)
          const GlassCard(child: Center(child: Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Text('Жаңа өтінімдер жоқ', style: AppTypography.bodyMedium),
          )))
        else
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: incoming.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) => _buildRequestCard(incoming[i], isIncoming: true),
          ),
        const SizedBox(height: 20),
        Text('Жіберілген өтінімдер', style: AppTypography.headingMedium),
        const SizedBox(height: 8),
        if (outgoing.isEmpty)
          const GlassCard(child: Center(child: Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Text('Күтілуде өтінімдер жоқ', style: AppTypography.bodyMedium),
          )))
        else
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: outgoing.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) => _buildRequestCard(outgoing[i], isIncoming: false),
          ),
      ],
    );
  }

  Widget _buildRequestCard(Friend friend, {required bool isIncoming}) {
    return GlassCard(
      child: Row(children: [
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(color: AppColors.bgDarkSurface, shape: BoxShape.circle),
          child: Center(child: Text(friend.avatarEmoji, style: const TextStyle(fontSize: 20))),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(friend.name, style: AppTypography.headingSmall),
            Text('Lvl ${friend.level} • 💎 ${friend.wisdom} • ${friend.city}', style: AppTypography.bodySmall),
          ],
        )),
        if (isIncoming) ...[
          IconButton(
            icon: const Icon(Icons.check_circle, color: AppColors.success, size: 32),
            onPressed: () { widget.store.acceptFriendRequest(friend.qqId); setState(() {}); },
          ),
          IconButton(
            icon: const Icon(Icons.cancel, color: AppColors.error, size: 32),
            onPressed: () { widget.store.declineFriendRequest(friend.qqId); setState(() {}); },
          ),
        ] else
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.warning.withValues(alpha: .15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.warning.withValues(alpha: .3)),
            ),
            child: const Text('Күтілуде...', style: TextStyle(color: AppColors.warning, fontSize: 12, fontWeight: FontWeight.w600)),
          ),
      ]),
    );
  }

  // ── TAB 3: ІЗДЕУ ──
  Widget _buildSearchTab() {
    return Column(
      key: const ValueKey('search'),
      children: [
        GlassCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Дос іздеу', style: AppTypography.headingMedium),
              const SizedBox(height: 4),
              const Text('Досыңыздың QQ-ID нөмірін енгізіңіз:', style: AppTypography.bodySmall),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    style: AppTypography.bodyLarge,
                    decoration: const InputDecoration(
                      labelText: 'QQ-XXXXXXXXX ID жаз',
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                GlowButton(
                  label: 'Іздеу 🔍',
                  height: 48,
                  color: widget.store.assistant.color,
                  onPressed: _performSearch,
                ),
              ]),
            ],
          ),
        ),
        const SizedBox(height: 16),
        if (_searching)
          const Padding(
            padding: EdgeInsets.all(24),
            child: CircularProgressIndicator(),
          )
        else if (_searchResult != null)
          _buildSearchResultCard()
        else if (_searchController.text.isNotEmpty)
          const GlassCard(child: Center(child: Padding(
            padding: EdgeInsets.symmetric(vertical: 20),
            child: Text('Қолданушы табылмады 😔', style: AppTypography.bodyLarge),
          ))),
      ],
    );
  }

  Widget _buildSearchResultCard() {
    final user = _searchResult!;
    final alreadyFriend = widget.store.friends.any((f) => f.qqId == user.qqId);
    return GlassCard(
      borderGradient: LinearGradient(
        colors: [widget.store.assistant.color, AppColors.neonCyan],
      ),
      child: Column(children: [
        const SizedBox(height: 8),
        Container(
          width: 72, height: 72,
          decoration: BoxDecoration(
            color: AppColors.bgDarkSurface,
            shape: BoxShape.circle,
            border: Border.all(color: widget.store.assistant.color, width: 2),
          ),
          child: Center(child: Text(user.avatarEmoji, style: const TextStyle(fontSize: 36))),
        ),
        const SizedBox(height: 12),
        Text(user.name, style: AppTypography.headingLarge),
        const SizedBox(height: 4),
        Text(user.qqId, style: AppTypography.bodySmall),
        const SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          _statChip('Lvl', '${user.level}', AppColors.neonCyan),
          const SizedBox(width: 12),
          _statChip('💎', '${user.wisdom}', AppColors.wisdom),
          const SizedBox(width: 12),
          _statChip('📍', user.city, AppColors.neonPurple),
        ]),
        const SizedBox(height: 16),
        if (alreadyFriend || _requestSent)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: AppColors.success.withValues(alpha: .15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              _requestSent ? '✅ Сұраныс жіберілді!' : '✅ Бұл досыңыз!',
              style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.bold),
            ),
          )
        else
          GlowButton(
            label: 'Дос қос 🤝',
            color: AppColors.success,
            onPressed: _sendRequest,
          ),
        const SizedBox(height: 8),
      ]),
    );
  }

  Widget _statChip(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: .3)),
      ),
      child: Text('$label $value',
        style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}
