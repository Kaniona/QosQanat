import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/models/friend.dart';
import '../../data/models/game_models.dart';
import '../../data/store/app_store.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';
import '../../widgets/particle_background.dart';
import 'battle_setup_screen.dart';

class BattleResultScreen extends StatefulWidget {
  const BattleResultScreen({
    required this.store,
    required this.result,
    required this.battleState,
    super.key,
  });

  final AppStore store;
  final BattleResult result;
  final LiveBattleState battleState;

  @override
  State<BattleResultScreen> createState() => _BattleResultScreenState();
}

class _BattleResultScreenState extends State<BattleResultScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _celebrationCtrl;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _celebrationCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _scaleAnimation = CurvedAnimation(
      parent: _celebrationCtrl,
      curve: Curves.elasticOut,
    );
    _celebrationCtrl.forward();
  }

  @override
  void dispose() {
    _celebrationCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final res = widget.result;
    final state = widget.battleState;
    final color = widget.store.assistant.color;

    // Rewards calculation
    final won = res.won;
    final akylGained = won ? state.winnerAkylReward : state.loserAkylReward;
    final coinsGained = won ? 12 + (state.totalQuestions ~/ 5) : 0;
    final expGained = won ? 14 + state.myTimeBonus : 6;

    return Scaffold(
      body: ParticleBackground(
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
            child: Column(
              children: [
                const SizedBox(height: 20),
                // Title / Result Header
                ScaleTransition(
                  scale: _scaleAnimation,
                  child: Center(
                    child: Column(
                      children: [
                        Text(
                          won ? '🏆 ЖЕҢІС! 🏆' : '⚔️ КЕЛЕСІ ЖОЛЫ СӘТТІЛІК! ⚔️',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                            color: won ? AppColors.neonGold : AppColors.neonMagenta,
                            shadows: [
                              Shadow(
                                color: won ? AppColors.neonGold : AppColors.neonMagenta,
                                blurRadius: 15,
                              )
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppColors.bgDarkSurface,
                            border: Border.all(
                              color: won ? AppColors.neonGold : AppColors.neonMagenta,
                              width: 3,
                            ),
                          ),
                          child: Text(
                            won ? '👑' : '🛡️',
                            style: const TextStyle(fontSize: 48),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // Score breakdown
                GlassCard(
                  borderGradient: LinearGradient(
                    colors: won
                        ? [AppColors.neonGold, AppColors.success]
                        : [AppColors.neonMagenta, AppColors.error],
                  ),
                  child: Column(
                    children: [
                      Text(
                        '${state.opponentName}-мен болған Батл нәтижесі!',
                        textAlign: TextAlign.center,
                        style: AppTypography.headingSmall,
                      ),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Column(
                            children: [
                              const Text('Сен', style: AppTypography.labelMedium),
                              const SizedBox(height: 6),
                              Text(
                                '${res.myScore}/${res.totalQuestions}',
                                style: AppTypography.displayLarge.copyWith(
                                  color: AppColors.success,
                                  fontSize: 40,
                                ),
                              ),
                              if (won && state.myTimeBonus > 0)
                                Text(
                                  '+${state.myTimeBonus}уақыт бонысы',
                                  style: const TextStyle(
                                    color: AppColors.neonCyan,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                            ],
                          ),
                          const Text('VS', style: AppTypography.headingLarge),
                          Column(
                            children: [
                              Text(state.opponentName, style: AppTypography.labelMedium),
                              const SizedBox(height: 6),
                              Text(
                                '${res.friendScore}/${res.totalQuestions}',
                                style: AppTypography.displayLarge.copyWith(
                                  color: AppColors.error,
                                  fontSize: 40,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Rewards
                GlassCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Алынған марапаттар:',
                        style: AppTypography.headingMedium,
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _rewardItem('💎 Ақыл', '+$akylGained', AppColors.wisdom),
                          _rewardItem('🪙 Тиын', '+$coinsGained', AppColors.coin),
                          _rewardItem('⚡ EXP', '+$expGained', AppColors.exp),
                        ],
                      ),
                      if (won) ...[
                        const SizedBox(height: 12),
                        const Center(
                          child: Text(
                            'Жеңімпаз 2 есе Ақыл ұпайларын алды! 🌟',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: AppColors.neonGold,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 32),

                // Actions
                SizedBox(
                  width: double.infinity,
                  child: GlowButton(
                    label: 'Бас бетке қайту 🏠',
                    color: color,
                    onPressed: () {
                      // Navigate back to the main shell (Pop everything back to the root shell)
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    },
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: const BorderSide(color: AppColors.glassBorder),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    icon: const Icon(Icons.refresh, color: AppColors.textPrimary),
                    label: const Text(
                      'Қайтадан ойнау ⚔️',
                      style: TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    onPressed: () {
                      // Restart the battle setup with the same opponent
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(
                          builder: (_) => BattleSetupScreen(
                            store: widget.store,
                            opponent: Friend(
                              qqId: state.battleId, // Placeholder
                              name: state.opponentName,
                              city: 'Қазақстан',
                              wisdom: state.opponentWisdom,
                              level: state.opponentLevel,
                              avatarEmoji: state.opponentEmoji,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _rewardItem(String label, String value, Color color) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: .1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withValues(alpha: .3), width: 1),
        ),
        child: Column(
          children: [
            Text(
              label,
              style: AppTypography.labelSmall.copyWith(color: AppColors.textSecondary),
            ),
            const SizedBox(height: 6),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 18,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
