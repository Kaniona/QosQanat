import 'package:flutter/material.dart';
import '../../core/constants.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/models/friend.dart';
import '../../data/store/app_store.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';
import '../../widgets/particle_background.dart';
import 'battle_waiting_screen.dart';

class BattleSetupScreen extends StatefulWidget {
  const BattleSetupScreen({required this.store, required this.opponent, super.key});
  final AppStore store;
  final Friend opponent;

  @override
  State<BattleSetupScreen> createState() => _BattleSetupScreenState();
}

class _BattleSetupScreenState extends State<BattleSetupScreen>
    with SingleTickerProviderStateMixin {
  int _questionCount = 15;
  String _selectedSubject = 'Барлық пәндер';
  late AnimationController _pulseCtrl;

  static const _subjects = [
    'Барлық пәндер', 'Математика', 'Қазақ тілі', 'Ағылшын',
    'Тарих', 'Жаратылыстану', 'Информатика', 'Логика', 'Әдебиет',
  ];

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() { _pulseCtrl.dispose(); super.dispose(); }

  void _startBattle() {
    final subject = _selectedSubject == 'Барлық пәндер' ? null : _selectedSubject;
    final state = widget.store.createBattleState(
      widget.opponent, _questionCount, subject: subject,
    );
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => BattleWaitingScreen(store: widget.store, battleState: state),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final opp = widget.opponent;
    final color = widget.store.assistant.color;

    return Scaffold(
      body: ParticleBackground(
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(children: [
              // Back button
              Align(
                alignment: Alignment.centerLeft,
                child: IconButton(
                  icon: const Icon(Icons.arrow_back_ios, color: AppColors.textPrimary),
                  onPressed: () => Navigator.pop(context),
                ),
              ),
              const SizedBox(height: 8),
              // Title
              const Text('АҚЫЛ БАТЛ ⚔️', style: AppTypography.displayLarge),
              const SizedBox(height: 4),
              Text('${opp.name}-мен жарыс', style: AppTypography.bodyMedium),
              const SizedBox(height: 24),

              // VS Card
              GlassCard(
                borderGradient: const LinearGradient(
                  colors: [AppColors.neonMagenta, AppColors.neonCyan],
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _avatarColumn(
                        'Сен',
                        widget.store.profile?.fullName ?? 'Сен',
                        '🧑‍🎓',
                        widget.store.level,
                        widget.store.wisdom,
                        color,
                      ),
                      AnimatedBuilder(
                        animation: _pulseCtrl,
                        builder: (_, __) => Transform.scale(
                          scale: 1.0 + _pulseCtrl.value * 0.1,
                          child: const Text('VS', style: TextStyle(
                            fontSize: 42, fontWeight: FontWeight.w900,
                            color: AppColors.neonMagenta,
                            shadows: [Shadow(color: AppColors.neonMagenta, blurRadius: 20)],
                          )),
                        ),
                      ),
                      _avatarColumn(opp.name, opp.name, opp.avatarEmoji,
                          opp.level, opp.wisdom, AppColors.neonMagenta),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Question count
              GlassCard(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Сұрақтар саны:', style: AppTypography.headingMedium),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8, runSpacing: 8,
                    children: AppConstants.battleQuestionCounts.map((c) {
                      final sel = _questionCount == c;
                      return GestureDetector(
                        onTap: () => setState(() => _questionCount = c),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          decoration: BoxDecoration(
                            color: sel ? color.withValues(alpha: .2) : AppColors.bgDarkSurface,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: sel ? color : AppColors.glassBorder, width: 1.5),
                            boxShadow: sel ? [BoxShadow(color: color.withValues(alpha: .3), blurRadius: 8)] : [],
                          ),
                          child: Text('$c', style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold,
                            color: sel ? Colors.white : AppColors.textSecondary)),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              )),
              const SizedBox(height: 16),

              // Subject selection
              GlassCard(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Пән таңдау:', style: AppTypography.headingMedium),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8, runSpacing: 8,
                    children: _subjects.map((s) {
                      final sel = _selectedSubject == s;
                      return GestureDetector(
                        onTap: () => setState(() => _selectedSubject = s),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: sel ? AppColors.neonPurple.withValues(alpha: .2) : AppColors.bgDarkSurface,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: sel ? AppColors.neonPurple : AppColors.glassBorder),
                          ),
                          child: Text(s, style: TextStyle(
                            fontSize: 13, fontWeight: sel ? FontWeight.bold : FontWeight.w500,
                            color: sel ? Colors.white : AppColors.textSecondary)),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              )),
              const SizedBox(height: 28),

              // Start button
              SizedBox(
                width: double.infinity,
                child: GlowButton(
                  label: 'Батл бастау! ⚔️',
                  height: 56,
                  color: AppColors.neonMagenta,
                  glowColor: AppColors.neonMagenta.withValues(alpha: .5),
                  onPressed: _startBattle,
                ),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Артқа', style: TextStyle(color: AppColors.textSecondary)),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _avatarColumn(String label, String name, String emoji, int lvl, int wis, Color color) {
    return Column(children: [
      Container(
        width: 64, height: 64,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: AppColors.bgDarkSurface,
          border: Border.all(color: color, width: 2),
          boxShadow: [BoxShadow(color: color.withValues(alpha: .3), blurRadius: 12)],
        ),
        child: Center(child: Text(emoji, style: const TextStyle(fontSize: 32))),
      ),
      const SizedBox(height: 8),
      Text(label, style: AppTypography.headingSmall),
      Text('Lvl $lvl', style: AppTypography.bodySmall),
      Text('💎 $wis', style: AppTypography.bodySmall),
    ]);
  }
}
