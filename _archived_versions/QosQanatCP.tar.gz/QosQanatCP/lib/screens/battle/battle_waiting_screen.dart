import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/models/game_models.dart';
import '../../data/store/app_store.dart';
import '../../widgets/particle_background.dart';
import 'battle_screen.dart';

class BattleWaitingScreen extends StatefulWidget {
  const BattleWaitingScreen({required this.store, required this.battleState, super.key});
  final AppStore store;
  final LiveBattleState battleState;

  @override
  State<BattleWaitingScreen> createState() => _BattleWaitingScreenState();
}

class _BattleWaitingScreenState extends State<BattleWaitingScreen>
    with TickerProviderStateMixin {
  late AnimationController _swordCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _dotsCtrl;
  Timer? _waitTimer;
  int _dotCount = 0;

  @override
  void initState() {
    super.initState();
    _swordCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
    _dotsCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600))
      ..repeat();
    _dotsCtrl.addListener(() {
      if (_dotsCtrl.status == AnimationStatus.completed) {
        setState(() => _dotCount = (_dotCount + 1) % 4);
      }
    });

    // Simulate opponent accepting after 2-4 seconds
    final delay = 2 + Random().nextInt(2);
    _waitTimer = Timer(Duration(seconds: delay), _opponentAccepted);
  }

  void _opponentAccepted() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => BattleScreen(store: widget.store, battleState: widget.battleState),
    ));
  }

  @override
  void dispose() {
    _swordCtrl.dispose();
    _pulseCtrl.dispose();
    _dotsCtrl.dispose();
    _waitTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dots = '.' * (_dotCount + 1);
    return Scaffold(
      body: ParticleBackground(
        child: SafeArea(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Pulsing opponent avatar
                AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (_, __) => Transform.scale(
                    scale: 1.0 + _pulseCtrl.value * 0.08,
                    child: Container(
                      width: 100, height: 100,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.bgDarkSurface,
                        border: Border.all(color: AppColors.neonMagenta, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.neonMagenta.withValues(alpha: .3 + _pulseCtrl.value * .2),
                            blurRadius: 20 + _pulseCtrl.value * 10,
                          ),
                        ],
                      ),
                      child: Center(child: Text(
                        widget.battleState.opponentEmoji,
                        style: const TextStyle(fontSize: 48),
                      )),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(widget.battleState.opponentName, style: AppTypography.headingLarge),
                const SizedBox(height: 32),

                // Animated swords
                AnimatedBuilder(
                  animation: _swordCtrl,
                  builder: (_, __) => Transform.rotate(
                    angle: _swordCtrl.value * 0.3 - 0.15,
                    child: const Text('⚔️', style: TextStyle(fontSize: 64)),
                  ),
                ),
                const SizedBox(height: 24),

                // Waiting text
                Text('Күтіп тұр$dots', style: AppTypography.headingMedium.copyWith(
                  color: AppColors.neonCyan,
                )),
                const SizedBox(height: 8),
                Text(
                  '${widget.battleState.totalQuestions} сұрақ — Ақыл Батлы',
                  style: AppTypography.bodyMedium,
                ),
                const SizedBox(height: 40),

                // Loading indicator
                SizedBox(
                  width: 200,
                  child: LinearProgressIndicator(
                    minHeight: 4,
                    backgroundColor: AppColors.bgDarkSurface,
                    valueColor: const AlwaysStoppedAnimation<Color>(AppColors.neonMagenta),
                  ),
                ),
                const SizedBox(height: 40),

                // Cancel
                TextButton.icon(
                  icon: const Icon(Icons.close, color: AppColors.textMuted),
                  label: const Text('Бас тарту', style: TextStyle(color: AppColors.textMuted)),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
