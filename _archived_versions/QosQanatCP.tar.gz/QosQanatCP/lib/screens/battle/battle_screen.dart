import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/models/game_models.dart';
import '../../data/store/app_store.dart';
import '../../widgets/glass_card.dart';
import 'battle_result_screen.dart';

class BattleScreen extends StatefulWidget {
  const BattleScreen({required this.store, required this.battleState, super.key});
  final AppStore store;
  final LiveBattleState battleState;

  @override
  State<BattleScreen> createState() => _BattleScreenState();
}

class _BattleScreenState extends State<BattleScreen>
    with TickerProviderStateMixin {
  late LiveBattleState _state;
  late AnimationController _timerCtrl;
  int? _selectedIndex;
  bool _answered = false;
  bool _opponentAnswered = false;
  int? _opponentChoice;
  Timer? _opponentTimer;
  Timer? _nextTimer;

  static const _timePerQuestion = 10; // seconds

  @override
  void initState() {
    super.initState();
    _state = widget.battleState;
    _timerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: _timePerQuestion),
    );
    _startQuestion();
  }

  void _startQuestion() {
    _selectedIndex = null;
    _answered = false;
    _opponentAnswered = false;
    _opponentChoice = null;
    _timerCtrl.forward(from: 0);
    _timerCtrl.addStatusListener(_onTimerEnd);
    _simulateOpponent();
  }

  void _onTimerEnd(AnimationStatus status) {
    if (status == AnimationStatus.completed && !_answered) {
      _onAnswer(-1); // Time's up
    }
  }

  void _simulateOpponent() {
    final r = Random();
    final delay = 1000 + r.nextInt(7000); // 1-8 seconds
    _opponentTimer = Timer(Duration(milliseconds: delay), () {
      if (!mounted) return;
      final q = _state.currentQuestion;
      final correctProb = (0.40 + _state.opponentWisdom / 1900).clamp(0.35, 0.88);
      final correct = r.nextDouble() < correctProb;
      _opponentChoice = correct ? q.correctIndex : ((q.correctIndex + 1 + r.nextInt(3)) % 4);
      if (correct) _state.opponentScore++;
      setState(() => _opponentAnswered = true);
      _checkBothAnswered();
    });
  }

  void _onAnswer(int index) {
    if (_answered) return;
    _timerCtrl.stop();
    final q = _state.currentQuestion;
    final correct = index == q.correctIndex;
    if (correct) {
      _state.myScore++;
      // Time bonus: faster answer = more bonus (max 3)
      final elapsed = _timerCtrl.value * _timePerQuestion;
      if (elapsed < 3) _state.myTimeBonus += 3;
      else if (elapsed < 6) _state.myTimeBonus += 1;
    }
    setState(() { _selectedIndex = index; _answered = true; });
    _checkBothAnswered();
  }

  void _checkBothAnswered() {
    if (!_answered || !_opponentAnswered) return;
    _nextTimer = Timer(const Duration(milliseconds: 1200), _nextQuestion);
  }

  void _nextQuestion() {
    if (!mounted) return;
    _state.currentQuestionIndex++;
    _timerCtrl.removeStatusListener(_onTimerEnd);
    if (_state.isFinished) {
      final result = widget.store.finalizeBattle(_state);
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => BattleResultScreen(
          store: widget.store,
          result: result,
          battleState: _state,
        ),
      ));
    } else {
      setState(() => _startQuestion());
    }
  }

  @override
  void dispose() {
    _timerCtrl.removeStatusListener(_onTimerEnd);
    _timerCtrl.dispose();
    _opponentTimer?.cancel();
    _nextTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = _state.currentQuestion;
    final qNum = _state.currentQuestionIndex + 1;
    final total = _state.totalQuestions;

    return Scaffold(
      backgroundColor: AppColors.bgDark,
      body: SafeArea(
        child: Column(children: [
          // ── TOP: Opponent bar ──
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.neonMagenta.withValues(alpha: .15), Colors.transparent],
              ),
            ),
            child: Row(children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.bgDarkSurface,
                  border: Border.all(color: AppColors.neonMagenta, width: 2),
                ),
                child: Center(child: Text(_state.opponentEmoji, style: const TextStyle(fontSize: 20))),
              ),
              const SizedBox(width: 10),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_state.opponentName, style: AppTypography.headingSmall),
                Text('Lvl ${_state.opponentLevel}', style: AppTypography.bodySmall),
              ]),
              const Spacer(),
              // Opponent score
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: AppColors.neonMagenta.withValues(alpha: .2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.neonMagenta.withValues(alpha: .4)),
                ),
                child: Row(children: [
                  Text('${_state.opponentScore}', style: const TextStyle(
                    fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.neonMagenta)),
                  const SizedBox(width: 4),
                  if (_opponentAnswered)
                    const Icon(Icons.check, color: AppColors.neonMagenta, size: 16)
                  else
                    SizedBox(width: 16, height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2, color: AppColors.neonMagenta.withValues(alpha: .5))),
                ]),
              ),
            ]),
          ),

          // ── Timer bar ──
          AnimatedBuilder(
            animation: _timerCtrl,
            builder: (_, __) {
              final remaining = 1.0 - _timerCtrl.value;
              final color = remaining > 0.3 ? AppColors.neonCyan
                  : remaining > 0.15 ? AppColors.warning : AppColors.error;
              return Column(children: [
                LinearProgressIndicator(
                  value: remaining,
                  minHeight: 5,
                  backgroundColor: AppColors.bgDarkSurface,
                  valueColor: AlwaysStoppedAnimation<Color>(color),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('$qNum/$total', style: AppTypography.labelMedium),
                      Text('${(remaining * _timePerQuestion).ceil()}с',
                        style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 13)),
                    ],
                  ),
                ),
              ]);
            },
          ),

          // ── Question area ──
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(children: [
                const SizedBox(height: 16),
                // Subject tag
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.neonPurple.withValues(alpha: .15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(q.subject, style: TextStyle(
                    color: AppColors.neonPurple, fontSize: 12, fontWeight: FontWeight.w700)),
                ),
                const SizedBox(height: 16),
                // Question text
                GlassCard(
                  child: Center(child: Text(
                    q.question,
                    textAlign: TextAlign.center,
                    style: AppTypography.headingMedium.copyWith(height: 1.4),
                  )),
                ),
                const SizedBox(height: 20),
                // Answer options
                ...List.generate(4, (i) => _buildOption(i, q)),
                const SizedBox(height: 16),
              ]),
            ),
          ),

          // ── BOTTOM: Player bar ──
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.transparent, widget.store.assistant.color.withValues(alpha: .15)],
              ),
            ),
            child: Row(children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.bgDarkSurface,
                  border: Border.all(color: widget.store.assistant.color, width: 2),
                ),
                child: const Center(child: Text('🧑‍🎓', style: TextStyle(fontSize: 20))),
              ),
              const SizedBox(width: 10),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(widget.store.profile?.fullName ?? 'Сен', style: AppTypography.headingSmall),
                Text('Lvl ${widget.store.level}', style: AppTypography.bodySmall),
              ]),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: widget.store.assistant.color.withValues(alpha: .2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: widget.store.assistant.color.withValues(alpha: .4)),
                ),
                child: Text('${_state.myScore}', style: TextStyle(
                  fontSize: 20, fontWeight: FontWeight.w900, color: widget.store.assistant.color)),
              ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _buildOption(int index, BattleQuestion q) {
    final isSelected = _selectedIndex == index;
    final isCorrect = index == q.correctIndex;
    Color bgColor = AppColors.bgDarkCard;
    Color borderColor = AppColors.glassBorder;

    if (_answered) {
      if (isCorrect) {
        bgColor = AppColors.success.withValues(alpha: .2);
        borderColor = AppColors.success;
      } else if (isSelected && !isCorrect) {
        bgColor = AppColors.error.withValues(alpha: .2);
        borderColor = AppColors.error;
      }
    } else if (isSelected) {
      bgColor = widget.store.assistant.color.withValues(alpha: .15);
      borderColor = widget.store.assistant.color;
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onTap: _answered ? null : () => _onAnswer(index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: borderColor, width: 1.5),
          ),
          child: Row(children: [
            Container(
              width: 28, height: 28,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: borderColor.withValues(alpha: .15),
                border: Border.all(color: borderColor),
              ),
              child: Center(child: Text(
                String.fromCharCode(65 + index), // A, B, C, D
                style: TextStyle(fontWeight: FontWeight.bold, color: borderColor, fontSize: 13),
              )),
            ),
            const SizedBox(width: 12),
            Expanded(child: Text(q.options[index], style: AppTypography.bodyLarge)),
            if (_answered && isCorrect)
              const Icon(Icons.check_circle, color: AppColors.success, size: 22),
            if (_answered && isSelected && !isCorrect)
              const Icon(Icons.cancel, color: AppColors.error, size: 22),
          ]),
        ),
      ),
    );
  }
}
