import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../data/models/curriculum.dart';
import '../../../data/store/app_store.dart';
import '../../../widgets/assistant_avatar.dart';
import '../../../widgets/glass_card.dart';

class MultipleChoiceView extends StatefulWidget {
  const MultipleChoiceView({
    required this.question,
    required this.store,
    required this.onAnswerSelected,
    super.key,
  });

  final TaskQuestion question;
  final AppStore store;
  final ValueChanged<bool> onAnswerSelected; // true if correct, false if wrong

  @override
  State<MultipleChoiceView> createState() => _MultipleChoiceViewState();
}

class _MultipleChoiceViewState extends State<MultipleChoiceView>
    with SingleTickerProviderStateMixin {
  int? _selectedIndex;
  bool _isAnswered = false;
  late AnimationController _shakeController;
  late Animation<double> _shakeAnimation;

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _shakeAnimation = Tween<double>(begin: 0.0, end: 12.0)
        .chain(CurveTween(curve: Curves.elasticIn))
        .animate(_shakeController);
  }

  @override
  void dispose() {
    _shakeController.dispose();
    super.dispose();
  }

  void _onOptionTapped(int index) {
    if (_isAnswered) return;

    setState(() {
      _selectedIndex = index;
      _isAnswered = true;
    });

    final isCorrect = index == widget.question.correctIndex;
    if (!isCorrect) {
      _shakeController.forward(from: 0.0);
    }
    widget.onAnswerSelected(isCorrect);
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final isCorrect = _selectedIndex == q.correctIndex;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Question card
          AnimatedBuilder(
            animation: _shakeAnimation,
            builder: (context, child) {
              double offset = 0.0;
              if (_shakeController.isAnimating) {
                // Generate quick shake offset
                offset = (0.5 - ((_shakeController.value * 5) % 1.0)).abs() *
                    _shakeAnimation.value *
                    ( _shakeController.value > 0.5 ? -1 : 1);
              }
              return Transform.translate(
                offset: Offset(offset, 0),
                child: GlassCard(
                  backgroundColor: AppColors.bgDarkSurface.withValues(alpha: .7),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: Text(
                      q.questionText,
                      textAlign: TextAlign.center,
                      style: AppTypography.bodyLarge.copyWith(
                        fontSize: 18,
                        height: 1.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 24),

          // Options list
          ...List.generate(q.options.length, (index) {
            final option = q.options[index];

            Color itemBorder = AppColors.glassBorder;
            Color itemBg = AppColors.bgDarkSurface.withValues(alpha: .5);
            Widget? trailingIcon;

            if (_isAnswered) {
              if (index == q.correctIndex) {
                itemBorder = AppColors.success;
                itemBg = AppColors.success.withValues(alpha: .15);
                trailingIcon = const Icon(Icons.check_circle, color: AppColors.success);
              } else if (index == _selectedIndex) {
                itemBorder = AppColors.error;
                itemBg = AppColors.error.withValues(alpha: .15);
                trailingIcon = const Icon(Icons.cancel, color: AppColors.error);
              }
            } else if (_selectedIndex == index) {
              itemBorder = widget.store.assistant.color;
              itemBg = widget.store.assistant.color.withValues(alpha: .1);
            }

            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: GestureDetector(
                onTap: () => _onOptionTapped(index),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  decoration: BoxDecoration(
                    color: itemBg,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: itemBorder, width: 2),
                    boxShadow: _selectedIndex == index && !_isAnswered
                        ? [
                            BoxShadow(
                              color: widget.store.assistant.color.withValues(alpha: .3),
                              blurRadius: 10,
                              spreadRadius: 1,
                            )
                          ]
                        : [],
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _selectedIndex == index
                              ? (_isAnswered
                                  ? (isCorrect ? AppColors.success : AppColors.error)
                                  : widget.store.assistant.color)
                              : AppColors.bgDarkSurface,
                          border: Border.all(
                            color: _selectedIndex == index
                                ? Colors.transparent
                                : AppColors.glassBorder,
                            width: 1.5,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            String.fromCharCode(65 + index), // A, B, C, D
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              color: _selectedIndex == index ? Colors.white : AppColors.textSecondary,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Text(
                          option,
                          style: AppTypography.bodyMedium.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      ?trailingIcon,
                    ],
                  ),
                ),
              ),
            );
          }),

          const SizedBox(height: 24),

          // Reactive Assistant Character Avatar
          Center(
            child: SizedBox(
              height: 120,
              child: AssistantAvatar(
                assistant: widget.store.assistant,
                size: 110,
                equippedItems: widget.store.equippedItems,
                equippedPet: widget.store.equippedPet,
                equippedBackground: widget.store.equippedBackground,
                mood: !_isAnswered
                    ? 'studying'
                    : (isCorrect ? 'celebrating' : 'sad'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
