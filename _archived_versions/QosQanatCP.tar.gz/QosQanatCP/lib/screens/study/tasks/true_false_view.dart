import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../data/models/curriculum.dart';
import '../../../data/store/app_store.dart';
import '../../../widgets/assistant_avatar.dart';
import '../../../widgets/glass_card.dart';

class TrueFalseView extends StatefulWidget {
  const TrueFalseView({
    required this.question,
    required this.store,
    required this.onAnswerSelected,
    super.key,
  });

  final TaskQuestion question;
  final AppStore store;
  final ValueChanged<bool> onAnswerSelected;

  @override
  State<TrueFalseView> createState() => _TrueFalseViewState();
}

class _TrueFalseViewState extends State<TrueFalseView>
    with SingleTickerProviderStateMixin {
  bool _isAnswered = false;
  bool _isCorrect = false;
  String? _userChoice;

  // Swipe gesture physics state
  double _dragDx = 0.0;
  late AnimationController _animController;
  late Animation<double> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _slideAnimation = Tween<double>(begin: 0.0, end: 0.0).animate(_animController);
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  void _submitChoice(String choice) {
    if (_isAnswered) return;

    final correct = choice == widget.question.correctString;
    setState(() {
      _userChoice = choice;
      _isAnswered = true;
      _isCorrect = correct;
    });

    widget.onAnswerSelected(correct);
  }

  void _onHorizontalDragUpdate(DragUpdateDetails details) {
    if (_isAnswered) return;
    setState(() {
      _dragDx += details.delta.dx;
    });
  }

  void _onHorizontalDragEnd(DragEndDetails details) {
    if (_isAnswered) return;

    // Threshold to register swipe is 100 pixels
    if (_dragDx > 100) {
      // Swiped Right -> TRUE
      _slideOutCard(true);
    } else if (_dragDx < -100) {
      // Swiped Left -> FALSE
      _slideOutCard(false);
    } else {
      // Snap back to center
      setState(() {
        _dragDx = 0;
      });
    }
  }

  void _slideOutCard(bool isTrue) {
    final choice = isTrue ? 'Шындық' : 'Жалған';
    setState(() {
      _userChoice = choice;
    });

    _slideAnimation = Tween<double>(
      begin: _dragDx,
      end: isTrue ? 500.0 : -500.0,
    ).animate(CurvedAnimation(parent: _animController, curve: Curves.easeOut));

    _animController.forward(from: 0.0).then((_) {
      _submitChoice(choice);
    });
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;

    // Calculate rotation and color intensity based on drag position
    final double rotationAngle = (_dragDx / 400).clamp(-0.25, 0.25);
    final double opacity = (_dragDx.abs() / 150).clamp(0.0, 0.8);

    Color swipeGlowColor = Colors.transparent;
    if (_dragDx > 0) {
      swipeGlowColor = AppColors.success.withValues(alpha: opacity);
    } else if (_dragDx < 0) {
      swipeGlowColor = AppColors.error.withValues(alpha: opacity);
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Шындық немесе Жалған? 🤔',
            textAlign: TextAlign.center,
            style: AppTypography.labelMedium.copyWith(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 8),
          Text(
            'Сенімдісіз бе? Сәйкес жаққа сырғытыңыз немесе төмендегі батырмаларды басыңыз!',
            textAlign: TextAlign.center,
            style: AppTypography.bodySmall.copyWith(color: AppColors.textMuted),
          ),
          const SizedBox(height: 24),

          // Interactive Swipeable Statement Card
          GestureDetector(
            onHorizontalDragUpdate: _onHorizontalDragUpdate,
            onHorizontalDragEnd: _onHorizontalDragEnd,
            child: AnimatedBuilder(
              animation: _animController,
              builder: (context, child) {
                final double currentDx =
                    _animController.isAnimating ? _slideAnimation.value : _dragDx;

                return Transform.translate(
                  offset: Offset(currentDx, 0),
                  child: Transform.rotate(
                    angle: rotationAngle,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: [
                          BoxShadow(
                            color: _isAnswered
                                ? (_isCorrect
                                    ? AppColors.success.withValues(alpha: .4)
                                    : AppColors.error.withValues(alpha: .4))
                                : swipeGlowColor,
                            blurRadius: 25,
                            spreadRadius: 2,
                          )
                        ],
                      ),
                      child: GlassCard(
                        backgroundColor: AppColors.bgDarkSurface.withValues(alpha: .8),
                        borderGradient: _isAnswered
                            ? (_isCorrect ? AppColors.successGradient : AppColors.errorGradient)
                            : AppColors.bgGradient,
                        child: Container(
                          height: 180,
                          alignment: Alignment.center,
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          child: Text(
                            q.questionText,
                            textAlign: TextAlign.center,
                            style: AppTypography.bodyLarge.copyWith(
                              fontSize: 18,
                              height: 1.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 32),

          // True / False action buttons
          Row(
            children: [
              // FALSE (Жалған) Button
              Expanded(
                child: GestureDetector(
                  onTap: () => _submitChoice('Жалған'),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      color: _isAnswered && _userChoice == 'Жалған'
                          ? (_isCorrect
                              ? AppColors.success.withValues(alpha: .15)
                              : AppColors.error.withValues(alpha: .15))
                          : AppColors.bgDarkSurface.withValues(alpha: .5),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: _isAnswered && _userChoice == 'Жалған'
                            ? (_isCorrect ? AppColors.success : AppColors.error)
                            : AppColors.error.withValues(alpha: .7),
                        width: 2.5,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.close, color: AppColors.error, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          'ЖАЛҒАН',
                          style: AppTypography.labelMedium.copyWith(
                            color: AppColors.error,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),

              // TRUE (Шындық) Button
              Expanded(
                child: GestureDetector(
                  onTap: () => _submitChoice('Шындық'),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      color: _isAnswered && _userChoice == 'Шындық'
                          ? (_isCorrect
                              ? AppColors.success.withValues(alpha: .15)
                              : AppColors.error.withValues(alpha: .15))
                          : AppColors.bgDarkSurface.withValues(alpha: .5),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: _isAnswered && _userChoice == 'Шындық'
                            ? (_isCorrect ? AppColors.success : AppColors.error)
                            : AppColors.success.withValues(alpha: .7),
                        width: 2.5,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.check, color: AppColors.success, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          'ШЫНДЫҚ',
                          style: AppTypography.labelMedium.copyWith(
                            color: AppColors.success,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // Reactive Assistant Character Avatar
          Center(
            child: SizedBox(
              height: 120,
              child: AssistantAvatar(
                assistant: widget.store.assistant,
                size: 110,
                equippedItems: widget.store.equippedItems,
                equippedPet: widget.store.equippedPet,
                equippedBackground: widget.store.equippedBackground,
                mood: !_isAnswered
                    ? 'thinking'
                    : (_isCorrect ? 'celebrating' : 'sad'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
