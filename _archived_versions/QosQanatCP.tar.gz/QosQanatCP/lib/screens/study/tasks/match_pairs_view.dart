import 'dart:math';
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../data/models/curriculum.dart';
import '../../../data/store/app_store.dart';
import '../../../widgets/assistant_avatar.dart';

class MatchPairsView extends StatefulWidget {
  const MatchPairsView({
    required this.question,
    required this.store,
    required this.onAnswerSelected,
    super.key,
  });

  final TaskQuestion question;
  final AppStore store;
  final ValueChanged<bool> onAnswerSelected;

  @override
  State<MatchPairsView> createState() => _MatchPairsViewState();
}

class _MatchPairsViewState extends State<MatchPairsView> {
  final List<String> _leftItems = [];
  final List<String> _rightItems = [];

  String? _selectedLeft;
  String? _selectedRight;

  final Map<String, String> _completedMatches = {};
  final Set<String> _wrongLefts = {};
  final Set<String> _wrongRights = {};

  bool _isAnswered = false;
  bool _isAllMatched = false;

  @override
  void initState() {
    super.initState();
    // Initialize items and shuffle them to create a real matching puzzle
    final pairs = widget.question.matchingPairs;
    _leftItems.addAll(pairs.keys);
    _rightItems.addAll(pairs.values);

    // Shuffle both columns independently so they are not aligned by default
    final random = Random();
    _leftItems.shuffle(random);
    _rightItems.shuffle(random);
  }

  void _onLeftSelected(String item) {
    if (_isAnswered || _completedMatches.containsKey(item)) return;

    setState(() {
      _selectedLeft = item;
      _wrongLefts.clear();
      _wrongRights.clear();
      _checkMatch();
    });
  }

  void _onRightSelected(String item) {
    if (_isAnswered || _completedMatches.containsValue(item)) return;

    setState(() {
      _selectedRight = item;
      _wrongLefts.clear();
      _wrongRights.clear();
      _checkMatch();
    });
  }

  void _checkMatch() {
    if (_selectedLeft == null || _selectedRight == null) return;

    final pairs = widget.question.matchingPairs;
    final isMatch = pairs[_selectedLeft!] == _selectedRight!;

    if (isMatch) {
      // Record correct match
      _completedMatches[_selectedLeft!] = _selectedRight!;
      _selectedLeft = null;
      _selectedRight = null;

      // Check if all pairs are matched
      if (_completedMatches.length == pairs.length) {
        setState(() {
          _isAllMatched = true;
          _isAnswered = true;
        });
        widget.onAnswerSelected(true);
      }
    } else {
      // Flash red incorrect feedback
      setState(() {
        _wrongLefts.add(_selectedLeft!);
        _wrongRights.add(_selectedRight!);
        _selectedLeft = null;
        _selectedRight = null;
      });

      // Clear wrong feedback after short delay
      Future.delayed(const Duration(milliseconds: 600), () {
        if (mounted) {
          setState(() {
            _wrongLefts.clear();
            _wrongRights.clear();
          });
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            widget.question.questionText,
            textAlign: TextAlign.center,
            style: AppTypography.bodyLarge.copyWith(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 20),

          // Two columns layout
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left Column
              Expanded(
                child: Column(
                  children: _leftItems.map((item) {
                    final isSelected = _selectedLeft == item;
                    final isMatched = _completedMatches.containsKey(item);
                    final isWrong = _wrongLefts.contains(item);

                    Color borderCol = AppColors.glassBorder;
                    Color bgCol = AppColors.bgDarkSurface.withValues(alpha: .5);

                    if (isMatched) {
                      borderCol = AppColors.success;
                      bgCol = AppColors.success.withValues(alpha: .15);
                    } else if (isSelected) {
                      borderCol = widget.store.assistant.color;
                      bgCol = widget.store.assistant.color.withValues(alpha: .1);
                    } else if (isWrong) {
                      borderCol = AppColors.error;
                      bgCol = AppColors.error.withValues(alpha: .15);
                    }

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: GestureDetector(
                        onTap: () => _onLeftSelected(item),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
                          decoration: BoxDecoration(
                            color: bgCol,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: borderCol, width: 2),
                          ),
                          child: Center(
                            child: Text(
                              item,
                              textAlign: TextAlign.center,
                              style: AppTypography.bodySmall.copyWith(
                                color: isMatched ? AppColors.success : Colors.white,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),

              const SizedBox(width: 12),

              // Divider arrow / icon column
              const Padding(
                padding: EdgeInsets.only(top: 80),
                child: Icon(Icons.swap_horiz, color: AppColors.textMuted, size: 24),
              ),

              const SizedBox(width: 12),

              // Right Column
              Expanded(
                child: Column(
                  children: _rightItems.map((item) {
                    final isSelected = _selectedRight == item;
                    final isMatched = _completedMatches.containsValue(item);
                    final isWrong = _wrongRights.contains(item);

                    Color borderCol = AppColors.glassBorder;
                    Color bgCol = AppColors.bgDarkSurface.withValues(alpha: .5);

                    if (isMatched) {
                      borderCol = AppColors.success;
                      bgCol = AppColors.success.withValues(alpha: .15);
                    } else if (isSelected) {
                      borderCol = widget.store.assistant.color;
                      bgCol = widget.store.assistant.color.withValues(alpha: .1);
                    } else if (isWrong) {
                      borderCol = AppColors.error;
                      bgCol = AppColors.error.withValues(alpha: .15);
                    }

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: GestureDetector(
                        onTap: () => _onRightSelected(item),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
                          decoration: BoxDecoration(
                            color: bgCol,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: borderCol, width: 2),
                          ),
                          child: Center(
                            child: Text(
                              item,
                              textAlign: TextAlign.center,
                              style: AppTypography.bodySmall.copyWith(
                                color: isMatched ? AppColors.success : Colors.white,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // Reactive Assistant Character Avatar
          Center(
            child: SizedBox(
              height: 120,
              child: AssistantAvatar(
                assistant: widget.store.assistant,
                size: 110,
                equippedItems: widget.store.equippedItems,
                equippedPet: widget.store.equippedPet,
                equippedBackground: widget.store.equippedBackground,
                mood: !_isAnswered
                    ? 'studying'
                    : (_isAllMatched ? 'celebrating' : 'sad'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
