import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../data/models/curriculum.dart';
import '../../../data/store/app_store.dart';
import '../../../widgets/assistant_avatar.dart';
import '../../../widgets/glass_card.dart';
import '../../../widgets/glow_button.dart';

class FillInBlankView extends StatefulWidget {
  const FillInBlankView({
    required this.question,
    required this.store,
    required this.onAnswerSelected,
    super.key,
  });

  final TaskQuestion question;
  final AppStore store;
  final ValueChanged<bool> onAnswerSelected;

  @override
  State<FillInBlankView> createState() => _FillInBlankViewState();
}

class _FillInBlankViewState extends State<FillInBlankView> {
  String? _selectedWord;
  bool _isAnswered = false;
  bool _isCorrect = false;

  void _onWordSelected(String word) {
    if (_isAnswered) return;
    setState(() {
      if (_selectedWord == word) {
        _selectedWord = null; // Unselect
      } else {
        _selectedWord = word;
      }
    });
  }

  void _verifyAnswer() {
    if (_selectedWord == null || _isAnswered) return;

    final correct = _selectedWord == widget.question.correctString;
    setState(() {
      _isAnswered = true;
      _isCorrect = correct;
    });

    widget.onAnswerSelected(correct);
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final options = q.options;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Question card with blank representation
          GlassCard(
            backgroundColor: AppColors.bgDarkSurface.withValues(alpha: .7),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Text(
                    'Бос орынды толтырыңыз:',
                    style: AppTypography.labelSmall.copyWith(
                      color: widget.store.assistant.color,
                      letterSpacing: 1.0,
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Sentence with interactive blank block
                  Wrap(
                    alignment: WrapAlignment.center,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    spacing: 8.0,
                    runSpacing: 8.0,
                    children: [
                      ...q.questionText.split(' ').map((word) {
                        if (word.contains('___')) {
                          return IntrinsicWidth(
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 250),
                              constraints: const BoxConstraints(minWidth: 90),
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: _selectedWord != null
                                    ? (_isAnswered
                                        ? (_isCorrect
                                            ? AppColors.success.withValues(alpha: .2)
                                            : AppColors.error.withValues(alpha: .2))
                                        : widget.store.assistant.color.withValues(alpha: .15))
                                    : AppColors.bgDarkSurface,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: _selectedWord != null
                                      ? (_isAnswered
                                          ? (_isCorrect ? AppColors.success : AppColors.error)
                                          : widget.store.assistant.color)
                                      : AppColors.glassBorder,
                                  width: 2,
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  _selectedWord ?? ' бос орын ',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: _selectedWord != null
                                        ? Colors.white
                                        : AppColors.textMuted,
                                  ),
                                ),
                              ),
                            ),
                          );
                        }
                        return Text(
                          word,
                          style: AppTypography.bodyLarge.copyWith(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        );
                      }),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 32),

          // Word Bank pill cards
          Text(
            'Сөз банкі:',
            textAlign: TextAlign.center,
            style: AppTypography.labelMedium.copyWith(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 12),
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: options.map((word) {
              final isChosen = _selectedWord == word;
              Color itemBorder = AppColors.glassBorder;
              Color itemBg = AppColors.bgDarkSurface.withValues(alpha: .5);

              if (isChosen) {
                itemBorder = widget.store.assistant.color;
                itemBg = widget.store.assistant.color.withValues(alpha: .2);
              }

              return GestureDetector(
                onTap: () => _onWordSelected(word),
                child: Opacity(
                  opacity: _isAnswered && !isChosen ? 0.4 : 1.0,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                    decoration: BoxDecoration(
                      color: itemBg,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: itemBorder, width: 1.5),
                    ),
                    child: Text(
                      word,
                      style: AppTypography.bodyMedium.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 32),

          // Action verification button
          if (!_isAnswered)
            Center(
              child: GlowButton(
                label: 'Тексеру 🔍',
                color: _selectedWord != null
                    ? widget.store.assistant.color
                    : AppColors.bgDarkElevated,
                glowColor: _selectedWord != null
                    ? widget.store.assistant.color.withValues(alpha: .4)
                    : Colors.transparent,
                onPressed: _selectedWord != null ? _verifyAnswer : () {},
              ),
            ),

          const SizedBox(height: 24),

          // Reactive Assistant Character Avatar
          Center(
            child: SizedBox(
              height: 120,
              child: AssistantAvatar(
                assistant: widget.store.assistant,
                size: 110,
                equippedItems: widget.store.equippedItems,
                equippedPet: widget.store.equippedPet,
                equippedBackground: widget.store.equippedBackground,
                mood: !_isAnswered
                    ? 'studying'
                    : (_isCorrect ? 'celebrating' : 'sad'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
