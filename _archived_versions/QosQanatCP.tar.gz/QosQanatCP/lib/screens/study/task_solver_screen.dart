import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/models/curriculum.dart';
import '../../data/store/app_store.dart';
import '../../widgets/animated_counter.dart';
import '../../widgets/floating_reward_toast.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';
import 'tasks/fill_in_blank_view.dart';
import 'tasks/match_pairs_view.dart';
import 'tasks/multiple_choice_view.dart';
import 'tasks/true_false_view.dart';

class TaskSolverScreen extends StatefulWidget {
  const TaskSolverScreen({
    required this.node,
    required this.store,
    super.key,
  });

  final CurriculumNode node;
  final AppStore store;

  @override
  State<TaskSolverScreen> createState() => _TaskSolverScreenState();
}

class _QustionState {
  _QustionState({
    required this.isCorrect,
    required this.isAnswered,
  });
  bool isCorrect;
  bool isAnswered;
}

class _TaskSolverScreenState extends State<TaskSolverScreen> {
  int _currentIndex = 0;
  int _correctAnswersCount = 0;
  bool _isNodeFinished = false;

  late List<_QustionState> _questionStates;
  bool _currentQuestionCorrect = false;
  bool _currentQuestionAnswered = false;

  @override
  void initState() {
    super.initState();
    _questionStates = List.generate(
      widget.node.questions.length,
      (index) => _QustionState(isCorrect: false, isAnswered: false),
    );
  }

  void _onAnswerEvaluated(bool isCorrect) {
    setState(() {
      _currentQuestionAnswered = true;
      _currentQuestionCorrect = isCorrect;
      _questionStates[_currentIndex].isAnswered = true;
      _questionStates[_currentIndex].isCorrect = isCorrect;

      if (isCorrect) {
        _correctAnswersCount++;
        // Emit high-fidelity reward toast immediately for tactile delight
        FloatingRewardToast.show(
          context,
          rewardText: 'ДҰРЫС! +${widget.node.xpReward ~/ widget.node.questions.length} XP',
          iconText: '⚡',
          color: AppColors.exp,
        );
      } else {
        widget.store.recordWrongAnswer();
        FloatingRewardToast.show(
          context,
          rewardText: 'ҚАТЕ! Тәжірибе +2',
          iconText: '💔',
          color: AppColors.error,
        );
      }
    });
  }

  void _proceedToNext() {
    if (_currentIndex < widget.node.questions.length - 1) {
      setState(() {
        _currentIndex++;
        _currentQuestionAnswered = false;
        _currentQuestionCorrect = false;
      });
    } else {
      // Finished all questions in the node
      setState(() {
        _isNodeFinished = true;
      });
      // Register completion & trigger rewards inside store
      widget.store.completeCurriculumNode(widget.node);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isNodeFinished) {
      return _buildFinishedCelebrationScreen();
    }

    final question = widget.node.questions[_currentIndex];
    final progress = (_currentIndex + 1) / widget.node.questions.length;

    return Scaffold(
      backgroundColor: AppColors.bgDarkCard,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          children: [
            Text(
              widget.node.title,
              style: AppTypography.headingSmall.copyWith(fontSize: 14),
            ),
            const SizedBox(height: 6),
            // Progress Bar
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 6,
                backgroundColor: AppColors.bgDarkSurface,
                valueColor: AlwaysStoppedAnimation<Color>(widget.store.assistant.color),
              ),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: Center(
              child: Text(
                '${_currentIndex + 1}/${widget.node.questions.length}',
                style: AppTypography.labelMedium.copyWith(color: AppColors.textSecondary),
              ),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          // Background soft gradient glowing highlights
          Positioned(
            top: -100,
            left: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.store.assistant.color.withValues(alpha: .15),
                boxShadow: [
                  BoxShadow(
                    color: widget.store.assistant.color.withValues(alpha: .1),
                    blurRadius: 60,
                    spreadRadius: 30,
                  ),
                ],
              ),
            ),
          ),

          // Main question content
          Column(
            children: [
              const SizedBox(height: 16),
              Expanded(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.only(bottom: 120),
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 350),
                    transitionBuilder: (child, animation) {
                      return SlideTransition(
                        position: Tween<Offset>(
                          begin: const Offset(1.0, 0.0),
                          end: Offset.zero,
                        ).animate(CurvedAnimation(parent: animation, curve: Curves.easeInOutCubic)),
                        child: child,
                      );
                    },
                    child: KeyedSubtree(
                      key: ValueKey<int>(_currentIndex),
                      child: _buildSolverForType(question),
                    ),
                  ),
                ),
              ),
            ],
          ),

          // Bottom verification overlay drawer
          if (_currentQuestionAnswered)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: TweenAnimationBuilder<Offset>(
                tween: Tween<Offset>(
                  begin: const Offset(0.0, 1.0),
                  end: Offset.zero,
                ),
                duration: const Duration(milliseconds: 350),
                curve: Curves.easeOutBack,
                builder: (context, offset, child) {
                  return FractionalTranslation(
                    translation: offset,
                    child: child,
                  );
                },
                child: _buildVerificationPanel(question),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSolverForType(TaskQuestion question) {
    switch (question.type) {
      case TaskType.multipleChoice:
        return MultipleChoiceView(
          question: question,
          store: widget.store,
          onAnswerSelected: _onAnswerEvaluated,
        );
      case TaskType.fillBlank:
        return FillInBlankView(
          question: question,
          store: widget.store,
          onAnswerSelected: _onAnswerEvaluated,
        );
      case TaskType.matchPairs:
        return MatchPairsView(
          question: question,
          store: widget.store,
          onAnswerSelected: _onAnswerEvaluated,
        );
      case TaskType.trueFalse:
        return TrueFalseView(
          question: question,
          store: widget.store,
          onAnswerSelected: _onAnswerEvaluated,
        );
    }
  }

  Widget _buildVerificationPanel(TaskQuestion question) {
    final themeColor = _currentQuestionCorrect ? AppColors.success : AppColors.error;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      decoration: BoxDecoration(
        color: AppColors.bgDarkElevated.withValues(alpha: .98),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        border: Border(
          top: BorderSide(
            color: themeColor.withValues(alpha: .4),
            width: 2.0,
          ),
        ),
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(
                  _currentQuestionCorrect ? Icons.stars : Icons.info_outline,
                  color: themeColor,
                  size: 28,
                ),
                const SizedBox(width: 12),
                Text(
                  _currentQuestionCorrect ? 'ӨТЕ КЕРЕМЕТ! 🎉' : 'ДҰРЫС ЖАУАП ЕМЕС',
                  style: AppTypography.headingMedium.copyWith(
                    color: themeColor,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              question.explanation.isNotEmpty
                  ? question.explanation
                  : 'Сұрақтың шешімі мен ережесін оқулықтан қайталауды ұсынамыз.',
              style: AppTypography.bodySmall.copyWith(
                color: Colors.white.withValues(alpha: .9),
                height: 1.4,
              ),
            ),
            const SizedBox(height: 24),
            GlowButton(
              label: 'Жалғастыру 🪽',
              color: themeColor,
              glowColor: themeColor.withValues(alpha: .3),
              onPressed: _proceedToNext,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFinishedCelebrationScreen() {
    final n = widget.node;
    final totalRewardCoins = n.coinReward;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        alignment: Alignment.center,
        children: [
          // Golden radiant beams in background
          Positioned.fill(
            child: Opacity(
              opacity: 0.15,
              child: Image.network(
                'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=600',
                fit: BoxFit.cover,
              ),
            ),
          ),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Text(
                    'КЕЗЕҢДІ БАҒЫНДЫРДЫҢЫЗ! 🪽',
                    style: TextStyle(
                      fontSize: 14,
                      color: AppColors.neonGold,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.0,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    n.title,
                    textAlign: TextAlign.center,
                    style: AppTypography.displayLarge.copyWith(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Giant Celebration Icon
                  TweenAnimationBuilder<double>(
                    tween: Tween<double>(begin: 0.0, end: 1.0),
                    duration: const Duration(seconds: 1),
                    curve: Curves.elasticOut,
                    builder: (context, scale, child) {
                      return Transform.scale(
                        scale: scale,
                        child: Container(
                          width: 140,
                          height: 140,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              colors: [Colors.amber, Colors.orangeAccent],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.orange.withValues(alpha: .5),
                                blurRadius: 40,
                                spreadRadius: 5,
                              )
                            ],
                          ),
                          child: const Icon(
                            Icons.emoji_events,
                            color: Colors.white,
                            size: 72,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 48),

                  // Rewards listing cards
                  GlassCard(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildRewardIndicator('💎 Ақыл', n.akylReward, AppColors.wisdom),
                        _buildRewardIndicator('🪙 Монета', totalRewardCoins, AppColors.coin),
                        _buildRewardIndicator('⚡ Тәжірибе', n.xpReward, AppColors.exp),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Дұрыс сұрақтар саны: $_correctAnswersCount / ${n.questions.length}',
                    style: AppTypography.bodySmall.copyWith(color: AppColors.textMuted),
                  ),

                  const SizedBox(height: 60),

                  // Complete button
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 280),
                    child: GlowButton(
                      label: 'Мәссаған! 🎉',
                      color: AppColors.neonGold,
                      glowColor: AppColors.neonGold.withValues(alpha: .4),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRewardIndicator(String label, int val, Color color) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedCounter(
          value: val,
          prefix: '+',
          style: AppTypography.headingLarge.copyWith(color: color, fontSize: 24),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: AppTypography.labelMedium.copyWith(color: AppColors.textSecondary),
        ),
      ],
    );
  }
}
