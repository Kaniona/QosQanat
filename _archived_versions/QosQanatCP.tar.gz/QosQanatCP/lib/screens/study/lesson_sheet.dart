import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/models/game_models.dart';
import '../../data/models/lesson_node.dart';
import '../../data/store/app_store.dart';
import '../../widgets/animated_counter.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';

class LessonSheet extends StatefulWidget {
  const LessonSheet({
    required this.lesson,
    required this.store,
    super.key,
  });

  final LessonNode lesson;
  final AppStore store;

  @override
  State<LessonSheet> createState() => _LessonSheetState();
}

class _LessonSheetState extends State<LessonSheet> {
  int? _selectedIndex;
  bool _isAnswered = false;
  int _secondsLeft = 30;
  Timer? _timer;
  bool _timeOut = false;

  @override
  void initState() {
    super.initState();
    _secondsLeft = widget.lesson.timeLimit;
    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (_secondsLeft > 0) {
        setState(() {
          _secondsLeft--;
        });
      } else {
        _timer?.cancel();
        setState(() {
          _timeOut = true;
          _isAnswered = true;
        });
        widget.store.recordWrongAnswer();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _selectOption(int index) {
    if (_isAnswered) return;
    _timer?.cancel();

    setState(() {
      _selectedIndex = index;
      _isAnswered = true;
    });

    final isCorrect = index == widget.lesson.correctIndex;
    if (isCorrect) {
      final reward = widget.store.completeLesson(widget.lesson);
      _showRewardDialog(reward);
    } else {
      widget.store.recordWrongAnswer();
    }
  }

  void _showRewardDialog(LessonReward reward) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          title: Center(
            child: Text(
              reward.leveledUp ? 'ЖАҢА ДЕҢГЕЙ! 🎉' : 'КЕРЕМЕТ! 🚀',
              style: AppTypography.headingLarge.copyWith(color: AppColors.neonGold),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.stars, color: AppColors.neonGold, size: 64),
              const SizedBox(height: 16),
              const Text(
                'Тапсырма сәтті аяқталды!',
                textAlign: TextAlign.center,
                style: AppTypography.bodyLarge,
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildRewardIndicator('💎 Ақыл', reward.wisdom, AppColors.wisdom),
                  _buildRewardIndicator('🪙 Монета', reward.coins, AppColors.coin),
                  _buildRewardIndicator('⚡ Тәжірибе', reward.exp, AppColors.exp),
                ],
              ),
            ],
          ),
          actions: [
            Center(
              child: GlowButton(
                label: 'Жалғастыру 🪽',
                color: widget.store.assistant.color,
                onPressed: () {
                  Navigator.pop(context); // Close dialog
                  Navigator.pop(context); // Close sheet
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildRewardIndicator(String label, int val, Color color) {
    return Column(
      children: [
        AnimatedCounter(
          value: val,
          prefix: '+',
          style: AppTypography.headingMedium.copyWith(color: color),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: AppTypography.bodySmall,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final lesson = widget.lesson;
    final isCorrect = _selectedIndex == lesson.correctIndex;

    return Container(
      padding: EdgeInsets.fromLTRB(16, 20, 16, MediaQuery.of(context).viewInsets.bottom + 30),
      decoration: const BoxDecoration(
        color: AppColors.bgDarkCard,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Head indicators
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: widget.store.assistant.color.withValues(alpha: .15),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    lesson.subject,
                    style: AppTypography.labelSmall.copyWith(
                      color: widget.store.assistant.color,
                    ),
                  ),
                ),
                // Time progress limit gauge
                Row(
                  children: [
                    const Icon(Icons.timer, color: AppColors.neonMagenta, size: 18),
                    const SizedBox(width: 4),
                    Text(
                      '$_secondsLeft c',
                      style: AppTypography.labelMedium.copyWith(
                        color: _secondsLeft < 10 ? AppColors.neonMagenta : Colors.white,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              lesson.title,
              style: AppTypography.displaySmall,
            ),
            const SizedBox(height: 16),

            // Question Container
            GlassCard(
              backgroundColor: AppColors.bgDarkSurface,
              child: Text(
                lesson.question,
                style: AppTypography.bodyLarge.copyWith(height: 1.4),
              ),
            ),
            const SizedBox(height: 20),

            // Multiple Choice Options list
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: lesson.options.length,
              itemBuilder: (context, index) {
                final option = lesson.options[index];

                Color itemBorder = AppColors.glassBorder;
                Color itemBg = AppColors.bgDarkSurface;

                if (_isAnswered) {
                  if (index == lesson.correctIndex) {
                    itemBorder = AppColors.success;
                    itemBg = AppColors.success.withValues(alpha: .15);
                  } else if (index == _selectedIndex) {
                    itemBorder = AppColors.error;
                    itemBg = AppColors.error.withValues(alpha: .15);
                  }
                } else if (_selectedIndex == index) {
                  itemBorder = widget.store.assistant.color;
                  itemBg = widget.store.assistant.color.withValues(alpha: .1);
                }

                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: GestureDetector(
                    onTap: () => _selectOption(index),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(
                        color: itemBg,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: itemBorder, width: 1.5),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              option,
                              style: AppTypography.bodyMedium.copyWith(color: Colors.white),
                            ),
                          ),
                          if (_isAnswered && index == lesson.correctIndex)
                            const Icon(Icons.check_circle, color: AppColors.success)
                          else if (_isAnswered && index == _selectedIndex)
                            const Icon(Icons.cancel, color: AppColors.error),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),

            // Explanatory Review panel
            if (_isAnswered) ...[
              const SizedBox(height: 16),
              GlassCard(
                borderGradient: isCorrect ? AppColors.successGradient : AppColors.bgGradient,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isCorrect ? 'ДҰРЫС ШЕШІМ! 🌟' : (_timeOut ? 'УАҚЫТ АЯҚТАЛДЫ! ⏰' : 'ҚАТЕ ШЕШІМ'),
                      style: AppTypography.headingSmall.copyWith(
                        color: isCorrect ? AppColors.success : AppColors.error,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      lesson.explanation.isNotEmpty
                          ? lesson.explanation
                          : 'Оқулықты қайта қарап шығуды ұсынамыз.',
                      style: AppTypography.bodySmall.copyWith(color: AppColors.textPrimary),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Center(
                child: GlowButton(
                  label: 'Жабу 🪽',
                  color: widget.store.assistant.color,
                  onPressed: () => Navigator.pop(context),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
