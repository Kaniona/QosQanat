import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/content/curriculum_data.dart';
import '../../data/models/curriculum.dart';
import '../../data/store/app_store.dart';
import '../../widgets/app_page.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';
import 'task_solver_screen.dart';

class StudyScreen extends StatefulWidget {
  const StudyScreen({required this.store, super.key});

  final AppStore store;

  @override
  State<StudyScreen> createState() => _StudyScreenState();
}

class _StudyScreenState extends State<StudyScreen> with SingleTickerProviderStateMixin {
  String _selectedSubjectId = 'math';

  Subject get _currentSubject {
    return curriculum.firstWhere(
      (s) => s.id == _selectedSubjectId,
      orElse: () => curriculum.first,
    );
  }

  List<CurriculumNode> get _allNodes {
    final List<CurriculumNode> nodesList = [];
    for (final chapter in _currentSubject.chapters) {
      nodesList.addAll(chapter.nodes);
    }
    return nodesList;
  }

  void _openNodePreview(CurriculumNode node) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _NodePreviewSheet(
        node: node,
        store: widget.store,
        subjectColor: _getSubjectColor(),
      ),
    );
  }

  void _showLockedMessage() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: AppColors.error,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        content: Row(
          children: [
            const Icon(Icons.lock, color: Colors.white),
            const SizedBox(width: 12),
            Text(
              'Алдыңғы тапсырманы аяқтаңыз! 🔒',
              style: AppTypography.bodySmall.copyWith(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }

  Color _getSubjectColor() {
    final hexColor = _currentSubject.colorHex.replaceAll('#', '0xFF');
    return Color(int.parse(hexColor));
  }

  @override
  Widget build(BuildContext context) {
    final subjectColor = _getSubjectColor();
    final nodes = _allNodes;

    return ListenableBuilder(
      listenable: widget.store,
      builder: (context, _) {
        return AppPage(
          title: 'Оқу Картасы 🗺️',
          subtitle: 'Duolingo-стиліндегі оқу аралдары арқылы Қазақстан мектеп бағдарламасын бағындырыңыз.',
          child: Column(
            children: [
              // Subjects list bar
              SizedBox(
                height: 56,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: curriculum.length,
                  physics: const BouncingScrollPhysics(),
                  separatorBuilder: (context, index) => const SizedBox(width: 10),
                  itemBuilder: (context, index) {
                    final subj = curriculum[index];
                    final isSel = _selectedSubjectId == subj.id;
                    final color = Color(int.parse(subj.colorHex.replaceAll('#', '0xFF')));

                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedSubjectId = subj.id;
                        });
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: isSel ? color.withValues(alpha: .2) : AppColors.bgDarkCard,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: isSel ? color : AppColors.glassBorder,
                            width: 2,
                          ),
                          boxShadow: isSel
                              ? [
                                  BoxShadow(
                                    color: color.withValues(alpha: .25),
                                    blurRadius: 10,
                                  )
                                ]
                              : [],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              subj.icon,
                              style: const TextStyle(fontSize: 18),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              subj.name,
                              style: AppTypography.labelMedium.copyWith(
                                color: isSel ? Colors.white : AppColors.textSecondary,
                                fontWeight: isSel ? FontWeight.w900 : FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 24),

              // Scrollable organic zig-zag path map
              Stack(
                children: [
                  // Dotted connecting path painter
                  Positioned.fill(
                    child: CustomPaint(
                      painter: _DottedPathPainter(
                        nodeCount: nodes.length,
                        pathColor: subjectColor,
                      ),
                    ),
                  ),

                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: nodes.length,
                    itemBuilder: (context, index) {
                      final node = nodes[index];

                      // Determine states
                      final isCompleted = widget.store.completedCurriculumNodes.contains(node.id);
                      final isCurrent = !isCompleted &&
                          (index == 0 ||
                              widget.store.completedCurriculumNodes.contains(nodes[index - 1].id));
                      final isLocked = !isCompleted && !isCurrent;

                      // Alternating zig-zag alignments
                      Alignment alignment = Alignment.center;
                      if (index % 4 == 0) {
                        alignment = Alignment.centerLeft;
                      } else if (index % 4 == 2) {
                        alignment = Alignment.centerRight;
                      }

                      return Container(
                        margin: const EdgeInsets.symmetric(vertical: 36, horizontal: 24),
                        child: Align(
                          alignment: alignment,
                          child: _buildMapNodeItem(
                            node: node,
                            isCompleted: isCompleted,
                            isCurrent: isCurrent,
                            isLocked: isLocked,
                            subjectColor: subjectColor,
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildMapNodeItem({
    required CurriculumNode node,
    required bool isCompleted,
    required bool isCurrent,
    required bool isLocked,
    required Color subjectColor,
  }) {
    IconData icon;
    switch (node.type) {
      case CurriculumNodeType.quiz:
        icon = Icons.flash_on;
        break;
      case CurriculumNodeType.boss:
        icon = Icons.emoji_events;
        break;
      case CurriculumNodeType.treasure:
        icon = Icons.card_giftcard;
        break;
      case CurriculumNodeType.lesson:
        icon = Icons.menu_book;
        break;
    }

    if (isLocked) {
      icon = Icons.lock;
    }

    final double nodeSize = node.type == CurriculumNodeType.boss ? 80 : 70;

    return GestureDetector(
      onTap: isLocked ? _showLockedMessage : () => _openNodePreview(node),
      child: Stack(
        alignment: Alignment.center,
        clipBehavior: Clip.none,
        children: [
          // Pulse halo ring if current active available node
          if (isCurrent) _buildPulseHalo(subjectColor),

          // Circle Node Container
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: nodeSize,
            height: nodeSize,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isLocked
                  ? AppColors.bgDarkElevated
                  : (isCompleted
                      ? AppColors.success.withValues(alpha: .25)
                      : subjectColor.withValues(alpha: .3)),
              border: Border.all(
                color: isLocked
                    ? AppColors.glassBorder
                    : (isCompleted ? AppColors.success : subjectColor),
                width: isCurrent ? 3.5 : 2.0,
              ),
              boxShadow: isCurrent
                  ? [
                      BoxShadow(
                        color: subjectColor.withValues(alpha: .5),
                        blurRadius: 20,
                        spreadRadius: 2,
                      )
                    ]
                  : [],
            ),
            child: Center(
              child: Icon(
                icon,
                color: isLocked
                    ? AppColors.textMuted
                    : (isCompleted ? AppColors.success : Colors.white),
                size: node.type == CurriculumNodeType.boss ? 34 : 26,
              ),
            ),
          ),

          // Unlocks / Checkmark badge tag
          if (isCompleted)
            Positioned(
              bottom: -4,
              right: -4,
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: const BoxDecoration(
                  color: AppColors.success,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.check,
                  size: 12,
                  color: Colors.white,
                ),
              ),
            ),

          // Title banner label
          Positioned(
            bottom: -32,
            child: SizedBox(
              width: 150,
              child: Text(
                node.title,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppTypography.labelSmall.copyWith(
                  color: isLocked
                      ? AppColors.textMuted
                      : (isCurrent ? Colors.white : AppColors.textSecondary),
                  fontWeight: isCurrent ? FontWeight.w900 : FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPulseHalo(Color color) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 1.0, end: 1.35),
      duration: const Duration(milliseconds: 1200),
      curve: Curves.easeInOut,
      builder: (context, value, child) {
        return Container(
          width: 82 * value,
          height: 82 * value,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: color.withValues(alpha: (1.35 - value).clamp(0.0, 1.0)),
              width: 2.0,
            ),
          ),
        );
      },
    );
  }
}

class _DottedPathPainter extends CustomPainter {
  _DottedPathPainter({
    required this.nodeCount,
    required this.pathColor,
  });

  final int nodeCount;
  final Color pathColor;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = pathColor.withValues(alpha: .3)
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final path = Path();
    final stepY = size.height / (nodeCount + 1);

    // Initial point
    path.moveTo(size.width / 2, 24);

    for (int i = 0; i < nodeCount; i++) {
      final y = stepY * (i + 1.25);
      double x = size.width / 2;

      if (i % 4 == 0) {
        x = 55;
      } else if (i % 4 == 2) {
        x = size.width - 55;
      }

      if (i == 0) {
        path.lineTo(x, y);
      } else {
        final prevY = stepY * (i + 0.25);
        double prevX = size.width / 2;
        if ((i - 1) % 4 == 0) prevX = 55;
        if ((i - 1) % 4 == 2) prevX = size.width - 55;

        path.cubicTo(
          prevX,
          prevY + stepY * 0.5,
          x,
          y - stepY * 0.5,
          x,
          y,
        );
      }
    }

    // Convert solid path to premium dotted/dashed path
    final dashPath = _buildDashedPath(path, 8.0, 6.0);
    canvas.drawPath(dashPath, paint);
  }

  Path _buildDashedPath(Path source, double dashWidth, double dashGap) {
    final Path dest = Path();
    for (final PathMetric metric in source.computeMetrics()) {
      double distance = 0.0;
      bool draw = true;
      while (distance < metric.length) {
        final double len = draw ? dashWidth : dashGap;
        if (draw) {
          dest.addPath(
            metric.extractPath(distance, min(distance + len, metric.length)),
            Offset.zero,
          );
        }
        distance += len;
        draw = !draw;
      }
    }
    return dest;
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class _NodePreviewSheet extends StatelessWidget {
  const _NodePreviewSheet({
    required this.node,
    required this.store,
    required this.subjectColor,
  });

  final CurriculumNode node;
  final AppStore store;
  final Color subjectColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(20, 24, 20, MediaQuery.of(context).viewInsets.bottom + 36),
      decoration: const BoxDecoration(
        color: AppColors.bgDarkCard,
        borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        boxShadow: [
          BoxShadow(
            color: Colors.black54,
            blurRadius: 20,
            spreadRadius: 2,
          )
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 50,
              height: 5,
              decoration: BoxDecoration(
                color: AppColors.glassBorder,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Header details
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: subjectColor.withValues(alpha: .2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  node.type.name.toUpperCase(),
                  style: AppTypography.labelSmall.copyWith(color: subjectColor, fontWeight: FontWeight.bold),
                ),
              ),
              const Spacer(),
              Row(
                children: [
                  const Icon(Icons.help_outline, color: AppColors.textMuted, size: 16),
                  const SizedBox(width: 4),
                  Text(
                    '${node.questions.length} сұрақ',
                    style: AppTypography.bodySmall.copyWith(color: AppColors.textSecondary),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            node.title,
            style: AppTypography.headingLarge.copyWith(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),

          // Rewards detail panel
          GlassCard(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildRewardBadge('💎 Ақыл', node.akylReward, AppColors.wisdom),
                _buildRewardBadge('🪙 Монета', node.coinReward, AppColors.coin),
                _buildRewardBadge('⚡ Тәжірибе', node.xpReward, AppColors.exp),
              ],
            ),
          ),
          const SizedBox(height: 28),

          // Start action button
          GlowButton(
            label: 'Бастау! 🚀',
            color: subjectColor,
            glowColor: subjectColor.withValues(alpha: .4),
            onPressed: () {
              Navigator.pop(context); // Close preview sheet
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TaskSolverScreen(
                    node: node,
                    store: store,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildRewardBadge(String label, int val, Color color) {
    return Column(
      children: [
        Text(
          '+$val',
          style: AppTypography.headingLarge.copyWith(color: color, fontSize: 20),
        ),
        const SizedBox(height: 4),
        Text(label, style: AppTypography.labelSmall.copyWith(color: AppColors.textSecondary)),
      ],
    );
  }
}
