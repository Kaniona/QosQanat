import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/store/app_store.dart';
import '../../widgets/app_page.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({required this.store, super.key});
  final AppStore store;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _battleInvites = true;
  bool _dailyReminders = true;
  bool _soundEffects = true;
  String _selectedLanguage = 'KK'; // 'KK' or 'RU'

  void _showResetConfirm() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Профильді жою? ⚠️'),
          content: const Text(
            'Бұл әрекет сіздің барлық жетістіктеріңізді, жиналған монеталар мен сатып алынған киімдерді толық жояды. Қайта тіркелу қажет болады. Жалғастырамыз ба?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Бас тарту'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              onPressed: () {
                Navigator.pop(context); // Dialog
                Navigator.pop(context); // SettingsScreen
                widget.store.resetProfile();
              },
              child: const Text('Иә, жою', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.store.assistant.color;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AppPage(
        title: 'Баптаулар ⚙️',
        subtitle: 'Қосымша параметрлерін реттеу',
        child: Column(
          children: [
            // Sound & Language Card
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Жалпы', style: AppTypography.headingMedium),
                  const SizedBox(height: 12),
                  // Language Selection
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.language, color: AppColors.neonCyan),
                          const SizedBox(width: 12),
                          Text('Тіл / Язык', style: AppTypography.bodyLarge),
                        ],
                      ),
                      Row(
                        children: [
                          _buildLanguageBtn('KK', 'Қазақша'),
                          const SizedBox(width: 6),
                          _buildLanguageBtn('RU', 'Русский'),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  const Divider(color: AppColors.glassBorder, height: 1),
                  const SizedBox(height: 14),
                  // Sound FX Toggle
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.volume_up, color: AppColors.neonPurple),
                          const SizedBox(width: 12),
                          Text('Дыбыс әсерлері', style: AppTypography.bodyLarge),
                        ],
                      ),
                      Switch.adaptive(
                        activeColor: color,
                        value: _soundEffects,
                        onChanged: (val) => setState(() => _soundEffects = val),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Notification preferences card
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Хабарландырулар', style: AppTypography.headingMedium),
                  const SizedBox(height: 12),
                  // Battle Invites Toggle
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.emoji_events, color: AppColors.neonMagenta),
                          const SizedBox(width: 12),
                          const Text('Батл шақырулары', style: AppTypography.bodyLarge),
                        ],
                      ),
                      Switch.adaptive(
                        activeColor: color,
                        value: _battleInvites,
                        onChanged: (val) => setState(() => _battleInvites = val),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  // Daily Reminders Toggle
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.notifications_active, color: AppColors.warning),
                          const SizedBox(width: 12),
                          Text('Күнделікті ескертулер', style: AppTypography.bodyLarge),
                        ],
                      ),
                      Switch.adaptive(
                        activeColor: color,
                        value: _dailyReminders,
                        onChanged: (val) => setState(() => _dailyReminders = val),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Account & App Info Card
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Қосымша туралы', style: AppTypography.headingMedium),
                  const SizedBox(height: 14),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Нұсқасы (Version)', style: AppTypography.bodyLarge),
                      Text('2.1.0', style: AppTypography.bodyMedium.copyWith(color: AppColors.textMuted)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Жасақтаушылар', style: AppTypography.bodyLarge),
                      Text('Advanced Agentic Coding', style: AppTypography.bodyMedium.copyWith(color: AppColors.neonCyan)),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Divider(color: AppColors.glassBorder, height: 1),
                  const SizedBox(height: 20),
                  // Delete Profile Button
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        side: const BorderSide(color: AppColors.error),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      icon: const Icon(Icons.delete_forever, color: AppColors.error, size: 20),
                      label: const Text(
                        'Профильді толықтай жою ⚠️',
                        style: TextStyle(color: AppColors.error, fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                      onPressed: _showResetConfirm,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Back button
            SizedBox(
              width: double.infinity,
              child: GlowButton(
                label: 'Артқа қайту 🏠',
                color: color,
                onPressed: () => Navigator.pop(context),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLanguageBtn(String langCode, String label) {
    final sel = _selectedLanguage == langCode;
    return GestureDetector(
      onTap: () => setState(() => _selectedLanguage = langCode),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: sel ? widget.store.assistant.color.withValues(alpha: .2) : AppColors.bgDarkSurface,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: sel ? widget.store.assistant.color : AppColors.glassBorder,
            width: 1,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: sel ? FontWeight.bold : FontWeight.w500,
            color: sel ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}
