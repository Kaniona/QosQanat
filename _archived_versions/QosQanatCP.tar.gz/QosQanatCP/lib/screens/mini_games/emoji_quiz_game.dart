import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/store/app_store.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';

class EmojiQuizGame extends StatefulWidget {
  const EmojiQuizGame({
    required this.store,
    required this.onClose,
    super.key,
  });

  final AppStore store;
  final VoidCallback onClose;

  @override
  State<EmojiQuizGame> createState() => _EmojiQuizGameState();
}

class _EmojiQuizGameState extends State<EmojiQuizGame> {
  final List<_EmojiQuizItem> _quizItems = [
    _EmojiQuizItem(emojis: '🍎🍏', word: 'АЛМА', options: ['АЛМА', 'АЛМҰРТ', 'ЖҮЗІМ', 'БАНАН']),
    _EmojiQuizItem(emojis: '🏫📚', word: 'МЕКТЕП', options: ['МЕКТЕП', 'УНИВЕРСИТЕТ', 'КІТАПХАНА', 'ДҮКЕН']),
    _EmojiQuizItem(emojis: '🪽🦅', word: 'ҚЫРАН', options: ['ҚЫРАН', 'ҚАРҒА', 'ТОРҒАЙ', 'КЕПТЕР']),
    _EmojiQuizItem(emojis: '🌊🐟', word: 'БАЛЫҚ', options: ['БАЛЫҚ', 'КИТ', 'ДЕЛФИН', 'БАҚА']),
    _EmojiQuizItem(emojis: '🚗💨', word: 'КӨЛІК', options: ['КӨЛІК', 'ҰШАҚ', 'ПОЙЫЗ', 'ВЕЛОСИПЕД']),
    _EmojiQuizItem(emojis: '📖✍️', word: 'КІТАП', options: ['КІТАП', 'ДӘПТЕР', 'ҚАЛАМ', 'ӨШІРГІШ']),
    _EmojiQuizItem(emojis: '☀️🌍', word: 'КҮН', options: ['КҮН', 'АЙ', 'ЖҰЛДЫЗ', 'ЖЕР']),
    _EmojiQuizItem(emojis: '❄️⛄', word: 'ҚАР', options: ['ҚАР', 'ЖАҢБЫР', 'ЖЕЛ', 'ТҰМАН']),
  ];

  int _currentIndex = 0;
  int _score = 0;
  bool _isPlaying = true;
  String? _selectedOption;
  bool _isAnswered = false;

  void _chooseOption(String option) {
    if (_isAnswered) return;

    setState(() {
      _selectedOption = option;
      _isAnswered = true;
    });

    final currentItem = _quizItems[_currentIndex];
    final isCorrect = option == currentItem.word;

    if (isCorrect) {
      setState(() {
        _score += 10;
      });
      widget.store.rewardMiniGame(correct: true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('ДҰРЫС! Керемет логика! 🌟'),
          backgroundColor: AppColors.success,
          duration: Duration(milliseconds: 1000),
        ),
      );
    } else {
      widget.store.rewardMiniGame(correct: false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('ҚАТЕ! Дұрыс шешім: ${currentItem.word}'),
          backgroundColor: AppColors.error,
          duration: const Duration(milliseconds: 1500),
        ),
      );
    }

    Future.delayed(const Duration(milliseconds: 1600), () {
      if (!mounted) return;
      if (_currentIndex < _quizItems.length - 1) {
        setState(() {
          _currentIndex++;
          _selectedOption = null;
          _isAnswered = false;
        });
      } else {
        setState(() {
          _isPlaying = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        title: const Text('Emoji жұмбақ'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: widget.onClose,
        ),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 550),
              child: _isPlaying ? _buildGameBody() : _buildGameOverBody(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGameBody() {
    final currentItem = _quizItems[_currentIndex];

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Жұмбақ: ${_currentIndex + 1}/${_quizItems.length}', style: AppTypography.headingMedium),
            Text('Ұпай: $_score', style: AppTypography.headingMedium.copyWith(color: AppColors.neonGold)),
          ],
        ),
        const SizedBox(height: 30),
        GlassCard(
          padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
          child: Text(
            currentItem.emojis,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 64),
          ),
        ),
        const SizedBox(height: 40),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: currentItem.options.length,
          itemBuilder: (context, index) {
            final opt = currentItem.options[index];

            Color border = AppColors.glassBorder;
            Color bg = AppColors.bgDarkSurface;

            if (_isAnswered) {
              if (opt == currentItem.word) {
                border = AppColors.success;
                bg = AppColors.success.withValues(alpha: .15);
              } else if (opt == _selectedOption) {
                border = AppColors.error;
                bg = AppColors.error.withValues(alpha: .15);
              }
            }

            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: bg,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(color: border, width: 1.5),
                  ),
                ),
                onPressed: () => _chooseOption(opt),
                child: Text(
                  opt,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildGameOverBody() {
    return GlassCard(
      child: Column(
        children: [
          const Icon(Icons.emoji_emotions, color: AppColors.neonGold, size: 64),
          const SizedBox(height: 16),
          const Text('ТАМАША ҚИЯЛ! 🌟🎉', style: AppTypography.displayMedium),
          const SizedBox(height: 12),
          Text(
            'Эмодзилер жұмбағын толық шештіңіз.',
            textAlign: TextAlign.center,
            style: AppTypography.bodyMedium.copyWith(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 20),
          Text(
            'Қорытынды ұпай: $_score',
            style: AppTypography.headingLarge.copyWith(color: AppColors.neonGold),
          ),
          const SizedBox(height: 30),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: widget.onClose,
                  child: const Text('Артқа'),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: GlowButton(
                  label: 'Қайта бастау 🔄',
                  color: widget.store.assistant.color,
                  onPressed: () {
                    setState(() {
                      _currentIndex = 0;
                      _score = 0;
                      _isPlaying = true;
                      _selectedOption = null;
                      _isAnswered = false;
                    });
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _EmojiQuizItem {
  _EmojiQuizItem({
    required this.emojis,
    required this.word,
    required this.options,
  });

  final String emojis;
  final String word;
  final List<String> options;
}
