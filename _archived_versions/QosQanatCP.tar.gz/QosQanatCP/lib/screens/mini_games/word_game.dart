import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/store/app_store.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';

class WordGame extends StatefulWidget {
  const WordGame({
    required this.store,
    required this.onClose,
    super.key,
  });

  final AppStore store;
  final VoidCallback onClose;

  @override
  State<WordGame> createState() => _WordGameState();
}

class _WordGameState extends State<WordGame> {
  final List<String> _words = ['БІЛІМ', 'МЕКТЕП', 'ҚАНАТ', 'АРМАН', 'КІТАП', 'ДӘПТЕР', 'ҚАЛАМ', 'ТАРИХ', 'ҒАЛАМ', 'ОҚУШЫ'];
  final List<String> _hints = [
    'Knowledge',
    'School',
    'Wing',
    'Dream',
    'Book',
    'Notebook',
    'Pen',
    'History',
    'Space/Universe',
    'Student'
  ];

  int _currentIndex = 0;
  int _score = 0;
  bool _isPlaying = true;

  late String _targetWord;
  late String _hint;
  final List<String> _scrambledLetters = [];
  final List<String> _selectedLetters = [];

  @override
  void initState() {
    super.initState();
    _loadWord();
  }

  void _loadWord() {
    if (_currentIndex >= _words.length) {
      setState(() {
        _isPlaying = false;
      });
      return;
    }

    _targetWord = _words[_currentIndex];
    _hint = _hints[_currentIndex];

    // Scramble letters
    final letters = _targetWord.split('');
    final rand = Random();
    do {
      letters.shuffle(rand);
    } while (letters.join('') == _targetWord && letters.length > 1);

    setState(() {
      _scrambledLetters.clear();
      _scrambledLetters.addAll(letters);
      _selectedLetters.clear();
    });
  }

  void _tapScrambledLetter(int index) {
    if (!_isPlaying) return;
    setState(() {
      final letter = _scrambledLetters[index];
      _selectedLetters.add(letter);
      _scrambledLetters.removeAt(index);
    });

    // Verify final word
    if (_scrambledLetters.isEmpty) {
      final finalWord = _selectedLetters.join('');
      final isCorrect = finalWord == _targetWord;

      if (isCorrect) {
        setState(() {
          _score += 10;
        });
        widget.store.rewardMiniGame(correct: true);
        _showSuccessAlert();
      } else {
        widget.store.rewardMiniGame(correct: false);
        _showFailAlert();
      }
    }
  }

  void _tapSelectedLetter(int index) {
    if (!_isPlaying) return;
    setState(() {
      final letter = _selectedLetters[index];
      _scrambledLetters.add(letter);
      _selectedLetters.removeAt(index);
    });
  }

  void _showSuccessAlert() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('ДҰРЫС! Керемет сөздік қор! 🌟'),
        backgroundColor: AppColors.success,
        duration: Duration(milliseconds: 1200),
      ),
    );
    Future.delayed(const Duration(milliseconds: 1400), () {
      if (mounted) {
        setState(() {
          _currentIndex++;
        });
        _loadWord();
      }
    });
  }

  void _showFailAlert() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('ҚАТЕ! Дұрыс жауап: $_targetWord. Сөзді қайта орнына қойыңыз.'),
        backgroundColor: AppColors.error,
        duration: const Duration(seconds: 2),
      ),
    );
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        _loadWord(); // Restart same word
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        title: const Text('Сөз тапқыш'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: widget.onClose,
        ),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 600),
              child: _isPlaying ? _buildGameBody() : _buildGameOverBody(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGameBody() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Сөз: ${_currentIndex + 1}/${_words.length}', style: AppTypography.headingMedium),
            Text('Ұпай: $_score', style: AppTypography.headingMedium.copyWith(color: AppColors.neonGold)),
          ],
        ),
        const SizedBox(height: 20),

        // Hint Card
        GlassCard(
          child: Row(
            children: [
              const Icon(Icons.help_outline, color: AppColors.neonCyan),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Ағылшынша мағынасы:', style: AppTypography.labelSmall),
                    Text(
                      _hint,
                      style: AppTypography.headingMedium.copyWith(color: Colors.white),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 40),

        // 1. Output selected letters slot
        const Text('Құрастырылған сөз:', style: AppTypography.labelMedium),
        const SizedBox(height: 10),
        Container(
          constraints: const BoxConstraints(minHeight: 64),
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            color: AppColors.bgDarkSurface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.glassBorder),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_selectedLetters.length, (index) {
              return GestureDetector(
                onTap: () => _tapSelectedLetter(index),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: widget.store.assistant.color,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _selectedLetters[index],
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
              );
            }),
          ),
        ),
        const SizedBox(height: 40),

        // 2. Input Scrambled letters
        const Text('Әріптерді таңдаңыз:', style: AppTypography.labelMedium),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          alignment: WrapAlignment.center,
          children: List.generate(_scrambledLetters.length, (index) {
            return GestureDetector(
              onTap: () => _tapScrambledLetter(index),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.bgDarkElevated,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.glassBorder),
                ),
                child: Text(
                  _scrambledLetters[index],
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildGameOverBody() {
    return GlassCard(
      child: Column(
        children: [
          const Icon(Icons.emoji_events, color: AppColors.neonGold, size: 64),
          const SizedBox(height: 16),
          const Text('КЕРЕМЕТ СӨЗДІК ШЕШІМ! 🎉', style: AppTypography.displayMedium),
          const SizedBox(height: 12),
          Text(
            'Барлық сөздерді толық таптыңыз.',
            textAlign: TextAlign.center,
            style: AppTypography.bodyMedium.copyWith(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 20),
          Text(
            'Қорытынды ұпай: $_score',
            style: AppTypography.headingLarge.copyWith(color: AppColors.neonGold),
          ),
          const SizedBox(height: 30),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: widget.onClose,
                  child: const Text('Артқа'),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: GlowButton(
                  label: 'Қайта бастау 🔄',
                  color: widget.store.assistant.color,
                  onPressed: () {
                    setState(() {
                      _currentIndex = 0;
                      _score = 0;
                      _isPlaying = true;
                    });
                    _loadWord();
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
