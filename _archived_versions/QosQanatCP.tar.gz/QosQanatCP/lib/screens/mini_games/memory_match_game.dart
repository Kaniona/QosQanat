import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/store/app_store.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';

class MemoryMatchGame extends StatefulWidget {
  const MemoryMatchGame({
    required this.store,
    required this.onClose,
    super.key,
  });

  final AppStore store;
  final VoidCallback onClose;

  @override
  State<MemoryMatchGame> createState() => _MemoryMatchGameState();
}

class _MemoryMatchGameState extends State<MemoryMatchGame> {
  final List<String> _kazakhWords = ['Ана', 'Отан', 'Мектеп', 'Қанат', 'Кітап', 'Ақыл', 'Дос', 'Ай'];
  final List<String> _englishWords = ['Mother', 'Motherland', 'School', 'Wing', 'Book', 'Wisdom', 'Friend', 'Moon'];

  final List<_MemoryCard> _cards = [];
  int? _firstSelectedIndex;
  bool _isChecking = false;
  int _pairsFound = 0;
  int _score = 0;
  bool _isPlaying = true;

  @override
  void initState() {
    super.initState();
    _setupCards();
  }

  void _setupCards() {
    _cards.clear();
    _firstSelectedIndex = null;
    _isChecking = false;
    _pairsFound = 0;
    _isPlaying = true;

    // Create Kazakh and English cards
    for (int i = 0; i < 8; i++) {
      _cards.add(_MemoryCard(id: i, label: _kazakhWords[i], isKazakh: true));
      _cards.add(_MemoryCard(id: i, label: _englishWords[i], isKazakh: false));
    }

    _cards.shuffle();
  }

  void _selectCard(int index) {
    if (_isChecking || _cards[index].isFlipped || _cards[index].isMatched) return;

    setState(() {
      _cards[index].isFlipped = true;
    });

    if (_firstSelectedIndex == null) {
      _firstSelectedIndex = index;
    } else {
      final firstIndex = _firstSelectedIndex!;
      if (firstIndex == index) return;

      _isChecking = true;

      final card1 = _cards[firstIndex];
      final card2 = _cards[index];

      // Check if matching pair (matching id and different type)
      if (card1.id == card2.id && card1.isKazakh != card2.isKazakh) {
        // Matched!
        setState(() {
          card1.isMatched = true;
          card2.isMatched = true;
          _firstSelectedIndex = null;
          _isChecking = false;
          _pairsFound++;
          _score += 15;
        });

        widget.store.rewardMiniGame(correct: true);

        if (_pairsFound == 8) {
          setState(() {
            _isPlaying = false;
          });
        }
      } else {
        // Not matched: flip back after 1.2s delay
        Timer(const Duration(milliseconds: 1000), () {
          if (!mounted) return;
          setState(() {
            card1.isFlipped = false;
            card2.isFlipped = false;
            _firstSelectedIndex = null;
            _isChecking = false;
          });
        });
        widget.store.rewardMiniGame(correct: false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        title: const Text('Жадты Жаттықтыру'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: widget.onClose,
        ),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 600),
              child: _isPlaying ? _buildGameBody() : _buildGameOverBody(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGameBody() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Сәйкестіктер: $_pairsFound/8', style: AppTypography.headingMedium),
            Text('Ұпай: $_score', style: AppTypography.headingMedium.copyWith(color: AppColors.neonGold)),
          ],
        ),
        const SizedBox(height: 24),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 16,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            childAspectRatio: 0.9,
          ),
          itemBuilder: (context, index) {
            final card = _cards[index];

            return GestureDetector(
              onTap: () => _selectCard(index),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                decoration: BoxDecoration(
                  color: card.isMatched
                      ? AppColors.success.withValues(alpha: .2)
                      : (card.isFlipped ? AppColors.bgDarkSurface : AppColors.bgDarkElevated),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: card.isMatched
                        ? AppColors.success
                        : (card.isFlipped ? widget.store.assistant.color : AppColors.glassBorder),
                    width: 1.5,
                  ),
                ),
                child: Center(
                  child: card.isFlipped || card.isMatched
                      ? Padding(
                          padding: const EdgeInsets.all(4),
                          child: Text(
                            card.label,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: card.label.length > 8 ? 10 : 12,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        )
                      : Icon(
                          Icons.help_outline,
                          color: widget.store.assistant.color.withValues(alpha: .6),
                          size: 28,
                        ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildGameOverBody() {
    return GlassCard(
      child: Column(
        children: [
          const Icon(Icons.psychology, color: AppColors.neonGold, size: 64),
          const SizedBox(height: 16),
          const Text('КЕРЕМЕТ ЖАД! 🧠🎉', style: AppTypography.displayMedium),
          const SizedBox(height: 12),
          Text(
            'Сөздердің қазақша-ағылшынша сәйкестігін толық таптыңыз.',
            textAlign: TextAlign.center,
            style: AppTypography.bodyMedium.copyWith(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 20),
          Text(
            'Қорытынды ұпай: $_score',
            style: AppTypography.headingLarge.copyWith(color: AppColors.neonGold),
          ),
          const SizedBox(height: 30),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: widget.onClose,
                  child: const Text('Артқа'),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: GlowButton(
                  label: 'Қайта бастау 🔄',
                  color: widget.store.assistant.color,
                  onPressed: () {
                    setState(() {
                      _score = 0;
                    });
                    _setupCards();
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MemoryCard {
  _MemoryCard({
    required this.id,
    required this.label,
    required this.isKazakh,
    this.isFlipped = false,
    this.isMatched = false,
  });

  final int id;
  final String label;
  final bool isKazakh;
  bool isFlipped;
  bool isMatched;
}
