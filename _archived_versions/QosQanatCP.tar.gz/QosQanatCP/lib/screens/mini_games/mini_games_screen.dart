import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/store/app_store.dart';
import '../../widgets/app_page.dart';
import '../../widgets/glass_card.dart';
import 'quick_math_game.dart';
import 'word_game.dart';
import 'memory_match_game.dart';
import 'emoji_quiz_game.dart';
import 'speed_typing_game.dart';

class MiniGamesScreen extends StatefulWidget {
  const MiniGamesScreen({required this.store, super.key});

  final AppStore store;

  @override
  State<MiniGamesScreen> createState() => _MiniGamesScreenState();
}

class _MiniGamesScreenState extends State<MiniGamesScreen> {
  Widget? _activeGame;

  void _launchGame(Widget gameWidget) {
    setState(() {
      _activeGame = gameWidget;
    });
  }

  void _closeGame() {
    setState(() {
      _activeGame = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_activeGame != null) {
      return _activeGame!;
    }

    final games = [
      _GameMetadata(
        title: 'Қарқынды Есеп (Math)',
        description: 'Уақыт біткенше математикалық амалдарды жылдам шешіңіз.',
        icon: Icons.calculate,
        color: AppColors.wisdom,
        launch: () => _launchGame(QuickMathGame(store: widget.store, onClose: _closeGame)),
      ),
      _GameMetadata(
        title: 'Сөз тапқыш (Word Finder)',
        description: 'Қазақша аударманы дұрыс құрастыруға арналған сөздік ойын.',
        icon: Icons.abc,
        color: const Color(0xFF00E676),
        launch: () => _launchGame(WordGame(store: widget.store, onClose: _closeGame)),
      ),
      _GameMetadata(
        title: 'Жадты Жаттықтыру (Memory)',
        description: 'Жасырылған карточкалардың сәйкестігін есте сақтап ашыңыз.',
        icon: Icons.grid_view,
        color: const Color(0xFFFF2D78),
        launch: () => _launchGame(MemoryMatchGame(store: widget.store, onClose: _closeGame)),
      ),
      _GameMetadata(
        title: 'Emoji жұмбақ (Emoji Quiz)',
        description: 'Эмодзилер арқылы жасырылған қазақша сөздерді шешіңіз.',
        icon: Icons.emoji_emotions,
        color: const Color(0xFFFFAB00),
        launch: () => _launchGame(EmojiQuizGame(store: widget.store, onClose: _closeGame)),
      ),
      _GameMetadata(
        title: 'Жылдам теру (Speed Typing)',
        description: 'Қазақша сөздерді жылдам әрі қатесіз теру жарысы.',
        icon: Icons.keyboard,
        color: const Color(0xFFB388FF),
        launch: () => _launchGame(SpeedTypingGame(store: widget.store, onClose: _closeGame)),
      ),
    ];

    return AppPage(
      title: 'Ми ойындары 🎮',
      subtitle: 'Танымдық мини-ойындар арқылы ақыл мен монета жинаңыз.',
      child: Column(
        children: [
          // Games Grid
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: games.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 0.95,
            ),
            itemBuilder: (context, index) {
              final game = games[index];

              return GlassCard(
                onTap: game.launch,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: game.color.withValues(alpha: .15),
                        shape: BoxShape.circle,
                        border: Border.all(color: game.color, width: 1.5),
                      ),
                      child: Icon(game.icon, color: game.color, size: 28),
                    ),
                    const Spacer(),
                    Text(
                      game.title,
                      style: AppTypography.headingMedium,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      game.description,
                      style: AppTypography.bodySmall,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _GameMetadata {
  _GameMetadata({
    required this.title,
    required this.description,
    required this.icon,
    required this.color,
    required this.launch,
  });

  final String title;
  final String description;
  final IconData icon;
  final Color color;
  final VoidCallback launch;
}
