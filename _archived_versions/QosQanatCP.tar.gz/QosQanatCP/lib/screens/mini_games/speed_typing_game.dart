import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/store/app_store.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';

class SpeedTypingGame extends StatefulWidget {
  const SpeedTypingGame({
    required this.store,
    required this.onClose,
    super.key,
  });

  final AppStore store;
  final VoidCallback onClose;

  @override
  State<SpeedTypingGame> createState() => _SpeedTypingGameState();
}

class _SpeedTypingGameState extends State<SpeedTypingGame> {
  final List<String> _words = [
    'БІЛІМ',
    'МЕКТЕП',
    'ҚАЗАҚСТАН',
    'АСТАНА',
    'ГЕЙМИФИКАЦИЯ',
    'ИНТЕЛЛЕКТ',
    'ҚАНАТ',
    'БАҒДАРЛАМАЛАУ',
    'АҚЫЛБЕК',
    'КҮНДЕЛІКТІ'
  ];

  int _currentIndex = 0;
  int _score = 0;
  bool _isPlaying = true;
  final _inputController = TextEditingController();
  int _secondsElapsed = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (_isPlaying) {
        setState(() {
          _secondsElapsed++;
        });
      }
    });
  }

  void _checkInput(String val) {
    final target = _words[_currentIndex];
    final cleanInput = val.trim().toUpperCase();

    if (cleanInput == target) {
      _inputController.clear();
      setState(() {
        _score += 15;
      });
      widget.store.rewardMiniGame(correct: true);

      if (_currentIndex < _words.length - 1) {
        setState(() {
          _currentIndex++;
        });
      } else {
        _timer?.cancel();
        setState(() {
          _isPlaying = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _inputController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        title: const Text('Жылдам теру'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: widget.onClose,
        ),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 550),
              child: _isPlaying ? _buildGameBody() : _buildGameOverBody(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGameBody() {
    final targetWord = _words[_currentIndex];

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Сөз: ${_currentIndex + 1}/${_words.length}', style: AppTypography.headingMedium),
            Text('Уақыт: $_secondsElapsed с', style: AppTypography.headingMedium.copyWith(color: AppColors.neonMagenta)),
          ],
        ),
        const SizedBox(height: 30),
        const Text(
          'Төмендегі сөзді қатесіз жылдам теріңіз:',
          style: AppTypography.labelMedium,
        ),
        const SizedBox(height: 12),
        GlassCard(
          padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 20),
          child: Text(
            targetWord,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 36,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
              color: Colors.white,
            ),
          ),
        ),
        const SizedBox(height: 30),
        TextField(
          controller: _inputController,
          autofocus: true,
          style: AppTypography.headingMedium.copyWith(color: Colors.white),
          textAlign: TextAlign.center,
          decoration: const InputDecoration(
            hintText: 'Осында теріңіз...',
            contentPadding: EdgeInsets.symmetric(vertical: 16),
          ),
          onChanged: _checkInput,
        ),
        const SizedBox(height: 20),
        Text(
          'Жиналған ұпай: $_score',
          style: AppTypography.labelMedium.copyWith(color: AppColors.neonGold),
        ),
      ],
    );
  }

  Widget _buildGameOverBody() {
    return GlassCard(
      child: Column(
        children: [
          const Icon(Icons.speed, color: AppColors.neonGold, size: 64),
          const SizedBox(height: 16),
          const Text('КЕРЕМЕТ ЖЫЛДАМДЫҚ! ⚡🎉', style: AppTypography.displayMedium),
          const SizedBox(height: 12),
          Text(
            'Барлық сөздерді толық аяқтадыңыз.',
            textAlign: TextAlign.center,
            style: AppTypography.bodyMedium.copyWith(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 20),
          Text(
            'Жалпы уақыт: $_secondsElapsed секунд',
            style: AppTypography.headingMedium.copyWith(color: AppColors.neonMagenta),
          ),
          Text(
            'Қорытынды ұпай: $_score',
            style: AppTypography.headingLarge.copyWith(color: AppColors.neonGold),
          ),
          const SizedBox(height: 30),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: widget.onClose,
                  child: const Text('Артқа'),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: GlowButton(
                  label: 'Қайта бастау 🔄',
                  color: widget.store.assistant.color,
                  onPressed: () {
                    setState(() {
                      _currentIndex = 0;
                      _score = 0;
                      _secondsElapsed = 0;
                      _isPlaying = true;
                    });
                    _inputController.clear();
                    _startTimer();
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
