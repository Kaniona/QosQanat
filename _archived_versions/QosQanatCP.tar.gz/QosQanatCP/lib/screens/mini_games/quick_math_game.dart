import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/store/app_store.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';

class QuickMathGame extends StatefulWidget {
  const QuickMathGame({
    required this.store,
    required this.onClose,
    super.key,
  });

  final AppStore store;
  final VoidCallback onClose;

  @override
  State<QuickMathGame> createState() => _QuickMathGameState();
}

class _QuickMathGameState extends State<QuickMathGame> {
  int _score = 0;
  int _targetSeconds = 15;
  Timer? _timer;
  bool _isPlaying = true;

  late String _question;
  late int _correctAnswer;
  final List<int> _options = [];

  @override
  void initState() {
    super.initState();
    _generateQuestion();
    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (_targetSeconds > 0) {
        setState(() {
          _targetSeconds--;
        });
      } else {
        _endGame();
      }
    });
  }

  void _generateQuestion() {
    final rand = Random();
    final type = rand.nextInt(3); // 0: +, 1: -, 2: *

    int a = 0;
    int b = 0;

    if (type == 0) {
      a = 10 + rand.nextInt(50);
      b = 10 + rand.nextInt(50);
      _question = '$a + $b = ?';
      _correctAnswer = a + b;
    } else if (type == 1) {
      a = 20 + rand.nextInt(60);
      b = 5 + rand.nextInt(a - 2);
      _question = '$a - $b = ?';
      _correctAnswer = a - b;
    } else {
      a = 2 + rand.nextInt(10);
      b = 3 + rand.nextInt(10);
      _question = '$a × $b = ?';
      _correctAnswer = a * b;
    }

    // Generate option list
    _options.clear();
    _options.add(_correctAnswer);
    while (_options.length < 4) {
      final opt = _correctAnswer + (rand.nextInt(16) - 8);
      if (!_options.contains(opt)) {
        _options.add(opt);
      }
    }
    _options.shuffle();
  }

  void _chooseOption(int val) {
    if (!_isPlaying) return;

    final isCorrect = val == _correctAnswer;
    if (isCorrect) {
      setState(() {
        _score++;
        _targetSeconds += 2; // Add bonus time
      });
      widget.store.rewardMiniGame(correct: true);
    } else {
      widget.store.rewardMiniGame(correct: false);
    }

    _generateQuestion();
  }

  void _endGame() {
    _timer?.cancel();
    setState(() {
      _isPlaying = false;
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        title: const Text('Қарқынды Есеп'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: widget.onClose,
        ),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 550),
              child: _isPlaying ? _buildGameBody() : _buildGameOverBody(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGameBody() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Ұпай: $_score', style: AppTypography.headingMedium),
            Row(
              children: [
                const Icon(Icons.timer, color: AppColors.neonMagenta),
                const SizedBox(width: 6),
                Text(
                  '$_targetSeconds c',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: _targetSeconds <= 5 ? AppColors.neonMagenta : Colors.white,
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 30),
        GlassCard(
          padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
          child: Text(
            _question,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 42, fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ),
        const SizedBox(height: 40),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 4,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 1.5,
          ),
          itemBuilder: (context, index) {
            final opt = _options[index];
            return ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.bgDarkSurface,
                side: const BorderSide(color: AppColors.glassBorder),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () => _chooseOption(opt),
              child: Text(
                '$opt',
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildGameOverBody() {
    return GlassCard(
      child: Column(
        children: [
          const Icon(Icons.stars, color: AppColors.neonGold, size: 64),
          const SizedBox(height: 16),
          const Text('УАҚЫТ АЯҚТАЛДЫ! ⏰', style: AppTypography.displayMedium),
          const SizedBox(height: 12),
          Text(
            'Қарқынды Есеп ойыны аяқталды.',
            style: AppTypography.bodyMedium.copyWith(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 20),
          Text(
            'Жалпы ұпайыңыз: $_score',
            style: AppTypography.headingLarge.copyWith(color: AppColors.neonGold),
          ),
          const SizedBox(height: 30),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: widget.onClose,
                  child: const Text('Артқа'),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: GlowButton(
                  label: 'Қайта ойнау 🔄',
                  color: widget.store.assistant.color,
                  onPressed: () {
                    setState(() {
                      _score = 0;
                      _targetSeconds = 15;
                      _isPlaying = true;
                    });
                    _generateQuestion();
                    _startTimer();
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
