import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/content/achievements_data.dart';
import '../../data/models/game_models.dart';
import '../../data/store/app_store.dart';
import '../../widgets/app_page.dart';
import '../../widgets/assistant_avatar.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';
import '../settings/settings_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({required this.store, super.key});

  final AppStore store;

  void _copyToClipboard(BuildContext context, String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('QQ-ID көшірілді! 📋: $text'),
        backgroundColor: store.assistant.color,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showResetConfirm(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Профильді жою? ⚠️'),
          content: const Text(
            'Бұл әрекет сіздің барлық жетістіктеріңізді, жиналған монеталар мен сатып алынған киімдерді толық жояды. Жалғастырамыз ба?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Бас тарту'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              onPressed: () {
                Navigator.pop(context);
                store.resetProfile();
              },
              child: const Text('Иә, жою', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final profile = store.profile!;
    final color = store.assistant.color;
    final totalTasks = store.completedLessons.length + store.completedCurriculumNodes.length;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AppPage(
        title: 'Жеке Профиль 🪽',
        subtitle: 'Өз көрсеткіштеріңіз бен жетістіктеріңізді бақылаңыз',
        actions: [
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.white, size: 26),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => SettingsScreen(store: store),
                ),
              );
            },
          ),
        ],
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              // Character Equipped view Card
              GlassCard(
                borderGradient: store.assistant.gradient,
                child: Column(
                  children: [
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: 170,
                          height: 170,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [
                                color.withValues(alpha: .35),
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                        AssistantAvatar(
                          assistant: store.assistant,
                          size: 150,
                          equippedItems: store.equippedItems,
                          equippedPet: store.equippedPet,
                          equippedBackground: store.equippedBackground,
                          mood: 'happy',
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      profile.fullName,
                      style: AppTypography.headingLarge.copyWith(fontSize: 22),
                    ),
                    const SizedBox(height: 4),
                    // Tap to copy QQ-ID
                    GestureDetector(
                      onTap: () => _copyToClipboard(context, profile.qqId),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.bgDarkSurface,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.glassBorder, width: 0.5),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              profile.qqId,
                              style: AppTypography.labelSmall.copyWith(
                                color: AppColors.neonCyan,
                                letterSpacing: 1.2,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(width: 6),
                            const Icon(Icons.copy, color: AppColors.neonCyan, size: 12),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),

                    // Level and EXP Progress Bar
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: color.withValues(alpha: .2),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: color.withValues(alpha: .5)),
                                ),
                                child: Text(
                                  'Level ${store.level}',
                                  style: TextStyle(
                                    color: color,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ),
                              Text(
                                '${store.exp}/${store.expForNextLevel} XP',
                                style: AppTypography.bodySmall.copyWith(color: AppColors.textSecondary),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(6),
                            child: LinearProgressIndicator(
                              value: store.levelProgress,
                              minHeight: 8,
                              backgroundColor: AppColors.bgDarkSurface,
                              valueColor: AlwaysStoppedAnimation<Color>(color),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // Stats Grid
              Text('Статистика', style: AppTypography.headingMedium),
              const SizedBox(height: 8),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 2.1,
                children: [
                  _buildStatTile('Ақыл ұпайы', '${store.wisdom}', '⭐', AppColors.wisdom),
                  _buildStatTile('Монета', '${store.coins}', '🪙', AppColors.coin),
                  _buildStatTile('Достар саны', '${store.acceptedFriends.length}', '🤝', AppColors.neonCyan),
                  _buildStatTile('Жалғасқан күндер', '${store.streak}', '🔥', AppColors.warning),
                  _buildStatTile('Тапсырмалар', '$totalTasks', '📚', AppColors.neonPurple),
                  _buildStatTile('Жеңілген батлдар', '${store.battlesWon}', '⚔️', AppColors.neonMagenta),
                ],
              ),
              const SizedBox(height: 24),

              // Achievements Section
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Жетістіктер',
                    style: AppTypography.headingMedium,
                  ),
                  Text(
                    '${store.unlockedAchievements.length}/${allAchievements.length}',
                    style: AppTypography.labelMedium.copyWith(color: color),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              // Achievements Grid
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: allAchievements.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 2.1,
                ),
                itemBuilder: (context, index) {
                  final ach = allAchievements[index];
                  final unlocked = store.unlockedAchievements.contains(ach.id);
                  return _buildAchievementCard(ach, unlocked);
                },
              ),
              const SizedBox(height: 28),

              // Logout Button
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    side: const BorderSide(color: AppColors.error),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  icon: const Icon(Icons.logout, color: AppColors.error, size: 20),
                  label: const Text(
                    'Жүйеден шығу (Logout)',
                    style: TextStyle(color: AppColors.error, fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  onPressed: () => _showResetConfirm(context),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatTile(String label, String value, String emoji, Color accentColor) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: accentColor.withValues(alpha: .12),
              shape: BoxShape.circle,
            ),
            child: Text(emoji, style: const TextStyle(fontSize: 18)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  value,
                  style: AppTypography.headingSmall.copyWith(
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.bodySmall.copyWith(fontSize: 10),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAchievementCard(Achievement ach, bool unlocked) {
    return GlassCard(
      padding: const EdgeInsets.all(8),
      backgroundColor: unlocked ? AppColors.neonGold.withValues(alpha: .06) : Colors.black.withValues(alpha: .3),
      borderGradient: unlocked
          ? AppColors.goldGradient
          : const LinearGradient(colors: [AppColors.glassBorder, AppColors.glassBorder]),
      child: Row(
        children: [
          // Circular Badge Icon / Silhouette
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: unlocked ? AppColors.neonGold.withValues(alpha: .15) : AppColors.bgDarkSurface.withValues(alpha: .5),
              shape: BoxShape.circle,
              border: Border.all(
                color: unlocked ? AppColors.neonGold : AppColors.textMuted.withValues(alpha: .3),
                width: 1.5,
              ),
            ),
            child: Center(
              child: Opacity(
                opacity: unlocked ? 1.0 : 0.25,
                child: Text(
                  ach.icon,
                  style: const TextStyle(fontSize: 20),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  ach.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.headingSmall.copyWith(
                    color: unlocked ? Colors.white : AppColors.textMuted,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  ach.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.bodySmall.copyWith(
                    fontSize: 9,
                    color: unlocked ? AppColors.textSecondary : AppColors.textMuted,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
