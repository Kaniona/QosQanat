import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/content/shop_data.dart';
import '../../data/models/shop_item.dart';
import '../../data/store/app_store.dart';
import '../../widgets/animated_counter.dart';
import '../../widgets/app_page.dart';
import '../../widgets/assistant_avatar.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/glow_button.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({required this.store, super.key});

  final AppStore store;

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final List<String> _categories = [
    'Жоғарғы киім',
    'Төменгі киім',
    'Бас киім',
    'Аксессуар',
    'Питомец',
  ];

  // Temporary equipping live preview container
  final Set<String> _previewItems = {};
  String? _previewPet;
  String _previewBackground = 'bg-default';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _categories.length, vsync: this);
    _syncPreviewWithStore();
  }

  void _syncPreviewWithStore() {
    setState(() {
      _previewItems
        ..clear()
        ..addAll(widget.store.equippedItems);
      _previewPet = widget.store.equippedPet;
      _previewBackground = widget.store.equippedBackground;
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _previewItem(ShopItem item) {
    setState(() {
      if (item.category == 'Питомец') {
        _previewPet = item.id;
      } else {
        // Wearable clothes: replace conflicting ones of the same category slot
        _previewItems.removeWhere((id) {
          final shopItem = allShopItems.firstWhere(
            (x) => x.id == id,
            orElse: () => const ShopItem(id: '', name: '', category: '', price: 0, coinPrice: 0, description: '', unlockLevel: 1, previewImage: '', icon: Icons.error, color: Colors.transparent),
          );
          return shopItem.category == item.category;
        });

        if (item.id != 'no-hat' && item.id != 'no-accessory') {
          _previewItems.add(item.id);
        }
      }
    });
  }

  void _showPurchaseConfirmation(ShopItem item) {
    final store = widget.store;
    final isLevelLocked = store.level < item.unlockLevel;
    final isAffordable = store.coins >= item.price;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          padding: EdgeInsets.fromLTRB(20, 24, 20, MediaQuery.of(context).viewInsets.bottom + 36),
          decoration: const BoxDecoration(
            color: AppColors.bgDarkCard,
            borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
            boxShadow: [
              BoxShadow(
                color: Colors.black54,
                blurRadius: 20,
                spreadRadius: 2,
              )
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 50,
                  height: 5,
                  decoration: BoxDecoration(
                    color: AppColors.glassBorder,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              // Item Header Preview
              Center(
                child: Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    color: item.color.withValues(alpha: .15),
                    shape: BoxShape.circle,
                    border: Border.all(color: item.color, width: 2),
                  ),
                  child: Icon(item.icon, color: item.color, size: 48),
                ),
              ),
              const SizedBox(height: 16),
              Center(
                child: Text(
                  item.name,
                  style: AppTypography.headingLarge.copyWith(fontSize: 24, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 8),
              Center(
                child: Text(
                  item.description,
                  textAlign: TextAlign.center,
                  style: AppTypography.bodySmall.copyWith(color: AppColors.textSecondary),
                ),
              ),
              const SizedBox(height: 20),

              // Rarity & Level details
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: item.rarity.color.withValues(alpha: .2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      item.rarity.label.toUpperCase(),
                      style: AppTypography.labelSmall.copyWith(color: item.rarity.color, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: isLevelLocked ? AppColors.error.withValues(alpha: .2) : AppColors.success.withValues(alpha: .2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          isLevelLocked ? Icons.lock : Icons.lock_open,
                          size: 14,
                          color: isLevelLocked ? AppColors.error : AppColors.success,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${item.unlockLevel} Деңгей',
                          style: AppTypography.labelSmall.copyWith(
                            color: isLevelLocked ? AppColors.error : AppColors.success,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 28),

              // Warnings
              if (isLevelLocked)
                Container(
                  margin: const EdgeInsets.only(bottom: 20),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.error.withValues(alpha: .1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.error.withValues(alpha: .3)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline, color: AppColors.error),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Сатып алу үшін сізге ${item.unlockLevel}-ші деңгей керек! (Қазіргі деңгейіңіз: ${store.level})',
                          style: AppTypography.bodySmall.copyWith(color: AppColors.error),
                        ),
                      ),
                    ],
                  ),
                )
              else if (!isAffordable)
                Container(
                  margin: const EdgeInsets.only(bottom: 20),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.error.withValues(alpha: .1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.error.withValues(alpha: .3)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.warning_amber_rounded, color: AppColors.error),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Монеталар жеткіліксіз! Сізге тағы ${item.price - store.coins} монета қажет.',
                          style: AppTypography.bodySmall.copyWith(color: AppColors.error),
                        ),
                      ),
                    ],
                  ),
                ),

              // Actions buttons
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onPressed: () => Navigator.pop(context),
                      child: Text(
                        'Болдырмау',
                        style: AppTypography.labelMedium.copyWith(color: AppColors.textSecondary),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: GlowButton(
                      label: 'Сатып алу: 🪙 ${item.price}',
                      color: isLevelLocked || !isAffordable ? AppColors.textMuted : AppColors.coin,
                      glowColor: isLevelLocked || !isAffordable
                          ? Colors.transparent
                          : AppColors.coin.withValues(alpha: .3),
                      onPressed: isLevelLocked || !isAffordable
                          ? null
                          : () {
                              Navigator.pop(context);
                              _purchaseAndEquip(item);
                            },
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  void _purchaseAndEquip(ShopItem item) {
    final store = widget.store;
    final success = store.buy(item);

    if (success) {
      if (item.category == 'Питомец') {
        store.equipPet(item.id);
      } else {
        store.equipItem(item.id);
      }
      _syncPreviewWithStore();

      // Show beautiful celebration popup
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            backgroundColor: AppColors.bgDarkCard,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
              side: BorderSide(color: item.color, width: 2),
            ),
            title: const Center(
              child: Text(
                'СӘТТІ САТЫП АЛЫНДЫ! 🎉',
                style: TextStyle(color: AppColors.neonGold, fontWeight: FontWeight.bold),
              ),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    color: item.color.withValues(alpha: .15),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(item.icon, color: item.color, size: 40),
                ),
                const SizedBox(height: 16),
                Text(
                  'Сіз "${item.name}" затын сәтті сатып алып, жаңа топтамаңызға қостыңыз!',
                  textAlign: TextAlign.center,
                  style: AppTypography.bodyMedium,
                ),
              ],
            ),
            actions: [
              Center(
                child: GlowButton(
                  label: 'Керемет! 🪽',
                  color: item.color,
                  glowColor: item.color.withValues(alpha: .3),
                  onPressed: () => Navigator.pop(context),
                ),
              ),
            ],
          );
        },
      );
    }
  }

  void _equipOwnedItem(ShopItem item) {
    final store = widget.store;
    if (item.category == 'Питомец') {
      store.equipPet(item.id);
    } else {
      store.equipItem(item.id);
    }
    _syncPreviewWithStore();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: AppColors.success,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 12),
            Text(
              '"${item.name}" сәтті киілді! 🪽',
              style: AppTypography.bodySmall.copyWith(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.store,
      builder: (context, _) {
        return AppPage(
          title: 'QosQanat Shop 🪙',
          subtitle: 'Ассистентіңізді сәнді киімдермен, бас киімдермен және үй жануарларымен безендіріңіз.',
          actions: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: AppColors.coin.withValues(alpha: .15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.coin, width: 1.5),
              ),
              child: Row(
                children: [
                  const Text('🪙 ', style: TextStyle(fontSize: 16)),
                  AnimatedCounter(
                    value: widget.store.coins,
                    style: AppTypography.labelMedium.copyWith(
                      color: AppColors.coin,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
          ],
          child: Column(
            children: [
              // Adaptive body preview vs catalog grids
              LayoutBuilder(
                builder: (context, constraints) {
                  final isWide = constraints.maxWidth > 700;

                  final avatarPreview = GlassCard(
                    borderGradient: widget.store.assistant.gradient,
                    child: Column(
                      children: [
                        Text(
                          'Киіп көру (Сынақ)',
                          style: AppTypography.labelMedium.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 12),
                        AssistantAvatar(
                          assistant: widget.store.assistant,
                          size: 160,
                          equippedItems: _previewItems,
                          equippedPet: _previewPet,
                          equippedBackground: _previewBackground,
                          mood: 'happy',
                        ),
                        const SizedBox(height: 12),
                        TextButton.icon(
                          onPressed: _syncPreviewWithStore,
                          icon: const Icon(Icons.restore, color: AppColors.textSecondary),
                          label: Text(
                            'Қалпына келтіру',
                            style: AppTypography.labelSmall.copyWith(color: AppColors.textSecondary),
                          ),
                        ),
                      ],
                    ),
                  );

                  final shopTabbedContent = Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: AppColors.bgDarkCard,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppColors.glassBorder),
                        ),
                        child: TabBar(
                          controller: _tabController,
                          isScrollable: true,
                          indicator: BoxDecoration(
                            color: widget.store.assistant.color,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          dividerColor: Colors.transparent,
                          labelColor: Colors.white,
                          unselectedLabelColor: AppColors.textSecondary,
                          tabs: _categories.map((c) {
                            String shortName = c;
                            if (c == 'Жоғарғы киім') shortName = 'Жоғарғы';
                            if (c == 'Төменгі киім') shortName = 'Төменгі';
                            return Tab(text: shortName);
                          }).toList(),
                        ),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        height: 420,
                        child: TabBarView(
                          controller: _tabController,
                          children: _categories.map(_buildCategoryGrid).toList(),
                        ),
                      ),
                    ],
                  );

                  if (isWide) {
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(flex: 3, child: avatarPreview),
                        const SizedBox(width: 20),
                        Expanded(flex: 5, child: shopTabbedContent),
                      ],
                    );
                  } else {
                    return Column(
                      children: [
                        avatarPreview,
                        const SizedBox(height: 20),
                        shopTabbedContent,
                      ],
                    );
                  }
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCategoryGrid(String category) {
    final items = allShopItems.where((i) => i.category == category).toList();

    return GridView.builder(
      itemCount: items.length,
      physics: const BouncingScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.76,
      ),
      itemBuilder: (context, index) {
        final item = items[index];

        final isLevelLocked = widget.store.level < item.unlockLevel;

        final ownedSet = item.category == 'Питомец' ? widget.store.ownedPets : widget.store.ownedItems;
        final isOwned = ownedSet.contains(item.id) || item.price == 0;

        final isEquipped = item.category == 'Питомец'
            ? widget.store.equippedPet == item.id
            : widget.store.equippedItems.contains(item.id);

        // Dummy none items should count as equipped if set is empty of that category
        bool isDummyEquipped = false;
        if (item.id == 'no-hat') {
          isDummyEquipped = !widget.store.equippedItems.any((x) {
            final eqItem = allShopItems.firstWhere(
              (y) => y.id == x,
              orElse: () => const ShopItem(id: '', name: '', category: '', price: 0, coinPrice: 0, description: '', unlockLevel: 1, previewImage: '', icon: Icons.error, color: Colors.transparent),
            );
            return eqItem.category == 'Бас киім';
          });
        } else if (item.id == 'no-accessory') {
          isDummyEquipped = !widget.store.equippedItems.any((x) {
            final eqItem = allShopItems.firstWhere(
              (y) => y.id == x,
              orElse: () => const ShopItem(id: '', name: '', category: '', price: 0, coinPrice: 0, description: '', unlockLevel: 1, previewImage: '', icon: Icons.error, color: Colors.transparent),
            );
            return eqItem.category == 'Аксессуар';
          });
        } else if (item.id == 'no-pet') {
          isDummyEquipped = widget.store.equippedPet == null;
        }

        final activeEquipped = isEquipped || isDummyEquipped;

        return GlassCard(
          padding: const EdgeInsets.all(12),
          onTap: () => _previewItem(item),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Rarity Tag & Badges row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: item.rarity.color.withValues(alpha: .15),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      item.rarity.label,
                      style: TextStyle(
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                        color: item.rarity.color,
                      ),
                    ),
                  ),
                  if (activeEquipped)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: const BoxDecoration(
                        color: AppColors.success,
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      child: const Text(
                        'Киген',
                        style: TextStyle(fontSize: 8, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                    )
                  else if (isOwned && item.price > 0)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: const BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      child: const Text(
                        'Алынды',
                        style: TextStyle(fontSize: 8, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                    ),
                ],
              ),
              const Spacer(),
              // Icon representation
              Center(
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: item.color.withValues(alpha: .08),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    item.icon,
                    color: isLevelLocked ? AppColors.textMuted : item.color,
                    size: 38,
                  ),
                ),
              ),
              const Spacer(),
              // Item Name
              Text(
                item.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppTypography.headingSmall.copyWith(fontSize: 14),
              ),
              const SizedBox(height: 6),
              // Purchase / Equip button action
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: activeEquipped
                            ? AppColors.bgDarkSurface
                            : (isOwned ? AppColors.primary : AppColors.bgDarkElevated),
                        foregroundColor: Colors.white,
                        elevation: 0,
                        padding: EdgeInsets.zero,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                          side: BorderSide(
                            color: activeEquipped ? AppColors.success : Colors.transparent,
                            width: 1.5,
                          ),
                        ),
                      ),
                      onPressed: isLevelLocked
                          ? () => _showPurchaseConfirmation(item)
                          : (isOwned ? () => _equipOwnedItem(item) : () => _showPurchaseConfirmation(item)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          if (isLevelLocked) ...[
                            const Icon(Icons.lock, size: 12, color: AppColors.error),
                            const SizedBox(width: 4),
                            Text(
                              'Lvl ${item.unlockLevel}',
                              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.error),
                            ),
                          ] else if (activeEquipped) ...[
                            const Icon(Icons.check, size: 12, color: AppColors.success),
                            const SizedBox(width: 4),
                            const Text(
                              'Киілген',
                              style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.success),
                            ),
                          ] else if (isOwned) ...[
                            const Text(
                              'Кию',
                              style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
                            ),
                          ] else ...[
                            const Text(
                              '🪙 ',
                              style: TextStyle(fontSize: 10),
                            ),
                            Text(
                              '${item.price}',
                              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.coin),
                            ),
                          ]
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
