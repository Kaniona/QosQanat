import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../data/store/app_store.dart';
import '../../data/models/friend.dart';

// Screen imports
import '../home/home_screen.dart';
import '../rating/rating_screen.dart';
import '../study/study_screen.dart';
import '../shop/shop_screen.dart';
import '../friends/friends_screen.dart';
import '../profile/profile_screen.dart';
import '../mini_games/mini_games_screen.dart';
import '../../widgets/level_up_modal.dart';

class QosQanatShell extends StatefulWidget {
  const QosQanatShell({required this.store, super.key});

  final AppStore store;

  @override
  State<QosQanatShell> createState() => _QosQanatShellState();
}

class _QosQanatShellState extends State<QosQanatShell> {
  // Navigation Index:
  // 0: HomeScreen, 1: ShopScreen, 2: StudyScreen, 3: FriendsScreen, 4: ProfileScreen
  // 5: RatingScreen, 6: MiniGamesScreen (accessible via actions)
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    widget.store.addListener(_onStoreChanged);
    // Perform daily streak check on app launch
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.store.checkStreak();
    });
  }

  @override
  void dispose() {
    widget.store.removeListener(_onStoreChanged);
    super.dispose();
  }

  void _onStoreChanged() {
    if (widget.store.leveledUpThisSession) {
      widget.store.leveledUpThisSession = false;
      _showLevelUpCelebration();
    }
  }

  void _showLevelUpCelebration() {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withValues(alpha: .9),
      transitionDuration: const Duration(milliseconds: 550),
      pageBuilder: (context, anim1, anim2) {
        return LevelUpModal(
          store: widget.store,
          onClose: () => Navigator.of(context).pop(),
        );
      },
      transitionBuilder: (context, anim1, anim2, child) {
        return FadeTransition(
          opacity: anim1,
          child: ScaleTransition(
            scale: Tween<double>(begin: 0.8, end: 1.0).animate(
              CurvedAnimation(parent: anim1, curve: Curves.easeOutBack),
            ),
            child: child,
          ),
        );
      },
    );
  }

  void _navigateTo(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Pages to render based on navigation index
    final pages = [
      HomeScreen(store: widget.store, onNavigate: _navigateTo),
      ShopScreen(store: widget.store),
      StudyScreen(store: widget.store),
      FriendsScreen(store: widget.store),
      ProfileScreen(store: widget.store),
      RatingScreen(store: widget.store),
      MiniGamesScreen(store: widget.store),
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= 920;

        return Scaffold(
          body: Row(
            children: [
              if (isWide) _buildSidebarRail(),
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: pages[_currentIndex],
                ),
              ),
            ],
          ),
          bottomNavigationBar: isWide ? null : _buildCustomBottomTabBar(),
        );
      },
    );
  }

  // 1. Sidebar Rail for wide displays
  Widget _buildSidebarRail() {
    return Container(
      width: 110,
      decoration: const BoxDecoration(
        color: AppColors.bgDarkCard,
        border: Border(
          right: BorderSide(color: AppColors.glassBorder, width: 0.5),
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 16),
            // Floating brand wing icon
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: .1),
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.primary.withValues(alpha: .3)),
              ),
              child: const Icon(
                Icons.school,
                color: AppColors.neonCyan,
                size: 28,
              ),
            ),
            const SizedBox(height: 30),
            Expanded(
              child: ListView.builder(
                itemCount: 5,
                itemBuilder: (context, index) {
                  final item = _destinations[index];
                  final isSelected = _currentIndex == index;

                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                    child: InkWell(
                      onTap: () => _navigateTo(index),
                      borderRadius: BorderRadius.circular(12),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? widget.store.assistant.color.withValues(alpha: .15)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isSelected
                                ? widget.store.assistant.color.withValues(alpha: .3)
                                : Colors.transparent,
                          ),
                        ),
                        child: Column(
                          children: [
                            Icon(
                              isSelected ? item.selectedIcon : item.icon,
                              color: isSelected
                                  ? widget.store.assistant.color
                                  : AppColors.textMuted,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              item.label,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: isSelected ? FontWeight.w800 : FontWeight.w500,
                                color: isSelected
                                    ? AppColors.textPrimary
                                    : AppColors.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 2. High-Fidelity Custom Bottom Navigation Tab Bar (Middle button raised + notification badge)
  Widget _buildCustomBottomTabBar() {
    final pendingRequests = widget.store.friends
        .where((f) => f.requestStatus == FriendRequestStatus.pendingIncoming)
        .length;

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.bgDarkCard,
        border: Border(
          top: BorderSide(color: AppColors.glassBorder, width: 0.5),
        ),
      ),
      child: SafeArea(
        child: SizedBox(
          height: 72,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(5, (index) {
              final item = _destinations[index];
              final isSelected = _currentIndex == index;

              // Index 2 is the middle "Оқу" tab, which is specially raised and styled
              if (index == 2) {
                return Expanded(
                  child: GestureDetector(
                    onTap: () => _navigateTo(2),
                    child: Stack(
                      alignment: Alignment.center,
                      clipBehavior: Clip.none,
                      children: [
                        Positioned(
                          top: -15,
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 250),
                            width: 58,
                            height: 58,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: isSelected
                                  ? AppColors.goldGradient
                                  : AppColors.primaryGradient,
                              boxShadow: [
                                BoxShadow(
                                  color: (isSelected ? AppColors.neonGold : AppColors.neonCyan)
                                      .withValues(alpha: .4),
                                  blurRadius: 10,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: Icon(
                              item.selectedIcon,
                              color: Colors.white,
                              size: 26,
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 6,
                          child: Text(
                            item.label,
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: isSelected ? FontWeight.w900 : FontWeight.w600,
                              color: isSelected ? AppColors.neonGold : AppColors.textSecondary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }

              // Normal Tab Buttons (Home, Shop, Friends, Profile)
              return Expanded(
                child: Tooltip(
                  message: item.label,
                  child: InkWell(
                    onTap: () => _navigateTo(index),
                    borderRadius: BorderRadius.circular(12),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Stack(
                          clipBehavior: Clip.none,
                          children: [
                            AnimatedScale(
                              scale: isSelected ? 1.15 : 1.0,
                              duration: const Duration(milliseconds: 200),
                              child: Icon(
                                isSelected ? item.selectedIcon : item.icon,
                                color: isSelected
                                    ? AppColors.neonGold
                                    : AppColors.textMuted,
                                size: 22,
                              ),
                            ),
                            // Notification Badges on Friends Tab (Index 3)
                            if (index == 3 && pendingRequests > 0)
                              Positioned(
                                top: -4,
                                right: -4,
                                child: Container(
                                  padding: const EdgeInsets.all(4),
                                  decoration: const BoxDecoration(
                                    color: AppColors.error,
                                    shape: BoxShape.circle,
                                  ),
                                  constraints: const BoxConstraints(
                                    minWidth: 16,
                                    minHeight: 16,
                                  ),
                                  child: Text(
                                    '$pendingRequests',
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 9,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          item.label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: isSelected ? FontWeight.w900 : FontWeight.w600,
                            color: isSelected
                                ? AppColors.neonGold
                                : AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

class _NavItem {
  const _NavItem(this.label, this.icon, this.selectedIcon);
  final String label;
  final IconData icon;
  final IconData selectedIcon;
}

// 5 Main Destinations aligned with user's requested navigation structure
const _destinations = [
  _NavItem('Басты бет', Icons.home_outlined, Icons.home),
  _NavItem('Дүкен', Icons.storefront_outlined, Icons.storefront),
  _NavItem('Оқу', Icons.map_outlined, Icons.map),
  _NavItem('Достар', Icons.group_outlined, Icons.group),
  _NavItem('Профиль', Icons.account_circle_outlined, Icons.account_circle),
];
