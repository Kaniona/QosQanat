import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/constants.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/store/app_store.dart';
import '../../widgets/animated_counter.dart';
import '../../widgets/app_page.dart';
import '../../widgets/glass_card.dart';

class RatingScreen extends StatefulWidget {
  const RatingScreen({required this.store, super.key});

  final AppStore store;

  @override
  State<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends State<RatingScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final List<_LeaderboardUser> _globalLeaderboard = [];
  final List<_LeaderboardUser> _friendsLeaderboard = [];
  final List<_LeaderboardUser> _schoolLeaderboard = [];
  final List<_LeaderboardUser> _cityLeaderboard = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      setState(() {});
    });
    _generateSimulationData();
  }

  void _generateSimulationData() {
    final random = Random(42); // Seed for consistency
    final profile = widget.store.profile!;

    // Current player's ranking entity
    final me = _LeaderboardUser(
      name: '${profile.fullName} (Сен)',
      qqId: profile.qqId,
      wisdom: widget.store.wisdom,
      level: widget.store.level,
      city: profile.city,
      school: profile.school,
      avatarEmoji: '🧑‍🎓',
      isMe: true,
    );

    // 1. Generate Global Competitive Ranks (25 users)
    final Set<String> globalNames = {};
    while (globalNames.length < 25) {
      globalNames.add(AppConstants.randomName());
    }

    final List<_LeaderboardUser> globalUsers = [];
    int idCounter = 100;
    for (final name in globalNames) {
      final wisdom = 300 + random.nextInt(3700);
      final level = 1 + wisdom ~/ 150;
      final city = AppConstants.cities[random.nextInt(AppConstants.cities.length)];
      globalUsers.add(_LeaderboardUser(
        name: name,
        qqId: 'QQ-${idCounter++}0000',
        wisdom: wisdom,
        level: level,
        city: city,
        school: '№${random.nextInt(150)} мектеп-лицейі',
        avatarEmoji: _randomAvatarEmoji(random),
      ));
    }
    globalUsers.add(me);
    globalUsers.sort((a, b) => b.wisdom.compareTo(a.wisdom));
    _globalLeaderboard.addAll(globalUsers);

    // 2. Generate Friends competitive list
    final List<_LeaderboardUser> friendsList = [me];
    for (final f in widget.store.friends) {
      friendsList.add(_LeaderboardUser(
        name: f.name,
        qqId: f.qqId,
        wisdom: f.wisdom,
        level: f.level,
        city: f.city,
        school: '№${random.nextInt(150)} мектеп-лицейі',
        avatarEmoji: f.avatarEmoji,
      ));
    }
    friendsList.sort((a, b) => b.wisdom.compareTo(a.wisdom));
    _friendsLeaderboard.addAll(friendsList);

    // 3. Generate School competitive list
    final List<_LeaderboardUser> schoolList = [me];
    final Set<String> schoolNames = {};
    while (schoolNames.length < 15) {
      schoolNames.add(AppConstants.randomName());
    }
    for (final name in schoolNames) {
      final wisdom = 200 + random.nextInt(1500);
      final level = 1 + wisdom ~/ 160;
      schoolList.add(_LeaderboardUser(
        name: name,
        qqId: 'QQ-${idCounter++}0000',
        wisdom: wisdom,
        level: level,
        city: profile.city,
        school: profile.school,
        avatarEmoji: _randomAvatarEmoji(random),
      ));
    }
    schoolList.sort((a, b) => b.wisdom.compareTo(a.wisdom));
    _schoolLeaderboard.addAll(schoolList);

    // 4. Generate City (Қалам) competitive list
    final List<_LeaderboardUser> cityList = [me];
    final Set<String> cityNames = {};
    while (cityNames.length < 18) {
      cityNames.add(AppConstants.randomName());
    }
    for (final name in cityNames) {
      final wisdom = 250 + random.nextInt(2000);
      final level = 1 + wisdom ~/ 150;
      cityList.add(_LeaderboardUser(
        name: name,
        qqId: 'QQ-${idCounter++}0000',
        wisdom: wisdom,
        level: level,
        city: profile.city,
        school: '№${random.nextInt(100)} мектеп',
        avatarEmoji: _randomAvatarEmoji(random),
      ));
    }
    cityList.sort((a, b) => b.wisdom.compareTo(a.wisdom));
    _cityLeaderboard.addAll(cityList);
  }

  String _randomAvatarEmoji(Random r) {
    const emojis = ['👦', '👧', '🦸', '🦹', '🧙', '🧑‍🚀', '🧑‍💻', '🦊', '🦁', '🦉'];
    return emojis[r.nextInt(emojis.length)];
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  List<_LeaderboardUser> _getCurrentList() {
    switch (_tabController.index) {
      case 0: return _globalLeaderboard;
      case 1: return _friendsLeaderboard;
      case 2: return _schoolLeaderboard;
      case 3: return _cityLeaderboard;
      default: return _globalLeaderboard;
    }
  }

  @override
  Widget build(BuildContext context) {
    final activeList = _getCurrentList();
    final myRank = activeList.indexWhere((u) => u.isMe) + 1;
    final isMeInTop3 = myRank <= 3;
    final meUser = activeList.firstWhere((u) => u.isMe);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AppPage(
        title: 'Ақыл Лигасы 🏆',
        subtitle: 'Ең озық зияткер оқушылар рейтингі',
        actions: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: _getLeagueColor(widget.store.league).withValues(alpha: .15),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _getLeagueColor(widget.store.league), width: 1.5),
            ),
            child: Row(
              children: [
                Icon(Icons.shield, color: _getLeagueColor(widget.store.league), size: 16),
                const SizedBox(width: 4),
                Text(
                  widget.store.league,
                  style: AppTypography.labelSmall.copyWith(
                    color: _getLeagueColor(widget.store.league),
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
        child: Column(
          children: [
            // Tabs Bar
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: AppColors.bgDarkCard.withValues(alpha: .6),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.glassBorder, width: 0.5),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  color: widget.store.assistant.color.withValues(alpha: .2),
                  border: Border.all(color: widget.store.assistant.color.withValues(alpha: .4)),
                  borderRadius: BorderRadius.circular(10),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                dividerColor: Colors.transparent,
                labelColor: Colors.white,
                unselectedLabelColor: AppColors.textSecondary,
                labelStyle: AppTypography.labelSmall.copyWith(fontWeight: FontWeight.w700),
                tabs: const [
                  Tab(text: 'Жалпы'),
                  Tab(text: 'Достарым'),
                  Tab(text: 'Мектебім'),
                  Tab(text: 'Қалам'),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Main Leaderboard Content
            Expanded(
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Column(
                      children: [
                        // Podium Area (Top 3)
                        if (activeList.length >= 3) ...[
                          _buildPodium(
                            top1: activeList[0],
                            top2: activeList[1],
                            top3: activeList[2],
                          ),
                          const SizedBox(height: 16),
                        ],

                        // Scrollable List (Ranks 4+)
                        Expanded(
                          child: ListView.separated(
                            padding: EdgeInsets.only(
                              bottom: !isMeInTop3 ? 90 : 16,
                            ),
                            itemCount: max(0, activeList.length - 3),
                            physics: const BouncingScrollPhysics(),
                            separatorBuilder: (_, __) => const SizedBox(height: 8),
                            itemBuilder: (context, index) {
                              final user = activeList[index + 3];
                              final rank = index + 4;
                              return _buildRankRow(user, rank);
                            },
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Sticky user card at bottom if not in top 3
                  if (!isMeInTop3)
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              AppColors.bgDark.withValues(alpha: .95),
                            ],
                          ),
                        ),
                        child: _buildRankRow(meUser, myRank, isSticky: true),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPodium({
    required _LeaderboardUser top1,
    required _LeaderboardUser top2,
    required _LeaderboardUser top3,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        // Rank 2 (Left)
        Expanded(child: _buildPodiumColumn(top2, 2, 100, AppColors.silver, '🥈')),
        const SizedBox(width: 8),
        // Rank 1 (Center - Tallest)
        Expanded(child: _buildPodiumColumn(top1, 1, 125, AppColors.gold, '🥇', isWinner: true)),
        const SizedBox(width: 8),
        // Rank 3 (Right)
        Expanded(child: _buildPodiumColumn(top3, 3, 85, AppColors.bronze, '🥉')),
      ],
    );
  }

  Widget _buildPodiumColumn(
    _LeaderboardUser user,
    int rank,
    double height,
    Color medalColor,
    String medalEmoji, {
    bool isWinner = false,
  }) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        // Avatar Ring with Crown
        Stack(
          alignment: Alignment.topCenter,
          clipBehavior: Clip.none,
          children: [
            Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: medalColor, width: isWinner ? 3.0 : 1.5),
                boxShadow: isWinner
                    ? [
                        BoxShadow(
                          color: AppColors.gold.withValues(alpha: .35),
                          blurRadius: 15,
                        ),
                      ]
                    : [],
              ),
              child: CircleAvatar(
                radius: isWinner ? 30 : 25,
                backgroundColor: AppColors.bgDarkSurface,
                child: Text(
                  user.avatarEmoji,
                  style: TextStyle(fontSize: isWinner ? 32 : 26),
                ),
              ),
            ),
            if (isWinner)
              const Positioned(
                top: -18,
                child: Text(
                  '👑',
                  style: TextStyle(fontSize: 20),
                ),
              ),
          ],
        ),
        const SizedBox(height: 6),

        // User Details
        Text(
          user.name,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: AppTypography.headingSmall.copyWith(
            color: user.isMe ? AppColors.neonCyan : Colors.white,
            fontSize: isWinner ? 13 : 11,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          user.city,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: AppTypography.bodySmall.copyWith(fontSize: 10),
        ),
        const SizedBox(height: 6),

        // Podium Pillar
        Container(
          height: height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                medalColor.withValues(alpha: .25),
                AppColors.bgDarkCard,
              ],
            ),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
            border: Border.all(color: medalColor.withValues(alpha: .3), width: 1.2),
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      medalEmoji,
                      style: const TextStyle(fontSize: 16),
                    ),
                    const SizedBox(width: 2),
                    Text(
                      '🔥',
                      style: TextStyle(fontSize: isWinner ? 14 : 12),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  '#$rank',
                  style: TextStyle(
                    fontSize: isWinner ? 24 : 18,
                    fontWeight: FontWeight.w900,
                    color: medalColor,
                  ),
                ),
                const SizedBox(height: 2),
                AnimatedCounter(
                  value: user.wisdom,
                  suffix: ' 💎',
                  style: TextStyle(
                    fontSize: isWinner ? 13 : 11,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRankRow(_LeaderboardUser user, int rank, {bool isSticky = false}) {
    final bool isTop3 = rank <= 3;
    final Color rankColor = rank == 1
        ? AppColors.gold
        : rank == 2
            ? AppColors.silver
            : rank == 3
                ? AppColors.bronze
                : user.isMe
                    ? AppColors.neonCyan
                    : AppColors.textSecondary;

    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      backgroundColor: user.isMe
          ? AppColors.neonCyan.withValues(alpha: .1)
          : isSticky
              ? AppColors.bgDarkCard
              : null,
      borderGradient: user.isMe
          ? LinearGradient(colors: [AppColors.neonCyan, AppColors.neonPurple])
          : isSticky
              ? LinearGradient(colors: [AppColors.glassBorder, AppColors.glassBorder])
              : null,
      child: Row(
        children: [
          // Rank Number
          Container(
            width: 32,
            alignment: Alignment.center,
            child: Text(
              '#$rank',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w900,
                color: rankColor,
              ),
            ),
          ),
          const SizedBox(width: 8),

          // Avatar
          Container(
            width: 36,
            height: 36,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.bgDarkSurface,
            ),
            child: Center(
              child: Text(
                user.avatarEmoji,
                style: const TextStyle(fontSize: 20),
              ),
            ),
          ),
          const SizedBox(width: 12),

          // User details
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        user.name,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.headingSmall.copyWith(
                          color: user.isMe ? AppColors.neonCyan : Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    if (isTop3) ...[
                      const SizedBox(width: 4),
                      const Text('🔥', style: TextStyle(fontSize: 12)),
                    ],
                  ],
                ),
                Text(
                  '${user.city} • Lvl ${user.level}',
                  style: AppTypography.bodySmall.copyWith(fontSize: 11),
                ),
              ],
            ),
          ),

          // Points
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '💎 ${user.wisdom}',
                style: AppTypography.headingSmall.copyWith(
                  color: AppColors.wisdom,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 2),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: _getLeagueColor(AppConstants.getLeague(user.wisdom)).withValues(alpha: .15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  AppConstants.getLeague(user.wisdom),
                  style: TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    color: _getLeagueColor(AppConstants.getLeague(user.wisdom)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Color _getLeagueColor(String league) {
    switch (league) {
      case 'Легенда': return AppColors.legend;
      case 'Алмас': return AppColors.diamond;
      case 'Платина': return AppColors.platinum;
      case 'Алтын': return AppColors.gold;
      case 'Күміс': return AppColors.silver;
      case 'Қола':
      default:
        return AppColors.bronze;
    }
  }
}

class _LeaderboardUser {
  _LeaderboardUser({
    required this.name,
    required this.qqId,
    required this.wisdom,
    required this.level,
    required this.city,
    required this.school,
    required this.avatarEmoji,
    this.isMe = false,
  });

  final String name;
  final String qqId;
  final int wisdom;
  final int level;
  final String city;
  final String school;
  final String avatarEmoji;
  final bool isMe;
}
