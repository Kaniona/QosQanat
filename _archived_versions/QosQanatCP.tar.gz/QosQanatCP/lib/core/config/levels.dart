/// Config for levels system in QosQanat
class LevelConfig {
  LevelConfig._();

  /// Calculate XP required for a given level
  /// Formula: xpRequired = level * 100 + (level^2 * 10)
  static int xpRequiredForLevel(int level) {
    if (level < 1) return 100;
    return (level * 100) + (level * level * 10);
  }

  /// Calculates level reward coins
  /// Each level gives: coins = level * 20
  static int coinsRewardForLevel(int level) {
    return level * 20;
  }

  /// Get list of unlocked items/features based on level
  static List<String> getUnlockedFeatures(int level) {
    final features = <String>[];
    if (level >= 2) {
      features.add('Жаңа киімдер мен аксессуарлар 👕');
    }
    if (level >= 3) {
      features.add('Күнделікті қосымша квесттер 📝');
    }
    if (level >= 5) {
      features.add('Ақылды питомдар мен серіктер 🦅');
    }
    if (level >= 8) {
      features.add('Аренадағы жаңа батл режимдер ⚔️');
    }
    if (level >= 10) {
      features.add('Эксклюзивті профиль фондары 🌌');
    }
    if (level >= 15) {
      features.add('Аңызға айналған «Алтын Тәж» 👑');
    }
    return features;
  }
}
