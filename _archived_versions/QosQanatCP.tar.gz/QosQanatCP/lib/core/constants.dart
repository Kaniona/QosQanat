import 'dart:math';

/// QosQanat Constants
class AppConstants {
  AppConstants._();

  static const String appName = 'QosQanat';
  static const String tagline = 'Екі қанатпен ұш — білім мен арманмен';

  /// Generate QQ-ID like QQ-123456789
  static String generateQqId() {
    final number = 100000000 + Random().nextInt(900000000);
    return 'QQ-$number';
  }

  /// Date key for streak tracking
  static String dateKey(DateTime date) {
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '${date.year}-$month-$day';
  }

  /// Battle question counts
  static const List<int> battleQuestionCounts = [15, 20, 25, 40, 50];

  /// League thresholds
  static const Map<String, int> leagueThresholds = {
    'Қола': 0,
    'Күміс': 200,
    'Алтын': 500,
    'Платина': 1000,
    'Алмас': 2000,
    'Легенда': 5000,
  };

  /// Get league name from wisdom
  static String getLeague(int wisdom) {
    if (wisdom >= 5000) return 'Легенда';
    if (wisdom >= 2000) return 'Алмас';
    if (wisdom >= 1000) return 'Платина';
    if (wisdom >= 500) return 'Алтын';
    if (wisdom >= 200) return 'Күміс';
    return 'Қола';
  }

  /// Kazakh cities
  static const List<String> cities = [
    'Астана', 'Алматы', 'Шымкент', 'Қарағанды', 'Ақтөбе',
    'Тараз', 'Павлодар', 'Өскемен', 'Семей', 'Атырау',
    'Қостанай', 'Қызылорда', 'Орал', 'Петропавл', 'Ақтау',
    'Теміртау', 'Түркістан', 'Көкшетау', 'Талдықорған', 'Екібастұз',
  ];

  /// Kazakh names for simulated users
  static const List<String> boyNames = [
    'Ерасыл', 'Нұрсұлтан', 'Алихан', 'Дәмір', 'Әлішер',
    'Арнұр', 'Бекзат', 'Данияр', 'Ермек', 'Қайрат',
    'Мұхтар', 'Нұрлан', 'Олжас', 'Рамазан', 'Сұлтан',
  ];

  static const List<String> girlNames = [
    'Айзере', 'Медина', 'Аружан', 'Айша', 'Дана',
    'Жансая', 'Зарина', 'Інжу', 'Камила', 'Ләззат',
    'Мадина', 'Нұргүл', 'Айсұлу', 'Сәуле', 'Томирис',
  ];

  static String randomName() {
    final all = [...boyNames, ...girlNames];
    return all[Random().nextInt(all.length)];
  }
}
