import 'package:flutter/material.dart';

/// QosQanat Premium Color Palette
/// Dark-first gaming aesthetic with neon accents
class AppColors {
  AppColors._();

  // ─── Primary Brand ───
  static const Color primary = Color(0xFF2D7FF9);
  static const Color primaryDark = Color(0xFF1A5FC2);
  static const Color primaryLight = Color(0xFF5CA0FF);

  // ─── Secondary / Accent ───
  static const Color secondary = Color(0xFF0CEBAB);
  static const Color secondaryDark = Color(0xFF08B886);

  // ─── Neon Accents ───
  static const Color neonCyan = Color(0xFF00E5FF);
  static const Color neonMagenta = Color(0xFFFF2D78);
  static const Color neonGold = Color(0xFFFFD600);
  static const Color neonPurple = Color(0xFFB388FF);
  static const Color neonGreen = Color(0xFF69F0AE);

  // ─── Gamification ───
  static const Color wisdom = Color(0xFF448AFF);
  static const Color coin = Color(0xFFFFAB00);
  static const Color exp = Color(0xFF00E676);
  static const Color streak = Color(0xFFFF6D00);

  // ─── Rarity ───
  static const Color common = Color(0xFF90A4AE);
  static const Color rare = Color(0xFF42A5F5);
  static const Color epic = Color(0xFFAB47BC);
  static const Color legendary = Color(0xFFFFD600);

  // ─── League ───
  static const Color bronze = Color(0xFFCD7F32);
  static const Color silver = Color(0xFFC0C0C0);
  static const Color gold = Color(0xFFFFD700);
  static const Color platinum = Color(0xFFE5E4E2);
  static const Color diamond = Color(0xFF00BCD4);
  static const Color legend = Color(0xFFFF6D00);

  // ─── Dark Theme Base ───
  static const Color bgDark = Color(0xFF0A0E21);
  static const Color bgDarkCard = Color(0xFF111633);
  static const Color bgDarkSurface = Color(0xFF1A1F3D);
  static const Color bgDarkElevated = Color(0xFF222859);

  // ─── Glassmorphism ───
  static const Color glassWhite = Color(0x14FFFFFF);
  static const Color glassBorder = Color(0x33FFFFFF);
  static const Color glassHighlight = Color(0x0DFFFFFF);

  // ─── Text ───
  static const Color textPrimary = Color(0xFFF0F4FF);
  static const Color textSecondary = Color(0xFF8B97B8);
  static const Color textMuted = Color(0xFF5A6484);

  // ─── Status ───
  static const Color success = Color(0xFF00E676);
  static const Color error = Color(0xFFFF5252);
  static const Color warning = Color(0xFFFFAB00);
  static const Color info = Color(0xFF448AFF);

  // ─── Assistant Specific ───
  static const Color bekturPrimary = Color(0xFF2D7FF9);
  static const Color bekturAccent = Color(0xFF0CEBAB);
  static const Color nazymPrimary = Color(0xFFE91E78);
  static const Color nazymAccent = Color(0xFFFF9100);

  // ─── Gradients ───
  static const LinearGradient bgGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF0A0E21), Color(0xFF141A3C), Color(0xFF0D1230)],
  );

  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF2D7FF9), Color(0xFF0CEBAB)],
  );

  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFFFD600), Color(0xFFFF9100)],
  );

  static const LinearGradient magentaGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFE91E78), Color(0xFFFF6090)],
  );

  static const LinearGradient successGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF00E676), Color(0xFF00BFA5)],
  );

  static const LinearGradient errorGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFFF5252), Color(0xFFFF1744)],
  );
}
