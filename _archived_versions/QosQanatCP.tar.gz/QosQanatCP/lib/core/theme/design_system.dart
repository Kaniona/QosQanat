import 'package:flutter/material.dart';

/// QosQanat World-Class Kazakh-Inspired Visual Design System
/// Defines unified design tokens for colors, typography, spacing, shadows, and animations.
class DesignSystem {
  DesignSystem._();

  // ───────────────────────────────────────────────────────────────────────────
  // 1. COLOR PALETTE (Kazakh-Inspired: Deep Blue, Gold, Sky Blue, Silk White)
  // ───────────────────────────────────────────────────────────────────────────
  static const Color kazakhDeepBlue = Color(0xFF0B1437); // Deep steppe night sky
  static const Color kazakhSkyBlue = Color(0xFF38BDF8);  // Flag blue sky / freedom
  static const Color kazakhGold = Color(0xFFFFD600);     // Altyn / Golden warrior / Sun
  static const Color shanyrakGold = Color(0xFFFBBF24);   // Warm dome gold
  static const Color silkWhite = Color(0xFFF8FAFC);      // Clean snow / pure white
  static const Color steppeSilver = Color(0xFFE2E8F0);   // Silver jewelry luster

  // Dark gaming card surfaces
  static const Color cardBg = Color(0xFF111827);         // Matte dark slate
  static const Color surfaceBg = Color(0xFF1E293B);      // Sleek navy slate
  static const Color borderGlass = Color(0x22FFFFFF);    // Frosted glass border

  static const LinearGradient kazakhFlagGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [kazakhSkyBlue, Color(0xFF0284C7)],
  );

  static const LinearGradient goldenSunGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [kazakhGold, shanyrakGold],
  );

  static const LinearGradient deepSteppeGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [kazakhDeepBlue, Color(0xFF0F172A)],
  );

  // ───────────────────────────────────────────────────────────────────────────
  // 2. TYPOGRAPHY SCALE (Flexible, modern font pairing)
  // ───────────────────────────────────────────────────────────────────────────
  static const String fontFamily = 'Outfit'; // Premium geometric brand font

  static TextStyle get displayLarge => const TextStyle(
        fontFamily: fontFamily,
        fontSize: 34,
        fontWeight: FontWeight.w900,
        color: silkWhite,
        letterSpacing: -0.8,
        height: 1.15,
      );

  static TextStyle get displayMedium => const TextStyle(
        fontFamily: fontFamily,
        fontSize: 28,
        fontWeight: FontWeight.w900,
        color: silkWhite,
        letterSpacing: -0.5,
        height: 1.2,
      );

  static TextStyle get headingLarge => const TextStyle(
        fontFamily: fontFamily,
        fontSize: 22,
        fontWeight: FontWeight.w800,
        color: silkWhite,
        letterSpacing: -0.3,
        height: 1.25,
      );

  static TextStyle get headingMedium => const TextStyle(
        fontFamily: fontFamily,
        fontSize: 18,
        fontWeight: FontWeight.w800,
        color: silkWhite,
        height: 1.3,
      );

  static TextStyle get headingSmall => const TextStyle(
        fontFamily: fontFamily,
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: silkWhite,
        height: 1.3,
      );

  static TextStyle get bodyLarge => const TextStyle(
        fontFamily: fontFamily,
        fontSize: 16,
        fontWeight: FontWeight.w500,
        color: silkWhite,
        height: 1.5,
      );

  static TextStyle get bodyMedium => const TextStyle(
        fontFamily: fontFamily,
        fontSize: 14,
        fontWeight: FontWeight.w500,
        color: steppeSilver,
        height: 1.45,
      );

  static TextStyle get bodySmall => const TextStyle(
        fontFamily: fontFamily,
        fontSize: 12,
        fontWeight: FontWeight.w400,
        color: Color(0xFF94A3B8),
        height: 1.4,
      );

  static TextStyle get labelMedium => const TextStyle(
        fontFamily: fontFamily,
        fontSize: 12,
        fontWeight: FontWeight.w700,
        color: steppeSilver,
        letterSpacing: 0.5,
      );

  // ───────────────────────────────────────────────────────────────────────────
  // 3. SPACING SYSTEM
  // ───────────────────────────────────────────────────────────────────────────
  static const double spaceXXS = 4.0;
  static const double spaceXS = 8.0;
  static const double spaceSM = 12.0;
  static const double spaceMD = 16.0;
  static const double spaceLG = 24.0;
  static const double spaceXL = 32.0;
  static const double spaceXXL = 48.0;

  // ───────────────────────────────────────────────────────────────────────────
  // 4. SHADOW / ELEVATION TOKENS
  // ───────────────────────────────────────────────────────────────────────────
  static List<BoxShadow> get softShadow => [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.2),
          blurRadius: 10,
          offset: const Offset(0, 4),
        ),
      ];

  static List<BoxShadow> get goldGlow => [
        BoxShadow(
          color: kazakhGold.withValues(alpha: 0.35),
          blurRadius: 16,
          spreadRadius: 1,
          offset: const Offset(0, 0),
        ),
      ];

  static List<BoxShadow> get neonBlueGlow => [
        BoxShadow(
          color: kazakhSkyBlue.withValues(alpha: 0.35),
          blurRadius: 16,
          spreadRadius: 1,
          offset: const Offset(0, 0),
        ),
      ];

  static List<BoxShadow> get glassShadow => [
        BoxShadow(
          color: Colors.white.withValues(alpha: 0.05),
          blurRadius: 12,
          spreadRadius: 1,
        ),
      ];

  // ───────────────────────────────────────────────────────────────────────────
  // 5. ANIMATION PRESETS (Spring & Bounce curves & durations)
  // ───────────────────────────────────────────────────────────────────────────
  static const Curve springCurve = Curves.elasticOut;
  static const Curve bounceCurve = Curves.bounceOut;
  static const Curve backCurve = Curves.easeOutBack;
  static const Curve smoothCurve = Curves.easeInOutQuad;

  static const Duration durationQuick = Duration(milliseconds: 200);
  static const Duration durationStandard = Duration(milliseconds: 350);
  static const Duration durationSpring = Duration(milliseconds: 650);
  static const Duration durationBounce = Duration(milliseconds: 900);
}
