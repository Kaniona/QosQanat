import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../data/models/assistant_kind.dart';

/// Highly interactive premium dynamic vector assistant avatar
/// Renders dynamic accessories, expressions, animations, and pet companions
class AssistantAvatar extends StatefulWidget {
  const AssistantAvatar({
    required this.assistant,
    this.size = 130,
    this.equippedItems = const {},
    this.equippedPet,
    this.equippedBackground = 'bg-default',
    this.mood = 'neutral',
    super.key,
  });

  final AssistantKind assistant;
  final double size;
  final Set<String> equippedItems;
  final String? equippedPet;
  final String equippedBackground;
  final String mood; // neutral, happy, thinking, celebrating

  @override
  State<AssistantAvatar> createState() => _AssistantAvatarState();
}

class _AssistantAvatarState extends State<AssistantAvatar>
    with SingleTickerProviderStateMixin {
  late AnimationController _idleController;
  late Animation<double> _breatheAnimation;
  final Random _random = Random();
  bool _isBlinking = false;
  Timer? _blinkTimer;

  @override
  void initState() {
    super.initState();
    _idleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _breatheAnimation = Tween<double>(begin: 0.0, end: 4.0).animate(
      CurvedAnimation(parent: _idleController, curve: Curves.easeInOutSine),
    );

    _startBlinkTimer();
  }

  void _startBlinkTimer() {
    _blinkTimer?.cancel();
    _blinkTimer = Timer(Duration(seconds: _random.nextInt(4) + 2), () {
      if (!mounted) return;
      setState(() => _isBlinking = true);
      _blinkTimer = Timer(const Duration(milliseconds: 150), () {
        if (!mounted) return;
        setState(() => _isBlinking = false);
        _startBlinkTimer();
      });
    });
  }

  @override
  void dispose() {
    _idleController.dispose();
    _blinkTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.size;

    // Background Gradient based on equippedBackground
    final bgGradient = _getBackgroundGradient();

    // Clothes colors
    final clothGradient = _getClothGradient();

    return SizedBox(
      width: size,
      height: size,
      child: AnimatedBuilder(
        animation: _breatheAnimation,
        builder: (context, child) {
          final breathe = _breatheAnimation.value;
          return Stack(
            alignment: Alignment.center,
            children: [
              // 1. Base Container / Background Scenic frame
              Container(
                width: size,
                height: size,
                decoration: BoxDecoration(
                  gradient: bgGradient,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: widget.assistant.color.withValues(alpha: .3),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: widget.assistant.color.withValues(alpha: .2),
                      blurRadius: 10,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),

              // 1.5 Backpack peeking behind
              if (widget.equippedItems.contains('backpack'))
                Positioned(
                  bottom: size * 0.12 + (breathe * 0.3),
                  right: size * 0.12,
                  child: Icon(
                    Icons.backpack,
                    size: size * 0.35,
                    color: const Color(0xFF64B5F6),
                  ),
                ),

              // 2. Pet Companion (If equipped and not 'no-pet')
              if (widget.equippedPet != null && widget.equippedPet != 'no-pet')
                Positioned(
                  left: size * 0.04,
                  bottom: size * 0.04,
                  child: _buildPetCompanion(),
                ),

              // 2.5. Bottoms Layer (Pants/Skirt)
              Positioned(
                bottom: size * 0.05 + (breathe * 0.1),
                child: Container(
                  width: size * 0.52,
                  height: size * 0.12,
                  decoration: BoxDecoration(
                    gradient: _getPantsGradient(),
                    borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: .15),
                        blurRadius: 3,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                ),
              ),

              // 3. Body Clothing base (Tops)
              Positioned(
                bottom: size * 0.08 + (breathe * 0.3),
                child: Container(
                  width: size * 0.54,
                  height: size * 0.42,
                  decoration: BoxDecoration(
                    gradient: clothGradient,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                      bottomLeft: Radius.circular(16),
                      bottomRight: Radius.circular(16),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: .2),
                        blurRadius: 4,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                ),
              ),

              // 3.5. Wristband overlay
              if (widget.equippedItems.contains('wristband'))
                Positioned(
                  bottom: size * 0.14 + (breathe * 0.3),
                  right: size * 0.22,
                  child: Container(
                    width: size * 0.08,
                    height: size * 0.03,
                    decoration: BoxDecoration(
                      color: const Color(0xFFFF8A80),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),

              // 4. Head (Face)
              Positioned(
                top: size * 0.18 + (breathe * 0.8),
                child: Container(
                  width: size * 0.46,
                  height: size * 0.46,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFD5B4), // warm skin tone
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: widget.assistant.color.withValues(alpha: .5),
                      width: 1.5,
                    ),
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Star earrings (Nazym only)
                      if (widget.assistant == AssistantKind.nazym && widget.equippedItems.contains('star-earrings')) ...[
                        Positioned(
                          left: size * 0.02,
                          top: size * 0.22,
                          child: const Icon(Icons.star, size: 14, color: Color(0xFFFF4081)),
                        ),
                        Positioned(
                          right: size * 0.02,
                          top: size * 0.22,
                          child: const Icon(Icons.star, size: 14, color: Color(0xFFFF4081)),
                        ),
                      ],

                      // Eyes (with active blink)
                      Positioned(
                        left: size * 0.10,
                        top: size * 0.16,
                        child: _buildEye(),
                      ),
                      Positioned(
                        right: size * 0.10,
                        top: size * 0.16,
                        child: _buildEye(),
                      ),

                      // Mouth (Mood expressions)
                      Positioned(
                        bottom: size * 0.11,
                        child: _buildMouth(),
                      ),

                      // Glasses layer
                      if (widget.equippedItems.contains('glasses'))
                        _buildGlasses(const Color(0xFF1E293B)),
                      if (widget.equippedItems.contains('neon-glasses'))
                        _buildGlasses(const Color(0xFF00E5FF)),
                      if (widget.equippedItems.contains('pilot-glasses'))
                        _buildPilotGlasses(),
                      if (widget.equippedItems.contains('vr-headset'))
                        _buildVrHeadset(),
                    ],
                  ),
                ),
              ),

              // 5. Hair
              Positioned(
                top: size * 0.12 + (breathe * 0.8),
                child: _buildHair(),
              ),

              // 6. Accessories overlay: Bas kiim (Cap, Crown, Hats)
              if (widget.equippedItems.contains('cap'))
                Positioned(
                  top: size * 0.02 + (breathe * 0.8),
                  child: Icon(
                    Icons.school,
                    size: size * 0.3,
                    color: widget.assistant.accent,
                  ),
                ),

              if (widget.equippedItems.contains('baseball-cap'))
                Positioned(
                  top: size * 0.04 + (breathe * 0.8),
                  child: Icon(
                    Icons.directions_run,
                    size: size * 0.28,
                    color: const Color(0xFF00E5FF),
                  ),
                ),

              if (widget.equippedItems.contains('winter-hat'))
                Positioned(
                  top: size * 0.04 + (breathe * 0.8),
                  child: Icon(
                    Icons.ac_unit,
                    size: size * 0.28,
                    color: const Color(0xFF81C784),
                  ),
                ),

              if (widget.equippedItems.contains('traditional-takiya'))
                Positioned(
                  top: size * 0.01 + (breathe * 0.8),
                  child: Icon(
                    Icons.workspace_premium,
                    size: size * 0.32,
                    color: const Color(0xFFFFD600),
                  ),
                ),

              if (widget.equippedItems.contains('graduation-cap'))
                Positioned(
                  top: size * 0.01 + (breathe * 0.8),
                  child: Icon(
                    Icons.school,
                    size: size * 0.32,
                    color: const Color(0xFFB388FF),
                  ),
                ),

              if (widget.equippedItems.contains('smart-crown'))
                Positioned(
                  top: size * -0.01 + (breathe * 0.8),
                  child: Icon(
                    Icons.workspace_premium,
                    size: size * 0.32,
                    color: const Color(0xFFFFD600),
                  ),
                ),

              if (widget.equippedItems.contains('legend-crown'))
                Positioned(
                  top: size * -0.02 + (breathe * 0.8),
                  child: Icon(
                    Icons.diamond,
                    size: size * 0.34,
                    color: const Color(0xFFFFD600),
                  ),
                ),

              if (widget.equippedItems.contains('wizard-hat'))
                Positioned(
                  top: size * -0.04 + (breathe * 0.8),
                  child: Icon(
                    Icons.auto_awesome,
                    size: size * 0.34,
                    color: const Color(0xFFB388FF),
                  ),
                ),

              // 7. Accessories overlay: Alqa (Necklace, chain, pendant)
              if (widget.equippedItems.contains('necklace'))
                Positioned(
                  bottom: size * 0.22 + (breathe * 0.3),
                  child: Icon(
                    Icons.diamond,
                    size: size * 0.18,
                    color: const Color(0xFFFF2D78),
                  ),
                ),
              if (widget.equippedItems.contains('gold-chain'))
                Positioned(
                  bottom: size * 0.23 + (breathe * 0.3),
                  child: Icon(
                    Icons.link,
                    size: size * 0.16,
                    color: const Color(0xFFFFD600),
                  ),
                ),
              if (widget.equippedItems.contains('star-pendant'))
                Positioned(
                  bottom: size * 0.22 + (breathe * 0.3),
                  child: Icon(
                    Icons.star,
                    size: size * 0.18,
                    color: const Color(0xFF00E5FF),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }

  // Helper Methods for building vector parts
  Gradient _getBackgroundGradient() {
    switch (widget.equippedBackground) {
      case 'bg-steppe':
        return const LinearGradient(
          colors: [Color(0xFF2E7D32), Color(0xFF4CAF50), Color(0xFF81C784)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        );
      case 'bg-space':
        return const LinearGradient(
          colors: [Color(0xFF0D1B2A), Color(0xFF1B263B), Color(0xFF415A77)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
      case 'bg-neon':
        return const LinearGradient(
          colors: [Color(0xFF310A31), Color(0xFF845EC2), Color(0xFFFF6F91)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
      case 'bg-default':
      default:
        return LinearGradient(
          colors: [
            widget.assistant.color.withValues(alpha: .2),
            widget.assistant.accent.withValues(alpha: .08),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
    }
  }

  Gradient _getPantsGradient() {
    if (widget.equippedItems.contains('jeans')) {
      return const LinearGradient(
        colors: [Color(0xFF1E88E5), Color(0xFF1565C0)],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      );
    }
    if (widget.equippedItems.contains('sweatpants')) {
      return const LinearGradient(
        colors: [Color(0xFF78909C), Color(0xFF455A64)],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      );
    }
    if (widget.equippedItems.contains('traditional-pants')) {
      return const LinearGradient(
        colors: [Color(0xFFFFB300), Color(0xFFE65100)],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      );
    }
    // Default school pants
    return const LinearGradient(
      colors: [Color(0xFF37474F), Color(0xFF212121)],
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
    );
  }

  Gradient _getClothGradient() {
    if (widget.equippedItems.contains('hoodie-blue')) {
      return const LinearGradient(
        colors: [Color(0xFF2196F3), Color(0xFF0D47A1)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
    }
    if (widget.equippedItems.contains('hoodie-red')) {
      return const LinearGradient(
        colors: [Color(0xFFF44336), Color(0xFFB71C1C)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
    }
    if (widget.equippedItems.contains('sports-jersey')) {
      return const LinearGradient(
        colors: [Color(0xFF4CAF50), Color(0xFF2E7D32)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
    }
    if (widget.equippedItems.contains('leather-jacket')) {
      return const LinearGradient(
        colors: [Color(0xFF37474F), Color(0xFF212121)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
    }
    if (widget.equippedItems.contains('traditional-chapan')) {
      return const LinearGradient(
        colors: [Color(0xFFFFAB00), Color(0xFFFF6D00)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
    }

    // Default base jacket
    return const LinearGradient(
      colors: [Color(0xFF2D7FF9), Color(0xFF1565C0)],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  Widget _buildEye() {
    final eyeSize = widget.size * 0.05;
    if (_isBlinking) {
      return Container(
        width: eyeSize,
        height: 1.5,
        color: const Color(0xFF1A1A2E),
      );
    }
    return Container(
      width: eyeSize,
      height: eyeSize,
      decoration: const BoxDecoration(
        color: Color(0xFF1A1A2E),
        shape: BoxShape.circle,
      ),
    );
  }

  Widget _buildMouth() {
    final size = widget.size;
    final mood = widget.mood;

    if (mood == 'happy' || mood == 'celebrating') {
      return Container(
        width: size * 0.08,
        height: size * 0.04,
        decoration: const BoxDecoration(
          color: Color(0xFF7A3E24),
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
        ),
      );
    } else if (mood == 'thinking') {
      return Container(
        width: size * 0.06,
        height: 3,
        decoration: BoxDecoration(
          color: const Color(0xFF7A3E24),
          borderRadius: BorderRadius.circular(2),
        ),
      );
    }

    // Default neat slight smile
    return Container(
      width: size * 0.07,
      height: size * 0.02,
      decoration: const BoxDecoration(
        color: Color(0xFF7A3E24),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(10)),
      ),
    );
  }

  Widget _buildHair() {
    final size = widget.size;
    final isBektur = widget.assistant == AssistantKind.bektur;

    return Container(
      width: size * 0.49,
      height: size * 0.18,
      decoration: BoxDecoration(
        color: widget.assistant.hairColor,
        borderRadius: isBektur
            ? const BorderRadius.vertical(top: Radius.circular(80))
            : const BorderRadius.only(
                topLeft: Radius.circular(80),
                topRight: Radius.circular(80),
                bottomLeft: Radius.circular(40),
                bottomRight: Radius.circular(40),
              ),
      ),
    );
  }

  Widget _buildGlasses(Color borderCol) {
    final size = widget.size;
    return Positioned(
      left: size * 0.06,
      right: size * 0.06,
      top: size * 0.13,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            width: size * 0.13,
            height: size * 0.09,
            decoration: BoxDecoration(
              border: Border.all(color: borderCol, width: 2),
              borderRadius: BorderRadius.circular(6),
            ),
          ),
          Container(
            width: size * 0.06,
            height: 2,
            color: borderCol,
          ),
          Container(
            width: size * 0.13,
            height: size * 0.09,
            decoration: BoxDecoration(
              border: Border.all(color: borderCol, width: 2),
              borderRadius: BorderRadius.circular(6),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPilotGlasses() {
    final size = widget.size;
    final goldColor = const Color(0xFFFFD600);
    return Positioned(
      left: size * 0.05,
      right: size * 0.05,
      top: size * 0.12,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: size * 0.14,
            height: size * 0.11,
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: .7),
              border: Border.all(color: goldColor, width: 1.5),
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(16),
                bottomRight: Radius.circular(10),
                topLeft: Radius.circular(6),
                topRight: Radius.circular(6),
              ),
            ),
          ),
          Container(
            width: size * 0.04,
            height: 2,
            color: goldColor,
          ),
          Container(
            width: size * 0.14,
            height: size * 0.11,
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: .7),
              border: Border.all(color: goldColor, width: 1.5),
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(10),
                bottomRight: Radius.circular(16),
                topLeft: Radius.circular(6),
                topRight: Radius.circular(6),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVrHeadset() {
    final size = widget.size;
    return Positioned(
      left: size * 0.04,
      right: size * 0.04,
      top: size * 0.11,
      child: Container(
        height: size * 0.14,
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E2F),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: const Color(0xFFAB47BC), width: 2),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFAB47BC).withValues(alpha: .5),
              blurRadius: 6,
            ),
          ],
        ),
        child: Center(
          child: Container(
            width: size * 0.2,
            height: 3,
            decoration: BoxDecoration(
              color: const Color(0xFF00E5FF),
              borderRadius: BorderRadius.circular(1),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPetCompanion() {
    final petSize = widget.size * 0.25;
    IconData petIcon = Icons.pets;
    Color petColor = const Color(0xFF0CEBAB);

    switch (widget.equippedPet) {
      case 'white-cat':
        petIcon = Icons.pets;
        petColor = Colors.white;
        break;
      case 'wolf-pup':
        petIcon = Icons.pets;
        petColor = const Color(0xFF90A4AE);
        break;
      case 'robot-companion':
        petIcon = Icons.smart_toy;
        petColor = const Color(0xFF00E5FF);
        break;
      case 'golden-eagle':
        petIcon = Icons.flight;
        petColor = const Color(0xFFFFB300);
        break;
      case 'snow-leopard':
        petIcon = Icons.pets;
        petColor = const Color(0xFFCFD8DC);
        break;
    }

    return Container(
      width: petSize,
      height: petSize,
      decoration: BoxDecoration(
        color: petColor.withValues(alpha: .2),
        shape: BoxShape.circle,
        border: Border.all(color: petColor, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: petColor.withValues(alpha: .3),
            blurRadius: 6,
          ),
        ],
      ),
      child: Center(
        child: Icon(
          petIcon,
          size: petSize * 0.6,
          color: petColor,
        ),
      ),
    );
  }
}
