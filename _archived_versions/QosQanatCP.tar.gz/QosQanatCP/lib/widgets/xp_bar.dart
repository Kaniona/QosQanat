import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/design_system.dart';

/// Premium XP Bar Component with custom level badge and close-to-levelup glowing effect.
class XPBar extends StatelessWidget {
  const XPBar({
    required this.currentXp,
    required this.xpForNextLevel,
    required this.level,
    super.key,
  });

  final int currentXp;
  final int xpForNextLevel;
  final int level;

  @override
  Widget build(BuildContext context) {
    final double percentage = xpForNextLevel > 0
        ? (currentXp / xpForNextLevel).clamp(0.0, 1.0)
        : 0.0;
    final bool closeToLevelUp = percentage >= 0.8;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.bgDarkCard.withValues(alpha: .6),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: closeToLevelUp
              ? AppColors.neonGold.withValues(alpha: .4)
              : AppColors.glassBorder,
          width: closeToLevelUp ? 1.5 : 1,
        ),
        boxShadow: closeToLevelUp
            ? [
                BoxShadow(
                  color: AppColors.neonGold.withValues(alpha: .15),
                  blurRadius: 16,
                  spreadRadius: 1,
                )
              ]
            : [],
      ),
      child: Row(
        children: [
          // ── Level Badge ──
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: closeToLevelUp
                  ? DesignSystem.goldenSunGradient
                  : DesignSystem.kazakhFlagGradient,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: (closeToLevelUp ? AppColors.neonGold : AppColors.primary)
                      .withValues(alpha: .4),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                )
              ],
            ),
            child: Center(
              child: Text(
                'Lvl\n$level',
                textAlign: TextAlign.center,
                style: DesignSystem.labelMedium.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 11,
                  height: 1.1,
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),

          // ── Progress Bar & Text ──
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      closeToLevelUp ? 'ДЕНГЕЙ КӨТЕРІЛУГЕ ЖАҚЫН! 🔥' : 'Тәжірибе (EXP)',
                      style: DesignSystem.labelMedium.copyWith(
                        color: closeToLevelUp ? AppColors.neonGold : DesignSystem.steppeSilver,
                        fontWeight: closeToLevelUp ? FontWeight.w900 : FontWeight.w700,
                      ),
                    ),
                    Text(
                      '$currentXp / $xpForNextLevel XP',
                      style: DesignSystem.labelMedium.copyWith(
                        color: closeToLevelUp ? Colors.white : AppColors.textSecondary,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    height: 10,
                    color: AppColors.bgDarkSurface,
                    child: Stack(
                      children: [
                        // Progressive Bar
                        TweenAnimationBuilder<double>(
                          tween: Tween<double>(begin: 0, end: percentage),
                          duration: const Duration(milliseconds: 600),
                          curve: Curves.easeOutCubic,
                          builder: (context, val, _) {
                            return FractionallySizedBox(
                              widthFactor: val,
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: closeToLevelUp
                                      ? DesignSystem.goldenSunGradient
                                      : DesignSystem.kazakhFlagGradient,
                                  boxShadow: closeToLevelUp
                                      ? [
                                          BoxShadow(
                                            color: AppColors.neonGold.withValues(alpha: .6),
                                            blurRadius: 8,
                                            spreadRadius: 2,
                                          )
                                        ]
                                      : [],
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
