import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_typography.dart';

/// Premium Neon Glow Button with pulsing shadows and smooth tap animation
class GlowButton extends StatefulWidget {
  const GlowButton({
    required this.label,
    required this.onPressed,
    this.color = AppColors.primary,
    this.glowColor,
    this.icon,
    this.height = 52,
    this.borderRadius = 14,
    super.key,
  });

  final String label;
  final VoidCallback? onPressed;
  final Color color;
  final Color? glowColor;
  final IconData? icon;
  final double height;
  final double borderRadius;

  @override
  State<GlowButton> createState() => _GlowButtonState();
}

class _GlowButtonState extends State<GlowButton>
    with SingleTickerProviderStateMixin {
  bool _isHovered = false;
  bool _isTapped = false;
  late AnimationController _pulseController;
  late Animation<double> _glowScale;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _glowScale = Tween<double>(begin: 4.0, end: 12.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final finalGlow = widget.glowColor ?? widget.color.withValues(alpha: .5);
    final enabled = widget.onPressed != null;

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _isTapped = true),
        onTapUp: (_) => setState(() => _isTapped = false),
        onTapCancel: () => setState(() => _isTapped = false),
        onTap: widget.onPressed,
        child: AnimatedScale(
          scale: !enabled ? 1.0 : (_isTapped ? 0.96 : (_isHovered ? 1.02 : 1.0)),
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOutCubic,
          child: AnimatedBuilder(
            animation: _glowScale,
            builder: (context, child) {
              return Container(
                height: widget.height,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(widget.borderRadius),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: enabled
                        ? [widget.color, widget.color.withValues(alpha: .85)]
                        : [AppColors.textMuted, AppColors.bgDarkElevated],
                  ),
                  boxShadow: !enabled
                      ? []
                      : [
                          BoxShadow(
                            color: finalGlow,
                            blurRadius: _glowScale.value + (_isHovered ? 4.0 : 0.0),
                            spreadRadius: 1.0,
                            offset: const Offset(0, 2),
                          ),
                        ],
                ),
                child: Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (widget.icon != null) ...[
                        Icon(
                          widget.icon,
                          color: enabled ? Colors.white : AppColors.textMuted,
                          size: 20,
                        ),
                        const SizedBox(width: 8),
                      ],
                      Text(
                        widget.label,
                        style: AppTypography.button.copyWith(
                          color: enabled ? Colors.white : AppColors.textMuted,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
