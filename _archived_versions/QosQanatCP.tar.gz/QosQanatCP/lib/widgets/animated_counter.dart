import 'package:flutter/material.dart';

/// Animated Counter for smooth number counting animation (e.g. coin increment, wisdom update)
class AnimatedCounter extends StatelessWidget {
  const AnimatedCounter({
    required this.value,
    this.style,
    this.prefix = '',
    this.suffix = '',
    this.duration = const Duration(milliseconds: 800),
    super.key,
  });

  final int value;
  final TextStyle? style;
  final String prefix;
  final String suffix;
  final Duration duration;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0.0, end: value.toDouble()),
      duration: duration,
      curve: Curves.easeOutQuart,
      builder: (context, val, child) {
        final count = val.toInt();
        return Text(
          '$prefix$count$suffix',
          style: style,
        );
      },
    );
  }
}
