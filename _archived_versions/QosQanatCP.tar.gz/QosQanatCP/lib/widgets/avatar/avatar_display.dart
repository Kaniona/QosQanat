import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/theme/design_system.dart';
import '../../data/models/assistant_kind.dart';
import '../assistant_avatar.dart';

/// Shows the assistant avatar with beautiful high-end micro-animations:
/// - 'idle': Gentle breathing and floating loop
/// - 'celebrate': Spring jump and rotating star burst particles
/// - 'thinking': Slow head tilt with animated question marks rising above
class AvatarDisplay extends StatefulWidget {
  const AvatarDisplay({
    required this.assistant,
    this.size = 140,
    this.equippedItems = const {},
    this.equippedPet,
    this.equippedBackground = 'bg-default',
    this.animationState = 'idle', // 'idle', 'celebrate', 'thinking'
    super.key,
  });

  final AssistantKind assistant;
  final double size;
  final Set<String> equippedItems;
  final String? equippedPet;
  final String equippedBackground;
  final String animationState;

  @override
  State<AvatarDisplay> createState() => _AvatarDisplayState();
}

class _AvatarDisplayState extends State<AvatarDisplay>
    with TickerProviderStateMixin {
  // Animators
  late AnimationController _floatController;
  late AnimationController _bounceController;
  late AnimationController _tiltController;
  late AnimationController _particlesController;

  late Animation<double> _floatTranslation;
  late Animation<double> _springScale;
  late Animation<double> _springJump;
  late Animation<double> _tiltAngle;
  late Animation<double> _particleOpacity;
  late Animation<double> _particleFloat;

  // Star bursts & Question marks coords
  final List<Point<double>> _stars = [];
  final List<Point<double>> _questions = [];
  final Random _random = Random();

  @override
  void initState() {
    super.initState();

    // 1. Idle Floating Controller
    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _floatTranslation = Tween<double>(begin: 0.0, end: -6.0).animate(
      CurvedAnimation(parent: _floatController, curve: Curves.easeInOutQuad),
    );

    // 2. Celebration Spring Jump Controller
    _bounceController = AnimationController(
      vsync: this,
      duration: DesignSystem.durationSpring,
    );

    _springScale = TweenSequence<double>([
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 0.85).chain(CurveTween(curve: Curves.easeOut)), weight: 20),
      TweenSequenceItem(tween: Tween<double>(begin: 0.85, end: 1.15).chain(CurveTween(curve: DesignSystem.springCurve)), weight: 50),
      TweenSequenceItem(tween: Tween<double>(begin: 1.15, end: 1.0).chain(CurveTween(curve: Curves.easeIn)), weight: 30),
    ]).animate(_bounceController);

    _springJump = TweenSequence<double>([
      TweenSequenceItem(tween: Tween<double>(begin: 0.0, end: 0.0), weight: 15),
      TweenSequenceItem(tween: Tween<double>(begin: 0.0, end: -25.0).chain(CurveTween(curve: Curves.easeOutQuad)), weight: 35),
      TweenSequenceItem(tween: Tween<double>(begin: -25.0, end: 0.0).chain(CurveTween(curve: Curves.bounceOut)), weight: 50),
    ]).animate(_bounceController);

    // 3. Thinking Tilt Controller
    _tiltController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _tiltAngle = TweenSequence<double>([
      TweenSequenceItem(tween: Tween<double>(begin: 0.0, end: 0.08).chain(CurveTween(curve: Curves.easeInOut)), weight: 40),
      TweenSequenceItem(tween: Tween<double>(begin: 0.08, end: -0.06).chain(CurveTween(curve: Curves.easeInOut)), weight: 40),
      TweenSequenceItem(tween: Tween<double>(begin: -0.06, end: 0.0).chain(CurveTween(curve: Curves.easeInOut)), weight: 20),
    ]).animate(_tiltController);

    // 4. Particle Emitter Controller
    _particlesController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _particleOpacity = TweenSequence<double>([
      TweenSequenceItem(tween: Tween<double>(begin: 0.0, end: 1.0), weight: 20),
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 1.0), weight: 50),
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 0.0), weight: 30),
    ]).animate(_particlesController);

    _particleFloat = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _particlesController, curve: Curves.easeOutCubic),
    );

    _initializeParticles();
    _triggerStateAnimation();
  }

  void _initializeParticles() {
    _stars.clear();
    _questions.clear();
    for (int i = 0; i < 6; i++) {
      _stars.add(Point(
        _random.nextDouble() * 2.0 - 1.0, // X: -1 to 1
        _random.nextDouble() * -0.8 - 0.2, // Y: -1 to -0.2
      ));
      _questions.add(Point(
        _random.nextDouble() * 0.8 - 0.4, // X: -0.4 to 0.4
        _random.nextDouble() * -0.6 - 0.4, // Y: -1 to -0.4
      ));
    }
  }

  @override
  void didUpdateWidget(covariant AvatarDisplay oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.animationState != widget.animationState) {
      _triggerStateAnimation();
    }
  }

  void _triggerStateAnimation() {
    if (widget.animationState == 'celebrate') {
      _bounceController.reset();
      _bounceController.forward();
      _particlesController.reset();
      _particlesController.forward();
    } else if (widget.animationState == 'thinking') {
      _tiltController.reset();
      _tiltController.repeat(reverse: true);
      _particlesController.reset();
      _particlesController.repeat();
    } else {
      _tiltController.stop();
      _tiltController.reverse();
    }
  }

  @override
  void dispose() {
    _floatController.dispose();
    _bounceController.dispose();
    _tiltController.dispose();
    _particlesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([
        _floatController,
        _bounceController,
        _tiltController,
        _particlesController,
      ]),
      builder: (context, child) {
        final floatOffset = widget.animationState == 'idle' ? _floatTranslation.value : 0.0;
        final jumpOffset = _springJump.value;
        final scale = widget.animationState == 'celebrate' ? _springScale.value : 1.0;
        final tilt = _tiltAngle.value;

        return SizedBox(
          width: widget.size * 1.3,
          height: widget.size * 1.3,
          child: Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              // Dynamic backgrounds
              Transform.translate(
                offset: Offset(0, floatOffset + jumpOffset),
                child: Transform.scale(
                  scale: scale,
                  child: Transform.rotate(
                    angle: tilt,
                    child: AssistantAvatar(
                      assistant: widget.assistant,
                      size: widget.size,
                      equippedItems: widget.equippedItems,
                      equippedPet: widget.equippedPet,
                      equippedBackground: widget.equippedBackground,
                      mood: widget.animationState == 'celebrate'
                          ? 'celebrating'
                          : (widget.animationState == 'thinking' ? 'thinking' : 'happy'),
                    ),
                  ),
                ),
              ),

              // Celebrate Particle Burst Overlay
              if (widget.animationState == 'celebrate' && _particlesController.isAnimating)
                ..._buildStarBursts(),

              // Thinking Question Mark Overlay
              if (widget.animationState == 'thinking')
                ..._buildQuestionMarks(),
            ],
          ),
        );
      },
    );
  }

  List<Widget> _buildStarBursts() {
    final size = widget.size;
    final floatProgress = _particleFloat.value;
    final opacity = _particleOpacity.value;

    return List.generate(_stars.length, (index) {
      final p = _stars[index];
      // Final target positions
      final x = p.x * size * 0.6;
      final y = p.y * size * 0.7 - 20;

      // Animate from center outward
      final currentX = x * floatProgress;
      final currentY = (y + 30) * floatProgress - 30;

      return Positioned(
        left: size * 0.65 + currentX - 10,
        top: size * 0.5 + currentY - 10,
        child: Opacity(
          opacity: opacity,
          child: Transform.rotate(
            angle: floatProgress * pi * 2,
            child: Icon(
              Icons.star,
              color: index % 2 == 0 ? DesignSystem.kazakhGold : DesignSystem.kazakhSkyBlue,
              size: 20 + (index % 3) * 4.0,
            ),
          ),
        ),
      );
    });
  }

  List<Widget> _buildQuestionMarks() {
    final size = widget.size;
    final floatProgress = _particleFloat.value;
    final opacity = _particleOpacity.value;

    return List.generate(_questions.length, (index) {
      final p = _questions[index];
      // Animate rising up above the head
      final x = p.x * size * 0.5;
      final y = -40.0 - (floatProgress * 60.0) + (p.y * 15.0);

      return Positioned(
        left: size * 0.65 + x - 10,
        top: size * 0.35 + y,
        child: Opacity(
          opacity: (1.0 - floatProgress).clamp(0.0, 1.0) * opacity,
          child: Transform.rotate(
            angle: sin(floatProgress * pi * 2 + index) * 0.2,
            child: Text(
              '?',
              style: TextStyle(
                fontSize: 18 + (index % 3) * 6.0,
                fontWeight: FontWeight.w900,
                color: index % 2 == 0 ? DesignSystem.kazakhSkyBlue : Colors.white,
                shadows: [
                  Shadow(
                    color: DesignSystem.kazakhDeepBlue,
                    blurRadius: 4,
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    });
  }
}
