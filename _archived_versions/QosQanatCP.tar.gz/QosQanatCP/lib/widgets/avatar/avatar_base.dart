import 'package:flutter/material.dart';
import '../../data/models/assistant_kind.dart';
import '../../data/store/app_store.dart';
import '../assistant_avatar.dart';

/// Core Base Widget that renders the current customized assistant avatar
/// Automatically hooks up to the central AppStore if supplied, or renders static configs.
class AvatarBase extends StatelessWidget {
  const AvatarBase({
    required this.assistant,
    this.size = 130,
    this.equippedItems = const {},
    this.equippedPet,
    this.equippedBackground = 'bg-default',
    this.mood = 'neutral',
    this.store,
    super.key,
  });

  /// Factory constructor to render the active customized avatar directly from the state store
  factory AvatarBase.fromStore({
    required AppStore store,
    double size = 130,
    String mood = 'neutral',
    Key? key,
  }) {
    return AvatarBase(
      key: key,
      assistant: store.assistant,
      size: size,
      equippedItems: store.equippedItems,
      equippedPet: store.equippedPet,
      equippedBackground: store.equippedBackground,
      mood: mood,
      store: store,
    );
  }

  final AssistantKind assistant;
  final double size;
  final Set<String> equippedItems;
  final String? equippedPet;
  final String equippedBackground;
  final String mood;
  final AppStore? store;

  @override
  Widget build(BuildContext context) {
    // If store is present, bind to store values automatically
    final activeItems = store != null ? store!.equippedItems : equippedItems;
    final activePet = store != null ? store!.equippedPet : equippedPet;
    final activeBg = store != null ? store!.equippedBackground : equippedBackground;

    return AssistantAvatar(
      assistant: assistant,
      size: size,
      equippedItems: activeItems,
      equippedPet: activePet,
      equippedBackground: activeBg,
      mood: mood,
    );
  }
}
