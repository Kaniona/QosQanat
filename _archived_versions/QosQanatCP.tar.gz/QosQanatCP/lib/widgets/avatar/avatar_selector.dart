import 'package:flutter/material.dart';
import '../../core/theme/design_system.dart';
import '../../data/models/assistant_kind.dart';
import '../glass_card.dart';
import 'avatar_display.dart';

/// Reusable interactive selector card for onboarding or customization
class AvatarSelector extends StatefulWidget {
  const AvatarSelector({
    required this.selectedAssistant,
    required this.onChanged,
    super.key,
  });

  final AssistantKind selectedAssistant;
  final ValueChanged<AssistantKind> onChanged;

  @override
  State<AvatarSelector> createState() => _AvatarSelectorState();
}

class _AvatarSelectorState extends State<AvatarSelector> {
  // Temporary map to trigger single custom celebrate burst on card tap
  final Map<AssistantKind, String> _avatarStates = {
    AssistantKind.bektur: 'idle',
    AssistantKind.nazym: 'idle',
  };

  void _onTapAssistant(AssistantKind kind) {
    if (widget.selectedAssistant != kind) {
      widget.onChanged(kind);
    }
    // Set to celebrate to play jump burst once, then reset to idle
    setState(() {
      _avatarStates[kind] = 'celebrate';
    });
    Future.delayed(const Duration(milliseconds: 1000), () {
      if (mounted) {
        setState(() {
          _avatarStates[kind] = 'idle';
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(child: _buildCard(AssistantKind.bektur)),
            const SizedBox(width: 16),
            Expanded(child: _buildCard(AssistantKind.nazym)),
          ],
        ),
        const SizedBox(height: 24),
        // Description detail panel
        AnimatedSwitcher(
          duration: DesignSystem.durationStandard,
          child: _buildAssistantBio(widget.selectedAssistant),
        ),
      ],
    );
  }

  Widget _buildCard(AssistantKind kind) {
    final isSelected = widget.selectedAssistant == kind;
    final themeColor = kind.color;
    final state = _avatarStates[kind] ?? 'idle';

    return GestureDetector(
      onTap: () => _onTapAssistant(kind),
      child: TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 1.0, end: isSelected ? 1.03 : 0.97),
        duration: DesignSystem.durationQuick,
        builder: (context, scale, child) {
          return Transform.scale(
            scale: scale,
            child: AnimatedContainer(
              duration: DesignSystem.durationStandard,
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
              decoration: BoxDecoration(
                color: isSelected
                    ? themeColor.withValues(alpha: 0.12)
                    : DesignSystem.cardBg.withValues(alpha: 0.7),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: isSelected ? themeColor : DesignSystem.borderGlass,
                  width: isSelected ? 2.5 : 1,
                ),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: themeColor.withValues(alpha: 0.35),
                          blurRadius: 16,
                          spreadRadius: 1,
                        )
                      ]
                    : [],
              ),
              child: Column(
                children: [
                  AvatarDisplay(
                    assistant: kind,
                    size: 110,
                    animationState: state,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    kind.displayName,
                    style: DesignSystem.headingLarge.copyWith(
                      color: isSelected ? themeColor : DesignSystem.silkWhite,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 6),
                  AnimatedContainer(
                    duration: DesignSystem.durationQuick,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: isSelected ? themeColor : Colors.transparent,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isSelected ? Colors.transparent : DesignSystem.borderGlass,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          isSelected ? Icons.check_circle : Icons.circle_outlined,
                          color: isSelected ? Colors.white : themeColor,
                          size: 14,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          isSelected ? 'ТАҢДАЛДЫ' : 'ТАҢДАУ',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            color: isSelected ? Colors.white : DesignSystem.steppeSilver,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildAssistantBio(AssistantKind kind) {
    final themeColor = kind.color;

    return GlassCard(
      key: ValueKey<AssistantKind>(kind),
      borderGradient: LinearGradient(
        colors: [themeColor.withValues(alpha: 0.5), DesignSystem.borderGlass],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(kind.icon, color: kind.accent, size: 24),
              const SizedBox(width: 8),
              Text(
                '${kind.displayName} — Серік',
                style: DesignSystem.headingMedium.copyWith(color: themeColor, fontWeight: FontWeight.w900),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            kind.role,
            style: DesignSystem.bodyMedium.copyWith(height: 1.4),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: DesignSystem.kazakhDeepBlue.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: DesignSystem.borderGlass, width: 0.5),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('💬', style: TextStyle(fontSize: 16)),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '"${kind.greeting}"',
                    style: DesignSystem.bodySmall.copyWith(
                      color: DesignSystem.silkWhite,
                      fontStyle: FontStyle.italic,
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
