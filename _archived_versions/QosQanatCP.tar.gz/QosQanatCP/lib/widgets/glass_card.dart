import 'dart:ui';
import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';

/// Frosted Glassmorphism Card with neon gradient borders
class GlassCard extends StatelessWidget {
  const GlassCard({
    required this.child,
    this.borderRadius = 16,
    this.padding = const EdgeInsets.all(16),
    this.borderGradient,
    this.onTap,
    this.backgroundColor,
    super.key,
  });

  final Widget child;
  final double borderRadius;
  final EdgeInsetsGeometry padding;
  final Gradient? borderGradient;
  final VoidCallback? onTap;
  final Color? backgroundColor;

  @override
  Widget build(BuildContext context) {
    final defaultGradient = LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        AppColors.glassBorder,
        AppColors.glassBorder.withValues(alpha: .05),
      ],
    );

    Widget card = ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          decoration: BoxDecoration(
            color: backgroundColor ?? AppColors.bgDarkCard.withValues(alpha: .75),
            borderRadius: BorderRadius.circular(borderRadius),
            border: Border.all(
              color: Colors.transparent, // Controlled by CustomPainter below
              width: 1,
            ),
          ),
          child: CustomPaint(
            painter: _GradientBorderPainter(
              radius: borderRadius,
              strokeWidth: 1.2,
              gradient: borderGradient ?? defaultGradient,
            ),
            child: Padding(
              padding: padding,
              child: child,
            ),
          ),
        ),
      ),
    );

    if (onTap != null) {
      card = InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(borderRadius),
        child: card,
      );
    }

    return card;
  }
}

class _GradientBorderPainter extends CustomPainter {
  _GradientBorderPainter({
    required this.radius,
    required this.strokeWidth,
    required this.gradient,
  });

  final double radius;
  final double strokeWidth;
  final Gradient gradient;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final paint = Paint()
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke
      ..shader = gradient.createShader(rect);

    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius));
    canvas.drawRRect(rrect, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
