import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/design_system.dart';

/// Premium Real-time Reward Notification & Floating Text Emitter
class FloatingRewardToast {
  FloatingRewardToast._();

  /// Shows a beautiful floating reward (e.g. "+50 XP" or "+20 Coins") that rises up and fades out.
  static void show(
    BuildContext context, {
    required String rewardText,
    required String iconText,
    Color color = AppColors.primary,
  }) {
    final overlayState = Overlay.of(context);
    late OverlayEntry overlayEntry;

    overlayEntry = OverlayEntry(
      builder: (context) {
        return Positioned(
          top: MediaQuery.of(context).size.height * 0.45,
          left: 0,
          right: 0,
          child: IgnorePointer(
            child: _FloatingRewardWidget(
              rewardText: rewardText,
              iconText: iconText,
              color: color,
              onFinished: () {
                overlayEntry.remove();
              },
            ),
          ),
        );
      },
    );

    overlayState.insert(overlayEntry);
  }
}

class _FloatingRewardWidget extends StatefulWidget {
  const _FloatingRewardWidget({
    required this.rewardText,
    required this.iconText,
    required this.color,
    required this.onFinished,
  });

  final String rewardText;
  final String iconText;
  final Color color;
  final VoidCallback onFinished;

  @override
  State<_FloatingRewardWidget> createState() => _FloatingRewardWidgetState();
}

class _FloatingRewardWidgetState extends State<_FloatingRewardWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _opacity;
  late Animation<double> _slideUp;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );

    _opacity = TweenSequence<double>([
      TweenSequenceItem(tween: Tween<double>(begin: 0.0, end: 1.0), weight: 15),
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 1.0), weight: 55),
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 0.0), weight: 30),
    ]).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    _slideUp = Tween<double>(begin: 0.0, end: -120.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );

    _scale = TweenSequence<double>([
      TweenSequenceItem(tween: Tween<double>(begin: 0.5, end: 1.1), weight: 20),
      TweenSequenceItem(tween: Tween<double>(begin: 1.1, end: 1.0), weight: 20),
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 1.0), weight: 60),
    ]).animate(CurvedAnimation(parent: _controller, curve: Curves.elasticOut));

    _controller.forward().then((_) => widget.onFinished());
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _slideUp.value),
          child: Opacity(
            opacity: _opacity.value,
            child: Transform.scale(
              scale: _scale.value,
              child: Center(
                child: Material(
                  color: Colors.transparent,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    decoration: BoxDecoration(
                      color: AppColors.bgDarkElevated.withValues(alpha: .9),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: widget.color.withValues(alpha: .5),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: widget.color.withValues(alpha: .3),
                          blurRadius: 20,
                          spreadRadius: 2,
                        )
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          widget.iconText,
                          style: const TextStyle(fontSize: 22),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          widget.rewardText,
                          style: DesignSystem.headingLarge.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.5,
                            shadows: [
                              BoxShadow(
                                color: widget.color.withValues(alpha: .8),
                                blurRadius: 8,
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
