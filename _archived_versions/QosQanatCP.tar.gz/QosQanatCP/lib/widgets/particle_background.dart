import 'dart:math';
import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';

/// Floating active particle background for premium gaming feel
class ParticleBackground extends StatefulWidget {
  const ParticleBackground({this.child, super.key});

  final Widget? child;

  @override
  State<ParticleBackground> createState() => _ParticleBackgroundState();
}

class _ParticleBackgroundState extends State<ParticleBackground>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  final List<_Particle> _particles = [];
  final Random _random = Random();
  final int _particleCount = 25;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..addListener(() {
        _updateParticles();
      })..repeat();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_particles.isEmpty) {
      final size = MediaQuery.of(context).size;
      for (int i = 0; i < _particleCount; i++) {
        _particles.add(_Particle(
          x: _random.nextDouble() * size.width,
          y: _random.nextDouble() * size.height,
          size: _random.nextDouble() * 4 + 1.5,
          speedY: _random.nextDouble() * 0.4 + 0.1,
          speedX: (_random.nextDouble() - 0.5) * 0.2,
          opacity: _random.nextDouble() * 0.5 + 0.1,
          color: _getRandomColor(),
        ));
      }
    }
  }

  Color _getRandomColor() {
    final colors = [
      AppColors.primaryLight.withValues(alpha: .5),
      AppColors.secondary.withValues(alpha: .4),
      AppColors.neonCyan.withValues(alpha: .4),
      AppColors.neonMagenta.withValues(alpha: .3),
      AppColors.neonPurple.withValues(alpha: .4),
    ];
    return colors[_random.nextInt(colors.length)];
  }

  void _updateParticles() {
    if (!mounted) return;
    final size = MediaQuery.of(context).size;
    setState(() {
      for (var p in _particles) {
        p.y -= p.speedY;
        p.x += p.speedX;

        // Reset particle if it leaves the screen
        if (p.y < -10) {
          p.y = size.height + 10;
          p.x = _random.nextDouble() * size.width;
        }
        if (p.x < -10 || p.x > size.width + 10) {
          p.x = _random.nextDouble() * size.width;
        }
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Base dark cosmic gradient
        Container(
          decoration: const BoxDecoration(
            gradient: AppColors.bgGradient,
          ),
        ),
        // Live custom painter for particles
        CustomPaint(
          painter: _ParticlePainter(particles: _particles),
          size: Size.infinite,
        ),
        if (widget.child != null) widget.child!,
      ],
    );
  }
}

class _Particle {
  _Particle({
    required this.x,
    required this.y,
    required this.size,
    required this.speedY,
    required this.speedX,
    required this.opacity,
    required this.color,
  });

  double x;
  double y;
  final double size;
  final double speedY;
  final double speedX;
  final double opacity;
  final Color color;
}

class _ParticlePainter extends CustomPainter {
  _ParticlePainter({required this.particles});

  final List<_Particle> particles;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;

    for (var p in particles) {
      paint.color = p.color.withValues(alpha: p.opacity);
      canvas.drawCircle(Offset(p.x, p.y), p.size, paint);

      // Subtle glow for larger particles
      if (p.size > 3.0) {
        paint.color = p.color.withValues(alpha: p.opacity * 0.3);
        canvas.drawCircle(Offset(p.x, p.y), p.size * 2, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
