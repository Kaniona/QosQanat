import 'dart:math';
import 'package:flutter/material.dart';
import '../core/config/levels.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/design_system.dart';
import '../data/store/app_store.dart';
import 'assistant_avatar.dart';
import 'glow_button.dart';

/// Premium Full-Screen Level Up Celebration Modal
class LevelUpModal extends StatefulWidget {
  const LevelUpModal({
    required this.store,
    required this.onClose,
    super.key,
  });

  final AppStore store;
  final VoidCallback onClose;

  @override
  State<LevelUpModal> createState() => _LevelUpModalState();
}

class _LevelUpModalState extends State<LevelUpModal>
    with TickerProviderStateMixin {
  late AnimationController _sparkController;
  late AnimationController _badgeController;
  late AnimationController _listController;

  late Animation<double> _badgeScale;
  late Animation<double> _badgeRotation;
  late Animation<double> _listOpacity;

  final List<_GoldenSpark> _sparks = [];
  final Random _random = Random();

  @override
  void initState() {
    super.initState();

    // ── Golden sparks emitter ──
    _sparkController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..addListener(() {
        _updateSparks();
      })..repeat();

    // ── Badge Entrance Animation ──
    _badgeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _badgeScale = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _badgeController, curve: Curves.elasticOut),
    );
    _badgeRotation = Tween<double>(begin: -0.2, end: 0.0).animate(
      CurvedAnimation(parent: _badgeController, curve: Curves.easeOutBack),
    );

    // ── Unlocked List Staggered Fade ──
    _listController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _listOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _listController, curve: Curves.easeOut),
    );

    // Generate sparks initial spray
    _generateSparks();

    // Stagger sequences
    _badgeController.forward();
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _listController.forward();
    });
  }

  void _generateSparks() {
    for (int i = 0; i < 60; i++) {
      final double angle = _random.nextDouble() * pi * 2;
      final double velocity = 2.0 + _random.nextDouble() * 5.0;
      _sparks.add(_GoldenSpark(
        x: 0,
        y: 0,
        vx: cos(angle) * velocity,
        vy: sin(angle) * velocity - 2.0, // Initial upward push
        size: 3.0 + _random.nextDouble() * 6.0,
        alpha: 1.0,
        decay: 0.01 + _random.nextDouble() * 0.02,
      ));
    }
  }

  void _updateSparks() {
    if (!mounted) return;
    setState(() {
      for (final s in _sparks) {
        s.x += s.vx;
        s.y += s.vy;
        s.vy += 0.15; // Gravity pull
        s.alpha = (s.alpha - s.decay).clamp(0.0, 1.0);
      }
      // Regenerate faded sparks to maintain sparkle loop
      for (final s in _sparks) {
        if (s.alpha <= 0.0) {
          final double angle = _random.nextDouble() * pi * 2;
          final double velocity = 1.0 + _random.nextDouble() * 4.0;
          s.x = 0;
          s.y = 0;
          s.vx = cos(angle) * velocity;
          s.vy = sin(angle) * velocity - 1.5;
          s.alpha = 1.0;
        }
      }
    });
  }

  @override
  void dispose() {
    _sparkController.dispose();
    _badgeController.dispose();
    _listController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final unlocked = LevelConfig.getUnlockedFeatures(widget.store.level);

    return Scaffold(
      backgroundColor: Colors.black.withValues(alpha: .85),
      body: Stack(
        children: [
          // ── Background Golden Glow Shimmer ──
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  colors: [
                    AppColors.neonGold.withValues(alpha: .25),
                    Colors.transparent,
                  ],
                  radius: 0.8,
                ),
              ),
            ),
          ),

          // ── Dynamic Golden Sparks ──
          Positioned.fill(
            child: CustomPaint(
              painter: _GoldenSparksPainter(sparks: _sparks),
            ),
          ),

          // ── Content Layout ──
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // ── Animated Level up Badge ──
                    ScaleTransition(
                      scale: _badgeScale,
                      child: RotationTransition(
                        turns: _badgeRotation,
                        child: Container(
                          padding: const EdgeInsets.all(28),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: DesignSystem.goldenSunGradient,
                            border: Border.all(color: Colors.white, width: 4),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.neonGold.withValues(alpha: .6),
                                blurRadius: 40,
                                spreadRadius: 4,
                              )
                            ],
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                'ЖАҢА ДЕҢГЕЙ!',
                                style: DesignSystem.labelMedium.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 2.0,
                                  fontSize: 14,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${widget.store.level}',
                                style: DesignSystem.displayLarge.copyWith(
                                  fontSize: 72,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                  height: 1.0,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 32),

                    // ── Character Avatar Jumping/Celebrating ──
                    TweenAnimationBuilder<double>(
                      tween: Tween<double>(begin: 0, end: -15),
                      duration: const Duration(milliseconds: 600),
                      curve: Curves.easeInOutSine,
                      builder: (context, bounce, _) {
                        return Transform.translate(
                          offset: Offset(0, bounce),
                          child: AssistantAvatar(
                            assistant: widget.store.assistant,
                            size: 150,
                            equippedItems: widget.store.equippedItems,
                            equippedPet: widget.store.equippedPet,
                            equippedBackground: widget.store.equippedBackground,
                            mood: 'celebrating',
                          ),
                        );
                      },
                    ),

                    const SizedBox(height: 24),

                    Text(
                      'ҚҰТТЫҚТАЙМЫЗ! 🎉',
                      style: DesignSystem.displayMedium.copyWith(
                        color: AppColors.neonGold,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Сіз жаңа деңгейге көтерілдіңіз және оқу сыйлығы ретінде +${widget.store.level * 20} 🪙 алдыңыз!',
                      textAlign: TextAlign.center,
                      style: DesignSystem.bodyMedium.copyWith(color: DesignSystem.steppeSilver),
                    ),

                    const SizedBox(height: 32),

                    // ── Unlocked Features List ──
                    if (unlocked.isNotEmpty)
                      FadeTransition(
                        opacity: _listOpacity,
                        child: Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(maxWidth: 400),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: AppColors.bgDarkCard.withValues(alpha: .8),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: AppColors.glassBorder),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'АШЫЛҒАН МҮМКІНДІКТЕР 🔓',
                                style: DesignSystem.labelMedium.copyWith(
                                  color: AppColors.neonGold,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 12),
                              ...unlocked.map((f) => Padding(
                                    padding: const EdgeInsets.only(bottom: 8.0),
                                    child: Row(
                                      children: [
                                        const Icon(Icons.check_circle,
                                            color: AppColors.success, size: 18),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: Text(
                                            f,
                                            style: DesignSystem.bodyMedium.copyWith(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  )),
                            ],
                          ),
                        ),
                      ),

                    const SizedBox(height: 48),

                    // ── Primary Action Button ──
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 250),
                      child: GlowButton(
                        label: 'Керемет! 🪽',
                        color: AppColors.neonGold,
                        glowColor: AppColors.neonGold.withValues(alpha: .4),
                        onPressed: widget.onClose,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _GoldenSpark {
  _GoldenSpark({
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
    required this.size,
    required this.alpha,
    required this.decay,
  });

  double x;
  double y;
  double vx;
  double vy;
  final double size;
  double alpha;
  final double decay;
}

class _GoldenSparksPainter extends CustomPainter {
  _GoldenSparksPainter({required this.sparks});

  final List<_GoldenSpark> sparks;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height * 0.35);
    final paint = Paint()..style = PaintingStyle.fill;

    for (final s in sparks) {
      paint.color = Colors.amber.withValues(alpha: s.alpha);
      canvas.drawCircle(Offset(center.dx + s.x, center.dy + s.y), s.size, paint);

      // Subtle glow shadow behind spark
      paint.color = Colors.orangeAccent.withValues(alpha: s.alpha * 0.4);
      canvas.drawCircle(Offset(center.dx + s.x, center.dy + s.y), s.size * 2, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
