import 'package:flutter/material.dart';

/// Push Notification Service manager for scheduling and showing local simulation reminders
class NotificationService {
  NotificationService._privateConstructor();
  static final NotificationService instance = NotificationService._privateConstructor();

  final List<String> _notificationsLog = [];
  List<String> get notificationsLog => List.unmodifiable(_notificationsLog);

  void triggerLocalNotification({
    required String title,
    required String body,
  }) {
    final timestamp = DateTime.now().toString().substring(11, 16);
    final formatted = '[$timestamp] $title: $body';
    _notificationsLog.insert(0, formatted);
    debugPrint('🔔 PUSH NOTIFICATION: $title - $body');
  }

  /// Simulate Battle Request push alert
  void pushBattleInvite(String friendName) {
    triggerLocalNotification(
      title: 'Батл шақыруы! ⚔️',
      body: '$friendName сені зияткерлік батлға шақырды! Қазір кір!',
    );
  }

  /// Simulate Daily reminder pushed at 17:00
  void pushDailyReminder() {
    triggerLocalNotification(
      title: 'Білім саяхаты! 🗺️',
      body: 'Бүгін сабаққа кірдің бе? Күнделікті квесттер сені күтуде!',
    );
  }

  /// Simulate New Quest Day push alert
  void pushNewQuestsAvailable() {
    triggerLocalNotification(
      title: 'Жаңа күн - жаңа квест! 🎯',
      body: 'Күнделікті квесттер жаңартылды. Қосымша ұпайлар жинауға кіріс!',
    );
  }

  /// Simulate Streak reminder before midnight
  void pushStreakWarning() {
    triggerLocalNotification(
      title: 'Streak-ті сақтап қал! 🔥',
      body: 'Бүгінгі сабағыңды аяқтап, күнделікті серияңды үзіп алма!',
    );
  }
}
