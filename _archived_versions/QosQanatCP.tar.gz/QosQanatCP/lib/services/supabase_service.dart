import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../data/models/assistant_kind.dart';

/// QosQanat Supabase Backend Service
/// Offline-first: SharedPreferences primary, Supabase syncs when available.
class SupabaseService {
  SupabaseService._();
  static final SupabaseService instance = SupabaseService._();

  // TODO: Replace with your actual Supabase project credentials
  static const String _supabaseUrl = 'https://YOUR_PROJECT_REF.supabase.co';
  static const String _supabaseAnonKey = 'YOUR_ANON_KEY_HERE';

  SupabaseClient get _client => Supabase.instance.client;
  bool _initialized = false;

  bool get isConfigured =>
      _supabaseUrl != 'https://YOUR_PROJECT_REF.supabase.co' &&
      _supabaseAnonKey != 'YOUR_ANON_KEY_HERE';

  Future<void> initialize() async {
    if (_initialized) return;
    try {
      await Supabase.initialize(url: _supabaseUrl, anonKey: _supabaseAnonKey);
      _initialized = true;
      debugPrint('✅ Supabase initialized');
    } catch (e) {
      debugPrint('⚠️ Supabase init failed: $e — offline mode');
    }
  }

  // ── AUTH ──────────────────────────────────────────────────────────────────

  User? get currentUser => _initialized ? _client.auth.currentUser : null;
  Session? get currentSession => _initialized ? _client.auth.currentSession : null;
  bool get isSignedIn => currentUser != null;

  Future<User?> signUpWithPhone(String phone) async {
    if (!_initialized || !isConfigured) return null;
    try {
      final r = await _client.auth.signUp(phone: phone, password: _securePass());
      return r.user;
    } on AuthException catch (e) {
      debugPrint('❌ Sign-up: ${e.message}');
      return null;
    }
  }

  Future<User?> verifyOtp(String phone, String token) async {
    if (!_initialized || !isConfigured) return null;
    try {
      final r = await _client.auth.verifyOTP(phone: phone, token: token, type: OtpType.sms);
      return r.user;
    } on AuthException catch (e) {
      debugPrint('❌ OTP: ${e.message}');
      return null;
    }
  }

  Future<void> signOut() async {
    if (!_initialized) return;
    try { await _client.auth.signOut(); } catch (_) {}
  }

  // ── PROFILE CRUD ─────────────────────────────────────────────────────────

  Future<bool> createProfile({
    required String qqId, required String fullName, required String phone,
    required String iin, required String city, required String school,
    required AssistantKind assistant,
  }) async {
    if (!_initialized || !isConfigured || currentUser == null) return false;
    try {
      await _client.from('users').insert({
        'id': currentUser!.id, 'qq_id': qqId, 'full_name': fullName,
        'phone': phone, 'iin': iin, 'city': city, 'school': school,
        'assistant_choice': assistant.name,
        'level': 1, 'xp': 0, 'coins': 80, 'akyl_points': 120, 'streak': 1,
      });
      return true;
    } catch (e) { debugPrint('❌ createProfile: $e'); return false; }
  }

  Future<Map<String, dynamic>?> fetchProfile() async {
    if (!_initialized || !isConfigured || currentUser == null) return null;
    try {
      return await _client.from('users').select().eq('id', currentUser!.id).maybeSingle();
    } catch (e) { debugPrint('⚠️ fetchProfile: $e'); return null; }
  }

  Future<bool> updateProfile(Map<String, dynamic> updates) async {
    if (!_initialized || !isConfigured || currentUser == null) return false;
    try {
      await _client.from('users').update(updates).eq('id', currentUser!.id);
      return true;
    } catch (e) { debugPrint('⚠️ updateProfile: $e'); return false; }
  }

  Future<void> syncStats({
    required int level, required int xp, required int coins,
    required int akylPoints, required int streak, required String assistantChoice,
  }) async {
    await updateProfile({
      'level': level, 'xp': xp, 'coins': coins, 'akyl_points': akylPoints,
      'streak': streak, 'assistant_choice': assistantChoice,
      'last_login': DateTime.now().toIso8601String(),
    });
  }

  // ── FRIENDSHIPS ──────────────────────────────────────────────────────────

  Future<bool> sendFriendRequest(String targetQqId) async {
    if (!_initialized || !isConfigured || currentUser == null) return false;
    try {
      final target = await _client.from('users').select('id').eq('qq_id', targetQqId).maybeSingle();
      if (target == null) return false;
      await _client.from('friendships').insert({
        'user_a': currentUser!.id, 'user_b': target['id'], 'status': 'pending',
      });
      return true;
    } catch (e) { debugPrint('⚠️ sendFriendRequest: $e'); return false; }
  }

  Future<List<Map<String, dynamic>>> fetchFriendships() async {
    if (!_initialized || !isConfigured || currentUser == null) return [];
    try {
      final uid = currentUser!.id;
      final data = await _client.from('friendships').select()
          .or('user_a.eq.$uid,user_b.eq.$uid').eq('status', 'accepted');
      return List<Map<String, dynamic>>.from(data);
    } catch (e) { debugPrint('⚠️ fetchFriendships: $e'); return []; }
  }

  // ── BATTLES ──────────────────────────────────────────────────────────────

  Future<String?> createBattleRequest({
    required String opponentId, required int questionCount,
  }) async {
    if (!_initialized || !isConfigured || currentUser == null) return null;
    try {
      final data = await _client.from('battle_requests').insert({
        'challenger_id': currentUser!.id, 'opponent_id': opponentId,
        'question_count': questionCount, 'status': 'pending',
      }).select('id').single();
      return data['id'] as String?;
    } catch (e) { debugPrint('⚠️ createBattle: $e'); return null; }
  }

  Future<bool> submitBattleResult({
    required String battleRequestId, required String opponentId,
    required int myScore, required int opponentScore, required int totalQuestions,
  }) async {
    if (!_initialized || !isConfigured || currentUser == null) return false;
    final uid = currentUser!.id;
    final won = myScore > opponentScore;
    try {
      await _client.from('battle_results').insert({
        'battle_request_id': battleRequestId,
        'challenger_id': uid, 'opponent_id': opponentId,
        'challenger_score': myScore, 'opponent_score': opponentScore,
        'winner_id': won ? uid : opponentId, 'total_questions': totalQuestions,
      });
      await _client.from('battle_requests').update({'status': 'completed'}).eq('id', battleRequestId);
      return true;
    } catch (e) { debugPrint('⚠️ submitBattleResult: $e'); return false; }
  }

  // ── INVENTORY ────────────────────────────────────────────────────────────

  Future<bool> addOwnedItem(String itemId) async {
    if (!_initialized || !isConfigured || currentUser == null) return false;
    try {
      await _client.from('owned_items').insert({'user_id': currentUser!.id, 'item_id': itemId});
      return true;
    } catch (e) { debugPrint('⚠️ addOwnedItem: $e'); return false; }
  }

  Future<bool> equipItem(String itemId, String slot) async {
    if (!_initialized || !isConfigured || currentUser == null) return false;
    try {
      await _client.from('equipped_items').upsert({'user_id': currentUser!.id, 'item_id': itemId, 'slot': slot});
      return true;
    } catch (e) { debugPrint('⚠️ equipItem: $e'); return false; }
  }

  // ── LEADERBOARD ──────────────────────────────────────────────────────────

  Future<List<Map<String, dynamic>>> fetchLeaderboard({int limit = 50}) async {
    if (!_initialized || !isConfigured) return [];
    try {
      final data = await _client.from('users')
          .select('qq_id, full_name, city, akyl_points, level, assistant_choice')
          .order('akyl_points', ascending: false).limit(limit);
      return List<Map<String, dynamic>>.from(data);
    } catch (e) { debugPrint('⚠️ fetchLeaderboard: $e'); return []; }
  }

  // ── REAL-TIME BATTLE & SOCIAL SUBSCRIPTIONS ──────────────────────────────

  /// Search a user profile by QQ-ID
  Future<Map<String, dynamic>?> searchUserByQqId(String qqId) async {
    if (!_initialized || !isConfigured) return null;
    try {
      return await _client.from('users').select().eq('qq_id', qqId.trim().toUpperCase()).maybeSingle();
    } catch (e) {
      debugPrint('⚠️ searchUserByQqId: $e');
      return null;
    }
  }

  /// Respond to a friend request (status: 'accepted' or delete if declined)
  Future<bool> respondToFriendRequest(String senderId, bool accept) async {
    if (!_initialized || !isConfigured || currentUser == null) return false;
    final uid = currentUser!.id;
    try {
      if (accept) {
        await _client.from('friendships')
            .update({'status': 'accepted'})
            .match({'user_a': senderId, 'user_b': uid});
      } else {
        await _client.from('friendships')
            .delete()
            .match({'user_a': senderId, 'user_b': uid});
      }
      return true;
    } catch (e) {
      debugPrint('⚠️ respondToFriendRequest: $e');
      return false;
    }
  }

  /// Subscribe to real-time battle channel
  RealtimeChannel? subscribeToBattle(String battleId, void Function(Map<String, dynamic> payload) onPayload) {
    if (!_initialized || !isConfigured) return null;
    try {
      final channel = _client.channel('battle:$battleId');
      channel.onBroadcast(
        event: 'answer',
        callback: (payload) {
          onPayload(payload);
        },
      ).subscribe();
      return channel;
    } catch (e) {
      debugPrint('⚠️ subscribeToBattle: $e');
      return null;
    }
  }

  /// Broadcast battle answers in real-time
  Future<void> broadcastBattleAnswer(
    RealtimeChannel channel, {
    required int questionIndex,
    required int answerIndex,
    required int score,
  }) async {
    if (!_initialized || !isConfigured || currentUser == null) return;
    try {
      await channel.sendBroadcastMessage(
        event: 'answer',
        payload: {
          'sender_id': currentUser!.id,
          'question_index': questionIndex,
          'answer_index': answerIndex,
          'score': score,
        },
      );
    } catch (e) {
      debugPrint('⚠️ broadcastBattleAnswer: $e');
    }
  }

  // ── HELPERS ──────────────────────────────────────────────────────────────

  static String _securePass() {
    const c = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#\$%^&*';
    final r = Random.secure();
    return List.generate(24, (_) => c[r.nextInt(c.length)]).join();
  }
}
