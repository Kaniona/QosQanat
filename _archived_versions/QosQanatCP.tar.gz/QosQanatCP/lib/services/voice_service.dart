import 'dart:async';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

/// Service to handle TTS (Text-to-Speech) and STT (Speech-to-Text) for QosQanat voice assistant
class VoiceService {
  VoiceService._internal();
  static final VoiceService instance = VoiceService._internal();

  final FlutterTts _tts = FlutterTts();
  final stt.SpeechToText _stt = stt.SpeechToText();

  bool _isSttInitialized = false;

  Future<void> init() async {
    // Setup Kazakh TTS language
    try {
      await _tts.setLanguage('kk-KZ');
      await _tts.setSpeechRate(0.5);
      await _tts.setVolume(1.0);
      await _tts.setPitch(1.0);
    } catch (e) {
      // Fallback
    }
  }

  /// Speak Kazakh text aloud
  Future<void> speak(String text) async {
    await _tts.stop();
    await _tts.speak(text);
  }

  /// Stop any speaking voice
  Future<void> stopSpeaking() async {
    await _tts.stop();
  }

  /// Start speech listening session in Kazakh
  Future<void> listen({
    required Function(String) onResult,
    required Function(bool) onListeningStateChanged,
    required Function(String) onError,
  }) async {
    if (!_isSttInitialized) {
      _isSttInitialized = await _stt.initialize(
        onStatus: (status) {
          if (status == 'listening') {
            onListeningStateChanged(true);
          } else {
            onListeningStateChanged(false);
          }
        },
        onError: (error) {
          onListeningStateChanged(false);
          onError(error.errorMsg);
        },
      );
    }

    if (_isSttInitialized) {
      onListeningStateChanged(true);
      await _stt.listen(
        localeId: 'kk_KZ', // Kazakh localization
        listenFor: const Duration(seconds: 10),
        pauseFor: const Duration(seconds: 4),
        onResult: (result) {
          onResult(result.recognizedWords);
        },
      );
    } else {
      onError('Дауыс тануды іске қосу мүмкін болмады');
    }
  }

  /// Stop speech listening session
  Future<void> stopListening() async {
    await _stt.stop();
  }
}
