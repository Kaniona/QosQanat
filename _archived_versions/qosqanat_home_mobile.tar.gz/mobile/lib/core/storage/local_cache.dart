import 'package:hive_flutter/hive_flutter.dart';

class CachedUserProfile {
  const CachedUserProfile({
    required this.id,
    required this.qqId,
    required this.name,
    required this.grade,
    required this.region,
    required this.role,
    this.phone,
    this.birthDate,
  });

  final String id;
  final String qqId;
  final String name;
  final int grade;
  final String region;
  final String role;
  final String? phone;
  final String? birthDate;

  Map<String, Object?> toJson() {
    return <String, Object?>{
      'id': id,
      'qqId': qqId,
      'phone': phone,
      'name': name,
      'grade': grade,
      'region': region,
      'birthDate': birthDate,
      'role': role,
    };
  }

  static CachedUserProfile? fromJson(Map<Object?, Object?> json) {
    final Object? id = json['id'];
    final Object? qqId = json['qqId'];
    final Object? name = json['name'];
    final Object? grade = json['grade'];
    final Object? region = json['region'];
    final Object? role = json['role'];
    if (id is! String ||
        qqId is! String ||
        name is! String ||
        grade is! int ||
        region is! String ||
        role is! String) {
      return null;
    }

    final Object? phone = json['phone'];
    final Object? birthDate = json['birthDate'];
    return CachedUserProfile(
      id: id,
      qqId: qqId,
      name: name,
      grade: grade,
      region: region,
      role: role,
      phone: phone is String ? phone : null,
      birthDate: birthDate is String ? birthDate : null,
    );
  }
}

class LocalCache {
  LocalCache();

  static const String _profileBoxName = 'qq_profile_cache';
  static const String _profileKey = 'profile';

  Box<Object?>? get _box {
    try {
      if (Hive.isBoxOpen(_profileBoxName)) {
        return Hive.box<Object?>(_profileBoxName);
      }
    } catch (_) {}
    return null;
  }

  static Future<void> init() async {
    try {
      await Hive.initFlutter();
      if (!Hive.isBoxOpen(_profileBoxName)) {
        await Hive.openBox<Object?>(_profileBoxName);
      }
    } catch (e) {
      // If initialization or opening fails (e.g. corruption), delete the box files and try again
      try {
        await Hive.deleteBoxFromDisk(_profileBoxName);
        await Hive.openBox<Object?>(_profileBoxName);
      } catch (_) {
        // Fallback: ignore or let it run in memory
      }
    }
  }

  Future<void> cacheProfile(CachedUserProfile profile) async {
    // Офлайн режим: профиль Hive ішінде сақталады.
    final Box<Object?>? box = _box;
    if (box != null) {
      await box.put(_profileKey, profile.toJson());
    }
  }

  CachedUserProfile? readProfile() {
    final Box<Object?>? box = _box;
    if (box == null) return null;
    final Object? raw = box.get(_profileKey);
    if (raw is Map<Object?, Object?>) {
      return CachedUserProfile.fromJson(raw);
    }
    return null;
  }

  Future<void> clearProfile() async {
    final Box<Object?>? box = _box;
    if (box != null) {
      await box.delete(_profileKey);
    }
  }
}
