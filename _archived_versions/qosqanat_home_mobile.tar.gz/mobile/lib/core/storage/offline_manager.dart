/// Офлайн менеджері — кэш + синхрондау кезегі (Hive негізінде)
///
/// Функциялары:
/// 1. Соңғы 5 сабақ + квиздерді кэштеу
/// 2. Квиз жауаптарын офлайн кезекке қосу
/// 3. Интернет қосылғанда кезекті синхрондау

import 'dart:convert';

import 'package:hive_flutter/hive_flutter.dart';

import '../../data/models/lesson_model.dart';
import '../../data/models/quiz_model.dart';
import '../network/api_client.dart';
import '../network/endpoints.dart';

/// Офлайн кезектегі элемент
class QueuedSubmission {
  const QueuedSubmission({
    required this.id,
    required this.payload,
    required this.createdAt,
  });

  final String id;
  final Map<String, Object?> payload;
  final String createdAt;

  Map<String, Object?> toJson() => <String, Object?>{
    'id': id, 'payload': payload, 'createdAt': createdAt,
  };

  static QueuedSubmission? fromJson(Map<Object?, Object?> raw) {
    final Object? id = raw['id'];
    final Object? payload = raw['payload'];
    final Object? createdAt = raw['createdAt'];
    if (id is! String || payload is! Map || createdAt is! String) return null;
    final Map<String, Object?> typedPayload = <String, Object?>{};
    payload.forEach((Object? key, Object? value) {
      if (key is String) typedPayload[key] = value;
    });
    return QueuedSubmission(id: id, payload: typedPayload, createdAt: createdAt);
  }
}

class OfflineManager {
  OfflineManager({ApiClient? apiClient}) : _apiClient = apiClient;

  static const String _lessonBoxName = 'qq_lesson_cache';
  static const String _quizBoxName = 'qq_quiz_cache';
  static const String _queueBoxName = 'qq_sync_queue';
  static const int _maxCachedItems = 5;

  ApiClient? _apiClient;
  late final Box<Object?> _lessonBox;
  late final Box<Object?> _quizBox;
  late final Box<Object?> _queueBox;
  bool _initialized = false;

  /// Офлайн менеджерін инициализациялау
  Future<void> init() async {
    if (_initialized) return;
    if (!Hive.isBoxOpen(_lessonBoxName)) {
      _lessonBox = await Hive.openBox<Object?>(_lessonBoxName);
    } else {
      _lessonBox = Hive.box<Object?>(_lessonBoxName);
    }
    if (!Hive.isBoxOpen(_quizBoxName)) {
      _quizBox = await Hive.openBox<Object?>(_quizBoxName);
    } else {
      _quizBox = Hive.box<Object?>(_quizBoxName);
    }
    if (!Hive.isBoxOpen(_queueBoxName)) {
      _queueBox = await Hive.openBox<Object?>(_queueBoxName);
    } else {
      _queueBox = Hive.box<Object?>(_queueBoxName);
    }
    _initialized = true;
  }

  void setApiClient(ApiClient client) {
    _apiClient = client;
  }

  // ── Сабақ кэші ──

  /// Сабақты кэшке сақтау (FIFO, максимум 5)
  Future<void> cacheLesson(LessonDetailModel lesson) async {
    _ensureInitialized();
    // Ескі жазбаларды тазалау (FIFO)
    if (_lessonBox.length >= _maxCachedItems) {
      final String oldestKey = _lessonBox.keys.first as String;
      await _lessonBox.delete(oldestKey);
    }
    await _lessonBox.put(lesson.id, jsonEncode(lesson.toJson()));
  }

  /// Кэштен сабақ оқу
  LessonDetailModel? getCachedLesson(String lessonId) {
    _ensureInitialized();
    final Object? raw = _lessonBox.get(lessonId);
    if (raw is! String) return null;
    final Object? decoded = jsonDecode(raw);
    if (decoded is! Map<String, Object?>) return null;
    return LessonDetailModel.fromJson(decoded);
  }

  /// Кэштегі сабақ ID-лері
  List<String> get cachedLessonIds {
    _ensureInitialized();
    return _lessonBox.keys.cast<String>().toList();
  }

  // ── Квиз кэші ──

  /// Квизді кэшке сақтау (FIFO, максимум 5)
  Future<void> cacheQuiz(QuizModel quiz) async {
    _ensureInitialized();
    if (_quizBox.length >= _maxCachedItems) {
      final String oldestKey = _quizBox.keys.first as String;
      await _quizBox.delete(oldestKey);
    }
    await _quizBox.put(quiz.id, jsonEncode(quiz.toJson()));
  }

  /// Кэштен квиз оқу
  QuizModel? getCachedQuiz(String quizId) {
    _ensureInitialized();
    final Object? raw = _quizBox.get(quizId);
    if (raw is! String) return null;
    final Object? decoded = jsonDecode(raw);
    if (decoded is! Map<String, Object?>) return null;
    return QuizModel.fromJson(decoded);
  }

  // ── Синхрондау кезегі ──

  /// Квиз жауабын кезекке қосу (офлайн режим)
  Future<void> enqueueSubmission(QuizSubmitPayload payload) async {
    _ensureInitialized();
    final String id = '${payload.quizId}_${DateTime.now().millisecondsSinceEpoch}';
    final QueuedSubmission entry = QueuedSubmission(
      id: id,
      payload: payload.toJson(),
      createdAt: DateTime.now().toUtc().toIso8601String(),
    );
    await _queueBox.put(id, jsonEncode(entry.toJson()));
  }

  /// Кезектегі элементтер саны
  int get pendingCount {
    _ensureInitialized();
    return _queueBox.length;
  }

  /// Кезектегі барлық элементтерді синхрондау
  /// Қосылым қалпына келгенде шақырылады.
  Future<SyncResult> syncQueue() async {
    _ensureInitialized();
    final ApiClient? client = _apiClient;
    if (client == null) {
      return const SyncResult(synced: 0, failed: 0, errors: <String>[]);
    }

    int synced = 0;
    int failed = 0;
    final List<String> errors = <String>[];
    final List<String> keysToDelete = <String>[];

    for (final Object key in _queueBox.keys.cast<Object>()) {
      final Object? raw = _queueBox.get(key);
      if (raw is! String) {
        keysToDelete.add(key as String);
        continue;
      }

      final Object? decoded = jsonDecode(raw);
      if (decoded is! Map<String, Object?>) {
        keysToDelete.add(key as String);
        continue;
      }

      final Object? payload = decoded['payload'];
      if (payload is! Map<String, Object?>) {
        keysToDelete.add(key as String);
        continue;
      }

      try {
        await client.post(
          ProgressEndpoints.submitQuiz,
          payload,
          authenticated: true,
        );
        keysToDelete.add(key as String);
        synced++;
      } on Exception catch (e) {
        // Қайталанатын жіберу қатесі — кезектен өшіру
        if (e.toString().contains('DUPLICATE_SUBMISSION')) {
          keysToDelete.add(key as String);
          synced++;
        } else {
          failed++;
          errors.add(e.toString());
        }
      }
    }

    // Сәтті синхрондалған элементтерді өшіру
    for (final String key in keysToDelete) {
      await _queueBox.delete(key);
    }

    return SyncResult(synced: synced, failed: failed, errors: errors);
  }

  /// Барлық кэшті тазалау
  Future<void> clearAll() async {
    _ensureInitialized();
    await _lessonBox.clear();
    await _quizBox.clear();
    await _queueBox.clear();
  }

  void _ensureInitialized() {
    if (!_initialized) {
      throw StateError('OfflineManager.init() шақырылмаған');
    }
  }
}

/// Синхрондау нәтижесі
class SyncResult {
  const SyncResult({
    required this.synced,
    required this.failed,
    required this.errors,
  });

  final int synced;
  final int failed;
  final List<String> errors;

  bool get hasErrors => failed > 0;
}
