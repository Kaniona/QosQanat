import 'dart:convert';

import 'package:http/http.dart' as http;

import '../storage/secure_storage.dart';

class AuthInterceptor {
  AuthInterceptor({
    required SecureStorage secureStorage,
    required http.Client httpClient,
    required Uri baseUri,
  })  : _secureStorage = secureStorage,
        _httpClient = httpClient,
        _baseUri = baseUri;

  final SecureStorage _secureStorage;
  final http.Client _httpClient;
  final Uri _baseUri;

  Future<http.Response> send({
    required String method,
    required Uri uri,
    required Map<String, String> headers,
    String? body,
    bool authenticated = false,
  }) async {
    final Map<String, String> requestHeaders = <String, String>{...headers};
    if (authenticated) {
      final String? accessToken = await _secureStorage.readAccessToken();
      if (accessToken != null) {
        requestHeaders['Authorization'] = 'Bearer $accessToken';
      }
    }

    final http.Response response = await _send(method, uri, requestHeaders, body);
    if (!authenticated || response.statusCode != 401) {
      return response;
    }

    final bool refreshed = await _refreshTokens();
    if (!refreshed) {
      await _secureStorage.clearTokens();
      return response;
    }

    final String? accessToken = await _secureStorage.readAccessToken();
    final Map<String, String> retryHeaders = <String, String>{...headers};
    if (accessToken != null) {
      retryHeaders['Authorization'] = 'Bearer $accessToken';
    }
    return _send(method, uri, retryHeaders, body);
  }

  Future<http.Response> _send(
    String method,
    Uri uri,
    Map<String, String> headers,
    String? body,
  ) {
    return switch (method) {
      'GET' => _httpClient.get(uri, headers: headers),
      'POST' => _httpClient.post(uri, headers: headers, body: body),
      'PUT' => _httpClient.put(uri, headers: headers, body: body),
      _ => throw UnsupportedError('Unsupported method: $method'),
    };
  }

  Future<bool> _refreshTokens() async {
    final String? refreshToken = await _secureStorage.readRefreshToken();
    if (refreshToken == null) {
      return false;
    }

    final http.Response response = await _httpClient.post(
      _baseUri.resolve('/auth/refresh'),
      headers: <String, String>{'Content-Type': 'application/json'},
      body: jsonEncode(<String, Object?>{'refreshToken': refreshToken}),
    );
    if (response.statusCode != 200) {
      return false;
    }

    final Object? decoded = jsonDecode(response.body) as Object?;
    if (decoded is! Map<String, Object?>) {
      return false;
    }
    final Object? data = decoded['data'];
    if (data is! Map<String, Object?>) {
      return false;
    }
    final Object? tokens = data['tokens'];
    if (tokens is! Map<String, Object?>) {
      return false;
    }
    final Object? access = tokens['accessToken'];
    final Object? refresh = tokens['refreshToken'];
    if (access is! String || refresh is! String) {
      return false;
    }

    await _secureStorage.saveTokens(accessToken: access, refreshToken: refresh);
    return true;
  }
}
