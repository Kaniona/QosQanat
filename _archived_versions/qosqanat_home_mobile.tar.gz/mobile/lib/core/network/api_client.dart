import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/env_config.dart';
import '../storage/local_cache.dart';
import '../storage/secure_storage.dart';
import 'auth_interceptor.dart';

class ApiClient {
  ApiClient({
    SecureStorage? secureStorage,
    LocalCache? localCache,
    http.Client? httpClient,
    String baseUrl = EnvConfig.apiBaseUrl,
  })  : secureStorage = secureStorage ?? SecureStorage(),
        localCache = localCache ?? LocalCache(),
        _httpClient = httpClient ?? http.Client(),
        _baseUri = Uri.parse(baseUrl) {
    _authInterceptor = AuthInterceptor(
      secureStorage: this.secureStorage,
      httpClient: _httpClient,
      baseUri: _baseUri,
    );
  }

  final SecureStorage secureStorage;
  final LocalCache localCache;
  final http.Client _httpClient;
  final Uri _baseUri;
  late final AuthInterceptor _authInterceptor;

  Future<Map<String, Object?>> get(
    String path, {
    bool authenticated = false,
  }) {
    return _request(
      method: 'GET',
      path: path,
      authenticated: authenticated,
    );
  }

  Future<Map<String, Object?>> post(
    String path,
    Map<String, Object?> body, {
    bool authenticated = false,
  }) {
    return _request(
      method: 'POST',
      path: path,
      body: body,
      authenticated: authenticated,
    );
  }

  Future<Map<String, Object?>> put(
    String path,
    Map<String, Object?> body, {
    bool authenticated = false,
  }) {
    return _request(
      method: 'PUT',
      path: path,
      body: body,
      authenticated: authenticated,
    );
  }

  Future<void> saveAuthPayload(Map<String, Object?> payload) async {
    final Object? tokens = payload['tokens'];
    final Object? user = payload['user'];
    if (tokens is! Map<String, Object?> || user is! Map<String, Object?>) {
      throw const ApiClientException('Malformed auth response');
    }

    final Object? accessToken = tokens['accessToken'];
    final Object? refreshToken = tokens['refreshToken'];
    if (accessToken is! String || refreshToken is! String) {
      throw const ApiClientException('Missing auth tokens');
    }
    await secureStorage.saveTokens(accessToken: accessToken, refreshToken: refreshToken);

    final CachedUserProfile? profile = CachedUserProfile.fromJson(user);
    if (profile != null) {
      await localCache.cacheProfile(profile);
    }
  }

  Future<Map<String, Object?>> _request({
    required String method,
    required String path,
    Map<String, Object?>? body,
    bool authenticated = false,
  }) async {
    final http.Response response = await _authInterceptor.send(
      method: method,
      uri: _baseUri.resolve(path),
      headers: <String, String>{'Content-Type': 'application/json'},
      body: body == null ? null : jsonEncode(body),
      authenticated: authenticated,
    );

    final Object? decoded = response.body.isEmpty ? null : jsonDecode(response.body) as Object?;
    if (decoded is! Map<String, Object?>) {
      throw const ApiClientException('Malformed server response');
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final Object? error = decoded['error'];
      if (error is Map<String, Object?>) {
        final Object? message = error['message'];
        throw ApiClientException(message is String ? message : 'Request failed');
      }
      throw const ApiClientException('Request failed');
    }

    final Object? data = decoded['data'];
    if (data is Map<String, Object?>) {
      return data;
    }
    return <String, Object?>{'value': data};
  }
}

class ApiClientException implements Exception {
  const ApiClientException(this.message);

  final String message;

  @override
  String toString() => message;
}
