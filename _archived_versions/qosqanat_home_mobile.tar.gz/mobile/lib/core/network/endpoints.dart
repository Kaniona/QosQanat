// API endpoint тұрақтылары — барлық REST маршруттар бір жерде

/// Контент маршруттары
class ContentEndpoints {
  const ContentEndpoints._();

  /// Пәндер тізімі (grade query параметрімен)
  static String subjects(int grade) => '/content/subjects?grade=$grade';

  /// Сабақтың толық мазмұны
  static String lesson(String id) => '/content/lessons/$id';

  /// Квиз сұрақтарымен
  static String quiz(String id) => '/content/quizzes/$id';

  /// Күтудегі үй тапсырмалары
  static const String pendingHomework = '/content/homework/pending';
}

/// Прогресс маршруттары
class ProgressEndpoints {
  const ProgressEndpoints._();

  /// Квиз жауабын жіберу
  static const String submitQuiz = '/progress/quiz/submit';

  /// Серия тексеру
  static const String streakCheck = '/progress/streak/check';

  /// Прогресс картасы
  static const String map = '/progress/map';
}

/// Ассистент маршруттары
class AssistantEndpoints {
  const AssistantEndpoints._();

  /// Чат сұрауы
  static const String chat = '/assistant/chat';

  /// Қатені талдау
  static const String explainMistake = '/assistant/explain-mistake';

  /// Апталық жоспар
  static const String weeklyPlan = '/assistant/weekly-plan';

  /// TTS дауыстар тізімі
  static const String voices = '/assistant/voices';
}

/// Достар маршруттары
class FriendsEndpoints {
  const FriendsEndpoints._();

  static const String search = '/friends/search';
  static const String friendsRequest = '/friends/request';
  static const String friendsAccept = '/friends/accept';
  static const String friendsDecline = '/friends/decline';
  static const String friendsGift = '/friends/gift';

  // League & Tournaments
  static const String leagueStatus = '/league/status';
  static const String leagueLeaderboard = '/league/leaderboard';
  static const String tournamentsActive = '/tournaments/active';
  static const String tournamentsJoin = '/tournaments/join';
  
  // Shop & Inventory
  static const String shopItems = '/shop/items';
  static const String shopBuy = '/shop/buy';
  static const String inventory = '/inventory';
  static const String inventoryEquip = '/inventory/equip';
  static const String inventoryUnequip = '/inventory/unequip';

  // Notifications & Analytics
  static const String fcmRegister = '/notifications/register';
  static const String adminPush = '/notifications/admin/push';
  static const String analyticsBatch = '/analytics/batch';
  static const String analyticsDashboard = '/analytics/dashboard';

  // Parent Portal
  static const String parentReport = '/parent/report';

  // Squad
  static const String squadCreate = '/squad/create';
  static const String list = '/friends';
  static const String requests = '/friends/requests';
  static const String gift = '/friends/gift';
}

/// Топ маршруттары
class SquadEndpoints {
  const SquadEndpoints._();

  static const String create = '/squad/create';
  static const String startQuiz = '/squad/start-quiz'; // URL has /:id/
  static const String submit = '/squad/submit';       // URL has /:id/
}

/// Батл маршруттары
class BattleEndpoints {
  const BattleEndpoints._();

  static const String find = '/battle/find';
  static const String room = '/battle/room';
}

/// WebSocket URL құру
String getWsUrl(String baseUrl) {
  final uri = Uri.parse(baseUrl);
  final scheme = uri.scheme == 'https' ? 'wss' : 'ws';
  return '$scheme://${uri.host}:${uri.port}/ws';
}
