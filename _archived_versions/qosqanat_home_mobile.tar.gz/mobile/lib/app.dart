import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/network/api_client.dart';
import 'features/auth/login_screen.dart';

class QosQanatApp extends StatelessWidget {
  const QosQanatApp({
    required this.apiClient,
    super.key,
  });

  final ApiClient apiClient;

  @override
  Widget build(BuildContext context) {
    return ProviderScope(
      child: MaterialApp(
        title: 'QosQanat',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF1A6FBF),
            primary: const Color(0xFF1A6FBF),
            secondary: const Color(0xFFD4A017),
            surface: const Color(0xFFF8FAFC),
          ),
          scaffoldBackgroundColor: const Color(0xFFF8FAFC),
          useMaterial3: true,
          inputDecorationTheme: InputDecorationTheme(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
          ),
        ),
        darkTheme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF1A6FBF),
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
        ),
        home: LoginScreen(apiClient: apiClient),
      ),
    );
  }
}
