/// Прогресс деректер моделі — EXP, монеталар, серия, прогресс картасы

class ProgressModel {
  const ProgressModel({
    required this.totalExp,
    required this.coins,
    required this.currentStreak,
    required this.longestStreak,
    required this.completedLessons,
    required this.completedTopics,
  });

  final int totalExp;
  final int coins;
  final int currentStreak;
  final int longestStreak;
  final List<CompletedLessonModel> completedLessons;
  final List<String> completedTopics;

  static ProgressModel? fromJson(Map<String, Object?> json) {
    final Object? exp = json['totalExp'];
    final Object? coins = json['coins'];
    final Object? streak = json['currentStreak'];
    final Object? longest = json['longestStreak'];
    final Object? lessons = json['completedLessons'];
    final Object? topics = json['completedTopics'];
    if (exp is! int || coins is! int || streak is! int ||
        longest is! int || lessons is! List || topics is! List) {
      return null;
    }
    return ProgressModel(
      totalExp: exp, coins: coins,
      currentStreak: streak, longestStreak: longest,
      completedLessons: lessons
          .whereType<Map<String, Object?>>()
          .map(CompletedLessonModel.fromJson)
          .whereType<CompletedLessonModel>()
          .toList(),
      completedTopics: topics.whereType<String>().toList(),
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'totalExp': totalExp, 'coins': coins,
    'currentStreak': currentStreak, 'longestStreak': longestStreak,
    'completedLessons': completedLessons.map(
      (CompletedLessonModel l) => l.toJson(),
    ).toList(),
    'completedTopics': completedTopics,
  };
}

class CompletedLessonModel {
  const CompletedLessonModel({required this.lessonId, required this.expEarned});

  final String lessonId;
  final int expEarned;

  static CompletedLessonModel? fromJson(Map<String, Object?> json) {
    final Object? id = json['lessonId'];
    final Object? exp = json['expEarned'];
    if (id is! String || exp is! int) return null;
    return CompletedLessonModel(lessonId: id, expEarned: exp);
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'lessonId': lessonId, 'expEarned': expEarned,
  };
}

class StreakModel {
  const StreakModel({
    required this.currentStreak,
    required this.longestStreak,
    required this.isActiveToday,
    this.lastActivityDate,
  });

  final int currentStreak;
  final int longestStreak;
  final String? lastActivityDate;
  final bool isActiveToday;

  static StreakModel? fromJson(Map<String, Object?> json) {
    final Object? streak = json['currentStreak'];
    final Object? longest = json['longestStreak'];
    final Object? active = json['isActiveToday'];
    if (streak is! int || longest is! int || active is! bool) return null;
    final Object? lastDate = json['lastActivityDate'];
    return StreakModel(
      currentStreak: streak, longestStreak: longest,
      isActiveToday: active,
      lastActivityDate: lastDate is String ? lastDate : null,
    );
  }
}
