/// Квиз деректер моделі — сұрақтар, нұсқалар, жауап жіберу

class QuizModel {
  const QuizModel({
    required this.id,
    required this.type,
    required this.nameKk,
    required this.nameRu,
    required this.timeLimitSeconds,
    required this.questions,
    this.lessonId,
  });

  final String id;
  final String? lessonId;
  final String type; // LESSON | TOPIC | HOMEWORK
  final String nameKk;
  final String nameRu;
  final int timeLimitSeconds;
  final List<QuestionModel> questions;

  static QuizModel? fromJson(Map<String, Object?> json) {
    final Object? id = json['id'];
    final Object? type = json['type'];
    final Object? nameKk = json['nameKk'];
    final Object? nameRu = json['nameRu'];
    final Object? timeLimit = json['timeLimitSeconds'];
    final Object? questions = json['questions'];
    if (id is! String || type is! String || nameKk is! String ||
        nameRu is! String || timeLimit is! int || questions is! List) {
      return null;
    }
    final Object? lessonId = json['lessonId'];
    return QuizModel(
      id: id, lessonId: lessonId is String ? lessonId : null,
      type: type, nameKk: nameKk, nameRu: nameRu,
      timeLimitSeconds: timeLimit,
      questions: questions
          .whereType<Map<String, Object?>>()
          .map(QuestionModel.fromJson)
          .whereType<QuestionModel>()
          .toList(),
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'id': id, 'lessonId': lessonId, 'type': type,
    'nameKk': nameKk, 'nameRu': nameRu,
    'timeLimitSeconds': timeLimitSeconds,
    'questions': questions.map((QuestionModel q) => q.toJson()).toList(),
  };
}

class QuestionModel {
  const QuestionModel({
    required this.id,
    required this.textKk,
    required this.textRu,
    required this.kind,
    required this.order,
    required this.options,
  });

  final String id;
  final String textKk;
  final String textRu;
  final String kind; // SINGLE | MULTIPLE
  final int order;
  final List<OptionModel> options;

  static QuestionModel? fromJson(Map<String, Object?> json) {
    final Object? id = json['id'];
    final Object? textKk = json['textKk'];
    final Object? textRu = json['textRu'];
    final Object? kind = json['kind'];
    final Object? order = json['order'];
    final Object? options = json['options'];
    if (id is! String || textKk is! String || textRu is! String ||
        kind is! String || order is! int || options is! List) {
      return null;
    }
    return QuestionModel(
      id: id, textKk: textKk, textRu: textRu, kind: kind, order: order,
      options: options
          .whereType<Map<String, Object?>>()
          .map(OptionModel.fromJson)
          .whereType<OptionModel>()
          .toList(),
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'id': id, 'textKk': textKk, 'textRu': textRu,
    'kind': kind, 'order': order,
    'options': options.map((OptionModel o) => o.toJson()).toList(),
  };
}

class OptionModel {
  const OptionModel({
    required this.id,
    required this.textKk,
    required this.textRu,
    required this.order,
  });

  final String id;
  final String textKk;
  final String textRu;
  final int order;

  static OptionModel? fromJson(Map<String, Object?> json) {
    final Object? id = json['id'];
    final Object? textKk = json['textKk'];
    final Object? textRu = json['textRu'];
    final Object? order = json['order'];
    if (id is! String || textKk is! String || textRu is! String || order is! int) {
      return null;
    }
    return OptionModel(id: id, textKk: textKk, textRu: textRu, order: order);
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'id': id, 'textKk': textKk, 'textRu': textRu, 'order': order,
  };
}

/// Квиз жіберу сұрауы
class QuizSubmitPayload {
  const QuizSubmitPayload({
    required this.quizId,
    required this.answers,
    required this.startedAt,
    required this.submittedAt,
  });

  final String quizId;
  final List<AnswerPayload> answers;
  final String startedAt;
  final String submittedAt;

  Map<String, Object?> toJson() => <String, Object?>{
    'quizId': quizId,
    'answers': answers.map((AnswerPayload a) => a.toJson()).toList(),
    'startedAt': startedAt,
    'submittedAt': submittedAt,
  };
}

class AnswerPayload {
  const AnswerPayload({required this.questionId, required this.selectedOptionIds});

  final String questionId;
  final List<String> selectedOptionIds;

  Map<String, Object?> toJson() => <String, Object?>{
    'questionId': questionId,
    'selectedOptionIds': selectedOptionIds,
  };
}

/// Квиз жіберу нәтижесі
class QuizResultModel {
  const QuizResultModel({
    required this.score,
    required this.totalQuestions,
    required this.correctCount,
    required this.expEarned,
    required this.coinsEarned,
    required this.maxCombo,
    required this.newStreak,
    required this.streakUpdated,
  });

  final int score;
  final int totalQuestions;
  final int correctCount;
  final int expEarned;
  final int coinsEarned;
  final int maxCombo;
  final int newStreak;
  final bool streakUpdated;

  static QuizResultModel? fromJson(Map<String, Object?> json) {
    final Object? score = json['score'];
    final Object? total = json['totalQuestions'];
    final Object? correct = json['correctCount'];
    final Object? exp = json['expEarned'];
    final Object? coins = json['coinsEarned'];
    final Object? combo = json['maxCombo'];
    final Object? streak = json['newStreak'];
    final Object? updated = json['streakUpdated'];
    if (score is! int || total is! int || correct is! int || exp is! int ||
        coins is! int || combo is! int || streak is! int || updated is! bool) {
      return null;
    }
    return QuizResultModel(
      score: score, totalQuestions: total, correctCount: correct,
      expEarned: exp, coinsEarned: coins, maxCombo: combo,
      newStreak: streak, streakUpdated: updated,
    );
  }
}
