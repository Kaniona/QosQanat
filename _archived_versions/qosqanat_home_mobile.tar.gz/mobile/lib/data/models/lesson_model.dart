/// Сабақ деректер моделі — API жауабын Dart объектіне айналдырады

class LessonSummaryModel {
  const LessonSummaryModel({
    required this.id,
    required this.topicId,
    required this.nameKk,
    required this.nameRu,
    required this.order,
    required this.durationMinutes,
  });

  final String id;
  final String topicId;
  final String nameKk;
  final String nameRu;
  final int order;
  final int durationMinutes;

  static LessonSummaryModel? fromJson(Map<String, Object?> json) {
    final Object? id = json['id'];
    final Object? topicId = json['topicId'];
    final Object? nameKk = json['nameKk'];
    final Object? nameRu = json['nameRu'];
    final Object? order = json['order'];
    final Object? dur = json['durationMinutes'];
    if (id is! String || topicId is! String || nameKk is! String ||
        nameRu is! String || order is! int || dur is! int) {
      return null;
    }
    return LessonSummaryModel(
      id: id, topicId: topicId, nameKk: nameKk,
      nameRu: nameRu, order: order, durationMinutes: dur,
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'id': id, 'topicId': topicId, 'nameKk': nameKk,
    'nameRu': nameRu, 'order': order, 'durationMinutes': durationMinutes,
  };
}

/// Сабақтың толық мазмұны
class LessonDetailModel {
  const LessonDetailModel({
    required this.id,
    required this.topicId,
    required this.nameKk,
    required this.nameRu,
    required this.contentKk,
    required this.contentRu,
    required this.order,
    required this.durationMinutes,
    required this.quizIds,
  });

  final String id;
  final String topicId;
  final String nameKk;
  final String nameRu;
  final String contentKk;
  final String contentRu;
  final int order;
  final int durationMinutes;
  final List<String> quizIds;

  static LessonDetailModel? fromJson(Map<String, Object?> json) {
    final Object? id = json['id'];
    final Object? topicId = json['topicId'];
    final Object? nameKk = json['nameKk'];
    final Object? nameRu = json['nameRu'];
    final Object? contentKk = json['contentKk'];
    final Object? contentRu = json['contentRu'];
    final Object? order = json['order'];
    final Object? dur = json['durationMinutes'];
    final Object? quizIds = json['quizIds'];
    if (id is! String || topicId is! String || nameKk is! String ||
        nameRu is! String || contentKk is! String || contentRu is! String ||
        order is! int || dur is! int || quizIds is! List) {
      return null;
    }
    return LessonDetailModel(
      id: id, topicId: topicId, nameKk: nameKk, nameRu: nameRu,
      contentKk: contentKk, contentRu: contentRu,
      order: order, durationMinutes: dur,
      quizIds: quizIds.whereType<String>().toList(),
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'id': id, 'topicId': topicId, 'nameKk': nameKk, 'nameRu': nameRu,
    'contentKk': contentKk, 'contentRu': contentRu,
    'order': order, 'durationMinutes': durationMinutes, 'quizIds': quizIds,
  };
}

/// Пән → бөлім → тақырып ағашы (Knowledge Map үшін)
class SubjectTreeModel {
  const SubjectTreeModel({
    required this.id,
    required this.grade,
    required this.nameKk,
    required this.nameRu,
    required this.icon,
    required this.order,
    required this.sections,
  });

  final String id;
  final int grade;
  final String nameKk;
  final String nameRu;
  final String icon;
  final int order;
  final List<SectionModel> sections;

  static SubjectTreeModel? fromJson(Map<String, Object?> json) {
    final Object? id = json['id'];
    final Object? grade = json['grade'];
    final Object? nameKk = json['nameKk'];
    final Object? nameRu = json['nameRu'];
    final Object? icon = json['icon'];
    final Object? order = json['order'];
    final Object? sections = json['sections'];
    if (id is! String || grade is! int || nameKk is! String ||
        nameRu is! String || icon is! String || order is! int ||
        sections is! List) {
      return null;
    }
    return SubjectTreeModel(
      id: id, grade: grade, nameKk: nameKk, nameRu: nameRu,
      icon: icon, order: order,
      sections: sections
          .whereType<Map<String, Object?>>()
          .map(SectionModel.fromJson)
          .whereType<SectionModel>()
          .toList(),
    );
  }
}

class SectionModel {
  const SectionModel({
    required this.id, required this.nameKk, required this.nameRu,
    required this.order, required this.topics,
  });

  final String id;
  final String nameKk;
  final String nameRu;
  final int order;
  final List<TopicModel> topics;

  static SectionModel? fromJson(Map<String, Object?> json) {
    final Object? id = json['id'];
    final Object? nameKk = json['nameKk'];
    final Object? nameRu = json['nameRu'];
    final Object? order = json['order'];
    final Object? topics = json['topics'];
    if (id is! String || nameKk is! String || nameRu is! String ||
        order is! int || topics is! List) {
      return null;
    }
    return SectionModel(
      id: id, nameKk: nameKk, nameRu: nameRu, order: order,
      topics: topics
          .whereType<Map<String, Object?>>()
          .map(TopicModel.fromJson)
          .whereType<TopicModel>()
          .toList(),
    );
  }
}

class TopicModel {
  const TopicModel({
    required this.id, required this.nameKk, required this.nameRu,
    required this.order, required this.lessons,
  });

  final String id;
  final String nameKk;
  final String nameRu;
  final int order;
  final List<LessonSummaryModel> lessons;

  static TopicModel? fromJson(Map<String, Object?> json) {
    final Object? id = json['id'];
    final Object? nameKk = json['nameKk'];
    final Object? nameRu = json['nameRu'];
    final Object? order = json['order'];
    final Object? lessons = json['lessons'];
    if (id is! String || nameKk is! String || nameRu is! String ||
        order is! int || lessons is! List) {
      return null;
    }
    return TopicModel(
      id: id, nameKk: nameKk, nameRu: nameRu, order: order,
      lessons: lessons
          .whereType<Map<String, Object?>>()
          .map(LessonSummaryModel.fromJson)
          .whereType<LessonSummaryModel>()
          .toList(),
    );
  }
}
