// lib/services/analytics_service.dart

import 'dart:convert';

class AnalyticsEvent {
  final String id;
  final String name;
  final int timestamp;
  final Map<String, dynamic>? parameters;

  AnalyticsEvent({required this.name, this.parameters})
      : id = DateTime.now().microsecondsSinceEpoch.toString(),
        timestamp = DateTime.now().millisecondsSinceEpoch;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'timestamp': timestamp,
        'parameters': parameters,
      };
}

class AnalyticsService {
  // Hive Box симуляциясы (Оффлайн буфер)
  final List<AnalyticsEvent> _offlineBuffer = [];

  Future<void> init() async {
    // Stubbed to remove uuid package dependency
  }

  /// Оқиғаны тіркеу (Тікелей буферге түседі)
  void logEvent(String name, [Map<String, dynamic>? parameters]) {
    final event = AnalyticsEvent(name: name, parameters: parameters);
    _offlineBuffer.add(event); // Hive box-қа сақталады
    
    // Егер интернет болса, бірден жіберуге тырысамыз
    _attemptImmediateFlush();
  }

  Future<void> _attemptImmediateFlush() async {
    // if (await _hasInternet()) flushEvents();
  }

  /// Оффлайн буферді Backend-ке жіберу
  Future<void> flushEvents() async {
    if (_offlineBuffer.isEmpty) return;

    final batch = _offlineBuffer.map((e) => e.toJson()).toList();
    
    try {
      print('${batch.length} аналитика оқиғасы сәтті жіберілді.');
      
      // Сәтті жіберілгеннен кейін буферді тазалау
      _offlineBuffer.clear(); // Hive box.clear()
    } catch (e) {
      print('Аналитика жіберу қатесі. Келесі жолы қайталанады.');
    }
  }

  // COPPA Standard (No PII helper)
  void logLessonCompleted(String lessonId, int grade) {
    // PII емес, тек пайдалы метрикалар
    logEvent('LESSON_COMPLETED', {'lesson_id': lessonId, 'grade': grade});
  }
}
