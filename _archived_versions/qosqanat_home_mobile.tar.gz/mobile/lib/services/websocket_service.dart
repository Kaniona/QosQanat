// lib/services/websocket_service.dart

import 'dart:async';

class WebSocketService {
  WebSocketService({required this.baseUrl});

  final String baseUrl;
  
  final _eventController = StreamController<Map<String, dynamic>>.broadcast();
  Stream<Map<String, dynamic>> get events => _eventController.stream;

  bool _isConnected = false;
  bool get isConnected => _isConnected;

  String? _token;

  Future<void> connect(String token) async {
    _token = token;
    _isConnected = false;
    print('WebSocket connection disabled');
  }

  void send(Map<String, dynamic> data) {
    print('WebSocket send disabled');
  }

  void disconnect() {
    _token = null;
    _isConnected = false;
  }
}
