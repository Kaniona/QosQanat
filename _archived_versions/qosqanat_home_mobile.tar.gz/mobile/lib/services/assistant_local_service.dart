// Ассистент жергілікті сервисі — API клиент обертка
// Барлық REST сұраулар аутентификациямен жіберіледі

import '../core/network/api_client.dart';
import '../core/network/endpoints.dart';

/// Ассистент API сервисі — бэкендпен байланыс
class AssistantLocalService {
  AssistantLocalService({required ApiClient apiClient}) : _apiClient = apiClient;

  final ApiClient _apiClient;

  /// POST /assistant/chat — хабарлама жіберу
  Future<Map<String, Object?>> sendMessage(
    String message,
    String language,
  ) async {
    return _apiClient.post(
      AssistantEndpoints.chat,
      <String, Object?>{
        'message': message,
        'language': language,
      },
      authenticated: true,
    );
  }

  /// POST /assistant/explain-mistake — қатені талдау
  Future<Map<String, Object?>> explainMistake(
    String questionId,
    String language,
  ) async {
    return _apiClient.post(
      AssistantEndpoints.explainMistake,
      <String, Object?>{
        'questionId': questionId,
        'language': language,
      },
      authenticated: true,
    );
  }

  /// GET /assistant/weekly-plan — апталық жоспар
  Future<Map<String, Object?>> getWeeklyPlan() async {
    return _apiClient.get(
      AssistantEndpoints.weeklyPlan,
      authenticated: true,
    );
  }

  /// GET /assistant/voices — TTS дауыстар тізімі
  Future<Map<String, Object?>> getVoices() async {
    return _apiClient.get(
      AssistantEndpoints.voices,
      authenticated: true,
    );
  }
}
