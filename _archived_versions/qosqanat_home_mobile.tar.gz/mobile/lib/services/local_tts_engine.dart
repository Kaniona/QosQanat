// Жергілікті TTS қозғалтқышы — flutter_tts обертка
// Қазақша/Орысша дауыс таңдау + graceful fallback

import 'dart:async';

import 'package:flutter_tts/flutter_tts.dart';

/// TTS қозғалтқышы — құрылғы дауыстарымен жұмыс
class LocalTtsEngine {
  LocalTtsEngine({FlutterTts? tts}) : _tts = tts ?? FlutterTts();

  final FlutterTts _tts;
  bool _initialized = false;
  bool _available = false;
  bool _speaking = false;

  /// TTS қолжетімді ме?
  bool get isAvailable => _available;

  /// Қазір сөйлеп жатыр ма?
  bool get isSpeaking => _speaking;

  /// Инициализация — дауыстарды тексеру
  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;

    try {
      // Құрылғыда TTS бар ма тексеру
      final engines = await _tts.getEngines;
      _available = engines is List && engines.isNotEmpty;

      if (_available) {
        await _tts.setVolume(0.8);
        await _tts.setSpeechRate(0.45);
        await _tts.setPitch(1.0);

        _tts.setCompletionHandler(() {
          _speaking = false;
        });
        _tts.setErrorHandler((_) {
          _speaking = false;
        });
      }
    } catch (_) {
      _available = false;
    }
  }

  /// Мәтінді оқу — тіл бойынша дауыс таңдау
  Future<void> speak(String text, String language) async {
    await initialize();
    if (!_available || text.isEmpty) return;

    try {
      // Тіл орнату
      final langCode = language == 'kk' ? 'kk-KZ' : 'ru-RU';
      await _tts.setLanguage(langCode);

      // Егер тіл қолжетімді болмаса — fallback
      final isSupported = await _tts.isLanguageAvailable(langCode);
      if (isSupported != true) {
        // Орысша fallback (көпшілік құрылғыда бар)
        await _tts.setLanguage('ru-RU');
      }

      _speaking = true;
      await _tts.speak(text);
    } catch (_) {
      _speaking = false;
    }
  }

  /// Оқуды тоқтату
  Future<void> stop() async {
    try {
      _speaking = false;
      await _tts.stop();
    } catch (_) {
      // Қатені елемеу — graceful degradation
    }
  }

  /// Қолжетімді дауыстар тізімі
  Future<List<Map<String, String>>> getAvailableVoices() async {
    await initialize();
    if (!_available) return [];

    try {
      final voices = await _tts.getVoices;
      if (voices is! List) return [];

      return voices
          .whereType<Map>()
          .where((v) {
            final locale = (v['locale'] ?? '').toString();
            return locale.startsWith('kk') || locale.startsWith('ru');
          })
          .map((v) => {
                'name': v['name']?.toString() ?? '',
                'locale': v['locale']?.toString() ?? '',
              })
          .toList();
    } catch (_) {
      return [];
    }
  }

  /// Ресурстарды босату
  Future<void> dispose() async {
    try {
      await _tts.stop();
    } catch (_) {
      // Graceful cleanup
    }
  }
}
