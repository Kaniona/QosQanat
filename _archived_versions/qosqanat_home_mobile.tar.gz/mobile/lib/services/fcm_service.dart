// lib/services/fcm_service.dart

import 'dart:io';

class FcmService {
  Future<void> initPushNotifications() async {
    // Stubbed out to remove dependency on firebase_messaging
    print('Push notifications disabled');
  }

  Future<void> _registerTokenWithBackend(String token) async {
    print('FCM Token backend-ке жіберілді (Шифрланады)');
  }
}

// Background процесі (main.dart-тан тыс жерде орналасуы керек)
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(dynamic message) async {
  print("Фондық хабарлама алынды");
}
