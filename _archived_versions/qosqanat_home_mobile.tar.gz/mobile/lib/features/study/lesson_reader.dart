/// Сабақ оқу экраны — мәтінді оқу, квизге өту, офлайн кэштеу

import 'package:flutter/material.dart';

import '../../core/network/api_client.dart';
import '../../core/network/endpoints.dart';
import '../../core/storage/offline_manager.dart';
import '../../data/models/lesson_model.dart';

class LessonReaderScreen extends StatefulWidget {
  const LessonReaderScreen({
    required this.apiClient,
    required this.offlineManager,
    required this.lessonId,
    super.key,
    this.onQuizTap,
  });

  final ApiClient apiClient;
  final OfflineManager offlineManager;
  final String lessonId;
  final void Function(String quizId)? onQuizTap;

  @override
  State<LessonReaderScreen> createState() => _LessonReaderScreenState();
}

class _LessonReaderScreenState extends State<LessonReaderScreen> {
  LessonDetailModel? _lesson;
  bool _loading = true;
  String? _error;
  bool _isOffline = false;

  @override
  void initState() {
    super.initState();
    _loadLesson();
  }

  Future<void> _loadLesson() async {
    setState(() { _loading = true; _error = null; _isOffline = false; });

    try {
      final Map<String, Object?> res = await widget.apiClient.get(
        ContentEndpoints.lesson(widget.lessonId),
        authenticated: true,
      );

      final Object? lessonData = res['lesson'];
      if (lessonData is Map<String, Object?>) {
        final LessonDetailModel? parsed = LessonDetailModel.fromJson(lessonData);
        if (parsed != null) {
          // Кэшке сақтау
          await widget.offlineManager.cacheLesson(parsed);
          if (mounted) {
            setState(() { _lesson = parsed; _loading = false; });
          }
          return;
        }
      }
      throw Exception('Сабақ деректері қате');
    } on Exception catch (e) {
      // Қате болса — кэштен іздеу
      final LessonDetailModel? cached = widget.offlineManager.getCachedLesson(widget.lessonId);
      if (cached != null) {
        if (mounted) {
          setState(() {
            _lesson = cached;
            _isOffline = true;
            _loading = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _error = e.toString();
            _loading = false;
          });
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Сабақ'),
        bottom: _isOffline
            ? PreferredSize(
                preferredSize: const Size.fromHeight(24),
                child: Container(
                  color: Colors.amber,
                  width: double.infinity,
                  alignment: Alignment.center,
                  child: const Text('Офлайн режим (кэштелген нұсқа)', style: TextStyle(fontSize: 12)),
                ),
              )
            : null,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? _buildError()
              : _buildContent(),
    );
  }

  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          const Icon(Icons.error_outline, size: 64, color: Colors.red),
          const SizedBox(height: 16),
          const Text('Сабақты жүктеу мүмкін болмады'),
          const SizedBox(height: 8),
          Text(_error ?? '', style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 24),
          ElevatedButton(onPressed: _loadLesson, child: const Text('Қайталау')),
        ],
      ),
    );
  }

  Widget _buildContent() {
    final LessonDetailModel? lesson = _lesson;
    if (lesson == null) return const SizedBox.shrink();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(lesson.nameKk, style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 8),
          Text(lesson.nameRu, style: Theme.of(context).textTheme.titleMedium?.copyWith(color: Colors.grey)),
          const SizedBox(height: 24),
          // Қарапайым мәтін (Production-да Markdown/HTML рендері болады)
          Text(lesson.contentKk, style: const TextStyle(fontSize: 16, height: 1.5)),
          const SizedBox(height: 48),
          if (lesson.quizIds.isNotEmpty)
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: () => widget.onQuizTap?.call(lesson.quizIds.first),
                icon: const Icon(Icons.quiz),
                label: const Text('Тақырыпты бекіту (Квиз)', style: TextStyle(fontSize: 18)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1A6FBF),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
