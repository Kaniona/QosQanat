/// Knowledge Map — пәндер мен тақырыптар бойынша прогресс картасы
///
/// Иерархия: Пән → Бөлім → Тақырып → Сабақ
/// Аяқталған сабақтар жасыл, ағымдағы — көк, құлыптаулы — сұр.

import 'package:flutter/material.dart';

import '../../core/network/api_client.dart';
import '../../core/network/endpoints.dart';
import '../../data/models/lesson_model.dart';
import '../../data/models/progress_model.dart';

/// Прогресс картасы экраны
class KnowledgeMapScreen extends StatefulWidget {
  const KnowledgeMapScreen({
    required this.apiClient,
    required this.grade,
    super.key,
    this.onLessonTap,
  });

  final ApiClient apiClient;
  final int grade;
  final void Function(String lessonId)? onLessonTap;

  @override
  State<KnowledgeMapScreen> createState() => _KnowledgeMapScreenState();
}

class _KnowledgeMapScreenState extends State<KnowledgeMapScreen> {
  List<SubjectTreeModel> _subjects = <SubjectTreeModel>[];
  ProgressModel? _progress;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() { _loading = true; _error = null; });
    try {
      final Map<String, Object?> subjectsRes = await widget.apiClient.get(
        ContentEndpoints.subjects(widget.grade),
        authenticated: true,
      );
      final Map<String, Object?> progressRes = await widget.apiClient.get(
        ProgressEndpoints.map,
        authenticated: true,
      );

      final Object? subjectsList = subjectsRes['subjects'];
      final List<SubjectTreeModel> subjects = <SubjectTreeModel>[];
      if (subjectsList is List) {
        for (final Object? item in subjectsList) {
          if (item is Map<String, Object?>) {
            final SubjectTreeModel? model = SubjectTreeModel.fromJson(item);
            if (model != null) subjects.add(model);
          }
        }
      }

      if (mounted) {
        setState(() {
          _subjects = subjects;
          _progress = ProgressModel.fromJson(progressRes);
          _loading = false;
        });
      }
    } on Exception catch (e) {
      if (mounted) {
        setState(() { _error = e.toString(); _loading = false; });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Білім картасы'), // Знание картасы
        actions: <Widget>[
          if (_progress != null) ...<Widget>[
            _StatChip(icon: Icons.bolt, label: '${_progress!.totalExp} EXP'),
            _StatChip(icon: Icons.monetization_on, label: '${_progress!.coins}'),
            _StatChip(icon: Icons.local_fire_department, label: '${_progress!.currentStreak}🔥'),
          ],
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? _buildOfflineFallback()
              : _subjects.isEmpty
                  ? const Center(child: Text('Пәндер табылмады'))
                  : RefreshIndicator(
                      onRefresh: _loadData,
                      child: ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _subjects.length,
                        itemBuilder: (BuildContext context, int index) {
                          return _SubjectCard(
                            subject: _subjects[index],
                            completedLessonIds: _completedLessonIds,
                            completedTopicIds: _completedTopicIds,
                            onLessonTap: widget.onLessonTap,
                          );
                        },
                      ),
                    ),
    );
  }

  Set<String> get _completedLessonIds {
    final ProgressModel? p = _progress;
    if (p == null) return <String>{};
    return p.completedLessons.map((CompletedLessonModel l) => l.lessonId).toSet();
  }

  Set<String> get _completedTopicIds {
    final ProgressModel? p = _progress;
    if (p == null) return <String>{};
    return p.completedTopics.toSet();
  }

  /// Офлайн жағдайда көрсетілетін UI
  Widget _buildOfflineFallback() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Icon(Icons.cloud_off, size: 64, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Text(
            'Интернет қосылымы жоқ',
            style: TextStyle(fontSize: 18, color: Colors.grey.shade600),
          ),
          const SizedBox(height: 8),
          Text(
            'Кэштелген сабақтарды оқуға болады',
            style: TextStyle(color: Colors.grey.shade500),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _loadData,
            icon: const Icon(Icons.refresh),
            label: const Text('Қайталау'),
          ),
        ],
      ),
    );
  }
}

/// Статистика чипі (AppBar-да)
class _StatChip extends StatelessWidget {
  const _StatChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Chip(
        avatar: Icon(icon, size: 16),
        label: Text(label, style: const TextStyle(fontSize: 12)),
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        visualDensity: VisualDensity.compact,
      ),
    );
  }
}

/// Пән карточкасы — бөлімдер мен тақырыптарды ашуға болады
class _SubjectCard extends StatelessWidget {
  const _SubjectCard({
    required this.subject,
    required this.completedLessonIds,
    required this.completedTopicIds,
    this.onLessonTap,
  });

  final SubjectTreeModel subject;
  final Set<String> completedLessonIds;
  final Set<String> completedTopicIds;
  final void Function(String lessonId)? onLessonTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ExpansionTile(
        leading: Text(subject.icon, style: const TextStyle(fontSize: 28)),
        title: Text(subject.nameKk, style: theme.textTheme.titleMedium),
        subtitle: Text(subject.nameRu, style: theme.textTheme.bodySmall),
        children: <Widget>[
          for (final SectionModel section in subject.sections)
            _SectionTile(
              section: section,
              completedLessonIds: completedLessonIds,
              completedTopicIds: completedTopicIds,
              onLessonTap: onLessonTap,
            ),
        ],
      ),
    );
  }
}

class _SectionTile extends StatelessWidget {
  const _SectionTile({
    required this.section,
    required this.completedLessonIds,
    required this.completedTopicIds,
    this.onLessonTap,
  });

  final SectionModel section;
  final Set<String> completedLessonIds;
  final Set<String> completedTopicIds;
  final void Function(String lessonId)? onLessonTap;

  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      title: Text(section.nameKk),
      subtitle: Text(section.nameRu, style: Theme.of(context).textTheme.bodySmall),
      children: <Widget>[
        for (final TopicModel topic in section.topics)
          _TopicTile(
            topic: topic,
            completedLessonIds: completedLessonIds,
            isTopicCompleted: completedTopicIds.contains(topic.id),
            onLessonTap: onLessonTap,
          ),
      ],
    );
  }
}

class _TopicTile extends StatelessWidget {
  const _TopicTile({
    required this.topic,
    required this.completedLessonIds,
    required this.isTopicCompleted,
    this.onLessonTap,
  });

  final TopicModel topic;
  final Set<String> completedLessonIds;
  final bool isTopicCompleted;
  final void Function(String lessonId)? onLessonTap;

  @override
  Widget build(BuildContext context) {
    final int total = topic.lessons.length;
    final int completed = topic.lessons
        .where((LessonSummaryModel l) => completedLessonIds.contains(l.id))
        .length;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(
                isTopicCompleted ? Icons.check_circle : Icons.radio_button_unchecked,
                color: isTopicCompleted ? Colors.green : Colors.grey,
                size: 20,
              ),
              const SizedBox(width: 8),
              Expanded(child: Text(topic.nameKk)),
              Text('$completed/$total', style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
          if (total > 0)
            Padding(
              padding: const EdgeInsets.only(top: 4, bottom: 8),
              child: LinearProgressIndicator(
                value: total > 0 ? completed / total : 0,
                backgroundColor: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          for (final LessonSummaryModel lesson in topic.lessons)
            ListTile(
              dense: true,
              leading: Icon(
                completedLessonIds.contains(lesson.id)
                    ? Icons.check_circle
                    : Icons.play_circle_outline,
                color: completedLessonIds.contains(lesson.id)
                    ? Colors.green
                    : const Color(0xFF1A6FBF),
              ),
              title: Text(lesson.nameKk),
              subtitle: Text('${lesson.durationMinutes} мин'),
              onTap: () => onLessonTap?.call(lesson.id),
            ),
          const Divider(),
        ],
      ),
    );
  }
}
