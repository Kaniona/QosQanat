// Оқу тобы басқару тақтасы — құру, мүшелерді көру, топтық квиз бастау

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class SquadDashboard extends ConsumerStatefulWidget {
  const SquadDashboard({super.key});

  @override
  ConsumerState<SquadDashboard> createState() => _SquadDashboardState();
}

class _SquadDashboardState extends ConsumerState<SquadDashboard> {
  bool _hasActiveSquad = true; // Мок үшін true

  void _onCreateSquad() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Топ құрылды!')));
  }

  void _onStartQuiz() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Топтық квиз басталды!')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Оқу тобы')),
      body: _hasActiveSquad ? _buildActiveSquad() : _buildCreateSquad(),
    );
  }

  Widget _buildCreateSquad() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.group_add, size: 80, color: Colors.blue),
            const SizedBox(height: 16),
            const Text('Өз тобыңызды құрыңыз', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Достарыңызбен бірге оқып, күн сайын +50 EXP бонус алыңыз!', textAlign: TextAlign.center),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: _onCreateSquad,
              style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
              child: const Text('Достарды шақыру (1-3)'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActiveSquad() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          color: Theme.of(context).colorScheme.primaryContainer,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const Text('Жеңімпаздар тобы', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Бүгінгі бонус: Қолжетімді! 🎁', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: _onStartQuiz,
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('Топтық квизді бастау (Күніне 1 рет)'),
                  style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 24),
        const Text('Топ мүшелері (3/4)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        _buildMemberCard('Сен', 'Жасаушы', true),
        _buildMemberCard('Айдос', 'Мүше', false),
        _buildMemberCard('Меруерт', 'Мүше', false),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          onPressed: () {},
          icon: const Icon(Icons.add),
          label: const Text('Тағы 1 дос қосу'),
        ),
      ],
    );
  }

  Widget _buildMemberCard(String name, String role, bool isYou) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(child: Text(name[0])),
        title: Text(name + (isYou ? ' (Сен)' : ''), style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(role),
        trailing: isYou ? null : IconButton(icon: const Icon(Icons.remove_circle_outline, color: Colors.red), onPressed: () {}),
      ),
    );
  }
}
