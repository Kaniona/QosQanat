// Достар экраны — іздеу, сұраулар, сыйлықтар

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class FriendsScreen extends ConsumerStatefulWidget {
  const FriendsScreen({super.key});

  @override
  ConsumerState<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends ConsumerState<FriendsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _onSearch() {
    // QQ-ID бойынша іздеу логикасы (Mock API call)
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Іздеу: ${_searchController.text}')),
    );
  }

  void _showGiftDialog(String friendName) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('$friendName-ға сыйлық жіберу'),
        content: const TextField(
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: 'Монеталар саны', border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Болдырмау')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Сыйлық жіберілді! 🎁')));
            },
            child: const Text('Жіберу'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Достар'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Достар'),
            Tab(text: 'Сұраулар'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Достар тізімі
          RefreshIndicator(
            onRefresh: () async {
              await Future.delayed(const Duration(seconds: 1));
            },
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _searchController,
                        decoration: const InputDecoration(
                          hintText: 'QQ-ID бойынша іздеу',
                          prefixIcon: Icon(Icons.search),
                          border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                          contentPadding: EdgeInsets.symmetric(horizontal: 16),
                        ),
                        onSubmitted: (_) => _onSearch(),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filled(onPressed: _onSearch, icon: const Icon(Icons.person_add)),
                  ],
                ),
                const SizedBox(height: 24),
                _buildFriendCard('Айдос', '9-сынып', true),
                _buildFriendCard('Меруерт', '9-сынып', false),
              ],
            ),
          ),
          
          // Сұраулар тізімі
          ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _buildRequestCard('Данияр', '10-сынып'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFriendCard(String name, String grade, bool isOnline) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Stack(
          children: [
            CircleAvatar(child: Text(name[0])),
            if (isOnline)
              Positioned(
                right: 0,
                bottom: 0,
                child: Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)),
                ),
              ),
          ],
        ),
        title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(grade),
        trailing: Wrap(
          spacing: 8,
          children: [
            IconButton(
              icon: const Icon(Icons.card_giftcard, color: Colors.orange),
              onPressed: () => _showGiftDialog(name),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRequestCard(String name, String grade) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(child: Text(name[0])),
        title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(grade),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(icon: const Icon(Icons.check_circle, color: Colors.green), onPressed: () {}),
            IconButton(icon: const Icon(Icons.cancel, color: Colors.red), onPressed: () {}),
          ],
        ),
      ),
    );
  }
}
