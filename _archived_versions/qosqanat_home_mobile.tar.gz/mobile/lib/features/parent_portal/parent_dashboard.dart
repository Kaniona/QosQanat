// lib/features/parent_portal/parent_dashboard.dart

import 'package:flutter/material.dart';
import '../../services/pdf_report_generator.dart';

class ParentDashboard extends StatefulWidget {
  const ParentDashboard({Key? key}) : super(key: key);

  @override
  State<ParentDashboard> createState() => _ParentDashboardState();
}

class _ParentDashboardState extends State<ParentDashboard> {
  bool _isGeneratingPdf = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text('Ата-ана Порталы', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Балаңыздың оқу прогресі', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            
            // Overview Cards
            Row(
              children: [
                Expanded(child: _buildSummaryCard('Бұл аптада', '2500 EXP', Icons.star, Colors.amber)),
                const SizedBox(width: 12),
                Expanded(child: _buildSummaryCard('Оқылған сабақ', '14', Icons.book, Colors.blue)),
              ],
            ),
            
            const SizedBox(height: 30),
            
            // Download PDF Action
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
                ]
              ),
              child: Column(
                children: [
                  const Icon(Icons.picture_as_pdf, size: 48, color: Colors.redAccent),
                  const SizedBox(height: 16),
                  const Text('Апталық есеп', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text(
                    'Балаңыздың күшті және әлсіз тұстары көрсетілген толық PDF есепті жүктеп алыңыз немесе басып шығарыңыз.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _isGeneratingPdf ? null : _handleDownloadPdf,
                      icon: _isGeneratingPdf 
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                        : const Icon(Icons.download),
                      label: Text(_isGeneratingPdf ? 'Дайындалуда...' : 'Жүктеп алу / Бөлісу'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blueAccent,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
        ]
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 32),
          const SizedBox(height: 12),
          Text(title, style: const TextStyle(color: Colors.grey, fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Future<void> _handleDownloadPdf() async {
    setState(() => _isGeneratingPdf = true);
    
    try {
      // 1. API арқылы есеп мәліметтерін алу
      // final data = await api.get('/parent/report/latest');
      
      // 2. Жалған мәліметтер (Симуляция)
      await Future.delayed(const Duration(milliseconds: 800));
      
      // 3. PDF құру
      final pdfBytes = await PdfReportGenerator.generateParentReport(
        studentName: 'Алихан Маратұлы',
        weekDates: '06 Мамыр - 12 Мамыр 2026',
        totalExp: 2500,
        lessonsCompleted: 14,
        bestSubject: 'Математика (Алгебра)',
        weakSubject: 'Қазақ тілі (Синтаксис)',
      );
      
      // 4. Ортақ пайдалану / Көрсету терезесін ашу
      await PdfReportGenerator.printOrShareReport(pdfBytes, 'QosQanat_Report_Alihan.pdf');
      
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Қате пайда болды: $e')),
      );
    } finally {
      setState(() => _isGeneratingPdf = false);
    }
  }
}
