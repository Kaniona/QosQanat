/// Квиз ойнатқышы — таймер, жауап таңдау, жіберу, офлайн кезек

import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/network/api_client.dart';
import '../../core/network/endpoints.dart';
import '../../core/storage/offline_manager.dart';
import '../../data/models/quiz_model.dart';

class QuizPlayerScreen extends StatefulWidget {
  const QuizPlayerScreen({
    required this.apiClient,
    required this.offlineManager,
    required this.quizId,
    super.key,
    this.onQuizComplete,
  });

  final ApiClient apiClient;
  final OfflineManager offlineManager;
  final String quizId;
  final void Function(QuizResultModel? result)? onQuizComplete;

  @override
  State<QuizPlayerScreen> createState() => _QuizPlayerScreenState();
}

class _QuizPlayerScreenState extends State<QuizPlayerScreen> {
  QuizModel? _quiz;
  bool _loading = true;
  String? _error;

  int _currentIndex = 0;
  final Map<String, List<String>> _selectedAnswers = <String, List<String>>{};

  late DateTime _startedAt;
  int _timeRemaining = 0;
  Timer? _timer;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _loadQuiz();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadQuiz() async {
    setState(() { _loading = true; _error = null; });

    try {
      final Map<String, Object?> res = await widget.apiClient.get(
        ContentEndpoints.quiz(widget.quizId),
        authenticated: true,
      );

      final Object? quizData = res['quiz'];
      if (quizData is Map<String, Object?>) {
        final QuizModel? parsed = QuizModel.fromJson(quizData);
        if (parsed != null) {
          await widget.offlineManager.cacheQuiz(parsed);
          _initQuizState(parsed);
          return;
        }
      }
      throw Exception('Квиз деректері қате');
    } on Exception catch (e) {
      final QuizModel? cached = widget.offlineManager.getCachedQuiz(widget.quizId);
      if (cached != null) {
        _initQuizState(cached);
      } else {
        if (mounted) {
          setState(() { _error = e.toString(); _loading = false; });
        }
      }
    }
  }

  void _initQuizState(QuizModel quiz) {
    if (!mounted) return;
    setState(() {
      _quiz = quiz;
      _timeRemaining = quiz.timeLimitSeconds;
      _startedAt = DateTime.now().toUtc();
      _loading = false;
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (Timer timer) {
      if (!mounted) return;
      setState(() {
        if (_timeRemaining > 0) {
          _timeRemaining--;
        } else {
          _timer?.cancel();
          _submitQuiz(); // Уақыт біткенде автоматты түрде жіберу
        }
      });
    });
  }

  void _toggleOption(String questionId, String optionId, bool isMultiple) {
    setState(() {
      final List<String> current = _selectedAnswers[questionId] ?? <String>[];
      if (isMultiple) {
        if (current.contains(optionId)) {
          current.remove(optionId);
        } else {
          current.add(optionId);
        }
        _selectedAnswers[questionId] = current;
      } else {
        _selectedAnswers[questionId] = <String>[optionId];
      }
    });
  }

  Future<void> _submitQuiz() async {
    if (_submitting || _quiz == null) return;

    final Duration duration = DateTime.now().toUtc().difference(_startedAt);
    if (duration.inSeconds < 20) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Квизді тым тез аяқтадыңыз. Кемінде 20 секунд уақыт бөліңіз!')),
      );
      return;
    }

    setState(() { _submitting = true; });
    _timer?.cancel();

    final List<AnswerPayload> answers = <AnswerPayload>[];
    for (final QuestionModel q in _quiz!.questions) {
      answers.add(AnswerPayload(
        questionId: q.id,
        selectedOptionIds: _selectedAnswers[q.id] ?? <String>[],
      ));
    }

    final QuizSubmitPayload payload = QuizSubmitPayload(
      quizId: _quiz!.id,
      answers: answers,
      startedAt: _startedAt.toIso8601String(),
      submittedAt: DateTime.now().toUtc().toIso8601String(),
    );

    try {
      final Map<String, Object?> res = await widget.apiClient.post(
        ProgressEndpoints.submitQuiz,
        payload.toJson(),
        authenticated: true,
      );

      final QuizResultModel? result = QuizResultModel.fromJson(res);
      widget.onQuizComplete?.call(result);
    } on Exception catch (_) {
      // Желі қатесі — офлайн кезекке қосу
      await widget.offlineManager.enqueueSubmission(payload);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Офлайн режим. Нәтижелер кезекке қойылды.')),
        );
        widget.onQuizComplete?.call(null); // Нәтиже белгісіз (синхронды күтеміз)
      }
    } finally {
      if (mounted) setState(() { _submitting = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_error != null) {
      return Scaffold(body: Center(child: Text(_error!)));
    }
    final QuizModel? quiz = _quiz;
    if (quiz == null) return const SizedBox.shrink();

    final QuestionModel question = quiz.questions[_currentIndex];
    final List<String> selected = _selectedAnswers[question.id] ?? <String>[];
    final bool isMultiple = question.kind == 'MULTIPLE';

    return Scaffold(
      appBar: AppBar(
        title: Text('${_currentIndex + 1} / ${quiz.questions.length}'),
        centerTitle: true,
        actions: <Widget>[
          Center(
            child: Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Text(
                '${(_timeRemaining ~/ 60).toString().padLeft(2, '0')}:${(_timeRemaining % 60).toString().padLeft(2, '0')}',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
            ),
          ),
        ],
      ),
      body: _submitting
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    question.textKk,
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  const SizedBox(height: 32),
                  ...question.options.map((OptionModel option) {
                    final bool isSelected = selected.contains(option.id);
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: InkWell(
                        onTap: () => _toggleOption(question.id, option.id, isMultiple),
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: isSelected ? const Color(0xFF1A6FBF) : Colors.grey.shade300,
                              width: 2,
                            ),
                            borderRadius: BorderRadius.circular(12),
                            color: isSelected ? const Color(0xFF1A6FBF).withOpacity(0.1) : null,
                          ),
                          child: Row(
                            children: <Widget>[
                              Icon(
                                isMultiple
                                    ? (isSelected ? Icons.check_box : Icons.check_box_outline_blank)
                                    : (isSelected ? Icons.radio_button_checked : Icons.radio_button_unchecked),
                                color: isSelected ? const Color(0xFF1A6FBF) : Colors.grey,
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Text(option.textKk, style: const TextStyle(fontSize: 16)),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
                  const Spacer(),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: selected.isEmpty
                          ? null
                          : () {
                              if (_currentIndex < quiz.questions.length - 1) {
                                setState(() { _currentIndex++; });
                              } else {
                                _submitQuiz();
                              }
                            },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1A6FBF),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      child: Text(
                        _currentIndex < quiz.questions.length - 1 ? 'Келесі сұрақ' : 'Аяқтау',
                        style: const TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
