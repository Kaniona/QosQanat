// lib/features/shop/item_preview.dart

import 'package:flutter/material.dart';

class ItemPreviewModal extends StatelessWidget {
  final Map<String, dynamic> item;
  final int userCoins;

  const ItemPreviewModal({Key? key, required this.item, required this.userCoins}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final canAfford = userCoins >= (item['price'] as num);

    return Container(
      height: MediaQuery.of(context).size.height * 0.7,
      decoration: const BoxDecoration(
        color: Color(0xFF1E1E1E),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        children: [
          const SizedBox(height: 16),
          Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[700], borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 24),
          
          Text(item['name'] as String, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
          Text(item['rarity'] as String, style: TextStyle(color: _getRarityColor(item['rarity'] as String), fontWeight: FontWeight.w600)),
          
          const SizedBox(height: 32),
          
          // Avatar Preview Area (Жалған)
          Container(
            height: 200,
            width: 200,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.3),
              shape: BoxShape.circle,
            ),
            child: const Stack(
              alignment: Alignment.center,
              children: [
                Icon(Icons.person, size: 120, color: Colors.grey),
                Positioned(
                  top: 20,
                  child: Icon(Icons.checkroom, size: 60, color: Colors.amber), // Item overlay
                )
              ],
            ),
          ),
          
          const Spacer(),
          
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.monetization_on, color: Colors.amber, size: 32),
                    const SizedBox(width: 8),
                    Text('${item['price']}', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                  ],
                ),
                ElevatedButton(
                  onPressed: canAfford ? () => _buyItem(context) : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.amber,
                    disabledBackgroundColor: Colors.grey[800],
                    padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('САТЫП АЛУ', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _buyItem(BuildContext context) {
    // API Call: POST /shop/buy
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${item['name']} сәтті сатып алынды!'),
        backgroundColor: Colors.green,
      ),
    );
  }

  Color _getRarityColor(String rarity) {
    switch (rarity) {
      case 'COMMON': return Colors.grey;
      case 'RARE': return Colors.blue;
      case 'EPIC': return Colors.purple;
      case 'LEGENDARY': return Colors.orange;
      default: return Colors.grey;
    }
  }
}
