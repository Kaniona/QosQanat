// lib/features/shop/shop_grid.dart

import 'package:flutter/material.dart';
import 'item_preview.dart';

class ShopGrid extends StatefulWidget {
  const ShopGrid({Key? key}) : super(key: key);

  @override
  State<ShopGrid> createState() => _ShopGridState();
}

class _ShopGridState extends State<ShopGrid> {
  String _selectedCategory = 'ALL';
  int _userCoins = 1500; // Жалған мәлімет, API-ден келеді

  final List<String> categories = ['ALL', 'HAT', 'SHIRT', 'ACCESSORY', 'PET'];

  // Жалған заттар тізімі (API-ден келеді)
  final List<Map<String, dynamic>> _items = [
    {'id': '1', 'name': 'Қызыл Кепка', 'category': 'HAT', 'price': 500, 'rarity': 'COMMON', 'image': 'assets/shop/red_cap.png'},
    {'id': '2', 'name': 'Алтын Сағат', 'category': 'ACCESSORY', 'price': 2000, 'rarity': 'EPIC', 'image': 'assets/shop/gold_watch.png'},
    {'id': '3', 'name': 'Ғарышкер Скафандры', 'category': 'SHIRT', 'price': 1200, 'rarity': 'RARE', 'image': 'assets/shop/space_suit.png'},
    {'id': '4', 'name': 'Кішкентай Айдаһар', 'category': 'PET', 'price': 5000, 'rarity': 'EPIC', 'image': 'assets/shop/dragon_pet.png'},
  ];

  @override
  Widget build(BuildContext context) {
    final filteredItems = _selectedCategory == 'ALL' 
      ? _items 
      : _items.where((i) => i['category'] == _selectedCategory).toList();

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text('Дүкен'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                const Icon(Icons.monetization_on, color: Colors.amber),
                const SizedBox(width: 8),
                Text('$_userCoins', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              ],
            ),
          )
        ],
      ),
      body: Column(
        children: [
          _buildCategoryFilters(),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16.0),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 0.8,
              ),
              itemCount: filteredItems.length,
              itemBuilder: (context, index) {
                return _buildShopItemCard(filteredItems[index]);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryFilters() {
    return SizedBox(
      height: 50,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final cat = categories[index];
          final isSelected = cat == _selectedCategory;
          return Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: ChoiceChip(
              label: Text(cat, style: TextStyle(color: isSelected ? Colors.black : Colors.white)),
              selected: isSelected,
              selectedColor: Colors.amber,
              backgroundColor: const Color(0xFF1E1E1E),
              onSelected: (selected) {
                if (selected) setState(() => _selectedCategory = cat);
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildShopItemCard(Map<String, dynamic> item) {
    final canAfford = _userCoins >= (item['price'] as num);
    final rarityColor = _getRarityColor(item['rarity'] as String);

    return GestureDetector(
      onTap: () => _showItemPreview(item),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E1E),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: rarityColor.withOpacity(0.5), width: 2),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Center(
                // Placeholder for actual image
                child: Icon(Icons.checkroom, size: 64, color: canAfford ? Colors.white : Colors.grey),
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.5),
                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(14)),
              ),
              child: Column(
                children: [
                  Text(
                    item['name'] as String,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: canAfford ? Colors.white : Colors.grey,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.monetization_on, size: 16, color: canAfford ? Colors.amber : Colors.grey),
                      const SizedBox(width: 4),
                      Text(
                        '${item['price']}',
                        style: TextStyle(
                          color: canAfford ? Colors.amber : Colors.grey,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getRarityColor(String rarity) {
    switch (rarity) {
      case 'COMMON': return Colors.grey;
      case 'RARE': return Colors.blue;
      case 'EPIC': return Colors.purple;
      case 'LEGENDARY': return Colors.orange;
      default: return Colors.grey;
    }
  }

  void _showItemPreview(Map<String, dynamic> item) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => ItemPreviewModal(item: item, userCoins: _userCoins),
    );
  }
}
