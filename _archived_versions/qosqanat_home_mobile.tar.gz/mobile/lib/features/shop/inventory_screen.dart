// lib/features/shop/inventory_screen.dart

import 'package:flutter/material.dart';

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({Key? key}) : super(key: key);

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  // Жалған мәлімет
  final List<Map<String, dynamic>> _inventory = [
    {'id': 'inv1', 'item_id': '1', 'name': 'Қызыл Кепка', 'is_equipped': true},
    {'id': 'inv2', 'item_id': '2', 'name': 'Алтын Сағат', 'is_equipped': false},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text('Менің Инвентарім'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16.0),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
        ),
        itemCount: _inventory.length,
        itemBuilder: (context, index) {
          final invItem = _inventory[index];
          final bool isEquipped = invItem['is_equipped'] as bool;

          return GestureDetector(
            onTap: () => _toggleEquip(index),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E1E),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isEquipped ? Colors.green : Colors.grey[800]!,
                  width: isEquipped ? 2 : 1,
                ),
              ),
              child: Stack(
                children: [
                  const Center(child: Icon(Icons.checkroom, color: Colors.white, size: 48)),
                  if (isEquipped)
                    const Positioned(
                      top: 4,
                      right: 4,
                      child: Icon(Icons.check_circle, color: Colors.green, size: 20),
                    ),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      color: Colors.black54,
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Text(
                        invItem['name'] as String,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white, fontSize: 10),
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void _toggleEquip(int index) {
    // API Call: PUT /inventory/equip
    setState(() {
      _inventory[index]['is_equipped'] = !(_inventory[index]['is_equipped'] as bool);
    });
  }
}
