// Батл ойнау экраны — синхронды таймер, сұрақтар, қарсылас статусы

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:async';

class BattlePlayScreen extends ConsumerStatefulWidget {
  const BattlePlayScreen({super.key});

  @override
  ConsumerState<BattlePlayScreen> createState() => _BattlePlayScreenState();
}

class _BattlePlayScreenState extends ConsumerState<BattlePlayScreen> {
  int _myScore = 0;
  int _opponentScore = 0;
  bool _opponentAnswered = false;
  String? _selectedOption;
  bool _isAnswerCorrect = false;
  
  // Timer sync
  int _remainingMs = 20000;
  Timer? _localTimer;

  @override
  void initState() {
    super.initState();
    _startLocalTimer();
  }

  @override
  void dispose() {
    _localTimer?.cancel();
    super.dispose();
  }

  void _startLocalTimer() {
    _localTimer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (_remainingMs > 0) {
        setState(() {
          _remainingMs -= 100;
        });
      }
    });
  }

  void _onSelectOption(String option) {
    if (_selectedOption != null) return;
    
    setState(() {
      _selectedOption = option;
      _isAnswerCorrect = option == 'A'; // Мок: A әрқашан дұрыс
      
      if (_isAnswerCorrect) {
        _myScore += 100 + (_remainingMs ~/ 1000) * 5; // Уақыт бонусы
      }
    });

    // Қарсылас та жауап берді деп елестетейік 2 секундтан соң
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _opponentAnswered = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    final double progress = (_remainingMs / 20000).clamp(0.0, 1.0);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Раунд 1/10'),
        centerTitle: true,
        automaticallyImplyLeading: false, // Шығуды бұғаттау
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Score Board
            Container(
              padding: const EdgeInsets.all(16),
              color: Theme.of(context).colorScheme.surfaceContainerHighest,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildScoreCard('Сен', _myScore, Colors.blue),
                  const Text('VS', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
                  _buildScoreCard('Данияр', _opponentScore, Colors.red, _opponentAnswered),
                ],
              ),
            ),

            // Timer Bar
            LinearProgressIndicator(
              value: progress,
              color: progress > 0.25 ? Colors.green : Colors.red,
              minHeight: 8,
            ),
            
            const SizedBox(height: 32),

            // Сұрақ
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                'Екінші дүниежүзілік соғыс қай жылы басталды?',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ),
            
            const Spacer(),

            // Опциялар
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  _buildOptionBtn('A', '1939'),
                  const SizedBox(height: 12),
                  _buildOptionBtn('B', '1941'),
                  const SizedBox(height: 12),
                  _buildOptionBtn('C', '1945'),
                  const SizedBox(height: 12),
                  _buildOptionBtn('D', '1938'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScoreCard(String name, int score, Color color, [bool hasAnswered = false]) {
    return Column(
      children: [
        Row(
          children: [
            Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            if (hasAnswered) ...[
              const SizedBox(width: 4),
              const Icon(Icons.check_circle, size: 16, color: Colors.green),
            ]
          ],
        ),
        Text(score.toString(), style: TextStyle(color: color, fontSize: 24, fontWeight: FontWeight.w900)),
      ],
    );
  }

  Widget _buildOptionBtn(String id, String text) {
    final isSelected = _selectedOption == id;
    Color bgColor = Theme.of(context).colorScheme.surface;
    Color textColor = Theme.of(context).colorScheme.onSurface;

    if (_selectedOption != null) {
      if (id == 'A') { // Мок: A әрқашан дұрыс
        bgColor = Colors.green;
        textColor = Colors.white;
      } else if (isSelected) {
        bgColor = Colors.red;
        textColor = Colors.white;
      }
    }

    return InkWell(
      onTap: () => _onSelectOption(id),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        decoration: BoxDecoration(
          color: bgColor,
          border: Border.all(color: Colors.grey.shade300),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(text, style: TextStyle(fontSize: 18, color: textColor, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
