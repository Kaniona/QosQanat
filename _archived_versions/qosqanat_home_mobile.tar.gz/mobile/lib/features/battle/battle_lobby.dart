// Батл лобби — кезекке тұру, қарсылас күту, дайындық

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class BattleLobby extends ConsumerStatefulWidget {
  const BattleLobby({super.key});

  @override
  ConsumerState<BattleLobby> createState() => _BattleLobbyState();
}

class _BattleLobbyState extends ConsumerState<BattleLobby> with SingleTickerProviderStateMixin {
  bool _isSearching = false;
  bool _opponentFound = false;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(vsync: this, duration: const Duration(seconds: 1));
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  void _startSearch() {
    setState(() {
      _isSearching = true;
      _opponentFound = false;
    });
    _pulseController.repeat(reverse: true);

    // Мок: 3 секундтан кейін қарсылас табылады
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _isSearching = false;
          _opponentFound = true;
        });
        _pulseController.stop();
      }
    });
  }

  void _onReady() {
    // Дайын екенін растау -> ойынға өту
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Батл басталады!')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Aqyl Battle')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (!_isSearching && !_opponentFound) ...[
                const Icon(Icons.bolt, size: 80, color: Colors.orange),
                const SizedBox(height: 24),
                const Text('Қарсыласпен білім сынасыңыз!', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 32),
                ElevatedButton(
                  onPressed: _startSearch,
                  style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 60)),
                  child: const Text('Матч іздеу', style: TextStyle(fontSize: 18)),
                ),
              ] else if (_isSearching) ...[
                ScaleTransition(
                  scale: Tween(begin: 1.0, end: 1.2).animate(_pulseController),
                  child: const Icon(Icons.search, size: 80, color: Colors.blue),
                ),
                const SizedBox(height: 24),
                const Text('Қарсылас ізделуде...', style: TextStyle(fontSize: 18)),
                const SizedBox(height: 16),
                const CircularProgressIndicator(),
              ] else if (_opponentFound) ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildPlayer('Сен', '9-сынып'),
                    const Text('VS', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.red)),
                    _buildPlayer('Данияр', '9-сынып'),
                  ],
                ),
                const SizedBox(height: 48),
                ElevatedButton(
                  onPressed: _onReady,
                  style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 60), backgroundColor: Colors.green),
                  child: const Text('ДАЙЫНМЫН!', style: TextStyle(fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPlayer(String name, String grade) {
    return Column(
      children: [
        CircleAvatar(radius: 40, child: Text(name[0], style: const TextStyle(fontSize: 32))),
        const SizedBox(height: 8),
        Text(name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Text(grade),
      ],
    );
  }
}
