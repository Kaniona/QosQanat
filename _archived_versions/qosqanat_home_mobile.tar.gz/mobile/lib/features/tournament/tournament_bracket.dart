// lib/features/tournament/tournament_bracket.dart

import 'package:flutter/material.dart';

class TournamentBracket extends StatelessWidget {
  const TournamentBracket({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text('Турнир Сеткасы (1/4 Финал)'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildRound(8, '1/4 Финал'), // 8 ойыншы (4 матч)
                _buildConnectorColumn(4),
                _buildRound(4, 'Жартылай финал'), // 4 ойыншы (2 матч)
                _buildConnectorColumn(2),
                _buildRound(2, 'Финал'), // 2 ойыншы (1 матч)
                _buildConnectorColumn(1),
                _buildWinner(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRound(int playerCount, String title) {
    int matchCount = playerCount ~/ 2;
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Text(title, style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        for (int i = 0; i < matchCount; i++)
          Padding(
            padding: EdgeInsets.symmetric(vertical: (30.0 * (8 / playerCount))),
            child: _buildMatchCard('Ойыншы ${i * 2 + 1}', 'Ойыншы ${i * 2 + 2}'),
          ),
      ],
    );
  }

  Widget _buildMatchCard(String p1, String p2) {
    return Container(
      width: 150,
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(8.0),
        border: Border.all(color: Colors.grey[800]!),
      ),
      child: Column(
        children: [
          _buildPlayerRow(p1, true),
          const Divider(height: 1, color: Colors.grey),
          _buildPlayerRow(p2, false),
        ],
      ),
    );
  }

  Widget _buildPlayerRow(String name, bool isWinner) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(name, style: TextStyle(color: isWinner ? Colors.white : Colors.grey)),
          if (isWinner) const Icon(Icons.check, color: Colors.green, size: 16),
        ],
      ),
    );
  }

  Widget _buildConnectorColumn(int matchCount) {
    return SizedBox(
      width: 40,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          const SizedBox(height: 40),
          for (int i = 0; i < matchCount; i++)
            Padding(
              padding: EdgeInsets.symmetric(vertical: (40.0 * (4 / matchCount))),
              child: const Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
            ),
        ],
      ),
    );
  }

  Widget _buildWinner() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text('Жеңімпаз', style: TextStyle(color: Colors.amber, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        Container(
          width: 150,
          padding: const EdgeInsets.all(12.0),
          decoration: BoxDecoration(
            color: Colors.amber.withOpacity(0.2),
            borderRadius: BorderRadius.circular(8.0),
            border: Border.all(color: Colors.amber),
          ),
          child: const Center(
            child: Text('Ойыншы 1', style: TextStyle(color: Colors.amber, fontWeight: FontWeight.bold)),
          ),
        ),
      ],
    );
  }
}
