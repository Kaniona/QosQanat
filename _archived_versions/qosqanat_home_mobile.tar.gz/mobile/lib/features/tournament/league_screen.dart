// lib/features/tournament/league_screen.dart

import 'package:flutter/material.dart';

class LeagueScreen extends StatefulWidget {
  const LeagueScreen({Key? key}) : super(key: key);

  @override
  State<LeagueScreen> createState() => _LeagueScreenState();
}

class _LeagueScreenState extends State<LeagueScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  final Map<String, Color> leagueColors = {
    'BRONZE': const Color(0xFFCD7F32),
    'SILVER': const Color(0xFFC0C0C0),
    'GOLD': const Color(0xFFFFD700),
    'PLATINUM': const Color(0xFFE5E4E2),
    'DIAMOND': const Color(0xFFB9F2FF),
    'LEGEND': const Color(0xFFFF4500),
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text('Лигалар және Рейтинг'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          indicatorColor: Colors.amber,
          tabs: const [
            Tab(text: 'Глобал'),
            Tab(text: 'Аймақ'),
            Tab(text: 'Сынып'),
            Tab(text: 'Достар'),
          ],
        ),
      ),
      body: Column(
        children: [
          _buildMyLeagueCard(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildLeaderboardList('global'),
                _buildLeaderboardList('region'),
                _buildLeaderboardList('grade'),
                _buildLeaderboardList('friends'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMyLeagueCard() {
    // Жалған мәліметтер, нақты реализацияда Riverpod/Provider арқылы алынады
    const currentLeague = 'GOLD';
    const rating = 1650;
    const nextLeague = 'PLATINUM';
    const needed = 150;

    return Container(
      margin: const EdgeInsets.all(16.0),
      padding: const EdgeInsets.all(20.0),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [leagueColors[currentLeague]!.withOpacity(0.8), const Color(0xFF1E1E1E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: leagueColors[currentLeague]!.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Сіздің лигаңыз:',
                    style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 14),
                  ),
                  Text(
                    currentLeague,
                    style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const Icon(Icons.emoji_events, color: Colors.white, size: 48),
            ],
          ),
          const SizedBox(height: 20),
          LinearProgressIndicator(
            value: 0.65, // rating / (rating + needed)
            backgroundColor: Colors.white.withOpacity(0.2),
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('$rating ұпай', style: const TextStyle(color: Colors.white70)),
              Text('$nextLeague лигасына $needed ұпай қалды', style: const TextStyle(color: Colors.white70)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLeaderboardList(String scope) {
    // Жалған тізім, нақтыда API-ден алынады: GET /league/leaderboard/:scope
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: 20,
      itemBuilder: (context, index) {
        final rank = index + 1;
        return ListTile(
          leading: CircleAvatar(
            backgroundColor: rank <= 3 ? Colors.amber : Colors.grey[800],
            child: Text(
              '$rank',
              style: TextStyle(color: rank <= 3 ? Colors.black : Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
          title: Text('Ойыншы $rank', style: const TextStyle(color: Colors.white)),
          trailing: Text('${2000 - (index * 20)} 🏆', style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold)),
        );
      },
    );
  }
}
