import 'package:flutter/material.dart';

import '../../core/network/api_client.dart';

class OtpScreen extends StatefulWidget {
  const OtpScreen({
    required this.apiClient,
    required this.phone,
    required this.password,
    required this.name,
    required this.grade,
    required this.region,
    required this.birthDateIso,
    this.debugOtp,
    super.key,
  });

  final ApiClient apiClient;
  final String phone;
  final String password;
  final String name;
  final int grade;
  final String region;
  final String birthDateIso;
  final String? debugOtp;

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late final TextEditingController _otpController;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _otpController = TextEditingController(text: widget.debugOtp ?? '');
  }

  @override
  void dispose() {
    _otpController.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() => _loading = true);
    try {
      final Map<String, Object?> payload = await widget.apiClient.post(
        '/auth/verify-otp',
        <String, Object?>{
          'phone': widget.phone,
          'otp': _otpController.text.trim(),
          'password': widget.password,
          'name': widget.name,
          'grade': widget.grade,
          'region': widget.region,
          'birthDate': widget.birthDateIso,
        },
      );
      await widget.apiClient.saveAuthPayload(payload);
      if (!mounted) {
        return;
      }
      final NavigatorState navigator = Navigator.of(context);
      while (navigator.canPop()) {
        navigator.pop();
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Тіркелу аяқталды')),
      );
    } on Exception catch (error) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('OTP')),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Text(
                      widget.phone,
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _otpController,
                      decoration: const InputDecoration(labelText: '6 таңбалы код'),
                      keyboardType: TextInputType.number,
                      maxLength: 6,
                      validator: (String? value) {
                        if (value == null || !RegExp(r'^\d{6}$').hasMatch(value)) {
                          return '6 цифр енгізіңіз';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: _loading ? null : () {
                        _verify();
                      },
                      child: Text(_loading ? 'Тексеру...' : 'Растау'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
