import 'package:flutter/material.dart';

import '../../core/network/api_client.dart';
import 'otp_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({
    required this.apiClient,
    super.key,
  });

  final ApiClient apiClient;

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _regionController = TextEditingController();
  final TextEditingController _birthDateController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  int _grade = 1;
  bool _loading = false;

  @override
  void dispose() {
    _phoneController.dispose();
    _nameController.dispose();
    _regionController.dispose();
    _birthDateController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _sendOtp() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    setState(() => _loading = true);
    try {
      final Map<String, Object?> payload = await widget.apiClient.post(
        '/auth/send-otp',
        <String, Object?>{
          'phone': _phoneController.text.trim(),
          'purpose': 'REGISTER',
        },
      );
      if (!mounted) {
        return;
      }
      final Object? debugOtp = payload['debugOtp'];
      await Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (_) => OtpScreen(
            apiClient: widget.apiClient,
            phone: _phoneController.text.trim(),
            password: _passwordController.text,
            name: _nameController.text.trim(),
            grade: _grade,
            region: _regionController.text.trim(),
            birthDateIso: '${_birthDateController.text.trim()}T00:00:00.000Z',
            debugOtp: debugOtp is String ? debugOtp : null,
          ),
        ),
      );
    } on Exception catch (error) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Тіркелу')),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    TextFormField(
                      controller: _phoneController,
                      decoration: const InputDecoration(labelText: 'Телефон'),
                      keyboardType: TextInputType.phone,
                      validator: _required,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _nameController,
                      decoration: const InputDecoration(labelText: 'Аты'),
                      validator: _required,
                    ),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<int>(
                      value: _grade,
                      decoration: const InputDecoration(labelText: 'Сынып'),
                      items: List<DropdownMenuItem<int>>.generate(
                        11,
                        (int index) => DropdownMenuItem<int>(
                          value: index + 1,
                          child: Text('${index + 1}'),
                        ),
                      ),
                      onChanged: (int? value) {
                        if (value != null) {
                          setState(() => _grade = value);
                        }
                      },
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _regionController,
                      decoration: const InputDecoration(labelText: 'Өңір'),
                      validator: _required,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _birthDateController,
                      decoration: const InputDecoration(labelText: 'Туған күні: YYYY-MM-DD'),
                      keyboardType: TextInputType.datetime,
                      validator: (String? value) {
                        if (value == null || !RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(value)) {
                          return 'YYYY-MM-DD';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _passwordController,
                      decoration: const InputDecoration(labelText: 'Құпиясөз'),
                      obscureText: true,
                      validator: (String? value) {
                        if (value == null || value.length < 8) {
                          return 'Кемінде 8 таңба';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 24),
                    FilledButton(
                      onPressed: _loading ? null : () {
                        _sendOtp();
                      },
                      child: Text(_loading ? 'Күтіңіз...' : 'OTP жіберу'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  String? _required(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Міндетті өріс';
    }
    return null;
  }
}
