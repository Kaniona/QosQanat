import 'package:flutter/material.dart';

import '../../core/network/api_client.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({
    required this.apiClient,
    super.key,
  });

  final ApiClient apiClient;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _identifierController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _loading = false;

  @override
  void dispose() {
    _identifierController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    setState(() => _loading = true);
    try {
      final Map<String, Object?> payload = await widget.apiClient.post(
        '/auth/login',
        <String, Object?>{
          'identifier': _identifierController.text.trim(),
          'password': _passwordController.text,
        },
      );
      await widget.apiClient.saveAuthPayload(payload);
      if (!mounted) {
        return;
      }
      final String qqId = widget.apiClient.localCache.readProfile()?.qqId ?? '';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Кіру сәтті: $qqId')),
      );
    } on Exception catch (error) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  void _openRegister() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => RegisterScreen(apiClient: widget.apiClient),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Text(
                      'QosQanat',
                      style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                            fontWeight: FontWeight.w800,
                            color: const Color(0xFF1A6FBF),
                          ),
                    ),
                    const SizedBox(height: 24),
                    TextFormField(
                      controller: _identifierController,
                      decoration: const InputDecoration(labelText: 'QQ-ID немесе телефон'),
                      textInputAction: TextInputAction.next,
                      validator: (String? value) {
                        if (value == null || value.trim().length < 3) {
                          return 'Идентификаторды енгізіңіз';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _passwordController,
                      decoration: const InputDecoration(labelText: 'Құпиясөз'),
                      obscureText: true,
                      onFieldSubmitted: (_) {
                        _login();
                      },
                      validator: (String? value) {
                        if (value == null || value.length < 8) {
                          return 'Кемінде 8 таңба';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 24),
                    FilledButton(
                      onPressed: _loading ? null : () {
                        _login();
                      },
                      child: Text(_loading ? 'Күтіңіз...' : 'Кіру'),
                    ),
                    TextButton(
                      onPressed: _loading ? null : _openRegister,
                      child: const Text('Тіркелу'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
