// Эмоция контроллері — аватардың күй машинасы
// idle → encouraging → concerned → celebrating
// Riverpod StateNotifier арқылы басқарылады

import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Аватар эмоция күйлері
enum EmotionState {
  /// Әдепкі тыныш күй
  idle,

  /// Ынталандыру — серия ≥3, сәлемдесу
  encouraging,

  /// Алаңдау — көп қателер, мотивация сұрау
  concerned,

  /// Тойлау — серия ≥7, жоғары балл
  celebrating,
}

/// Эмоция контроллері — бэкенд жауабымен синхрондалады
class EmotionController extends StateNotifier<EmotionState> {
  EmotionController() : super(EmotionState.idle);

  Timer? _idleTimer;

  /// Бос тұру таймерінің ұзақтығы — 10 секунд
  static const _idleTimeout = Duration(seconds: 10);

  /// Бэкенд жауабынан эмоция күйін жаңарту
  void onResponse(String emotionName) {
    final newState = _parseEmotion(emotionName);
    state = newState;
    _resetIdleTimer();
  }

  /// Прогресс оқиғасы бойынша эмоция ауысу
  void onProgressEvent({
    required int streak,
    required int mistakeCount,
    required bool quizCompleted,
    int? quizScore,
  }) {
    if (quizCompleted && (quizScore ?? 0) >= 90) {
      state = EmotionState.celebrating;
    } else if (streak >= 7) {
      state = EmotionState.celebrating;
    } else if (streak >= 3) {
      state = EmotionState.encouraging;
    } else if (mistakeCount >= 3) {
      state = EmotionState.concerned;
    } else {
      state = EmotionState.encouraging;
    }
    _resetIdleTimer();
  }

  /// Тікелей күйді орнату
  void setEmotion(EmotionState newState) {
    state = newState;
    _resetIdleTimer();
  }

  /// 10 секунд бос тұрса — idle күйге қайту
  void _resetIdleTimer() {
    _idleTimer?.cancel();
    _idleTimer = Timer(_idleTimeout, () {
      if (mounted) {
        state = EmotionState.idle;
      }
    });
  }

  /// Мәтіннен EmotionState-ке конвертация
  EmotionState _parseEmotion(String name) {
    switch (name) {
      case 'encouraging':
        return EmotionState.encouraging;
      case 'concerned':
        return EmotionState.concerned;
      case 'celebrating':
        return EmotionState.celebrating;
      default:
        return EmotionState.idle;
    }
  }

  @override
  void dispose() {
    _idleTimer?.cancel();
    super.dispose();
  }
}

/// Riverpod провайдер — эмоция контроллері
final emotionProvider =
    StateNotifierProvider<EmotionController, EmotionState>((ref) {
  return EmotionController();
});
