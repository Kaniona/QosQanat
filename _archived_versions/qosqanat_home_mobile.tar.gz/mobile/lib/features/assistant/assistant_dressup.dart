// lib/features/assistant/assistant_dressup.dart

import 'package:flutter/material.dart';

class AssistantDressupRenderer extends StatelessWidget {
  final Map<String, String?> equippedItems; // {'HAT': 'url', 'SHIRT': 'url'}

  const AssistantDressupRenderer({Key? key, required this.equippedItems}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 300,
      width: 300,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Base Avatar
          Image.asset('assets/assistant/base_avatar.png', errorBuilder: (context, error, stackTrace) => const Icon(Icons.person, size: 200, color: Colors.grey)),
          
          // Equipped Shirt
          if (equippedItems['SHIRT'] != null)
            Image.network(equippedItems['SHIRT']!, errorBuilder: (c,e,s) => const SizedBox()),

          // Equipped Hat
          if (equippedItems['HAT'] != null)
            Positioned(
              top: 20,
              child: Image.network(equippedItems['HAT']!, errorBuilder: (c,e,s) => const Icon(Icons.checkroom, color: Colors.amber, size: 60)),
            ),

          // Equipped Accessory
          if (equippedItems['ACCESSORY'] != null)
            Image.network(equippedItems['ACCESSORY']!, errorBuilder: (c,e,s) => const SizedBox()),
            
          // Equipped Pet
          if (equippedItems['PET'] != null)
            Positioned(
              bottom: 0,
              right: 0,
              child: Image.network(equippedItems['PET']!, height: 80, errorBuilder: (c,e,s) => const Icon(Icons.pets, color: Colors.orange)),
            ),
        ],
      ),
    );
  }
}
