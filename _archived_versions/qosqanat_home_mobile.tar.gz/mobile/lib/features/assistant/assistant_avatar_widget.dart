// Ассистент аватар виджеті — эмоцияға реакция беретін анимациялы аватар
// EmotionState бойынша түс, иконка, анимация өзгереді

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'emotion_controller.dart';

/// Аватар виджеті — эмоция күйіне байланысты анимация жасайды
class AssistantAvatarWidget extends ConsumerStatefulWidget {
  const AssistantAvatarWidget({
    this.size = 80.0,
    this.isSpeaking = false,
    super.key,
  });

  /// Аватар өлшемі
  final double size;

  /// TTS сөйлеп жатыр ма?
  final bool isSpeaking;

  @override
  ConsumerState<AssistantAvatarWidget> createState() =>
      _AssistantAvatarWidgetState();
}

class _AssistantAvatarWidgetState extends ConsumerState<AssistantAvatarWidget>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseController;
  late final Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void didUpdateWidget(covariant AssistantAvatarWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isSpeaking && !_pulseController.isAnimating) {
      _pulseController.repeat(reverse: true);
    } else if (!widget.isSpeaking && _pulseController.isAnimating) {
      _pulseController.stop();
      _pulseController.reset();
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final emotion = ref.watch(emotionProvider);
    final config = _emotionConfig(emotion);

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 400),
      transitionBuilder: (child, animation) => ScaleTransition(
        scale: animation,
        child: child,
      ),
      child: ScaleTransition(
        key: ValueKey(emotion),
        scale: _pulseAnimation,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeOutCubic,
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: config.gradientColors,
            ),
            boxShadow: [
              BoxShadow(
                color: config.gradientColors.first.withValues(alpha: 0.3),
                blurRadius: 16,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Center(
            child: Text(
              config.emoji,
              style: TextStyle(fontSize: widget.size * 0.45),
            ),
          ),
        ),
      ),
    );
  }

  /// Эмоция күйіне сәйкес конфигурация
  _EmotionConfig _emotionConfig(EmotionState emotion) {
    switch (emotion) {
      case EmotionState.idle:
        return _EmotionConfig(
          emoji: '📚',
          gradientColors: const [Color(0xFF1A6FBF), Color(0xFF2196F3)],
        );
      case EmotionState.encouraging:
        return _EmotionConfig(
          emoji: '💪',
          gradientColors: const [Color(0xFF2E7D32), Color(0xFF66BB6A)],
        );
      case EmotionState.concerned:
        return _EmotionConfig(
          emoji: '🤔',
          gradientColors: const [Color(0xFFF57F17), Color(0xFFFFCA28)],
        );
      case EmotionState.celebrating:
        return _EmotionConfig(
          emoji: '🎉',
          gradientColors: const [Color(0xFFD4A017), Color(0xFFFFD54F)],
        );
    }
  }
}

/// Эмоция конфигурациясы — emoji + түстер
class _EmotionConfig {
  const _EmotionConfig({
    required this.emoji,
    required this.gradientColors,
  });

  final String emoji;
  final List<Color> gradientColors;
}
