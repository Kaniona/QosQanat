// Ассистент чат экраны — толық чат UI
// Хабарлама тізімі, теру эффектісі, TTS, жылдам әрекет чиптері

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../services/assistant_local_service.dart';
import '../../services/local_tts_engine.dart';
import 'assistant_avatar_widget.dart';
import 'emotion_controller.dart';

/// Чат хабарламасы моделі
class ChatMessage {
  const ChatMessage({
    required this.text,
    required this.isUser,
    this.isTyping = false,
    this.followUp,
  });

  final String text;
  final bool isUser;
  final bool isTyping;
  final String? followUp;
}

/// Чат күйі провайдері
final chatMessagesProvider =
    StateNotifierProvider<ChatMessagesNotifier, List<ChatMessage>>((ref) {
  return ChatMessagesNotifier();
});

/// Чат хабарламалар листінің контроллері
class ChatMessagesNotifier extends StateNotifier<List<ChatMessage>> {
  ChatMessagesNotifier() : super([]);

  /// Хабарлама қосу
  void addMessage(ChatMessage message) {
    state = [...state, message];
  }

  /// Соңғы хабарламаны жаңарту (теру эффектісі аяқталғанда)
  void updateLast(ChatMessage message) {
    if (state.isEmpty) return;
    state = [...state.sublist(0, state.length - 1), message];
  }

  /// Тазарту
  void clear() {
    state = [];
  }
}

/// Ассистент чат экраны
class AssistantChatScreen extends ConsumerStatefulWidget {
  const AssistantChatScreen({
    required this.assistantService,
    this.ttsEngine,
    super.key,
  });

  final AssistantLocalService assistantService;
  final LocalTtsEngine? ttsEngine;

  @override
  ConsumerState<AssistantChatScreen> createState() => _AssistantChatScreenState();
}

class _AssistantChatScreenState extends ConsumerState<AssistantChatScreen> {
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _isSending = false;
  bool _isSpeaking = false;
  String _currentLanguage = 'kk';
  Timer? _typingTimer;

  @override
  void initState() {
    super.initState();
    // Сәлемдесу хабарламасы
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(chatMessagesProvider.notifier).addMessage(
        const ChatMessage(
          text: 'Сәлем! Мен — QosQanat көмекшісімін. Саған қалай көмектесе аламын? 📚',
          isUser: false,
        ),
      );
    });
  }

  @override
  void dispose() {
    _textController.dispose();
    _scrollController.dispose();
    _typingTimer?.cancel();
    super.dispose();
  }

  /// Хабарлама жіберу
  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty || _isSending) return;

    final notifier = ref.read(chatMessagesProvider.notifier);

    // Пайдаланушы хабарламасы
    notifier.addMessage(ChatMessage(text: text.trim(), isUser: true));
    _textController.clear();
    _scrollToBottom();

    setState(() => _isSending = true);

    try {
      final response = await widget.assistantService.sendMessage(
        text.trim(),
        _currentLanguage,
      );

      // Эмоция жаңарту
      ref.read(emotionProvider.notifier).onResponse(
        response['emotion'] as String? ?? 'idle',
      );

      // Теру эффектісімен жауап қосу
      final reply = response['reply'] as String? ?? '';
      final followUp = response['followUp'] as String?;

      await _typewriterEffect(reply, followUp);
    } catch (e) {
      notifier.addMessage(
        ChatMessage(
          text: _currentLanguage == 'kk'
              ? 'Кешіріңіз, қате орын алды. Қайталап көріңіз.'
              : 'Извините, произошла ошибка. Попробуйте ещё раз.',
          isUser: false,
        ),
      );
    } finally {
      setState(() => _isSending = false);
    }
  }

  /// Теру эффектісі — символ бойынша шығару
  Future<void> _typewriterEffect(String fullText, String? followUp) async {
    final notifier = ref.read(chatMessagesProvider.notifier);
    notifier.addMessage(
      const ChatMessage(text: '', isUser: false, isTyping: true),
    );

    final buffer = StringBuffer();
    final completer = Completer<void>();

    int index = 0;
    _typingTimer = Timer.periodic(const Duration(milliseconds: 25), (timer) {
      if (index < fullText.length) {
        buffer.write(fullText[index]);
        notifier.updateLast(
          ChatMessage(text: buffer.toString(), isUser: false, isTyping: true),
        );
        _scrollToBottom();
        index++;
      } else {
        timer.cancel();
        notifier.updateLast(
          ChatMessage(
            text: fullText,
            isUser: false,
            isTyping: false,
            followUp: followUp,
          ),
        );
        completer.complete();
      }
    });

    return completer.future;
  }

  /// Экранды төменге айналдыру
  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  /// TTS арқылы оқу
  Future<void> _speak(String text) async {
    final tts = widget.ttsEngine;
    if (tts == null) return;

    setState(() => _isSpeaking = true);
    try {
      await tts.speak(text, _currentLanguage);
    } finally {
      setState(() => _isSpeaking = false);
    }
  }

  /// Жылдам әрекет чипін басу
  void _onQuickAction(String label) {
    _sendMessage(label);
  }

  @override
  Widget build(BuildContext context) {
    final messages = ref.watch(chatMessagesProvider);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('QosQanat Көмекші'),
        centerTitle: true,
        actions: [
          // Тіл ауыстыру
          IconButton(
            icon: Text(
              _currentLanguage == 'kk' ? 'ҚАЗ' : 'РУС',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            onPressed: () {
              setState(() {
                _currentLanguage = _currentLanguage == 'kk' ? 'ru' : 'kk';
              });
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Аватар
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: AssistantAvatarWidget(
              size: 64,
              isSpeaking: _isSpeaking,
            ),
          ),

          // Жылдам әрекет чиптері
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: _quickActions.map((action) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ActionChip(
                    label: Text(action, style: const TextStyle(fontSize: 13)),
                    onPressed: () => _onQuickAction(action),
                    backgroundColor: theme.colorScheme.primaryContainer,
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 8),

          // Хабарлама тізімі
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                return _ChatBubble(
                  message: message,
                  onSpeak: message.isUser ? null : () => _speak(message.text),
                );
              },
            ),
          ),

          // Мәтін енгізу аймағы
          Container(
            padding: const EdgeInsets.fromLTRB(16, 8, 8, 16),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 8,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _textController,
                      decoration: InputDecoration(
                        hintText: _currentLanguage == 'kk'
                            ? 'Сұрағыңызды жазыңыз...'
                            : 'Напишите вопрос...',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                      ),
                      textInputAction: TextInputAction.send,
                      onSubmitted: _sendMessage,
                    ),
                  ),
                  const SizedBox(width: 8),
                  FloatingActionButton.small(
                    onPressed: _isSending
                        ? null
                        : () => _sendMessage(_textController.text),
                    child: _isSending
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.send_rounded),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Жылдам әрекет тізімі — тілге байланысты
  List<String> get _quickActions => _currentLanguage == 'kk'
      ? const ['Кеңес бер', 'Қатемді талда', 'Жоспар жаса', 'Мысал көрсет']
      : const ['Подскажи', 'Разбор ошибки', 'Составь план', 'Покажи пример'];
}

/// Чат көпіршігі виджеті
class _ChatBubble extends StatelessWidget {
  const _ChatBubble({
    required this.message,
    this.onSpeak,
  });

  final ChatMessage message;
  final VoidCallback? onSpeak;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isUser = message.isUser;

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isUser) const SizedBox(width: 4),
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isUser
                    ? theme.colorScheme.primary
                    : theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: Radius.circular(isUser ? 16 : 4),
                  bottomRight: Radius.circular(isUser ? 4 : 16),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message.text,
                    style: TextStyle(
                      color: isUser
                          ? theme.colorScheme.onPrimary
                          : theme.colorScheme.onSurface,
                      fontSize: 15,
                    ),
                  ),
                  if (message.isTyping)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: SizedBox(
                        width: 24,
                        height: 8,
                        child: _TypingIndicator(),
                      ),
                    ),
                  if (message.followUp != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      message.followUp!,
                      style: TextStyle(
                        color: (isUser
                                ? theme.colorScheme.onPrimary
                                : theme.colorScheme.onSurface)
                            .withValues(alpha: 0.7),
                        fontSize: 13,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          if (!isUser && onSpeak != null)
            IconButton(
              icon: const Icon(Icons.volume_up_rounded, size: 20),
              onPressed: onSpeak,
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            ),
        ],
      ),
    );
  }
}

/// Теру индикаторы — 3 нүкте анимациясы
class _TypingIndicator extends StatefulWidget {
  @override
  State<_TypingIndicator> createState() => _TypingIndicatorState();
}

class _TypingIndicatorState extends State<_TypingIndicator>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Row(
          children: List.generate(3, (i) {
            final delay = i * 0.2;
            final value = ((_controller.value + delay) % 1.0);
            final opacity = value < 0.5 ? value * 2 : (1 - value) * 2;
            return Container(
              width: 6,
              height: 6,
              margin: const EdgeInsets.symmetric(horizontal: 1),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Theme.of(context)
                    .colorScheme
                    .onSurface
                    .withValues(alpha: opacity.clamp(0.2, 1.0)),
              ),
            );
          }),
        );
      },
    );
  }
}
