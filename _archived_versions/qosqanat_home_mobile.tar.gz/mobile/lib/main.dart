import 'package:flutter/material.dart';
import 'dart:developer' as developer;

import 'app.dart';
import 'core/network/api_client.dart';
import 'core/storage/local_cache.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await LocalCache.init();
  } catch (e, stack) {
    developer.log('Initialization error: $e', stackTrace: stack);
  }
  runApp(QosQanatApp(apiClient: ApiClient()));
}
