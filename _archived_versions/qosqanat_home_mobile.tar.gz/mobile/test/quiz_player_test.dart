// Квиз ойнатқышы виджет тесттері — таймер, жауап таңдау, офлайн fallback

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart' as http_testing;

import 'package:qosqanat/core/network/api_client.dart';
import 'package:qosqanat/core/storage/offline_manager.dart';
import 'package:qosqanat/data/models/quiz_model.dart';
import 'package:qosqanat/features/quiz/quiz_player.dart';

/// Тест квиз JSON деректері
Map<String, Object?> _makeQuizResponse() {
  return <String, Object?>{
    'success': true,
    'data': <String, Object?>{
      'quiz': <String, Object?>{
        'id': 'quiz-001',
        'lessonId': 'lesson-001',
        'type': 'LESSON',
        'nameKk': 'Тест квиз',
        'nameRu': 'Тестовый квиз',
        'timeLimitSeconds': 60,
        'questions': <Map<String, Object?>>[
          <String, Object?>{
            'id': 'q1',
            'textKk': '2 + 2 = ?',
            'textRu': '2 + 2 = ?',
            'kind': 'SINGLE',
            'order': 0,
            'options': <Map<String, Object?>>[
              <String, Object?>{'id': 'o1', 'textKk': '3', 'textRu': '3', 'order': 0},
              <String, Object?>{'id': 'o2', 'textKk': '4', 'textRu': '4', 'order': 1},
              <String, Object?>{'id': 'o3', 'textKk': '5', 'textRu': '5', 'order': 2},
            ],
          },
          <String, Object?>{
            'id': 'q2',
            'textKk': '3 + 3 = ?',
            'textRu': '3 + 3 = ?',
            'kind': 'SINGLE',
            'order': 1,
            'options': <Map<String, Object?>>[
              <String, Object?>{'id': 'o4', 'textKk': '5', 'textRu': '5', 'order': 0},
              <String, Object?>{'id': 'o5', 'textKk': '6', 'textRu': '6', 'order': 1},
            ],
          },
        ],
      },
    },
  };
}

void main() {
  group('QuizModel parsing', () {
    test('JSON-нан дұрыс парсингтеледі', () {
      final Map<String, Object?> quizJson =
          (_makeQuizResponse()['data']! as Map<String, Object?>)['quiz']!
              as Map<String, Object?>;
      final QuizModel? quiz = QuizModel.fromJson(quizJson);

      expect(quiz, isNotNull);
      expect(quiz!.id, 'quiz-001');
      expect(quiz.questions.length, 2);
      expect(quiz.questions[0].options.length, 3);
      expect(quiz.timeLimitSeconds, 60);
    });

    test('қате JSON = null', () {
      final QuizModel? quiz = QuizModel.fromJson(<String, Object?>{'id': 123});
      expect(quiz, isNull);
    });
  });

  group('QuizSubmitPayload', () {
    test('JSON-ға дұрыс серияланады', () {
      const QuizSubmitPayload payload = QuizSubmitPayload(
        quizId: 'quiz-001',
        answers: <AnswerPayload>[
          AnswerPayload(questionId: 'q1', selectedOptionIds: <String>['o2']),
          AnswerPayload(questionId: 'q2', selectedOptionIds: <String>['o5']),
        ],
        startedAt: '2026-05-11T10:00:00.000Z',
        submittedAt: '2026-05-11T10:01:00.000Z',
      );

      final Map<String, Object?> json = payload.toJson();
      expect(json['quizId'], 'quiz-001');

      final Object? answers = json['answers'];
      expect(answers, isList);
      expect((answers! as List<Object?>).length, 2);
    });
  });

  group('QuizResultModel parsing', () {
    test('JSON-нан дұрыс парсингтеледі', () {
      final QuizResultModel? result = QuizResultModel.fromJson(<String, Object?>{
        'score': 80,
        'totalQuestions': 5,
        'correctCount': 4,
        'expEarned': 60,
        'coinsEarned': 1,
        'maxCombo': 2,
        'newStreak': 3,
        'streakUpdated': true,
      });

      expect(result, isNotNull);
      expect(result!.score, 80);
      expect(result.expEarned, 60);
      expect(result.maxCombo, 2);
      expect(result.streakUpdated, isTrue);
    });

    test('толық емес JSON = null', () {
      final QuizResultModel? result =
          QuizResultModel.fromJson(<String, Object?>{'score': 80});
      expect(result, isNull);
    });
  });

  group('QuizPlayerScreen widget', () {
    testWidgets('жүктелу кезінде прогресс индикатор көрсетеді', (WidgetTester tester) async {
      // Ешқашан жауап бермейтін баяу клиент
      final http.Client slowClient = http_testing.MockClient(
        (http.Request request) async {
          await Future<void>.delayed(const Duration(seconds: 10));
          return http.Response('{}', 200);
        },
      );

      final ApiClient apiClient = ApiClient(
        httpClient: slowClient,
        baseUrl: 'http://localhost:4000',
      );

      await tester.pumpWidget(MaterialApp(
        home: QuizPlayerScreen(
          apiClient: apiClient,
          offlineManager: OfflineManager(),
          quizId: 'quiz-001',
        ),
      ));

      // Жүктелу кезінде CircularProgressIndicator болуы керек
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });

    testWidgets('квиз жүктелгенде сұрақ пен нұсқаларды көрсетеді', (WidgetTester tester) async {
      final http.Client mockClient = http_testing.MockClient(
        (http.Request request) async {
          if (request.url.path.contains('/content/quizzes/')) {
            return http.Response(jsonEncode(_makeQuizResponse()), 200);
          }
          return http.Response('{"success":true,"data":{}}', 200);
        },
      );

      final ApiClient apiClient = ApiClient(
        httpClient: mockClient,
        baseUrl: 'http://localhost:4000',
      );

      // Hive инициализациясыз OfflineManager (тест режимі)
      final OfflineManager offlineManager = OfflineManager(apiClient: apiClient);

      await tester.pumpWidget(MaterialApp(
        home: QuizPlayerScreen(
          apiClient: apiClient,
          offlineManager: offlineManager,
          quizId: 'quiz-001',
        ),
      ));

      // Жүктелуін күтеміз
      await tester.pumpAndSettle();

      // Сұрақ мәтіні көрсетіледі
      expect(find.text('2 + 2 = ?'), findsOneWidget);

      // Нұсқалар көрсетіледі
      expect(find.text('3'), findsOneWidget);
      expect(find.text('4'), findsOneWidget);
      expect(find.text('5'), findsOneWidget);

      // Таймер көрсетіледі (01:00 = 60 секунд)
      expect(find.text('01:00'), findsOneWidget);
    });

    testWidgets('жауап таңдағанда UI жаңарады', (WidgetTester tester) async {
      final http.Client mockClient = http_testing.MockClient(
        (http.Request request) async {
          if (request.url.path.contains('/content/quizzes/')) {
            return http.Response(jsonEncode(_makeQuizResponse()), 200);
          }
          return http.Response('{"success":true,"data":{}}', 200);
        },
      );

      final ApiClient apiClient = ApiClient(
        httpClient: mockClient,
        baseUrl: 'http://localhost:4000',
      );

      final OfflineManager offlineManager = OfflineManager(apiClient: apiClient);

      await tester.pumpWidget(MaterialApp(
        home: QuizPlayerScreen(
          apiClient: apiClient,
          offlineManager: offlineManager,
          quizId: 'quiz-001',
        ),
      ));

      await tester.pumpAndSettle();

      // "4" жауабын таңдау
      await tester.tap(find.text('4'));
      await tester.pump();

      // "Келесі сұрақ" батырмасы белсенді болуы керек
      expect(find.text('Келесі сұрақ'), findsOneWidget);
    });
  });
}
