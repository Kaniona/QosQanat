// Ассистент виджет тесттері — эмоция, чат көпіршік, аватар

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:qosqanat/features/assistant/emotion_controller.dart';
import 'package:qosqanat/features/assistant/assistant_avatar_widget.dart';
import 'package:qosqanat/features/assistant/assistant_chat_screen.dart';
import 'package:qosqanat/services/assistant_local_service.dart';
import 'package:qosqanat/core/network/api_client.dart';

// ═══════════════════════════════════════════════════════════════
// Эмоция контроллері тесттері
// ═══════════════════════════════════════════════════════════════

void main() {
  group('EmotionController', () {
    late EmotionController controller;

    setUp(() {
      controller = EmotionController();
    });

    tearDown(() {
      controller.dispose();
    });

    test('бастапқы күй — idle', () {
      expect(controller.debugState, EmotionState.idle);
    });

    test('onResponse — encouraging күйге ауысу', () {
      controller.onResponse('encouraging');
      expect(controller.debugState, EmotionState.encouraging);
    });

    test('onResponse — concerned күйге ауысу', () {
      controller.onResponse('concerned');
      expect(controller.debugState, EmotionState.concerned);
    });

    test('onResponse — celebrating күйге ауысу', () {
      controller.onResponse('celebrating');
      expect(controller.debugState, EmotionState.celebrating);
    });

    test('onResponse — белгісіз мән idle қайтарады', () {
      controller.onResponse('unknown_value');
      expect(controller.debugState, EmotionState.idle);
    });

    test('setEmotion — тікелей күй орнату', () {
      controller.setEmotion(EmotionState.celebrating);
      expect(controller.debugState, EmotionState.celebrating);
    });

    test('onProgressEvent — жоғары серияда celebrating', () {
      controller.onProgressEvent(
        streak: 7,
        mistakeCount: 0,
        quizCompleted: false,
      );
      expect(controller.debugState, EmotionState.celebrating);
    });

    test('onProgressEvent — жақсы квиз нәтижесінде celebrating', () {
      controller.onProgressEvent(
        streak: 1,
        mistakeCount: 0,
        quizCompleted: true,
        quizScore: 95,
      );
      expect(controller.debugState, EmotionState.celebrating);
    });

    test('onProgressEvent — көп қатеде concerned', () {
      controller.onProgressEvent(
        streak: 1,
        mistakeCount: 5,
        quizCompleted: false,
      );
      expect(controller.debugState, EmotionState.concerned);
    });

    test('onProgressEvent — орташа серияда encouraging', () {
      controller.onProgressEvent(
        streak: 4,
        mistakeCount: 0,
        quizCompleted: false,
      );
      expect(controller.debugState, EmotionState.encouraging);
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // Аватар виджеті тесттері
  // ═══════════════════════════════════════════════════════════════

  group('AssistantAvatarWidget', () {
    testWidgets('виджет рендерленеді', (tester) async {
      await tester.pumpWidget(
        const ProviderScope(
          child: MaterialApp(
            home: Scaffold(
              body: Center(
                child: AssistantAvatarWidget(size: 80),
              ),
            ),
          ),
        ),
      );

      // Аватар бар екенін тексеру
      expect(find.byType(AssistantAvatarWidget), findsOneWidget);
    });

    testWidgets('idle күйде 📚 эмодзиі көрсетіледі', (tester) async {
      await tester.pumpWidget(
        const ProviderScope(
          child: MaterialApp(
            home: Scaffold(
              body: Center(
                child: AssistantAvatarWidget(size: 80),
              ),
            ),
          ),
        ),
      );

      expect(find.text('📚'), findsOneWidget);
    });

    testWidgets('өлшемді қабылдайды', (tester) async {
      await tester.pumpWidget(
        const ProviderScope(
          child: MaterialApp(
            home: Scaffold(
              body: Center(
                child: AssistantAvatarWidget(size: 120),
              ),
            ),
          ),
        ),
      );

      expect(find.byType(AssistantAvatarWidget), findsOneWidget);
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // Чат экраны тесттері
  // ═══════════════════════════════════════════════════════════════

  group('AssistantChatScreen', () {
    testWidgets('экран рендерленеді', (tester) async {
      final service = AssistantLocalService(
        apiClient: ApiClient(baseUrl: 'http://localhost:4000'),
      );

      await tester.pumpWidget(
        ProviderScope(
          child: MaterialApp(
            home: AssistantChatScreen(assistantService: service),
          ),
        ),
      );

      await tester.pump();

      // AppBar тақырыбы
      expect(find.text('QosQanat Көмекші'), findsOneWidget);
    });

    testWidgets('тіл ауыстыру батырмасы бар', (tester) async {
      final service = AssistantLocalService(
        apiClient: ApiClient(baseUrl: 'http://localhost:4000'),
      );

      await tester.pumpWidget(
        ProviderScope(
          child: MaterialApp(
            home: AssistantChatScreen(assistantService: service),
          ),
        ),
      );

      await tester.pump();

      // ҚАЗ батырмасы бар
      expect(find.text('ҚАЗ'), findsOneWidget);
    });

    testWidgets('жылдам әрекет чиптері көрсетіледі', (tester) async {
      final service = AssistantLocalService(
        apiClient: ApiClient(baseUrl: 'http://localhost:4000'),
      );

      await tester.pumpWidget(
        ProviderScope(
          child: MaterialApp(
            home: AssistantChatScreen(assistantService: service),
          ),
        ),
      );

      await tester.pump();

      // Жылдам әрекет чиптері
      expect(find.text('Кеңес бер'), findsOneWidget);
      expect(find.text('Қатемді талда'), findsOneWidget);
      expect(find.text('Жоспар жаса'), findsOneWidget);
    });

    testWidgets('мәтін енгізу аймағы бар', (tester) async {
      final service = AssistantLocalService(
        apiClient: ApiClient(baseUrl: 'http://localhost:4000'),
      );

      await tester.pumpWidget(
        ProviderScope(
          child: MaterialApp(
            home: AssistantChatScreen(assistantService: service),
          ),
        ),
      );

      await tester.pump();

      // TextField бар
      expect(find.byType(TextField), findsOneWidget);

      // Жіберу батырмасы бар
      expect(find.byIcon(Icons.send_rounded), findsOneWidget);
    });

    testWidgets('сәлемдесу хабарламасы көрсетіледі', (tester) async {
      final service = AssistantLocalService(
        apiClient: ApiClient(baseUrl: 'http://localhost:4000'),
      );

      await tester.pumpWidget(
        ProviderScope(
          child: MaterialApp(
            home: AssistantChatScreen(assistantService: service),
          ),
        ),
      );

      await tester.pump();
      await tester.pump();

      // Сәлемдесу хабарламасы
      expect(
        find.textContaining('QosQanat көмекшісімін'),
        findsOneWidget,
      );
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // EmotionState enum тесттері
  // ═══════════════════════════════════════════════════════════════

  group('EmotionState', () => {
    test('4 күй бар', () {
      expect(EmotionState.values.length, 4);
    });

    test('барлық күйлер тізімде', () {
      expect(EmotionState.values, contains(EmotionState.idle));
      expect(EmotionState.values, contains(EmotionState.encouraging));
      expect(EmotionState.values, contains(EmotionState.concerned));
      expect(EmotionState.values, contains(EmotionState.celebrating));
    });
  });
}
