# QosQanat 🦅

**Білім — қанатыңда** ("Knowledge is on your wings")

QosQanat is a world-class, gamified educational mobile app for Kazakh school
students (grades 5–11). It blends a Duolingo-style learning map, a Brawl-Stars-
style collectible avatar system, real-time 1-v-1 quiz battles, leaderboards, and
a Siri-like voice assistant — all fully in the Kazakh language.

---

## ✨ Overview

Students pick a lifelong AI companion (Bektur or Nazym), learn through an
adventure map of subject worlds, earn XP / coins / akyl points, customize their
assistant in the shop, add friends, battle them live in the **Ақыл Батл**, climb
the leaderboards, and track their growth in a personal trophy room. A voice
assistant lets them navigate and ask questions hands-free.

The app is designed to feel magical, encouraging, and age-appropriate, and is
structured for release on the **App Store** and **Google Play**.

## 🧰 Tech stack

| Concern            | Choice                                  |
| ------------------ | --------------------------------------- |
| Framework          | Flutter 3.x + Dart (null-safe)          |
| Backend            | Supabase (auth, Postgres, Realtime)     |
| State management   | Riverpod (`flutter_riverpod`)           |
| Navigation         | `go_router` (StatefulShellRoute)        |
| Typography         | `google_fonts` (Nunito, full Cyrillic)  |
| Avatars            | `flutter_svg` (layered SVG characters)  |
| Animation          | `flutter_animate`, `lottie`, `confetti` |
| Voice              | `speech_to_text` + `flutter_tts` (kk-KZ)|
| External apps      | `url_launcher`                          |
| Local persistence  | `shared_preferences`                    |
| Config             | `flutter_dotenv` (`.env`)               |

## 📂 Folder structure

```
lib/
├── main.dart                  # Entry point, error boundary, portrait lock
├── core/
│   ├── theme/                 # AppColors, AppTypography, AppSpacing, AppTheme
│   ├── constants/             # All Kazakh UI strings + voice/command config
│   └── utils/                 # Formatters, validators
├── models/                    # User, TaskNode, ShopItem, Battle, Friend, …
├── services/                  # supabase_service, api_service, voice_service
├── providers/                 # Riverpod notifiers (auth, game, shop, battle, …)
├── data/                      # Curriculum, shop items, quests, achievements, levels
├── screens/
│   ├── auth/                  # Splash, welcome, register, assistant select
│   ├── onboarding/            # First-time spotlight tutorial
│   ├── home/                  # Dashboard + widgets
│   ├── learn/                 # Subjects, map, task, result
│   ├── shop/                  # Cosmetics shop
│   ├── friends/               # Friends hub
│   ├── battle/                # Setup, waiting, live battle, result
│   ├── rating/                # Leaderboard
│   ├── profile/               # Trophy room + settings
│   └── main_shell.dart        # Bottom-tab shell + global level-up listener
├── widgets/
│   ├── avatar/                # Layered avatar rendering + animation
│   ├── ui/                    # Buttons, tab bar, error screen, emblem, …
│   ├── game/                  # XP bar, level-up modal, reward toast
│   └── voice/                 # Voice overlay, waveform, sound rings, bubble
└── navigation/
    └── app_router.dart        # go_router config (auth redirect + shell)
```

## 🚀 Setup

1. **Install dependencies**
   ```bash
   flutter pub get
   ```

2. **Configure Supabase credentials** — create a `.env` file in the project root:
   ```env
   SUPABASE_URL=https://YOUR-PROJECT.supabase.co
   SUPABASE_ANON_KEY=YOUR-ANON-KEY
   ```
   (`.env` is bundled as an asset and loaded at startup via `flutter_dotenv`.)

3. **Provision the database** — in the Supabase SQL editor, run the schema,
   row-level-security policies, and SECURITY DEFINER functions:
   ```
   SUPABASE_SETUP.sql
   ```

4. **Run the app**
   ```bash
   flutter run
   ```

> The app launches even without a valid `.env` (it falls back to the onboarding
> flow and offline/demo data), so you can explore the UI before wiring Supabase.

### Quality check
```bash
flutter analyze   # expected: No issues found!
```

## 🎮 Feature list

- **Onboarding** — cinematic splash, registration, and an emotional assistant
  choice (Bektur / Nazym), plus a celebratory 100-coin welcome gift.
- **First-time tutorial** — an 8-step spotlight tour of the app, shown once.
- **Home dashboard** — live XP/coin/akyl counters, level progress, streak,
  daily quests, quick actions, and the voice button.
- **Learning system** — subject worlds, an adventure node map, interactive
  tasks/quizzes, and a results screen with rewards.
- **Gamification** — levels (1–100) with titles, XP, coins, akyl points, daily
  login streaks, 35 achievements, and a global level-up celebration.
- **Shop** — a layered, animated avatar with purchasable/equippable cosmetics
  across categories and rarities.
- **Friends** — search by QQ-ID, send/accept/decline requests, and a friends
  list (cross-user reads via SECURITY DEFINER functions).
- **Ақыл Батл** — real-time 1-v-1 quiz battles synced over Supabase Realtime,
  with a live countdown, score sync, and win/loss result screens.
- **Rating** — leaderboards across four scopes (global, city, school, friends)
  with a top-3 podium, rank movement, and your pinned standing.
- **Profile** — a trophy room: hero, stats grid, achievements, an activity
  heatmap, recent battles, and settings.
- **Settings** — language, sound, vibration, animation, notification toggles
  (persisted), a streak-reminder time, account actions, and logout.
- **Voice assistant** — Kazakh speech recognition + TTS in the assistant's
  voice; navigate, ask about your stats, or open external apps by voice.
- **Polish** — custom bottom tab bar, smooth transitions, an auth-based route
  guard, a top-level error boundary, and a fully Kazakh interface.

## 🎨 Design system

- **Colors** — Primary `#4A6CF7`, Secondary `#7B61FF`, Gold `#FFD700`,
  Success `#00C48C`, Danger `#FF4757`, Background `#F8F9FF`.
- **Radii** — 12 / 16 / 20 / 28 / 999.
- **Spacing** — a 4-pt grid (4, 8, 12, 16, 20, 24, 32).
- Material 3, with all colors/spacing/typography centralized in `core/theme`.

## 📌 Assets still needed

- Final character art for Bektur & Nazym (currently rendered as layered SVG
  placeholders).
- Sound effects and background music.
- The production app icon (a placeholder eagle-wings emblem is used for now).

---

Made with ❤️ for Kazakh students.
