# QosQanat Flutter - Claude Code Instructions

## Project Overview
QosQanat is a world-class gamified educational mobile app for Kazakh school 
students (grades 5-11). Built with Flutter + Dart + Supabase. Target: App Store 
and Play Store. Quality must rival Duolingo and Brawl Stars.

## Tech Stack
- Flutter 3.x + Dart (latest stable)
- Supabase (supabase_flutter) - backend, auth, realtime, storage
- Riverpod (flutter_riverpod) - state management ONLY, no setState for global state
- go_router - navigation
- google_fonts - typography
- flutter_svg - avatar system
- lottie + flutter_animate - animations
- audioplayers - sound effects
- speech_to_text + flutter_tts - voice assistant

## Code Quality Rules (STRICT)
- ALWAYS use null-safety properly, never use ! unless certain
- ALWAYS use const constructors where possible (performance)
- ALWAYS split large widgets into smaller reusable widgets
- ALWAYS use proper Dart naming: PascalCase classes, camelCase variables/methods
- NEVER put business logic in widgets - use Riverpod providers/notifiers
- NEVER hardcode colors - use AppColors from theme
- NEVER hardcode strings - all UI text in Kazakh via constants
- NEVER use deprecated APIs
- ALWAYS handle loading, error, and empty states
- ALWAYS use async/await with try-catch for Supabase calls

## Folder Structure
lib/
  ├── main.dart
  ├── core/
  │   ├── theme/ (colors, typography, spacing, app_theme)
  │   ├── constants/ (kazakh strings, config)
  │   └── utils/ (helpers, formatters)
  ├── models/ (data classes - User, TaskNode, ShopItem, etc.)
  ├── services/ (supabase_service, api_service, voice_service)
  ├── providers/ (Riverpod providers and notifiers)
  ├── data/ (curriculum, shop_items, quests, achievements, levels)
  ├── screens/ (organized by feature: auth, home, learn, shop, friends, battle, rating, profile)
  ├── widgets/ (reusable: avatar, ui components, game components)
  └── navigation/ (go_router config)

## Widget Pattern - ALWAYS follow:
```dart
class MyWidget extends StatelessWidget {
  const MyWidget({super.key, required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
```

## Riverpod Pattern - ALWAYS follow:
```dart
final userProvider = StateNotifierProvider<UserNotifier, UserState>((ref) {
  return UserNotifier(ref);
});
```

## Design System
- Primary: Color(0xFF4A6CF7)
- Secondary: Color(0xFF7B61FF)
- Gold: Color(0xFFFFD700)
- Success: Color(0xFF00C48C)
- Danger: Color(0xFFFF4757)
- Background: Color(0xFFF8F9FF)
- Border radius: 12, 16, 20, 28, 999 (full)
- Spacing: 4, 8, 12, 16, 20, 24, 32
- Use Material 3 (useMaterial3: true)

## Kazakh Language
ALL UI text in Kazakh. Buttons: "Жалғастыру", "Болдырмау", "Дайын", "Таңдау".
Loading: "Жүктелуде...". Errors in Kazakh.

## Performance
- const everywhere possible
- ListView.builder for long lists (never Column with many children in scroll)
- Cache images with cached_network_image
- Dispose controllers in dispose()

## What NOT to do
- No setState for app-wide state (use Riverpod)
- No hardcoded text or colors
- No deprecated widgets
- No business logic in build methods
- No synchronous heavy work on main thread
