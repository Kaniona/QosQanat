import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/constants/app_strings.dart';
import 'core/theme/app_theme.dart';
import 'navigation/app_router.dart';
import 'services/supabase_service.dart';
import 'widgets/ui/app_error.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Top-level error boundary: replace the default red error screen with a
  // friendly Kazakh message so unexpected build errors never feel like a crash.
  ErrorWidget.builder = (FlutterErrorDetails details) => const AppErrorScreen();

  // Lock to portrait, matching the design.
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Initialize Supabase. If credentials are missing or unreachable, the app
  // still launches into the onboarding flow rather than crashing.
  try {
    await SupabaseService.init();
  } catch (e) {
    debugPrint('Supabase init failed: $e');
  }

  runApp(const ProviderScope(child: QosQanatApp()));
}

/// Root of the QosQanat application.
class QosQanatApp extends StatelessWidget {
  const QosQanatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: AppStrings.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      routerConfig: appRouter,
    );
  }
}
