import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';

import '../data/quests.dart';
import '../data/shop_items.dart';
import '../models/enums.dart';
import '../models/shop_item.dart';
import '../services/supabase_service.dart';
import '../widgets/avatar/avatar_base.dart';
import 'daily_quests_provider.dart';
import 'game_provider.dart';

/// What a card should show for an item, given ownership and the player's level.
enum ShopItemStatus { equipped, owned, locked, purchasable }

/// The outcome of a buy attempt.
enum PurchaseOutcome { purchased, insufficientFunds, alreadyOwned }

ShopItemStatus shopStatus(
  ShopItem item, {
  required bool owned,
  required bool equipped,
  required int level,
}) {
  if (equipped) return ShopItemStatus.equipped;
  if (owned) return ShopItemStatus.owned;
  if (level < item.levelRequirement) return ShopItemStatus.locked;
  return ShopItemStatus.purchasable;
}

/// The wardrobe: owned item ids and the currently equipped item per category.
class ShopState {
  const ShopState({required this.owned, required this.equipped});

  final Set<String> owned;
  final Map<ItemCategory, String> equipped;

  ShopState copyWith({Set<String>? owned, Map<ItemCategory, String>? equipped}) =>
      ShopState(owned: owned ?? this.owned, equipped: equipped ?? this.equipped);

  static ShopState initial() => ShopState(
        owned: const {},
        equipped: {
          for (final c in ItemCategory.values) c: defaultEquippedId(c),
        },
      );
}

/// Owns the player's wardrobe. Buying spends coins through the game notifier and
/// persists to `user_inventory`; equipping persists to `user_equipment`.
class ShopNotifier extends StateNotifier<ShopState> {
  ShopNotifier(this._ref) : super(ShopState.initial());

  final Ref _ref;
  String? _userId;

  /// Free items (price 0) are owned by default; others must be purchased.
  bool isOwned(ShopItem item) =>
      item.price == 0 || state.owned.contains(item.id);

  bool isEquipped(ShopItem item) => state.equipped[item.category] == item.id;

  /// Loads inventory + equipment for [userId] (non-fatal on error).
  Future<void> loadFor(String userId) async {
    _userId = userId;
    try {
      final inv = await SupabaseService.client
          .from('user_inventory')
          .select('item_id')
          .eq('user_id', userId);
      final owned = {
        for (final row in inv as List<dynamic>)
          (row as Map<String, dynamic>)['item_id'] as String,
      };

      final equip = await SupabaseService.client
          .from('user_equipment')
          .select()
          .eq('user_id', userId)
          .maybeSingle();

      final equipped = {
        for (final c in ItemCategory.values) c: defaultEquippedId(c),
      };
      if (equip != null) {
        for (final c in ItemCategory.values) {
          final id = equip['${c.name}_id'] as String?;
          if (id != null && shopItemById(id) != null) equipped[c] = id;
        }
      }
      state = ShopState(owned: owned, equipped: equipped);
    } catch (_) {
      // Offline / not configured: keep defaults.
    }
  }

  /// Buys [item] if affordable, then auto-equips it. Already-owned items just
  /// equip. Returns the outcome so the UI can react (toast / animation).
  Future<PurchaseOutcome> buy(ShopItem item) async {
    if (isOwned(item)) {
      await equip(item);
      return PurchaseOutcome.alreadyOwned;
    }
    final paid = await _ref.read(gameProvider.notifier).spendCoins(item.price);
    if (!paid) return PurchaseOutcome.insufficientFunds;

    state = state.copyWith(
      owned: {...state.owned, item.id},
      equipped: {...state.equipped, item.category: item.id},
    );
    _ref.read(dailyQuestsProvider.notifier).recordTrigger(QuestTrigger.purchase);
    await _persistInventory(item.id);
    await _persistEquipment();
    return PurchaseOutcome.purchased;
  }

  /// Equips an owned (or free) [item] in its category.
  Future<void> equip(ShopItem item) async {
    if (!isOwned(item)) return;
    state = state.copyWith(
      equipped: {...state.equipped, item.category: item.id},
    );
    await _persistEquipment();
  }

  Future<void> _persistInventory(String itemId) async {
    final userId = _userId;
    if (userId == null) return;
    try {
      await SupabaseService.client.from('user_inventory').upsert(
        {'user_id': userId, 'item_id': itemId},
        onConflict: 'user_id,item_id',
      );
    } catch (_) {/* non-fatal */}
  }

  Future<void> _persistEquipment() async {
    final userId = _userId;
    if (userId == null) return;
    try {
      await SupabaseService.client.from('user_equipment').upsert({
        'user_id': userId,
        for (final c in ItemCategory.values) '${c.name}_id': state.equipped[c],
      }, onConflict: 'user_id');
    } catch (_) {/* non-fatal */}
  }
}

final shopProvider = StateNotifierProvider<ShopNotifier, ShopState>(
  (ref) => ShopNotifier(ref),
);

/// The equipped items as avatar body slots, for [AvatarBase]/[AvatarDisplay]
/// everywhere in the app. "Жоқ" items leave their slot empty.
final equippedSlotsProvider = Provider<Map<AvatarSlot, String>>((ref) {
  final shop = ref.watch(shopProvider);
  final map = <AvatarSlot, String>{};
  shop.equipped.forEach((category, id) {
    if (!isNoneItem(id)) map[slotForCategory(category)] = id;
  });
  return map;
});
