import 'package:flutter/material.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// The two interface languages QosQanat ships with.
enum AppLanguage {
  kaz,
  rus;

  static AppLanguage fromName(String? value) =>
      value == 'rus' ? AppLanguage.rus : AppLanguage.kaz;
}

/// All persisted user preferences. Defaults are sensible (everything on, Kazakh,
/// a 19:00 streak reminder) so a fresh install behaves well before any toggles.
class SettingsState {
  const SettingsState({
    this.language = AppLanguage.kaz,
    this.sound = true,
    this.vibration = true,
    this.animations = true,
    this.notifQuests = true,
    this.notifBattles = true,
    this.notifFriends = true,
    this.streakReminder = const TimeOfDay(hour: 19, minute: 0),
    this.loaded = false,
  });

  final AppLanguage language;
  final bool sound;
  final bool vibration;
  final bool animations;
  final bool notifQuests;
  final bool notifBattles;
  final bool notifFriends;
  final TimeOfDay streakReminder;

  /// True once preferences have been read from disk.
  final bool loaded;

  SettingsState copyWith({
    AppLanguage? language,
    bool? sound,
    bool? vibration,
    bool? animations,
    bool? notifQuests,
    bool? notifBattles,
    bool? notifFriends,
    TimeOfDay? streakReminder,
    bool? loaded,
  }) {
    return SettingsState(
      language: language ?? this.language,
      sound: sound ?? this.sound,
      vibration: vibration ?? this.vibration,
      animations: animations ?? this.animations,
      notifQuests: notifQuests ?? this.notifQuests,
      notifBattles: notifBattles ?? this.notifBattles,
      notifFriends: notifFriends ?? this.notifFriends,
      streakReminder: streakReminder ?? this.streakReminder,
      loaded: loaded ?? this.loaded,
    );
  }
}

/// Persists every preference to [SharedPreferences] as it changes, and restores
/// them on first build.
class SettingsNotifier extends StateNotifier<SettingsState> {
  SettingsNotifier() : super(const SettingsState()) {
    _load();
  }

  static const _kLanguage = 'settings.language';
  static const _kSound = 'settings.sound';
  static const _kVibration = 'settings.vibration';
  static const _kAnimations = 'settings.animations';
  static const _kNotifQuests = 'settings.notif.quests';
  static const _kNotifBattles = 'settings.notif.battles';
  static const _kNotifFriends = 'settings.notif.friends';
  static const _kReminderMinutes = 'settings.reminder.minutes';

  SharedPreferences? _prefs;

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      _prefs = p;
      final minutes = p.getInt(_kReminderMinutes) ?? 19 * 60;
      state = SettingsState(
        language: AppLanguage.fromName(p.getString(_kLanguage)),
        sound: p.getBool(_kSound) ?? true,
        vibration: p.getBool(_kVibration) ?? true,
        animations: p.getBool(_kAnimations) ?? true,
        notifQuests: p.getBool(_kNotifQuests) ?? true,
        notifBattles: p.getBool(_kNotifBattles) ?? true,
        notifFriends: p.getBool(_kNotifFriends) ?? true,
        streakReminder: TimeOfDay(hour: minutes ~/ 60, minute: minutes % 60),
        loaded: true,
      );
    } catch (_) {
      // Storage unavailable (e.g. tests): keep in-memory defaults.
      state = state.copyWith(loaded: true);
    }
  }

  void setLanguage(AppLanguage value) {
    state = state.copyWith(language: value);
    _prefs?.setString(_kLanguage, value.name);
  }

  void setSound(bool value) {
    state = state.copyWith(sound: value);
    _prefs?.setBool(_kSound, value);
  }

  void setVibration(bool value) {
    state = state.copyWith(vibration: value);
    _prefs?.setBool(_kVibration, value);
  }

  void setAnimations(bool value) {
    state = state.copyWith(animations: value);
    _prefs?.setBool(_kAnimations, value);
  }

  void setNotifQuests(bool value) {
    state = state.copyWith(notifQuests: value);
    _prefs?.setBool(_kNotifQuests, value);
  }

  void setNotifBattles(bool value) {
    state = state.copyWith(notifBattles: value);
    _prefs?.setBool(_kNotifBattles, value);
  }

  void setNotifFriends(bool value) {
    state = state.copyWith(notifFriends: value);
    _prefs?.setBool(_kNotifFriends, value);
  }

  void setStreakReminder(TimeOfDay value) {
    state = state.copyWith(streakReminder: value);
    _prefs?.setInt(_kReminderMinutes, value.hour * 60 + value.minute);
  }
}

final settingsProvider =
    StateNotifierProvider<SettingsNotifier, SettingsState>(
  (ref) => SettingsNotifier(),
);
