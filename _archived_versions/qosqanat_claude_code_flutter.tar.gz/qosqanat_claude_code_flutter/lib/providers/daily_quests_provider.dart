import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';

import '../data/quests.dart';
import '../models/quest.dart';
import 'game_provider.dart';

/// How many quests from the pool make up a single day's board.
const int kDailyQuestCount = 5;

/// Live state of today's daily quests. Other features advance progress via
/// [DailyQuestsNotifier.recordTrigger]; the Home screen claims finished ones.
class DailyQuestsNotifier extends StateNotifier<List<Quest>> {
  DailyQuestsNotifier(this._ref) : super(_seed()) {
    // Opening the app satisfies the login quest immediately.
    recordTrigger(QuestTrigger.login);
  }

  final Ref _ref;

  /// The chosen daily quests, by id, for reward lookups.
  static final Map<String, QuestDef> _defs = {
    for (final d in kDailyQuests.take(kDailyQuestCount)) d.id: d,
  };

  static List<Quest> _seed() => [
        for (final d in kDailyQuests.take(kDailyQuestCount))
          Quest(
            id: d.id,
            title: d.title,
            description: d.description,
            targetProgress: d.target,
            xpReward: d.xpReward,
            coinReward: d.coinReward,
            iconName: d.emoji,
          ),
      ];

  /// How many of today's quests are fully completed (claimed or not).
  int get completedCount => state.where((q) => q.isCompleted).length;

  /// How many quests are finished and still waiting to be claimed.
  int get claimableCount =>
      state.where((q) => q.isCompleted && !q.isClaimed).length;

  /// Advances every unclaimed quest matching [trigger] by [amount], capped at
  /// its target. Called by gameplay (task completion, battles, purchases…).
  void recordTrigger(QuestTrigger trigger, {int amount = 1}) {
    state = [
      for (final q in state)
        if (_defs[q.id]?.trigger == trigger && !q.isClaimed)
          q.copyWith(
            currentProgress:
                (q.currentProgress + amount).clamp(0, q.targetProgress),
          )
        else
          q,
    ];
  }

  /// Claims a finished quest: grants its rewards through the game notifier and
  /// marks it collected. Returns the claimed quest (for the fly-to-counter
  /// animation), or null if it is not claimable.
  Future<Quest?> claim(String id) async {
    final index = state.indexWhere((q) => q.id == id);
    if (index < 0) return null;
    final quest = state[index];
    if (!quest.isCompleted || quest.isClaimed) return null;

    final def = _defs[id];
    final game = _ref.read(gameProvider.notifier);
    await game.addCoins(quest.coinReward);
    await game.addXp(quest.xpReward);
    if (def != null && def.akylReward > 0) {
      await game.addAkylPoints(def.akylReward);
    }

    state = [
      for (final q in state)
        if (q.id == id) q.copyWith(isClaimed: true) else q,
    ];
    return quest;
  }
}

final dailyQuestsProvider =
    StateNotifierProvider<DailyQuestsNotifier, List<Quest>>(
  (ref) => DailyQuestsNotifier(ref),
);
