import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../data/battle_questions.dart';
import '../data/quests.dart';
import '../models/battle.dart';
import '../models/enums.dart';
import '../models/question.dart';
import '../services/api_service.dart';
import '../services/supabase_service.dart';
import 'daily_quests_provider.dart';
import 'game_provider.dart';

/// Phases of a battle session.
enum BattlePhase { idle, waiting, active, finished }

/// Outcome from the local player's point of view.
enum BattleOutcome { win, lose, draw }

/// Per-question seconds and the reward presets.
const double kQuestionSeconds = 10;
const int kWinAkyl = 20, kWinCoins = 50;
const int kLoseAkyl = 5, kLoseCoins = 20;

/// Live state of a battle session.
class BattleSession {
  const BattleSession({
    this.phase = BattlePhase.idle,
    this.battle,
    this.isHost = true,
    this.questions = const [],
    this.index = 0,
    this.myScore = 0,
    this.oppScore = 0,
    this.secondsLeft = kQuestionSeconds,
    this.selected,
    this.answeredCorrect,
    this.starBurst = 0,
  });

  final BattlePhase phase;
  final Battle? battle;
  final bool isHost;
  final List<MultipleChoiceQuestion> questions;
  final int index;
  final int myScore;
  final int oppScore;
  final double secondsLeft;

  /// The option the player tapped for the current question (null = unanswered).
  final int? selected;
  final bool? answeredCorrect;

  /// Increments on each correct answer to trigger the star-burst animation.
  final int starBurst;

  int get total => questions.length;
  bool get answered => selected != null;
  MultipleChoiceQuestion? get current =>
      index >= 0 && index < questions.length ? questions[index] : null;

  BattleOutcome get outcome {
    if (myScore > oppScore) return BattleOutcome.win;
    if (myScore < oppScore) return BattleOutcome.lose;
    return BattleOutcome.draw;
  }

  BattleSession copyWith({
    BattlePhase? phase,
    Battle? battle,
    bool? isHost,
    List<MultipleChoiceQuestion>? questions,
    int? index,
    int? myScore,
    int? oppScore,
    double? secondsLeft,
    int? selected,
    bool? answeredCorrect,
    int? starBurst,
    bool clearAnswer = false,
  }) {
    return BattleSession(
      phase: phase ?? this.phase,
      battle: battle ?? this.battle,
      isHost: isHost ?? this.isHost,
      questions: questions ?? this.questions,
      index: index ?? this.index,
      myScore: myScore ?? this.myScore,
      oppScore: oppScore ?? this.oppScore,
      secondsLeft: secondsLeft ?? this.secondsLeft,
      selected: clearAnswer ? null : (selected ?? this.selected),
      answeredCorrect: clearAnswer ? null : (answeredCorrect ?? this.answeredCorrect),
      starBurst: starBurst ?? this.starBurst,
    );
  }
}

/// Drives a battle: builds the shared question set, runs the synchronized 10s
/// per-question clock, mirrors the opponent's live score via Supabase Realtime,
/// and grants rewards at the end.
class BattleNotifier extends StateNotifier<BattleSession> {
  BattleNotifier(this._ref) : super(const BattleSession());

  final Ref _ref;
  RealtimeChannel? _channel;
  Timer? _tick;
  bool _rewarded = false;

  /// Begins a session for [battle]. The host waits for the opponent to accept;
  /// once the row flips to active (seen over Realtime) play begins for both.
  void start({required Battle battle, required bool isHost}) {
    _tick?.cancel();
    _rewarded = false;
    state = BattleSession(
      phase: battle.status == BattleStatus.active
          ? BattlePhase.active
          : BattlePhase.waiting,
      battle: battle,
      isHost: isHost,
      questions: battleQuestions(
        seed: battle.id,
        count: battle.questionCount,
        subjectId: battle.subjectId,
      ),
    );
    _subscribe(battle.id);
    if (battle.status == BattleStatus.active) _beginPlay();
  }

  void _subscribe(String battleId) {
    try {
      _channel = SupabaseService.client.channel('battle:$battleId')
        ..onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'battles',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'id',
            value: battleId,
          ),
          callback: _onRowChanged,
        )
        ..subscribe();
    } catch (_) {
      // Realtime unavailable (offline / tests): the local clock still drives play.
    }
  }

  void _onRowChanged(PostgresChangePayload payload) {
    final row = payload.newRecord;
    if (row.isEmpty) return;
    final battle = Battle.fromJson(row);
    final myScore = state.isHost ? battle.hostScore : battle.opponentScore;
    final oppScore = state.isHost ? battle.opponentScore : battle.hostScore;

    state = state.copyWith(
      battle: battle,
      // Trust the server for the opponent; keep our own optimistic score.
      myScore: myScore > state.myScore ? myScore : state.myScore,
      oppScore: oppScore,
    );

    if (state.phase == BattlePhase.waiting &&
        battle.status == BattleStatus.active) {
      _beginPlay();
    } else if (battle.status == BattleStatus.finished &&
        state.phase != BattlePhase.finished) {
      _finish();
    }
  }

  void _beginPlay() {
    state = state.copyWith(phase: BattlePhase.active, index: 0);
    _startQuestionTimer();
  }

  void _startQuestionTimer() {
    _tick?.cancel();
    state = state.copyWith(secondsLeft: kQuestionSeconds, clearAnswer: true);
    _tick = Timer.periodic(const Duration(milliseconds: 100), (_) {
      final next = state.secondsLeft - 0.1;
      if (next <= 0) {
        _advance();
      } else {
        state = state.copyWith(secondsLeft: next);
      }
    });
  }

  /// Records the player's tap for the current question. Both players have the
  /// full 10s; the clock advances everyone together, so scores stay synced.
  Future<void> answer(int optionIndex) async {
    if (state.answered || state.phase != BattlePhase.active) return;
    final q = state.current;
    if (q == null) return;

    final correct = optionIndex == q.correctIndex;
    state = state.copyWith(
      selected: optionIndex,
      answeredCorrect: correct,
      myScore: correct ? state.myScore + 1 : state.myScore,
      starBurst: correct ? state.starBurst + 1 : state.starBurst,
    );

    // Sync to the server (increments the player's score column for the peer).
    try {
      await ApiService.submitBattleAnswer(state.battle!.id, correct: correct);
    } catch (_) {/* offline: local score stands */}
  }

  void _advance() {
    _tick?.cancel();
    if (state.index < state.questions.length - 1) {
      state = state.copyWith(index: state.index + 1);
      _startQuestionTimer();
    } else {
      _finish();
    }
  }

  Future<void> _finish() async {
    _tick?.cancel();
    state = state.copyWith(phase: BattlePhase.finished);
    if (_rewarded) return;
    _rewarded = true;

    final won = state.outcome == BattleOutcome.win;
    final game = _ref.read(gameProvider.notifier);
    await game.addAkylPoints(won ? kWinAkyl : kLoseAkyl);
    await game.addCoins(won ? kWinCoins : kLoseCoins);

    final quests = _ref.read(dailyQuestsProvider.notifier);
    quests.recordTrigger(QuestTrigger.battlePlayed);
    if (won) quests.recordTrigger(QuestTrigger.battleWon);

    // Best-effort server finalize.
    try {
      await ApiService.getBattleResult(state.battle!.id);
    } catch (_) {/* non-fatal */}
  }

  /// Leaves / cancels the session and tears down Realtime + timers.
  void leave() {
    _tick?.cancel();
    _tick = null;
    final ch = _channel;
    _channel = null;
    if (ch != null) {
      try {
        SupabaseService.client.removeChannel(ch);
      } catch (_) {/* ignore */}
    }
    state = const BattleSession();
  }

  @override
  void dispose() {
    _tick?.cancel();
    final ch = _channel;
    if (ch != null) {
      try {
        SupabaseService.client.removeChannel(ch);
      } catch (_) {/* ignore */}
    }
    super.dispose();
  }
}

final battleProvider =
    StateNotifierProvider<BattleNotifier, BattleSession>((ref) => BattleNotifier(ref));
