import 'package:flutter_riverpod/legacy.dart';

import '../models/friend.dart';
import '../services/api_service.dart';

/// Friends hub state: the friend list, pending requests (both directions), and
/// the current search result.
class FriendsState {
  const FriendsState({
    this.friends = const [],
    this.requests = const [],
    this.loading = false,
    this.error,
    this.searchResult,
    this.searching = false,
    this.searched = false,
    this.searchError,
  });

  final List<PublicProfile> friends;
  final List<FriendRequest> requests;
  final bool loading;
  final String? error;

  final PublicProfile? searchResult;
  final bool searching;

  /// True once a search has run (so the UI can show "not found" vs the prompt).
  final bool searched;
  final String? searchError;

  List<FriendRequest> get incoming =>
      [for (final r in requests) if (!r.outgoing) r];
  List<FriendRequest> get outgoing =>
      [for (final r in requests) if (r.outgoing) r];
  int get pendingIncomingCount => incoming.length;

  FriendsState copyWith({
    List<PublicProfile>? friends,
    List<FriendRequest>? requests,
    bool? loading,
    String? error,
    PublicProfile? searchResult,
    bool? searching,
    bool? searched,
    String? searchError,
    bool clearError = false,
    bool clearSearch = false,
  }) {
    return FriendsState(
      friends: friends ?? this.friends,
      requests: requests ?? this.requests,
      loading: loading ?? this.loading,
      error: clearError ? null : (error ?? this.error),
      searchResult: clearSearch ? null : (searchResult ?? this.searchResult),
      searching: searching ?? this.searching,
      searched: clearSearch ? false : (searched ?? this.searched),
      searchError: clearSearch ? null : (searchError ?? this.searchError),
    );
  }
}

/// How the friend list is ordered.
enum FriendSort { akyl, level, name }

class FriendsNotifier extends StateNotifier<FriendsState> {
  FriendsNotifier() : super(const FriendsState());

  FriendSort _sort = FriendSort.akyl;
  FriendSort get sort => _sort;

  /// Loads friends + pending requests.
  Future<void> refresh() async {
    state = state.copyWith(loading: true, clearError: true);
    try {
      final friends = await ApiService.getFriends();
      final requests = await ApiService.getPendingRequests();
      state = state.copyWith(
        friends: _sorted(friends),
        requests: requests,
        loading: false,
      );
    } on ApiException catch (e) {
      state = state.copyWith(loading: false, error: e.message);
    }
  }

  void setSort(FriendSort sort) {
    _sort = sort;
    state = state.copyWith(friends: _sorted(state.friends));
  }

  List<PublicProfile> _sorted(List<PublicProfile> list) {
    final copy = [...list];
    switch (_sort) {
      case FriendSort.akyl:
        copy.sort((a, b) => b.akylPoints.compareTo(a.akylPoints));
      case FriendSort.level:
        copy.sort((a, b) => b.level.compareTo(a.level));
      case FriendSort.name:
        copy.sort((a, b) => a.fullName.compareTo(b.fullName));
    }
    return copy;
  }

  Future<void> search(String qosqanatId) async {
    state = state.copyWith(searching: true, searchError: null);
    try {
      final result = await ApiService.searchUserByQosqanatId(qosqanatId);
      state = state.copyWith(
        searching: false,
        searched: true,
        searchResult: result,
      );
    } on ApiException catch (e) {
      state = state.copyWith(
          searching: false, searched: true, searchError: e.message);
    }
  }

  void clearSearch() => state = state.copyWith(clearSearch: true);

  Future<bool> sendRequest(String userId) async {
    try {
      await ApiService.sendFriendRequest(userId);
      await refresh();
      return true;
    } on ApiException catch (e) {
      state = state.copyWith(error: e.message);
      return false;
    }
  }

  Future<void> accept(String requestId) async {
    try {
      await ApiService.acceptFriendRequest(requestId);
      await refresh();
    } on ApiException catch (e) {
      state = state.copyWith(error: e.message);
    }
  }

  Future<void> decline(String requestId) async {
    try {
      await ApiService.declineFriendRequest(requestId);
      await refresh();
    } on ApiException catch (e) {
      state = state.copyWith(error: e.message);
    }
  }
}

final friendsProvider =
    StateNotifierProvider<FriendsNotifier, FriendsState>((ref) => FriendsNotifier());
