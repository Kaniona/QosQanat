import 'package:flutter_riverpod/legacy.dart';

import '../core/utils/validators.dart';

/// Immutable snapshot of the multi-step registration form.
class RegistrationData {
  const RegistrationData({
    this.fullName = '',
    this.phone = '',
    this.iin = '',
    this.city,
    this.school = '',
    this.grade,
    this.agreedTerms = false,
    this.agreedData = false,
  });

  final String fullName;

  /// Formatted as `+7 (XXX) XXX-XX-XX`.
  final String phone;
  final String iin;
  final String? city;
  final String school;
  final int? grade;
  final bool agreedTerms;
  final bool agreedData;

  /// Just the digits of the phone, e.g. `77012345678`.
  String get phoneDigits => phone.replaceAll(RegExp(r'\D'), '');

  bool get isStep1Valid =>
      Validators.fullName(fullName) == null &&
      Validators.phone(phone) == null &&
      Validators.iin(iin) == null;

  bool get isStep2Valid =>
      (city != null && city!.isNotEmpty) &&
      school.trim().isNotEmpty &&
      grade != null;

  bool get hasAgreed => agreedTerms && agreedData;

  RegistrationData copyWith({
    String? fullName,
    String? phone,
    String? iin,
    String? city,
    String? school,
    int? grade,
    bool? agreedTerms,
    bool? agreedData,
  }) {
    return RegistrationData(
      fullName: fullName ?? this.fullName,
      phone: phone ?? this.phone,
      iin: iin ?? this.iin,
      city: city ?? this.city,
      school: school ?? this.school,
      grade: grade ?? this.grade,
      agreedTerms: agreedTerms ?? this.agreedTerms,
      agreedData: agreedData ?? this.agreedData,
    );
  }
}

/// Holds and mutates the registration form across the three steps.
class RegistrationNotifier extends StateNotifier<RegistrationData> {
  RegistrationNotifier() : super(const RegistrationData());

  void setFullName(String value) => state = state.copyWith(fullName: value);
  void setPhone(String value) => state = state.copyWith(phone: value);
  void setIin(String value) => state = state.copyWith(iin: value);
  void setCity(String? value) => state = state.copyWith(city: value);
  void setSchool(String value) => state = state.copyWith(school: value);
  void setGrade(int value) => state = state.copyWith(grade: value);
  void setAgreedTerms(bool value) => state = state.copyWith(agreedTerms: value);
  void setAgreedData(bool value) => state = state.copyWith(agreedData: value);

  void reset() => state = const RegistrationData();
}

final registrationProvider =
    StateNotifierProvider<RegistrationNotifier, RegistrationData>(
  (ref) => RegistrationNotifier(),
);
