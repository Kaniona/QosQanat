import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/achievements.dart';
import '../data/shop_items.dart';
import '../models/enums.dart';
import '../models/leaderboard.dart';
import '../services/api_service.dart';
import 'auth_provider.dart';
import 'friends_provider.dart';
import 'game_provider.dart';
import 'shop_provider.dart';

/// The player's achievement metrics, composed live from the auth, game, friends
/// and shop providers so the trophy room updates the moment anything changes.
final achievementStatsProvider = Provider<AchievementStats>((ref) {
  final user = ref.watch(authProvider).user;
  final game = ref.watch(gameProvider);
  final friends = ref.watch(friendsProvider).friends;
  final shop = ref.watch(shopProvider);

  final petsOwned = shop.owned
      .where((id) => shopItemById(id)?.category == ItemCategory.pet)
      .length;

  return AchievementStats(
    tasksCompleted: user?.totalTasksCompleted ?? 0,
    level: game.level,
    battlesWon: user?.totalBattlesWon ?? 0,
    battlesPlayed: user?.totalBattlesWon ?? 0,
    itemsOwned: shop.owned.length,
    petsOwned: petsOwned,
    friends: friends.length,
    streakDays: game.longestStreak,
    akylPoints: game.akylPoints,
    coinsEarned: game.coins,
  );
});

/// The achievement catalog paired with each definition's unlocked state for the
/// current player.
typedef AchievementView = ({AchievementDef def, bool unlocked});

final achievementsViewProvider = Provider<List<AchievementView>>((ref) {
  final stats = ref.watch(achievementStatsProvider);
  return [
    for (final def in kAchievements)
      (def: def, unlocked: def.isUnlockedBy(stats)),
  ];
});

/// The last five finished battles for the recent-battles list. Tries the
/// SECURITY DEFINER backend, then falls back to a deterministic demo set so the
/// trophy room is never empty in offline/demo mode.
final recentBattlesProvider = FutureProvider<List<RecentBattle>>((ref) async {
  try {
    final battles = await ApiService.getRecentBattles(limit: 5);
    if (battles.isNotEmpty) return battles;
  } on ApiException {
    // Fall through to the demo set.
  }
  return _demoBattles;
});

const List<RecentBattle> _demoBattles = [
  RecentBattle(won: true, opponentName: 'Айдана Серік', myScore: 16, opponentScore: 12),
  RecentBattle(won: true, opponentName: 'Дамир Асхат', myScore: 18, opponentScore: 9),
  RecentBattle(won: false, opponentName: 'Аружан Бекзат', myScore: 11, opponentScore: 14),
  RecentBattle(won: true, opponentName: 'Санжар Ербол', myScore: 20, opponentScore: 17),
  RecentBattle(won: false, opponentName: 'Мадина Талғат', myScore: 8, opponentScore: 13),
];
