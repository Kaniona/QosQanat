import 'dart:math' as math;

import 'package:flutter_riverpod/legacy.dart';

import '../data/levels.dart';
import '../data/quests.dart';
import '../models/user.dart';
import '../services/supabase_service.dart';

/// A level-up the UI should celebrate.
class LevelUpEvent {
  const LevelUpEvent({
    required this.previousLevel,
    required this.newLevel,
    required this.coinReward,
  });

  final int previousLevel;
  final int newLevel;
  final int coinReward;

  String get title => levelTitle(newLevel);
}

/// A streak milestone the UI should celebrate.
class StreakEvent {
  const StreakEvent({required this.days, required this.coinReward});
  final int days;
  final int coinReward;
}

/// Live player game state. XP is stored as a running total.
class GameState {
  const GameState({
    this.level = 1,
    this.xp = 0,
    this.coins = 0,
    this.akylPoints = 0,
    this.streak = 0,
    this.longestStreak = 0,
    this.lastLoginDate,
    this.pendingLevelUp,
    this.pendingStreak,
  });

  final int level;
  final int xp;
  final int coins;
  final int akylPoints;
  final int streak;
  final int longestStreak;
  final DateTime? lastLoginDate;

  /// Set when a level-up should be celebrated; cleared by the UI.
  final LevelUpEvent? pendingLevelUp;

  /// Set when a streak milestone should be celebrated; cleared by the UI.
  final StreakEvent? pendingStreak;

  int get xpForCurrentLevel => xpRequiredFor(level);
  int get xpForNextLevel => xpRequiredFor(math.min(level + 1, kMaxLevel));

  /// XP accumulated within the current level.
  int get xpIntoLevel => (xp - xpForCurrentLevel).clamp(0, 1 << 31);

  /// XP still needed to reach the next level (0 at max level).
  int get xpToNextLevel =>
      level >= kMaxLevel ? 0 : (xpForNextLevel - xp).clamp(0, 1 << 31);

  /// Progress through the current level, 0..1.
  double get levelProgress {
    if (level >= kMaxLevel) return 1;
    final span = xpForNextLevel - xpForCurrentLevel;
    if (span <= 0) return 1;
    return (xpIntoLevel / span).clamp(0, 1);
  }

  GameState copyWith({
    int? level,
    int? xp,
    int? coins,
    int? akylPoints,
    int? streak,
    int? longestStreak,
    DateTime? lastLoginDate,
    LevelUpEvent? pendingLevelUp,
    StreakEvent? pendingStreak,
    bool clearLevelUp = false,
    bool clearStreak = false,
  }) {
    return GameState(
      level: level ?? this.level,
      xp: xp ?? this.xp,
      coins: coins ?? this.coins,
      akylPoints: akylPoints ?? this.akylPoints,
      streak: streak ?? this.streak,
      longestStreak: longestStreak ?? this.longestStreak,
      lastLoginDate: lastLoginDate ?? this.lastLoginDate,
      pendingLevelUp:
          clearLevelUp ? null : (pendingLevelUp ?? this.pendingLevelUp),
      pendingStreak: clearStreak ? null : (pendingStreak ?? this.pendingStreak),
    );
  }
}

/// Owns all live progression logic. No widget mutates these values directly —
/// they call actions here, which also persist to the Supabase users table.
class GameNotifier extends StateNotifier<GameState> {
  GameNotifier() : super(const GameState());

  /// Id of the row to persist changes to; captured from [setGameState].
  String? _userId;

  /// Whether live state has been seeded from a profile this app run.
  bool _seeded = false;

  /// Loads state from the signed-in [user] profile (no persistence).
  void setGameState(User user) {
    _userId = user.id;
    state = GameState(
      level: user.level,
      xp: user.xp,
      coins: user.coins,
      akylPoints: user.akylPoints,
      streak: user.currentStreak,
      longestStreak: user.longestStreak,
      lastLoginDate: user.lastLoginDate,
    );
  }

  /// Seeds live state from [user] and runs the daily streak check exactly once
  /// per app run. Safe to call on every Home build; later calls are no-ops so
  /// in-session XP/coin changes are never clobbered by the (staler) profile.
  Future<void> ensureSeeded(User user) async {
    if (_seeded) return;
    _seeded = true;
    setGameState(user);
    await checkStreak();
  }

  /// Adds XP, applying any level-ups (with their coin rewards) and flagging the
  /// celebration. Handles crossing multiple levels at once.
  Future<void> addXp(int amount) async {
    if (amount <= 0) return;
    final newXp = state.xp + amount;
    final newLevel = calculateLevel(newXp);

    if (newLevel > state.level) {
      var coinsGained = 0;
      for (var l = state.level + 1; l <= newLevel; l++) {
        coinsGained += coinRewardFor(l);
      }
      state = state.copyWith(
        xp: newXp,
        level: newLevel,
        coins: state.coins + coinsGained,
        pendingLevelUp: LevelUpEvent(
          previousLevel: state.level,
          newLevel: newLevel,
          coinReward: coinsGained,
        ),
      );
      await _persist({'xp': newXp, 'level': newLevel, 'coins': state.coins});
    } else {
      state = state.copyWith(xp: newXp);
      await _persist({'xp': newXp});
    }
  }

  /// Forces a single level-up (used rarely; addXp is the normal path).
  Future<void> levelUp() async {
    if (state.level >= kMaxLevel) return;
    final newLevel = state.level + 1;
    final reward = coinRewardFor(newLevel);
    state = state.copyWith(
      level: newLevel,
      coins: state.coins + reward,
      pendingLevelUp: LevelUpEvent(
        previousLevel: state.level,
        newLevel: newLevel,
        coinReward: reward,
      ),
    );
    await _persist({'level': newLevel, 'coins': state.coins});
  }

  Future<void> addCoins(int amount) async {
    if (amount == 0) return;
    final coins = math.max(0, state.coins + amount);
    state = state.copyWith(coins: coins);
    await _persist({'coins': coins});
  }

  Future<void> addAkylPoints(int amount) async {
    if (amount == 0) return;
    final akyl = math.max(0, state.akylPoints + amount);
    state = state.copyWith(akylPoints: akyl);
    await _persist({'akyl_points': akyl});
  }

  /// Spends coins. Returns false (and changes nothing) if funds are short.
  Future<bool> spendCoins(int amount) async {
    if (amount <= 0) return true;
    if (state.coins < amount) return false;
    final coins = state.coins - amount;
    state = state.copyWith(coins: coins);
    await _persist({'coins': coins});
    return true;
  }

  /// Compares lastLoginDate to today and updates the streak, granting any
  /// milestone reward. Idempotent within the same calendar day.
  Future<void> checkStreak() async {
    final today = _dateOnly(DateTime.now());
    final last = state.lastLoginDate == null
        ? null
        : _dateOnly(state.lastLoginDate!);

    int newStreak;
    if (last == null) {
      newStreak = 1;
    } else {
      final diff = today.difference(last).inDays;
      if (diff <= 0) return; // already counted today
      newStreak = diff == 1 ? state.streak + 1 : 1; // continue or reset
    }

    final reward = streakMilestoneCoins(newStreak);
    final longest = math.max(state.longestStreak, newStreak);

    state = state.copyWith(
      streak: newStreak,
      longestStreak: longest,
      lastLoginDate: today,
      coins: state.coins + reward,
      pendingStreak:
          reward > 0 ? StreakEvent(days: newStreak, coinReward: reward) : null,
    );

    await _persist({
      'current_streak': newStreak,
      'longest_streak': longest,
      'last_login_date': _dateString(today),
      'coins': state.coins,
    });
  }

  void clearLevelUp() => state = state.copyWith(clearLevelUp: true);
  void clearStreak() => state = state.copyWith(clearStreak: true);

  // ─── Persistence ──────────────────────────────────────────────────────
  Future<void> _persist(Map<String, dynamic> changes) async {
    final userId = _userId;
    if (userId == null) return; // no profile loaded (e.g. tests) — skip silently
    try {
      await SupabaseService.client
          .from('users')
          .update(changes)
          .eq('id', userId);
    } catch (_) {
      // Network/transient errors are non-fatal; local state stays authoritative
      // and will reconcile on next successful write.
    }
  }

  DateTime _dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

  String _dateString(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';
}

final gameProvider = StateNotifierProvider<GameNotifier, GameState>(
  (ref) => GameNotifier(),
);
