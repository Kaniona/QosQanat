import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';

import '../data/curriculum.dart';
import '../data/quests.dart';
import '../services/supabase_service.dart';
import 'daily_quests_provider.dart';
import 'game_provider.dart';

/// Per-node progress for a student.
class NodeProgress {
  const NodeProgress({this.completed = false, this.stars = 0});
  final bool completed;
  final int stars;

  NodeProgress copyWith({bool? completed, int? stars}) => NodeProgress(
        completed: completed ?? this.completed,
        stars: stars ?? this.stars,
      );
}

/// Stars earned for a score [percent] (0–100). Gentle: even a low pass earns 1.
int starsForPercent(int percent) {
  if (percent >= 90) return 3;
  if (percent >= 60) return 2;
  return 1;
}

/// The outcome of one task attempt, handed to the result screen.
class TaskResult {
  const TaskResult({
    required this.subjectId,
    required this.nodeId,
    required this.nodeTitle,
    required this.correct,
    required this.total,
    required this.stars,
    required this.percent,
    required this.xp,
    required this.coins,
    required this.akyl,
    required this.heartsLeft,
    required this.isFirstClear,
    required this.unlockedNext,
  });

  final String subjectId;
  final String nodeId;
  final String nodeTitle;
  final int correct;
  final int total;
  final int stars;
  final int percent;
  final int xp;
  final int coins;
  final int akyl;
  final int heartsLeft;

  /// True the first time this node is cleared (rewards granted once).
  final bool isFirstClear;

  /// True when clearing this node opened a brand-new node.
  final bool unlockedNext;
}

/// Owns the student's learning-map progress: which nodes are done, their stars,
/// and the lock/unlock derivation. Mutations grant rewards through the game
/// notifier, advance daily quests, and persist to the `task_progress` table.
class LearnNotifier extends StateNotifier<Map<String, NodeProgress>> {
  LearnNotifier(this._ref) : super(const {});

  final Ref _ref;
  String? _userId;

  /// Loads existing progress for [userId] from Supabase (non-fatal on error).
  Future<void> loadFor(String userId) async {
    _userId = userId;
    try {
      final rows = await SupabaseService.client
          .from('task_progress')
          .select()
          .eq('user_id', userId);
      final map = <String, NodeProgress>{};
      for (final row in rows as List<dynamic>) {
        final r = row as Map<String, dynamic>;
        final id = r['node_id'] as String?;
        if (id == null) continue;
        map[id] = NodeProgress(
          completed: r['completed'] as bool? ?? true,
          stars: (r['stars'] as num?)?.toInt() ?? 0,
        );
      }
      state = map;
    } catch (_) {
      // Offline / not configured: start fresh; writes still work locally.
    }
  }

  NodeProgress progressFor(String nodeId) =>
      state[nodeId] ?? const NodeProgress();

  bool isCompleted(String nodeId) => state[nodeId]?.completed ?? false;

  /// A node is unlocked if it's the first in its subject or the previous node
  /// (in play order) is completed.
  bool isUnlocked(String subjectId, String nodeId) {
    final subject = subjectById(subjectId);
    if (subject == null) return false;
    final nodes = subject.allNodes;
    final i = nodes.indexWhere((n) => n.id == nodeId);
    if (i <= 0) return true;
    return isCompleted(nodes[i - 1].id);
  }

  /// Completed-node count for a subject (for the grid progress label).
  int completedCount(String subjectId) {
    final subject = subjectById(subjectId);
    if (subject == null) return 0;
    return subject.allNodes.where((n) => isCompleted(n.id)).length;
  }

  /// Records a finished task: computes stars, grants rewards on first clear,
  /// advances quests, persists, and reports the result for the result screen.
  Future<TaskResult> completeNode({
    required String subjectId,
    required LearnNode node,
    required int correct,
    required int heartsLeft,
  }) async {
    final total = node.questions.length;
    final percent = total == 0 ? 100 : ((correct / total) * 100).round();
    final stars = starsForPercent(percent);

    final prev = state[node.id];
    final wasCompleted = prev?.completed ?? false;
    final isFirstClear = !wasCompleted;
    final bestStars = (prev?.stars ?? 0) > stars ? prev!.stars : stars;

    // Did a brand-new node become reachable?
    final subject = subjectById(subjectId);
    final nodes = subject?.allNodes ?? const [];
    final idx = nodes.indexWhere((n) => n.id == node.id);
    final unlockedNext = isFirstClear && idx >= 0 && idx < nodes.length - 1;

    state = {
      ...state,
      node.id: NodeProgress(completed: true, stars: bestStars),
    };

    // Rewards: granted once, on first clear.
    var xp = 0, coins = 0, akyl = 0;
    if (isFirstClear) {
      xp = node.xpReward;
      coins = node.coinReward;
      akyl = node.akylReward;
      final game = _ref.read(gameProvider.notifier);
      await game.addXp(xp);
      await game.addCoins(coins);
      if (akyl > 0) await game.addAkylPoints(akyl);
    }

    // Advance daily quests.
    final quests = _ref.read(dailyQuestsProvider.notifier);
    quests.recordTrigger(QuestTrigger.taskComplete);
    if (percent >= 100) quests.recordTrigger(QuestTrigger.perfectTask);

    await _persist(subjectId, node.id, bestStars, percent);

    return TaskResult(
      subjectId: subjectId,
      nodeId: node.id,
      nodeTitle: node.title,
      correct: correct,
      total: total,
      stars: stars,
      percent: percent,
      xp: xp,
      coins: coins,
      akyl: akyl,
      heartsLeft: heartsLeft,
      isFirstClear: isFirstClear,
      unlockedNext: unlockedNext,
    );
  }

  Future<void> _persist(
    String subjectId,
    String nodeId,
    int stars,
    int percent,
  ) async {
    final userId = _userId;
    if (userId == null) return;
    try {
      await SupabaseService.client.from('task_progress').upsert({
        'user_id': userId,
        'subject_id': subjectId,
        'node_id': nodeId,
        'stars': stars,
        'score': percent,
        'completed': true,
        'completed_at': DateTime.now().toIso8601String(),
      }, onConflict: 'user_id,node_id');
    } catch (_) {
      // Non-fatal; local progress remains authoritative until next write.
    }
  }
}

final learnProvider =
    StateNotifierProvider<LearnNotifier, Map<String, NodeProgress>>(
  (ref) => LearnNotifier(ref),
);
