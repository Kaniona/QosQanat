import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';

import '../models/enums.dart';
import '../models/friend.dart';
import '../models/leaderboard.dart';
import '../services/api_service.dart';
import 'auth_provider.dart';
import 'friends_provider.dart';
import 'game_provider.dart';

/// Below this many registered students a school leaderboard stays locked.
const int kSchoolUnlockThreshold = 10;

/// Live state of the rating screen for the currently-selected scope.
class RatingState {
  const RatingState({
    this.scope = RatingScope.global,
    this.loading = false,
    this.entries = const [],
    this.myEntry,
    this.error,
    this.schoolLocked = false,
    this.friendsEmpty = false,
  });

  final RatingScope scope;
  final bool loading;

  /// Ranked rows, rank 1 first.
  final List<LeaderboardEntry> entries;

  /// The signed-in user's row (may sit outside [entries] for a sticky footer).
  final LeaderboardEntry? myEntry;
  final String? error;

  /// True when the school scope has too few registered students.
  final bool schoolLocked;

  /// True when the friends scope has no friends yet.
  final bool friendsEmpty;

  /// The top-3 podium rows (fewer if the board is short).
  List<LeaderboardEntry> get podium => entries.take(3).toList();

  /// Everyone from 4th place down.
  List<LeaderboardEntry> get rest =>
      entries.length > 3 ? entries.sublist(3) : const [];

  /// Whether to pin the user's row at the bottom (they're off the podium).
  bool get showStickyMe => myEntry != null && myEntry!.rank > 3;

  RatingState copyWith({
    RatingScope? scope,
    bool? loading,
    List<LeaderboardEntry>? entries,
    LeaderboardEntry? myEntry,
    String? error,
    bool? schoolLocked,
    bool? friendsEmpty,
    bool clearError = false,
    bool clearMe = false,
  }) {
    return RatingState(
      scope: scope ?? this.scope,
      loading: loading ?? this.loading,
      entries: entries ?? this.entries,
      myEntry: clearMe ? null : (myEntry ?? this.myEntry),
      error: clearError ? null : (error ?? this.error),
      schoolLocked: schoolLocked ?? this.schoolLocked,
      friendsEmpty: friendsEmpty ?? this.friendsEmpty,
    );
  }
}

/// Loads leaderboards per scope from the SECURITY DEFINER backend, and falls
/// back to a deterministic local demo board when the backend is unavailable so
/// the screen always feels alive.
class RatingNotifier extends StateNotifier<RatingState> {
  RatingNotifier(this._ref) : super(const RatingState());

  final Ref _ref;

  Future<void> setScope(RatingScope scope) async {
    if (scope == state.scope && state.entries.isNotEmpty && !state.loading) {
      return;
    }
    state = state.copyWith(scope: scope);
    await load();
  }

  Future<void> load() async {
    state = state.copyWith(loading: true, clearError: true);
    final scope = state.scope;
    try {
      final entries = await ApiService.getLeaderboard(scope);
      _applyEntries(scope, entries);
    } on ApiException {
      _applyEntries(scope, _demoBoard(scope), demo: true);
    }
  }

  void _applyEntries(
    RatingScope scope,
    List<LeaderboardEntry> entries, {
    bool demo = false,
  }) {
    if (scope == RatingScope.school &&
        entries.length < kSchoolUnlockThreshold) {
      state = state.copyWith(
        loading: false,
        entries: const [],
        clearMe: true,
        schoolLocked: true,
        friendsEmpty: false,
      );
      return;
    }
    if (scope == RatingScope.friends && entries.length <= 1) {
      state = state.copyWith(
        loading: false,
        entries: const [],
        clearMe: true,
        friendsEmpty: true,
        schoolLocked: false,
      );
      return;
    }
    LeaderboardEntry? me;
    for (final e in entries) {
      if (e.isMe) {
        me = e;
        break;
      }
    }
    state = state.copyWith(
      loading: false,
      entries: entries,
      myEntry: me,
      clearMe: me == null,
      schoolLocked: false,
      friendsEmpty: false,
    );
  }

  // ─── Demo fallback ────────────────────────────────────────────────────

  /// A small pool of plausible Kazakh student names for demo boards.
  static const List<String> _names = [
    'Айдана Серік', 'Нұрислам Қанат', 'Әлия Жанбол', 'Дамир Асхат',
    'Аружан Бекзат', 'Ерасыл Мұрат', 'Мадина Талғат', 'Санжар Ербол',
    'Дильназ Арман', 'Темірлан Олжас', 'Камила Дәурен', 'Алихан Рустам',
    'Жанель Қайрат', 'Бекжан Сұлтан', 'Ясмин Нұрлан', 'Диас Әділ',
    'Аяулым Берік', 'Ерлан Тимур', 'Нұргүл Әбен', 'Рамазан Қуат',
  ];

  PublicProfile _me() {
    final user = _ref.read(authProvider).user;
    final game = _ref.read(gameProvider);
    return PublicProfile(
      id: user?.id ?? 'me',
      qosqanatId: user?.qosqanatId ?? 'QQ-XXXXXXXXX',
      fullName: user?.fullName ?? 'Сіз',
      level: game.level,
      akylPoints: game.akylPoints,
      assistantType: user?.assistantType ?? AssistantType.bektur,
      city: user?.city,
      school: user?.school,
    );
  }

  List<LeaderboardEntry> _demoBoard(RatingScope scope) {
    final me = _me();

    if (scope == RatingScope.friends) {
      final friends = _ref.read(friendsProvider).friends;
      if (friends.isEmpty) return const [];
      return _rank([...friends, me], me.id);
    }

    // Generate a deterministic bot pool whose akyl points bracket the user, so
    // their placement feels earned rather than random.
    final count = scope == RatingScope.school ? 14 : 40;
    final base = me.akylPoints;
    final bots = <PublicProfile>[];
    for (var i = 0; i < count; i++) {
      final name = _names[i % _names.length];
      // Spread points around the user's score with a stable pseudo-random step.
      final spread = ((i * 137) % 900) - 380 + (i - count ~/ 2) * 60;
      final akyl = (base + spread).clamp(50, 99999);
      bots.add(PublicProfile(
        id: 'demo-$scope-$i',
        qosqanatId: 'QQ-${(100000000 + i * 731).toString().substring(0, 9)}',
        fullName: '$name${i >= _names.length ? ' ${i ~/ _names.length + 1}' : ''}',
        level: 1 + akyl ~/ 350,
        akylPoints: akyl,
        assistantType:
            i.isEven ? AssistantType.bektur : AssistantType.nazym,
        city: me.city,
        school: me.school,
        isOnline: i % 3 == 0,
      ));
    }
    return _rank([...bots, me], me.id);
  }

  /// Sorts by akyl desc, assigns ranks, flags the user, and derives a stable
  /// rank-movement value so the ↑/↓ indicators look natural.
  List<LeaderboardEntry> _rank(List<PublicProfile> profiles, String meId) {
    final sorted = [...profiles]
      ..sort((a, b) => b.akylPoints.compareTo(a.akylPoints));
    return [
      for (var i = 0; i < sorted.length; i++)
        LeaderboardEntry(
          rank: i + 1,
          profile: sorted[i],
          rankChange: sorted[i].id == meId
              ? 2
              : ((sorted[i].id.hashCode % 7) - 3),
          isMe: sorted[i].id == meId,
        ),
    ];
  }
}

final ratingProvider =
    StateNotifierProvider<RatingNotifier, RatingState>((ref) => RatingNotifier(ref));
