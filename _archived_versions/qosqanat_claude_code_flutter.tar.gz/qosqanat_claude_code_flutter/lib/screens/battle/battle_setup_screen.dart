import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/battle_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/curriculum.dart';
import '../../models/battle.dart';
import '../../models/enums.dart';
import '../../models/friend.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/battle_provider.dart';
import '../../services/api_service.dart';
import '../../services/supabase_service.dart';
import '../../widgets/ui/gradient_button.dart';
import '../../widgets/ui/profile_avatar.dart';

/// "⚔️ Ақыл Батл" setup: choose the question count and subject, then start.
class BattleSetupScreen extends ConsumerStatefulWidget {
  const BattleSetupScreen({super.key, required this.opponent});

  final PublicProfile opponent;

  @override
  ConsumerState<BattleSetupScreen> createState() => _BattleSetupScreenState();
}

class _BattleSetupScreenState extends ConsumerState<BattleSetupScreen> {
  static const _counts = [15, 20, 25, 40, 50];

  int _count = 20;
  String _subjectId = 'all';
  bool _starting = false;

  Future<void> _start() async {
    if (_starting) return;
    setState(() => _starting = true);
    final notifier = ref.read(battleProvider.notifier);
    try {
      final battle = await ApiService.createBattle(
        opponentId: widget.opponent.id,
        questionCount: _count,
        subjectId: _subjectId == 'all' ? null : _subjectId,
      );
      notifier.start(battle: battle, isHost: true);
      if (mounted) {
        context.pushReplacement(AppRoutes.battleWaiting, extra: widget.opponent);
      }
    } on ApiException {
      // Offline fallback: a local, immediately-active battle so play can be
      // experienced solo. The realtime path (above) is used when online.
      final local = Battle(
        id: 'local-${DateTime.now().millisecondsSinceEpoch}',
        hostId: SupabaseService.currentUser?.id ?? 'me',
        opponentId: widget.opponent.id,
        questionCount: _count,
        status: BattleStatus.active,
        subjectId: _subjectId == 'all' ? null : _subjectId,
        createdAt: DateTime.now(),
      );
      notifier.start(battle: local, isHost: true);
      if (mounted) {
        context.pushReplacement(AppRoutes.battleLive, extra: widget.opponent);
      }
    } finally {
      if (mounted) setState(() => _starting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authProvider.select((s) => s.user));

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: BackButton(color: AppColors.ink, onPressed: () => context.pop()),
        title: Text(BattleStrings.title,
            style: AppTypography.heading3.copyWith(color: AppColors.ink)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.space5),
          child: Column(
            children: [
              _Combatant(
                name: widget.opponent.fullName,
                subtitle: widget.opponent.qosqanatId,
                assistant: widget.opponent.assistantType,
                color: AppColors.nazymPink,
              ),
              const SizedBox(height: AppSpacing.space2),
              Text(
                BattleStrings.vs,
                style: AppTypography.displayLarge.copyWith(color: AppColors.gold),
              ),
              const SizedBox(height: AppSpacing.space2),
              _Combatant(
                name: user?.fullName ?? BattleStrings.you,
                subtitle: user?.qosqanatId ?? '',
                assistant: user?.assistantType ?? AssistantType.bektur,
                color: AppColors.primary,
              ),
              const SizedBox(height: AppSpacing.space6),
              _Section(
                title: BattleStrings.questionCountTitle,
                child: Wrap(
                  spacing: AppSpacing.space2,
                  children: [
                    for (final c in _counts)
                      _Pill(
                        label: '$c',
                        selected: c == _count,
                        onTap: () => setState(() => _count = c),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.space5),
              _Section(
                title: BattleStrings.subjectTitle,
                child: Wrap(
                  spacing: AppSpacing.space2,
                  runSpacing: AppSpacing.space2,
                  children: [
                    _Pill(
                      label: BattleStrings.allSubjects,
                      selected: _subjectId == 'all',
                      onTap: () => setState(() => _subjectId = 'all'),
                    ),
                    for (final s in kCurriculum)
                      _Pill(
                        label: s.name,
                        selected: _subjectId == s.id,
                        onTap: () => setState(() => _subjectId = s.id),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.space8),
              GradientButton(
                label: BattleStrings.startBattle,
                gradient: const LinearGradient(
                  colors: [AppColors.secondary, AppColors.primary],
                ),
                isLoading: _starting,
                onPressed: _start,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Combatant extends StatelessWidget {
  const _Combatant({
    required this.name,
    required this.subtitle,
    required this.assistant,
    required this.color,
  });

  final String name;
  final String subtitle;
  final AssistantType assistant;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.space4),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withValues(alpha: 0.16), color.withValues(alpha: 0.04)],
        ),
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          ProfileAvatar(name: name, assistant: assistant, size: 56, ring: true),
          const SizedBox(width: AppSpacing.space3),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.heading3.copyWith(color: AppColors.ink),
                ),
                Text(subtitle, style: AppTypography.caption),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: AppTypography.heading3.copyWith(color: AppColors.ink)),
        const SizedBox(height: AppSpacing.space3),
        child,
      ],
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: AppSpacing.space2),
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.space4,
          vertical: AppSpacing.space2,
        ),
        decoration: BoxDecoration(
          gradient: selected ? AppColors.goldGradient : null,
          color: selected ? null : AppColors.surface,
          borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
          border: Border.all(
            color: selected ? AppColors.gold : AppColors.border,
            width: selected ? 2 : 1.5,
          ),
        ),
        child: Text(
          label,
          style: AppTypography.button.copyWith(
            color: selected ? AppColors.ink : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}
