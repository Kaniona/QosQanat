import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/battle_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../models/friend.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/battle_provider.dart';
import '../../widgets/ui/profile_avatar.dart';

/// Dramatic matchmaking screen: two combatants facing a glowing VS while we wait
/// for the opponent to accept. Transitions to the live battle on accept.
class BattleWaitingScreen extends ConsumerWidget {
  const BattleWaitingScreen({super.key, required this.opponent});

  final PublicProfile opponent;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // When the battle goes active (opponent accepted), drop into the fight.
    ref.listen<BattlePhase>(
      battleProvider.select((s) => s.phase),
      (_, phase) {
        if (phase == BattlePhase.active) {
          context.pushReplacement(AppRoutes.battleLive, extra: opponent);
        }
      },
    );

    final user = ref.watch(authProvider.select((s) => s.user));

    return Scaffold(
      body: Stack(
        alignment: Alignment.center,
        children: [
          Column(
            children: [
              Expanded(
                child: _Half(
                  color: AppColors.nazymPink,
                  name: opponent.fullName,
                  assistant: opponent.assistantType,
                  alignTop: true,
                ),
              ),
              Expanded(
                child: _Half(
                  color: AppColors.primary,
                  name: user?.fullName ?? BattleStrings.you,
                  assistant: user?.assistantType ?? AssistantType.bektur,
                  alignTop: false,
                ),
              ),
            ],
          ),
          const _VsEmblem(),
          Align(
            alignment: const Alignment(0, 0.55),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(
                      color: AppColors.white, strokeWidth: 3),
                ),
                const SizedBox(height: AppSpacing.space3),
                Text(
                  BattleStrings.waiting,
                  style: AppTypography.bodyLarge.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: AppSpacing.space4),
                const _RulesCard(),
                const SizedBox(height: AppSpacing.space4),
                TextButton(
                  onPressed: () {
                    ref.read(battleProvider.notifier).leave();
                    if (context.canPop()) {
                      context.pop();
                    } else {
                      context.go(AppRoutes.home);
                    }
                  },
                  child: Text(
                    BattleStrings.cancel,
                    style: AppTypography.button.copyWith(color: AppColors.white),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Half extends StatelessWidget {
  const _Half({
    required this.color,
    required this.name,
    required this.assistant,
    required this.alignTop,
  });

  final Color color;
  final String name;
  final AssistantType assistant;
  final bool alignTop;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [color, color.withValues(alpha: 0.7)],
        ),
      ),
      padding: EdgeInsets.only(
        top: alignTop ? 60 : 0,
        bottom: alignTop ? 0 : 60,
      ),
      child: Align(
        alignment: alignTop ? Alignment.topCenter : Alignment.bottomCenter,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ProfileAvatar(name: name, assistant: assistant, size: 84, ring: true),
            const SizedBox(height: AppSpacing.space2),
            Text(
              name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTypography.heading3.copyWith(
                color: AppColors.white,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _VsEmblem extends StatelessWidget {
  const _VsEmblem();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 96,
      height: 96,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: AppColors.goldGradient,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(color: AppColors.gold.withValues(alpha: 0.7), blurRadius: 30, spreadRadius: 4),
        ],
        border: Border.all(color: AppColors.white, width: 3),
      ),
      child: Text(
        BattleStrings.vs,
        style: AppTypography.displayLarge.copyWith(color: AppColors.ink),
      ),
    )
        .animate(onPlay: (c) => c.repeat(reverse: true))
        .scaleXY(begin: 0.92, end: 1.08, duration: 800.ms, curve: Curves.easeInOut);
  }
}

class _RulesCard extends StatelessWidget {
  const _RulesCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: AppSpacing.space6),
      padding: const EdgeInsets.all(AppSpacing.space4),
      decoration: BoxDecoration(
        color: AppColors.white.withValues(alpha: 0.18),
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        border: Border.all(color: AppColors.white.withValues(alpha: 0.4)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            BattleStrings.rulesTitle,
            style: AppTypography.caption.copyWith(
              color: AppColors.white,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            BattleStrings.rules,
            textAlign: TextAlign.center,
            style: AppTypography.bodySmall.copyWith(color: AppColors.white),
          ),
        ],
      ),
    );
  }
}
