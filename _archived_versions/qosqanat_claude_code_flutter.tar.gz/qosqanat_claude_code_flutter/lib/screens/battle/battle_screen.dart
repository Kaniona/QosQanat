import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/battle_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../models/friend.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/battle_provider.dart';
import '../../providers/shop_provider.dart';
import '../../widgets/avatar/avatar_base.dart';
import '../../widgets/avatar/avatar_display.dart';
import '../../widgets/ui/profile_avatar.dart';

/// The live 1v1 battle: opponent score on top, player + assistant on the bottom,
/// the current question in the middle, and a draining 10s countdown bar.
class BattleScreen extends ConsumerStatefulWidget {
  const BattleScreen({super.key, required this.opponent});

  final PublicProfile opponent;

  @override
  ConsumerState<BattleScreen> createState() => _BattleScreenState();
}

class _BattleScreenState extends ConsumerState<BattleScreen> {
  @override
  Widget build(BuildContext context) {
    ref.listen<BattlePhase>(
      battleProvider.select((s) => s.phase),
      (_, phase) {
        if (phase == BattlePhase.finished) {
          context.pushReplacement(AppRoutes.battleResult, extra: widget.opponent);
        }
      },
    );

    final session = ref.watch(battleProvider);
    final user = ref.watch(authProvider.select((s) => s.user));
    final assistant = user?.assistantType ?? AssistantType.bektur;
    final q = session.current;

    if (q == null) {
      return const Scaffold(
        backgroundColor: AppColors.ink,
        body: Center(child: CircularProgressIndicator(color: AppColors.white)),
      );
    }

    final avatarState = !session.answered
        ? AvatarAnimationState.thinking
        : (session.answeredCorrect == true
            ? AvatarAnimationState.celebrate
            : AvatarAnimationState.sad);

    return Scaffold(
      backgroundColor: AppColors.ink,
      body: SafeArea(
        child: Column(
          children: [
            // Opponent scoreboard.
            _ScoreBar(
              name: widget.opponent.fullName,
              assistant: widget.opponent.assistantType,
              score: session.oppScore,
              color: AppColors.nazymPink,
            ),
            _Counter(index: session.index, total: session.total),
            _Timer(secondsLeft: session.secondsLeft),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(AppSpacing.space5),
                child: Column(
                  children: [
                    Expanded(
                      child: Center(
                        child: Text(
                          q.prompt,
                          textAlign: TextAlign.center,
                          style: AppTypography.heading2.copyWith(color: AppColors.white),
                        ),
                      ),
                    ),
                    for (var i = 0; i < q.options.length; i++) ...[
                      _Option(
                        label: q.options[i],
                        state: _optionState(session, i, q.correctIndex),
                        onTap: () => ref.read(battleProvider.notifier).answer(i),
                      ),
                      const SizedBox(height: AppSpacing.space3),
                    ],
                  ],
                ),
              ),
            ),
            // Player scoreboard + reacting assistant.
            _PlayerBar(
              name: user?.fullName ?? BattleStrings.you,
              assistant: assistant,
              equipped: ref.watch(equippedSlotsProvider),
              avatarState: avatarState,
              score: session.myScore,
              starBurst: session.starBurst,
            ),
          ],
        ),
      ),
    );
  }

  _OptState _optionState(BattleSession s, int i, int correct) {
    if (!s.answered) return _OptState.idle;
    if (i == correct) return _OptState.correct;
    if (i == s.selected) return _OptState.wrong;
    return _OptState.dim;
  }
}

enum _OptState { idle, correct, wrong, dim }

class _ScoreBar extends StatelessWidget {
  const _ScoreBar({
    required this.name,
    required this.assistant,
    required this.score,
    required this.color,
  });

  final String name;
  final AssistantType assistant;
  final int score;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.space4,
        vertical: AppSpacing.space2,
      ),
      child: Row(
        children: [
          ProfileAvatar(name: name, assistant: assistant, size: 40),
          const SizedBox(width: AppSpacing.space3),
          Expanded(
            child: Text(
              name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTypography.bodyLarge.copyWith(
                color: AppColors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          _ScorePill(score: score, color: color),
        ],
      ),
    );
  }
}

class _PlayerBar extends StatelessWidget {
  const _PlayerBar({
    required this.name,
    required this.assistant,
    required this.equipped,
    required this.avatarState,
    required this.score,
    required this.starBurst,
  });

  final String name;
  final AssistantType assistant;
  final Map<AvatarSlot, String> equipped;
  final AvatarAnimationState avatarState;
  final int score;
  final int starBurst;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.space4,
        0,
        AppSpacing.space4,
        AppSpacing.space3,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          SizedBox(
            height: 72,
            width: 64,
            child: OverflowBox(
              maxHeight: 100,
              child: AvatarDisplay(
                type: assistant,
                state: avatarState,
                equipped: equipped,
                size: 80,
              ),
            ),
          ),
          const SizedBox(width: AppSpacing.space2),
          Expanded(
            child: Text(
              name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTypography.bodyLarge.copyWith(
                color: AppColors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          // Score pill with a star burst on each correct answer.
          Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.center,
            children: [
              _ScorePill(score: score, color: AppColors.primary),
              if (starBurst > 0)
                Positioned(
                  top: -18,
                  child: Icon(Icons.star_rounded, color: AppColors.gold, size: 28)
                      .animate(key: ValueKey(starBurst))
                      .scaleXY(begin: 0.2, end: 1.4, duration: 350.ms, curve: Curves.easeOut)
                      .fadeOut(delay: 350.ms, duration: 350.ms),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ScorePill extends StatelessWidget {
  const _ScorePill({required this.score, required this.color});
  final int score;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space4, vertical: 6),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
      ),
      child: Text(
        '$score',
        style: AppTypography.heading3.copyWith(
          color: AppColors.white,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}

class _Counter extends StatelessWidget {
  const _Counter({required this.index, required this.total});
  final int index;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Text(
      BattleStrings.questionCounter(index + 1, total),
      style: AppTypography.caption.copyWith(color: AppColors.primaryLight),
    );
  }
}

class _Timer extends StatelessWidget {
  const _Timer({required this.secondsLeft});
  final double secondsLeft;

  @override
  Widget build(BuildContext context) {
    final fraction = (secondsLeft / kQuestionSeconds).clamp(0.0, 1.0);
    final color = secondsLeft <= 3
        ? AppColors.danger
        : (secondsLeft <= 5 ? AppColors.warning : AppColors.success);
    final secs = secondsLeft.ceil().clamp(0, 99);

    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.space5,
        AppSpacing.space2,
        AppSpacing.space5,
        0,
      ),
      child: Row(
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
              child: Stack(
                children: [
                  Container(height: 12, color: AppColors.white.withValues(alpha: 0.12)),
                  AnimatedFractionallySizedBox(
                    duration: const Duration(milliseconds: 100),
                    widthFactor: fraction,
                    child: Container(
                      height: 12,
                      decoration: BoxDecoration(
                        color: color,
                        boxShadow: [BoxShadow(color: color.withValues(alpha: 0.6), blurRadius: 8)],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: AppSpacing.space3),
          Text(
            '0:${secs.toString().padLeft(2, '0')}',
            style: AppTypography.button.copyWith(color: color, fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }
}

class _Option extends StatelessWidget {
  const _Option({required this.label, required this.state, required this.onTap});
  final String label;
  final _OptState state;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final (bg, border, fg) = switch (state) {
      _OptState.idle => (AppColors.white.withValues(alpha: 0.08), AppColors.primaryLight, AppColors.white),
      _OptState.correct => (AppColors.success.withValues(alpha: 0.25), AppColors.success, AppColors.white),
      _OptState.wrong => (AppColors.danger.withValues(alpha: 0.25), AppColors.danger, AppColors.white),
      _OptState.dim => (AppColors.white.withValues(alpha: 0.04), AppColors.white.withValues(alpha: 0.15), AppColors.textTertiary),
    };

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        onTap: state == _OptState.idle ? onTap : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          width: double.infinity,
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.space4,
            vertical: AppSpacing.space4,
          ),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
            border: Border.all(color: border, width: 2),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: AppTypography.bodyLarge.copyWith(color: fg, fontWeight: FontWeight.w700),
          ),
        ),
      ),
    );
  }
}
