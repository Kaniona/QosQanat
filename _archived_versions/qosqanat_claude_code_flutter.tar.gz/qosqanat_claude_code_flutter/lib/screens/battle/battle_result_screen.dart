import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/battle_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../models/friend.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/battle_provider.dart';
import '../../providers/shop_provider.dart';
import '../../widgets/avatar/avatar_display.dart';
import '../../widgets/ui/gradient_button.dart';

/// The battle result: an explosive win or an encouraging loss, with the score
/// comparison and rewards. Losing always motivates.
class BattleResultScreen extends ConsumerStatefulWidget {
  const BattleResultScreen({super.key, required this.opponent});

  final PublicProfile opponent;

  @override
  ConsumerState<BattleResultScreen> createState() => _BattleResultScreenState();
}

class _BattleResultScreenState extends ConsumerState<BattleResultScreen> {
  late final ConfettiController _confetti;

  @override
  void initState() {
    super.initState();
    _confetti = ConfettiController(duration: const Duration(seconds: 4));
    if (ref.read(battleProvider).outcome == BattleOutcome.win) _confetti.play();
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  void _rematch() {
    ref.read(battleProvider.notifier).leave();
    context.pushReplacement(AppRoutes.battleSetup, extra: widget.opponent);
  }

  void _home() {
    ref.read(battleProvider.notifier).leave();
    context.go(AppRoutes.home);
  }

  @override
  Widget build(BuildContext context) {
    final session = ref.watch(battleProvider);
    final won = session.outcome == BattleOutcome.win;
    final draw = session.outcome == BattleOutcome.draw;
    final assistant =
        ref.watch(authProvider.select((s) => s.user?.assistantType)) ??
            AssistantType.bektur;
    final accuracy = session.total == 0
        ? 0
        : ((session.myScore / session.total) * 100).round();

    return Scaffold(
      backgroundColor: won ? AppColors.ink : AppColors.background,
      body: Stack(
        alignment: Alignment.topCenter,
        children: [
          if (won) const _GoldRays(),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(AppSpacing.space6),
              child: Column(
                children: [
                  const SizedBox(height: AppSpacing.space5),
                  Text(
                    won ? BattleStrings.win : (draw ? BattleStrings.draw : BattleStrings.lose),
                    textAlign: TextAlign.center,
                    style: AppTypography.displayHuge.copyWith(
                      color: won ? AppColors.gold : AppColors.ink,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.space2),
                  Text(
                    won ? BattleStrings.winCheer : BattleStrings.encourage,
                    style: AppTypography.bodyLarge.copyWith(
                      color: won ? AppColors.white : AppColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.space5),
                  SizedBox(
                    height: 150,
                    child: AvatarDisplay(
                      type: assistant,
                      equipped: ref.watch(equippedSlotsProvider),
                      state: won
                          ? AvatarAnimationState.celebrate
                          : AvatarAnimationState.wave,
                      size: 150,
                    ),
                  ),
                  if (won) ...[
                    const SizedBox(height: AppSpacing.space2),
                    const Text('🏆', style: TextStyle(fontSize: 44)),
                  ],
                  const SizedBox(height: AppSpacing.space5),
                  _ScoreCompare(
                    you: session.myScore,
                    opp: session.oppScore,
                    accuracy: accuracy,
                    dark: won,
                  ),
                  const SizedBox(height: AppSpacing.space4),
                  _Rewards(
                    akyl: won ? kWinAkyl : kLoseAkyl,
                    coins: won ? kWinCoins : kLoseCoins,
                    dark: won,
                  ),
                  const SizedBox(height: AppSpacing.space8),
                  GradientButton(
                    label: won ? BattleStrings.rematch : BattleStrings.retry,
                    gradient: AppColors.goldGradient,
                    onPressed: _rematch,
                  ),
                  const SizedBox(height: AppSpacing.space3),
                  TextButton(
                    onPressed: _home,
                    child: Text(
                      BattleStrings.home,
                      style: AppTypography.button.copyWith(
                        color: won ? AppColors.white : AppColors.textSecondary,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          ConfettiWidget(
            confettiController: _confetti,
            blastDirectionality: BlastDirectionality.explosive,
            numberOfParticles: 30,
            gravity: 0.2,
            shouldLoop: false,
            colors: const [AppColors.gold, AppColors.primary, AppColors.success, AppColors.white],
          ),
        ],
      ),
    );
  }
}

class _GoldRays extends StatelessWidget {
  const _GoldRays();

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: const Alignment(0, -0.4),
            radius: 1.1,
            colors: [
              AppColors.gold.withValues(alpha: 0.28),
              AppColors.ink.withValues(alpha: 0),
            ],
          ),
        ),
      ),
    );
  }
}

class _ScoreCompare extends StatelessWidget {
  const _ScoreCompare({
    required this.you,
    required this.opp,
    required this.accuracy,
    required this.dark,
  });

  final int you;
  final int opp;
  final int accuracy;
  final bool dark;

  @override
  Widget build(BuildContext context) {
    final fg = dark ? AppColors.white : AppColors.ink;
    return Column(
      children: [
        Text(
          BattleStrings.scoreCompare(you, opp),
          style: AppTypography.heading3.copyWith(color: fg, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 4),
        Text(
          BattleStrings.accuracy(accuracy),
          style: AppTypography.body.copyWith(
            color: dark ? AppColors.primaryLight : AppColors.textSecondary,
          ),
        ),
      ],
    );
  }
}

class _Rewards extends StatelessWidget {
  const _Rewards({required this.akyl, required this.coins, required this.dark});
  final int akyl;
  final int coins;
  final bool dark;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.space6,
        vertical: AppSpacing.space4,
      ),
      decoration: BoxDecoration(
        color: dark ? AppColors.white.withValues(alpha: 0.1) : AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        boxShadow: dark
            ? null
            : const [BoxShadow(color: AppColors.shadow, blurRadius: 14, offset: Offset(0, 6))],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '★ +$akyl',
            style: AppTypography.heading3.copyWith(
              color: AppColors.secondary,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(width: AppSpacing.space5),
          Text(
            '💰 +$coins',
            style: AppTypography.heading3.copyWith(
              color: AppColors.goldDeep,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}
