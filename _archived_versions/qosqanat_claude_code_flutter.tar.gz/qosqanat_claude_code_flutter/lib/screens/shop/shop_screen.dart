import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/shop_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/shop_items.dart';
import '../../models/enums.dart';
import '../../models/shop_item.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/game_provider.dart';
import '../../providers/shop_provider.dart';
import '../../widgets/avatar/avatar_display.dart';
import '../home/widgets/animated_counter.dart';
import 'widgets/avatar_stage.dart';
import 'widgets/item_detail_sheet.dart';
import 'widgets/shop_item_card.dart';

/// The Shop (Дүкен): coin balance, a live avatar preview stage, category tabs,
/// and a grid of purchasable / owned / equipped cosmetics.
class ShopScreen extends ConsumerStatefulWidget {
  const ShopScreen({super.key});

  @override
  ConsumerState<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends ConsumerState<ShopScreen> {
  ItemCategory _category = ItemCategory.top;
  AvatarAnimationState _stagePose = AvatarAnimationState.idle;
  Timer? _poseTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final user = ref.read(authProvider).user;
      if (user != null) ref.read(shopProvider.notifier).loadFor(user.id);
    });
  }

  @override
  void dispose() {
    _poseTimer?.cancel();
    super.dispose();
  }

  Future<void> _openItem(ShopItem item) async {
    final shop = ref.read(shopProvider.notifier);
    final level = ref.read(gameProvider).level;
    final status = shopStatus(
      item,
      owned: shop.isOwned(item),
      equipped: shop.isEquipped(item),
      level: level,
    );

    final act = await showItemDetail(
      context,
      item: item,
      assistant: ref.read(authProvider).user?.assistantType ?? AssistantType.bektur,
      status: status,
    );
    if (act != true || !mounted) return;

    final outcome = await shop.buy(item);
    if (!mounted) return;
    switch (outcome) {
      case PurchaseOutcome.purchased:
        _celebrate();
        _toast(ShopStrings.bought, AppColors.success);
      case PurchaseOutcome.alreadyOwned:
        _celebrate();
        _toast(ShopStrings.equippedToast, AppColors.success);
      case PurchaseOutcome.insufficientFunds:
        _toast(ShopStrings.insufficient, AppColors.danger);
    }
  }

  void _celebrate() {
    _poseTimer?.cancel();
    setState(() => _stagePose = AvatarAnimationState.celebrate);
    _poseTimer = Timer(const Duration(milliseconds: 1100), () {
      if (mounted) setState(() => _stagePose = AvatarAnimationState.idle);
    });
  }

  void _toast(String message, Color color) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(message),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
      ));
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authProvider.select((s) => s.user));
    final assistant = user?.assistantType ?? AssistantType.bektur;
    final coins = ref.watch(gameProvider.select((s) => s.coins));
    final level = ref.watch(gameProvider.select((s) => s.level));
    final equippedSlots = ref.watch(equippedSlotsProvider);
    final shop = ref.read(shopProvider.notifier);
    ref.watch(shopProvider); // rebuild on wardrobe changes

    final items = shopItemsByCategory(_category);
    final stageHeight = MediaQuery.sizeOf(context).height * 0.36;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _Header(coins: coins, onBack: () => _back(context)),
            SizedBox(
              height: stageHeight,
              child: AvatarStage(
                assistant: assistant,
                equipped: equippedSlots,
                state: _stagePose,
              ),
            ),
            _CategoryTabs(
              selected: _category,
              onSelect: (c) => setState(() => _category = c),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.space5,
                  AppSpacing.space3,
                  AppSpacing.space5,
                  AppSpacing.space8,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: AppSpacing.space4,
                  crossAxisSpacing: AppSpacing.space4,
                  childAspectRatio: 0.74,
                ),
                itemCount: items.length,
                itemBuilder: (context, i) {
                  final item = items[i];
                  final status = shopStatus(
                    item,
                    owned: shop.isOwned(item),
                    equipped: shop.isEquipped(item),
                    level: level,
                  );
                  return ShopItemCard(
                    item: item,
                    status: status,
                    isNew: kNewItemIds.contains(item.id),
                    assistant: assistant,
                    onTap: () => _openItem(item),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _back(BuildContext context) {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go(AppRoutes.home);
    }
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.coins, required this.onBack});
  final int coins;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.space4,
        AppSpacing.space3,
        AppSpacing.space5,
        AppSpacing.space2,
      ),
      child: Row(
        children: [
          // Only shown when pushed (not as a root tab).
          if (context.canPop()) ...[
            GestureDetector(
              onTap: onBack,
              behavior: HitTestBehavior.opaque,
              child: const Icon(Icons.arrow_back_rounded, color: AppColors.ink),
            ),
            const SizedBox(width: AppSpacing.space3),
          ],
          Expanded(
            child: Text(
              ShopStrings.title,
              style: AppTypography.heading1.copyWith(color: AppColors.ink),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.space4,
              vertical: AppSpacing.space2,
            ),
            decoration: BoxDecoration(
              gradient: AppColors.goldGradient,
              borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
              boxShadow: [
                BoxShadow(color: AppColors.gold.withValues(alpha: 0.4), blurRadius: 12),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('💰', style: TextStyle(fontSize: 16)),
                const SizedBox(width: 6),
                AnimatedCounter(
                  value: coins,
                  style: AppTypography.button.copyWith(
                    color: AppColors.ink,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CategoryTabs extends StatelessWidget {
  const _CategoryTabs({required this.selected, required this.onSelect});
  final ItemCategory selected;
  final ValueChanged<ItemCategory> onSelect;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 48,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space5),
        children: [
          for (final c in ItemCategory.values)
            _Tab(
              label: ShopStrings.categoryLabel(c),
              active: c == selected,
              onTap: () => onSelect(c),
            ),
        ],
      ),
    );
  }
}

class _Tab extends StatelessWidget {
  const _Tab({required this.label, required this.active, required this.onTap});
  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        margin: const EdgeInsets.only(right: AppSpacing.space5),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              label,
              style: AppTypography.bodyLarge.copyWith(
                color: active ? AppColors.ink : AppColors.textTertiary,
                fontWeight: active ? FontWeight.w800 : FontWeight.w600,
              ),
            ),
            const SizedBox(height: 4),
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              height: 3,
              width: active ? 28 : 0,
              decoration: BoxDecoration(
                gradient: AppColors.goldGradient,
                borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
