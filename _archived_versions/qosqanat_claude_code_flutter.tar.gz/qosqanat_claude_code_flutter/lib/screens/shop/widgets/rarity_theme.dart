import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../models/enums.dart';

/// Visual treatment for a rarity tier: a tint [color] and whether it earns a
/// premium gold [glow] (legendary).
extension RarityTheme on Rarity {
  Color get color => switch (this) {
        Rarity.common => AppColors.textTertiary,
        Rarity.rare => AppColors.primary,
        Rarity.epic => AppColors.secondary,
        Rarity.legendary => AppColors.gold,
      };

  bool get glow => this == Rarity.legendary;

  /// A soft gradient backdrop for the card preview, tinted by rarity.
  LinearGradient get backdrop => LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          color.withValues(alpha: 0.16),
          color.withValues(alpha: 0.04),
        ],
      );
}
