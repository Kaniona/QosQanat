import 'package:flutter/material.dart';

import '../../../core/constants/shop_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/utils/format.dart';
import '../../../models/enums.dart';
import '../../../models/shop_item.dart';
import '../../../providers/shop_provider.dart';
import 'item_avatar_preview.dart';
import 'rarity_theme.dart';

/// A single shop grid card: a try-on preview over a rarity backdrop, the item
/// name, and a price pill / status badge, with rarity border, a legendary glow,
/// a level lock, and an optional "ЖАҢА" ribbon.
class ShopItemCard extends StatelessWidget {
  const ShopItemCard({
    super.key,
    required this.item,
    required this.status,
    required this.isNew,
    required this.assistant,
    required this.onTap,
  });

  final ShopItem item;
  final ShopItemStatus status;
  final bool isNew;
  final AssistantType assistant;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final rarity = item.rarity;
    final equipped = status == ShopItemStatus.equipped;
    final locked = status == ShopItemStatus.locked;
    final borderColor = equipped ? AppColors.success : rarity.color;
    final legendaryPet =
        rarity == Rarity.legendary || (item.category == ItemCategory.pet && rarity == Rarity.epic);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
            border: Border.all(
              color: borderColor.withValues(alpha: equipped ? 1 : 0.5),
              width: equipped ? 2.5 : 1.5,
            ),
            boxShadow: [
              if (rarity.glow)
                BoxShadow(color: AppColors.gold.withValues(alpha: 0.45), blurRadius: 18)
              else
                const BoxShadow(color: AppColors.shadow, blurRadius: 10, offset: Offset(0, 4)),
            ],
          ),
          child: Stack(
            children: [
              Column(
                children: [
                  // Preview stage.
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        gradient: rarity.backdrop,
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(AppSpacing.radiusLg),
                        ),
                      ),
                      child: ItemAvatarPreview(
                        item: item,
                        assistant: assistant,
                        size: 92,
                        sparkle: legendaryPet,
                      ),
                    ),
                  ),
                  // Name + price/badge.
                  Padding(
                    padding: const EdgeInsets.fromLTRB(
                      AppSpacing.space3,
                      AppSpacing.space2,
                      AppSpacing.space3,
                      AppSpacing.space3,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          item.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: AppTypography.bodySmall.copyWith(
                            color: AppColors.ink,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 6),
                        _StatusChip(status: status, price: item.price),
                      ],
                    ),
                  ),
                ],
              ),
              if (locked) _lockOverlay(),
              if (isNew && !locked)
                Positioned(top: 0, left: 0, child: _NewRibbon()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _lockOverlay() {
    return Positioned.fill(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        child: Container(
          color: AppColors.ink.withValues(alpha: 0.55),
          alignment: Alignment.center,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock_rounded, color: AppColors.white, size: 26),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.gold,
                  borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
                ),
                child: Text(
                  ShopStrings.levelLock(item.levelRequirement),
                  style: AppTypography.caption.copyWith(
                    color: AppColors.ink,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.status, required this.price});
  final ShopItemStatus status;
  final int price;

  @override
  Widget build(BuildContext context) {
    final (label, fg, bg) = switch (status) {
      ShopItemStatus.equipped => (
          ShopStrings.equippedBadge,
          AppColors.white,
          AppColors.success,
        ),
      ShopItemStatus.owned => (
          ShopStrings.ownedBadge,
          AppColors.textSecondary,
          AppColors.surfaceMuted,
        ),
      ShopItemStatus.purchasable => (
          price == 0 ? 'Тегін' : '💰 ${formatThousands(price)}',
          AppColors.goldDeep,
          AppColors.gold.withValues(alpha: 0.16),
        ),
      ShopItemStatus.locked => (
          '💰 ${formatThousands(price)}',
          AppColors.textTertiary,
          AppColors.surfaceMuted,
        ),
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space3, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
      ),
      child: Text(
        label,
        style: AppTypography.caption.copyWith(color: fg, fontWeight: FontWeight.w800),
      ),
    );
  }
}

class _NewRibbon extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space3, vertical: 3),
      decoration: const BoxDecoration(
        color: AppColors.danger,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(AppSpacing.radiusLg),
          bottomRight: Radius.circular(AppSpacing.radiusMd),
        ),
      ),
      child: Text(
        ShopStrings.newRibbon,
        style: AppTypography.caption.copyWith(
          color: AppColors.white,
          fontWeight: FontWeight.w900,
          fontSize: 10,
        ),
      ),
    );
  }
}
