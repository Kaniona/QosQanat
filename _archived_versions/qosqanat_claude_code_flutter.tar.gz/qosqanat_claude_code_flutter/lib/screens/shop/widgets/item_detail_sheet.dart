import 'package:flutter/material.dart';

import '../../../core/constants/shop_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../data/shop_items.dart';
import '../../../models/enums.dart';
import '../../../models/shop_item.dart';
import '../../../providers/shop_provider.dart';
import '../../../widgets/avatar/avatar_base.dart';
import '../../../widgets/avatar/avatar_display.dart';
import '../../../widgets/ui/gradient_button.dart';
import 'rarity_theme.dart';

/// Detail sheet for an item: a large try-on, name + rarity, flavor text, an
/// "Аватарда көру" pose button, and a buy/equip action.
///
/// Resolves true when the player chooses to buy or equip.
Future<bool?> showItemDetail(
  BuildContext context, {
  required ShopItem item,
  required AssistantType assistant,
  required ShopItemStatus status,
}) {
  return showModalBottomSheet<bool>(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (_) =>
        _ItemDetailSheet(item: item, assistant: assistant, status: status),
  );
}

class _ItemDetailSheet extends StatefulWidget {
  const _ItemDetailSheet({
    required this.item,
    required this.assistant,
    required this.status,
  });

  final ShopItem item;
  final AssistantType assistant;
  final ShopItemStatus status;

  @override
  State<_ItemDetailSheet> createState() => _ItemDetailSheetState();
}

class _ItemDetailSheetState extends State<_ItemDetailSheet> {
  AvatarAnimationState _pose = AvatarAnimationState.idle;

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final rarity = item.rarity;
    final equipped = isNoneItem(item.id)
        ? const <AvatarSlot, String>{}
        : {slotForCategory(item.category): item.id};

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(AppSpacing.radiusXl)),
      ),
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.space5,
        AppSpacing.space3,
        AppSpacing.space5,
        AppSpacing.space6,
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 44,
              height: 5,
              margin: const EdgeInsets.only(bottom: AppSpacing.space3),
              decoration: BoxDecoration(
                color: AppColors.border,
                borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
              ),
            ),
            // Large try-on over a rarity backdrop.
            Container(
              height: 220,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: rarity.backdrop,
                borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
                boxShadow: rarity.glow
                    ? [BoxShadow(color: AppColors.gold.withValues(alpha: 0.4), blurRadius: 24)]
                    : null,
              ),
              child: Center(
                child: AvatarDisplay(
                  type: widget.assistant,
                  equipped: equipped,
                  state: _pose,
                  size: 190,
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.space4),
            Row(
              children: [
                Expanded(
                  child: Text(
                    item.name,
                    style: AppTypography.heading2.copyWith(color: AppColors.ink),
                  ),
                ),
                _RarityTag(rarity: rarity),
              ],
            ),
            if (item.description != null) ...[
              const SizedBox(height: AppSpacing.space2),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  item.description!,
                  style: AppTypography.body.copyWith(color: AppColors.textSecondary),
                ),
              ),
            ],
            const SizedBox(height: AppSpacing.space5),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () =>
                        setState(() => _pose = AvatarAnimationState.celebrate),
                    icon: const Icon(Icons.visibility_rounded, size: 18),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primary,
                      side: const BorderSide(color: AppColors.primary),
                      padding: const EdgeInsets.symmetric(vertical: AppSpacing.space4),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                      ),
                    ),
                    label: const Text(ShopStrings.preview),
                  ),
                ),
                const SizedBox(width: AppSpacing.space3),
                Expanded(child: _actionButton(context)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _actionButton(BuildContext context) {
    switch (widget.status) {
      case ShopItemStatus.equipped:
        return _disabled(ShopStrings.equipped);
      case ShopItemStatus.locked:
        return _disabled(ShopStrings.levelLock(widget.item.levelRequirement));
      case ShopItemStatus.owned:
        return GradientButton(
          label: ShopStrings.equip,
          gradient: AppColors.bekturGradient,
          onPressed: () => Navigator.of(context).pop(true),
        );
      case ShopItemStatus.purchasable:
        return GradientButton(
          label: widget.item.price == 0
              ? ShopStrings.equip
              : ShopStrings.buy(widget.item.price),
          gradient: AppColors.goldGradient,
          onPressed: () => Navigator.of(context).pop(true),
        );
    }
  }

  Widget _disabled(String label) {
    return Container(
      height: 56,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: AppColors.surfaceMuted,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
      ),
      child: Text(
        label,
        style: AppTypography.button.copyWith(color: AppColors.textTertiary),
      ),
    );
  }
}

class _RarityTag extends StatelessWidget {
  const _RarityTag({required this.rarity});
  final Rarity rarity;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space3, vertical: 4),
      decoration: BoxDecoration(
        color: rarity.color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
        border: Border.all(color: rarity.color.withValues(alpha: 0.5)),
      ),
      child: Text(
        ShopStrings.rarityLabel(rarity),
        style: AppTypography.caption.copyWith(
          color: rarity.color == AppColors.gold ? AppColors.goldDeep : rarity.color,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}
