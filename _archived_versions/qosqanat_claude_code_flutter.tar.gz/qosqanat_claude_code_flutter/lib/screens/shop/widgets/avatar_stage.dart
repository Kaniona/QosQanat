import 'package:flutter/material.dart';

import '../../../core/constants/shop_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/enums.dart';
import '../../../widgets/avatar/avatar_base.dart';
import '../../../widgets/avatar/avatar_display.dart';

/// The shop's preview stage: the assistant standing full-body on a softly lit
/// pedestal, wearing all equipped items. Swipe horizontally to turn the
/// character; it springs back when released.
class AvatarStage extends StatefulWidget {
  const AvatarStage({
    super.key,
    required this.assistant,
    required this.equipped,
    this.state = AvatarAnimationState.idle,
  });

  final AssistantType assistant;
  final Map<AvatarSlot, String> equipped;
  final AvatarAnimationState state;

  @override
  State<AvatarStage> createState() => _AvatarStageState();
}

class _AvatarStageState extends State<AvatarStage> {
  double _turn = 0; // radians around the Y axis

  void _onDragUpdate(DragUpdateDetails d) {
    setState(() => _turn = (_turn + d.delta.dx * 0.012).clamp(-0.6, 0.6));
  }

  void _onDragEnd(DragEndDetails _) => setState(() => _turn = 0);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onHorizontalDragUpdate: _onDragUpdate,
      onHorizontalDragEnd: _onDragEnd,
      behavior: HitTestBehavior.opaque,
      child: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.3),
            radius: 0.9,
            colors: [Color(0xFFEEF1FF), AppColors.background],
          ),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Pedestal.
            Align(
              alignment: const Alignment(0, 0.74),
              child: Container(
                width: 180,
                height: 34,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
                  gradient: LinearGradient(
                    colors: [
                      AppColors.primary.withValues(alpha: 0.18),
                      AppColors.secondary.withValues(alpha: 0.12),
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withValues(alpha: 0.18),
                      blurRadius: 30,
                      spreadRadius: 4,
                    ),
                  ],
                ),
              ),
            ),
            // Character (tilts with the swipe for a turn feel).
            Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..setEntry(3, 2, 0.001)
                ..rotateY(_turn),
              child: AvatarDisplay(
                type: widget.assistant,
                equipped: widget.equipped,
                state: widget.state,
                size: 200,
              ),
            ),
            // Rotate hint.
            Align(
              alignment: const Alignment(0, 0.95),
              child: Text(
                ShopStrings.rotateHint,
                style: AppTypography.caption.copyWith(color: AppColors.textTertiary),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
