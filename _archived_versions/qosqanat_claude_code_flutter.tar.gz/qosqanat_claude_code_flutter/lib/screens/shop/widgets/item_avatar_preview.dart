import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../data/shop_items.dart';
import '../../../models/enums.dart';
import '../../../models/shop_item.dart';
import '../../../widgets/avatar/avatar_base.dart';

/// A mini "try-on": the assistant wearing only [item], so the card shows exactly
/// what the player would get. Legendary items get an animated sparkle overlay.
class ItemAvatarPreview extends StatefulWidget {
  const ItemAvatarPreview({
    super.key,
    required this.item,
    required this.assistant,
    this.size = 96,
    this.sparkle = false,
  });

  final ShopItem item;
  final AssistantType assistant;
  final double size;
  final bool sparkle;

  @override
  State<ItemAvatarPreview> createState() => _ItemAvatarPreviewState();
}

class _ItemAvatarPreviewState extends State<ItemAvatarPreview>
    with SingleTickerProviderStateMixin {
  AnimationController? _sparkleCtrl;

  @override
  void initState() {
    super.initState();
    if (widget.sparkle) {
      _sparkleCtrl = AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 2200),
      )..repeat();
    }
  }

  @override
  void dispose() {
    _sparkleCtrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final equipped = isNoneItem(widget.item.id)
        ? const <AvatarSlot, String>{}
        : {slotForCategory(widget.item.category): widget.item.id};

    Widget avatar = AvatarBase(
      type: widget.assistant,
      equipped: equipped,
      size: widget.size,
    );

    if (_sparkleCtrl != null) {
      avatar = Stack(
        alignment: Alignment.center,
        children: [
          avatar,
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _sparkleCtrl!,
                builder: (context, _) => CustomPaint(
                  painter: _SparklePainter(_sparkleCtrl!.value),
                ),
              ),
            ),
          ),
        ],
      );
    }

    // "Жоқ" items show a clear remove marker instead of a bare avatar.
    if (isNoneItem(widget.item.id)) {
      return Center(
        child: Icon(Icons.block_rounded,
            color: AppColors.textTertiary, size: widget.size * 0.5),
      );
    }

    return avatar;
  }
}

/// A few twinkling stars for premium (legendary) items.
class _SparklePainter extends CustomPainter {
  _SparklePainter(this.t);
  final double t;

  static const _spots = [
    Offset(0.18, 0.22),
    Offset(0.82, 0.30),
    Offset(0.30, 0.74),
    Offset(0.74, 0.68),
    Offset(0.55, 0.12),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = AppColors.gold;
    for (var i = 0; i < _spots.length; i++) {
      final phase = (t + i / _spots.length) % 1.0;
      final twinkle = math.sin(phase * math.pi); // 0→1→0
      if (twinkle <= 0.05) continue;
      final c = Offset(_spots[i].dx * size.width, _spots[i].dy * size.height);
      paint.color = AppColors.gold.withValues(alpha: twinkle);
      _star(canvas, c, 3 + 3 * twinkle, paint);
    }
  }

  void _star(Canvas canvas, Offset c, double r, Paint paint) {
    final path = Path();
    for (var i = 0; i < 4; i++) {
      final a = i * math.pi / 2;
      final outer = Offset(c.dx + math.cos(a) * r, c.dy + math.sin(a) * r);
      final inner = Offset(
        c.dx + math.cos(a + math.pi / 4) * r * 0.35,
        c.dy + math.sin(a + math.pi / 4) * r * 0.35,
      );
      if (i == 0) {
        path.moveTo(outer.dx, outer.dy);
      } else {
        path.lineTo(outer.dx, outer.dy);
      }
      path.lineTo(inner.dx, inner.dy);
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _SparklePainter old) => old.t != t;
}
