import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_strings.dart';
import '../../core/constants/settings_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/settings_provider.dart';

/// "Баптаулар" — grouped settings: general toggles, notification preferences,
/// account actions, about info, and logout. Toggles persist via
/// [settingsProvider] (shared_preferences).
class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final notifier = ref.read(settingsProvider.notifier);
    final qqId = ref.watch(authProvider.select((s) => s.user?.qosqanatId)) ?? '';

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: BackButton(color: AppColors.ink, onPressed: () => context.pop()),
        title: Text(SettingsStrings.title,
            style: AppTypography.heading3.copyWith(color: AppColors.ink)),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.space5,
          AppSpacing.space2,
          AppSpacing.space5,
          AppSpacing.space8,
        ),
        children: [
          // ─── General ───────────────────────────────────────────────────
          _Group(
            title: SettingsStrings.groupGeneral,
            children: [
              _LanguageTile(
                value: settings.language,
                onChanged: notifier.setLanguage,
              ),
              _SwitchTile(
                label: SettingsStrings.sound,
                value: settings.sound,
                onChanged: notifier.setSound,
              ),
              _SwitchTile(
                label: SettingsStrings.vibration,
                value: settings.vibration,
                onChanged: notifier.setVibration,
              ),
              _SwitchTile(
                label: SettingsStrings.animations,
                value: settings.animations,
                onChanged: notifier.setAnimations,
              ),
            ],
          ),

          // ─── Notifications ─────────────────────────────────────────────
          _Group(
            title: SettingsStrings.groupNotifications,
            children: [
              _SwitchTile(
                label: SettingsStrings.notifQuests,
                value: settings.notifQuests,
                onChanged: notifier.setNotifQuests,
              ),
              _SwitchTile(
                label: SettingsStrings.notifBattles,
                value: settings.notifBattles,
                onChanged: notifier.setNotifBattles,
              ),
              _SwitchTile(
                label: SettingsStrings.notifFriends,
                value: settings.notifFriends,
                onChanged: notifier.setNotifFriends,
              ),
              _NavTile(
                label: SettingsStrings.streakReminder,
                trailing: _formatTime(settings.streakReminder),
                onTap: () => _pickTime(context, settings.streakReminder, notifier),
              ),
            ],
          ),

          // ─── Account ───────────────────────────────────────────────────
          _Group(
            title: SettingsStrings.groupAccount,
            children: [
              _NavTile(
                label: SettingsStrings.editProfile,
                onTap: () => context.go(AppRoutes.shop),
              ),
              _NavTile(
                label: SettingsStrings.changeAssistant,
                subtitle: SettingsStrings.changeAssistantNote,
                onTap: () => context.push(AppRoutes.assistantSelect),
              ),
              _NavTile(
                label: SettingsStrings.viewQqId,
                trailing: qqId,
                onTap: () => _showInfo(context, SettingsStrings.viewQqId, qqId),
              ),
            ],
          ),

          // ─── About ─────────────────────────────────────────────────────
          _Group(
            title: SettingsStrings.groupAbout,
            children: [
              const _NavTile(
                label: SettingsStrings.version,
                trailing: SettingsStrings.versionValue,
              ),
              _NavTile(
                label: SettingsStrings.terms,
                onTap: () => _showInfo(context, SettingsStrings.terms, SettingsStrings.terms),
              ),
              _NavTile(
                label: SettingsStrings.privacy,
                onTap: () => _showInfo(context, SettingsStrings.privacy, SettingsStrings.privacy),
              ),
              _NavTile(
                label: SettingsStrings.support,
                trailing: SettingsStrings.supportEmail,
                onTap: () => _showInfo(
                    context, SettingsStrings.support, SettingsStrings.supportEmail),
              ),
            ],
          ),

          const SizedBox(height: AppSpacing.space4),
          _LogoutTile(onTap: () => _confirmLogout(context, ref)),
        ],
      ),
    );
  }

  static String _formatTime(TimeOfDay t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  Future<void> _pickTime(
    BuildContext context,
    TimeOfDay current,
    SettingsNotifier notifier,
  ) async {
    final picked = await showTimePicker(context: context, initialTime: current);
    if (picked != null) notifier.setStreakReminder(picked);
  }

  void _showInfo(BuildContext context, String title, String body) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title, style: AppTypography.heading3),
        content: Text(body, style: AppTypography.body),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(AppStrings.ok, style: AppTypography.button),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmLogout(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(SettingsStrings.logoutConfirmTitle, style: AppTypography.heading3),
        content: Text(SettingsStrings.logoutConfirmBody, style: AppTypography.body),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(SettingsStrings.cancel,
                style: AppTypography.button.copyWith(color: AppColors.textSecondary)),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(SettingsStrings.confirm,
                style: AppTypography.button.copyWith(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (confirmed != true || !context.mounted) return;
    await ref.read(authProvider.notifier).signOut();
    if (context.mounted) context.go(AppRoutes.welcome);
  }
}

// ── Building blocks ─────────────────────────────────────────────────────────

class _Group extends StatelessWidget {
  const _Group({required this.title, required this.children});
  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.space2,
            AppSpacing.space4,
            0,
            AppSpacing.space2,
          ),
          child: Text(
            title,
            style: AppTypography.caption.copyWith(
              color: AppColors.textTertiary,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.6,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
            boxShadow: const [
              BoxShadow(color: AppColors.shadow, blurRadius: 10, offset: Offset(0, 3)),
            ],
          ),
          child: Column(
            children: [
              for (var i = 0; i < children.length; i++) ...[
                if (i > 0) const Divider(height: 1, color: AppColors.border),
                children[i],
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _SwitchTile extends StatelessWidget {
  const _SwitchTile({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.space4,
        vertical: AppSpacing.space1,
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(label, style: AppTypography.body.copyWith(color: AppColors.ink)),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeTrackColor: AppColors.primary,
          ),
        ],
      ),
    );
  }
}

class _NavTile extends StatelessWidget {
  const _NavTile({
    required this.label,
    this.subtitle,
    this.trailing,
    this.onTap,
  });

  final String label;
  final String? subtitle;
  final String? trailing;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.space4,
          vertical: AppSpacing.space4,
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(label, style: AppTypography.body.copyWith(color: AppColors.ink)),
                  if (subtitle != null)
                    Text(subtitle!, style: AppTypography.caption),
                ],
              ),
            ),
            if (trailing != null)
              Padding(
                padding: const EdgeInsets.only(right: AppSpacing.space2),
                child: Text(
                  trailing!,
                  style: AppTypography.bodySmall.copyWith(color: AppColors.textSecondary),
                ),
              ),
            if (onTap != null)
              const Icon(Icons.chevron_right_rounded, color: AppColors.textTertiary),
          ],
        ),
      ),
    );
  }
}

class _LanguageTile extends StatelessWidget {
  const _LanguageTile({required this.value, required this.onChanged});
  final AppLanguage value;
  final ValueChanged<AppLanguage> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.space4,
        vertical: AppSpacing.space3,
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(SettingsStrings.language,
                style: AppTypography.body.copyWith(color: AppColors.ink)),
          ),
          _Segment(
            label: SettingsStrings.langKaz,
            selected: value == AppLanguage.kaz,
            onTap: () => onChanged(AppLanguage.kaz),
          ),
          const SizedBox(width: AppSpacing.space1),
          _Segment(
            label: SettingsStrings.langRus,
            selected: value == AppLanguage.rus,
            onTap: () => onChanged(AppLanguage.rus),
          ),
        ],
      ),
    );
  }
}

class _Segment extends StatelessWidget {
  const _Segment({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.space3,
          vertical: AppSpacing.space1,
        ),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : AppColors.surfaceMuted,
          borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
        ),
        child: Text(
          label,
          style: AppTypography.caption.copyWith(
            color: selected ? AppColors.white : AppColors.textSecondary,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }
}

class _LogoutTile extends StatelessWidget {
  const _LogoutTile({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        boxShadow: const [
          BoxShadow(color: AppColors.shadow, blurRadius: 10, offset: Offset(0, 3)),
        ],
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.space4,
            vertical: AppSpacing.space4,
          ),
          child: Row(
            children: [
              const Icon(Icons.logout_rounded, color: AppColors.danger, size: 20),
              const SizedBox(width: AppSpacing.space3),
              Text(
                SettingsStrings.logout,
                style: AppTypography.body.copyWith(
                  color: AppColors.danger,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
