import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/assistant_theme.dart';
import '../../../models/enums.dart';
import '../../../widgets/avatar/avatar_base.dart';
import '../../../widgets/avatar/avatar_display.dart';
import '../../../widgets/game/xp_bar.dart';

/// The profile hero: an assistant-colored gradient backdrop with the full-body
/// character, edit + settings actions, the student's name, a copyable QQ-ID
/// pill, and the level badge with an XP bar.
class ProfileHero extends StatelessWidget {
  const ProfileHero({
    super.key,
    required this.assistant,
    required this.equipped,
    required this.name,
    required this.qosqanatId,
    required this.level,
    required this.levelProgress,
    required this.onEdit,
    required this.onSettings,
    required this.onCopyId,
  });

  final AssistantType assistant;
  final Map<AvatarSlot, String> equipped;
  final String name;
  final String qosqanatId;
  final int level;
  final double levelProgress;
  final VoidCallback onEdit;
  final VoidCallback onSettings;
  final VoidCallback onCopyId;

  @override
  Widget build(BuildContext context) {
    final topInset = MediaQuery.of(context).padding.top;

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: assistant.gradient,
        borderRadius: const BorderRadius.vertical(
          bottom: Radius.circular(AppSpacing.radiusXl),
        ),
      ),
      padding: EdgeInsets.fromLTRB(
        AppSpacing.space5,
        topInset + AppSpacing.space2,
        AppSpacing.space5,
        AppSpacing.space6,
      ),
      child: Column(
        children: [
          Row(
            children: [
              _CircleButton(icon: Icons.settings_rounded, onTap: onSettings),
              const Spacer(),
              _CircleButton(icon: Icons.edit_rounded, onTap: onEdit),
            ],
          ),
          SizedBox(
            height: 200,
            child: AvatarDisplay(
              type: assistant,
              equipped: equipped,
              size: 200,
            ),
          ),
          const SizedBox(height: AppSpacing.space3),
          Text(
            name,
            textAlign: TextAlign.center,
            style: AppTypography.displayLarge.copyWith(color: AppColors.white),
          ),
          const SizedBox(height: AppSpacing.space2),
          _QqIdPill(qosqanatId: qosqanatId, onCopy: onCopyId),
          const SizedBox(height: AppSpacing.space5),
          Container(
            padding: const EdgeInsets.all(AppSpacing.space3),
            decoration: BoxDecoration(
              color: AppColors.white.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
            ),
            child: XpBar(level: level, progress: levelProgress),
          ),
        ],
      ),
    );
  }
}

class _CircleButton extends StatelessWidget {
  const _CircleButton({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 40,
        height: 40,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: AppColors.white.withValues(alpha: 0.2),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: AppColors.white, size: 22),
      ),
    );
  }
}

class _QqIdPill extends StatelessWidget {
  const _QqIdPill({required this.qosqanatId, required this.onCopy});
  final String qosqanatId;
  final VoidCallback onCopy;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onCopy,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.space4,
          vertical: AppSpacing.space2,
        ),
        decoration: BoxDecoration(
          color: AppColors.white.withValues(alpha: 0.22),
          borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              qosqanatId,
              style: AppTypography.button.copyWith(
                color: AppColors.white,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(width: AppSpacing.space2),
            const Icon(Icons.copy_rounded, color: AppColors.white, size: 18),
          ],
        ),
      ),
    );
  }
}
