import 'package:flutter/material.dart';

import '../../../core/constants/profile_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/leaderboard.dart';

/// "Соңғы батлдар" — the last few finished battles, each with a W/L badge, the
/// opponent's name, and the final score.
class RecentBattlesList extends StatelessWidget {
  const RecentBattlesList({super.key, required this.battles});

  final List<RecentBattle> battles;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          ProfileStrings.recentBattlesTitle,
          style: AppTypography.heading3.copyWith(color: AppColors.ink),
        ),
        const SizedBox(height: AppSpacing.space3),
        if (battles.isEmpty)
          Text(ProfileStrings.noBattles, style: AppTypography.bodySmall)
        else
          for (final b in battles) _BattleRow(battle: b),
      ],
    );
  }
}

class _BattleRow extends StatelessWidget {
  const _BattleRow({required this.battle});
  final RecentBattle battle;

  @override
  Widget build(BuildContext context) {
    final won = battle.won;
    final color = won ? AppColors.success : AppColors.danger;

    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.space2),
      padding: const EdgeInsets.all(AppSpacing.space3),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.16),
              shape: BoxShape.circle,
            ),
            child: Text(
              won ? ProfileStrings.win : ProfileStrings.loss,
              style: AppTypography.bodyLarge.copyWith(
                color: color,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(width: AppSpacing.space3),
          Expanded(
            child: Text(
              battle.opponentName,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTypography.bodyLarge.copyWith(
                color: AppColors.ink,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Text(
            '${battle.myScore} : ${battle.opponentScore}',
            style: AppTypography.bodyLarge.copyWith(
              color: color,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}
