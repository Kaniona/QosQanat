import 'package:flutter/material.dart';

import '../../../core/constants/profile_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../providers/profile_provider.dart';

/// "🏅 Жетістіктер" — the unlock progress and a three-column grid of badges.
/// Unlocked badges are colorful; locked ones are greyed out with a "?".
class AchievementsSection extends StatelessWidget {
  const AchievementsSection({super.key, required this.achievements});

  final List<AchievementView> achievements;

  @override
  Widget build(BuildContext context) {
    final unlocked = achievements.where((a) => a.unlocked).length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              ProfileStrings.achievementsTitle,
              style: AppTypography.heading3.copyWith(color: AppColors.ink),
            ),
            Text(
              ProfileStrings.achievementsProgress(unlocked, achievements.length),
              style: AppTypography.bodySmall.copyWith(
                color: AppColors.primary,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.space3),
        GridView.count(
          crossAxisCount: 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: AppSpacing.space3,
          crossAxisSpacing: AppSpacing.space3,
          childAspectRatio: 0.82,
          children: [
            for (final a in achievements)
              _Badge(emoji: a.def.emoji, title: a.def.title, unlocked: a.unlocked),
          ],
        ),
      ],
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge({
    required this.emoji,
    required this.title,
    required this.unlocked,
  });

  final String emoji;
  final String title;
  final bool unlocked;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 60,
          height: 60,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: unlocked ? AppColors.goldGradient : null,
            color: unlocked ? null : AppColors.surfaceMuted,
            shape: BoxShape.circle,
            border: unlocked
                ? null
                : Border.all(color: AppColors.border, width: 1.5),
            boxShadow: unlocked
                ? [
                    BoxShadow(
                      color: AppColors.gold.withValues(alpha: 0.4),
                      blurRadius: 12,
                    ),
                  ]
                : null,
          ),
          child: unlocked
              ? Text(emoji, style: const TextStyle(fontSize: 28))
              : Text(
                  ProfileStrings.locked,
                  style: AppTypography.heading2.copyWith(
                    color: AppColors.textTertiary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
        ),
        const SizedBox(height: 4),
        Text(
          title,
          maxLines: 2,
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
          style: AppTypography.caption.copyWith(
            height: 1.1,
            color: unlocked ? AppColors.textSecondary : AppColors.textTertiary,
          ),
        ),
      ],
    );
  }
}
