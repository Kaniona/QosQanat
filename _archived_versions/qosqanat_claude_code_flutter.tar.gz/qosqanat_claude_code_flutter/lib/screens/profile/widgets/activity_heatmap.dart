import 'package:flutter/material.dart';

import '../../../core/constants/profile_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';

/// "📅 Белсенділік" — a GitHub-style contribution grid of weeks (columns) by
/// days (rows), cells shaded by activity intensity, showing roughly four months
/// of the student's consistency. Intensity is derived deterministically from
/// [seed] so the same student always sees the same history.
class ActivityHeatmap extends StatelessWidget {
  const ActivityHeatmap({
    super.key,
    required this.seed,
    this.weeks = 17,
    this.recentActiveDays = 0,
  });

  final int seed;
  final int weeks;

  /// Number of trailing days forced to be active (mirrors the current streak).
  final int recentActiveDays;

  static const double _cell = 13;
  static const double _gap = 3;

  /// Five-step shade scale (0 = none → 4 = most active).
  Color _shade(int level) {
    switch (level) {
      case 0:
        return AppColors.surfaceMuted;
      case 1:
        return AppColors.success.withValues(alpha: 0.3);
      case 2:
        return AppColors.success.withValues(alpha: 0.55);
      case 3:
        return AppColors.success.withValues(alpha: 0.8);
      default:
        return AppColors.success;
    }
  }

  /// Deterministic intensity 0..4 for the day at [index] (0 = oldest).
  int _intensity(int index, int totalDays) {
    if (index >= totalDays - recentActiveDays) {
      // Trailing streak days are reliably active.
      return 3 + ((seed + index) % 2);
    }
    final h = (seed * 2654435761 + index * 40503) & 0x7fffffff;
    final r = h % 100;
    if (r < 45) return 0;
    if (r < 65) return 1;
    if (r < 82) return 2;
    if (r < 94) return 3;
    return 4;
  }

  @override
  Widget build(BuildContext context) {
    final totalDays = weeks * 7;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          ProfileStrings.activityTitle,
          style: AppTypography.heading3.copyWith(color: AppColors.ink),
        ),
        const SizedBox(height: AppSpacing.space3),
        Container(
          padding: const EdgeInsets.all(AppSpacing.space4),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
            boxShadow: const [
              BoxShadow(color: AppColors.shadow, blurRadius: 12, offset: Offset(0, 4)),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                reverse: true,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for (var w = 0; w < weeks; w++)
                      Padding(
                        padding: const EdgeInsets.only(right: _gap),
                        child: Column(
                          children: [
                            for (var d = 0; d < 7; d++)
                              Padding(
                                padding: const EdgeInsets.only(bottom: _gap),
                                child: Container(
                                  width: _cell,
                                  height: _cell,
                                  decoration: BoxDecoration(
                                    color: _shade(_intensity(w * 7 + d, totalDays)),
                                    borderRadius: BorderRadius.circular(3),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.space2),
              _Legend(shade: _shade),
            ],
          ),
        ),
      ],
    );
  }
}

class _Legend extends StatelessWidget {
  const _Legend({required this.shade});
  final Color Function(int) shade;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text('Аз', style: AppTypography.caption),
        const SizedBox(width: 4),
        for (var i = 0; i < 5; i++)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 1.5),
            child: Container(
              width: 11,
              height: 11,
              decoration: BoxDecoration(
                color: shade(i),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
        const SizedBox(width: 4),
        Text('Көп', style: AppTypography.caption),
      ],
    );
  }
}
