import 'package:flutter/material.dart';

import '../../../core/constants/profile_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/utils/format.dart';

/// One stat shown in the 2×3 grid: an emoji, a big number, and a Kazakh label.
class StatItem {
  const StatItem({
    required this.emoji,
    required this.value,
    required this.label,
    required this.color,
  });

  final String emoji;
  final String value;
  final String label;
  final Color color;
}

/// A 2×3 grid of stat cards summarizing the student's accomplishments.
class StatsGrid extends StatelessWidget {
  const StatsGrid({
    super.key,
    required this.akyl,
    required this.coins,
    required this.friends,
    required this.longestStreak,
    required this.tasksCompleted,
    required this.battlesWon,
  });

  final int akyl;
  final int coins;
  final int friends;
  final int longestStreak;
  final int tasksCompleted;
  final int battlesWon;

  @override
  Widget build(BuildContext context) {
    final items = <StatItem>[
      StatItem(emoji: '★', value: formatThousands(akyl), label: ProfileStrings.statAkyl, color: AppColors.secondary),
      StatItem(emoji: '💰', value: formatThousands(coins), label: ProfileStrings.statCoins, color: AppColors.goldDeep),
      StatItem(emoji: '👥', value: '$friends', label: ProfileStrings.statFriends, color: AppColors.primary),
      StatItem(emoji: '🔥', value: '$longestStreak', label: ProfileStrings.statStreak, color: AppColors.warning),
      StatItem(emoji: '✓', value: formatThousands(tasksCompleted), label: ProfileStrings.statTasks, color: AppColors.success),
      StatItem(emoji: '⚔️', value: '$battlesWon', label: ProfileStrings.statBattles, color: AppColors.danger),
    ];

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: AppSpacing.space3,
      crossAxisSpacing: AppSpacing.space3,
      childAspectRatio: 1.7,
      children: [for (final item in items) _StatCard(item: item)],
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.item});
  final StatItem item;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.space3),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        boxShadow: const [
          BoxShadow(color: AppColors.shadow, blurRadius: 12, offset: Offset(0, 4)),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: item.color.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
            ),
            child: Text(item.emoji, style: TextStyle(fontSize: 22, color: item.color)),
          ),
          const SizedBox(width: AppSpacing.space3),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  item.value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.heading2.copyWith(
                    color: AppColors.ink,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  item.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.caption,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
