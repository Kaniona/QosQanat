import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/profile_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/friends_provider.dart';
import '../../providers/game_provider.dart';
import '../../providers/profile_provider.dart';
import '../../providers/shop_provider.dart';
import 'widgets/achievements_section.dart';
import 'widgets/activity_heatmap.dart';
import 'widgets/profile_hero.dart';
import 'widgets/recent_battles_list.dart';
import 'widgets/stats_grid.dart';

/// "Профиль" — the student's personal trophy room: hero, stats, achievements,
/// an activity heatmap, recent battles, and logout.
class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final user = ref.read(authProvider).user;
      if (user != null) {
        ref.read(gameProvider.notifier).ensureSeeded(user);
        ref.read(shopProvider.notifier).loadFor(user.id);
      }
      ref.read(friendsProvider.notifier).refresh();
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authProvider.select((s) => s.user));
    final game = ref.watch(gameProvider);
    final friends = ref.watch(friendsProvider).friends;
    final equipped = ref.watch(equippedSlotsProvider);
    final achievements = ref.watch(achievementsViewProvider);
    final recent =
        ref.watch(recentBattlesProvider).asData?.value ?? const [];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          ProfileHero(
            assistant: user?.assistantType ?? AssistantType.bektur,
            equipped: equipped,
            name: user?.fullName ?? ProfileStrings.title,
            qosqanatId: user?.qosqanatId ?? 'QQ-XXXXXXXXX',
            level: game.level,
            levelProgress: game.levelProgress,
            onEdit: () => context.go(AppRoutes.shop),
            onSettings: () => context.push(AppRoutes.settings),
            onCopyId: () => _copyId(user?.qosqanatId ?? ''),
          ),
          Padding(
            padding: const EdgeInsets.all(AppSpacing.space5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                StatsGrid(
                  akyl: game.akylPoints,
                  coins: game.coins,
                  friends: friends.length,
                  longestStreak: game.longestStreak,
                  tasksCompleted: user?.totalTasksCompleted ?? 0,
                  battlesWon: user?.totalBattlesWon ?? 0,
                ),
                const SizedBox(height: AppSpacing.space6),
                AchievementsSection(achievements: achievements),
                const SizedBox(height: AppSpacing.space6),
                ActivityHeatmap(
                  seed: (user?.id.hashCode ?? 7) ^ 0x5f3759df,
                  recentActiveDays: game.streak,
                ),
                const SizedBox(height: AppSpacing.space6),
                RecentBattlesList(battles: recent),
                const SizedBox(height: AppSpacing.space6),
                _LogoutButton(onTap: _confirmLogout),
                const SizedBox(height: AppSpacing.space6),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _copyId(String id) async {
    await Clipboard.setData(ClipboardData(text: id));
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(
        const SnackBar(
          content: Text(ProfileStrings.copied),
          duration: Duration(seconds: 1),
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  Future<void> _confirmLogout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ProfileStrings.logoutConfirmTitle, style: AppTypography.heading3),
        content: Text(ProfileStrings.logoutConfirmBody, style: AppTypography.body),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(ProfileStrings.cancel,
                style: AppTypography.button.copyWith(color: AppColors.textSecondary)),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(ProfileStrings.logout,
                style: AppTypography.button.copyWith(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    await ref.read(authProvider.notifier).signOut();
    if (mounted) context.go(AppRoutes.welcome);
  }
}

class _LogoutButton extends StatelessWidget {
  const _LogoutButton({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: TextButton.icon(
        onPressed: onTap,
        icon: const Icon(Icons.logout_rounded, color: AppColors.danger, size: 20),
        label: Text(
          ProfileStrings.logout,
          style: AppTypography.button.copyWith(color: AppColors.danger),
        ),
      ),
    );
  }
}
