import 'package:flutter/material.dart';

import '../../core/constants/tutorial_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../widgets/ui/eagle_emblem.dart';
import '../../widgets/ui/gradient_button.dart';

/// One step of the spotlight tour. [targetKey] points at the widget to
/// highlight; a null key (the finale) dims the whole screen.
class TutorialStep {
  const TutorialStep({
    this.targetKey,
    required this.title,
    required this.body,
    this.isFinale = false,
  });

  final GlobalKey? targetKey;
  final String title;
  final String body;
  final bool isFinale;
}

/// A simple, dependency-free spotlight tutorial: it dims the screen, cuts a
/// rounded hole around the current target, and shows a Kazakh explanation card
/// with a "Келесі" button — ending on a celebratory finale.
class TutorialOverlay extends StatefulWidget {
  const TutorialOverlay({
    super.key,
    required this.steps,
    required this.onFinish,
  });

  final List<TutorialStep> steps;
  final VoidCallback onFinish;

  @override
  State<TutorialOverlay> createState() => _TutorialOverlayState();
}

class _TutorialOverlayState extends State<TutorialOverlay> {
  int _index = 0;

  TutorialStep get _step => widget.steps[_index];
  bool get _isLast => _index >= widget.steps.length - 1;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _focusTarget());
  }

  void _advance() {
    if (_isLast) {
      widget.onFinish();
    } else {
      setState(() => _index++);
      WidgetsBinding.instance.addPostFrameCallback((_) => _focusTarget());
    }
  }

  /// Scrolls the current target into view (if it lives in a scrollable), then
  /// repaints so the spotlight lands on its final position.
  void _focusTarget() {
    final ctx = _step.targetKey?.currentContext;
    if (ctx == null) return;
    Scrollable.ensureVisible(
      ctx,
      duration: const Duration(milliseconds: 300),
      alignment: 0.5,
    ).then((_) {
      if (mounted) setState(() {});
    });
  }

  Rect? _targetRect() {
    final key = _step.targetKey;
    final ctx = key?.currentContext;
    if (ctx == null) return null;
    final box = ctx.findRenderObject() as RenderBox?;
    if (box == null || !box.attached) return null;
    final origin = box.localToGlobal(Offset.zero);
    return origin & box.size;
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final rect = _step.isFinale ? null : _targetRect();
    final hole = rect?.inflate(8);

    return Material(
      type: MaterialType.transparency,
      child: Stack(
        children: [
          // Dim + spotlight cutout.
          Positioned.fill(
            child: CustomPaint(
              painter: _SpotlightPainter(hole: hole),
            ),
          ),
          // Explanation card, placed clear of the highlighted area.
          _positionedCard(size, hole),
        ],
      ),
    );
  }

  Widget _positionedCard(Size size, Rect? hole) {
    final card = _StepCard(
      step: _step,
      stepNumber: _index + 1,
      total: widget.steps.length,
      isLast: _isLast,
      onNext: _advance,
    );

    if (hole == null) {
      return Center(child: Padding(
        padding: const EdgeInsets.all(AppSpacing.space6),
        child: card,
      ));
    }

    // Put the card on the opposite side of the screen from the target.
    final targetAbove = hole.center.dy < size.height / 2;
    return Positioned(
      left: AppSpacing.space5,
      right: AppSpacing.space5,
      top: targetAbove ? hole.bottom + AppSpacing.space5 : null,
      bottom: targetAbove ? null : (size.height - hole.top) + AppSpacing.space5,
      child: card,
    );
  }
}

class _SpotlightPainter extends CustomPainter {
  _SpotlightPainter({required this.hole});

  final Rect? hole;

  @override
  void paint(Canvas canvas, Size size) {
    final dim = Paint()..color = AppColors.ink.withValues(alpha: 0.82);
    final full = Offset.zero & size;

    if (hole == null) {
      canvas.drawRect(full, dim);
      return;
    }

    final rrect = RRect.fromRectAndRadius(hole!, const Radius.circular(20));
    final overlay = Path.combine(
      PathOperation.difference,
      Path()..addRect(full),
      Path()..addRRect(rrect),
    );
    canvas.drawPath(overlay, dim);

    // A soft gold ring around the spotlight.
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..color = AppColors.gold.withValues(alpha: 0.9);
    canvas.drawRRect(rrect, ring);
  }

  @override
  bool shouldRepaint(covariant _SpotlightPainter oldDelegate) =>
      oldDelegate.hole != hole;
}

class _StepCard extends StatelessWidget {
  const _StepCard({
    required this.step,
    required this.stepNumber,
    required this.total,
    required this.isLast,
    required this.onNext,
  });

  final TutorialStep step;
  final int stepNumber;
  final int total;
  final bool isLast;
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.space5),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        boxShadow: const [
          BoxShadow(color: AppColors.shadow, blurRadius: 24, offset: Offset(0, 10)),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (step.isFinale) ...[
            const Center(child: EagleEmblem(size: 72)),
            const SizedBox(height: AppSpacing.space4),
          ],
          Text(
            step.title,
            style: AppTypography.heading2.copyWith(color: AppColors.ink),
          ),
          const SizedBox(height: AppSpacing.space2),
          Text(
            step.body,
            style: AppTypography.body.copyWith(color: AppColors.textSecondary),
          ),
          const SizedBox(height: AppSpacing.space4),
          Row(
            children: [
              // Progress dots.
              if (!step.isFinale)
                Row(
                  children: [
                    for (var i = 0; i < total - 1; i++)
                      Container(
                        width: 7,
                        height: 7,
                        margin: const EdgeInsets.only(right: 5),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: i == stepNumber - 1
                              ? AppColors.primary
                              : AppColors.border,
                        ),
                      ),
                  ],
                ),
              const Spacer(),
              SizedBox(
                width: 150,
                child: GradientButton(
                  label: isLast ? TutorialStrings.start : TutorialStrings.next,
                  gradient: isLast
                      ? AppColors.goldGradient
                      : AppColors.bekturGradient,
                  height: 48,
                  onPressed: onNext,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
