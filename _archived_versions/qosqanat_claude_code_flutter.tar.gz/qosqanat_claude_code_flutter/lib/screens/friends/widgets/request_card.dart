import 'package:flutter/material.dart';

import '../../../core/constants/friends_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/friend.dart';
import '../../../widgets/ui/profile_avatar.dart';

/// A pending friend request. Incoming requests show accept/decline; outgoing
/// requests show a "Күтілуде..." status.
class RequestCard extends StatelessWidget {
  const RequestCard({
    super.key,
    required this.request,
    required this.onAccept,
    required this.onDecline,
  });

  final FriendRequest request;
  final VoidCallback onAccept;
  final VoidCallback onDecline;

  @override
  Widget build(BuildContext context) {
    final p = request.profile;
    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.space3),
      padding: const EdgeInsets.all(AppSpacing.space3),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        boxShadow: const [
          BoxShadow(color: AppColors.shadow, blurRadius: 10, offset: Offset(0, 4)),
        ],
      ),
      child: Row(
        children: [
          ProfileAvatar(name: p.fullName, assistant: p.assistantType, size: 44),
          const SizedBox(width: AppSpacing.space3),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  p.fullName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.bodyLarge.copyWith(
                    color: AppColors.ink,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(p.qosqanatId, style: AppTypography.caption),
              ],
            ),
          ),
          if (request.outgoing)
            Text(
              FriendsStrings.pending,
              style: AppTypography.caption.copyWith(color: AppColors.textTertiary),
            )
          else
            Row(
              children: [
                _Action(
                  icon: Icons.check_rounded,
                  color: AppColors.success,
                  onTap: onAccept,
                ),
                const SizedBox(width: AppSpacing.space2),
                _Action(
                  icon: Icons.close_rounded,
                  color: AppColors.danger,
                  onTap: onDecline,
                ),
              ],
            ),
        ],
      ),
    );
  }
}

class _Action extends StatelessWidget {
  const _Action({required this.icon, required this.color, required this.onTap});
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: color.withValues(alpha: 0.12),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Icon(icon, color: color, size: 22),
        ),
      ),
    );
  }
}
