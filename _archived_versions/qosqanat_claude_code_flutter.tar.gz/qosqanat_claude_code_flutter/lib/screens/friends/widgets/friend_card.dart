import 'package:flutter/material.dart';

import '../../../core/constants/friends_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/friend.dart';
import '../../../widgets/ui/profile_avatar.dart';

/// A friend row: avatar with online dot, name, QQ-id, level badge, akyl points,
/// and the battle / profile actions.
class FriendCard extends StatelessWidget {
  const FriendCard({
    super.key,
    required this.profile,
    required this.onBattle,
    required this.onProfile,
  });

  final PublicProfile profile;
  final VoidCallback onBattle;
  final VoidCallback onProfile;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.space3),
      padding: const EdgeInsets.all(AppSpacing.space3),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        boxShadow: const [
          BoxShadow(color: AppColors.shadow, blurRadius: 10, offset: Offset(0, 4)),
        ],
      ),
      child: Row(
        children: [
          ProfileAvatar(
            name: profile.fullName,
            assistant: profile.assistantType,
            online: profile.isOnline,
            size: 48,
          ),
          const SizedBox(width: AppSpacing.space3),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  profile.fullName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.bodyLarge.copyWith(
                    color: AppColors.ink,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(profile.qosqanatId, style: AppTypography.caption),
                const SizedBox(height: 4),
                Row(
                  children: [
                    _Badge(
                      label: FriendsStrings.levelBadge(profile.level),
                      color: AppColors.primary,
                    ),
                    const SizedBox(width: AppSpacing.space2),
                    _Badge(label: '★ ${profile.akylPoints}', color: AppColors.secondary),
                  ],
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: onProfile,
            icon: const Icon(Icons.person_rounded, color: AppColors.textTertiary),
          ),
          _BattleButton(onTap: onBattle),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge({required this.label, required this.color});
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
      ),
      child: Text(
        label,
        style: AppTypography.caption.copyWith(color: color, fontWeight: FontWeight.w800),
      ),
    );
  }
}

class _BattleButton extends StatelessWidget {
  const _BattleButton({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.space3,
            vertical: AppSpacing.space2,
          ),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppColors.secondaryLight, AppColors.secondary],
            ),
            borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
          ),
          child: Text(
            FriendsStrings.battle,
            style: AppTypography.caption.copyWith(
              color: AppColors.white,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ),
    );
  }
}
