import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/friends_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/friend.dart';
import '../../../providers/friends_provider.dart';
import '../../../widgets/ui/gradient_button.dart';
import '../../../widgets/ui/profile_avatar.dart';

/// The "Іздеу" tab: a QQ-id input, a found-user result card, or a friendly
/// empty state.
class SearchPanel extends ConsumerStatefulWidget {
  const SearchPanel({super.key});

  @override
  ConsumerState<SearchPanel> createState() => _SearchPanelState();
}

class _SearchPanelState extends ConsumerState<SearchPanel> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _search() {
    FocusScope.of(context).unfocus();
    final raw = _controller.text.trim();
    if (raw.isEmpty) return;
    final query = raw.toUpperCase().startsWith('QQ-') ? raw : 'QQ-$raw';
    ref.read(friendsProvider.notifier).search(query);
  }

  Future<void> _add(PublicProfile profile) async {
    final ok = await ref.read(friendsProvider.notifier).sendRequest(profile.id);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(ok ? FriendsStrings.requestSent : ref.read(friendsProvider).error ?? ''),
        backgroundColor: ok ? AppColors.success : AppColors.danger,
        behavior: SnackBarBehavior.floating,
      ));
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(friendsProvider);

    return ListView(
      padding: const EdgeInsets.all(AppSpacing.space5),
      children: [
        _SearchField(controller: _controller, onSubmit: _search),
        const SizedBox(height: AppSpacing.space5),
        if (state.searching)
          const Center(child: CircularProgressIndicator())
        else if (state.searchResult != null)
          _ResultCard(profile: state.searchResult!, onAdd: () => _add(state.searchResult!))
        else if (state.searched)
          const _SearchMessage(emoji: '🔍', text: FriendsStrings.notFound)
        else
          const _SearchMessage(emoji: '🧭', text: FriendsStrings.searchEmpty),
      ],
    );
  }
}

class _SearchField extends StatelessWidget {
  const _SearchField({required this.controller, required this.onSubmit});
  final TextEditingController controller;
  final VoidCallback onSubmit;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      textCapitalization: TextCapitalization.characters,
      onSubmitted: (_) => onSubmit(),
      inputFormatters: [UpperCaseFormatter()],
      style: AppTypography.bodyLarge.copyWith(
        color: AppColors.ink,
        fontWeight: FontWeight.w700,
        letterSpacing: 1.2,
      ),
      decoration: InputDecoration(
        hintText: FriendsStrings.searchHint,
        prefixIcon: const Icon(Icons.badge_rounded, color: AppColors.primary),
        suffixIcon: IconButton(
          onPressed: onSubmit,
          icon: const Icon(Icons.search_rounded, color: AppColors.primary),
        ),
        filled: true,
        fillColor: AppColors.surface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
          borderSide: const BorderSide(color: AppColors.primary, width: 2),
        ),
      ),
    );
  }
}

/// Forces input to upper case so QQ-ids read consistently.
class UpperCaseFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue old, TextEditingValue value) {
    return value.copyWith(text: value.text.toUpperCase());
  }
}

class _ResultCard extends StatelessWidget {
  const _ResultCard({required this.profile, required this.onAdd});
  final PublicProfile profile;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.space5),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        boxShadow: const [
          BoxShadow(color: AppColors.shadow, blurRadius: 16, offset: Offset(0, 6)),
        ],
      ),
      child: Column(
        children: [
          ProfileAvatar(
            name: profile.fullName,
            assistant: profile.assistantType,
            size: 80,
            ring: true,
          ),
          const SizedBox(height: AppSpacing.space3),
          Text(
            profile.fullName,
            style: AppTypography.heading3.copyWith(color: AppColors.ink),
          ),
          Text(profile.qosqanatId, style: AppTypography.caption),
          const SizedBox(height: AppSpacing.space3),
          Wrap(
            alignment: WrapAlignment.center,
            spacing: AppSpacing.space2,
            runSpacing: AppSpacing.space2,
            children: [
              _Chip(label: FriendsStrings.levelBadge(profile.level), color: AppColors.primary),
              _Chip(label: '★ ${profile.akylPoints}', color: AppColors.secondary),
              if (profile.city != null) _Chip(label: '📍 ${profile.city}', color: AppColors.info),
              if (profile.school != null) _Chip(label: '🏫 ${profile.school}', color: AppColors.success),
            ],
          ),
          const SizedBox(height: AppSpacing.space5),
          GradientButton(
            label: FriendsStrings.addFriend,
            gradient: AppColors.bekturGradient,
            onPressed: onAdd,
          ),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.label, required this.color});
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space3, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
      ),
      child: Text(
        label,
        style: AppTypography.caption.copyWith(color: color, fontWeight: FontWeight.w700),
      ),
    );
  }
}

class _SearchMessage extends StatelessWidget {
  const _SearchMessage({required this.emoji, required this.text});
  final String emoji;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: AppSpacing.space12),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 64)),
          const SizedBox(height: AppSpacing.space4),
          Text(
            text,
            textAlign: TextAlign.center,
            style: AppTypography.bodyLarge.copyWith(color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }
}
