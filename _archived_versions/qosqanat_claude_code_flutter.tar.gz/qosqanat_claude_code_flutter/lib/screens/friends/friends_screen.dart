import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/friends_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../navigation/app_router.dart';
import '../../providers/friends_provider.dart';
import 'widgets/friend_card.dart';
import 'widgets/request_card.dart';
import 'widgets/search_panel.dart';

/// "👥 Достар" — the social hub with Friends / Requests / Search tabs.
class FriendsScreen extends ConsumerStatefulWidget {
  const FriendsScreen({super.key});

  @override
  ConsumerState<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends ConsumerState<FriendsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => ref.read(friendsProvider.notifier).refresh(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(friendsProvider);

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: AppColors.background,
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.space4,
                  AppSpacing.space4,
                  AppSpacing.space5,
                  AppSpacing.space2,
                ),
                child: Row(
                  children: [
                    // Only shown when pushed (not as a root tab).
                    if (context.canPop()) ...[
                      GestureDetector(
                        onTap: () => _back(context),
                        behavior: HitTestBehavior.opaque,
                        child: const Icon(Icons.arrow_back_rounded, color: AppColors.ink),
                      ),
                      const SizedBox(width: AppSpacing.space3),
                    ],
                    Text(
                      FriendsStrings.title,
                      style: AppTypography.heading1.copyWith(color: AppColors.ink),
                    ),
                  ],
                ),
              ),
              TabBar(
                labelColor: AppColors.primary,
                unselectedLabelColor: AppColors.textTertiary,
                indicatorColor: AppColors.primary,
                labelStyle: AppTypography.button,
                tabs: [
                  const Tab(text: FriendsStrings.tabFriends),
                  Tab(child: _RequestsTabLabel(count: state.pendingIncomingCount)),
                  const Tab(text: FriendsStrings.tabSearch),
                ],
              ),
              const Expanded(
                child: TabBarView(
                  children: [
                    _FriendsTab(),
                    _RequestsTab(),
                    SearchPanel(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _back(BuildContext context) {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go(AppRoutes.home);
    }
  }
}

class _RequestsTabLabel extends StatelessWidget {
  const _RequestsTabLabel({required this.count});
  final int count;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Text(FriendsStrings.tabRequests),
        if (count > 0) ...[
          const SizedBox(width: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
            decoration: const BoxDecoration(
              color: AppColors.danger,
              shape: BoxShape.circle,
            ),
            child: Text(
              '$count',
              style: AppTypography.caption.copyWith(
                color: AppColors.white,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ],
    );
  }
}

// ── Friends tab ─────────────────────────────────────────────────────────────

class _FriendsTab extends ConsumerWidget {
  const _FriendsTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(friendsProvider);
    final notifier = ref.read(friendsProvider.notifier);

    if (state.loading && state.friends.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (state.friends.isEmpty) {
      return const _EmptyState(emoji: '🧍', text: FriendsStrings.friendsEmpty);
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.space5,
            AppSpacing.space3,
            AppSpacing.space5,
            0,
          ),
          child: Row(
            children: [
              const Spacer(),
              _SortDropdown(
                value: notifier.sort,
                onChanged: notifier.setSort,
              ),
            ],
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: notifier.refresh,
            child: ListView.builder(
              padding: const EdgeInsets.all(AppSpacing.space5),
              itemCount: state.friends.length,
              itemBuilder: (context, i) {
                final friend = state.friends[i];
                return FriendCard(
                  profile: friend,
                  onBattle: () =>
                      context.push(AppRoutes.battleSetup, extra: friend),
                  onProfile: () {},
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

class _SortDropdown extends StatelessWidget {
  const _SortDropdown({required this.value, required this.onChanged});
  final FriendSort value;
  final ValueChanged<FriendSort> onChanged;

  @override
  Widget build(BuildContext context) {
    return DropdownButton<FriendSort>(
      value: value,
      underline: const SizedBox.shrink(),
      icon: const Icon(Icons.sort_rounded, color: AppColors.textSecondary),
      style: AppTypography.bodySmall.copyWith(color: AppColors.ink),
      items: const [
        DropdownMenuItem(value: FriendSort.akyl, child: Text(FriendsStrings.sortByAkyl)),
        DropdownMenuItem(value: FriendSort.level, child: Text(FriendsStrings.sortByLevel)),
        DropdownMenuItem(value: FriendSort.name, child: Text(FriendsStrings.sortByName)),
      ],
      onChanged: (v) => v == null ? null : onChanged(v),
    );
  }
}

// ── Requests tab ──────────────────────────────────────────────────────────

class _RequestsTab extends ConsumerWidget {
  const _RequestsTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(friendsProvider);
    final notifier = ref.read(friendsProvider.notifier);
    final requests = [...state.incoming, ...state.outgoing];

    if (requests.isEmpty) {
      return const _EmptyState(emoji: '📭', text: FriendsStrings.requestsEmpty);
    }

    return ListView.builder(
      padding: const EdgeInsets.all(AppSpacing.space5),
      itemCount: requests.length,
      itemBuilder: (context, i) {
        final r = requests[i];
        return RequestCard(
          request: r,
          onAccept: () => notifier.accept(r.id),
          onDecline: () => notifier.decline(r.id),
        );
      },
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.emoji, required this.text});
  final String emoji;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.space8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 64)),
            const SizedBox(height: AppSpacing.space4),
            Text(
              text,
              textAlign: TextAlign.center,
              style: AppTypography.bodyLarge.copyWith(color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}
