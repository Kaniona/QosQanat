import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_strings.dart';
import '../../core/constants/auth_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../navigation/app_router.dart';
import '../../services/supabase_service.dart';
import '../../widgets/ui/eagle_emblem.dart';
import '../../widgets/ui/floating_particles.dart';

/// Epic first impression: the eagle emblem flies in, particles drift, then
/// after 2.5s we route to Home (if a session exists) or Welcome.
class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer(const Duration(milliseconds: 2500), _decideNextRoute);
  }

  void _decideNextRoute() {
    if (!mounted) return;
    if (SupabaseService.isSignedIn) {
      context.go(AppRoutes.home);
    } else {
      context.go(AppRoutes.welcome);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.heroGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: FloatingParticles()),
            SafeArea(
              child: Column(
                children: [
                  const Spacer(flex: 3),
                  // Emblem flies up from below and fades in with a spring curve.
                  const EagleEmblem(size: 132)
                      .animate()
                      .fadeIn(duration: 700.ms)
                      .slideY(
                        begin: 0.6,
                        end: 0,
                        duration: 900.ms,
                        curve: Curves.elasticOut,
                      ),
                  const SizedBox(height: AppSpacing.space6),
                  Text(
                    AppStrings.appName,
                    style: AppTypography.displayHuge
                        .copyWith(color: AppColors.white),
                  )
                      .animate(delay: 350.ms)
                      .fadeIn(duration: 600.ms)
                      .slideY(begin: 0.3, end: 0, curve: Curves.easeOut),
                  const SizedBox(height: AppSpacing.space2),
                  Text(
                    AuthStrings.splashTagline,
                    style: AppTypography.bodyLarge.copyWith(
                      color: AppColors.white.withValues(alpha: 0.8),
                      fontStyle: FontStyle.italic,
                    ),
                  ).animate(delay: 650.ms).fadeIn(duration: 600.ms),
                  const Spacer(flex: 3),
                  // Slim gold loading bar.
                  SizedBox(
                    width: 160,
                    child: ClipRRect(
                      borderRadius:
                          BorderRadius.circular(AppSpacing.radiusFull),
                      child: const LinearProgressIndicator(
                        minHeight: 4,
                        backgroundColor: Colors.white24,
                        valueColor:
                            AlwaysStoppedAnimation<Color>(AppColors.gold),
                      ),
                    ),
                  ).animate(delay: 800.ms).fadeIn(),
                  const SizedBox(height: AppSpacing.space4),
                  Text(
                    AppStrings.loading,
                    style: AppTypography.caption
                        .copyWith(color: AppColors.white.withValues(alpha: 0.7)),
                  ).animate(delay: 800.ms).fadeIn(),
                  const SizedBox(height: AppSpacing.space10),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
