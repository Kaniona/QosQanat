import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_strings.dart';
import '../../core/constants/auth_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/avatar/avatar_display.dart';
import '../../widgets/ui/floating_particles.dart';
import '../../widgets/ui/gradient_button.dart';
import 'welcome_gift_modal.dart';

/// The emotional peak of onboarding: choose Bektur or Nazym.
class AssistantSelectScreen extends ConsumerStatefulWidget {
  const AssistantSelectScreen({super.key});

  @override
  ConsumerState<AssistantSelectScreen> createState() =>
      _AssistantSelectScreenState();
}

class _AssistantSelectScreenState
    extends ConsumerState<AssistantSelectScreen> {
  AssistantType? _selected;

  Future<void> _confirm() async {
    final type = _selected;
    if (type == null) return;

    final ok = await ref.read(authProvider.notifier).setAssistant(type);
    if (!mounted) return;
    if (!ok) {
      final error = ref.read(authProvider).error ?? AppStrings.errorGeneric;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(error)));
      return;
    }

    await showWelcomeGift(context, assistant: type);
    if (!mounted) return;
    await ref.read(authProvider.notifier).grantWelcomeGift();
    if (!mounted) return;
    context.go(AppRoutes.home);
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = ref.watch(authProvider).isLoading;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.heroGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: FloatingParticles(count: 36)),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(AppSpacing.space5),
                child: Column(
                  children: [
                    const SizedBox(height: AppSpacing.space4),
                    Text(
                      AuthStrings.assistantTitle,
                      textAlign: TextAlign.center,
                      style: AppTypography.displayLarge.copyWith(
                        color: AppColors.white,
                        shadows: [
                          const Shadow(
                            color: AppColors.gold,
                            blurRadius: 24,
                          ),
                        ],
                      ),
                    ).animate().fadeIn(duration: 600.ms).slideY(begin: -0.2, end: 0),
                    const SizedBox(height: AppSpacing.space3),
                    Text(
                      AuthStrings.assistantSubtitle,
                      textAlign: TextAlign.center,
                      style: AppTypography.body.copyWith(
                        color: AppColors.white.withValues(alpha: 0.85),
                      ),
                    ).animate(delay: 200.ms).fadeIn(),
                    const Spacer(),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: _AssistantCard(
                            type: AssistantType.bektur,
                            name: AuthStrings.bekturName,
                            tags: AuthStrings.bekturTags,
                            bio: AuthStrings.bekturBio,
                            selected: _selected == AssistantType.bektur,
                            dimmed: _selected == AssistantType.nazym,
                            onTap: () => setState(
                                () => _selected = AssistantType.bektur),
                          ),
                        ),
                        const SizedBox(width: AppSpacing.space3),
                        Expanded(
                          child: _AssistantCard(
                            type: AssistantType.nazym,
                            name: AuthStrings.nazymName,
                            tags: AuthStrings.nazymTags,
                            bio: AuthStrings.nazymBio,
                            selected: _selected == AssistantType.nazym,
                            dimmed: _selected == AssistantType.bektur,
                            onTap: () => setState(
                                () => _selected = AssistantType.nazym),
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    // Confirm button appears only after a choice is made.
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      child: _selected == null
                          ? const SizedBox(height: 56)
                          : GradientButton(
                              key: const ValueKey('confirm'),
                              label: AuthStrings.assistantConfirm,
                              gradient: AppColors.goldGradient,
                              isLoading: isLoading,
                              onPressed: isLoading ? null : _confirm,
                            ),
                    ),
                    const SizedBox(height: AppSpacing.space4),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AssistantCard extends StatelessWidget {
  const _AssistantCard({
    required this.type,
    required this.name,
    required this.tags,
    required this.bio,
    required this.selected,
    required this.dimmed,
    required this.onTap,
  });

  final AssistantType type;
  final String name;
  final String tags;
  final String bio;
  final bool selected;
  final bool dimmed;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final accent = type == AssistantType.bektur
        ? AppColors.bekturBlue
        : AppColors.nazymPink;

    return AnimatedOpacity(
      duration: const Duration(milliseconds: 300),
      opacity: dimmed ? 0.6 : 1,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
        scale: selected ? 1.05 : (dimmed ? 0.95 : 1.0),
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(AppSpacing.space4),
            decoration: BoxDecoration(
              color: AppColors.white.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(AppSpacing.radiusXl),
              border: Border.all(
                color: selected ? AppColors.gold : Colors.white24,
                width: selected ? 3 : 1,
              ),
              boxShadow: selected
                  ? [
                      BoxShadow(
                        color: AppColors.gold.withValues(alpha: 0.55),
                        blurRadius: 28,
                        spreadRadius: 2,
                      ),
                    ]
                  : null,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    AvatarDisplay(
                      type: type,
                      size: 110,
                      state: selected
                          ? AvatarAnimationState.wave
                          : AvatarAnimationState.idle,
                    ),
                    if (selected)
                      Positioned(
                        top: 0,
                        right: 6,
                        child: const Icon(Icons.auto_awesome,
                                color: AppColors.gold, size: 26)
                            .animate()
                            .scaleXY(
                              begin: 0,
                              end: 1,
                              curve: Curves.elasticOut,
                              duration: 600.ms,
                            ),
                      ),
                  ],
                ),
                const SizedBox(height: AppSpacing.space3),
                Text(
                  name,
                  style: AppTypography.heading2.copyWith(color: AppColors.white),
                ),
                const SizedBox(height: AppSpacing.space1),
                Text(
                  tags,
                  textAlign: TextAlign.center,
                  style: AppTypography.caption.copyWith(color: accent),
                ),
                const SizedBox(height: AppSpacing.space2),
                Text(
                  bio,
                  textAlign: TextAlign.center,
                  style: AppTypography.caption.copyWith(
                    color: AppColors.white.withValues(alpha: 0.75),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
