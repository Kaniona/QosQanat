import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/auth_strings.dart';
import '../../core/constants/kz_data.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/validators.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/registration_provider.dart';
import '../../widgets/ui/gradient_button.dart';

/// Whether the auth screen is showing the login or the registration flow.
enum _AuthMode { login, register }

/// Auth screen hosting two sections: "Кіру" (login) for returning students and
/// "Тіркелу" (a three-step registration: personal → school → review).
class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  static const int _stepCount = 3;

  final PageController _pageController = PageController();
  final _step1FormKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _iinController = TextEditingController();
  final _schoolController = TextEditingController();

  // Login section controllers.
  final _loginFormKey = GlobalKey<FormState>();
  final _loginPhoneController = TextEditingController();
  final _loginPasswordController = TextEditingController();

  _AuthMode _mode = _AuthMode.register;
  int _step = 0;
  bool _step2Tried = false;

  @override
  void dispose() {
    _pageController.dispose();
    _nameController.dispose();
    _phoneController.dispose();
    _iinController.dispose();
    _schoolController.dispose();
    _loginPhoneController.dispose();
    _loginPasswordController.dispose();
    super.dispose();
  }

  void _setMode(_AuthMode mode) {
    if (mode == _mode) return;
    setState(() => _mode = mode);
  }

  void _goTo(int step) {
    setState(() => _step = step);
    _pageController.animateToPage(
      step,
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOutCubic,
    );
  }

  void _onBack() {
    if (_mode == _AuthMode.login || _step == 0) {
      context.go(AppRoutes.welcome);
    } else {
      _goTo(_step - 1);
    }
  }

  Future<void> _login() async {
    if (!(_loginFormKey.currentState?.validate() ?? false)) return;
    final ok = await ref.read(authProvider.notifier).signIn(
          phone: _loginPhoneController.text,
          password: _loginPasswordController.text,
        );
    if (!mounted) return;
    if (ok) {
      context.go(AppRoutes.home);
    } else {
      final error = ref.read(authProvider).error ?? AuthStrings.loginFailed;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
    }
  }

  void _onNext() {
    final reg = ref.read(registrationProvider);
    if (_step == 0) {
      if (_step1FormKey.currentState?.validate() ?? false) _goTo(1);
    } else if (_step == 1) {
      setState(() => _step2Tried = true);
      if (reg.isStep2Valid) _goTo(2);
    }
  }

  Future<void> _submit() async {
    final ok = await ref.read(authProvider.notifier).register();
    if (!mounted) return;
    if (ok) {
      ref.read(registrationProvider.notifier).reset();
      context.go(AppRoutes.assistantSelect);
    } else {
      final error = ref.read(authProvider).error ?? AuthStrings.registerFailed;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _Header(
              mode: _mode,
              step: _step,
              stepCount: _stepCount,
              onBack: _onBack,
              onModeChanged: _setMode,
            ),
            Expanded(
              child: _mode == _AuthMode.login
                  ? _buildLogin()
                  : PageView(
                      controller: _pageController,
                      physics: const NeverScrollableScrollPhysics(),
                      children: [
                        _buildStep1(),
                        _buildStep2(),
                        _buildStep3(),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Login section ──────────────────────────────────────────────────────
  Widget _buildLogin() {
    final auth = ref.watch(authProvider);
    return _StepScaffold(
      title: AuthStrings.loginTitle,
      footer: Column(
        children: [
          GradientButton(
            label: AuthStrings.loginButton,
            isLoading: auth.isLoading,
            onPressed: auth.isLoading ? null : _login,
          ),
          const SizedBox(height: AppSpacing.space2),
          TextButton(
            onPressed: () => _setMode(_AuthMode.register),
            child: Text.rich(
              TextSpan(
                text: AuthStrings.noAccountPrompt,
                style: AppTypography.bodySmall
                    .copyWith(color: AppColors.textSecondary),
                children: [
                  TextSpan(
                    text: AuthStrings.noAccountAction,
                    style: AppTypography.bodySmall.copyWith(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      child: Form(
        key: _loginFormKey,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              AuthStrings.loginSubtitle,
              style: AppTypography.body.copyWith(color: AppColors.textSecondary),
            ),
            const SizedBox(height: AppSpacing.space6),
            _FieldLabel(AuthStrings.labelPhone),
            TextFormField(
              controller: _loginPhoneController,
              keyboardType: TextInputType.phone,
              inputFormatters: [PhoneInputFormatter()],
              decoration: const InputDecoration(hintText: '+7 (___) ___-__-__'),
              validator: Validators.phone,
            ),
            const SizedBox(height: AppSpacing.space5),
            _FieldLabel(AuthStrings.labelPassword),
            TextFormField(
              controller: _loginPasswordController,
              keyboardType: TextInputType.number,
              obscureText: true,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(12),
              ],
              decoration: const InputDecoration(
                hintText: AuthStrings.hintPassword,
              ),
              validator: (value) => (value == null || value.trim().isEmpty)
                  ? AuthStrings.passwordRequired
                  : null,
              onFieldSubmitted: (_) => _login(),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Step 1 · personal ──────────────────────────────────────────────────
  Widget _buildStep1() {
    final notifier = ref.read(registrationProvider.notifier);
    return _StepScaffold(
      title: AuthStrings.stepPersonal,
      footer: GradientButton(label: 'Келесі', onPressed: _onNext),
      child: Form(
        key: _step1FormKey,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _FieldLabel(AuthStrings.labelFullName),
            TextFormField(
              controller: _nameController,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(hintText: AuthStrings.hintFullName),
              validator: Validators.fullName,
              onChanged: notifier.setFullName,
            ),
            const SizedBox(height: AppSpacing.space5),
            _FieldLabel(AuthStrings.labelPhone),
            TextFormField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              inputFormatters: [PhoneInputFormatter()],
              decoration: const InputDecoration(hintText: '+7 (___) ___-__-__'),
              validator: Validators.phone,
              onChanged: notifier.setPhone,
            ),
            const SizedBox(height: AppSpacing.space5),
            _FieldLabel(AuthStrings.labelIin),
            TextFormField(
              controller: _iinController,
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(12),
              ],
              decoration: const InputDecoration(
                hintText: '000000000000',
                helperText: AuthStrings.helperIin,
              ),
              validator: Validators.iin,
              onChanged: notifier.setIin,
            ),
          ],
        ),
      ),
    );
  }

  // ─── Step 2 · school ────────────────────────────────────────────────────
  Widget _buildStep2() {
    final reg = ref.watch(registrationProvider);
    final notifier = ref.read(registrationProvider.notifier);
    final showCityError = _step2Tried && (reg.city == null);
    final showSchoolError = _step2Tried && reg.school.trim().isEmpty;
    final showGradeError = _step2Tried && reg.grade == null;

    return _StepScaffold(
      title: AuthStrings.stepSchool,
      footer: GradientButton(label: 'Келесі', onPressed: _onNext),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _FieldLabel(AuthStrings.labelCity),
          DropdownButtonFormField<String>(
            initialValue: reg.city,
            isExpanded: true,
            decoration: InputDecoration(
              hintText: AuthStrings.hintCity,
              errorText: showCityError ? 'Қалаңды таңда' : null,
            ),
            items: [
              for (final c in KzData.cities)
                DropdownMenuItem(value: c, child: Text(c)),
            ],
            onChanged: notifier.setCity,
          ),
          const SizedBox(height: AppSpacing.space5),
          _FieldLabel(AuthStrings.labelSchool),
          TextField(
            controller: _schoolController,
            decoration: InputDecoration(
              hintText: AuthStrings.hintSchool,
              errorText: showSchoolError ? 'Мектебіңді жаз' : null,
            ),
            onChanged: notifier.setSchool,
          ),
          const SizedBox(height: AppSpacing.space5),
          _FieldLabel(AuthStrings.labelGrade),
          _GradeSelector(
            selected: reg.grade,
            onSelect: notifier.setGrade,
          ),
          if (showGradeError)
            Padding(
              padding: const EdgeInsets.only(top: AppSpacing.space2),
              child: Text(
                'Сыныбыңды таңда',
                style: AppTypography.caption.copyWith(color: AppColors.danger),
              ),
            ),
        ],
      ),
    );
  }

  // ─── Step 3 · review ────────────────────────────────────────────────────
  Widget _buildStep3() {
    final reg = ref.watch(registrationProvider);
    final auth = ref.watch(authProvider);

    return _StepScaffold(
      title: AuthStrings.stepReview,
      footer: GradientButton(
        label: AuthStrings.registerTitle,
        gradient: AppColors.bekturGradient,
        isLoading: auth.isLoading,
        onPressed: reg.hasAgreed && !auth.isLoading ? _submit : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(AuthStrings.reviewTitle, style: AppTypography.heading3),
          const SizedBox(height: AppSpacing.space4),
          Container(
            padding: const EdgeInsets.all(AppSpacing.space5),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              children: [
                _SummaryRow(label: AuthStrings.labelFullName, value: reg.fullName),
                _SummaryRow(label: AuthStrings.labelPhone, value: Mask.phone(reg.phone)),
                _SummaryRow(label: AuthStrings.labelIin, value: Mask.iin(reg.iin)),
                _SummaryRow(label: AuthStrings.labelCity, value: reg.city ?? '—'),
                _SummaryRow(label: AuthStrings.labelSchool, value: reg.school),
                _SummaryRow(
                  label: AuthStrings.labelGrade,
                  value: reg.grade == null ? '—' : '${reg.grade}-сынып',
                  isLast: true,
                ),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.space5),
          _AgreementCheckbox(
            value: reg.agreedTerms,
            label: AuthStrings.agreeTerms,
            onChanged: ref.read(registrationProvider.notifier).setAgreedTerms,
          ),
          _AgreementCheckbox(
            value: reg.agreedData,
            label: AuthStrings.agreeData,
            onChanged: ref.read(registrationProvider.notifier).setAgreedData,
          ),
        ],
      ),
    );
  }
}

// ─── Shared step chrome ─────────────────────────────────────────────────────

class _Header extends StatelessWidget {
  const _Header({
    required this.mode,
    required this.step,
    required this.stepCount,
    required this.onBack,
    required this.onModeChanged,
  });

  final _AuthMode mode;
  final int step;
  final int stepCount;
  final VoidCallback onBack;
  final ValueChanged<_AuthMode> onModeChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.space2,
            vertical: AppSpacing.space2,
          ),
          child: Row(
            children: [
              IconButton(
                onPressed: onBack,
                icon: const Icon(Icons.arrow_back_rounded),
                color: AppColors.textPrimary,
              ),
              Expanded(
                child: Center(
                  child: _AuthModeToggle(mode: mode, onChanged: onModeChanged),
                ),
              ),
              // Balances the leading icon so the toggle stays centered.
              const SizedBox(width: 48),
            ],
          ),
        ),
        // Step dots only apply to the multi-step registration flow.
        if (mode == _AuthMode.register) ...[
          const SizedBox(height: AppSpacing.space2),
          _StepDots(step: step, count: stepCount),
        ],
        const SizedBox(height: AppSpacing.space2),
      ],
    );
  }
}

/// Pill segmented control switching between the login and registration views.
class _AuthModeToggle extends StatelessWidget {
  const _AuthModeToggle({required this.mode, required this.onChanged});

  final _AuthMode mode;
  final ValueChanged<_AuthMode> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppColors.surfaceMuted,
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _segment(AuthStrings.tabLogin, _AuthMode.login),
          _segment(AuthStrings.tabRegister, _AuthMode.register),
        ],
      ),
    );
  }

  Widget _segment(String label, _AuthMode value) {
    final active = mode == value;
    return GestureDetector(
      onTap: () => onChanged(value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        decoration: BoxDecoration(
          color: active ? AppColors.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
        ),
        child: Text(
          label,
          style: AppTypography.button.copyWith(
            color: active ? AppColors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}

/// Lays out a step: a scrollable body + a pinned footer button.
class _StepScaffold extends StatelessWidget {
  const _StepScaffold({
    required this.title,
    required this.child,
    required this.footer,
  });

  final String title;
  final Widget child;
  final Widget footer;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(
              AppSpacing.space6,
              AppSpacing.space4,
              AppSpacing.space6,
              AppSpacing.space6,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: AppTypography.heading1),
                const SizedBox(height: AppSpacing.space6),
                child,
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.space6,
            AppSpacing.space2,
            AppSpacing.space6,
            AppSpacing.space6,
          ),
          child: footer,
        ),
      ],
    );
  }
}

/// The 3-dot step indicator; the active dot is gold and elongated.
class _StepDots extends StatelessWidget {
  const _StepDots({required this.step, required this.count});

  final int step;
  final int count;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(count, (i) {
        final active = i == step;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: active ? 28 : 10,
          height: 10,
          decoration: BoxDecoration(
            color: active ? AppColors.gold : AppColors.border,
            borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
          ),
        );
      }),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  const _FieldLabel(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.space2, left: 4),
      child: Text(text, style: AppTypography.bodySmall.copyWith(
        color: AppColors.textPrimary,
        fontWeight: FontWeight.w600,
      )),
    );
  }
}

/// Horizontally-scrolling grade pills (1–11).
class _GradeSelector extends StatelessWidget {
  const _GradeSelector({required this.selected, required this.onSelect});

  final int? selected;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 56,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: KzData.grades.length,
        separatorBuilder: (_, _) => const SizedBox(width: AppSpacing.space3),
        itemBuilder: (context, i) {
          final grade = KzData.grades[i];
          final isSelected = grade == selected;
          return GestureDetector(
            onTap: () => onSelect(grade),
            child: AnimatedScale(
              scale: isSelected ? 1.12 : 1.0,
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOut,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 52,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  gradient: isSelected ? AppColors.goldGradient : null,
                  color: isSelected ? null : AppColors.surfaceMuted,
                  borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                  border: Border.all(
                    color: isSelected ? AppColors.goldDeep : AppColors.border,
                  ),
                ),
                child: Text(
                  '$grade',
                  style: AppTypography.bodyLarge.copyWith(
                    fontWeight: FontWeight.w800,
                    color: isSelected ? AppColors.ink : AppColors.textSecondary,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({
    required this.label,
    required this.value,
    this.isLast = false,
  });

  final String label;
  final String value;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: isLast ? 0 : AppSpacing.space3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 2,
            child: Text(label,
                style: AppTypography.bodySmall
                    .copyWith(color: AppColors.textSecondary)),
          ),
          Expanded(
            flex: 3,
            child: Text(
              value.isEmpty ? '—' : value,
              textAlign: TextAlign.right,
              style: AppTypography.body
                  .copyWith(fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}

class _AgreementCheckbox extends StatelessWidget {
  const _AgreementCheckbox({
    required this.value,
    required this.label,
    required this.onChanged,
  });

  final bool value;
  final String label;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
      onTap: () => onChanged(!value),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: AppSpacing.space2),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Checkbox(
              value: value,
              onChanged: (v) => onChanged(v ?? false),
              activeColor: AppColors.primary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(6),
              ),
            ),
            Expanded(
              child: Text(label, style: AppTypography.bodySmall
                  .copyWith(color: AppColors.textPrimary)),
            ),
          ],
        ),
      ),
    );
  }
}
