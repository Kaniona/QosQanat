import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../core/constants/auth_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../widgets/avatar/avatar_display.dart';
import '../../widgets/ui/gradient_button.dart';

/// Shows the celebratory 100-coin welcome gift. Resolves when the user taps
/// continue, so the caller can grant the gift and route to Home.
Future<void> showWelcomeGift(
  BuildContext context, {
  required AssistantType assistant,
}) {
  return showDialog<void>(
    context: context,
    barrierDismissible: false,
    barrierColor: AppColors.ink.withValues(alpha: 0.6),
    builder: (context) => _WelcomeGiftDialog(assistant: assistant),
  );
}

class _WelcomeGiftDialog extends StatefulWidget {
  const _WelcomeGiftDialog({required this.assistant});

  final AssistantType assistant;

  @override
  State<_WelcomeGiftDialog> createState() => _WelcomeGiftDialogState();
}

class _WelcomeGiftDialogState extends State<_WelcomeGiftDialog> {
  late final ConfettiController _confetti;

  @override
  void initState() {
    super.initState();
    _confetti = ConfettiController(duration: const Duration(seconds: 2))..play();
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.topCenter,
      children: [
        Center(
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.space6),
            child: Container(
              padding: const EdgeInsets.all(AppSpacing.space6),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(AppSpacing.radiusXl),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AvatarDisplay(
                    type: widget.assistant,
                    size: 130,
                    state: AvatarAnimationState.celebrate,
                  ),
                  const SizedBox(height: AppSpacing.space5),
                  Text(
                    AuthStrings.giftTitle,
                    textAlign: TextAlign.center,
                    style: AppTypography.heading2,
                  ),
                  const SizedBox(height: AppSpacing.space5),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppSpacing.space6,
                      vertical: AppSpacing.space3,
                    ),
                    decoration: BoxDecoration(
                      gradient: AppColors.goldGradient,
                      borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
                    ),
                    child: Text(
                      AuthStrings.giftReward,
                      style: AppTypography.numberDisplay
                          .copyWith(fontSize: 28, color: AppColors.ink),
                    ),
                  )
                      .animate()
                      .scaleXY(begin: 0.4, end: 1, curve: Curves.elasticOut, duration: 800.ms)
                      .fadeIn(),
                  const SizedBox(height: AppSpacing.space6),
                  GradientButton(
                    label: AuthStrings.giftContinue,
                    gradient: AppColors.goldGradient,
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
            ),
          ).animate().scaleXY(begin: 0.85, end: 1, curve: Curves.easeOutBack).fadeIn(),
        ),
        ConfettiWidget(
          confettiController: _confetti,
          blastDirectionality: BlastDirectionality.explosive,
          shouldLoop: false,
          numberOfParticles: 24,
          gravity: 0.25,
          colors: const [
            AppColors.gold,
            AppColors.primary,
            AppColors.secondary,
            AppColors.success,
            AppColors.nazymPink,
          ],
        ),
      ],
    );
  }
}
