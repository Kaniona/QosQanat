import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_strings.dart';
import '../../core/constants/auth_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../navigation/app_router.dart';
import '../../widgets/ui/gradient_button.dart';

/// One slide of the onboarding carousel.
class _OnbPage {
  const _OnbPage({
    required this.title,
    required this.body,
    required this.gradient,
    required this.icon,
  });

  final String title;
  final String body;
  final Gradient gradient;
  final IconData icon;
}

const List<_OnbPage> _pages = [
  _OnbPage(
    title: AuthStrings.onb1Title,
    body: AuthStrings.onb1Body,
    gradient: AppColors.bekturGradient,
    icon: Icons.sports_esports_rounded,
  ),
  _OnbPage(
    title: AuthStrings.onb2Title,
    body: AuthStrings.onb2Body,
    gradient: AppColors.successGradient,
    icon: Icons.bolt_rounded,
  ),
  _OnbPage(
    title: AuthStrings.onb3Title,
    body: AuthStrings.onb3Body,
    gradient: AppColors.nazymGradient,
    icon: Icons.favorite_rounded,
  ),
];

/// 3-page onboarding carousel shown to first-time users.
class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final PageController _controller = PageController();
  int _index = 0;

  bool get _isLast => _index == _pages.length - 1;

  void _next() {
    if (_isLast) {
      _finish();
    } else {
      _controller.nextPage(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeOutCubic,
      );
    }
  }

  void _finish() => context.go(AppRoutes.register);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // Skip + language toggle row.
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.space4,
                vertical: AppSpacing.space2,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(
                    onPressed: _finish,
                    child: Text(
                      AuthStrings.onbSkip,
                      style: AppTypography.button
                          .copyWith(color: AppColors.textSecondary),
                    ),
                  ),
                  const _LanguageTogglePill(),
                ],
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: _pages.length,
                onPageChanged: (i) => setState(() => _index = i),
                itemBuilder: (context, i) => _OnbPageView(page: _pages[i]),
              ),
            ),
            // Dots + action button.
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.space6,
                AppSpacing.space4,
                AppSpacing.space6,
                AppSpacing.space8,
              ),
              child: Column(
                children: [
                  _PageDots(count: _pages.length, index: _index),
                  const SizedBox(height: AppSpacing.space6),
                  GradientButton(
                    label: _isLast ? AuthStrings.onbStart : AppStrings.next,
                    gradient: AppColors.bekturGradient,
                    onPressed: _next,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OnbPageView extends StatelessWidget {
  const _OnbPageView({required this.page});

  final _OnbPage page;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Top 60% — colorful illustration.
        Expanded(
          flex: 6,
          child: Container(
            margin: const EdgeInsets.all(AppSpacing.space4),
            decoration: BoxDecoration(
              gradient: page.gradient,
              borderRadius: BorderRadius.circular(AppSpacing.radiusXl),
            ),
            child: Center(
              child: Icon(page.icon, size: 120, color: AppColors.white)
                  .animate(onPlay: (c) => c.repeat(reverse: true))
                  .scaleXY(
                    begin: 1,
                    end: 1.12,
                    duration: 1600.ms,
                    curve: Curves.easeInOut,
                  ),
            ),
          ),
        ),
        // Bottom 40% — text card.
        Expanded(
          flex: 4,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(AppSpacing.space6),
            decoration: const BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(AppSpacing.radiusXl),
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  page.title,
                  textAlign: TextAlign.center,
                  style: AppTypography.heading1,
                ).animate(key: ValueKey(page.title)).fadeIn().slideY(begin: 0.2, end: 0),
                const SizedBox(height: AppSpacing.space3),
                Text(
                  page.body,
                  textAlign: TextAlign.center,
                  style: AppTypography.body
                      .copyWith(color: AppColors.textSecondary),
                ).animate(key: ValueKey(page.body), delay: 100.ms).fadeIn(),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

/// Animated page indicator: the active dot elongates and turns to primary.
class _PageDots extends StatelessWidget {
  const _PageDots({required this.count, required this.index});

  final int count;
  final int index;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(count, (i) {
        final active = i == index;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: active ? 28 : 8,
          height: 8,
          decoration: BoxDecoration(
            color: active ? AppColors.primary : AppColors.border,
            borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
          ),
        );
      }),
    );
  }
}

/// `ҚАЗ | РУС` language toggle (Kazakh active; Russian wired in a later task).
class _LanguageTogglePill extends StatelessWidget {
  const _LanguageTogglePill();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.surfaceMuted,
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
            ),
            child: Text(
              'ҚАЗ',
              style: AppTypography.caption.copyWith(
                color: AppColors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(width: 4),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              'РУС',
              style: AppTypography.caption
                  .copyWith(color: AppColors.textSecondary),
            ),
          ),
        ],
      ),
    );
  }
}
