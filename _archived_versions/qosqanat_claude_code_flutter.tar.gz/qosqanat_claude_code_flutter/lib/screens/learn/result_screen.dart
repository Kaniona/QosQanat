import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/learn_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/learn_provider.dart';
import '../../providers/shop_provider.dart';
import '../../widgets/avatar/avatar_display.dart';
import '../../widgets/ui/gradient_button.dart';

/// The post-task celebration: confetti, a 3-star rating, the score, a reward
/// breakdown, the assistant celebrating, an unlock hint, and continue/retry.
class ResultScreen extends ConsumerStatefulWidget {
  const ResultScreen({super.key, required this.result});

  final TaskResult result;

  @override
  ConsumerState<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends ConsumerState<ResultScreen> {
  late final ConfettiController _confetti;

  @override
  void initState() {
    super.initState();
    _confetti = ConfettiController(duration: const Duration(seconds: 3));
    if (widget.result.stars >= 2) _confetti.play();
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  void _continue() {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go('${AppRoutes.learnMap}/${widget.result.subjectId}');
    }
  }

  void _retry() {
    context.pushReplacement(
      '${AppRoutes.learnTask}/${widget.result.subjectId}/${widget.result.nodeId}',
    );
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.result;
    final assistant =
        ref.watch(authProvider.select((s) => s.user?.assistantType)) ??
            AssistantType.bektur;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        alignment: Alignment.topCenter,
        children: [
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(AppSpacing.space6),
              child: Column(
                children: [
                  const SizedBox(height: AppSpacing.space4),
                  Text(
                    LearnStrings.resultTitle,
                    textAlign: TextAlign.center,
                    style: AppTypography.heading1.copyWith(color: AppColors.ink),
                  ).animate().fadeIn().slideY(begin: 0.2, end: 0),
                  const SizedBox(height: AppSpacing.space5),
                  _Stars(stars: r.stars),
                  const SizedBox(height: AppSpacing.space5),
                  SizedBox(
                    height: 130,
                    child: AvatarDisplay(
                      type: assistant,
                      equipped: ref.watch(equippedSlotsProvider),
                      state: r.stars >= 2
                          ? AvatarAnimationState.celebrate
                          : AvatarAnimationState.idle,
                      size: 130,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.space3),
                  Text(
                    LearnStrings.scorePercent(r.percent),
                    style: AppTypography.numberDisplay.copyWith(color: AppColors.primary),
                  ),
                  Text(
                    '${r.correct}/${r.total}',
                    style: AppTypography.bodyLarge.copyWith(color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: AppSpacing.space5),
                  _RewardsCard(result: r),
                  const SizedBox(height: AppSpacing.space4),
                  if (r.unlockedNext)
                    _UnlockHint(text: LearnStrings.unlockedNext)
                  else if (r.isFirstClear)
                    _UnlockHint(text: LearnStrings.allDone),
                  const SizedBox(height: AppSpacing.space6),
                  GradientButton(
                    label: LearnStrings.resultContinue,
                    gradient: AppColors.bekturGradient,
                    onPressed: _continue,
                  ),
                  const SizedBox(height: AppSpacing.space3),
                  TextButton(
                    onPressed: _retry,
                    child: Text(
                      LearnStrings.resultRetry,
                      style: AppTypography.button.copyWith(color: AppColors.textSecondary),
                    ),
                  ),
                ],
              ),
            ),
          ),
          ConfettiWidget(
            confettiController: _confetti,
            blastDirectionality: BlastDirectionality.explosive,
            numberOfParticles: 24,
            gravity: 0.2,
            shouldLoop: false,
            colors: const [
              AppColors.gold,
              AppColors.primary,
              AppColors.secondary,
              AppColors.success,
            ],
          ),
        ],
      ),
    );
  }
}

class _Stars extends StatelessWidget {
  const _Stars({required this.stars});
  final int stars;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        for (var i = 0; i < 3; i++)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space2),
            child: Icon(
              Icons.star_rounded,
              size: i == 1 ? 76 : 60,
              color: i < stars ? AppColors.gold : AppColors.border,
            )
                .animate()
                .scale(
                  delay: (250 * i).ms,
                  duration: 450.ms,
                  curve: Curves.elasticOut,
                  begin: const Offset(0.2, 0.2),
                  end: const Offset(1, 1),
                ),
          ),
      ],
    );
  }
}

class _RewardsCard extends StatelessWidget {
  const _RewardsCard({required this.result});
  final TaskResult result;

  @override
  Widget build(BuildContext context) {
    if (!result.isFirstClear) {
      return Container(
        padding: const EdgeInsets.all(AppSpacing.space4),
        decoration: BoxDecoration(
          color: AppColors.surfaceMuted,
          borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        ),
        child: Text(
          'Қайта өту — сыйлықсыз, бірақ жаттығу пайдалы! 💪',
          textAlign: TextAlign.center,
          style: AppTypography.body.copyWith(color: AppColors.textSecondary),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(AppSpacing.space5),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        boxShadow: const [
          BoxShadow(color: AppColors.shadow, blurRadius: 16, offset: Offset(0, 6)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            LearnStrings.rewardsTitle,
            style: AppTypography.caption.copyWith(
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: AppSpacing.space3),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _RewardItem(icon: '⚡', label: '+${result.xp}', color: AppColors.success),
              _RewardItem(icon: '💰', label: '+${result.coins}', color: AppColors.goldDeep),
              if (result.akyl > 0)
                _RewardItem(icon: '★', label: '+${result.akyl}', color: AppColors.secondary),
            ],
          ),
        ],
      ),
    );
  }
}

class _RewardItem extends StatelessWidget {
  const _RewardItem({required this.icon, required this.label, required this.color});

  final String icon;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(icon, style: const TextStyle(fontSize: 28)),
        const SizedBox(height: 4),
        Text(
          label,
          style: AppTypography.heading3.copyWith(color: color, fontWeight: FontWeight.w800),
        ),
      ],
    );
  }
}

class _UnlockHint extends StatelessWidget {
  const _UnlockHint({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.space4,
        vertical: AppSpacing.space3,
      ),
      decoration: BoxDecoration(
        color: AppColors.success.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
      ),
      child: Text(
        text,
        style: AppTypography.bodySmall.copyWith(
          color: AppColors.success,
          fontWeight: FontWeight.w800,
        ),
      ),
    ).animate().fadeIn(delay: 600.ms).slideY(begin: 0.3, end: 0);
  }
}
