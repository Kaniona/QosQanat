import 'package:flutter/material.dart';

import '../../../../core/constants/learn_strings.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../models/question.dart';
import 'task_shared.dart';

/// True/false: a statement and two large buttons, "Дұрыс ✓" and "Қате ✗".
class TrueFalseTask extends StatefulWidget {
  const TrueFalseTask({
    super.key,
    required this.question,
    required this.onAnswered,
  });

  final TrueFalseQuestion question;
  final ValueChanged<bool> onAnswered;

  @override
  State<TrueFalseTask> createState() => _TrueFalseTaskState();
}

class _TrueFalseTaskState extends State<TrueFalseTask> {
  bool? _picked;
  bool get _answered => _picked != null;

  void _pick(bool value) {
    if (_answered) return;
    setState(() => _picked = value);
    widget.onAnswered(value == widget.question.answer);
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TaskPrompt(text: q.prompt),
        const SizedBox(height: AppSpacing.space6),
        Row(
          children: [
            Expanded(
              child: _Choice(
                label: LearnStrings.trueLabel,
                value: true,
                picked: _picked,
                answer: q.answer,
                color: AppColors.success,
                onTap: () => _pick(true),
              ),
            ),
            const SizedBox(width: AppSpacing.space3),
            Expanded(
              child: _Choice(
                label: LearnStrings.falseLabel,
                value: false,
                picked: _picked,
                answer: q.answer,
                color: AppColors.danger,
                onTap: () => _pick(false),
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.space4),
        if (_answered && _picked != q.answer) ExplanationPanel(text: q.explanation),
      ],
    );
  }
}

class _Choice extends StatelessWidget {
  const _Choice({
    required this.label,
    required this.value,
    required this.picked,
    required this.answer,
    required this.color,
    required this.onTap,
  });

  final String label;
  final bool value;
  final bool? picked;
  final bool answer;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final answered = picked != null;
    // After answering, show the right choice in green and a wrong pick in red.
    Color bg = color.withValues(alpha: 0.12);
    Color border = color;
    Color fg = color;
    if (answered) {
      if (value == answer) {
        bg = AppColors.success.withValues(alpha: 0.16);
        border = AppColors.success;
        fg = AppColors.success;
      } else if (value == picked) {
        bg = AppColors.danger.withValues(alpha: 0.12);
        border = AppColors.danger;
        fg = AppColors.danger;
      } else {
        bg = AppColors.surface;
        border = AppColors.border;
        fg = AppColors.textTertiary;
      }
    }

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        onTap: onTap,
        child: Container(
          height: 96,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
            border: Border.all(color: border, width: 2),
          ),
          child: Text(
            label,
            style: AppTypography.heading3.copyWith(
              color: fg,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ),
    );
  }
}
