import 'package:flutter/material.dart';

import '../../../../core/constants/learn_strings.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../models/question.dart';
import 'task_shared.dart';

/// Fill-in-the-blank: a sentence with a blank, completed by tapping a word chip
/// from the bank. The first tap commits and reveals correctness.
class FillInBlankTask extends StatefulWidget {
  const FillInBlankTask({
    super.key,
    required this.question,
    required this.onAnswered,
  });

  final FillBlankQuestion question;
  final ValueChanged<bool> onAnswered;

  @override
  State<FillInBlankTask> createState() => _FillInBlankTaskState();
}

class _FillInBlankTaskState extends State<FillInBlankTask> {
  int? _picked;
  bool get _answered => _picked != null;

  void _choose(int i) {
    if (_answered) return;
    setState(() => _picked = i);
    widget.onAnswered(i == widget.question.correctIndex);
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final parts = q.prompt.split('___');
    final before = parts.isNotEmpty ? parts.first : q.prompt;
    final after = parts.length > 1 ? parts[1] : '';

    final correct = _answered && _picked == q.correctIndex;
    final blankWord = _picked == null ? '_____' : q.words[_picked!];
    final blankColor = !_answered
        ? AppColors.primary
        : (correct ? AppColors.success : AppColors.danger);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(LearnStrings.tapWordHint, style: AppTypography.caption),
        const SizedBox(height: AppSpacing.space3),
        // The sentence with an inline blank slot.
        Wrap(
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            Text(before, style: AppTypography.heading3.copyWith(color: AppColors.ink)),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 4),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
              decoration: BoxDecoration(
                color: blankColor.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
                border: Border.all(color: blankColor, width: 2),
              ),
              child: Text(
                blankWord,
                style: AppTypography.heading3.copyWith(
                  color: blankColor,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            Text(after, style: AppTypography.heading3.copyWith(color: AppColors.ink)),
          ],
        ),
        const SizedBox(height: AppSpacing.space6),
        Wrap(
          spacing: AppSpacing.space3,
          runSpacing: AppSpacing.space3,
          children: [
            for (var i = 0; i < q.words.length; i++)
              _WordChip(
                label: q.words[i],
                state: _chipState(i),
                onTap: () => _choose(i),
              ),
          ],
        ),
        const SizedBox(height: AppSpacing.space4),
        if (_answered && !correct) ExplanationPanel(text: q.explanation),
      ],
    );
  }

  _ChipState _chipState(int i) {
    if (!_answered) return _ChipState.idle;
    if (i == widget.question.correctIndex) return _ChipState.correct;
    if (i == _picked) return _ChipState.wrong;
    return _ChipState.dim;
  }
}

enum _ChipState { idle, correct, wrong, dim }

class _WordChip extends StatelessWidget {
  const _WordChip({required this.label, required this.state, required this.onTap});

  final String label;
  final _ChipState state;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final (bg, border, fg) = switch (state) {
      _ChipState.idle => (AppColors.surface, AppColors.primary, AppColors.primary),
      _ChipState.correct => (
          AppColors.success.withValues(alpha: 0.14),
          AppColors.success,
          AppColors.success,
        ),
      _ChipState.wrong => (
          AppColors.danger.withValues(alpha: 0.12),
          AppColors.danger,
          AppColors.danger,
        ),
      _ChipState.dim => (AppColors.surfaceMuted, AppColors.border, AppColors.textTertiary),
    };

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.space4,
            vertical: AppSpacing.space3,
          ),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
            border: Border.all(color: border, width: 2),
          ),
          child: Text(
            label,
            style: AppTypography.bodyLarge.copyWith(
              color: fg,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
    );
  }
}
