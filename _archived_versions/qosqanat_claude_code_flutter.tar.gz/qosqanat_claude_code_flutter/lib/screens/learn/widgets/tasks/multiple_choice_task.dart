import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../models/question.dart';
import 'task_shared.dart';

/// Multiple-choice: a prompt and four answer cards. On the first tap the chosen
/// card colors green (correct) or red (wrong, with the correct one highlighted)
/// and an explanation appears on a miss.
class MultipleChoiceTask extends StatefulWidget {
  const MultipleChoiceTask({
    super.key,
    required this.question,
    required this.onAnswered,
  });

  final MultipleChoiceQuestion question;
  final ValueChanged<bool> onAnswered;

  @override
  State<MultipleChoiceTask> createState() => _MultipleChoiceTaskState();
}

class _MultipleChoiceTaskState extends State<MultipleChoiceTask> {
  int? _selected;
  bool get _answered => _selected != null;

  void _choose(int i) {
    if (_answered) return;
    setState(() => _selected = i);
    widget.onAnswered(i == widget.question.correctIndex);
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TaskPrompt(text: q.prompt),
        const SizedBox(height: AppSpacing.space5),
        for (var i = 0; i < q.options.length; i++) ...[
          _AnswerCard(
            label: q.options[i],
            state: _stateFor(i),
            onTap: () => _choose(i),
          ),
          const SizedBox(height: AppSpacing.space3),
        ],
        if (_answered && _selected != widget.question.correctIndex)
          ExplanationPanel(text: q.explanation),
      ],
    );
  }

  _CardState _stateFor(int i) {
    if (!_answered) return _CardState.idle;
    if (i == widget.question.correctIndex) return _CardState.correct;
    if (i == _selected) return _CardState.wrong;
    return _CardState.dim;
  }
}

enum _CardState { idle, correct, wrong, dim }

class _AnswerCard extends StatelessWidget {
  const _AnswerCard({
    required this.label,
    required this.state,
    required this.onTap,
  });

  final String label;
  final _CardState state;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final (bg, border, fg, icon) = switch (state) {
      _CardState.idle => (
          AppColors.surface,
          AppColors.border,
          AppColors.ink,
          null,
        ),
      _CardState.correct => (
          AppColors.success.withValues(alpha: 0.12),
          AppColors.success,
          AppColors.success,
          Icons.check_circle_rounded,
        ),
      _CardState.wrong => (
          AppColors.danger.withValues(alpha: 0.1),
          AppColors.danger,
          AppColors.danger,
          Icons.cancel_rounded,
        ),
      _CardState.dim => (
          AppColors.surface,
          AppColors.border,
          AppColors.textTertiary,
          null,
        ),
    };

    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.space4,
              vertical: AppSpacing.space4,
            ),
            decoration: BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
              border: Border.all(color: border, width: 2),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    label,
                    style: AppTypography.bodyLarge.copyWith(
                      color: fg,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                if (icon != null) Icon(icon, color: fg),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
