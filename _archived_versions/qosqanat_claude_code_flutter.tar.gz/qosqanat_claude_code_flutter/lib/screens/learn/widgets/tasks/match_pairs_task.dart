import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../models/question.dart';
import 'task_shared.dart';

/// Match-pairs: two columns connected by animated lines as the student matches
/// each left item to its right item. Gentle — wrong taps just flash and reset,
/// costing no heart; the question resolves correct once everything is matched.
class MatchPairsTask extends StatefulWidget {
  const MatchPairsTask({
    super.key,
    required this.question,
    required this.onAnswered,
  });

  final MatchPairsQuestion question;
  final ValueChanged<bool> onAnswered;

  @override
  State<MatchPairsTask> createState() => _MatchPairsTaskState();
}

class _MatchPairsTaskState extends State<MatchPairsTask> {
  static const double _rowHeight = 64;

  int? _selectedLeft;
  int? _wrongRight; // display index briefly flashed red
  final Map<int, int> _leftToRightDisplay = {}; // leftIndex → right display index
  late final List<int> _rightOrder; // display order → original pair index
  bool _done = false;

  @override
  void initState() {
    super.initState();
    final n = widget.question.pairs.length;
    _rightOrder = List<int>.generate(n, (i) => i)
      ..shuffle(math.Random(widget.question.id.hashCode));
  }

  bool _isLeftMatched(int i) => _leftToRightDisplay.containsKey(i);
  bool _isRightMatched(int display) =>
      _leftToRightDisplay.values.contains(display);

  void _tapLeft(int i) {
    if (_isLeftMatched(i)) return;
    setState(() => _selectedLeft = i);
  }

  void _tapRight(int display) {
    if (_isRightMatched(display) || _selectedLeft == null) return;
    final originalIndex = _rightOrder[display];
    if (originalIndex == _selectedLeft) {
      HapticFeedback.selectionClick();
      setState(() {
        _leftToRightDisplay[_selectedLeft!] = display;
        _selectedLeft = null;
      });
      if (_leftToRightDisplay.length == widget.question.pairs.length && !_done) {
        _done = true;
        widget.onAnswered(true);
      }
    } else {
      HapticFeedback.lightImpact();
      setState(() => _wrongRight = display);
      Future.delayed(const Duration(milliseconds: 350), () {
        if (mounted) setState(() => _wrongRight = null);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final pairs = widget.question.pairs;
    final height = pairs.length * _rowHeight;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TaskPrompt(text: widget.question.prompt),
        const SizedBox(height: AppSpacing.space5),
        LayoutBuilder(
          builder: (context, constraints) {
            final width = constraints.maxWidth;
            final colW = (width - AppSpacing.space5) / 2;
            return SizedBox(
              height: height,
              child: Stack(
                children: [
                  // Connecting lines behind the cards.
                  Positioned.fill(
                    child: CustomPaint(
                      painter: _LinkPainter(
                        links: _leftToRightDisplay,
                        rowHeight: _rowHeight,
                        colWidth: colW,
                        totalWidth: width,
                      ),
                    ),
                  ),
                  // Left column.
                  for (var i = 0; i < pairs.length; i++)
                    Positioned(
                      left: 0,
                      width: colW,
                      top: i * _rowHeight + 6,
                      height: _rowHeight - 12,
                      child: _PairCard(
                        label: pairs[i].left,
                        selected: _selectedLeft == i,
                        matched: _isLeftMatched(i),
                        wrong: false,
                        onTap: () => _tapLeft(i),
                      ),
                    ),
                  // Right column (shuffled).
                  for (var d = 0; d < pairs.length; d++)
                    Positioned(
                      right: 0,
                      width: colW,
                      top: d * _rowHeight + 6,
                      height: _rowHeight - 12,
                      child: _PairCard(
                        label: pairs[_rightOrder[d]].right,
                        selected: false,
                        matched: _isRightMatched(d),
                        wrong: _wrongRight == d,
                        onTap: () => _tapRight(d),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }
}

class _PairCard extends StatelessWidget {
  const _PairCard({
    required this.label,
    required this.selected,
    required this.matched,
    required this.wrong,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final bool matched;
  final bool wrong;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    Color bg = AppColors.surface;
    Color border = AppColors.border;
    Color fg = AppColors.ink;
    if (matched) {
      bg = AppColors.success.withValues(alpha: 0.14);
      border = AppColors.success;
      fg = AppColors.success;
    } else if (wrong) {
      bg = AppColors.danger.withValues(alpha: 0.12);
      border = AppColors.danger;
      fg = AppColors.danger;
    } else if (selected) {
      bg = AppColors.primary.withValues(alpha: 0.12);
      border = AppColors.primary;
      fg = AppColors.primary;
    }

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        onTap: matched ? null : onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space3),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
            border: Border.all(color: border, width: 2),
          ),
          child: Text(
            label,
            maxLines: 2,
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            style: AppTypography.body.copyWith(color: fg, fontWeight: FontWeight.w700),
          ),
        ),
      ),
    );
  }
}

class _LinkPainter extends CustomPainter {
  _LinkPainter({
    required this.links,
    required this.rowHeight,
    required this.colWidth,
    required this.totalWidth,
  });

  final Map<int, int> links;
  final double rowHeight;
  final double colWidth;
  final double totalWidth;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.success
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    links.forEach((leftIndex, rightDisplay) {
      final start = Offset(colWidth, leftIndex * rowHeight + rowHeight / 2);
      final end = Offset(totalWidth - colWidth, rightDisplay * rowHeight + rowHeight / 2);
      final mid = (start.dx + end.dx) / 2;
      final path = Path()
        ..moveTo(start.dx, start.dy)
        ..cubicTo(mid, start.dy, mid, end.dy, end.dx, end.dy);
      canvas.drawPath(path, paint);
      canvas.drawCircle(start, 4, Paint()..color = AppColors.success);
      canvas.drawCircle(end, 4, Paint()..color = AppColors.success);
    });
  }

  @override
  bool shouldRepaint(covariant _LinkPainter old) =>
      // The map is mutated in place, so compare contents (count is enough here).
      old.links.length != links.length || old.colWidth != colWidth;
}
