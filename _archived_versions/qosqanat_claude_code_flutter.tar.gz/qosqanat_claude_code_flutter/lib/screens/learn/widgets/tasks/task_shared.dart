import 'package:flutter/material.dart';

import '../../../../core/constants/learn_strings.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';

/// The question prompt, styled consistently across all task types.
class TaskPrompt extends StatelessWidget {
  const TaskPrompt({super.key, required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: AppTypography.heading2.copyWith(color: AppColors.ink),
    );
  }
}

/// A gentle, encouraging explanation card shown after a wrong answer.
class ExplanationPanel extends StatelessWidget {
  const ExplanationPanel({super.key, required this.text});
  final String? text;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: AppSpacing.space2),
      padding: const EdgeInsets.all(AppSpacing.space4),
      decoration: BoxDecoration(
        color: AppColors.info.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        border: Border.all(color: AppColors.info.withValues(alpha: 0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              const Icon(Icons.lightbulb_rounded, color: AppColors.info, size: 18),
              const SizedBox(width: AppSpacing.space2),
              Text(
                LearnStrings.explanationTitle,
                style: AppTypography.caption.copyWith(
                  color: AppColors.info,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            text == null || text!.isEmpty ? LearnStrings.tryAgainGentle : text!,
            style: AppTypography.body.copyWith(color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }
}
