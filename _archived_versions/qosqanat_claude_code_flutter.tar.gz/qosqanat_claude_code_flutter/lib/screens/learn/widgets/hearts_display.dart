import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';

/// A row of hearts showing remaining lives out of [max]. Lost hearts fade to a
/// broken outline. Used in the map header and the task top bar.
class HeartsDisplay extends StatelessWidget {
  const HeartsDisplay({super.key, required this.lives, this.max = 3, this.size = 22});

  final int lives;
  final int max;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 0; i < max; i++)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 1.5),
            child: AnimatedScale(
              scale: i < lives ? 1.0 : 0.85,
              duration: const Duration(milliseconds: 250),
              child: Icon(
                i < lives ? Icons.favorite_rounded : Icons.heart_broken_rounded,
                color: i < lives
                    ? AppColors.danger
                    : AppColors.danger.withValues(alpha: 0.3),
                size: size,
              ),
            ),
          ),
      ],
    );
  }
}
