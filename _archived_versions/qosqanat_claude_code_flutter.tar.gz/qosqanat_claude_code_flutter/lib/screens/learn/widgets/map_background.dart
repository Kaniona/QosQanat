import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';

/// Paints the winding dotted S-path connecting the node centers, plus subtle
/// landscape decorations (clouds, stars, trees, Kazakh ornament curls) so the
/// map reads as a journey through a living world.
class MapBackgroundPainter extends CustomPainter {
  MapBackgroundPainter({required this.centers, required this.accent});

  /// Node centers, top to bottom, in the same coordinate space as the canvas.
  final List<Offset> centers;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    _paintDecorations(canvas, size);
    _paintPath(canvas);
  }

  void _paintPath(Canvas canvas) {
    if (centers.length < 2) return;

    final path = Path()..moveTo(centers.first.dx, centers.first.dy);
    for (var i = 0; i < centers.length - 1; i++) {
      final a = centers[i];
      final b = centers[i + 1];
      final midY = (a.dy + b.dy) / 2;
      // Cubic with vertical control points → smooth S-curve between alternating
      // node columns.
      path.cubicTo(a.dx, midY, b.dx, midY, b.dx, b.dy);
    }

    // Render the path as evenly spaced dots.
    final dot = Paint()
      ..color = accent.withValues(alpha: 0.35)
      ..style = PaintingStyle.fill;
    for (final metric in path.computeMetrics()) {
      var d = 0.0;
      const step = 15.0;
      while (d < metric.length) {
        final tan = metric.getTangentForOffset(d);
        if (tan != null) canvas.drawCircle(tan.position, 3, dot);
        d += step;
      }
    }
  }

  void _paintDecorations(Canvas canvas, Size size) {
    final rnd = math.Random(7); // seeded → stable across repaints
    final count = (size.height / 150).clamp(6, 80).toInt();

    for (var i = 0; i < count; i++) {
      final x = rnd.nextDouble() * size.width;
      final y = rnd.nextDouble() * size.height;
      switch (i % 4) {
        case 0:
          _cloud(canvas, Offset(x, y));
        case 1:
          _star(canvas, Offset(x, y), 3 + rnd.nextDouble() * 3);
        case 2:
          _tree(canvas, Offset(x, y));
        case 3:
          _ornament(canvas, Offset(x, y));
      }
    }
  }

  void _cloud(Canvas canvas, Offset c) {
    final paint = Paint()..color = AppColors.primaryLight.withValues(alpha: 0.12);
    canvas.drawCircle(c, 14, paint);
    canvas.drawCircle(c.translate(14, 4), 11, paint);
    canvas.drawCircle(c.translate(-13, 5), 10, paint);
  }

  void _star(Canvas canvas, Offset c, double r) {
    final paint = Paint()..color = AppColors.gold.withValues(alpha: 0.4);
    final path = Path();
    for (var i = 0; i < 4; i++) {
      final a = i * math.pi / 2;
      final outer = Offset(c.dx + math.cos(a) * r, c.dy + math.sin(a) * r);
      final inner = Offset(
        c.dx + math.cos(a + math.pi / 4) * r * 0.4,
        c.dy + math.sin(a + math.pi / 4) * r * 0.4,
      );
      if (i == 0) {
        path.moveTo(outer.dx, outer.dy);
      } else {
        path.lineTo(outer.dx, outer.dy);
      }
      path.lineTo(inner.dx, inner.dy);
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  void _tree(Canvas canvas, Offset base) {
    final trunk = Paint()..color = const Color(0xFF9C6B3F).withValues(alpha: 0.3);
    final leaves = Paint()..color = AppColors.success.withValues(alpha: 0.22);
    canvas.drawRect(
      Rect.fromLTWH(base.dx - 2, base.dy, 4, 10),
      trunk,
    );
    final tri = Path()
      ..moveTo(base.dx, base.dy - 18)
      ..lineTo(base.dx - 11, base.dy + 1)
      ..lineTo(base.dx + 11, base.dy + 1)
      ..close();
    canvas.drawPath(tri, leaves);
  }

  /// A small paired-curl motif evoking Kazakh ою-өрнек.
  void _ornament(Canvas canvas, Offset c) {
    final paint = Paint()
      ..color = AppColors.gold.withValues(alpha: 0.22)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    final left = Path()
      ..moveTo(c.dx, c.dy)
      ..cubicTo(c.dx - 10, c.dy - 8, c.dx - 12, c.dy + 6, c.dx - 4, c.dy + 4);
    final right = Path()
      ..moveTo(c.dx, c.dy)
      ..cubicTo(c.dx + 10, c.dy - 8, c.dx + 12, c.dy + 6, c.dx + 4, c.dy + 4);
    canvas.drawPath(left, paint);
    canvas.drawPath(right, paint);
  }

  @override
  bool shouldRepaint(covariant MapBackgroundPainter old) =>
      old.centers != centers || old.accent != accent;
}
