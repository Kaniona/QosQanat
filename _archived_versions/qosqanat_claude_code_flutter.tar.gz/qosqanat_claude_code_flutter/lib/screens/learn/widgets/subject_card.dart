import 'package:flutter/material.dart';

import '../../../core/constants/learn_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../data/curriculum.dart';

/// A portal-like card for one subject: its gradient, a large emoji, the name,
/// and a progress label/bar. Tapping enters the subject's learning map.
class SubjectCard extends StatelessWidget {
  const SubjectCard({
    super.key,
    required this.subject,
    required this.completed,
    required this.onTap,
  });

  final Subject subject;
  final int completed;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final total = subject.totalNodes;
    final fraction = total == 0 ? 0.0 : completed / total;

    return Material(
      color: Colors.transparent,
      child: Ink(
        decoration: BoxDecoration(
          gradient: subject.gradient,
          borderRadius: BorderRadius.circular(AppSpacing.radiusXl),
          boxShadow: [
            BoxShadow(
              color: subject.color.withValues(alpha: 0.35),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppSpacing.radiusXl),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.space4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(subject.emoji, style: const TextStyle(fontSize: 44)),
                const SizedBox(height: AppSpacing.space3),
                Text(
                  subject.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.heading3.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: AppSpacing.space2),
                ClipRRect(
                  borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
                  child: Stack(
                    children: [
                      Container(
                        height: 6,
                        color: AppColors.white.withValues(alpha: 0.3),
                      ),
                      FractionallySizedBox(
                        widthFactor: fraction.clamp(0.0, 1.0),
                        child: Container(height: 6, color: AppColors.white),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  LearnStrings.taskCount(completed, total),
                  style: AppTypography.caption.copyWith(
                    color: AppColors.white.withValues(alpha: 0.9),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
