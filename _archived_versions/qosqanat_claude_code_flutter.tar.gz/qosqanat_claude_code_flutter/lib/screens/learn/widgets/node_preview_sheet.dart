import 'package:flutter/material.dart';

import '../../../core/constants/learn_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../data/curriculum.dart';
import '../../../widgets/ui/gradient_button.dart';

/// Bottom-sheet preview for an available node: title, type label, description,
/// reward preview, question count, and a "Бастау →" button.
///
/// Resolves to true when the student chooses to start.
Future<bool?> showNodePreview(
  BuildContext context, {
  required LearnNode node,
  required Color accent,
}) {
  return showModalBottomSheet<bool>(
    context: context,
    backgroundColor: Colors.transparent,
    builder: (_) => _NodePreview(node: node, accent: accent),
  );
}

class _NodePreview extends StatelessWidget {
  const _NodePreview({required this.node, required this.accent});

  final LearnNode node;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(AppSpacing.radiusXl)),
      ),
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.space5,
        AppSpacing.space3,
        AppSpacing.space5,
        AppSpacing.space6,
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 5,
                margin: const EdgeInsets.only(bottom: AppSpacing.space4),
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
                ),
              ),
            ),
            Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                  ),
                  child: Text(LearnStrings.nodeEmoji(node.type),
                      style: const TextStyle(fontSize: 26)),
                ),
                const SizedBox(width: AppSpacing.space3),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        LearnStrings.nodeType(node.type),
                        style: AppTypography.caption.copyWith(
                          color: accent,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        node.title,
                        style: AppTypography.heading3.copyWith(color: AppColors.ink),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.space3),
            Text(
              node.description,
              style: AppTypography.body.copyWith(color: AppColors.textSecondary),
            ),
            const SizedBox(height: AppSpacing.space4),
            Row(
              children: [
                _Reward(icon: '⚡', value: node.xpReward, color: AppColors.success),
                const SizedBox(width: AppSpacing.space2),
                _Reward(icon: '💰', value: node.coinReward, color: AppColors.goldDeep),
                if (node.akylReward > 0) ...[
                  const SizedBox(width: AppSpacing.space2),
                  _Reward(icon: '★', value: node.akylReward, color: AppColors.secondary),
                ],
                const Spacer(),
                Text(
                  LearnStrings.questionCount(node.questionCount),
                  style: AppTypography.caption,
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.space5),
            GradientButton(
              label: LearnStrings.startArrow,
              gradient: AppColors.bekturGradient,
              onPressed: () => Navigator.of(context).pop(true),
            ),
          ],
        ),
      ),
    );
  }
}

class _Reward extends StatelessWidget {
  const _Reward({required this.icon, required this.value, required this.color});

  final String icon;
  final int value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space3, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
      ),
      child: Text(
        '$icon +$value',
        style: AppTypography.caption.copyWith(
          color: color,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}
