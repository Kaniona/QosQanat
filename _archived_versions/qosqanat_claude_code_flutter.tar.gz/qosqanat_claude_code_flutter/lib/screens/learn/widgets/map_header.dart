import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import 'hearts_display.dart';

/// Sticky map header: back arrow, subject icon + name, an overall progress bar,
/// and the hearts display.
class MapHeader extends StatelessWidget {
  const MapHeader({
    super.key,
    required this.subjectName,
    required this.emoji,
    required this.accent,
    required this.completed,
    required this.total,
    required this.lives,
    required this.onBack,
  });

  final String subjectName;
  final String emoji;
  final Color accent;
  final int completed;
  final int total;
  final int lives;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final fraction = total == 0 ? 0.0 : completed / total;
    return Container(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.space4,
        AppSpacing.space3,
        AppSpacing.space4,
        AppSpacing.space3,
      ),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        boxShadow: [
          BoxShadow(color: AppColors.shadow, blurRadius: 14, offset: Offset(0, 4)),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: onBack,
                behavior: HitTestBehavior.opaque,
                child: const Icon(Icons.arrow_back_rounded, color: AppColors.ink),
              ),
              const SizedBox(width: AppSpacing.space3),
              Text(emoji, style: const TextStyle(fontSize: 22)),
              const SizedBox(width: AppSpacing.space2),
              Expanded(
                child: Text(
                  subjectName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.heading3.copyWith(color: AppColors.ink),
                ),
              ),
              HeartsDisplay(lives: lives),
            ],
          ),
          const SizedBox(height: AppSpacing.space2),
          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
                  child: Stack(
                    children: [
                      Container(height: 8, color: AppColors.surfaceMuted),
                      FractionallySizedBox(
                        widthFactor: fraction.clamp(0.0, 1.0),
                        child: Container(
                          height: 8,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [accent.withValues(alpha: 0.7), accent],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: AppSpacing.space2),
              Text(
                '$completed/$total',
                style: AppTypography.caption.copyWith(fontWeight: FontWeight.w800),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
