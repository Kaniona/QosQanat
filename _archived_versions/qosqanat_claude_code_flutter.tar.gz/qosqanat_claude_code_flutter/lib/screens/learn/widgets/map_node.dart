import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../core/constants/learn_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/enums.dart';

/// Visual state of a node on the map.
enum NodeVisualState { mastered, completed, current, available, locked }

/// A single map node: a 72px circle (88px for a boss) whose look conveys its
/// [state] and [type]. Tapping a locked node shakes it; otherwise [onTap] fires.
class MapNode extends StatefulWidget {
  const MapNode({
    super.key,
    required this.type,
    required this.state,
    required this.stars,
    required this.onTap,
    required this.onLockedTap,
  });

  final NodeType type;
  final NodeVisualState state;
  final int stars;
  final VoidCallback onTap;
  final VoidCallback onLockedTap;

  static const double diameter = 72;
  static const double bossDiameter = 88;

  double get size => type == NodeType.boss ? bossDiameter : diameter;

  /// Side of the square layout box for a node of [type] (circle + overflow
  /// room). The map uses this to position each node by its center.
  static double boxSizeFor(NodeType type) =>
      (type == NodeType.boss ? bossDiameter : diameter) + 56;

  @override
  State<MapNode> createState() => _MapNodeState();
}

class _MapNodeState extends State<MapNode> with TickerProviderStateMixin {
  late final AnimationController _pulse;
  late final AnimationController _shake;

  bool get _isLocked => widget.state == NodeVisualState.locked;
  bool get _isCurrent => widget.state == NodeVisualState.current;
  bool get _isBoss => widget.type == NodeType.boss;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );
    _shake = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 420),
    );
    if (_isCurrent || _isBoss) _pulse.repeat();
  }

  @override
  void didUpdateWidget(covariant MapNode old) {
    super.didUpdateWidget(old);
    final shouldPulse = _isCurrent || _isBoss;
    if (shouldPulse && !_pulse.isAnimating) {
      _pulse.repeat();
    } else if (!shouldPulse && _pulse.isAnimating) {
      _pulse
        ..stop()
        ..value = 0;
    }
  }

  @override
  void dispose() {
    _pulse.dispose();
    _shake.dispose();
    super.dispose();
  }

  void _handleTap() {
    if (_isLocked) {
      _shake.forward(from: 0);
      widget.onLockedTap();
    } else {
      widget.onTap();
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.size;

    Widget node = SizedBox(
      // Square box with the circle centered; extra room (via Clip.none) holds
      // the glow ring, crown, stars and "Бастау" label. Square keeps the map's
      // center-based positioning simple.
      width: size + 56,
      height: size + 56,
      child: Stack(
        alignment: Alignment.center,
        clipBehavior: Clip.none,
        children: [
          if (_isCurrent || _isBoss) _glowRing(size),
          _circle(size),
          if (_isBoss) _crown(size),
          if (_isBoss) _guardian(size),
          if (_isCurrent) _startLabel(size),
          if (widget.state == NodeVisualState.mastered) _stars(size),
        ],
      ),
    );

    // Shake on a locked tap.
    node = AnimatedBuilder(
      animation: _shake,
      builder: (context, child) {
        // Damped horizontal wiggle: a few quick oscillations that fade out.
        final t = _shake.value;
        final dx = math.sin(t * math.pi * 6) * 9 * (1 - t);
        return Transform.translate(offset: Offset(dx, 0), child: child);
      },
      child: node,
    );

    return GestureDetector(
      onTap: _handleTap,
      behavior: HitTestBehavior.opaque,
      child: node,
    );
  }

  // ── Layers ──────────────────────────────────────────────────────────────

  Widget _glowRing(double size) {
    return AnimatedBuilder(
      animation: _pulse,
      builder: (context, _) {
        final t = _pulse.value;
        final color = _isBoss ? AppColors.danger : AppColors.gold;
        return Container(
          width: size + 18 * t + 8,
          height: size + 18 * t + 8,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withValues(alpha: 0.22 * (1 - t)),
          ),
        );
      },
    );
  }

  Widget _circle(double size) {
    final decoration = switch (widget.state) {
      NodeVisualState.mastered || NodeVisualState.completed => const BoxDecoration(
          gradient: AppColors.successGradient,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(color: AppColors.shadow, blurRadius: 10, offset: Offset(0, 4)),
          ],
        ),
      NodeVisualState.current => BoxDecoration(
          gradient: AppColors.goldGradient,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: AppColors.gold.withValues(alpha: 0.6),
              blurRadius: 20,
              spreadRadius: 1,
            ),
          ],
        ),
      NodeVisualState.available => const BoxDecoration(
          gradient: AppColors.bekturGradient,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(color: AppColors.shadow, blurRadius: 10, offset: Offset(0, 4)),
          ],
        ),
      NodeVisualState.locked => BoxDecoration(
          color: AppColors.textTertiary.withValues(alpha: 0.45),
          shape: BoxShape.circle,
        ),
    };

    final scale = _isCurrent ? 1.08 : 1.0;

    return Transform.scale(
      scale: scale,
      child: Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: decoration,
        child: _inner(size),
      ),
    );
  }

  Widget _inner(double size) {
    final fontSize = size * 0.42;
    switch (widget.state) {
      case NodeVisualState.locked:
        return Icon(Icons.lock_rounded,
            color: AppColors.white.withValues(alpha: 0.85), size: size * 0.34);
      case NodeVisualState.completed:
      case NodeVisualState.mastered:
        // Boss/treasure keep their icon even when done; lessons/quizzes show ✓.
        if (_isBoss || widget.type == NodeType.treasure) {
          return Text(LearnStrings.nodeEmoji(widget.type),
              style: TextStyle(fontSize: fontSize));
        }
        return Icon(Icons.check_rounded, color: AppColors.white, size: size * 0.5);
      case NodeVisualState.current:
      case NodeVisualState.available:
        return Text(
          LearnStrings.nodeEmoji(widget.type),
          style: TextStyle(fontSize: fontSize),
        );
    }
  }

  Widget _crown(double size) {
    return Positioned(
      top: -2,
      child: Text('👑', style: TextStyle(fontSize: size * 0.34)),
    );
  }

  Widget _guardian(double size) {
    return Positioned(
      right: 0,
      bottom: 6,
      child: Container(
        padding: const EdgeInsets.all(3),
        decoration: const BoxDecoration(
          color: AppColors.surface,
          shape: BoxShape.circle,
        ),
        child: Text('👾', style: TextStyle(fontSize: size * 0.26)),
      ),
    );
  }

  Widget _startLabel(double size) {
    return Positioned(
      bottom: 0,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: AppColors.ink,
          borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
          boxShadow: const [
            BoxShadow(color: AppColors.shadow, blurRadius: 8, offset: Offset(0, 2)),
          ],
        ),
        child: Text(
          LearnStrings.start,
          style: AppTypography.caption.copyWith(
            color: AppColors.gold,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }

  Widget _stars(double size) {
    return Positioned(
      top: -6,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(
          3,
          (i) => Padding(
            padding: const EdgeInsets.symmetric(horizontal: 1),
            child: Icon(Icons.star_rounded,
                color: AppColors.gold, size: size * 0.26),
          ),
        ),
      ),
    );
  }
}
