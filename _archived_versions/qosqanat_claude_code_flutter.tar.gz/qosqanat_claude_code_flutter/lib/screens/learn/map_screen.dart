import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/learn_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../data/curriculum.dart';
import '../../navigation/app_router.dart';
import '../../providers/learn_provider.dart';
import 'widgets/map_background.dart';
import 'widgets/map_header.dart';
import 'widgets/map_node.dart';
import 'widgets/module_banner.dart';
import 'widgets/node_preview_sheet.dart';

/// The signature learning map: a vertical S-curved journey of node circles for
/// one subject, with module banners between grades and a sticky header.
class MapScreen extends ConsumerWidget {
  const MapScreen({super.key, required this.subjectId});

  final String subjectId;

  // Layout constants for the winding path.
  static const double _nodeBand = 124;
  static const double _bannerBand = 92;
  static const double _topPad = 32;
  static const double _bottomPad = 120;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final subject = subjectById(subjectId);
    if (subject == null) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(child: Text('—')),
      );
    }

    ref.watch(learnProvider); // rebuild as progress changes
    final learn = ref.read(learnProvider.notifier);
    final completed = learn.completedCount(subjectId);
    final allNodes = subject.allNodes;
    final frontierId =
        allNodes.firstWhere((n) => !learn.isCompleted(n.id), orElse: () => allNodes.last).id;
    final allDone = allNodes.every((n) => learn.isCompleted(n.id));

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          SafeArea(
            bottom: false,
            child: MapHeader(
              subjectName: subject.name,
              emoji: subject.emoji,
              accent: subject.color,
              completed: completed,
              total: subject.totalNodes,
              lives: 3,
              onBack: () => _back(context),
            ),
          ),
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final width = constraints.maxWidth;
                final layout = _buildLayout(subject, width);
                return SingleChildScrollView(
                  child: SizedBox(
                    width: width,
                    height: layout.height,
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Positioned.fill(
                          child: CustomPaint(
                            painter: MapBackgroundPainter(
                              centers: layout.centers,
                              accent: subject.color,
                            ),
                          ),
                        ),
                        for (final b in layout.banners)
                          Positioned(
                            top: b.y - 28,
                            left: 0,
                            right: 0,
                            child: ModuleBanner(text: b.text),
                          ),
                        for (final p in layout.nodes)
                          _positionedNode(context, ref, subject, p,
                              frontierId: frontierId, allDone: allDone),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _positionedNode(
    BuildContext context,
    WidgetRef ref,
    Subject subject,
    _NodePlacement p, {
    required String frontierId,
    required bool allDone,
  }) {
    final learn = ref.read(learnProvider.notifier);
    final progress = learn.progressFor(p.node.id);
    final NodeVisualState state;
    if (progress.completed) {
      state = progress.stars >= 3
          ? NodeVisualState.mastered
          : NodeVisualState.completed;
    } else if (p.node.id == frontierId && !allDone) {
      state = NodeVisualState.current;
    } else if (learn.isUnlocked(subject.id, p.node.id)) {
      state = NodeVisualState.available;
    } else {
      state = NodeVisualState.locked;
    }

    final box = MapNode.boxSizeFor(p.node.type);
    return Positioned(
      left: p.x - box / 2,
      top: p.y - box / 2,
      child: MapNode(
        type: p.node.type,
        state: state,
        stars: progress.stars,
        onTap: () => _openNode(context, ref, subject, p.node),
        onLockedTap: () => _showLockedToast(context),
      ),
    );
  }

  Future<void> _openNode(
    BuildContext context,
    WidgetRef ref,
    Subject subject,
    LearnNode node,
  ) async {
    final start = await showNodePreview(context, node: node, accent: subject.color);
    if (start == true && context.mounted) {
      context.push('${AppRoutes.learnTask}/${subject.id}/${node.id}');
    }
  }

  void _showLockedToast(BuildContext context) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(const SnackBar(
        content: Text(LearnStrings.lockedToast),
        behavior: SnackBarBehavior.floating,
        duration: Duration(milliseconds: 1400),
      ));
  }

  void _back(BuildContext context) {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go(AppRoutes.learn);
    }
  }

  /// Computes node/banner positions and the path centers for the given [width].
  _MapLayout _buildLayout(Subject subject, double width) {
    final centerX = width / 2;
    final amplitude = math.min(width * 0.30, 120.0);
    final nodes = <_NodePlacement>[];
    final banners = <_BannerPlacement>[];
    final centers = <Offset>[];

    var y = _topPad;
    var globalIndex = 0;

    for (var m = 0; m < subject.modules.length; m++) {
      final module = subject.modules[m];

      if (m > 0) {
        // Celebratory banner between grade modules.
        final prev = subject.modules[m - 1];
        y += _bannerBand / 2;
        banners.add(_BannerPlacement(
          y: y,
          text: LearnStrings.moduleComplete(prev.grade, module.grade),
        ));
        y += _bannerBand / 2;
      }

      for (final node in module.nodes) {
        y += _nodeBand / 2;
        final x = (centerX + amplitude * math.sin(globalIndex * 0.9))
            .clamp(80.0, width - 80.0);
        final center = Offset(x, y);
        nodes.add(_NodePlacement(node: node, x: x, y: y));
        centers.add(center);
        y += _nodeBand / 2;
        globalIndex++;
      }
    }

    return _MapLayout(
      height: y + _bottomPad,
      nodes: nodes,
      banners: banners,
      centers: centers,
    );
  }
}

class _MapLayout {
  const _MapLayout({
    required this.height,
    required this.nodes,
    required this.banners,
    required this.centers,
  });

  final double height;
  final List<_NodePlacement> nodes;
  final List<_BannerPlacement> banners;
  final List<Offset> centers;
}

class _NodePlacement {
  const _NodePlacement({required this.node, required this.x, required this.y});
  final LearnNode node;
  final double x;
  final double y;
}

class _BannerPlacement {
  const _BannerPlacement({required this.y, required this.text});
  final double y;
  final String text;
}
