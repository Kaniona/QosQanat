import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/learn_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/curriculum.dart';
import '../../models/enums.dart';
import '../../models/question.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/learn_provider.dart';
import '../../providers/shop_provider.dart';
import '../../widgets/avatar/avatar_base.dart';
import '../../widgets/avatar/avatar_display.dart';
import '../../widgets/game/reward_toast.dart';
import '../../widgets/ui/gradient_button.dart';
import 'widgets/hearts_display.dart';
import 'widgets/tasks/fill_in_blank_task.dart';
import 'widgets/tasks/match_pairs_task.dart';
import 'widgets/tasks/multiple_choice_task.dart';
import 'widgets/tasks/true_false_task.dart';

/// The task container: a top bar (close, segmented progress, hearts), the
/// current question, and the assistant reacting at the bottom. Drives the flow
/// through every question and hands the outcome to the result screen.
class TaskScreen extends ConsumerStatefulWidget {
  const TaskScreen({super.key, required this.subjectId, required this.nodeId});

  final String subjectId;
  final String nodeId;

  @override
  ConsumerState<TaskScreen> createState() => _TaskScreenState();
}

class _TaskScreenState extends ConsumerState<TaskScreen> {
  static const int _maxLives = 3;

  int _index = 0;
  int _correct = 0;
  int _lives = _maxLives;
  bool _answered = false;
  bool _lastCorrect = false;
  AvatarAnimationState _avatar = AvatarAnimationState.idle;
  Timer? _advanceTimer;

  LearnNode? get _node => nodeById(widget.subjectId, widget.nodeId);

  @override
  void dispose() {
    _advanceTimer?.cancel();
    super.dispose();
  }

  void _handleAnswer(bool correct) {
    if (_answered) return;
    setState(() {
      _answered = true;
      _lastCorrect = correct;
      if (correct) {
        _correct++;
        _avatar = AvatarAnimationState.celebrate;
      } else {
        _lives = (_lives - 1).clamp(0, _maxLives);
        _avatar = AvatarAnimationState.sad;
      }
    });

    if (correct) {
      SystemSound.play(SystemSoundType.click);
      showRewardToast(context, amount: 5, kind: RewardKind.xp, topOffset: 160);
      _advanceTimer = Timer(const Duration(milliseconds: 1100), () {
        if (mounted) _next();
      });
    } else {
      HapticFeedback.mediumImpact();
    }
  }

  void _next() {
    _advanceTimer?.cancel();
    final node = _node!;
    if (_index < node.questions.length - 1) {
      setState(() {
        _index++;
        _answered = false;
        _lastCorrect = false;
        _avatar = AvatarAnimationState.idle;
      });
    } else {
      _finish(node);
    }
  }

  Future<void> _finish(LearnNode node) async {
    final result = await ref.read(learnProvider.notifier).completeNode(
          subjectId: widget.subjectId,
          node: node,
          correct: _correct,
          heartsLeft: _lives,
        );
    if (mounted) {
      context.pushReplacement(AppRoutes.learnResult, extra: result);
    }
  }

  Future<void> _confirmQuit() async {
    final quit = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: Text(LearnStrings.quitTitle, style: AppTypography.heading3),
        content: Text(LearnStrings.quitBody, style: AppTypography.body),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(LearnStrings.stay),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(LearnStrings.quitConfirm,
                style: const TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (quit == true && mounted) _close();
  }

  void _close() {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go(AppRoutes.learn);
    }
  }

  @override
  Widget build(BuildContext context) {
    final node = _node;
    if (node == null || node.questions.isEmpty) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(child: Text('—')),
      );
    }

    final assistant =
        ref.watch(authProvider.select((s) => s.user?.assistantType)) ??
            AssistantType.bektur;
    final question = node.questions[_index];
    final total = node.questions.length;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _TopBar(
              index: _index,
              total: total,
              lives: _lives,
              onClose: _confirmQuit,
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(AppSpacing.space5),
                child: KeyedSubtree(
                  key: ValueKey(_index),
                  child: _buildTask(question),
                ),
              ),
            ),
            _Footer(
              assistant: assistant,
              equipped: ref.watch(equippedSlotsProvider),
              avatarState: _avatar,
              showContinue: _answered && !_lastCorrect,
              onContinue: _next,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTask(Question q) => switch (q) {
        MultipleChoiceQuestion() =>
          MultipleChoiceTask(question: q, onAnswered: _handleAnswer),
        TrueFalseQuestion() =>
          TrueFalseTask(question: q, onAnswered: _handleAnswer),
        FillBlankQuestion() =>
          FillInBlankTask(question: q, onAnswered: _handleAnswer),
        MatchPairsQuestion() =>
          MatchPairsTask(question: q, onAnswered: _handleAnswer),
      };
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.index,
    required this.total,
    required this.lives,
    required this.onClose,
  });

  final int index;
  final int total;
  final int lives;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.space4,
        AppSpacing.space3,
        AppSpacing.space4,
        AppSpacing.space2,
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: onClose,
            behavior: HitTestBehavior.opaque,
            child: const Icon(Icons.close_rounded, color: AppColors.textSecondary),
          ),
          const SizedBox(width: AppSpacing.space3),
          Expanded(
            child: Row(
              children: [
                for (var i = 0; i < total; i++)
                  Expanded(
                    child: Container(
                      height: 8,
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      decoration: BoxDecoration(
                        color: i < index
                            ? AppColors.success
                            : (i == index
                                ? AppColors.primary
                                : AppColors.surfaceMuted),
                        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.space3),
          HeartsDisplay(lives: lives, size: 20),
        ],
      ),
    );
  }
}

class _Footer extends StatelessWidget {
  const _Footer({
    required this.assistant,
    required this.equipped,
    required this.avatarState,
    required this.showContinue,
    required this.onContinue,
  });

  final AssistantType assistant;
  final Map<AvatarSlot, String> equipped;
  final AvatarAnimationState avatarState;
  final bool showContinue;
  final VoidCallback onContinue;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.space5,
        0,
        AppSpacing.space5,
        AppSpacing.space5,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          SizedBox(
            height: 88,
            width: 80,
            child: OverflowBox(
              maxHeight: 120,
              child: AvatarDisplay(
                  type: assistant,
                  state: avatarState,
                  equipped: equipped,
                  size: 96),
            ),
          ),
          const SizedBox(width: AppSpacing.space3),
          Expanded(
            child: AnimatedOpacity(
              duration: const Duration(milliseconds: 200),
              opacity: showContinue ? 1 : 0,
              child: IgnorePointer(
                ignoring: !showContinue,
                child: GradientButton(
                  label: LearnStrings.continueLabel,
                  gradient: AppColors.bekturGradient,
                  onPressed: onContinue,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
