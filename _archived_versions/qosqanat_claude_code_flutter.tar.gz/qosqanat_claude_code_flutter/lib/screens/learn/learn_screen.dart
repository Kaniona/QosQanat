import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/learn_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/curriculum.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/learn_provider.dart';
import 'widgets/subject_card.dart';

/// "📚 Пәндер" — the subject selection grid. Each card is a portal into a
/// subject's learning world.
class LearnScreen extends ConsumerStatefulWidget {
  const LearnScreen({super.key});

  @override
  ConsumerState<LearnScreen> createState() => _LearnScreenState();
}

class _LearnScreenState extends ConsumerState<LearnScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final user = ref.read(authProvider).user;
      if (user != null) ref.read(learnProvider.notifier).loadFor(user.id);
    });
  }

  @override
  Widget build(BuildContext context) {
    ref.watch(learnProvider); // rebuild as progress loads/changes
    final learn = ref.read(learnProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.space5,
                AppSpacing.space5,
                AppSpacing.space5,
                AppSpacing.space3,
              ),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: [
                    _BackButton(onTap: () => _close(context)),
                    const SizedBox(width: AppSpacing.space3),
                    Text(
                      LearnStrings.subjectsTitle,
                      style: AppTypography.heading1.copyWith(color: AppColors.ink),
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.space5,
                0,
                AppSpacing.space5,
                AppSpacing.space8,
              ),
              sliver: SliverGrid(
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: AppSpacing.space4,
                  crossAxisSpacing: AppSpacing.space4,
                  childAspectRatio: 0.92,
                ),
                delegate: SliverChildBuilderDelegate(
                  (context, i) {
                    final subject = kCurriculum[i];
                    return SubjectCard(
                      subject: subject,
                      completed: learn.completedCount(subject.id),
                      onTap: () => context.push(
                        '${AppRoutes.learnMap}/${subject.id}',
                      ),
                    )
                        .animate()
                        .fadeIn(delay: (60 * i).ms, duration: 350.ms)
                        .slideY(begin: 0.1, end: 0, curve: Curves.easeOutCubic);
                  },
                  childCount: kCurriculum.length,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _close(BuildContext context) {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go(AppRoutes.home);
    }
  }
}

class _BackButton extends StatelessWidget {
  const _BackButton({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 40,
        height: 40,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: AppColors.surface,
          shape: BoxShape.circle,
          boxShadow: const [
            BoxShadow(color: AppColors.shadow, blurRadius: 10, offset: Offset(0, 3)),
          ],
        ),
        child: const Icon(Icons.arrow_back_rounded, color: AppColors.ink, size: 22),
      ),
    );
  }
}
