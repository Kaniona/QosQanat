import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/constants/home_strings.dart';
import '../../core/constants/tutorial_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/assistant_theme.dart';
import '../../data/achievements.dart';
import '../../data/levels.dart';
import '../../models/enums.dart';
import '../../models/quest.dart';
import '../../models/user.dart' as model;
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/daily_quests_provider.dart';
import '../../providers/game_provider.dart';
import '../../providers/shop_provider.dart';
import '../../widgets/game/level_up_modal.dart';
import '../../widgets/game/reward_toast.dart';
import '../../screens/onboarding/tutorial_overlay.dart';
import '../../widgets/voice/voice_overlay.dart';
import 'widgets/continue_learning_card.dart';
import 'widgets/daily_quests_section.dart';
import 'widgets/fly_reward.dart';
import 'widgets/greeting_hero.dart';
import 'widgets/home_header.dart';
import 'widgets/level_progress_card.dart';
import 'widgets/quick_actions.dart';
import 'widgets/recent_achievements.dart';
import 'widgets/streak_card.dart';
import 'widgets/voice_fab.dart';

/// QosQanat's daily landing page (Басты бет): a warm, live dashboard of the
/// student's progress, daily quests and their assistant. All data flows from
/// the auth, game and daily-quests providers so it updates in real time.
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final GlobalKey _pillsKey = GlobalKey();

  // Tutorial spotlight targets.
  final GlobalKey _heroKey = GlobalKey();
  final GlobalKey _learnKey = GlobalKey();
  final GlobalKey _battleKey = GlobalKey();
  final GlobalKey _ratingKey = GlobalKey();
  final GlobalKey _questsKey = GlobalKey();
  final GlobalKey _voiceKey = GlobalKey();

  OverlayEntry? _tutorialEntry;

  @override
  void initState() {
    super.initState();
    // Seed live game state from the profile that's already loaded (if any).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final user = ref.read(authProvider).user;
      if (user != null) {
        ref.read(gameProvider.notifier).ensureSeeded(user);
        ref.read(shopProvider.notifier).loadFor(user.id);
      }
      _maybeShowTutorial();
    });
  }

  @override
  void dispose() {
    _tutorialEntry?.remove();
    _tutorialEntry = null;
    super.dispose();
  }

  /// Runs the eight-step spotlight tour once, on the very first Home visit
  /// after onboarding. The seen-flag is persisted so it never repeats.
  Future<void> _maybeShowTutorial() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool('tutorial_seen') ?? false) return;
      if (!mounted || ref.read(authProvider).user == null) return;
      // Let the first layout settle so target rects resolve.
      await Future<void>.delayed(const Duration(milliseconds: 600));
      if (!mounted || _tutorialEntry != null) return;

      final entry = OverlayEntry(
        builder: (_) => TutorialOverlay(
          steps: _tutorialSteps(),
          onFinish: () async {
            await prefs.setBool('tutorial_seen', true);
            _removeTutorial();
          },
        ),
      );
      _tutorialEntry = entry;
      Overlay.of(context).insert(entry);
    } catch (_) {
      // Storage unavailable (e.g. tests): skip the tutorial silently.
    }
  }

  void _removeTutorial() {
    _tutorialEntry?.remove();
    _tutorialEntry = null;
  }

  List<TutorialStep> _tutorialSteps() => [
        TutorialStep(targetKey: _heroKey, title: TutorialStrings.assistantTitle, body: TutorialStrings.assistantBody),
        TutorialStep(targetKey: _pillsKey, title: TutorialStrings.pointsTitle, body: TutorialStrings.pointsBody),
        TutorialStep(targetKey: _learnKey, title: TutorialStrings.learnTitle, body: TutorialStrings.learnBody),
        TutorialStep(targetKey: _pillsKey, title: TutorialStrings.shopTitle, body: TutorialStrings.shopBody),
        TutorialStep(targetKey: _battleKey, title: TutorialStrings.friendsTitle, body: TutorialStrings.friendsBody),
        TutorialStep(targetKey: _ratingKey, title: TutorialStrings.ratingTitle, body: TutorialStrings.ratingBody),
        TutorialStep(targetKey: _questsKey, title: TutorialStrings.questsTitle, body: TutorialStrings.questsBody),
        TutorialStep(targetKey: _voiceKey, title: TutorialStrings.voiceTitle, body: TutorialStrings.voiceBody),
        const TutorialStep(title: TutorialStrings.finaleTitle, body: TutorialStrings.finaleBody, isFinale: true),
      ];

  @override
  Widget build(BuildContext context) {
    // Seed once the profile arrives after an async session load.
    ref.listen<model.User?>(
      authProvider.select((s) => s.user),
      (_, user) {
        if (user != null) ref.read(gameProvider.notifier).ensureSeeded(user);
      },
    );

    // Surface level-up celebrations the game notifier flags.
    ref.listen<LevelUpEvent?>(
      gameProvider.select((s) => s.pendingLevelUp),
      (_, event) {
        if (event == null) return;
        showLevelUpModal(
          context,
          previousLevel: event.previousLevel,
          newLevel: event.newLevel,
          coinReward: event.coinReward,
        );
        ref.read(gameProvider.notifier).clearLevelUp();
      },
    );

    // Surface streak-milestone rewards as a floating toast.
    ref.listen<StreakEvent?>(
      gameProvider.select((s) => s.pendingStreak),
      (_, event) {
        if (event == null) return;
        showRewardToast(context, amount: event.coinReward, kind: RewardKind.coins);
        ref.read(gameProvider.notifier).clearStreak();
      },
    );

    final user = ref.watch(authProvider.select((s) => s.user));
    final game = ref.watch(gameProvider);
    final quests = ref.watch(dailyQuestsProvider);

    final assistant = user?.assistantType ?? AssistantType.bektur;
    final name = _firstName(user?.fullName);
    final grade = user?.grade ?? 5;
    final completed =
        quests.where((q) => q.isCompleted).length; // for the "3/5" chip
    final unlocked = _unlockedAchievements(user, game);
    final equippedSlots = ref.watch(equippedSlotsProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: AppSpacing.space2),
        child: KeyedSubtree(
          key: _voiceKey,
          child: VoiceFab(
            gradient: assistant.gradient,
            glowColor: assistant.accent,
            onTap: () => showVoiceOverlay(context),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // 1 — Sticky header (stays put while the rest scrolls).
            HomeHeader(
              initial: _initial(name),
              assistant: assistant,
              coins: game.coins,
              xp: game.xp,
              akyl: game.akylPoints,
              hasUnread: true,
              pillsKey: _pillsKey,
              onTapProfile: () => context.go(AppRoutes.profile),
              onTapBell: () => _toast(HomeStrings.comingSoon),
              onTapCoins: () => context.go(AppRoutes.shop),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.only(bottom: 120),
                // Build off-screen sections eagerly so the first-time tutorial
                // can resolve and scroll to every spotlight target.
                cacheExtent: 2000,
                children: [
                  _padded(KeyedSubtree(
                    key: _heroKey,
                    child: GreetingHero(
                      name: name,
                      assistant: assistant,
                      hour: DateTime.now().hour,
                      equipped: equippedSlots,
                    ),
                  )),
                  const SizedBox(height: AppSpacing.space4),
                  _padded(LevelProgressCard(
                    level: game.level,
                    progress: game.levelProgress,
                    xpIntoLevel: game.xpIntoLevel,
                    xpForLevelSpan: game.xpForNextLevel - game.xpForCurrentLevel,
                    xpToNextLevel: game.xpToNextLevel,
                    isMaxLevel: game.level >= kMaxLevel,
                  )),
                  const SizedBox(height: AppSpacing.space4),
                  _padded(StreakCard(streak: game.streak)),
                  const SizedBox(height: AppSpacing.space6),
                  KeyedSubtree(
                    key: _questsKey,
                    child: DailyQuestsSection(
                      quests: quests,
                      completed: completed,
                      onClaim: _onClaimQuest,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.space6),
                  _padded(QuickActions(
                    learnKey: _learnKey,
                    battleKey: _battleKey,
                    ratingKey: _ratingKey,
                    onLearn: () => context.go(AppRoutes.learn),
                    onBattle: () => context.go(AppRoutes.friends),
                    onRating: () => context.push(AppRoutes.rating),
                  )),
                  const SizedBox(height: AppSpacing.space4),
                  _padded(ContinueLearningCard(
                    subject: HomeStrings.continueSubject,
                    grade: grade,
                    progress: 0.45,
                    onContinue: () => _toast(HomeStrings.comingSoon),
                  )),
                  const SizedBox(height: AppSpacing.space6),
                  RecentAchievements(
                    unlocked: unlocked,
                    onViewAll: () => _toast(HomeStrings.comingSoon),
                  ),
                ].animate(interval: 60.ms).fadeIn(duration: 350.ms).slideY(
                      begin: 0.08,
                      end: 0,
                      curve: Curves.easeOutCubic,
                    ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Flies a reward badge from the claimed card to the header pills, granting
  /// the reward (which animates the counters) right as the badge lands.
  void _onClaimQuest(Quest quest, Offset source) {
    final emoji = quest.coinReward > 0 ? '💰' : '⚡';
    flyReward(
      context,
      from: source,
      to: _pillsCenter() ?? source,
      emoji: emoji,
      onArrive: () => ref.read(dailyQuestsProvider.notifier).claim(quest.id),
    );
  }

  Offset? _pillsCenter() {
    final box = _pillsKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null) return null;
    return box.localToGlobal(box.size.center(Offset.zero));
  }

  /// Achievements satisfied by the player's current stats.
  List<AchievementDef> _unlockedAchievements(model.User? user, GameState game) {
    final stats = AchievementStats(
      tasksCompleted: user?.totalTasksCompleted ?? 0,
      level: game.level,
      battlesWon: user?.totalBattlesWon ?? 0,
      streakDays: game.streak,
      akylPoints: game.akylPoints,
      coinsEarned: game.coins,
    );
    return [for (final a in kAchievements) if (a.isUnlockedBy(stats)) a];
  }

  void _toast(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
      ));
  }

  static Widget _padded(Widget child) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space5),
        child: child,
      );

  static String _firstName(String? fullName) {
    final trimmed = (fullName ?? '').trim();
    if (trimmed.isEmpty) return HomeStrings.defaultName;
    return trimmed.split(RegExp(r'\s+')).first;
  }

  static String _initial(String name) =>
      name.isEmpty ? 'Q' : name.characters.first.toUpperCase();
}
