import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';

/// A 64px circular voice button in the assistant's gradient with a soft,
/// continuously pulsing glow ring. Opens the voice assistant when tapped.
class VoiceFab extends StatefulWidget {
  const VoiceFab({
    super.key,
    required this.gradient,
    required this.glowColor,
    required this.onTap,
  });

  final Gradient gradient;
  final Color glowColor;
  final VoidCallback onTap;

  @override
  State<VoiceFab> createState() => _VoiceFabState();
}

class _VoiceFabState extends State<VoiceFab>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1800),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: SizedBox(
        width: 96,
        height: 96,
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            final t = _controller.value;
            return Stack(
              alignment: Alignment.center,
              children: [
                // Expanding, fading glow ring.
                Container(
                  width: 64 + 32 * t,
                  height: 64 + 32 * t,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: widget.glowColor.withValues(alpha: 0.25 * (1 - t)),
                  ),
                ),
                child!,
              ],
            );
          },
          child: Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              gradient: widget.gradient,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: widget.glowColor.withValues(alpha: 0.5),
                  blurRadius: 18,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: const Icon(Icons.mic_rounded, color: AppColors.white, size: 30),
          ),
        ),
      ),
    );
  }
}
