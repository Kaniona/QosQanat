import 'package:flutter/material.dart';

import '../../../core/constants/home_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../data/achievements.dart';
import 'section_header.dart';

/// "Соңғы жетістіктер" section: a "see all" link and a horizontal row of
/// earned achievement medallions, or a gentle nudge when none are unlocked yet.
class RecentAchievements extends StatelessWidget {
  const RecentAchievements({
    super.key,
    required this.unlocked,
    required this.onViewAll,
  });

  final List<AchievementDef> unlocked;
  final VoidCallback onViewAll;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space5),
          child: SectionHeader(
            title: HomeStrings.achievementsTitle,
            trailing: GestureDetector(
              onTap: onViewAll,
              behavior: HitTestBehavior.opaque,
              child: Text(
                HomeStrings.viewAll,
                style: AppTypography.caption.copyWith(
                  color: AppColors.primary,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.space3),
        if (unlocked.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space5),
            child: Text(
              HomeStrings.noAchievements,
              style: AppTypography.bodySmall,
            ),
          )
        else
          SizedBox(
            height: 104,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space5),
              itemCount: unlocked.length,
              itemBuilder: (context, i) => _Medallion(achievement: unlocked[i]),
            ),
          ),
      ],
    );
  }
}

class _Medallion extends StatelessWidget {
  const _Medallion({required this.achievement});

  final AchievementDef achievement;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 76,
      margin: const EdgeInsets.only(right: AppSpacing.space3),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 60,
            height: 60,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              gradient: AppColors.goldGradient,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppColors.gold.withValues(alpha: 0.4),
                  blurRadius: 12,
                ),
              ],
            ),
            child: Text(achievement.emoji, style: const TextStyle(fontSize: 28)),
          ),
          const SizedBox(height: 4),
          Text(
            achievement.title,
            maxLines: 2,
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            style: AppTypography.caption.copyWith(height: 1.1),
          ),
        ],
      ),
    );
  }
}
