import 'package:flutter/material.dart';

import '../../../core/constants/home_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../data/levels.dart';
import '../../../widgets/game/xp_bar.dart';
import 'app_card.dart';

/// White card showing the level badge + title, the animated [XpBar], and how
/// much XP remains until the next level.
class LevelProgressCard extends StatelessWidget {
  const LevelProgressCard({
    super.key,
    required this.level,
    required this.progress,
    required this.xpIntoLevel,
    required this.xpForLevelSpan,
    required this.xpToNextLevel,
    required this.isMaxLevel,
  });

  final int level;
  final double progress;
  final int xpIntoLevel;
  final int xpForLevelSpan;
  final int xpToNextLevel;
  final bool isMaxLevel;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            levelTitle(level),
            style: AppTypography.heading3.copyWith(color: AppColors.ink),
          ),
          const SizedBox(height: AppSpacing.space3),
          XpBar(
            level: level,
            progress: progress,
            xpInto: isMaxLevel ? null : xpIntoLevel,
            xpNeeded: isMaxLevel ? null : xpForLevelSpan,
          ),
          const SizedBox(height: AppSpacing.space2),
          Text(
            isMaxLevel
                ? HomeStrings.maxLevel
                : HomeStrings.xpToNext(xpToNextLevel),
            style: AppTypography.caption,
          ),
        ],
      ),
    );
  }
}
