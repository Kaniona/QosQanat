import 'package:flutter/material.dart';

import '../../../core/constants/home_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import 'app_card.dart';

/// Warm orange-accented card celebrating the login streak: a flame, the day
/// count, a row of seven day-circles, and an encouragement line.
class StreakCard extends StatelessWidget {
  const StreakCard({super.key, required this.streak});

  /// Current consecutive-day streak (0 when not started today).
  final int streak;

  static const Color _flame = AppColors.warning;

  /// State of the i-th day-circle given the streak's position in the week.
  _DayState _dayState(int i, int todayIndex) {
    if (streak == 0) return _DayState.upcoming;
    if (i < todayIndex) return _DayState.done;
    if (i == todayIndex) return _DayState.today;
    return _DayState.upcoming;
  }

  @override
  Widget build(BuildContext context) {
    // Position within the current 7-day week (today is the streak's last day).
    final todayIndex = streak == 0 ? 0 : (streak - 1) % 7;

    return AppCard(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [_flame.withValues(alpha: 0.14), _flame.withValues(alpha: 0.04)],
      ),
      borderColor: _flame.withValues(alpha: 0.25),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              const Text('🔥', style: TextStyle(fontSize: 26)),
              const SizedBox(width: AppSpacing.space2),
              Text(
                streak == 0
                    ? HomeStrings.streakStart
                    : HomeStrings.streakDays(streak),
                style: AppTypography.heading3.copyWith(color: AppColors.ink),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.space4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              for (var i = 0; i < 7; i++)
                _DayCircle(state: _dayState(i, todayIndex)),
            ],
          ),
          const SizedBox(height: AppSpacing.space4),
          Text(
            streak == 0
                ? HomeStrings.streakEncourage(1)
                : HomeStrings.streakEncourage(streak + 1),
            style: AppTypography.bodySmall,
          ),
        ],
      ),
    );
  }
}

enum _DayState { done, today, upcoming }

class _DayCircle extends StatefulWidget {
  const _DayCircle({required this.state});

  final _DayState state;

  @override
  State<_DayCircle> createState() => _DayCircleState();
}

class _DayCircleState extends State<_DayCircle>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    // Created eagerly (not lazily) so it always exists while mounted — a lazy
    // field would otherwise be built inside dispose(), which is unsafe.
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    );
    if (widget.state == _DayState.today) _pulse.repeat(reverse: true);
  }

  @override
  void didUpdateWidget(covariant _DayCircle oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.state == _DayState.today && !_pulse.isAnimating) {
      _pulse.repeat(reverse: true);
    } else if (widget.state != _DayState.today && _pulse.isAnimating) {
      _pulse
        ..stop()
        ..value = 0;
    }
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const orange = AppColors.warning;
    final circle = switch (widget.state) {
      _DayState.done => Container(
          width: 32,
          height: 32,
          decoration: const BoxDecoration(color: orange, shape: BoxShape.circle),
          child: const Icon(Icons.check_rounded,
              color: AppColors.white, size: 18),
        ),
      _DayState.today => Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: orange.withValues(alpha: 0.18),
            shape: BoxShape.circle,
            border: Border.all(color: orange, width: 2),
          ),
          child: const Icon(Icons.local_fire_department_rounded,
              color: orange, size: 18),
        ),
      _DayState.upcoming => Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.border, width: 2),
          ),
        ),
    };

    if (widget.state != _DayState.today) return circle;
    return ScaleTransition(
      scale: Tween<double>(begin: 0.92, end: 1.12).animate(
        CurvedAnimation(parent: _pulse, curve: Curves.easeInOut),
      ),
      child: circle,
    );
  }
}
