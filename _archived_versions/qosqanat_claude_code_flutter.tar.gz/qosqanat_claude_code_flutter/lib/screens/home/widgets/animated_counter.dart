import 'package:flutter/material.dart';

import '../../../core/utils/format.dart';

/// A number that smoothly counts up (or down) whenever [value] changes.
///
/// Used by the resource pills so coins/XP/akyl tick toward their new total
/// instead of snapping, reinforcing the reward feeling.
class AnimatedCounter extends StatelessWidget {
  const AnimatedCounter({
    super.key,
    required this.value,
    required this.style,
    this.duration = const Duration(milliseconds: 650),
  });

  final int value;
  final TextStyle style;
  final Duration duration;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<int>(
      tween: IntTween(begin: value, end: value),
      duration: duration,
      curve: Curves.easeOutCubic,
      builder: (context, animated, _) => Text(
        formatThousands(animated),
        style: style,
      ),
    );
  }
}
