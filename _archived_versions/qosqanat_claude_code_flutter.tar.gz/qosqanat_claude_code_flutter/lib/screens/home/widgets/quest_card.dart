import 'package:flutter/material.dart';

import '../../../core/constants/home_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/quest.dart';

/// A single daily-quest card (~160×130) for the horizontal quest rail.
///
/// Shows the icon, title, a progress bar and a reward chip. When finished and
/// unclaimed it gets a green border and a gold "Алу" button; tapping it reports
/// the button's screen position via [onClaim] so the reward can fly to the
/// header counters.
class QuestCard extends StatelessWidget {
  const QuestCard({super.key, required this.quest, required this.onClaim});

  final Quest quest;

  /// Called with the global center of the card when its claim button is tapped.
  final void Function(Offset source) onClaim;

  @override
  Widget build(BuildContext context) {
    final claimable = quest.isCompleted && !quest.isClaimed;
    final cardKey = GlobalKey();

    return Container(
      key: cardKey,
      width: 162,
      margin: const EdgeInsets.only(right: AppSpacing.space3),
      padding: const EdgeInsets.all(AppSpacing.space3),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        border: Border.all(
          color: claimable ? AppColors.success : AppColors.border,
          width: claimable ? 2 : 1.5,
        ),
        boxShadow: const [
          BoxShadow(color: AppColors.shadow, blurRadius: 12, offset: Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Text(quest.iconName ?? '🎯', style: const TextStyle(fontSize: 22)),
              const Spacer(),
              _RewardChip(coins: quest.coinReward, xp: quest.xpReward),
            ],
          ),
          const SizedBox(height: AppSpacing.space2),
          Text(
            quest.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: AppTypography.bodySmall.copyWith(
              color: AppColors.ink,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: AppSpacing.space2),
          _ProgressBar(fraction: quest.progressFraction),
          const SizedBox(height: AppSpacing.space2),
          _Footer(
            quest: quest,
            claimable: claimable,
            onClaim: () {
              final box = cardKey.currentContext?.findRenderObject() as RenderBox?;
              final center = box == null
                  ? Offset.zero
                  : box.localToGlobal(box.size.center(Offset.zero));
              onClaim(center);
            },
          ),
        ],
      ),
    );
  }
}

class _RewardChip extends StatelessWidget {
  const _RewardChip({required this.coins, required this.xp});

  final int coins;
  final int xp;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: AppColors.surfaceMuted,
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
      ),
      child: Text(
        coins > 0 ? '💰$coins' : '⚡$xp',
        style: AppTypography.caption.copyWith(
          color: AppColors.goldDeep,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _ProgressBar extends StatelessWidget {
  const _ProgressBar({required this.fraction});

  final double fraction;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
      child: Stack(
        children: [
          Container(height: 6, color: AppColors.surfaceMuted),
          FractionallySizedBox(
            widthFactor: fraction.clamp(0.0, 1.0),
            child: Container(
              height: 6,
              decoration: const BoxDecoration(gradient: AppColors.successGradient),
            ),
          ),
        ],
      ),
    );
  }
}

class _Footer extends StatelessWidget {
  const _Footer({
    required this.quest,
    required this.claimable,
    required this.onClaim,
  });

  final Quest quest;
  final bool claimable;
  final VoidCallback onClaim;

  @override
  Widget build(BuildContext context) {
    if (quest.isClaimed) {
      return Text(
        HomeStrings.claimed,
        style: AppTypography.caption.copyWith(
          color: AppColors.success,
          fontWeight: FontWeight.w800,
        ),
      );
    }
    if (!claimable) {
      return Text(
        '${quest.currentProgress}/${quest.targetProgress}',
        style: AppTypography.caption.copyWith(fontWeight: FontWeight.w700),
      );
    }
    return GestureDetector(
      onTap: onClaim,
      child: Container(
        height: 30,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: AppColors.goldGradient,
          borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
        ),
        child: Text(
          HomeStrings.claim,
          style: AppTypography.caption.copyWith(
            color: AppColors.ink,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }
}
