import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';

/// A soft white surface card with rounded corners and a subtle shadow — the
/// shared container for Home's content sections.
class AppCard extends StatelessWidget {
  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(AppSpacing.space4),
    this.gradient,
    this.borderColor,
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;

  /// Optional gradient fill; when null the card is flat [AppColors.surface].
  final Gradient? gradient;
  final Color? borderColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final decoration = BoxDecoration(
      color: gradient == null ? AppColors.surface : null,
      gradient: gradient,
      borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
      border: borderColor == null ? null : Border.all(color: borderColor!, width: 1.5),
      boxShadow: const [
        BoxShadow(color: AppColors.shadow, blurRadius: 16, offset: Offset(0, 6)),
      ],
    );

    final content = Padding(padding: padding, child: child);

    if (onTap == null) {
      return DecoratedBox(decoration: decoration, child: content);
    }
    return Material(
      color: Colors.transparent,
      child: Ink(
        decoration: decoration,
        child: InkWell(
          borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
          onTap: onTap,
          child: content,
        ),
      ),
    );
  }
}
