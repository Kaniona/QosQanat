import 'package:flutter/material.dart';

import '../../../core/constants/home_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/theme/assistant_theme.dart';
import '../../../models/enums.dart';
import '../../../widgets/avatar/avatar_base.dart';
import '../../../widgets/avatar/avatar_display.dart';

/// The greeting hero: a time-based welcome and subtitle on the left, the
/// student's chosen assistant waving on the right, over a soft gradient card.
class GreetingHero extends StatelessWidget {
  const GreetingHero({
    super.key,
    required this.name,
    required this.assistant,
    required this.hour,
    this.equipped = const {},
  });

  final String name;
  final AssistantType assistant;

  /// Device-clock hour (0–23), injected so the copy is testable.
  final int hour;

  /// Equipped cosmetics, so the home avatar matches the saved look.
  final Map<AvatarSlot, String> equipped;

  @override
  Widget build(BuildContext context) {
    final accent = assistant.accent;
    return Container(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.space5,
        AppSpacing.space4,
        AppSpacing.space3,
        AppSpacing.space4,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            accent.withValues(alpha: 0.16),
            accent.withValues(alpha: 0.04),
          ],
        ),
        borderRadius: BorderRadius.circular(AppSpacing.radiusXl),
        border: Border.all(color: accent.withValues(alpha: 0.18)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  HomeStrings.greeting(hour, name),
                  style: AppTypography.heading2.copyWith(color: AppColors.ink),
                ),
                const SizedBox(height: AppSpacing.space1),
                Text(
                  HomeStrings.greetingSubtitle,
                  style: AppTypography.body
                      .copyWith(color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.space2),
          SizedBox(
            height: 120,
            width: 110,
            child: OverflowBox(
              maxHeight: 150,
              child: AvatarDisplay(
                type: assistant,
                state: AvatarAnimationState.wave,
                equipped: equipped,
                size: 120,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
