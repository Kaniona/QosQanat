import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';

/// Flies a small reward badge ([emoji]) from [from] to [to] in screen
/// coordinates, then removes itself. [onArrive] fires when it lands — the Home
/// screen uses it to grant the reward exactly as the badge reaches the counter.
void flyReward(
  BuildContext context, {
  required Offset from,
  required Offset to,
  required String emoji,
  VoidCallback? onArrive,
}) {
  final overlay = Overlay.of(context);
  late OverlayEntry entry;
  entry = OverlayEntry(
    builder: (_) => _FlyingReward(
      from: from,
      to: to,
      emoji: emoji,
      onArrive: onArrive,
      onDone: () => entry.remove(),
    ),
  );
  overlay.insert(entry);
}

class _FlyingReward extends StatefulWidget {
  const _FlyingReward({
    required this.from,
    required this.to,
    required this.emoji,
    required this.onDone,
    this.onArrive,
  });

  final Offset from;
  final Offset to;
  final String emoji;
  final VoidCallback onDone;
  final VoidCallback? onArrive;

  @override
  State<_FlyingReward> createState() => _FlyingRewardState();
}

class _FlyingRewardState extends State<_FlyingReward>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 750),
  );
  bool _arrived = false;

  @override
  void initState() {
    super.initState();
    _c
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) widget.onDone();
      })
      ..addListener(() {
        if (!_arrived && _c.value >= 0.92) {
          _arrived = true;
          widget.onArrive?.call();
        }
      })
      ..forward();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final curve = CurvedAnimation(parent: _c, curve: Curves.easeInCubic);
    return AnimatedBuilder(
      animation: curve,
      builder: (context, _) {
        final t = curve.value;
        // Lerp with a small upward arc for a livelier path.
        final x = widget.from.dx + (widget.to.dx - widget.from.dx) * t;
        final lift = -60 * (t * (1 - t)) * 4;
        final y = widget.from.dy + (widget.to.dy - widget.from.dy) * t + lift;
        final scale = 1.0 - 0.5 * t;
        final opacity = t < 0.85 ? 1.0 : (1 - (t - 0.85) / 0.15);

        return Positioned(
          left: x - 18,
          top: y - 18,
          child: IgnorePointer(
            child: Opacity(
              opacity: opacity.clamp(0.0, 1.0),
              child: Transform.scale(
                scale: scale,
                child: Container(
                  width: 36,
                  height: 36,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    gradient: AppColors.goldGradient,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.gold.withValues(alpha: 0.6),
                        blurRadius: 12,
                      ),
                    ],
                  ),
                  child: Text(widget.emoji, style: AppTypography.caption),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
