import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';

/// A row with a bold section [title] on the left and an optional [trailing]
/// widget (a progress chip or a "see all" link) on the right.
class SectionHeader extends StatelessWidget {
  const SectionHeader({super.key, required this.title, this.trailing});

  final String title;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: AppTypography.heading3.copyWith(color: AppColors.ink),
          ),
        ),
        ?trailing,
      ],
    );
  }
}
