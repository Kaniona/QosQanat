import 'package:flutter/material.dart';

import '../../../core/constants/home_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/quest.dart';
import 'quest_card.dart';
import 'section_header.dart';

/// The "Бүгінгі квесттер" section: a header with a completed/total chip and a
/// horizontally scrolling rail of [QuestCard]s.
class DailyQuestsSection extends StatelessWidget {
  const DailyQuestsSection({
    super.key,
    required this.quests,
    required this.completed,
    required this.onClaim,
  });

  final List<Quest> quests;
  final int completed;

  /// Reports which quest was claimed and where its card sat on screen.
  final void Function(Quest quest, Offset source) onClaim;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space5),
          child: SectionHeader(
            title: HomeStrings.questsTitle,
            trailing: _ProgressPill(completed: completed, total: quests.length),
          ),
        ),
        const SizedBox(height: AppSpacing.space3),
        SizedBox(
          height: 138,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space5),
            itemCount: quests.length,
            itemBuilder: (context, i) {
              final quest = quests[i];
              return QuestCard(
                quest: quest,
                onClaim: (source) => onClaim(quest, source),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _ProgressPill extends StatelessWidget {
  const _ProgressPill({required this.completed, required this.total});

  final int completed;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space3, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.primary.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
      ),
      child: Text(
        '$completed/$total',
        style: AppTypography.caption.copyWith(
          color: AppColors.primary,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}
