import 'package:flutter/material.dart';

import '../../../core/constants/home_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';

/// A row of three large gradient action cards: Learn, Battle, Rating.
class QuickActions extends StatelessWidget {
  const QuickActions({
    super.key,
    required this.onLearn,
    required this.onBattle,
    required this.onRating,
    this.learnKey,
    this.battleKey,
    this.ratingKey,
  });

  final VoidCallback onLearn;
  final VoidCallback onBattle;
  final VoidCallback onRating;

  /// Optional keys used by the first-time tutorial to spotlight each action.
  final Key? learnKey;
  final Key? battleKey;
  final Key? ratingKey;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: KeyedSubtree(
            key: learnKey,
            child: _ActionCard(
              label: HomeStrings.actionLearn,
              icon: Icons.menu_book_rounded,
              gradient: AppColors.bekturGradient,
              onTap: onLearn,
            ),
          ),
        ),
        const SizedBox(width: AppSpacing.space3),
        Expanded(
          child: KeyedSubtree(
            key: battleKey,
            child: _ActionCard(
              label: HomeStrings.actionBattle,
              icon: Icons.sports_kabaddi_rounded,
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppColors.secondaryLight, AppColors.secondary, AppColors.secondaryDark],
              ),
              onTap: onBattle,
            ),
          ),
        ),
        const SizedBox(width: AppSpacing.space3),
        Expanded(
          child: KeyedSubtree(
            key: ratingKey,
            child: _ActionCard(
              label: HomeStrings.actionRating,
              icon: Icons.emoji_events_rounded,
              gradient: AppColors.goldGradient,
              foreground: AppColors.ink,
              onTap: onRating,
            ),
          ),
        ),
      ],
    );
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.label,
    required this.icon,
    required this.gradient,
    required this.onTap,
    this.foreground = AppColors.white,
  });

  final String label;
  final IconData icon;
  final Gradient gradient;
  final VoidCallback onTap;
  final Color foreground;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Ink(
        decoration: BoxDecoration(
          gradient: gradient,
          borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
          boxShadow: const [
            BoxShadow(color: AppColors.shadow, blurRadius: 14, offset: Offset(0, 6)),
          ],
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: AppSpacing.space4),
            child: Column(
              children: [
                Icon(icon, color: foreground, size: 30),
                const SizedBox(height: AppSpacing.space2),
                Text(
                  label,
                  style: AppTypography.button.copyWith(color: foreground),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
