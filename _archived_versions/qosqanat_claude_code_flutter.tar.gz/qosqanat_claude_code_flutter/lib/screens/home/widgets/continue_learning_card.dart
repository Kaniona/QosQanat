import 'package:flutter/material.dart';

import '../../../core/constants/home_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import 'app_card.dart';

/// "Жалғастыр" card: the last-played subject with its icon, grade, a mini
/// progress bar and a continue button.
class ContinueLearningCard extends StatelessWidget {
  const ContinueLearningCard({
    super.key,
    required this.subject,
    required this.grade,
    required this.progress,
    required this.onContinue,
  });

  final String subject;
  final int grade;
  final double progress;
  final VoidCallback onContinue;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: onContinue,
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              gradient: AppColors.bekturGradient,
              borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
            ),
            child: const Text('📐', style: TextStyle(fontSize: 26)),
          ),
          const SizedBox(width: AppSpacing.space3),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  HomeStrings.continueTitle,
                  style: AppTypography.caption.copyWith(
                    color: AppColors.primary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  '$subject — ${HomeStrings.continueGrade(grade)}',
                  style: AppTypography.bodyLarge.copyWith(
                    color: AppColors.ink,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: AppSpacing.space2),
                ClipRRect(
                  borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
                  child: Stack(
                    children: [
                      Container(height: 6, color: AppColors.surfaceMuted),
                      FractionallySizedBox(
                        widthFactor: progress.clamp(0.0, 1.0),
                        child: Container(
                          height: 6,
                          decoration:
                              const BoxDecoration(gradient: AppColors.bekturGradient),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.space2),
          const Icon(Icons.arrow_forward_rounded, color: AppColors.primary),
        ],
      ),
    );
  }
}
