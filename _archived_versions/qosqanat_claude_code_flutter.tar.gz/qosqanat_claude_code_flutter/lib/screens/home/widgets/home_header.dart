import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/enums.dart';
import '../../../core/theme/assistant_theme.dart';
import 'resource_pill.dart';

/// The sticky top bar: a gold-ringed user avatar on the left, the three live
/// resource pills, and a notification bell with an unread dot on the right.
class HomeHeader extends StatelessWidget {
  const HomeHeader({
    super.key,
    required this.initial,
    required this.assistant,
    required this.coins,
    required this.xp,
    required this.akyl,
    required this.hasUnread,
    required this.onTapProfile,
    required this.onTapBell,
    this.onTapCoins,
    this.pillsKey,
  });

  /// First letter of the student's name, shown inside the avatar ring.
  final String initial;
  final AssistantType assistant;
  final int coins;
  final int xp;
  final int akyl;
  final bool hasUnread;
  final VoidCallback onTapProfile;
  final VoidCallback onTapBell;

  /// Opens the shop when the coin pill is tapped.
  final VoidCallback? onTapCoins;

  /// Attached to the pills row so rewards can fly toward it.
  final Key? pillsKey;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.space5,
        vertical: AppSpacing.space3,
      ),
      child: Row(
        children: [
          _Avatar(
            initial: initial,
            gradient: assistant.gradient,
            onTap: onTapProfile,
          ),
          const SizedBox(width: AppSpacing.space3),
          Expanded(
            child: FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerRight,
              child: Row(
                key: pillsKey,
                mainAxisSize: MainAxisSize.min,
                children: [
                  GestureDetector(
                    onTap: onTapCoins,
                    behavior: HitTestBehavior.opaque,
                    child: ResourcePill(
                        icon: '💰', value: coins, color: AppColors.gold),
                  ),
                  const SizedBox(width: AppSpacing.space2),
                  ResourcePill(icon: '⚡', value: xp, color: AppColors.primary),
                  const SizedBox(width: AppSpacing.space2),
                  ResourcePill(
                      icon: '★', value: akyl, color: AppColors.secondary),
                ],
              ),
            ),
          ),
          const SizedBox(width: AppSpacing.space2),
          _Bell(hasUnread: hasUnread, onTap: onTapBell),
        ],
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({
    required this.initial,
    required this.gradient,
    required this.onTap,
  });

  final String initial;
  final Gradient gradient;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 44,
        height: 44,
        padding: const EdgeInsets.all(2.5), // the thin gold ring
        decoration: const BoxDecoration(
          gradient: AppColors.goldGradient,
          shape: BoxShape.circle,
        ),
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: gradient,
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.surface, width: 1.5),
          ),
          child: Text(
            initial,
            style: AppTypography.button.copyWith(
              color: AppColors.white,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ),
    );
  }
}

class _Bell extends StatelessWidget {
  const _Bell({required this.hasUnread, required this.onTap});

  final bool hasUnread;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 40,
        height: 40,
        child: Stack(
          alignment: Alignment.center,
          children: [
            const Icon(Icons.notifications_rounded,
                color: AppColors.textSecondary, size: 26),
            if (hasUnread)
              Positioned(
                top: 6,
                right: 8,
                child: Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color: AppColors.danger,
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.background, width: 2),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
