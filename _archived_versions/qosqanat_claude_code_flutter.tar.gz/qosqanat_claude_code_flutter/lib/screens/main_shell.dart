import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../core/constants/app_strings.dart';
import '../providers/auth_provider.dart';
import '../providers/friends_provider.dart';
import '../providers/game_provider.dart';
import '../providers/shop_provider.dart';
import '../widgets/game/level_up_modal.dart';
import '../widgets/ui/app_tab_bar.dart';

/// The authenticated home of the app: an [IndexedStack] of the five primary
/// tabs (via [StatefulNavigationShell]) under a custom tab bar, with a global
/// level-up celebration that can fire from anywhere in the app.
class MainShell extends ConsumerStatefulWidget {
  const MainShell({super.key, required this.navigationShell});

  final StatefulNavigationShell navigationShell;

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> {
  static const _items = [
    AppTabItem(
      icon: Icons.home_outlined,
      activeIcon: Icons.home_rounded,
      label: AppStrings.tabHome,
    ),
    AppTabItem(
      icon: Icons.menu_book_outlined,
      activeIcon: Icons.menu_book_rounded,
      label: AppStrings.tabLearn,
    ),
    AppTabItem(
      icon: Icons.storefront_outlined,
      activeIcon: Icons.storefront_rounded,
      label: AppStrings.tabShop,
    ),
    AppTabItem(
      icon: Icons.group_outlined,
      activeIcon: Icons.group_rounded,
      label: AppStrings.tabFriends,
    ),
    AppTabItem(
      icon: Icons.person_outline_rounded,
      activeIcon: Icons.person_rounded,
      label: AppStrings.tabProfile,
    ),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final user = ref.read(authProvider).user;
      if (user != null) {
        ref.read(gameProvider.notifier).ensureSeeded(user);
        ref.read(shopProvider.notifier).loadFor(user.id);
      }
      // Load pending requests so the Friends tab badge is accurate.
      ref.read(friendsProvider.notifier).refresh();
    });
  }

  void _onLevelUp(LevelUpEvent? previous, LevelUpEvent? next) {
    if (next == null) return;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      await showLevelUpModal(
        context,
        previousLevel: next.previousLevel,
        newLevel: next.newLevel,
        coinReward: next.coinReward,
      );
      if (mounted) ref.read(gameProvider.notifier).clearLevelUp();
    });
  }

  void _onTap(int index) {
    widget.navigationShell.goBranch(
      index,
      // Re-tapping the active tab returns it to its initial route.
      initialLocation: index == widget.navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    // Global level-up celebration: fires wherever the player levels up.
    ref.listen<LevelUpEvent?>(
      gameProvider.select((s) => s.pendingLevelUp),
      _onLevelUp,
    );

    final pending =
        ref.watch(friendsProvider.select((s) => s.pendingIncomingCount));

    return Scaffold(
      body: widget.navigationShell,
      bottomNavigationBar: AppTabBar(
        items: _items,
        currentIndex: widget.navigationShell.currentIndex,
        onTap: _onTap,
        emphasizedIndex: 1,
        badgeIndex: 3,
        badgeCount: pending,
      ),
    );
  }
}
