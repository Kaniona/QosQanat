import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/rating_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/leaderboard.dart';
import '../../navigation/app_router.dart';
import '../../providers/rating_provider.dart';
import 'widgets/podium.dart';
import 'widgets/rank_row.dart';

/// "🏆 Рейтинг" — the leaderboard, switchable across four scopes, with a top-3
/// podium, a ranked list from 4th down, and the user's pinned standing.
class RatingScreen extends ConsumerStatefulWidget {
  const RatingScreen({super.key});

  @override
  ConsumerState<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends ConsumerState<RatingScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => ref.read(ratingProvider.notifier).load(),
    );
  }

  static const _scopes = [
    (RatingScope.global, RatingStrings.scopeGlobal),
    (RatingScope.city, RatingStrings.scopeCity),
    (RatingScope.school, RatingStrings.scopeSchool),
    (RatingScope.friends, RatingStrings.scopeFriends),
  ];

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(ratingProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _Header(onBack: () => _back(context)),
            _ScopeTabs(
              scopes: _scopes,
              selected: state.scope,
              onSelect: (s) => ref.read(ratingProvider.notifier).setScope(s),
            ),
            Expanded(child: _Body(state: state)),
            if (state.showStickyMe) _MyRankBar(entry: state.myEntry!),
          ],
        ),
      ),
    );
  }

  void _back(BuildContext context) {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go(AppRoutes.home);
    }
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.onBack});
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.space4,
        AppSpacing.space4,
        AppSpacing.space5,
        AppSpacing.space3,
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: onBack,
            behavior: HitTestBehavior.opaque,
            child: const Icon(Icons.arrow_back_rounded, color: AppColors.ink),
          ),
          const SizedBox(width: AppSpacing.space3),
          Text(
            RatingStrings.title,
            style: AppTypography.heading1.copyWith(color: AppColors.ink),
          ),
        ],
      ),
    );
  }
}

class _ScopeTabs extends StatelessWidget {
  const _ScopeTabs({
    required this.scopes,
    required this.selected,
    required this.onSelect,
  });

  final List<(RatingScope, String)> scopes;
  final RatingScope selected;
  final ValueChanged<RatingScope> onSelect;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space5),
        itemCount: scopes.length,
        separatorBuilder: (_, _) => const SizedBox(width: AppSpacing.space2),
        itemBuilder: (context, i) {
          final (scope, label) = scopes[i];
          final active = scope == selected;
          return GestureDetector(
            onTap: () => onSelect(scope),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space4),
              decoration: BoxDecoration(
                color: active ? AppColors.primary : AppColors.surface,
                borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
                border: Border.all(
                  color: active ? AppColors.primary : AppColors.border,
                ),
              ),
              child: Text(
                label,
                style: AppTypography.button.copyWith(
                  color: active ? AppColors.white : AppColors.textSecondary,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _Body extends StatelessWidget {
  const _Body({required this.state});
  final RatingState state;

  @override
  Widget build(BuildContext context) {
    if (state.loading && state.entries.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (state.error != null && state.entries.isEmpty) {
      return _EmptyState(emoji: '⚠️', text: state.error!);
    }
    if (state.schoolLocked) {
      return const _EmptyState(emoji: '🏫', text: RatingStrings.schoolLocked);
    }
    if (state.friendsEmpty) {
      return const _EmptyState(emoji: '👥', text: RatingStrings.friendsEmpty);
    }
    if (state.entries.isEmpty) {
      return const _EmptyState(emoji: '🏆', text: RatingStrings.empty);
    }

    final rest = state.rest;
    return ListView.builder(
      padding: const EdgeInsets.only(top: AppSpacing.space2, bottom: AppSpacing.space6),
      itemCount: rest.length + 1,
      itemBuilder: (context, i) {
        if (i == 0) return Podium(top: state.podium);
        return RankRow(entry: rest[i - 1]);
      },
    );
  }
}

/// Pinned footer showing the user's own standing when off the podium.
class _MyRankBar extends StatelessWidget {
  const _MyRankBar({required this.entry});
  final LeaderboardEntry entry;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.background,
        boxShadow: [
          BoxShadow(color: AppColors.shadow, blurRadius: 16, offset: Offset(0, -4)),
        ],
      ),
      padding: const EdgeInsets.only(top: AppSpacing.space2, bottom: AppSpacing.space2),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.space5, 0, 0, 2),
            child: Text(
              RatingStrings.myRank(entry.rank),
              style: AppTypography.caption.copyWith(
                color: AppColors.primary,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          RankRow(entry: entry),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.emoji, required this.text});
  final String emoji;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.space8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 64)),
            const SizedBox(height: AppSpacing.space4),
            Text(
              text,
              textAlign: TextAlign.center,
              style: AppTypography.bodyLarge.copyWith(color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}
