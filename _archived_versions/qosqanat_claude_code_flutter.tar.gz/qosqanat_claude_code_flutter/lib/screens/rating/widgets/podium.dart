import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/leaderboard.dart';
import '../../../widgets/ui/profile_avatar.dart';

/// The striking top-3 podium: first place centered, tallest, crowned and
/// glowing gold with sparkles; second on the left (silver) slightly lower; third
/// on the right (bronze) lowest.
class Podium extends StatelessWidget {
  const Podium({super.key, required this.top});

  /// Up to three entries, rank 1 first.
  final List<LeaderboardEntry> top;

  @override
  Widget build(BuildContext context) {
    if (top.isEmpty) return const SizedBox.shrink();
    final first = top[0];
    final second = top.length > 1 ? top[1] : null;
    final third = top.length > 2 ? top[2] : null;

    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.space4,
        AppSpacing.space4,
        AppSpacing.space4,
        AppSpacing.space6,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: second == null
                ? const SizedBox.shrink()
                : _PodiumColumn(
                    entry: second,
                    ringColor: AppColors.silver,
                    pedestalColors: const [AppColors.silver, AppColors.silverDeep],
                    avatarSize: 60,
                    pedestalHeight: 78,
                  ),
          ),
          Expanded(
            child: _PodiumColumn(
              entry: first,
              ringColor: AppColors.gold,
              pedestalColors: const [AppColors.goldLight, AppColors.goldDeep],
              avatarSize: 84,
              pedestalHeight: 112,
              crowned: true,
              glow: true,
            ),
          ),
          Expanded(
            child: third == null
                ? const SizedBox.shrink()
                : _PodiumColumn(
                    entry: third,
                    ringColor: AppColors.bronze,
                    pedestalColors: const [AppColors.bronze, AppColors.bronzeDeep],
                    avatarSize: 60,
                    pedestalHeight: 58,
                  ),
          ),
        ],
      ),
    );
  }
}

class _PodiumColumn extends StatelessWidget {
  const _PodiumColumn({
    required this.entry,
    required this.ringColor,
    required this.pedestalColors,
    required this.avatarSize,
    required this.pedestalHeight,
    this.crowned = false,
    this.glow = false,
  });

  final LeaderboardEntry entry;
  final Color ringColor;
  final List<Color> pedestalColors;
  final double avatarSize;
  final double pedestalHeight;
  final bool crowned;
  final bool glow;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (crowned)
          const Text('👑', style: TextStyle(fontSize: 30))
              .animate(onPlay: (c) => c.repeat(reverse: true))
              .moveY(begin: 0, end: -4, duration: 900.ms, curve: Curves.easeInOut),
        _RingedAvatar(
          entry: entry,
          ringColor: ringColor,
          size: avatarSize,
          glow: glow,
        ),
        const SizedBox(height: AppSpacing.space2),
        Text(
          entry.profile.fullName,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: AppTypography.bodySmall.copyWith(
            color: AppColors.ink,
            fontWeight: FontWeight.w800,
          ),
        ),
        Text(
          '★ ${entry.profile.akylPoints}',
          style: AppTypography.caption.copyWith(
            color: AppColors.secondary,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: AppSpacing.space2),
        // Pedestal.
        Container(
          height: pedestalHeight,
          alignment: Alignment.topCenter,
          padding: const EdgeInsets.only(top: AppSpacing.space2),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: pedestalColors,
            ),
            borderRadius: const BorderRadius.vertical(
              top: Radius.circular(AppSpacing.radiusMd),
            ),
          ),
          child: Text(
            '${entry.rank}',
            style: AppTypography.displayLarge.copyWith(
              color: AppColors.white,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ],
    );
  }
}

/// An avatar inside a colored medal ring; first place gets a glow and sparkles.
class _RingedAvatar extends StatelessWidget {
  const _RingedAvatar({
    required this.entry,
    required this.ringColor,
    required this.size,
    required this.glow,
  });

  final LeaderboardEntry entry;
  final Color ringColor;
  final double size;
  final bool glow;

  @override
  Widget build(BuildContext context) {
    final ring = Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: ringColor, width: 3),
        boxShadow: glow
            ? [
                BoxShadow(
                  color: ringColor.withValues(alpha: 0.7),
                  blurRadius: 22,
                  spreadRadius: 2,
                ),
              ]
            : null,
      ),
      child: ProfileAvatar(
        name: entry.profile.fullName,
        assistant: entry.profile.assistantType,
        size: size,
      ),
    );

    if (!glow) return ring;

    // Sparkle accents around first place.
    return Stack(
      clipBehavior: Clip.none,
      alignment: Alignment.center,
      children: [
        ring,
        const Positioned(top: -6, right: -2, child: _Sparkle(delayMs: 0)),
        const Positioned(bottom: 0, left: -8, child: _Sparkle(delayMs: 400)),
        const Positioned(top: 10, left: -4, child: _Sparkle(delayMs: 800)),
      ],
    );
  }
}

class _Sparkle extends StatelessWidget {
  const _Sparkle({required this.delayMs});

  final int delayMs;

  @override
  Widget build(BuildContext context) {
    return const Text('✨', style: TextStyle(fontSize: 14))
        .animate(onPlay: (c) => c.repeat())
        .fadeIn(delay: delayMs.ms, duration: 600.ms)
        .then()
        .fadeOut(duration: 600.ms);
  }
}
