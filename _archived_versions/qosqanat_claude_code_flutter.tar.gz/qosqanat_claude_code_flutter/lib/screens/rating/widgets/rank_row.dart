import 'package:flutter/material.dart';

import '../../../core/constants/rating_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../models/leaderboard.dart';
import '../../../widgets/ui/profile_avatar.dart';

/// A single leaderboard row from 4th place down: rank number, avatar, name, a
/// level badge, akyl points, and a rank-movement indicator. The signed-in
/// user's row is highlighted blue with a "Сіз" label.
class RankRow extends StatelessWidget {
  const RankRow({super.key, required this.entry});

  final LeaderboardEntry entry;

  @override
  Widget build(BuildContext context) {
    final me = entry.isMe;
    final p = entry.profile;

    return Container(
      margin: const EdgeInsets.symmetric(
        horizontal: AppSpacing.space5,
        vertical: AppSpacing.space1,
      ),
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.space3,
        vertical: AppSpacing.space2,
      ),
      decoration: BoxDecoration(
        color: me ? AppColors.primary.withValues(alpha: 0.12) : AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        border: Border.all(
          color: me ? AppColors.primary : AppColors.border,
          width: me ? 1.5 : 1,
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 28,
            child: Text(
              '${entry.rank}',
              textAlign: TextAlign.center,
              style: AppTypography.bodyLarge.copyWith(
                color: me ? AppColors.primary : AppColors.textSecondary,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          const SizedBox(width: AppSpacing.space2),
          ProfileAvatar(
            name: p.fullName,
            assistant: p.assistantType,
            size: 40,
            online: p.isOnline ? true : null,
          ),
          const SizedBox(width: AppSpacing.space3),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        p.fullName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.bodyLarge.copyWith(
                          color: AppColors.ink,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    if (me) ...[
                      const SizedBox(width: AppSpacing.space2),
                      const _MeBadge(),
                    ],
                  ],
                ),
                Text(
                  RatingStrings.levelBadge(p.level),
                  style: AppTypography.caption,
                ),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.space2),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '★ ${p.akylPoints}',
                style: AppTypography.bodyLarge.copyWith(
                  color: AppColors.secondary,
                  fontWeight: FontWeight.w800,
                ),
              ),
              MovementIndicator(change: entry.rankChange),
            ],
          ),
        ],
      ),
    );
  }
}

/// Small "Сіз" pill marking the current user's row.
class _MeBadge extends StatelessWidget {
  const _MeBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.primary,
        borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
      ),
      child: Text(
        RatingStrings.you,
        style: AppTypography.caption.copyWith(
          color: AppColors.white,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

/// "↑3" (green), "↓2" (red) or "—" (grey) rank-movement chip.
class MovementIndicator extends StatelessWidget {
  const MovementIndicator({super.key, required this.change});

  final int change;

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (change) {
      > 0 => ('↑$change', AppColors.success),
      < 0 => ('↓${-change}', AppColors.danger),
      _ => (RatingStrings.noMovement, AppColors.textTertiary),
    };
    return Text(
      label,
      style: AppTypography.caption.copyWith(
        color: color,
        fontWeight: FontWeight.w800,
      ),
    );
  }
}
