import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Thin wrapper around the Supabase client.
///
/// Loads credentials from `.env` and initializes Supabase once at startup.
/// Access the configured client anywhere via [SupabaseService.client].
abstract final class SupabaseService {
  SupabaseService._();

  /// Initialize dotenv + Supabase. Call once from `main()` before `runApp`.
  static Future<void> init() async {
    await dotenv.load();

    final url = dotenv.maybeGet('SUPABASE_URL');
    final anonKey = dotenv.maybeGet('SUPABASE_ANON_KEY');

    if (url == null || url.isEmpty || anonKey == null || anonKey.isEmpty) {
      throw StateError(
        'SUPABASE_URL and SUPABASE_ANON_KEY must be defined in .env',
      );
    }

    await Supabase.initialize(url: url, anonKey: anonKey);
  }

  /// The shared Supabase client.
  static SupabaseClient get client => Supabase.instance.client;

  /// The Supabase auth sub-client.
  static GoTrueClient get auth => client.auth;

  /// Currently authenticated user, or null when signed out / not initialized.
  static User? get currentUser {
    try {
      return auth.currentUser;
    } catch (_) {
      return null;
    }
  }

  /// Whether a session is currently active. Returns false if Supabase failed to
  /// initialize, so the app safely falls back to the onboarding flow.
  static bool get isSignedIn {
    try {
      return auth.currentSession != null;
    } catch (_) {
      return false;
    }
  }
}
