import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/constants/voice_commands.dart';
import '../core/constants/voice_strings.dart';
import '../models/enums.dart';

/// Speech recognition + text-to-speech for the voice assistant.
///
/// Recognition runs in Kazakh (`kk-KZ`) when the device supports it, gracefully
/// falling back to the system locale otherwise. Speech is voiced through the
/// assistant's character (Nazym a touch higher-pitched than Bektur). Command
/// parsing lives in [voice_commands.dart]; this service wires it to the mic.
class VoiceService {
  VoiceService();

  final SpeechToText _stt = SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool _initialized = false;
  bool _available = false;

  /// The locale id used for recognition, resolved once at init.
  String _sttLocaleId = 'kk-KZ';

  /// The language used for speech, resolved once at init.
  String _ttsLanguage = 'kk-KZ';

  bool get isListening => _stt.isListening;
  bool get isAvailable => _available;

  /// Initializes recognition + speech. Returns true when the mic is usable.
  /// The first call triggers the OS microphone permission prompt.
  Future<bool> init() async {
    if (_initialized) return _available;
    _initialized = true;
    try {
      _available = await _stt.initialize(
        onError: (e) => debugPrint('STT error: ${e.errorMsg}'),
        onStatus: (s) => debugPrint('STT status: $s'),
      );
      if (_available) {
        _sttLocaleId = await _resolveSttLocale();
      }
    } catch (e) {
      debugPrint('STT init failed: $e');
      _available = false;
    }

    try {
      _ttsLanguage = await _resolveTtsLanguage();
      await _tts.setLanguage(_ttsLanguage);
      await _tts.setSpeechRate(0.5);
      await _tts.setVolume(1.0);
      await _tts.awaitSpeakCompletion(true);
    } catch (e) {
      debugPrint('TTS init failed: $e');
    }
    return _available;
  }

  /// Whether the OS microphone permission has been granted.
  Future<bool> hasPermission() async {
    try {
      return await _stt.hasPermission;
    } catch (_) {
      return false;
    }
  }

  /// Picks `kk-KZ` if the device offers it, else a Kazakh/Russian/system match.
  Future<String> _resolveSttLocale() async {
    try {
      final locales = await _stt.locales();
      for (final candidate in ['kk_KZ', 'kk-KZ', 'kk']) {
        for (final l in locales) {
          if (l.localeId.toLowerCase().startsWith(candidate.toLowerCase())) {
            return l.localeId;
          }
        }
      }
      final system = await _stt.systemLocale();
      return system?.localeId ?? 'en_US';
    } catch (_) {
      return 'kk-KZ';
    }
  }

  /// Picks the best available TTS language, preferring Kazakh.
  Future<String> _resolveTtsLanguage() async {
    for (final candidate in ['kk-KZ', 'kk', 'ru-RU']) {
      try {
        final ok = await _tts.isLanguageAvailable(candidate);
        if (ok == true) return candidate;
      } catch (_) {
        // Probe the next candidate.
      }
    }
    return 'kk-KZ';
  }

  /// Begins listening. [onResult] fires with partial and final transcripts;
  /// [onFinal] fires once with the final transcript; [onLevel] reports the live
  /// microphone sound level for the waveform.
  Future<void> startListening({
    required ValueChanged<String> onResult,
    required ValueChanged<String> onFinal,
    ValueChanged<double>? onLevel,
  }) async {
    if (!_available) return;
    await _stt.listen(
      onResult: (result) {
        onResult(result.recognizedWords);
        if (result.finalResult) onFinal(result.recognizedWords);
      },
      onSoundLevelChange: onLevel,
      listenOptions: SpeechListenOptions(
        partialResults: true,
        cancelOnError: true,
        localeId: _sttLocaleId,
        listenFor: const Duration(seconds: 30),
        pauseFor: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> stopListening() async {
    if (_stt.isListening) await _stt.stop();
  }

  /// Speaks [text] in the assistant's voice. Nazym is pitched higher than
  /// Bektur to match her brighter character.
  Future<void> speak(String text, AssistantType assistant) async {
    if (text.trim().isEmpty) return;
    try {
      await _tts.setLanguage(_ttsLanguage);
      await _tts.setPitch(assistant == AssistantType.nazym ? 1.25 : 0.95);
      await _tts.speak(text);
    } catch (e) {
      debugPrint('TTS speak failed: $e');
    }
  }

  Future<void> stopSpeaking() async {
    try {
      await _tts.stop();
    } catch (_) {/* ignore */}
  }

  /// Parses recognized text into an actionable intent (see [parseVoiceCommand]).
  VoiceIntent parse(String recognizedText) => parseVoiceCommand(recognizedText);

  /// Placeholder for open-ended questions. Once an Anthropic API key is wired
  /// in, this is where the request would go — prompted with the assistant's
  /// personality ([assistant]) so Bektur and Nazym answer in their own voice.
  Future<String> aiRespond(String query, AssistantType assistant) async {
    // TODO(anthropic): call the Claude API here with a system prompt built from
    // the assistant's personality, returning a Kazakh, kid-appropriate answer.
    return VoiceStrings.aiFallback;
  }

  /// Opens an external app, trying its custom scheme first and a web fallback
  /// second. Returns false when nothing could be launched (e.g. calculator,
  /// which has no cross-platform scheme).
  Future<bool> launchExternal(ExternalApp app) async {
    for (final candidate in _appUris(app)) {
      try {
        final uri = Uri.parse(candidate);
        if (await canLaunchUrl(uri)) {
          return await launchUrl(uri, mode: LaunchMode.externalApplication);
        }
      } catch (_) {
        // Try the next candidate.
      }
    }
    return false;
  }

  List<String> _appUris(ExternalApp app) {
    switch (app) {
      case ExternalApp.youtube:
        return ['youtube://', 'https://www.youtube.com'];
      case ExternalApp.whatsapp:
        return ['whatsapp://send', 'https://wa.me'];
      case ExternalApp.instagram:
        return ['instagram://app', 'https://www.instagram.com'];
      case ExternalApp.tiktok:
        return ['snssdk1233://', 'https://www.tiktok.com'];
      case ExternalApp.telegram:
        return ['tg://', 'https://t.me'];
      case ExternalApp.calculator:
        // No standard cross-platform scheme; handled as a graceful failure.
        return const [];
    }
  }

  void dispose() {
    _stt.cancel();
    _tts.stop();
  }
}
