import '../models/battle.dart';
import '../models/enums.dart';
import '../models/friend.dart';
import '../models/leaderboard.dart';
import 'supabase_service.dart';

/// A friendly, Kazakh-facing failure from an API call.
class ApiException implements Exception {
  const ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Social + battle backend calls.
///
/// Cross-user reads go through SECURITY DEFINER database functions (`rpc`) so a
/// student can see only the public fields of others, never raw rows. Writes are
/// guarded by row-level security on the underlying tables.
abstract final class ApiService {
  ApiService._();

  static String get _uid {
    final id = SupabaseService.currentUser?.id;
    if (id == null) throw const ApiException('Алдымен жүйеге кір');
    return id;
  }

  // ─── Friends ──────────────────────────────────────────────────────────

  /// Finds a single user by their public QQ-id, or null if none matches.
  static Future<PublicProfile?> searchUserByQosqanatId(String qosqanatId) async {
    final query = qosqanatId.trim().toUpperCase();
    if (query.isEmpty) return null;
    try {
      final res = await SupabaseService.client.rpc(
        'search_user_by_qosqanat_id',
        params: {'p_qosqanat_id': query},
      );
      final row = _firstRow(res);
      return row == null ? null : PublicProfile.fromJson(row);
    } catch (e) {
      throw _friendly(e);
    }
  }

  static Future<void> sendFriendRequest(String toUserId) async {
    try {
      await SupabaseService.client.rpc(
        'send_friend_request',
        params: {'p_to_user': toUserId},
      );
    } catch (e) {
      throw _friendly(e);
    }
  }

  static Future<void> acceptFriendRequest(String requestId) async {
    try {
      await SupabaseService.client
          .rpc('accept_friend_request', params: {'p_request_id': requestId});
    } catch (e) {
      throw _friendly(e);
    }
  }

  static Future<void> declineFriendRequest(String requestId) async {
    try {
      await SupabaseService.client
          .rpc('decline_friend_request', params: {'p_request_id': requestId});
    } catch (e) {
      throw _friendly(e);
    }
  }

  /// The signed-in user's accepted friends.
  static Future<List<PublicProfile>> getFriends() async {
    try {
      final res = await SupabaseService.client.rpc('get_friends');
      return _rows(res).map(PublicProfile.fromJson).toList();
    } catch (e) {
      throw _friendly(e);
    }
  }

  /// Pending requests — both incoming and outgoing.
  static Future<List<FriendRequest>> getPendingRequests() async {
    try {
      final res = await SupabaseService.client.rpc('get_pending_requests');
      return _rows(res).map(FriendRequest.fromJson).toList();
    } catch (e) {
      throw _friendly(e);
    }
  }

  // ─── Battle ───────────────────────────────────────────────────────────

  /// Creates a battle row (status: waiting) and returns it.
  static Future<Battle> createBattle({
    required String opponentId,
    required int questionCount,
    String? subjectId,
  }) async {
    try {
      final inserted = await SupabaseService.client
          .from('battles')
          .insert({
            'host_id': _uid,
            'opponent_id': opponentId,
            'question_count': questionCount,
            'subject_id': subjectId,
            'status': BattleStatus.waiting.toJson(),
          })
          .select()
          .single();
      return Battle.fromJson(inserted);
    } catch (e) {
      throw _friendly(e);
    }
  }

  /// The opponent accepts a battle, flipping it to active.
  static Future<Battle> acceptBattle(String battleId) async {
    try {
      final updated = await SupabaseService.client
          .from('battles')
          .update({'status': BattleStatus.active.toJson()})
          .eq('id', battleId)
          .select()
          .single();
      return Battle.fromJson(updated);
    } catch (e) {
      throw _friendly(e);
    }
  }

  /// Records a correct answer for the calling player; the DB function increments
  /// the right score column based on auth.uid() and returns the fresh row.
  static Future<Battle?> submitBattleAnswer(
    String battleId, {
    required bool correct,
  }) async {
    try {
      final res = await SupabaseService.client.rpc(
        'submit_battle_answer',
        params: {'p_battle_id': battleId, 'p_correct': correct},
      );
      final row = _firstRow(res);
      return row == null ? null : Battle.fromJson(row);
    } catch (e) {
      throw _friendly(e);
    }
  }

  /// Finalizes (if needed) and returns the battle with scores and winner.
  static Future<Battle> getBattleResult(String battleId) async {
    try {
      final res = await SupabaseService.client
          .rpc('finish_battle', params: {'p_battle_id': battleId});
      final row = _firstRow(res);
      if (row != null) return Battle.fromJson(row);
      // Fallback: read the row directly.
      final direct = await SupabaseService.client
          .from('battles')
          .select()
          .eq('id', battleId)
          .single();
      return Battle.fromJson(direct);
    } catch (e) {
      throw _friendly(e);
    }
  }

  // ─── Rating / leaderboard ───────────────────────────────────────────────

  /// The top entries for [scope], ordered by akyl points descending. Goes
  /// through the SECURITY DEFINER `get_leaderboard` function so only public
  /// fields of other students are exposed, with the rank and movement computed
  /// server-side.
  static Future<List<LeaderboardEntry>> getLeaderboard(
    RatingScope scope, {
    int limit = 100,
  }) async {
    try {
      final res = await SupabaseService.client.rpc(
        'get_leaderboard',
        params: {'p_scope': scope.toJson(), 'p_limit': limit},
      );
      final me = SupabaseService.currentUser?.id;
      return _rows(res)
          .map((r) => LeaderboardEntry.fromJson(r, meId: me))
          .toList();
    } catch (e) {
      throw _friendly(e);
    }
  }

  /// The signed-in user's own rank within [scope], or null if unranked.
  static Future<int?> getMyRank(RatingScope scope) async {
    try {
      final res = await SupabaseService.client
          .rpc('get_my_rank', params: {'p_scope': scope.toJson()});
      final row = _firstRow(res);
      if (row != null) return (row['rank'] as num?)?.toInt();
      if (res is num) return res.toInt();
      return null;
    } catch (e) {
      throw _friendly(e);
    }
  }

  /// The signed-in user's most recent finished battles (newest first).
  static Future<List<RecentBattle>> getRecentBattles({int limit = 5}) async {
    try {
      final res = await SupabaseService.client
          .rpc('get_recent_battles', params: {'p_limit': limit});
      return _rows(res).map(RecentBattle.fromJson).toList();
    } catch (e) {
      throw _friendly(e);
    }
  }

  // ─── Helpers ──────────────────────────────────────────────────────────

  static List<Map<String, dynamic>> _rows(dynamic res) {
    if (res is List) {
      return res.cast<Map<String, dynamic>>();
    }
    if (res is Map<String, dynamic>) return [res];
    return const [];
  }

  static Map<String, dynamic>? _firstRow(dynamic res) {
    final rows = _rows(res);
    return rows.isEmpty ? null : rows.first;
  }

  static ApiException _friendly(Object error) {
    if (error is ApiException) return error;
    final text = error.toString().toLowerCase();
    if (text.contains('network') || text.contains('socket') ||
        text.contains('failed host')) {
      return const ApiException('Интернет байланысын тексер');
    }
    if (text.contains('duplicate') || text.contains('already')) {
      return const ApiException('Бұл өтінім бұрын жіберілген');
    }
    return const ApiException('Бірдеңе дұрыс болмады. Қайталап көр.');
  }
}
