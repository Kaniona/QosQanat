/// Form validators for QosQanat. All messages are returned in Kazakh.
abstract final class Validators {
  Validators._();

  /// Extracts only the digit characters from [value].
  static String digitsOnly(String value) => value.replaceAll(RegExp(r'\D'), '');

  /// Full name must contain at least two words (name + surname).
  static String? fullName(String? value) {
    final text = (value ?? '').trim();
    if (text.isEmpty) return 'Атыңды енгіз';
    final words = text.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (words.length < 2) return 'Аты-жөніңді толық жаз';
    return null;
  }

  /// Phone must be 11 digits and start with 7 (Kazakhstan).
  static String? phone(String? value) {
    final digits = digitsOnly(value ?? '');
    if (digits.isEmpty) return 'Телефон нөмірін енгіз';
    if (digits.length != 11 || !digits.startsWith('7')) {
      return 'Дұрыс нөмір енгіз';
    }
    return null;
  }

  /// IIN must be exactly 12 digits.
  static String? iin(String? value) {
    final digits = digitsOnly(value ?? '');
    if (digits.isEmpty) return 'ЖСН-ді енгіз';
    if (digits.length != 12) return '12 саннан тұруы керек';
    return null;
  }
}
