import 'package:flutter/services.dart';

/// Formats Kazakhstan phone numbers live as `+7 (XXX) XXX-XX-XX`.
///
/// Keeps at most 11 digits and forces a leading `7`.
class PhoneInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    var digits = newValue.text.replaceAll(RegExp(r'\D'), '');

    // Force the country code to 7 and cap to 11 digits total.
    if (digits.isNotEmpty && digits[0] != '7') {
      digits = '7$digits';
    }
    if (digits.length > 11) digits = digits.substring(0, 11);

    final formatted = _format(digits);
    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }

  static String _format(String digits) {
    if (digits.isEmpty) return '';
    final b = StringBuffer('+7');
    final rest = digits.substring(1); // strip the leading 7
    if (rest.isNotEmpty) {
      b.write(' (');
      b.write(rest.substring(0, rest.length.clamp(0, 3)));
      if (rest.length >= 3) b.write(')');
    }
    if (rest.length > 3) {
      b.write(' ');
      b.write(rest.substring(3, rest.length.clamp(3, 6)));
    }
    if (rest.length > 6) {
      b.write('-');
      b.write(rest.substring(6, rest.length.clamp(6, 8)));
    }
    if (rest.length > 8) {
      b.write('-');
      b.write(rest.substring(8, rest.length.clamp(8, 10)));
    }
    return b.toString();
  }
}

/// Masking helpers for displaying sensitive values on the review step.
abstract final class Mask {
  Mask._();

  /// `+7 (701) 234-56-78` → `+7 (701) ***-**-78`.
  static String phone(String formatted) {
    final digits = formatted.replaceAll(RegExp(r'\D'), '');
    if (digits.length != 11) return formatted;
    final code = digits.substring(1, 4);
    final last2 = digits.substring(9, 11);
    return '+7 ($code) ***-**-$last2';
  }

  /// `040712500123` → `0407********`.
  static String iin(String iin) {
    final digits = iin.replaceAll(RegExp(r'\D'), '');
    if (digits.length != 12) return iin;
    return '${digits.substring(0, 4)}${'*' * 8}';
  }
}
