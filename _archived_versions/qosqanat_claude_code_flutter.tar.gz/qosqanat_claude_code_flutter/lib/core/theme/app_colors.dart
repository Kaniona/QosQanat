import 'package:flutter/material.dart';

/// Central color palette for QosQanat.
///
/// NEVER hardcode a [Color] anywhere in the app — always reference a value
/// from here so the brand stays consistent and themeable.
abstract final class AppColors {
  AppColors._();

  // ─── Primary ──────────────────────────────────────────────────────────
  static const Color primary = Color(0xFF4A6CF7);
  static const Color primaryLight = Color(0xFF8AA0FB);
  static const Color primaryMedium = Color(0xFF6580F9);
  static const Color primaryDark = Color(0xFF3651D4);

  // ─── Secondary ────────────────────────────────────────────────────────
  static const Color secondary = Color(0xFF7B61FF);
  static const Color secondaryLight = Color(0xFFA38FFF);
  static const Color secondaryDark = Color(0xFF5B41E0);

  // ─── Gold (premium accents, coins, rewards) ─────────────────────────────
  static const Color gold = Color(0xFFFFD700);
  static const Color goldLight = Color(0xFFFFE769);
  static const Color goldDeep = Color(0xFFE6A700);

  // ─── Podium (leaderboard top 3) ─────────────────────────────────────────
  static const Color silver = Color(0xFFB6C0D6);
  static const Color silverDeep = Color(0xFF8A95AE);
  static const Color bronze = Color(0xFFCD8E5E);
  static const Color bronzeDeep = Color(0xFFA9663B);

  // ─── Semantic ───────────────────────────────────────────────────────────
  static const Color success = Color(0xFF00C48C);
  static const Color successLight = Color(0xFF5BE3BD);
  static const Color danger = Color(0xFFFF4757);
  static const Color dangerLight = Color(0xFFFF8A95);
  static const Color warning = Color(0xFFFFA502);
  static const Color info = Color(0xFF0891B2);

  // ─── Assistant brand colors ──────────────────────────────────────────────
  static const Color bekturBlue = Color(0xFF4A6CF7);
  static const Color nazymPink = Color(0xFFFF6B9D);

  // ─── Ink & text ───────────────────────────────────────────────────────────
  static const Color ink = Color(0xFF1A1A4E);
  static const Color textPrimary = Color(0xFF1A1A4E);
  static const Color textSecondary = Color(0xFF6B7197);
  static const Color textTertiary = Color(0xFFA0A4C0);

  // ─── Surfaces & lines ───────────────────────────────────────────────────────
  static const Color border = Color(0xFFE8ECFF);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color background = Color(0xFFF8F9FF);
  static const Color surfaceMuted = Color(0xFFF1F3FF);

  // ─── Utility ────────────────────────────────────────────────────────────────
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF000000);
  static const Color shadow = Color(0x1A4A6CF7);

  // ─── Gradients ──────────────────────────────────────────────────────────────
  static const LinearGradient heroGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [ink, primary],
  );

  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [goldLight, gold, goldDeep],
  );

  static const LinearGradient bekturGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [primaryLight, bekturBlue, primaryDark],
  );

  static const LinearGradient nazymGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFFF9DBF), nazymPink, Color(0xFFE04A7E)],
  );

  static const LinearGradient successGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [successLight, success, Color(0xFF00A074)],
  );
}
