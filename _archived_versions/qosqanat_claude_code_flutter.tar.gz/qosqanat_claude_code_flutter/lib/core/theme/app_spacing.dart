/// Spacing scale and corner radii for QosQanat.
///
/// Use these everywhere instead of magic numbers so layout rhythm stays
/// consistent across every screen.
abstract final class AppSpacing {
  AppSpacing._();

  // ─── Spacing scale (4pt grid) ──────────────────────────────────────────
  static const double space1 = 4;
  static const double space2 = 8;
  static const double space3 = 12;
  static const double space4 = 16;
  static const double space5 = 20;
  static const double space6 = 24;
  static const double space8 = 32;
  static const double space10 = 40;
  static const double space12 = 48;

  // ─── Corner radii ────────────────────────────────────────────────────────
  static const double radiusSm = 12;
  static const double radiusMd = 16;
  static const double radiusLg = 20;
  static const double radiusXl = 28;
  static const double radiusFull = 999;
}
