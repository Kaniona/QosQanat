import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_colors.dart';

/// Typography system for QosQanat.
///
/// Uses Nunito (full Cyrillic support, friendly rounded forms) for all text.
/// Reference these named styles directly, or read them from the inherited
/// [TextTheme] assembled in app_theme.dart.
abstract final class AppTypography {
  AppTypography._();

  /// Base font family helper — applies Nunito with the given parameters.
  static TextStyle _font({
    required double size,
    required FontWeight weight,
    required double height,
    Color color = AppColors.textPrimary,
    double? letterSpacing,
  }) {
    return GoogleFonts.nunito(
      fontSize: size,
      fontWeight: weight,
      height: height,
      color: color,
      letterSpacing: letterSpacing,
    );
  }

  // ─── Display ──────────────────────────────────────────────────────────────
  static TextStyle get displayHuge =>
      _font(size: 40, weight: FontWeight.w800, height: 1.2, letterSpacing: -0.5);

  static TextStyle get displayLarge =>
      _font(size: 32, weight: FontWeight.w800, height: 1.2, letterSpacing: -0.5);

  // ─── Headings ───────────────────────────────────────────────────────────────
  static TextStyle get heading1 =>
      _font(size: 28, weight: FontWeight.w700, height: 1.2);

  static TextStyle get heading2 =>
      _font(size: 24, weight: FontWeight.w600, height: 1.2);

  static TextStyle get heading3 =>
      _font(size: 20, weight: FontWeight.w600, height: 1.3);

  // ─── Body ───────────────────────────────────────────────────────────────────
  static TextStyle get bodyLarge =>
      _font(size: 18, weight: FontWeight.w500, height: 1.5);

  static TextStyle get body =>
      _font(size: 16, weight: FontWeight.w400, height: 1.5);

  static TextStyle get bodySmall =>
      _font(size: 14, weight: FontWeight.w400, height: 1.5, color: AppColors.textSecondary);

  static TextStyle get caption => _font(
        size: 12,
        weight: FontWeight.w500,
        height: 1.4,
        color: AppColors.textSecondary,
      );

  // ─── Functional ───────────────────────────────────────────────────────────────
  static TextStyle get button =>
      _font(size: 16, weight: FontWeight.w600, height: 1.2, letterSpacing: 0.2);

  static TextStyle get numberDisplay =>
      _font(size: 36, weight: FontWeight.w800, height: 1.1, letterSpacing: -0.5);

  /// Maps the named styles into a Material 3 [TextTheme] for the global theme.
  static TextTheme get textTheme => TextTheme(
        displayLarge: displayHuge,
        displayMedium: displayLarge,
        displaySmall: heading1,
        headlineLarge: heading1,
        headlineMedium: heading2,
        headlineSmall: heading3,
        titleLarge: heading3,
        titleMedium: bodyLarge,
        titleSmall: button,
        bodyLarge: bodyLarge,
        bodyMedium: body,
        bodySmall: bodySmall,
        labelLarge: button,
        labelMedium: caption,
        labelSmall: caption,
      );
}
