import 'package:flutter/material.dart';

import '../../models/enums.dart';
import '../constants/app_strings.dart';
import 'app_colors.dart';

/// Brand visuals for each assistant, kept out of the domain [AssistantType]
/// enum so the model stays UI-free. Reuse these anywhere an assistant is shown.
extension AssistantTheme on AssistantType {
  /// The signature gradient used behind the assistant and on its accents.
  LinearGradient get gradient => switch (this) {
        AssistantType.bektur => AppColors.bekturGradient,
        AssistantType.nazym => AppColors.nazymGradient,
      };

  /// The single accent color (FAB, glow, highlights).
  Color get accent => switch (this) {
        AssistantType.bektur => AppColors.bekturBlue,
        AssistantType.nazym => AppColors.nazymPink,
      };

  /// The assistant's Kazakh display name.
  String get displayName => switch (this) {
        AssistantType.bektur => AppStrings.bektur,
        AssistantType.nazym => AppStrings.nazym,
      };
}
