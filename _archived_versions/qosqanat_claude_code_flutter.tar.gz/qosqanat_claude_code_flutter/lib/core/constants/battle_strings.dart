/// Kazakh copy for the Akyl Battle (Ақыл Батл).
abstract final class BattleStrings {
  BattleStrings._();

  static const String title = '⚔️ Ақыл Батл';
  static const String vs = 'VS';

  // Setup.
  static const String questionCountTitle = 'Сұрақ саны';
  static const String subjectTitle = 'Пән';
  static const String allSubjects = 'Барлығы';
  static const String startBattle = '⚔️ Батл бастау!';

  // Waiting.
  static const String waiting = 'Қарсыласты күтудеміз...';
  static const String rulesTitle = 'Ережелер';
  static const String rules = 'Әр сұраққа 10 секунд. Көп дұрыс жауап берген жеңеді!';
  static const String cancel = 'Болдырмау';

  // Live.
  static String questionCounter(int i, int total) => 'Сұрақ $i/$total';
  static const String you = 'Сіз';
  static const String opponent = 'Қарсылас';

  // Result.
  static const String win = '🏆 ЖЕҢДІҢІЗ!';
  static const String lose = '😔 Жеңілдіңіз...';
  static const String draw = '🤝 Тең түсті!';
  static const String encourage = 'Келесіде жеңесің! 💪';
  static const String winCheer = 'Керемет ойын! 🎉';
  static String scoreCompare(int you, int opp) =>
      'Сіз: $you ✓  vs  Қарсылас: $opp ✓';
  static String accuracy(int percent) => 'Дәлдік: $percent%';
  static const String rewardsTitle = 'Сыйлықтар';
  static const String rematch = '🔄 Қайта батл';
  static const String home = '🏠 Басты бетке';
  static const String retry = 'Қайта тырысу';
  static const String opponentLeft = 'Қарсылас шығып кетті';
}
