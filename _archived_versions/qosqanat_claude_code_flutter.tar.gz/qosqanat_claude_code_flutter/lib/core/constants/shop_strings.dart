import '../../models/enums.dart';

/// Kazakh copy for the Shop (Дүкен).
abstract final class ShopStrings {
  ShopStrings._();

  static const String title = '🛍️ Дүкен';
  static const String rotateHint = 'Айналдыру үшін сипа 🔄';

  static String categoryLabel(ItemCategory c) => switch (c) {
        ItemCategory.top => 'Жоғарғы',
        ItemCategory.bottom => 'Төменгі',
        ItemCategory.hat => 'Бас киім',
        ItemCategory.accessory => 'Аксессуар',
        ItemCategory.pet => 'Питомец',
      };

  static String rarityLabel(Rarity r) => switch (r) {
        Rarity.common => 'Қарапайым',
        Rarity.rare => 'Сирек',
        Rarity.epic => 'Эпикалық',
        Rarity.legendary => 'Аңызға айналған',
      };

  // Card badges / overlays.
  static const String ownedBadge = 'АЛЫНДЫ';
  static const String equippedBadge = 'КИГЕН ✓';
  static const String newRibbon = 'ЖАҢА';
  static String levelLock(int level) => '$level-деңгей';

  // Bottom sheet.
  static const String preview = 'Аватарда көру';
  static String buy(int price) => 'Сатып алу: 💰 $price';
  static const String equip = 'Кию';
  static const String equipped = 'Киілген ✓';

  // Toasts.
  static const String bought = 'Алынды! ✓';
  static const String equippedToast = 'Киілді! ✓';
  static const String insufficient = '💰 Монета жетімсіз! Тапсырма орында';
}
