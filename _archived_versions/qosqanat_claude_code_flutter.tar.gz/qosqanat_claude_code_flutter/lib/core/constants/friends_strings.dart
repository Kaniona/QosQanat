/// Kazakh copy for the Friends hub.
abstract final class FriendsStrings {
  FriendsStrings._();

  static const String title = '👥 Достар';

  // Tabs.
  static const String tabFriends = 'Достарым';
  static const String tabRequests = 'Өтінімдер';
  static const String tabSearch = 'Іздеу';

  // Sort.
  static const String sort = 'Сұрыптау';
  static const String sortByAkyl = 'Ақыл бойынша';
  static const String sortByLevel = 'Деңгей бойынша';
  static const String sortByName = 'Аты бойынша';

  // Actions.
  static const String battle = '⚔️ Батл';
  static const String addFriend = 'Дос қос +';
  static const String accept = 'Қабылдау';
  static const String decline = 'Бас тарту';
  static const String pending = 'Күтілуде...';

  // Search.
  static const String searchHint = 'QQ-XXXXXXXXX';
  static const String searchEmpty = 'ID арқылы дос тап!';
  static const String notFound = 'Қолданушы табылмады';
  static const String requestSent = 'Өтінім жіберілді! ✓';

  // Empty / status.
  static const String friendsEmpty = 'Әзірге досың жоқ. Іздеуден баста!';
  static const String requestsEmpty = 'Жаңа өтінім жоқ';
  static const String online = 'Желіде';
  static String levelBadge(int level) => '$level-деңгей';
}
