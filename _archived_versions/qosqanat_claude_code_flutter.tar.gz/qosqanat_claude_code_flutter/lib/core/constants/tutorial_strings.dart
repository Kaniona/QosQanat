/// Kazakh copy for the first-time spotlight tutorial.
abstract final class TutorialStrings {
  TutorialStrings._();

  static const String next = 'Келесі';
  static const String start = 'Бастау!';

  // The eight spotlight steps.
  static const String assistantTitle = 'Сенің көмекшің';
  static const String assistantBody =
      'Бұл — сенің адал көмекшің! Ол саған көмектесіп, дауыспен сөйлеседі.';

  static const String pointsTitle = 'Ұпайларың';
  static const String pointsBody =
      'Мұнда тәжірибең, монетаң және ақыл ұпайың көрсетіледі.';

  static const String learnTitle = 'Оқу';
  static const String learnBody =
      'Осы жерден сабақтарды баста — әр пәнде қызықты тапсырмалар бар!';

  static const String shopTitle = 'Дүкен';
  static const String shopBody =
      'Жинаған монетаңа көмекшіңе киім мен заттар сатып ал.';

  static const String friendsTitle = 'Достар';
  static const String friendsBody =
      'Достарыңды қосып, олармен Ақыл Батлда жарыс!';

  static const String ratingTitle = 'Рейтинг';
  static const String ratingBody =
      'Рейтингте өз орныңды көріп, жоғары көтеріл!';

  static const String questsTitle = 'Күнделікті тапсырмалар';
  static const String questsBody =
      'Күн сайын тапсырмаларды орындап, сыйлық жина.';

  static const String voiceTitle = 'Дауыс көмекшісі';
  static const String voiceBody =
      'Көмекшіңмен сөйлес — батырманы бас та, сұрағыңды айт!';

  // The celebratory finale.
  static const String finaleTitle = 'Дайынсың! 🎉';
  static const String finaleBody =
      'Саяхат аяқталды! 100 монета сыйлығың есепшотыңда. '
      'Енді білім әлемін жаулай бер! 🦅';
}
