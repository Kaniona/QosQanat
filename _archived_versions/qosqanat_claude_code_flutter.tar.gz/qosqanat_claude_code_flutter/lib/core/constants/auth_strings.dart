/// Kazakh copy for the authentication & onboarding flow.
abstract final class AuthStrings {
  AuthStrings._();

  // ─── Splash ───────────────────────────────────────────────────────────
  static const String splashTagline = 'Білімнің екі қанаты';

  // ─── Welcome carousel ─────────────────────────────────────────────────
  static const String onb1Title = 'Оқуды ойынға айналдыр!';
  static const String onb1Body = 'Тапсырма орында, ұпай жина, деңгейіңді көтер';
  static const String onb2Title = 'Досыңмен жарыс!';
  static const String onb2Body = 'Ақыл Батлда жең, рейтингте көтеріл';
  static const String onb3Title = 'Сенің жеке көмекшің';
  static const String onb3Body = 'Бектұр немесе Назым сенімен бірге оқиды';
  static const String onbStart = 'Бастау';
  static const String onbSkip = 'Өткізу';

  // ─── Auth mode toggle ─────────────────────────────────────────────────
  static const String tabLogin = 'Кіру';
  static const String tabRegister = 'Тіркелу';

  // ─── Login ────────────────────────────────────────────────────────────
  static const String loginTitle = 'Қайта қош келдің!';
  static const String loginSubtitle = 'Нөмірің мен құпиясөзіңмен кір';
  static const String labelPassword = 'Құпиясөз';
  static const String hintPassword = 'ЖСН-ің — 12 сан';
  static const String loginButton = 'Кіру';
  static const String loginFailed = 'Кіру сәтсіз аяқталды. Қайталап көр.';
  static const String invalidCredentials = 'Нөмір не құпиясөз қате.';
  static const String passwordRequired = 'Құпиясөзіңді енгіз';
  static const String noAccountPrompt = 'Аккаунтың жоқ па? ';
  static const String noAccountAction = 'Тіркел';

  // ─── Registration ─────────────────────────────────────────────────────
  static const String registerTitle = 'Тіркелу';
  static const String stepPersonal = 'Жеке мәлімет';
  static const String stepSchool = 'Оқу орны';
  static const String stepReview = 'Тексеру';

  static const String labelFullName = 'Толық атың';
  static const String hintFullName = 'Мысалы: Айдос Серіков';
  static const String labelPhone = 'Телефон нөмірің';
  static const String labelIin = 'ЖСН';
  static const String helperIin = '12 саннан тұрады';
  static const String labelCity = 'Қалаң';
  static const String hintCity = 'Қаланы таңда';
  static const String labelSchool = 'Мектебің';
  static const String hintSchool = 'Мектеп атауы немесе нөмірі';
  static const String labelGrade = 'Сыныбың';

  static const String agreeTerms = 'Қолдану шарттарымен келісемін';
  static const String agreeData = 'Деректерді өңдеуге рұқсат беремін';
  static const String reviewTitle = 'Мәліметіңді тексер';
  static const String mustAgree = 'Алдымен шарттармен келіс';
  static const String registerFailed = 'Тіркелу сәтсіз аяқталды. Қайталап көр.';

  // ─── Assistant selection ──────────────────────────────────────────────
  static const String assistantTitle = 'Өз серігіңді таңда!';
  static const String assistantSubtitle =
      'Ол сенімен бірге оқиды, мадақтайды, көмектеседі';
  static const String assistantConfirm = 'Таңдадым! ✓';

  static const String bekturName = 'Бектұр';
  static const String bekturTags = 'Қайратты, Достық, Белсенді';
  static const String bekturBio = 'Қиындықта қолдап, жеңісте бірге қуанады!';

  static const String nazymName = 'Назым';
  static const String nazymTags = 'Мейірімді, Ақылды, Сенімді';
  static const String nazymBio = 'Сабырлы түсіндіріп, әр қадамда қолдайды!';

  // ─── Welcome gift ─────────────────────────────────────────────────────
  static const String giftTitle = 'Саған 100 монета сыйладым!';
  static const String giftReward = '💰 +100';
  static const String giftContinue = 'Тамаша!';
}
