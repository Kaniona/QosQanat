/// Centralized Kazakh UI strings for QosQanat.
///
/// ALL user-facing text lives here (or in feature-specific string files) so the
/// app is fully localized in Kazakh and never hardcodes copy in widgets.
abstract final class AppStrings {
  AppStrings._();

  // ─── App ────────────────────────────────────────────────────────────────
  static const String appName = 'QosQanat';
  static const String appTagline = 'Білім — қанатыңда';

  // ─── Common actions ─────────────────────────────────────────────────────
  static const String continue_ = 'Жалғастыру';
  static const String cancel = 'Болдырмау';
  static const String done = 'Дайын';
  static const String select = 'Таңдау';
  static const String next = 'Келесі';
  static const String back = 'Артқа';
  static const String save = 'Сақтау';
  static const String confirm = 'Растау';
  static const String close = 'Жабу';
  static const String retry = 'Қайталау';
  static const String skip = 'Өткізіп жіберу';
  static const String start = 'Бастау';
  static const String finish = 'Аяқтау';
  static const String yes = 'Иә';
  static const String no = 'Жоқ';
  static const String ok = 'Жарайды';
  static const String edit = 'Өзгерту';
  static const String delete = 'Жою';
  static const String search = 'Іздеу';
  static const String send = 'Жіберу';
  static const String add = 'Қосу';
  static const String buy = 'Сатып алу';

  // ─── States ───────────────────────────────────────────────────────────────
  static const String loading = 'Жүктелуде...';
  static const String empty = 'Әзірге бос';
  static const String error = 'Қателік орын алды';
  static const String errorGeneric = 'Бірдеңе дұрыс болмады. Қайталап көріңіз.';
  static const String errorNetwork = 'Интернет байланысын тексеріңіз';
  static const String noResults = 'Ештеңе табылмады';

  // ─── Currencies & stats ─────────────────────────────────────────────────
  static const String xp = 'Тәжірибе';
  static const String coins = 'Монета';
  static const String akylPoints = 'Ақыл ұпайы';
  static const String level = 'Деңгей';
  static const String streak = 'Серия';

  // ─── Navigation tabs ───────────────────────────────────────────────────
  static const String tabHome = 'Басты бет';
  static const String tabLearn = 'Оқу';
  static const String tabShop = 'Дүкен';
  static const String tabFriends = 'Достар';
  static const String tabRating = 'Рейтинг';
  static const String tabProfile = 'Профиль';

  // ─── Assistants ───────────────────────────────────────────────────────────
  static const String bektur = 'Бектұр';
  static const String nazym = 'Назым';
  static const String chooseAssistant = 'Көмекшіңді таңда';
}
