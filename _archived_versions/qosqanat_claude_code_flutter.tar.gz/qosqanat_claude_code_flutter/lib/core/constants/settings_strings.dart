/// Kazakh copy for the Settings screen.
abstract final class SettingsStrings {
  SettingsStrings._();

  static const String title = 'Баптаулар';

  // Group headers.
  static const String groupGeneral = 'ЖАЛПЫ';
  static const String groupNotifications = 'ХАБАРЛАМАЛАР';
  static const String groupAccount = 'АККАУНТ';
  static const String groupAbout = 'ТУРАЛЫ';

  // General.
  static const String language = 'Тіл';
  static const String langKaz = 'ҚАЗ';
  static const String langRus = 'РУС';
  static const String sound = 'Дыбыс';
  static const String vibration = 'Діріл';
  static const String animations = 'Анимациялар';

  // Notifications.
  static const String notifQuests = 'Күнделікті тапсырмалар';
  static const String notifBattles = 'Батл шақырулары';
  static const String notifFriends = 'Дос өтінімдері';
  static const String streakReminder = 'Streak еске салғыш';

  // Account.
  static const String editProfile = 'Профильді өңдеу';
  static const String changeAssistant = 'Көмекшіні ауыстыру';
  static const String changeAssistantNote = '30 күнде бір рет';
  static const String viewQqId = 'QQ-ID көру';

  // About.
  static const String version = 'Нұсқа';
  static const String versionValue = '1.0.0';
  static const String terms = 'Қолдану шарттары';
  static const String privacy = 'Құпиялылық саясаты';
  static const String support = 'Қолдау';
  static const String supportEmail = 'support@qosqanat.kz';

  // Logout dialog.
  static const String logout = 'Аккаунттан шығу';
  static const String logoutConfirmTitle = 'Шығу';
  static const String logoutConfirmBody = 'Аккаунттан шыққыңыз келе ме?';
  static const String cancel = 'Болдырмау';
  static const String confirm = 'Шығу';
}
