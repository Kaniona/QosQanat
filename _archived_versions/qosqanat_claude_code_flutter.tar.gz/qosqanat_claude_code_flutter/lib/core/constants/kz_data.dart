/// Static reference data for Kazakhstan (cities, grades).
abstract final class KzData {
  KzData._();

  /// Major cities, in Kazakh, used by the registration city dropdown.
  static const List<String> cities = [
    'Астана',
    'Алматы',
    'Шымкент',
    'Қарағанды',
    'Қызылорда',
    'Ақтөбе',
    'Тараз',
    'Өскемен',
    'Павлодар',
    'Семей',
    'Орал',
    'Атырау',
    'Ақтау',
    'Петропавл',
    'Қостанай',
    'Талдықорған',
    'Көкшетау',
    'Түркістан',
  ];

  /// Selectable school grades.
  static const List<int> grades = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
}
