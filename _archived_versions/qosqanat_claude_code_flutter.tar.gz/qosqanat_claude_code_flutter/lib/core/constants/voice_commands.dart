/// Recognizable Kazakh voice commands, grouped by intent, plus the parser's
/// result type and the spoken-response builders.
///
/// Patterns are matched as substrings against the normalized (lower-cased,
/// punctuation-stripped) recognized text, so a student can phrase a command
/// loosely ("менің деңгейім қанша екен?") and still be understood.
library;

/// The kind of action a recognized command maps to.
enum VoiceIntentType { navigate, info, externalApp, aiQuery }

/// In-app destinations the assistant can navigate to.
enum NavTarget { home, learn, shop, friends, rating, profile }

/// Spoken-information queries the assistant can answer about the student.
enum InfoQuery { level, coins, akyl, streak }

/// External apps the assistant can launch.
enum ExternalApp { youtube, whatsapp, instagram, tiktok, telegram, calculator }

/// A static command definition: the phrases that trigger it and what it does.
class VoiceCommand {
  const VoiceCommand({
    required this.patterns,
    required this.type,
    this.nav,
    this.info,
    this.app,
  });

  final List<String> patterns;
  final VoiceIntentType type;
  final NavTarget? nav;
  final InfoQuery? info;
  final ExternalApp? app;
}

/// The parsed result of a recognized utterance.
class VoiceIntent {
  const VoiceIntent({
    required this.type,
    required this.rawText,
    this.nav,
    this.info,
    this.app,
  });

  final VoiceIntentType type;
  final String rawText;
  final NavTarget? nav;
  final InfoQuery? info;
  final ExternalApp? app;

  /// The fallback for unrecognized input: an open-ended AI query.
  factory VoiceIntent.ai(String rawText) =>
      VoiceIntent(type: VoiceIntentType.aiQuery, rawText: rawText);
}

/// The full command catalog. More specific patterns (e.g. "нешінші тұрмын")
/// should appear before broader ones so they win when both could match.
const List<VoiceCommand> kVoiceCommands = [
  // ─── Navigation ─────────────────────────────────────────────────────────
  VoiceCommand(
    patterns: ['басты бет', 'үй', 'үйге', 'home'],
    type: VoiceIntentType.navigate,
    nav: NavTarget.home,
  ),
  VoiceCommand(
    patterns: ['сабақ', 'оқу', 'карта', 'оқуым'],
    type: VoiceIntentType.navigate,
    nav: NavTarget.learn,
  ),
  VoiceCommand(
    patterns: ['дүкен', 'дүкенге', 'магазин'],
    type: VoiceIntentType.navigate,
    nav: NavTarget.shop,
  ),
  VoiceCommand(
    patterns: ['достар', 'достарым', 'дос'],
    type: VoiceIntentType.navigate,
    nav: NavTarget.friends,
  ),
  VoiceCommand(
    patterns: ['рейтинг', 'нешінші тұрмын', 'орным қандай'],
    type: VoiceIntentType.navigate,
    nav: NavTarget.rating,
  ),
  VoiceCommand(
    patterns: ['профиль', 'профильім', 'менің бетім'],
    type: VoiceIntentType.navigate,
    nav: NavTarget.profile,
  ),

  // ─── Information (spoken answers) ────────────────────────────────────────
  VoiceCommand(
    patterns: ['деңгейім қанша', 'деңгейім', 'қай деңгейдемін'],
    type: VoiceIntentType.info,
    info: InfoQuery.level,
  ),
  VoiceCommand(
    patterns: ['монетам қанша', 'монетам', 'қанша монета'],
    type: VoiceIntentType.info,
    info: InfoQuery.coins,
  ),
  VoiceCommand(
    patterns: ['ақыл ұпайым', 'ақыл ұпай', 'ұпайым қанша'],
    type: VoiceIntentType.info,
    info: InfoQuery.akyl,
  ),
  VoiceCommand(
    patterns: ['стригім', 'стрик', 'streak', 'неше күн'],
    type: VoiceIntentType.info,
    info: InfoQuery.streak,
  ),

  // ─── External apps ──────────────────────────────────────────────────────
  VoiceCommand(
    patterns: ['youtube', 'ютуб'],
    type: VoiceIntentType.externalApp,
    app: ExternalApp.youtube,
  ),
  VoiceCommand(
    patterns: ['whatsapp', 'ватсап', 'васап'],
    type: VoiceIntentType.externalApp,
    app: ExternalApp.whatsapp,
  ),
  VoiceCommand(
    patterns: ['instagram', 'инстаграм', 'инста'],
    type: VoiceIntentType.externalApp,
    app: ExternalApp.instagram,
  ),
  VoiceCommand(
    patterns: ['tiktok', 'тикток'],
    type: VoiceIntentType.externalApp,
    app: ExternalApp.tiktok,
  ),
  VoiceCommand(
    patterns: ['telegram', 'телеграм'],
    type: VoiceIntentType.externalApp,
    app: ExternalApp.telegram,
  ),
  VoiceCommand(
    patterns: ['калькулятор', 'есептегіш'],
    type: VoiceIntentType.externalApp,
    app: ExternalApp.calculator,
  ),
];

/// Normalizes recognized text for matching: lower-case, collapse whitespace and
/// strip punctuation so "Дүкен!" and "дүкен" compare equal.
String normalizeCommand(String text) {
  return text
      .toLowerCase()
      .replaceAll(RegExp(r'[^\wа-яёәғқңөұүһі\s]', unicode: true), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}

/// Matches [recognizedText] against the catalog, returning the first command's
/// intent or an [VoiceIntent.ai] fallback when nothing matches.
VoiceIntent parseVoiceCommand(String recognizedText) {
  final text = normalizeCommand(recognizedText);
  if (text.isEmpty) return VoiceIntent.ai(recognizedText);

  for (final command in kVoiceCommands) {
    for (final pattern in command.patterns) {
      if (text.contains(pattern)) {
        return VoiceIntent(
          type: command.type,
          rawText: recognizedText,
          nav: command.nav,
          info: command.info,
          app: command.app,
        );
      }
    }
  }
  return VoiceIntent.ai(recognizedText);
}

/// Builds the Kazakh spoken answer for an [InfoQuery] from the player's numbers.
String infoResponse(
  InfoQuery query, {
  required int level,
  required int coins,
  required int akyl,
  required int rank,
  required int streak,
}) {
  switch (query) {
    case InfoQuery.level:
      return 'Сіздің деңгейіңіз $level';
    case InfoQuery.coins:
      return 'Сізде $coins монета бар';
    case InfoQuery.akyl:
      return 'Ақыл ұпайыңыз $akyl, рейтингте $rank-орындасыз';
    case InfoQuery.streak:
      return 'Сіз $streak күн қатарынан кіріп тұрсыз';
  }
}
