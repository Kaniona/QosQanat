/// Kazakh copy for the Rating / Leaderboard screen.
abstract final class RatingStrings {
  RatingStrings._();

  static const String title = '🏆 Рейтинг';

  // Scope tabs.
  static const String scopeGlobal = '🌍 Жалпы';
  static const String scopeCity = '🏙️ Қалам';
  static const String scopeSchool = '🏫 Мектебім';
  static const String scopeFriends = '👥 Достарым';

  // Rows / status.
  static const String you = 'Сіз';
  static const String akylUnit = 'ақыл';
  static const String noMovement = '—';
  static String myRank(int rank) => 'Сіздің орныңыз: $rank';
  static String levelBadge(int level) => '$level-деңгей';

  // Empty / locked states.
  static const String schoolLocked =
      'Мектеп рейтингі кемінде 10 оқушы тіркелгенде ашылады';
  static const String friendsEmpty =
      'Достарың әлі жоқ. Дос қосып, рейтингте жарыс!';
  static const String empty = 'Рейтинг әзірге бос';
  static const String loadError = 'Рейтингті жүктеу мүмкін болмады';
}
