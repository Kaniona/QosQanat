/// Kazakh copy for the Profile (trophy room) screen.
abstract final class ProfileStrings {
  ProfileStrings._();

  static const String title = 'Профиль';
  static const String copied = 'Көшірілді!';

  // Stats grid.
  static const String statAkyl = 'Ақыл ұпайы';
  static const String statCoins = 'Монета';
  static const String statFriends = 'Достар';
  static const String statStreak = 'Ұзақ streak';
  static const String statTasks = 'Орындалған';
  static const String statBattles = 'Батл жеңіс';

  // Sections.
  static const String achievementsTitle = '🏅 Жетістіктер';
  static const String activityTitle = '📅 Белсенділік';
  static const String recentBattlesTitle = 'Соңғы батлдар';
  static String achievementsProgress(int unlocked, int total) =>
      '$unlocked/$total ашылды';
  static const String locked = '?';

  // Recent battles.
  static const String win = 'Ж'; // Жеңіс
  static const String loss = 'Қ'; // Қателесу / жеңіліс
  static const String noBattles = 'Әзірге батл ойналмаған';

  // Actions.
  static const String logout = 'Шығу';
  static const String logoutConfirmTitle = 'Шығу';
  static const String logoutConfirmBody = 'Аккаунттан шыққыңыз келе ме?';
  static const String cancel = 'Болдырмау';
}
