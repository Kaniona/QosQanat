/// Kazakh copy for the Home screen.
abstract final class HomeStrings {
  HomeStrings._();

  static const String greetingSubtitle = 'Бүгін не үйренеміз?';

  // Greetings (name interpolated by the widget).
  static String morning(String name) => 'Қайырлы таң, $name! ☀️';
  static String day(String name) => 'Сәлем, $name! 👋';
  static String evening(String name) => 'Кешкі сәлем, $name! 🌆';
  static const String night = 'Ұйықтар алдында бір тапсырма? 🌙';

  /// Picks the greeting for the device clock [hour] (0–23).
  static String greeting(int hour, String name) {
    if (hour >= 6 && hour < 12) return morning(name);
    if (hour >= 12 && hour < 18) return day(name);
    if (hour >= 18 && hour < 22) return evening(name);
    return night;
  }

  // Level / progress.
  static String xpToNext(int xp) => 'Келесі деңгейге $xp XP қалды';
  static const String maxLevel = 'Ең жоғары деңгейге жеттің! 👑';

  // Streak.
  static String streakDays(int n) => '$n күн қатарынан!';
  static String streakEncourage(int next) => 'Ертең $next күн болады! Жалғастыр 🔥';
  static const String streakStart = 'Бүгін серияңды баста! 🔥';

  // Quests.
  static const String questsTitle = '📋 Бүгінгі квесттер';
  static const String claim = 'Алу';
  static const String claimed = 'Алынды ✓';

  // Quick actions.
  static const String actionLearn = 'Оқу';
  static const String actionBattle = 'Батл';
  static const String actionRating = 'Рейтинг';

  // Continue learning.
  static const String continueTitle = 'Жалғастыр';
  static const String continueButton = 'Жалғастыру →';
  static const String continueSubject = 'Математика';
  static String continueGrade(int grade) => '$grade-сынып';

  // Generic "not built yet" feedback for sections still in development.
  static const String comingSoon = 'Жақында! 🚀';

  // Achievements.
  static const String achievementsTitle = '🏅 Соңғы жетістіктер';
  static const String viewAll = 'Барлығын көру →';
  static const String noAchievements = 'Алғашқы жетістігіңді ал! 🎯';

  // Voice.
  static const String voiceComingSoon = 'Дауыс көмекшісі жақында іске қосылады!';

  static const String defaultName = 'дос';
}
