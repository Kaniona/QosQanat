/// Kazakh copy for the voice assistant overlay and spoken confirmations.
abstract final class VoiceStrings {
  VoiceStrings._();

  // Overlay prompts.
  static const String listening = 'Айт, тыңдап тұрмын! 🎤';
  static const String thinking = 'Ойланып жатырмын...';
  static const String tapToSpeak = 'Сөйлеу үшін басыңыз';

  // Permission dialog.
  static const String permissionTitle = 'Микрофонға рұқсат керек';
  static const String permissionBody =
      'Дауыс көмекшісін пайдалану үшін микрофонға рұқсат беріңіз. '
      'Сонда мен сені тыңдап, көмектесе аламын!';
  static const String permissionOk = 'Түсіндім';

  // Spoken confirmations for navigation.
  static const String openingHome = 'Басты бетке өтіп жатырмын';
  static const String openingLearn = 'Сабаққа өтейік!';
  static const String openingShop = 'Дүкенді ашып жатырмын';
  static const String openingFriends = 'Достарыңды ашайын';
  static const String openingRating = 'Рейтингті ашып жатырмын';
  static const String openingProfile = 'Профиліңді ашайын';

  // External app launch.
  static String openingApp(String name) => '$name ашып жатырмын';
  static const String launchFailed = 'Кешір, бұл қолданбаны аша алмадым';

  // AI fallback (placeholder until the Anthropic API is wired in).
  static const String aiFallback = 'Бұл сұраққа кейінірек жауап бере аламын!';

  // Discovery card.
  static const String hintTitle = 'Менен сұра:';
  static const String hintNav = '🧭 «Дүкенді аш», «Сабаққа өт»';
  static const String hintInfo = '📊 «Деңгейім қанша?», «Монетам қанша?»';
  static const String hintApps = '📱 «YouTube аш», «WhatsApp аш»';
}
