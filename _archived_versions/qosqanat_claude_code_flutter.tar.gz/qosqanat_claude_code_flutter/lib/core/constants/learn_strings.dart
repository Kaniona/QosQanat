import '../../models/enums.dart';

/// Kazakh copy for the learning system (subjects, map, tasks, results).
abstract final class LearnStrings {
  LearnStrings._();

  // Subject selection.
  static const String subjectsTitle = '📚 Пәндер';
  static String taskCount(int done, int total) => '$done/$total тапсырма';

  // Map.
  static const String start = 'Бастау';
  static const String startArrow = 'Бастау →';
  static const String lockedToast = '🔒 Алдыңғы тапсырманы аяқта!';
  static String moduleComplete(int grade, int next) =>
      '$grade-сынып модулі аяқталды! $next-сынып басталады';
  static String questionCount(int n) => '$n сұрақ';

  // Node type labels.
  static String nodeType(NodeType type) => switch (type) {
        NodeType.lesson => 'Сабақ',
        NodeType.quiz => 'Сынақ',
        NodeType.boss => 'Босс',
        NodeType.treasure => 'Қазына',
      };

  static String nodeEmoji(NodeType type) => switch (type) {
        NodeType.lesson => '📘',
        NodeType.quiz => '⚡',
        NodeType.boss => '🐉',
        NodeType.treasure => '💎',
      };

  // Task screen.
  static const String explanationTitle = 'Түсіндірме';
  static const String continueLabel = 'Жалғастыру';
  static const String trueLabel = 'Дұрыс ✓';
  static const String falseLabel = 'Қате ✗';
  static const String tapWordHint = 'Сөзді таңда';
  static const String checkLabel = 'Тексеру';
  static const String quitTitle = 'Шығасың ба?';
  static const String quitBody = 'Бұл тапсырманың барысы сақталмайды.';
  static const String quitConfirm = 'Шығу';
  static const String stay = 'Қалу';

  // Gentle encouragement after a wrong answer.
  static const String tryAgainGentle = 'Ештеңе етпейді, жалғастыр! 💪';
  static const String correctCheer = 'Жарайсың! ✨';

  // Result.
  static const String resultTitle = '🎉 Тапсырма аяқталды!';
  static const String rewardsTitle = 'Сыйлықтар';
  static const String resultContinue = 'Жалғастыру →';
  static const String resultRetry = 'Қайталау';
  static const String unlockedNext = 'Келесі деңгей ашылды! 🔓';
  static const String allDone = 'Бұл әлемді толық бітірдің! 👑';
  static String scorePercent(int p) => '$p%';
}
