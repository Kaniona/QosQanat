import 'friend.dart';

/// The scope a leaderboard is computed over.
enum RatingScope {
  global,
  city,
  school,
  friends;

  String toJson() => name;
}

/// A single ranked row in a leaderboard: a public profile plus its rank, the
/// movement since the previous ranking, and whether it is the signed-in user.
class LeaderboardEntry {
  const LeaderboardEntry({
    required this.rank,
    required this.profile,
    this.rankChange = 0,
    this.isMe = false,
  });

  final int rank;
  final PublicProfile profile;

  /// Positive = climbed (↑), negative = dropped (↓), zero = unchanged (—).
  final int rankChange;
  final bool isMe;

  factory LeaderboardEntry.fromJson(Map<String, dynamic> json, {String? meId}) {
    final profile = PublicProfile.fromJson(json);
    return LeaderboardEntry(
      rank: (json['rank'] as num?)?.toInt() ?? 0,
      profile: profile,
      rankChange: (json['rank_change'] as num?)?.toInt() ?? 0,
      isMe: (json['is_me'] as bool?) ?? (meId != null && profile.id == meId),
    );
  }

  LeaderboardEntry copyWith({int? rank, int? rankChange, bool? isMe}) {
    return LeaderboardEntry(
      rank: rank ?? this.rank,
      profile: profile,
      rankChange: rankChange ?? this.rankChange,
      isMe: isMe ?? this.isMe,
    );
  }
}

/// A compact summary of a finished battle, for the profile's recent list.
class RecentBattle {
  const RecentBattle({
    required this.won,
    required this.opponentName,
    required this.myScore,
    required this.opponentScore,
    this.finishedAt,
  });

  final bool won;
  final String opponentName;
  final int myScore;
  final int opponentScore;
  final DateTime? finishedAt;

  factory RecentBattle.fromJson(Map<String, dynamic> json) {
    return RecentBattle(
      won: (json['won'] as bool?) ?? false,
      opponentName: json['opponent_name'] as String? ?? '',
      myScore: (json['my_score'] as num?)?.toInt() ?? 0,
      opponentScore: (json['opponent_score'] as num?)?.toInt() ?? 0,
      finishedAt: json['finished_at'] == null
          ? null
          : DateTime.tryParse(json['finished_at'] as String),
    );
  }
}
