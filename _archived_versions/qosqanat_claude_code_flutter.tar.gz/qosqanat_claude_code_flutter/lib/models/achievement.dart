/// An unlockable achievement spanning learning, battles, collection,
/// friends and streaks.
class Achievement {
  const Achievement({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.targetProgress,
    this.currentProgress = 0,
    this.coinReward = 0,
    this.akylReward = 0,
    this.iconName,
    this.unlockedAt,
  });

  final String id;
  final String title;
  final String description;

  /// Grouping such as `learning`, `battle`, `collection`, `friends`, `streak`.
  final String category;

  final int targetProgress;
  final int currentProgress;

  final int coinReward;
  final int akylReward;

  final String? iconName;

  /// When the achievement was unlocked; null while still locked.
  final DateTime? unlockedAt;

  bool get isUnlocked => unlockedAt != null;

  double get progressFraction =>
      targetProgress == 0 ? 0 : (currentProgress / targetProgress).clamp(0, 1);

  factory Achievement.fromJson(Map<String, dynamic> json) {
    return Achievement(
      id: json['id'] as String,
      title: json['title'] as String? ?? '',
      description: json['description'] as String? ?? '',
      category: json['category'] as String? ?? 'learning',
      targetProgress: (json['target_progress'] as num?)?.toInt() ?? 1,
      currentProgress: (json['current_progress'] as num?)?.toInt() ?? 0,
      coinReward: (json['coin_reward'] as num?)?.toInt() ?? 0,
      akylReward: (json['akyl_reward'] as num?)?.toInt() ?? 0,
      iconName: json['icon_name'] as String?,
      unlockedAt: json['unlocked_at'] == null
          ? null
          : DateTime.tryParse(json['unlocked_at'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'category': category,
      'target_progress': targetProgress,
      'current_progress': currentProgress,
      'coin_reward': coinReward,
      'akyl_reward': akylReward,
      'icon_name': iconName,
      'unlocked_at': unlockedAt?.toIso8601String(),
    };
  }

  Achievement copyWith({
    String? id,
    String? title,
    String? description,
    String? category,
    int? targetProgress,
    int? currentProgress,
    int? coinReward,
    int? akylReward,
    String? iconName,
    DateTime? unlockedAt,
  }) {
    return Achievement(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      targetProgress: targetProgress ?? this.targetProgress,
      currentProgress: currentProgress ?? this.currentProgress,
      coinReward: coinReward ?? this.coinReward,
      akylReward: akylReward ?? this.akylReward,
      iconName: iconName ?? this.iconName,
      unlockedAt: unlockedAt ?? this.unlockedAt,
    );
  }
}
