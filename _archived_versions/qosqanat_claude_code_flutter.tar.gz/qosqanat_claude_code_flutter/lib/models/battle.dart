import 'enums.dart';

/// A realtime 1-versus-1 Akyl Battle between two students.
class Battle {
  const Battle({
    required this.id,
    required this.hostId,
    this.opponentId,
    required this.questionCount,
    required this.status,
    this.hostScore = 0,
    this.opponentScore = 0,
    this.winnerId,
    this.subjectId,
    required this.createdAt,
    this.finishedAt,
  });

  final String id;
  final String hostId;
  final String? opponentId;

  /// Total questions in the match: one of 15, 20, 25, 40, 50.
  final int questionCount;
  final BattleStatus status;

  final int hostScore;
  final int opponentScore;

  /// Set once the battle is finished; null on a draw.
  final String? winnerId;

  /// Optional subject the battle questions are drawn from.
  final String? subjectId;

  final DateTime createdAt;
  final DateTime? finishedAt;

  factory Battle.fromJson(Map<String, dynamic> json) {
    return Battle(
      id: json['id'] as String,
      hostId: json['host_id'] as String,
      opponentId: json['opponent_id'] as String?,
      questionCount: (json['question_count'] as num?)?.toInt() ?? 15,
      status: BattleStatus.fromJson(json['status'] as String?),
      hostScore: (json['host_score'] as num?)?.toInt() ?? 0,
      opponentScore: (json['opponent_score'] as num?)?.toInt() ?? 0,
      winnerId: json['winner_id'] as String?,
      subjectId: json['subject_id'] as String?,
      createdAt: DateTime.tryParse(json['created_at'] as String? ?? '') ??
          DateTime.now(),
      finishedAt: json['finished_at'] == null
          ? null
          : DateTime.tryParse(json['finished_at'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'host_id': hostId,
      'opponent_id': opponentId,
      'question_count': questionCount,
      'status': status.toJson(),
      'host_score': hostScore,
      'opponent_score': opponentScore,
      'winner_id': winnerId,
      'subject_id': subjectId,
      'created_at': createdAt.toIso8601String(),
      'finished_at': finishedAt?.toIso8601String(),
    };
  }

  Battle copyWith({
    String? id,
    String? hostId,
    String? opponentId,
    int? questionCount,
    BattleStatus? status,
    int? hostScore,
    int? opponentScore,
    String? winnerId,
    String? subjectId,
    DateTime? createdAt,
    DateTime? finishedAt,
  }) {
    return Battle(
      id: id ?? this.id,
      hostId: hostId ?? this.hostId,
      opponentId: opponentId ?? this.opponentId,
      questionCount: questionCount ?? this.questionCount,
      status: status ?? this.status,
      hostScore: hostScore ?? this.hostScore,
      opponentScore: opponentScore ?? this.opponentScore,
      winnerId: winnerId ?? this.winnerId,
      subjectId: subjectId ?? this.subjectId,
      createdAt: createdAt ?? this.createdAt,
      finishedAt: finishedAt ?? this.finishedAt,
    );
  }
}
