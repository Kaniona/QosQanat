import 'enums.dart';

/// A purchasable / collectible item for the assistant avatar.
class ShopItem {
  const ShopItem({
    required this.id,
    required this.name,
    this.description,
    required this.category,
    required this.rarity,
    required this.price,
    required this.assetPath,
    this.levelRequirement = 1,
    this.isOwned = false,
    this.isEquipped = false,
  });

  final String id;
  final String name;
  final String? description;
  final ItemCategory category;
  final Rarity rarity;

  /// Price in coins.
  final int price;

  /// Path to the SVG / image asset for this item.
  final String assetPath;

  /// Minimum player level required to buy.
  final int levelRequirement;

  // Per-user ownership state.
  final bool isOwned;
  final bool isEquipped;

  factory ShopItem.fromJson(Map<String, dynamic> json) {
    return ShopItem(
      id: json['id'] as String,
      name: json['name'] as String? ?? '',
      description: json['description'] as String?,
      category: ItemCategory.fromJson(json['category'] as String?),
      rarity: Rarity.fromJson(json['rarity'] as String?),
      price: (json['price'] as num?)?.toInt() ?? 0,
      assetPath: json['asset_path'] as String? ?? '',
      levelRequirement: (json['level_requirement'] as num?)?.toInt() ?? 1,
      isOwned: json['is_owned'] as bool? ?? false,
      isEquipped: json['is_equipped'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'category': category.toJson(),
      'rarity': rarity.toJson(),
      'price': price,
      'asset_path': assetPath,
      'level_requirement': levelRequirement,
      'is_owned': isOwned,
      'is_equipped': isEquipped,
    };
  }

  ShopItem copyWith({
    String? id,
    String? name,
    String? description,
    ItemCategory? category,
    Rarity? rarity,
    int? price,
    String? assetPath,
    int? levelRequirement,
    bool? isOwned,
    bool? isEquipped,
  }) {
    return ShopItem(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      category: category ?? this.category,
      rarity: rarity ?? this.rarity,
      price: price ?? this.price,
      assetPath: assetPath ?? this.assetPath,
      levelRequirement: levelRequirement ?? this.levelRequirement,
      isOwned: isOwned ?? this.isOwned,
      isEquipped: isEquipped ?? this.isEquipped,
    );
  }
}
