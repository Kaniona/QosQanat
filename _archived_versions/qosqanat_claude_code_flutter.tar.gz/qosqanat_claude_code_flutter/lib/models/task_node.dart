import 'enums.dart';

/// A single node on the learning map (lesson, quiz, boss, or treasure).
class TaskNode {
  const TaskNode({
    required this.id,
    required this.moduleId,
    required this.title,
    this.description,
    required this.type,
    required this.orderIndex,
    this.xpReward = 0,
    this.coinReward = 0,
    this.akylReward = 0,
    this.isLocked = true,
    this.isCompleted = false,
    this.starsEarned = 0,
  });

  final String id;
  final String moduleId;
  final String title;
  final String? description;
  final NodeType type;

  /// Position of this node within its module (0-based).
  final int orderIndex;

  // Rewards granted on completion.
  final int xpReward;
  final int coinReward;
  final int akylReward;

  // Per-user progress state.
  final bool isLocked;
  final bool isCompleted;

  /// 0–3 stars based on performance.
  final int starsEarned;

  factory TaskNode.fromJson(Map<String, dynamic> json) {
    return TaskNode(
      id: json['id'] as String,
      moduleId: json['module_id'] as String,
      title: json['title'] as String? ?? '',
      description: json['description'] as String?,
      type: NodeType.fromJson(json['type'] as String?),
      orderIndex: (json['order_index'] as num?)?.toInt() ?? 0,
      xpReward: (json['xp_reward'] as num?)?.toInt() ?? 0,
      coinReward: (json['coin_reward'] as num?)?.toInt() ?? 0,
      akylReward: (json['akyl_reward'] as num?)?.toInt() ?? 0,
      isLocked: json['is_locked'] as bool? ?? true,
      isCompleted: json['is_completed'] as bool? ?? false,
      starsEarned: (json['stars_earned'] as num?)?.toInt() ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'module_id': moduleId,
      'title': title,
      'description': description,
      'type': type.toJson(),
      'order_index': orderIndex,
      'xp_reward': xpReward,
      'coin_reward': coinReward,
      'akyl_reward': akylReward,
      'is_locked': isLocked,
      'is_completed': isCompleted,
      'stars_earned': starsEarned,
    };
  }

  TaskNode copyWith({
    String? id,
    String? moduleId,
    String? title,
    String? description,
    NodeType? type,
    int? orderIndex,
    int? xpReward,
    int? coinReward,
    int? akylReward,
    bool? isLocked,
    bool? isCompleted,
    int? starsEarned,
  }) {
    return TaskNode(
      id: id ?? this.id,
      moduleId: moduleId ?? this.moduleId,
      title: title ?? this.title,
      description: description ?? this.description,
      type: type ?? this.type,
      orderIndex: orderIndex ?? this.orderIndex,
      xpReward: xpReward ?? this.xpReward,
      coinReward: coinReward ?? this.coinReward,
      akylReward: akylReward ?? this.akylReward,
      isLocked: isLocked ?? this.isLocked,
      isCompleted: isCompleted ?? this.isCompleted,
      starsEarned: starsEarned ?? this.starsEarned,
    );
  }
}
