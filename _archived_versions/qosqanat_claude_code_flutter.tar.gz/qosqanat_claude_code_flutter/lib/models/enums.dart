// Domain enums for QosQanat, each with safe JSON (de)serialization.

/// The two AI assistants a student can choose as their lifelong companion.
enum AssistantType {
  bektur,
  nazym;

  static AssistantType fromJson(String? value) {
    return AssistantType.values.firstWhere(
      (e) => e.name == value,
      orElse: () => AssistantType.bektur,
    );
  }

  String toJson() => name;
}

/// The kinds of nodes that appear on the learning map.
enum NodeType {
  lesson,
  quiz,
  boss,
  treasure;

  static NodeType fromJson(String? value) {
    return NodeType.values.firstWhere(
      (e) => e.name == value,
      orElse: () => NodeType.lesson,
    );
  }

  String toJson() => name;
}

/// Wearable / collectible categories for the assistant avatar.
enum ItemCategory {
  top,
  bottom,
  hat,
  accessory,
  pet;

  static ItemCategory fromJson(String? value) {
    return ItemCategory.values.firstWhere(
      (e) => e.name == value,
      orElse: () => ItemCategory.accessory,
    );
  }

  String toJson() => name;
}

/// Rarity tiers for shop items.
enum Rarity {
  common,
  rare,
  epic,
  legendary;

  static Rarity fromJson(String? value) {
    return Rarity.values.firstWhere(
      (e) => e.name == value,
      orElse: () => Rarity.common,
    );
  }

  String toJson() => name;
}

/// Lifecycle of an Akyl Battle.
enum BattleStatus {
  waiting,
  active,
  finished,
  cancelled;

  static BattleStatus fromJson(String? value) {
    return BattleStatus.values.firstWhere(
      (e) => e.name == value,
      orElse: () => BattleStatus.waiting,
    );
  }

  String toJson() => name;
}
