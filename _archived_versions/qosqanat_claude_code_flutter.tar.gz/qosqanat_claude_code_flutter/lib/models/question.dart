/// Question models for the four task types. A sealed hierarchy so the task
/// screen can exhaustively switch on the concrete type to pick its widget.
library;

/// Base type for every question. [prompt] and [explanation] are Kazakh.
sealed class Question {
  const Question({
    required this.id,
    required this.prompt,
    this.explanation,
  });

  final String id;
  final String prompt;

  /// Shown after a wrong answer to teach gently (never punish).
  final String? explanation;
}

/// A question with four answer cards; exactly one is correct.
class MultipleChoiceQuestion extends Question {
  const MultipleChoiceQuestion({
    required super.id,
    required super.prompt,
    required this.options,
    required this.correctIndex,
    super.explanation,
  });

  final List<String> options;
  final int correctIndex;

  String get correctAnswer => options[correctIndex];
}

/// A statement the student judges true or false.
class TrueFalseQuestion extends Question {
  const TrueFalseQuestion({
    required super.id,
    required super.prompt,
    required this.answer,
    super.explanation,
  });

  /// Whether the statement is true.
  final bool answer;
}

/// A sentence with a blank, filled from a bank of word chips.
class FillBlankQuestion extends Question {
  const FillBlankQuestion({
    required super.id,
    required super.prompt,
    required this.words,
    required this.correctIndex,
    super.explanation,
  });

  /// The word bank shown as tappable chips.
  final List<String> words;

  /// Index into [words] of the correct chip.
  final int correctIndex;

  String get correctWord => words[correctIndex];
}

/// A single left↔right association in a [MatchPairsQuestion].
class MatchPair {
  const MatchPair({required this.left, required this.right});
  final String left;
  final String right;
}

/// Two columns the student connects by matching pairs.
class MatchPairsQuestion extends Question {
  const MatchPairsQuestion({
    required super.id,
    required super.prompt,
    required this.pairs,
    super.explanation,
  });

  final List<MatchPair> pairs;
}
