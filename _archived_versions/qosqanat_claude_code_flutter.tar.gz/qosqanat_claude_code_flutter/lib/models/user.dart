import 'enums.dart';

/// Immutable representation of a QosQanat student.
class User {
  const User({
    required this.id,
    required this.qosqanatId,
    required this.fullName,
    this.phone,
    this.iin,
    this.city,
    this.school,
    required this.grade,
    required this.assistantType,
    this.level = 1,
    this.xp = 0,
    this.coins = 0,
    this.akylPoints = 0,
    this.currentStreak = 0,
    this.longestStreak = 0,
    this.lastLoginDate,
    this.totalTasksCompleted = 0,
    this.totalBattlesWon = 0,
    required this.createdAt,
  });

  /// Supabase auth/user UUID.
  final String id;

  /// Public friend code, format `QQ-XXXXXXXXX`.
  final String qosqanatId;
  final String fullName;
  final String? phone;
  final String? iin;
  final String? city;
  final String? school;

  /// School grade, 5–11.
  final int grade;
  final AssistantType assistantType;

  // Progression.
  final int level;
  final int xp;
  final int coins;
  final int akylPoints;
  final int currentStreak;
  final int longestStreak;

  /// Date of the user's most recent daily login (date-only).
  final DateTime? lastLoginDate;
  final int totalTasksCompleted;
  final int totalBattlesWon;

  final DateTime createdAt;

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] as String,
      qosqanatId: json['qosqanat_id'] as String,
      fullName: json['full_name'] as String? ?? '',
      phone: json['phone'] as String?,
      iin: json['iin'] as String?,
      city: json['city'] as String?,
      school: json['school'] as String?,
      grade: (json['grade'] as num?)?.toInt() ?? 5,
      assistantType: AssistantType.fromJson(json['assistant_type'] as String?),
      level: (json['level'] as num?)?.toInt() ?? 1,
      xp: (json['xp'] as num?)?.toInt() ?? 0,
      coins: (json['coins'] as num?)?.toInt() ?? 0,
      akylPoints: (json['akyl_points'] as num?)?.toInt() ?? 0,
      currentStreak: (json['current_streak'] as num?)?.toInt() ?? 0,
      longestStreak: (json['longest_streak'] as num?)?.toInt() ?? 0,
      lastLoginDate: json['last_login_date'] == null
          ? null
          : DateTime.tryParse(json['last_login_date'] as String),
      totalTasksCompleted: (json['total_tasks_completed'] as num?)?.toInt() ?? 0,
      totalBattlesWon: (json['total_battles_won'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.tryParse(json['created_at'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'qosqanat_id': qosqanatId,
      'full_name': fullName,
      'phone': phone,
      'iin': iin,
      'city': city,
      'school': school,
      'grade': grade,
      'assistant_type': assistantType.toJson(),
      'level': level,
      'xp': xp,
      'coins': coins,
      'akyl_points': akylPoints,
      'current_streak': currentStreak,
      'longest_streak': longestStreak,
      'last_login_date': lastLoginDate?.toIso8601String(),
      'total_tasks_completed': totalTasksCompleted,
      'total_battles_won': totalBattlesWon,
      'created_at': createdAt.toIso8601String(),
    };
  }

  User copyWith({
    String? id,
    String? qosqanatId,
    String? fullName,
    String? phone,
    String? iin,
    String? city,
    String? school,
    int? grade,
    AssistantType? assistantType,
    int? level,
    int? xp,
    int? coins,
    int? akylPoints,
    int? currentStreak,
    int? longestStreak,
    DateTime? lastLoginDate,
    int? totalTasksCompleted,
    int? totalBattlesWon,
    DateTime? createdAt,
  }) {
    return User(
      id: id ?? this.id,
      qosqanatId: qosqanatId ?? this.qosqanatId,
      fullName: fullName ?? this.fullName,
      phone: phone ?? this.phone,
      iin: iin ?? this.iin,
      city: city ?? this.city,
      school: school ?? this.school,
      grade: grade ?? this.grade,
      assistantType: assistantType ?? this.assistantType,
      level: level ?? this.level,
      xp: xp ?? this.xp,
      coins: coins ?? this.coins,
      akylPoints: akylPoints ?? this.akylPoints,
      currentStreak: currentStreak ?? this.currentStreak,
      longestStreak: longestStreak ?? this.longestStreak,
      lastLoginDate: lastLoginDate ?? this.lastLoginDate,
      totalTasksCompleted: totalTasksCompleted ?? this.totalTasksCompleted,
      totalBattlesWon: totalBattlesWon ?? this.totalBattlesWon,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
