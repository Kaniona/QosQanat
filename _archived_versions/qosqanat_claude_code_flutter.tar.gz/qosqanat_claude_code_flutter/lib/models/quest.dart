/// A daily mission / quest that drives daily engagement.
class Quest {
  const Quest({
    required this.id,
    required this.title,
    this.description,
    required this.targetProgress,
    this.currentProgress = 0,
    this.xpReward = 0,
    this.coinReward = 0,
    this.isClaimed = false,
    this.iconName,
  });

  final String id;
  final String title;
  final String? description;

  /// How many units complete the quest (e.g. 3 lessons).
  final int targetProgress;
  final int currentProgress;

  final int xpReward;
  final int coinReward;

  /// Whether the reward has already been collected.
  final bool isClaimed;

  /// Optional icon identifier for the UI.
  final String? iconName;

  bool get isCompleted => currentProgress >= targetProgress;

  double get progressFraction =>
      targetProgress == 0 ? 0 : (currentProgress / targetProgress).clamp(0, 1);

  factory Quest.fromJson(Map<String, dynamic> json) {
    return Quest(
      id: json['id'] as String,
      title: json['title'] as String? ?? '',
      description: json['description'] as String?,
      targetProgress: (json['target_progress'] as num?)?.toInt() ?? 1,
      currentProgress: (json['current_progress'] as num?)?.toInt() ?? 0,
      xpReward: (json['xp_reward'] as num?)?.toInt() ?? 0,
      coinReward: (json['coin_reward'] as num?)?.toInt() ?? 0,
      isClaimed: json['is_claimed'] as bool? ?? false,
      iconName: json['icon_name'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'target_progress': targetProgress,
      'current_progress': currentProgress,
      'xp_reward': xpReward,
      'coin_reward': coinReward,
      'is_claimed': isClaimed,
      'icon_name': iconName,
    };
  }

  Quest copyWith({
    String? id,
    String? title,
    String? description,
    int? targetProgress,
    int? currentProgress,
    int? xpReward,
    int? coinReward,
    bool? isClaimed,
    String? iconName,
  }) {
    return Quest(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      targetProgress: targetProgress ?? this.targetProgress,
      currentProgress: currentProgress ?? this.currentProgress,
      xpReward: xpReward ?? this.xpReward,
      coinReward: coinReward ?? this.coinReward,
      isClaimed: isClaimed ?? this.isClaimed,
      iconName: iconName ?? this.iconName,
    );
  }
}
