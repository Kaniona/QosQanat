import 'enums.dart';

/// A public view of another student, as returned by the cross-user SECURITY
/// DEFINER reads. Only non-sensitive fields are exposed.
class PublicProfile {
  const PublicProfile({
    required this.id,
    required this.qosqanatId,
    required this.fullName,
    required this.level,
    required this.akylPoints,
    required this.assistantType,
    this.city,
    this.school,
    this.isOnline = false,
  });

  final String id;
  final String qosqanatId;
  final String fullName;
  final int level;
  final int akylPoints;
  final AssistantType assistantType;
  final String? city;
  final String? school;
  final bool isOnline;

  factory PublicProfile.fromJson(Map<String, dynamic> json) {
    return PublicProfile(
      id: json['id'] as String,
      qosqanatId: json['qosqanat_id'] as String? ?? '',
      fullName: json['full_name'] as String? ?? '',
      level: (json['level'] as num?)?.toInt() ?? 1,
      akylPoints: (json['akyl_points'] as num?)?.toInt() ?? 0,
      assistantType: AssistantType.fromJson(json['assistant_type'] as String?),
      city: json['city'] as String?,
      school: json['school'] as String?,
      isOnline: json['is_online'] as bool? ?? false,
    );
  }
}

/// A pending friend request, incoming or outgoing.
class FriendRequest {
  const FriendRequest({
    required this.id,
    required this.profile,
    required this.outgoing,
    required this.createdAt,
  });

  final String id;

  /// The other party (the sender for incoming, the recipient for outgoing).
  final PublicProfile profile;

  /// True when the signed-in user sent this request and is awaiting a reply.
  final bool outgoing;
  final DateTime createdAt;

  factory FriendRequest.fromJson(Map<String, dynamic> json) {
    return FriendRequest(
      id: json['id'] as String,
      profile: PublicProfile.fromJson(json),
      outgoing: json['outgoing'] as bool? ?? false,
      createdAt: DateTime.tryParse(json['created_at'] as String? ?? '') ??
          DateTime.now(),
    );
  }
}
