import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';

/// Animated XP progress bar toward the next level.
///
/// A gold level badge sits on the left; the fill is a gradient with a glowing
/// dot at its leading edge. [progress] is 0..1; optional [xpInto]/[xpNeeded]
/// render a "120 / 300 XP" label.
class XpBar extends StatelessWidget {
  const XpBar({
    super.key,
    required this.level,
    required this.progress,
    this.xpInto,
    this.xpNeeded,
    this.height = 16,
  });

  final int level;
  final double progress;
  final int? xpInto;
  final int? xpNeeded;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // Gold level badge.
        Container(
          width: 36,
          height: 36,
          alignment: Alignment.center,
          decoration: const BoxDecoration(
            gradient: AppColors.goldGradient,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(color: AppColors.shadow, blurRadius: 8, offset: Offset(0, 2)),
            ],
          ),
          child: Text(
            '$level',
            style: AppTypography.bodyLarge.copyWith(
              color: AppColors.ink,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        const SizedBox(width: AppSpacing.space3),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _Track(progress: progress.clamp(0, 1), height: height),
              if (xpInto != null && xpNeeded != null) ...[
                const SizedBox(height: 4),
                Text(
                  '$xpInto / $xpNeeded XP',
                  style: AppTypography.caption,
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _Track extends StatelessWidget {
  const _Track({required this.progress, required this.height});

  final double progress;
  final double height;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final maxW = constraints.maxWidth;
        return Container(
          height: height,
          decoration: BoxDecoration(
            color: AppColors.surfaceMuted,
            borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
            border: Border.all(color: AppColors.border),
          ),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: progress),
                duration: const Duration(milliseconds: 800),
                curve: Curves.easeOutCubic,
                builder: (context, value, _) {
                  final fillW = (maxW * value).clamp(0.0, maxW);
                  return Stack(
                    clipBehavior: Clip.none,
                    children: [
                      // Gradient fill.
                      Container(
                        width: fillW,
                        height: height,
                        decoration: BoxDecoration(
                          gradient: AppColors.bekturGradient,
                          borderRadius:
                              BorderRadius.circular(AppSpacing.radiusFull),
                        ),
                      ),
                      // Glowing leading dot.
                      if (value > 0.02)
                        Positioned(
                          left: fillW - height / 2,
                          top: -1,
                          child: Container(
                            width: height + 2,
                            height: height + 2,
                            decoration: BoxDecoration(
                              color: AppColors.white,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.primary.withValues(alpha: 0.8),
                                  blurRadius: 10,
                                  spreadRadius: 1,
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }
}
