import 'dart:async';

import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../data/levels.dart';
import '../ui/eagle_emblem.dart';
import '../ui/gradient_button.dart';

/// Shows the full-screen level-up celebration. Resolves when dismissed.
Future<void> showLevelUpModal(
  BuildContext context, {
  required int previousLevel,
  required int newLevel,
  required int coinReward,
}) {
  return showDialog<void>(
    context: context,
    barrierDismissible: false,
    barrierColor: AppColors.ink.withValues(alpha: 0.7),
    builder: (_) => _LevelUpDialog(
      previousLevel: previousLevel,
      newLevel: newLevel,
      coinReward: coinReward,
    ),
  );
}

class _LevelUpDialog extends StatefulWidget {
  const _LevelUpDialog({
    required this.previousLevel,
    required this.newLevel,
    required this.coinReward,
  });

  final int previousLevel;
  final int newLevel;
  final int coinReward;

  @override
  State<_LevelUpDialog> createState() => _LevelUpDialogState();
}

class _LevelUpDialogState extends State<_LevelUpDialog> {
  late final ConfettiController _confetti;

  @override
  void initState() {
    super.initState();
    _confetti = ConfettiController(duration: const Duration(seconds: 3))..play();
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.topCenter,
      children: [
        Center(
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.space6),
            child: Container(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.space6,
                AppSpacing.space8,
                AppSpacing.space6,
                AppSpacing.space6,
              ),
              decoration: BoxDecoration(
                gradient: AppColors.heroGradient,
                borderRadius: BorderRadius.circular(AppSpacing.radiusXl),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.gold.withValues(alpha: 0.4),
                    blurRadius: 40,
                    spreadRadius: 4,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'ЖАҢА ДЕҢГЕЙ!',
                    style: AppTypography.heading3.copyWith(
                      color: AppColors.gold,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.space5),
                  // Rotating emblem behind the transitioning level number.
                  SizedBox(
                    height: 150,
                    width: 150,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        const EagleEmblem(size: 150)
                            .animate(onPlay: (c) => c.repeat())
                            .rotate(duration: 8.seconds),
                        _LevelNumber(
                          previousLevel: widget.previousLevel,
                          newLevel: widget.newLevel,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.space5),
                  Text(
                    levelTitle(widget.newLevel),
                    textAlign: TextAlign.center,
                    style: AppTypography.heading1.copyWith(color: AppColors.white),
                  ).animate(delay: 700.ms).fadeIn().slideY(begin: 0.3, end: 0),
                  const SizedBox(height: AppSpacing.space4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppSpacing.space5,
                      vertical: AppSpacing.space2,
                    ),
                    decoration: BoxDecoration(
                      gradient: AppColors.goldGradient,
                      borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
                    ),
                    child: Text(
                      '💰 +${widget.coinReward}',
                      style: AppTypography.heading3.copyWith(color: AppColors.ink),
                    ),
                  ).animate(delay: 900.ms).scaleXY(
                        begin: 0.3,
                        end: 1,
                        curve: Curves.elasticOut,
                        duration: 700.ms,
                      ),
                  const SizedBox(height: AppSpacing.space6),
                  GradientButton(
                    label: 'Керемет! ✓',
                    gradient: AppColors.goldGradient,
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
            ),
          )
              .animate()
              .scaleXY(begin: 0.3, end: 1, curve: Curves.elasticOut, duration: 800.ms)
              .fadeIn(duration: 250.ms),
        ),
        ConfettiWidget(
          confettiController: _confetti,
          blastDirectionality: BlastDirectionality.explosive,
          numberOfParticles: 30,
          gravity: 0.22,
          shouldLoop: false,
          colors: const [
            AppColors.gold,
            AppColors.primary,
            AppColors.secondary,
            AppColors.success,
          ],
        ),
      ],
    );
  }
}

/// Shows the previous level for a beat, then pops to the new level in glowing
/// gold.
class _LevelNumber extends StatefulWidget {
  const _LevelNumber({required this.previousLevel, required this.newLevel});

  final int previousLevel;
  final int newLevel;

  @override
  State<_LevelNumber> createState() => _LevelNumberState();
}

class _LevelNumberState extends State<_LevelNumber> {
  bool _showNew = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer(const Duration(milliseconds: 550), () {
      if (mounted) setState(() => _showNew = true);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final value = _showNew ? widget.newLevel : widget.previousLevel;
    final color = _showNew ? AppColors.gold : AppColors.white;

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 350),
      transitionBuilder: (child, anim) =>
          ScaleTransition(scale: anim, child: FadeTransition(opacity: anim, child: child)),
      child: Text(
        '$value',
        key: ValueKey(value),
        style: AppTypography.displayHuge.copyWith(
          color: color,
          shadows: _showNew
              ? [const Shadow(color: AppColors.gold, blurRadius: 28)]
              : null,
        ),
      ),
    );
  }
}
