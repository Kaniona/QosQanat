import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';

/// The three reward currencies a toast can announce.
enum RewardKind { xp, coins, akyl }

extension on RewardKind {
  Color get color {
    switch (this) {
      case RewardKind.xp:
        return AppColors.success;
      case RewardKind.coins:
        return AppColors.goldDeep;
      case RewardKind.akyl:
        return AppColors.secondary;
    }
  }

  String get suffix {
    switch (this) {
      case RewardKind.xp:
        return '⚡';
      case RewardKind.coins:
        return '💰';
      case RewardKind.akyl:
        return '🧠';
    }
  }
}

/// Floats a small reward (e.g. "+50 ⚡") upward and fades it out, then removes
/// itself from the overlay. Color-coded by [kind].
void showRewardToast(
  BuildContext context, {
  required int amount,
  required RewardKind kind,
  double topOffset = 120,
}) {
  final overlay = Overlay.of(context);
  late OverlayEntry entry;
  entry = OverlayEntry(
    builder: (_) => _RewardToast(
      amount: amount,
      kind: kind,
      topOffset: topOffset,
      onDone: () => entry.remove(),
    ),
  );
  overlay.insert(entry);
}

class _RewardToast extends StatefulWidget {
  const _RewardToast({
    required this.amount,
    required this.kind,
    required this.topOffset,
    required this.onDone,
  });

  final int amount;
  final RewardKind kind;
  final double topOffset;
  final VoidCallback onDone;

  @override
  State<_RewardToast> createState() => _RewardToastState();
}

class _RewardToastState extends State<_RewardToast>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _rise;
  late final Animation<double> _opacity;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );
    _rise = Tween<double>(begin: 0, end: -48)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _scale = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween(begin: 0.6, end: 1.1)
            .chain(CurveTween(curve: Curves.easeOutBack)),
        weight: 30,
      ),
      TweenSequenceItem(tween: ConstantTween(1.1), weight: 40),
      TweenSequenceItem(tween: Tween(begin: 1.1, end: 1.0), weight: 30),
    ]).animate(_controller);
    _opacity = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0), weight: 20),
      TweenSequenceItem(tween: ConstantTween(1.0), weight: 45),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0), weight: 35),
    ]).animate(_controller);

    _controller.forward().whenComplete(widget.onDone);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: widget.topOffset,
      left: 0,
      right: 0,
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, _) => Opacity(
            opacity: _opacity.value,
            child: Transform.translate(
              offset: Offset(0, _rise.value),
              child: Transform.scale(scale: _scale.value, child: _chip()),
            ),
          ),
        ),
      ),
    );
  }

  Widget _chip() {
    final color = widget.kind.color;
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.space4,
          vertical: AppSpacing.space2,
        ),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(AppSpacing.radiusFull),
          border: Border.all(color: color, width: 2),
          boxShadow: [
            BoxShadow(color: color.withValues(alpha: 0.35), blurRadius: 12),
          ],
        ),
        child: Text(
          '+${widget.amount} ${widget.kind.suffix}',
          style: AppTypography.button.copyWith(color: color),
        ),
      ),
    );
  }
}
