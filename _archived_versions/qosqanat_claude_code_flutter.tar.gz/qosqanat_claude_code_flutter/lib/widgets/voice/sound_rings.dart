import 'package:flutter/material.dart';

/// Concentric rings that continuously expand and fade outward from the center,
/// like sound emanating from the assistant. Used around the character while it
/// listens and while it speaks.
class SoundRings extends StatefulWidget {
  const SoundRings({
    super.key,
    required this.color,
    this.size = 300,
    this.ringCount = 3,
  });

  final Color color;
  final double size;
  final int ringCount;

  @override
  State<SoundRings> createState() => _SoundRingsState();
}

class _SoundRingsState extends State<SoundRings>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2400),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Stack(
          alignment: Alignment.center,
          children: [
            for (var i = 0; i < widget.ringCount; i++)
              _ring((_controller.value + i / widget.ringCount) % 1.0),
          ],
        );
      },
    );
  }

  Widget _ring(double t) {
    final diameter = widget.size * (0.45 + 0.55 * t);
    return Container(
      width: diameter,
      height: diameter,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: widget.color.withValues(alpha: 0.45 * (1 - t)),
          width: 2.5,
        ),
      ),
    );
  }
}
