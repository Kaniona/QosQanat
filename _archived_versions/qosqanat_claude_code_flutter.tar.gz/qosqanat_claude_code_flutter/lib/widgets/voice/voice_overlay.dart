import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/voice_commands.dart';
import '../../core/constants/voice_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../core/theme/assistant_theme.dart';
import '../../models/enums.dart';
import '../../navigation/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/game_provider.dart';
import '../../providers/rating_provider.dart';
import '../../providers/shop_provider.dart';
import '../../services/voice_service.dart';
import '../avatar/avatar_display.dart';
import 'sound_rings.dart';
import 'speech_bubble.dart';
import 'voice_hint_card.dart';
import 'voice_waveform.dart';

/// Presents the full-screen voice assistant over a dimmed, blurred backdrop.
Future<void> showVoiceOverlay(BuildContext context) {
  return showGeneralDialog<void>(
    context: context,
    barrierDismissible: false,
    barrierColor: Colors.transparent,
    barrierLabel: 'voice',
    transitionDuration: const Duration(milliseconds: 250),
    pageBuilder: (_, _, _) => const VoiceOverlay(),
    transitionBuilder: (_, anim, _, child) =>
        FadeTransition(opacity: anim, child: child),
  );
}

/// The conversation phase the overlay is in.
enum _Phase { starting, listening, recognized, responding }

/// The voice assistant overlay: the chosen character listens, shows what it
/// heard, then speaks its answer — driving navigation, info answers, or app
/// launches based on the parsed command.
class VoiceOverlay extends ConsumerStatefulWidget {
  const VoiceOverlay({super.key});

  @override
  ConsumerState<VoiceOverlay> createState() => _VoiceOverlayState();
}

class _VoiceOverlayState extends ConsumerState<VoiceOverlay> {
  final VoiceService _service = VoiceService();

  _Phase _phase = _Phase.starting;
  String _partial = '';
  String _bubble = '';
  double _level = 0;
  bool _closing = false;

  GoRouter? _router;
  NavigatorState? _navigator;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _begin());
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _router = GoRouter.of(context);
    _navigator = Navigator.of(context, rootNavigator: true);
  }

  @override
  void dispose() {
    _service.dispose();
    super.dispose();
  }

  AssistantType get _assistant =>
      ref.read(authProvider).user?.assistantType ?? AssistantType.bektur;

  Future<void> _begin() async {
    final available = await _service.init();
    if (!mounted) return;
    if (!available) {
      await _showPermissionDialog();
      _close();
      return;
    }
    _listen();
  }

  Future<void> _listen() async {
    await _service.stopSpeaking();
    if (!mounted) return;
    setState(() {
      _phase = _Phase.listening;
      _partial = '';
      _bubble = '';
      _level = 0;
    });
    await _service.startListening(
      onResult: (t) {
        if (mounted) setState(() => _partial = t);
      },
      onFinal: _onFinal,
      onLevel: (lvl) {
        if (mounted) setState(() => _level = (lvl / 10).clamp(0, 1));
      },
    );
  }

  Future<void> _onFinal(String text) async {
    if (!mounted || _closing) return;
    if (text.trim().isEmpty) {
      _listen();
      return;
    }
    setState(() {
      _phase = _Phase.recognized;
      _bubble = text;
      _partial = text;
    });
    await Future<void>.delayed(const Duration(milliseconds: 350));
    if (!mounted) return;
    await _execute(_service.parse(text));
  }

  Future<void> _execute(VoiceIntent intent) async {
    final assistant = _assistant;
    switch (intent.type) {
      case VoiceIntentType.navigate:
        final (route, confirm) = _navInfo(intent.nav!);
        await _respond(confirm, assistant);
        _goTo(route);
      case VoiceIntentType.info:
        await _respond(await _infoResponse(intent.info!), assistant);
      case VoiceIntentType.externalApp:
        await _respond(VoiceStrings.openingApp(_appName(intent.app!)), assistant);
        final ok = await _service.launchExternal(intent.app!);
        if (!ok && mounted) await _respond(VoiceStrings.launchFailed, assistant);
      case VoiceIntentType.aiQuery:
        final reply = await _service.aiRespond(intent.rawText, assistant);
        await _respond(reply, assistant);
    }
  }

  Future<void> _respond(String text, AssistantType assistant) async {
    if (!mounted) return;
    setState(() {
      _phase = _Phase.responding;
      _bubble = text;
    });
    await _service.speak(text, assistant);
  }

  Future<String> _infoResponse(InfoQuery query) async {
    final game = ref.read(gameProvider);
    var rank = ref.read(ratingProvider).myEntry?.rank;
    if (query == InfoQuery.akyl && rank == null) {
      await ref.read(ratingProvider.notifier).load();
      rank = ref.read(ratingProvider).myEntry?.rank;
    }
    return infoResponse(
      query,
      level: game.level,
      coins: game.coins,
      akyl: game.akylPoints,
      rank: rank ?? 1,
      streak: game.streak,
    );
  }

  (String, String) _navInfo(NavTarget target) {
    switch (target) {
      case NavTarget.home:
        return (AppRoutes.home, VoiceStrings.openingHome);
      case NavTarget.learn:
        return (AppRoutes.learn, VoiceStrings.openingLearn);
      case NavTarget.shop:
        return (AppRoutes.shop, VoiceStrings.openingShop);
      case NavTarget.friends:
        return (AppRoutes.friends, VoiceStrings.openingFriends);
      case NavTarget.rating:
        return (AppRoutes.rating, VoiceStrings.openingRating);
      case NavTarget.profile:
        return (AppRoutes.profile, VoiceStrings.openingProfile);
    }
  }

  String _appName(ExternalApp app) {
    switch (app) {
      case ExternalApp.youtube:
        return 'YouTube';
      case ExternalApp.whatsapp:
        return 'WhatsApp';
      case ExternalApp.instagram:
        return 'Instagram';
      case ExternalApp.tiktok:
        return 'TikTok';
      case ExternalApp.telegram:
        return 'Telegram';
      case ExternalApp.calculator:
        return 'Калькулятор';
    }
  }

  Future<void> _goTo(String route) async {
    if (_closing) return;
    _closing = true;
    await _service.stopListening();
    _navigator?.pop();
    _router?.go(route);
  }

  void _close() {
    if (_closing) return;
    _closing = true;
    _service.stopListening();
    _navigator?.pop();
  }

  Future<void> _showPermissionDialog() async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(VoiceStrings.permissionTitle, style: AppTypography.heading3),
        content: Text(VoiceStrings.permissionBody, style: AppTypography.body),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(VoiceStrings.permissionOk, style: AppTypography.button),
          ),
        ],
      ),
    );
  }

  void _onMicTap() {
    if (_phase == _Phase.listening) {
      _service.stopListening();
    } else {
      _listen();
    }
  }

  AvatarAnimationState get _avatarState {
    switch (_phase) {
      case _Phase.responding:
        return AvatarAnimationState.wave;
      case _Phase.listening:
        return AvatarAnimationState.thinking;
      case _Phase.recognized:
      case _Phase.starting:
        return AvatarAnimationState.idle;
    }
  }

  @override
  Widget build(BuildContext context) {
    final accent = _assistant.accent;
    final equipped = ref.watch(equippedSlotsProvider);
    final showBubble = _bubble.isNotEmpty &&
        (_phase == _Phase.recognized || _phase == _Phase.responding);

    return Stack(
      children: [
        // Dimmed + blurred backdrop showing the app faintly behind.
        Positioned.fill(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
            child: Container(color: AppColors.ink.withValues(alpha: 0.62)),
          ),
        ),
        SafeArea(
          child: Column(
            children: [
              // Close button.
              Align(
                alignment: Alignment.topRight,
                child: Padding(
                  padding: const EdgeInsets.all(AppSpacing.space4),
                  child: _CircleIcon(icon: Icons.close_rounded, onTap: _close),
                ),
              ),
              // Speech bubble above the character.
              SizedBox(
                height: 150,
                child: Center(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 250),
                    child: showBubble
                        ? SpeechBubble(
                            key: ValueKey(_bubble),
                            text: _bubble,
                            emphasized: _phase == _Phase.responding,
                          )
                        : const SizedBox.shrink(),
                  ),
                ),
              ),
              // The character with aura + rings.
              SizedBox(
                width: 300,
                height: 300,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    if (_phase == _Phase.listening || _phase == _Phase.responding)
                      SoundRings(color: accent, size: 300),
                    Container(
                      width: 250,
                      height: 250,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            accent.withValues(alpha: 0.45),
                            accent.withValues(alpha: 0),
                          ],
                        ),
                      ),
                    ),
                    AvatarDisplay(
                      type: _assistant,
                      equipped: equipped,
                      state: _avatarState,
                      size: 250,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.space4),
              Expanded(child: _StatusArea(
                phase: _phase,
                partial: _partial,
                accent: accent,
                level: _level,
              )),
              // Mic control.
              Padding(
                padding: const EdgeInsets.only(bottom: AppSpacing.space6),
                child: _MicButton(
                  listening: _phase == _Phase.listening,
                  gradient: _assistant.gradient,
                  glow: accent,
                  onTap: _onMicTap,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// The text + waveform + hints area beneath the character, which varies by phase.
class _StatusArea extends StatelessWidget {
  const _StatusArea({
    required this.phase,
    required this.partial,
    required this.accent,
    required this.level,
  });

  final _Phase phase;
  final String partial;
  final Color accent;
  final double level;

  @override
  Widget build(BuildContext context) {
    if (phase == _Phase.listening) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.space6),
        child: Column(
          children: [
            Text(
              VoiceStrings.listening,
              textAlign: TextAlign.center,
              style: AppTypography.heading3.copyWith(color: AppColors.white),
            ),
            const SizedBox(height: AppSpacing.space3),
            VoiceWaveform(color: accent, level: level),
            if (partial.isNotEmpty) ...[
              const SizedBox(height: AppSpacing.space3),
              Text(
                partial,
                textAlign: TextAlign.center,
                style: AppTypography.body.copyWith(
                  color: AppColors.white.withValues(alpha: 0.8),
                ),
              ),
            ],
            const Spacer(),
            const VoiceHintCard(onDark: true),
            const SizedBox(height: AppSpacing.space4),
          ],
        ),
      );
    }

    final label =
        phase == _Phase.recognized ? VoiceStrings.thinking : '';
    return Center(
      child: Text(
        label,
        style: AppTypography.body.copyWith(
          color: AppColors.white.withValues(alpha: 0.8),
        ),
      ),
    );
  }
}

class _MicButton extends StatelessWidget {
  const _MicButton({
    required this.listening,
    required this.gradient,
    required this.glow,
    required this.onTap,
  });

  final bool listening;
  final Gradient gradient;
  final Color glow;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 72,
        height: 72,
        decoration: BoxDecoration(
          gradient: gradient,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(color: glow.withValues(alpha: 0.6), blurRadius: 22, spreadRadius: 2),
          ],
        ),
        child: Icon(
          listening ? Icons.stop_rounded : Icons.mic_rounded,
          color: AppColors.white,
          size: 34,
        ),
      ),
    );
  }
}

class _CircleIcon extends StatelessWidget {
  const _CircleIcon({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 40,
        height: 40,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: AppColors.white.withValues(alpha: 0.18),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: AppColors.white, size: 22),
      ),
    );
  }
}
