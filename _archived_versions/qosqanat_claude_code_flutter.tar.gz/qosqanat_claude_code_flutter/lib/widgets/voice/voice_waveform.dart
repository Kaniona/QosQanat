import 'dart:math' as math;

import 'package:flutter/material.dart';

/// An animated row of bars that pulse like a live voice waveform. Bars sway on
/// their own clock and swell with [level] (0..1), the live microphone loudness,
/// so the assistant visibly reacts to the student's voice.
class VoiceWaveform extends StatefulWidget {
  const VoiceWaveform({
    super.key,
    required this.color,
    this.level = 0,
    this.barCount = 7,
  });

  final Color color;
  final double level;
  final int barCount;

  @override
  State<VoiceWaveform> createState() => _VoiceWaveformState();
}

class _VoiceWaveformState extends State<VoiceWaveform>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1100),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final t = _controller.value * 2 * math.pi;
        final amp = 0.35 + 0.65 * widget.level.clamp(0, 1);
        return Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            for (var i = 0; i < widget.barCount; i++)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: _Bar(
                  height: 10 + 34 * amp * (0.5 + 0.5 * math.sin(t + i * 0.7)).abs(),
                  color: widget.color,
                ),
              ),
          ],
        );
      },
    );
  }
}

class _Bar extends StatelessWidget {
  const _Bar({required this.height, required this.color});

  final double height;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 90),
      width: 6,
      height: height,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(3),
      ),
    );
  }
}
