import 'package:flutter/material.dart';

import '../../core/constants/voice_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';

/// "Менен сұра:" — a compact discovery card listing example voice commands
/// grouped by category so students learn what they can say. Used inside the
/// voice overlay (and reusable on Home).
class VoiceHintCard extends StatelessWidget {
  const VoiceHintCard({super.key, this.onDark = false});

  /// When shown over the dimmed overlay, use light-on-dark styling.
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    final fg = onDark ? AppColors.white : AppColors.ink;
    final subFg =
        onDark ? AppColors.white.withValues(alpha: 0.85) : AppColors.textSecondary;

    return Container(
      padding: const EdgeInsets.all(AppSpacing.space4),
      decoration: BoxDecoration(
        color: onDark
            ? AppColors.white.withValues(alpha: 0.12)
            : AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        border: onDark
            ? Border.all(color: AppColors.white.withValues(alpha: 0.25))
            : null,
        boxShadow: onDark
            ? null
            : const [
                BoxShadow(color: AppColors.shadow, blurRadius: 12, offset: Offset(0, 4)),
              ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            VoiceStrings.hintTitle,
            style: AppTypography.button.copyWith(color: fg),
          ),
          const SizedBox(height: AppSpacing.space2),
          _line(VoiceStrings.hintNav, subFg),
          _line(VoiceStrings.hintInfo, subFg),
          _line(VoiceStrings.hintApps, subFg),
        ],
      ),
    );
  }

  Widget _line(String text, Color color) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(
        text,
        style: AppTypography.bodySmall.copyWith(color: color),
      ),
    );
  }
}
