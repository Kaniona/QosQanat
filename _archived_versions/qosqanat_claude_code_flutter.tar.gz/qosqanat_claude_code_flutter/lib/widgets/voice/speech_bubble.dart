import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';

/// A rounded speech bubble with a small downward tail, used to show the captured
/// command or the assistant's spoken reply above the character.
class SpeechBubble extends StatelessWidget {
  const SpeechBubble({
    super.key,
    required this.text,
    this.emphasized = false,
  });

  final String text;

  /// When true (the assistant's reply) the bubble uses the brand color; when
  /// false (the recognized command) it uses a neutral white card.
  final bool emphasized;

  @override
  Widget build(BuildContext context) {
    final bg = emphasized ? AppColors.primary : AppColors.white;
    final fg = emphasized ? AppColors.white : AppColors.ink;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          constraints: const BoxConstraints(maxWidth: 300),
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.space5,
            vertical: AppSpacing.space4,
          ),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
            boxShadow: const [
              BoxShadow(color: AppColors.shadow, blurRadius: 20, offset: Offset(0, 8)),
            ],
          ),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: AppTypography.bodyLarge.copyWith(
              color: fg,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        // Downward tail.
        CustomPaint(
          size: const Size(20, 10),
          painter: _TailPainter(color: bg),
        ),
      ],
    );
  }
}

class _TailPainter extends CustomPainter {
  _TailPainter({required this.color});

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _TailPainter oldDelegate) =>
      oldDelegate.color != color;
}
