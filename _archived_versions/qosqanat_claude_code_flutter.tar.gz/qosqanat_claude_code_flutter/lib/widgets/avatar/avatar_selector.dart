import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../models/enums.dart';
import 'avatar_display.dart';

/// Reusable side-by-side picker for the two assistants.
///
/// Handles the selected/unselected visuals (lift + gold glow / dim + shrink).
/// The selected character waves; the others idle. Reused on onboarding and a
/// future "change assistant" settings screen.
class AvatarSelector extends StatelessWidget {
  const AvatarSelector({
    super.key,
    required this.selected,
    required this.onChanged,
    this.avatarSize = 120,
  });

  final AssistantType? selected;
  final ValueChanged<AssistantType> onChanged;
  final double avatarSize;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          child: _SelectableAvatar(
            type: AssistantType.bektur,
            name: 'Бектұр',
            selected: selected == AssistantType.bektur,
            dimmed: selected == AssistantType.nazym,
            avatarSize: avatarSize,
            onTap: () => onChanged(AssistantType.bektur),
          ),
        ),
        const SizedBox(width: AppSpacing.space4),
        Expanded(
          child: _SelectableAvatar(
            type: AssistantType.nazym,
            name: 'Назым',
            selected: selected == AssistantType.nazym,
            dimmed: selected == AssistantType.bektur,
            avatarSize: avatarSize,
            onTap: () => onChanged(AssistantType.nazym),
          ),
        ),
      ],
    );
  }
}

class _SelectableAvatar extends StatelessWidget {
  const _SelectableAvatar({
    required this.type,
    required this.name,
    required this.selected,
    required this.dimmed,
    required this.avatarSize,
    required this.onTap,
  });

  final AssistantType type;
  final String name;
  final bool selected;
  final bool dimmed;
  final double avatarSize;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final accent = type == AssistantType.bektur
        ? AppColors.bekturBlue
        : AppColors.nazymPink;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 300),
        opacity: dimmed ? 0.6 : 1,
        child: AnimatedScale(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
          scale: selected ? 1.05 : (dimmed ? 0.95 : 1.0),
          child: Container(
            padding: const EdgeInsets.all(AppSpacing.space4),
            decoration: BoxDecoration(
              color: AppColors.white.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(AppSpacing.radiusXl),
              border: Border.all(
                color: selected ? AppColors.gold : Colors.white24,
                width: selected ? 3 : 1,
              ),
              boxShadow: selected
                  ? [
                      BoxShadow(
                        color: AppColors.gold.withValues(alpha: 0.55),
                        blurRadius: 28,
                        spreadRadius: 2,
                      ),
                    ]
                  : null,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AvatarDisplay(
                  type: type,
                  size: avatarSize,
                  state: selected
                      ? AvatarAnimationState.wave
                      : AvatarAnimationState.idle,
                ),
                const SizedBox(height: AppSpacing.space2),
                Text(
                  name,
                  style:
                      AppTypography.heading3.copyWith(color: AppColors.white),
                ),
                Text(
                  type == AssistantType.bektur ? 'Қайратты' : 'Мейірімді',
                  style: AppTypography.caption.copyWith(color: accent),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
