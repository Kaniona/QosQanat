import 'avatar_base.dart';

/// Cosmetic art for shop items, keyed by the same item ids the shop catalog
/// uses. The avatar consults this so equipping an item visibly changes the
/// character. Unknown ids return null and the avatar keeps its default look.
///
/// Each renderer returns a full `<svg viewBox='0 0 200 200'>` string drawn in
/// the avatar's coordinate space, so items land in the right place on the body.

String _svg(String inner) =>
    "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'>$inner</svg>";

/// A cosmetic descriptor: which body slot it occupies, a render [style], and a
/// primary [color].
class Cosmetic {
  const Cosmetic(this.slot, this.style, this.color, {this.accent = '#FFFFFF'});
  final AvatarSlot slot;
  final String style;
  final String color;
  final String accent;
}

/// The cosmetic registry. Ids match `lib/data/shop_items.dart`.
const Map<String, Cosmetic> kCosmetics = {
  // ── Tops (replace the shirt) ──
  'top_school': Cosmetic(AvatarSlot.top, 'jacket', '#4A6CF7', accent: '#2A2F5B'),
  'top_hoodie_red': Cosmetic(AvatarSlot.top, 'hoodie', '#FF4757'),
  'top_hoodie_blue': Cosmetic(AvatarSlot.top, 'hoodie', '#4A6CF7'),
  'top_hoodie_green': Cosmetic(AvatarSlot.top, 'hoodie', '#00C48C'),
  'top_leather': Cosmetic(AvatarSlot.top, 'jacket', '#3A3340', accent: '#22202A'),
  'top_chapan': Cosmetic(AvatarSlot.top, 'chapan', '#1F7A5A', accent: '#FFD700'),
  'top_sweatshirt': Cosmetic(AvatarSlot.top, 'hoodie', '#FFA502'),
  'top_astronaut': Cosmetic(AvatarSlot.top, 'suit', '#EDEFF7', accent: '#4A6CF7'),
  'top_robot': Cosmetic(AvatarSlot.top, 'armor', '#9AA7C7', accent: '#22D3EE'),
  'top_hoodie_yellow': Cosmetic(AvatarSlot.top, 'hoodie', '#FFD000'),
  'top_hoodie_black': Cosmetic(AvatarSlot.top, 'hoodie', '#22202A'),
  'top_tee_white': Cosmetic(AvatarSlot.top, 'tee', '#F2F4FF', accent: '#4A6CF7'),
  'top_denim': Cosmetic(AvatarSlot.top, 'jacket', '#5B7FB0', accent: '#3A567E'),
  'top_varsity': Cosmetic(AvatarSlot.top, 'jacket', '#8B2E3C', accent: '#FFD700'),

  // ── Bottoms (replace the pants) ──
  'bottom_school': Cosmetic(AvatarSlot.bottom, 'pants', '#2A2F5B'),
  'bottom_jeans': Cosmetic(AvatarSlot.bottom, 'pants', '#3F6CA6'),
  'bottom_sport': Cosmetic(AvatarSlot.bottom, 'pants', '#22264A', accent: '#FFFFFF'),
  'bottom_trad': Cosmetic(AvatarSlot.bottom, 'pants', '#7A3B2E', accent: '#FFD700'),
  'bottom_shorts': Cosmetic(AvatarSlot.bottom, 'pants', '#2FA37A'),
  'bottom_cargo': Cosmetic(AvatarSlot.bottom, 'pants', '#5A5A3A', accent: '#2A2A1A'),
  'bottom_classic': Cosmetic(AvatarSlot.bottom, 'pants', '#22202A'),

  // ── Hats ──
  'hat_cap': Cosmetic(AvatarSlot.hat, 'cap', '#FF4757'),
  'hat_takia': Cosmetic(AvatarSlot.hat, 'takia', '#1F7A5A', accent: '#FFD700'),
  'hat_tophat': Cosmetic(AvatarSlot.hat, 'tophat', '#22202A'),
  'hat_crown': Cosmetic(AvatarSlot.hat, 'crown', '#FFD700', accent: '#FF4757'),
  'hat_winter': Cosmetic(AvatarSlot.hat, 'beanie', '#4A6CF7', accent: '#FFFFFF'),
  'hat_panama': Cosmetic(AvatarSlot.hat, 'cap', '#EAD9A0'),
  'hat_wizard': Cosmetic(AvatarSlot.hat, 'wizard', '#5B41E0', accent: '#FFD700'),

  // ── Accessories (face slot, art positions itself) ──
  'acc_chain': Cosmetic(AvatarSlot.faceAccessory, 'chain', '#FFD700'),
  'acc_bracelet': Cosmetic(AvatarSlot.faceAccessory, 'bracelet', '#FFD700'),
  'acc_backpack': Cosmetic(AvatarSlot.faceAccessory, 'backpack', '#7B61FF'),
  'acc_vr': Cosmetic(AvatarSlot.faceAccessory, 'vr', '#22202A', accent: '#22D3EE'),
  'acc_silver_chain': Cosmetic(AvatarSlot.faceAccessory, 'chain', '#C0C0C8'),
  'acc_watch': Cosmetic(AvatarSlot.faceAccessory, 'bracelet', '#22202A'),
  'acc_glasses': Cosmetic(AvatarSlot.faceAccessory, 'glasses', '#22202A'),
  'acc_scarf': Cosmetic(AvatarSlot.faceAccessory, 'scarf', '#FF4757'),
  'acc_headset': Cosmetic(AvatarSlot.faceAccessory, 'vr', '#22202A', accent: '#00C48C'),

  // ── Pets ──
  'pet_cat': Cosmetic(AvatarSlot.pet, 'cat', '#EDEFF7', accent: '#FF9DBF'),
  'pet_eagle': Cosmetic(AvatarSlot.pet, 'eagle', '#7A5B3A', accent: '#FFD700'),
  'pet_wolf': Cosmetic(AvatarSlot.pet, 'wolf', '#9AA7C7'),
  'pet_leopard': Cosmetic(AvatarSlot.pet, 'leopard', '#FFB23E', accent: '#22202A'),
  'pet_robot': Cosmetic(AvatarSlot.pet, 'robot', '#9AA7C7', accent: '#22D3EE'),
  'pet_dragon': Cosmetic(AvatarSlot.pet, 'dragon', '#7B61FF', accent: '#FF4757'),
  'pet_black_cat': Cosmetic(AvatarSlot.pet, 'cat', '#2A2730', accent: '#00C48C'),
  'pet_turtle': Cosmetic(AvatarSlot.pet, 'turtle', '#2FA37A', accent: '#1F5E45'),
  'pet_rabbit': Cosmetic(AvatarSlot.pet, 'rabbit', '#F2F4FF', accent: '#FF9DBF'),
  'pet_parrot': Cosmetic(AvatarSlot.pet, 'eagle', '#00C48C', accent: '#FFD700'),
};

/// Returns SVG art for an equipped item, or null to use the avatar's default.
String? cosmeticArt(AvatarSlot slot, String itemId) {
  final c = kCosmetics[itemId];
  if (c == null || c.slot != slot) return null;
  return switch (slot) {
    AvatarSlot.top => _topArt(c),
    AvatarSlot.bottom => _bottomArt(c),
    AvatarSlot.hat => _hatArt(c),
    AvatarSlot.faceAccessory => _accessoryArt(c),
    AvatarSlot.pet => _petArt(c),
    _ => null,
  };
}

// ── Tops ──────────────────────────────────────────────────────────────────

String _topArt(Cosmetic c) {
  final base = '''
<rect x='52' y='112' width='18' height='30' rx='9' fill='${c.color}'/>
<rect x='130' y='112' width='18' height='30' rx='9' fill='${c.color}'/>
<rect x='68' y='110' width='64' height='52' rx='22' fill='${c.color}'/>''';
  final extra = switch (c.style) {
    'hoodie' => '''
<path d='M82 110 Q100 96 118 110 Q108 116 100 116 Q92 116 82 110 Z' fill='${c.color}'/>
<rect x='98.5' y='120' width='3' height='36' fill='#00000022'/>
<circle cx='86' cy='150' r='5' fill='#00000022'/>''',
    'jacket' => '''
<path d='M88 110 L100 124 L112 110 Z' fill='#ffffff'/>
<rect x='98.5' y='118' width='3' height='40' rx='1.5' fill='${c.accent}'/>
<circle cx='100' cy='132' r='2' fill='#ffffff'/>
<circle cx='100' cy='144' r='2' fill='#ffffff'/>''',
    'chapan' => '''
<rect x='70' y='112' width='6' height='48' fill='${c.accent}'/>
<rect x='124' y='112' width='6' height='48' fill='${c.accent}'/>
<rect x='96' y='112' width='8' height='48' fill='${c.accent}'/>''',
    'suit' => '''
<circle cx='100' cy='134' r='13' fill='${c.accent}' opacity='0.85'/>
<circle cx='100' cy='134' r='8' fill='#ffffff'/>
<rect x='76' y='150' width='48' height='6' rx='3' fill='${c.accent}'/>''',
    'armor' => '''
<rect x='72' y='114' width='56' height='14' rx='4' fill='${c.accent}' opacity='0.5'/>
<rect x='74' y='134' width='52' height='12' rx='4' fill='#ffffff' opacity='0.25'/>
<circle cx='100' cy='124' r='5' fill='${c.accent}'/>''',
    'tee' => '''
<path d='M88 110 L100 122 L112 110 Z' fill='${c.accent}' opacity='0.5'/>''',
    _ => '',
  };
  return _svg('$base$extra');
}

// ── Bottoms ─────────────────────────────────────────────────────────────────

String _bottomArt(Cosmetic c) => _svg('''
<rect x='80' y='146' width='40' height='18' rx='8' fill='${c.color}'/>
<rect x='83' y='150' width='15' height='30' rx='6' fill='${c.color}'/>
<rect x='102' y='150' width='15' height='30' rx='6' fill='${c.color}'/>
${c.accent != '#FFFFFF' ? "<rect x='84' y='150' width='2' height='30' fill='${c.accent}'/><rect x='114' y='150' width='2' height='30' fill='${c.accent}'/>" : ''}
''');

// ── Hats ──────────────────────────────────────────────────────────────────

String _hatArt(Cosmetic c) {
  final inner = switch (c.style) {
    'cap' => '''
<path d='M66 44 Q100 20 134 44 Q134 50 100 50 Q66 50 66 44 Z' fill='${c.color}'/>
<path d='M120 46 Q150 48 150 56 Q132 54 120 50 Z' fill='${c.color}'/>''',
    'takia' => '''
<path d='M70 46 Q100 18 130 46 Z' fill='${c.color}'/>
<rect x='70' y='44' width='60' height='7' rx='3' fill='${c.accent}'/>
<path d='M85 40 l5 -8 5 8 z' fill='${c.accent}'/>''',
    'tophat' => '''
<rect x='80' y='14' width='40' height='30' rx='3' fill='${c.color}'/>
<rect x='66' y='42' width='68' height='8' rx='4' fill='${c.color}'/>
<rect x='80' y='34' width='40' height='6' fill='#FFD70088'/>''',
    'crown' => '''
<path d='M70 46 L78 24 L90 40 L100 20 L110 40 L122 24 L130 46 Z' fill='${c.color}'/>
<circle cx='100' cy='30' r='4' fill='${c.accent}'/>
<rect x='70' y='44' width='60' height='8' rx='3' fill='${c.color}'/>''',
    'beanie' => '''
<path d='M68 48 Q100 22 132 48 L132 52 Q100 56 68 52 Z' fill='${c.color}'/>
<rect x='66' y='48' width='68' height='8' rx='4' fill='${c.accent}'/>
<circle cx='100' cy='24' r='5' fill='${c.accent}'/>''',
    'wizard' => '''
<path d='M100 6 L122 50 Q100 56 78 50 Z' fill='${c.color}'/>
<path d='M64 50 Q100 42 136 50 Q100 60 64 50 Z' fill='${c.color}'/>
<path d='M100 22 l4 8 -8 0 z' fill='${c.accent}'/>
<circle cx='100' cy='12' r='3' fill='${c.accent}'/>''',
    _ => '',
  };
  return _svg(inner);
}

// ── Accessories ─────────────────────────────────────────────────────────────

String _accessoryArt(Cosmetic c) {
  final inner = switch (c.style) {
    'chain' => '''
<path d='M86 104 Q100 128 114 104' stroke='${c.color}' stroke-width='4' fill='none' stroke-linecap='round'/>
<circle cx='100' cy='122' r='5' fill='${c.color}'/>''',
    'bracelet' => "<circle cx='61' cy='158' r='10' fill='none' stroke='${c.color}' stroke-width='4'/>",
    'backpack' => '''
<rect x='60' y='112' width='8' height='40' rx='4' fill='${c.color}'/>
<rect x='132' y='112' width='8' height='40' rx='4' fill='${c.color}'/>''',
    'vr' => '''
<rect x='74' y='58' width='52' height='18' rx='6' fill='${c.color}'/>
<rect x='80' y='62' width='40' height='10' rx='4' fill='${c.accent}' opacity='0.8'/>''',
    'glasses' => '''
<circle cx='86' cy='66' r='9' fill='none' stroke='${c.color}' stroke-width='2.6'/>
<circle cx='114' cy='66' r='9' fill='none' stroke='${c.color}' stroke-width='2.6'/>
<line x1='95' y1='66' x2='105' y2='66' stroke='${c.color}' stroke-width='2.6'/>''',
    'scarf' => '''
<path d='M84 104 Q100 116 116 104 L116 112 Q100 122 84 112 Z' fill='${c.color}'/>
<rect x='108' y='110' width='10' height='22' rx='4' fill='${c.color}'/>''',
    _ => '',
  };
  return _svg(inner);
}

// ── Pets (drawn beside the character, bottom-left) ───────────────────────────

String _petArt(Cosmetic c) {
  final shadow = "<ellipse cx='40' cy='186' rx='20' ry='5' fill='#1A1A4E' opacity='0.1'/>";
  final eyes = '''
<circle cx='34' cy='166' r='2.6' fill='#1A1A4E'/>
<circle cx='46' cy='166' r='2.6' fill='#1A1A4E'/>''';
  final inner = switch (c.style) {
    'cat' => '''
<circle cx='40' cy='168' r='17' fill='${c.color}'/>
<path d='M28 156 l-2 -11 9 6 z' fill='${c.color}'/>
<path d='M52 156 l2 -11 -9 6 z' fill='${c.color}'/>
<circle cx='40' cy='174' r='2' fill='${c.accent}'/>$eyes''',
    'eagle' => '''
<circle cx='40' cy='168' r='16' fill='${c.color}'/>
<path d='M22 166 q-10 4 -4 12 q8 -2 10 -8 z' fill='${c.color}'/>
<path d='M58 166 q10 4 4 12 q-8 -2 -10 -8 z' fill='${c.color}'/>
<path d='M40 174 l-4 5 8 0 z' fill='${c.accent}'/>$eyes''',
    'wolf' => '''
<circle cx='40' cy='168' r='17' fill='${c.color}'/>
<path d='M27 155 l-2 -10 8 6 z' fill='${c.color}'/>
<path d='M53 155 l2 -10 -8 6 z' fill='${c.color}'/>
<path d='M40 176 l-4 4 8 0 z' fill='#1A1A4E'/>$eyes''',
    'leopard' => '''
<circle cx='40' cy='168' r='17' fill='${c.color}'/>
<circle cx='33' cy='164' r='2' fill='${c.accent}'/>
<circle cx='47' cy='170' r='2' fill='${c.accent}'/>
<circle cx='44' cy='160' r='1.6' fill='${c.accent}'/>$eyes''',
    'robot' => '''
<rect x='26' y='154' width='28' height='28' rx='6' fill='${c.color}'/>
<rect x='31' y='160' width='18' height='8' rx='2' fill='${c.accent}'/>
<rect x='38' y='148' width='4' height='8' fill='${c.color}'/>
<circle cx='40' cy='146' r='3' fill='${c.accent}'/>''',
    'dragon' => '''
<circle cx='40' cy='168' r='17' fill='${c.color}'/>
<path d='M26 154 l-3 -12 10 7 z' fill='${c.accent}'/>
<path d='M54 154 l3 -12 -10 7 z' fill='${c.accent}'/>
<path d='M58 170 q12 -2 14 6 q-10 2 -16 -2 z' fill='${c.accent}' opacity='0.8'/>$eyes''',
    'turtle' => '''
<ellipse cx='40' cy='172' rx='18' ry='12' fill='${c.accent}'/>
<ellipse cx='40' cy='170' rx='13' ry='8' fill='${c.color}'/>
<circle cx='56' cy='170' r='5' fill='${c.accent}'/>
<circle cx='26' cy='178' r='3' fill='${c.accent}'/>
<circle cx='54' cy='168' r='1.6' fill='#1A1A4E'/>''',
    'rabbit' => '''
<circle cx='40' cy='170' r='15' fill='${c.color}'/>
<ellipse cx='34' cy='150' rx='4' ry='12' fill='${c.color}'/>
<ellipse cx='46' cy='150' rx='4' ry='12' fill='${c.color}'/>
<ellipse cx='34' cy='150' rx='2' ry='8' fill='${c.accent}'/>
<ellipse cx='46' cy='150' rx='2' ry='8' fill='${c.accent}'/>
<circle cx='40' cy='174' r='2' fill='${c.accent}'/>$eyes''',
    _ => '',
  };
  return _svg('$shadow$inner');
}
