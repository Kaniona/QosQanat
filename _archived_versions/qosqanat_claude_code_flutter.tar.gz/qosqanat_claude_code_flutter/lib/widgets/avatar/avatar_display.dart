import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/widgets.dart';

import '../../models/enums.dart';
import 'avatar_base.dart';
import 'expressions.dart';

/// The motion states an avatar can play.
enum AvatarAnimationState { idle, celebrate, sad, wave, thinking }

/// Wraps [AvatarBase] and brings it to life with smooth, 60fps motion.
///
/// - [AvatarAnimationState.idle]: gentle continuous float + occasional blink
/// - [AvatarAnimationState.celebrate]: a springy jump (plays once)
/// - [AvatarAnimationState.sad]: a brief slump (plays once)
/// - [AvatarAnimationState.wave]: a friendly tilting greeting (loops)
/// - [AvatarAnimationState.thinking]: a slight head tilt + sway (loops)
class AvatarDisplay extends StatefulWidget {
  const AvatarDisplay({
    super.key,
    required this.type,
    this.state = AvatarAnimationState.idle,
    this.expression,
    this.equipped = const {},
    this.size = 160,
  });

  final AssistantType type;
  final AvatarAnimationState state;

  /// Overrides the expression implied by [state] when provided.
  final AvatarExpression? expression;
  final Map<AvatarSlot, String> equipped;
  final double size;

  @override
  State<AvatarDisplay> createState() => _AvatarDisplayState();
}

class _AvatarDisplayState extends State<AvatarDisplay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  Timer? _blinkTimer;
  bool _blinking = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this);
    _configure(widget.state);
    _scheduleBlink();
  }

  @override
  void didUpdateWidget(covariant AvatarDisplay oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.state != widget.state) _configure(widget.state);
  }

  /// Sets the duration + playback mode for [state].
  void _configure(AvatarAnimationState state) {
    switch (state) {
      case AvatarAnimationState.idle:
        _controller.duration = const Duration(seconds: 4);
        _controller.repeat();
      case AvatarAnimationState.wave:
        _controller.duration = const Duration(milliseconds: 1400);
        _controller.repeat();
      case AvatarAnimationState.thinking:
        _controller.duration = const Duration(seconds: 3);
        _controller.repeat();
      case AvatarAnimationState.celebrate:
        _controller.duration = const Duration(milliseconds: 900);
        _controller.forward(from: 0);
      case AvatarAnimationState.sad:
        _controller.duration = const Duration(milliseconds: 700);
        _controller.forward(from: 0);
    }
  }

  /// Blinks for ~130ms every few seconds while idle/waving.
  void _scheduleBlink() {
    _blinkTimer = Timer(
      Duration(milliseconds: 2600 + math.Random().nextInt(2600)),
      () async {
        if (!mounted) return;
        final canBlink = widget.state == AvatarAnimationState.idle ||
            widget.state == AvatarAnimationState.wave;
        if (canBlink) {
          setState(() => _blinking = true);
          await Future<void>.delayed(const Duration(milliseconds: 130));
          if (mounted) setState(() => _blinking = false);
        }
        _scheduleBlink();
      },
    );
  }

  @override
  void dispose() {
    _blinkTimer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  AvatarExpression get _expression {
    if (widget.expression != null) return widget.expression!;
    switch (widget.state) {
      case AvatarAnimationState.idle:
        return AvatarExpression.neutral;
      case AvatarAnimationState.celebrate:
        return AvatarExpression.celebrate;
      case AvatarAnimationState.sad:
        return AvatarExpression.sad;
      case AvatarAnimationState.wave:
        return AvatarExpression.happy;
      case AvatarAnimationState.thinking:
        return AvatarExpression.thinking;
    }
  }

  @override
  Widget build(BuildContext context) {
    final avatar = AvatarBase(
      type: widget.type,
      equipped: widget.equipped,
      expression: _expression,
      blink: _blinking,
      size: widget.size,
    );

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final t = _controller.value;
        var dy = 0.0;
        var scale = 1.0;
        var angle = 0.0;

        switch (widget.state) {
          case AvatarAnimationState.idle:
            dy = -4 * math.sin(t * 2 * math.pi);
          case AvatarAnimationState.wave:
            angle = 0.14 * math.sin(t * 2 * math.pi * 2);
            dy = -3 * math.sin(t * 2 * math.pi);
          case AvatarAnimationState.thinking:
            angle = 0.07 + 0.04 * math.sin(t * 2 * math.pi);
            dy = -2 * math.sin(t * 2 * math.pi);
          case AvatarAnimationState.celebrate:
            // Single hop with a damped landing bounce.
            dy = -46 * math.sin(math.pi * t);
            scale = 1 + 0.14 * math.sin(math.pi * t) +
                0.05 * math.sin(t * math.pi * 6) * (1 - t);
          case AvatarAnimationState.sad:
            dy = 9 * math.sin(math.pi * t);
            scale = 1 - 0.04 * math.sin(math.pi * t);
        }

        return Transform.translate(
          offset: Offset(0, dy),
          child: Transform.rotate(
            angle: angle,
            alignment: const Alignment(0, -0.4),
            child: Transform.scale(scale: scale, child: child),
          ),
        );
      },
      child: avatar,
    );
  }
}
