import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../models/enums.dart';
import 'cosmetics.dart';
import 'expressions.dart';

/// Independently-swappable layers of the avatar, listed back-to-front.
///
/// [pet] and [shadow] / [body] / [face] are intrinsic; the rest can be
/// overridden by equipped shop items. Equip slots map onto these.
enum AvatarSlot { pet, bottom, shoes, top, neck, hair, hat, faceAccessory }

/// All the colors that distinguish one assistant's look from another.
class AvatarPalette {
  const AvatarPalette({
    required this.skin,
    required this.skinShade,
    required this.hair,
    required this.top,
    required this.topShade,
    required this.bottom,
    required this.shoes,
    required this.cheek,
  });

  final String skin;
  final String skinShade;
  final String hair;
  final String top;
  final String topShade;
  final String bottom;
  final String shoes;
  final String cheek;

  static const AvatarPalette bektur = AvatarPalette(
    skin: '#EBB58B',
    skinShade: '#D89E72',
    hair: '#16131F',
    top: '#4A6CF7',
    topShade: '#3651D4',
    bottom: '#2A2F5B',
    shoes: '#22264A',
    cheek: '#F0907A',
  );

  static const AvatarPalette nazym = AvatarPalette(
    skin: '#F6D2B8',
    skinShade: '#E8BC9C',
    hair: '#1A1622',
    top: '#FF6B9D',
    topShade: '#E04A7E',
    bottom: '#9C3268',
    shoes: '#5B2140',
    cheek: '#FF9DBF',
  );

  static AvatarPalette of(AssistantType type) =>
      type == AssistantType.bektur ? bektur : nazym;
}

/// Composes an assistant character from layered SVGs in correct z-order.
///
/// Pass [equipped] to override individual slots with shop items (wired to the
/// shop catalog in a later task); empty means the default school uniform.
class AvatarBase extends StatelessWidget {
  const AvatarBase({
    super.key,
    required this.type,
    this.equipped = const {},
    this.expression = AvatarExpression.neutral,
    this.blink = false,
    this.size = 160,
  });

  final AssistantType type;
  final Map<AvatarSlot, String> equipped;
  final AvatarExpression expression;
  final bool blink;
  final double size;

  @override
  Widget build(BuildContext context) {
    final p = AvatarPalette.of(type);

    final layers = <String>[
      // pet sits beside the character (drawn into the same canvas, bottom-left)
      if (equipped.containsKey(AvatarSlot.pet))
        cosmeticArt(AvatarSlot.pet, equipped[AvatarSlot.pet]!) ?? _petSvg(p),
      _shadowSvg,
      _bodySvg(p),
      _resolve(AvatarSlot.bottom, _bottomSvg(p), p),
      _resolve(AvatarSlot.shoes, _shoesSvg(p), p),
      _resolve(AvatarSlot.top, _topSvg(p), p),
      if (equipped.containsKey(AvatarSlot.neck))
        _resolve(AvatarSlot.neck, _genericAccessory('#FFD700', 116), p),
      faceSvg(expression, cheekHex: p.cheek, blink: blink),
      _resolve(AvatarSlot.hair, _hairSvg(type, p), p),
      if (equipped.containsKey(AvatarSlot.hat))
        _resolve(AvatarSlot.hat, _genericAccessory('#FFD700', 22), p),
      if (equipped.containsKey(AvatarSlot.faceAccessory))
        _resolve(AvatarSlot.faceAccessory, _glassesSvg, p),
    ];

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        children: [
          for (final svg in layers)
            Positioned.fill(
              child: SvgPicture.string(svg, fit: BoxFit.contain),
            ),
        ],
      ),
    );
  }

  /// Returns the equipped item's art for [slot], or [fallback] when nothing is
  /// equipped / the item has no art yet.
  String _resolve(AvatarSlot slot, String fallback, AvatarPalette p) {
    final itemId = equipped[slot];
    if (itemId != null) {
      final art = _equippedItemSvg(slot, itemId, p);
      if (art != null) return art;
    }
    return fallback;
  }

  /// Hook for the shop catalog — returns the item's cosmetic art, or null when
  /// the id is unknown (the avatar then keeps its default look for the slot).
  String? _equippedItemSvg(AvatarSlot slot, String itemId, AvatarPalette p) =>
      cosmeticArt(slot, itemId);
}

String _svg(String inner) =>
    "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'>$inner</svg>";

// ─── Intrinsic layers ───────────────────────────────────────────────────────

const String _shadowSvg =
    "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'>"
    "<ellipse cx='100' cy='190' rx='46' ry='8' fill='#1A1A4E' opacity='0.12'/>"
    "</svg>";

String _bodySvg(AvatarPalette p) => _svg('''
<!-- legs -->
<rect x='84' y='150' width='13' height='34' rx='6.5' fill='${p.skin}'/>
<rect x='103' y='150' width='13' height='34' rx='6.5' fill='${p.skin}'/>
<!-- arms -->
<rect x='54' y='114' width='14' height='44' rx='7' fill='${p.skin}'/>
<rect x='132' y='114' width='14' height='44' rx='7' fill='${p.skin}'/>
<!-- hands -->
<circle cx='61' cy='158' r='8.5' fill='${p.skin}'/>
<circle cx='139' cy='158' r='8.5' fill='${p.skin}'/>
<!-- torso base -->
<rect x='70' y='108' width='60' height='56' rx='24' fill='${p.skin}'/>
<!-- neck -->
<rect x='92' y='100' width='16' height='16' rx='5' fill='${p.skinShade}'/>
<!-- ears -->
<circle cx='61' cy='70' r='9' fill='${p.skin}'/>
<circle cx='139' cy='70' r='9' fill='${p.skin}'/>
<circle cx='61' cy='70' r='4' fill='${p.skinShade}'/>
<circle cx='139' cy='70' r='4' fill='${p.skinShade}'/>
<!-- head -->
<circle cx='100' cy='68' r='40' fill='${p.skin}'/>
''');

String _bottomSvg(AvatarPalette p) => _svg('''
<rect x='80' y='146' width='40' height='18' rx='8' fill='${p.bottom}'/>
<rect x='83' y='150' width='15' height='30' rx='6' fill='${p.bottom}'/>
<rect x='102' y='150' width='15' height='30' rx='6' fill='${p.bottom}'/>
''');

String _shoesSvg(AvatarPalette p) => _svg('''
<ellipse cx='90' cy='185' rx='12' ry='7' fill='${p.shoes}'/>
<ellipse cx='110' cy='185' rx='12' ry='7' fill='${p.shoes}'/>
<rect x='84' y='178' width='12' height='6' rx='3' fill='#ffffff' opacity='0.85'/>
<rect x='104' y='178' width='12' height='6' rx='3' fill='#ffffff' opacity='0.85'/>
''');

String _topSvg(AvatarPalette p) => _svg('''
<!-- sleeves -->
<rect x='52' y='112' width='18' height='30' rx='9' fill='${p.topShade}'/>
<rect x='130' y='112' width='18' height='30' rx='9' fill='${p.topShade}'/>
<!-- shirt -->
<rect x='68' y='110' width='64' height='52' rx='22' fill='${p.top}'/>
<!-- collar -->
<path d='M88 110 L100 124 L112 110 Z' fill='#ffffff'/>
<!-- placket -->
<rect x='98.5' y='118' width='3' height='40' rx='1.5' fill='${p.topShade}'/>
<circle cx='100' cy='132' r='2' fill='#ffffff'/>
<circle cx='100' cy='144' r='2' fill='#ffffff'/>
''');

String _hairSvg(AssistantType type, AvatarPalette p) {
  if (type == AssistantType.bektur) {
    // Short, slightly spiky fringe.
    return _svg('''
<path d='M62 64 Q60 30 100 28 Q140 30 138 64 Q138 50 120 46
         Q124 56 110 52 Q112 60 98 50 Q96 60 84 50 Q80 58 70 52 Q64 56 62 64 Z'
      fill='${p.hair}'/>
''');
  }
  // Long flowing hair framing the face and falling past the shoulders.
  return _svg('''
<path d='M58 70 Q54 150 70 168 Q60 120 66 86 Z' fill='${p.hair}'/>
<path d='M142 70 Q146 150 130 168 Q140 120 134 86 Z' fill='${p.hair}'/>
<path d='M60 70 Q56 30 100 27 Q144 30 140 70 Q140 50 116 46
         Q120 58 100 50 Q80 58 84 46 Q60 50 60 70 Z' fill='${p.hair}'/>
<circle cx='100' cy='30' r='6' fill='#FFD700' opacity='0.9'/>
''');
}

/// A small, friendly placeholder pet (rounded blob) beside the character.
String _petSvg(AvatarPalette p) => _svg('''
<ellipse cx='40' cy='186' rx='20' ry='5' fill='#1A1A4E' opacity='0.1'/>
<circle cx='40' cy='168' r='18' fill='${p.topShade}'/>
<path d='M28 156 l-3 -10 9 5 z' fill='${p.topShade}'/>
<path d='M52 156 l3 -10 -9 5 z' fill='${p.topShade}'/>
<circle cx='34' cy='166' r='2.6' fill='#1A1A4E'/>
<circle cx='46' cy='166' r='2.6' fill='#1A1A4E'/>
<path d='M37 172 Q40 175 43 172' stroke='#1A1A4E' stroke-width='1.6' fill='none' stroke-linecap='round'/>
''');

/// Simple round glasses used as the default face-accessory placeholder.
const String _glassesSvg =
    "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'>"
    "<circle cx='86' cy='66' r='9' fill='none' stroke='#1A1A4E' stroke-width='2.4'/>"
    "<circle cx='114' cy='66' r='9' fill='none' stroke='#1A1A4E' stroke-width='2.4'/>"
    "<line x1='95' y1='66' x2='105' y2='66' stroke='#1A1A4E' stroke-width='2.4'/>"
    "</svg>";

/// Generic accessory placeholder (a small band) drawn at vertical [y].
String _genericAccessory(String color, double y) => _svg(
      "<rect x='70' y='$y' width='60' height='10' rx='5' fill='$color'/>",
    );
