/// Facial expressions for the assistant avatars.
///
/// Each expression is returned as an SVG fragment positioned over the head of
/// the character (head centred at ~(100, 68) on a 200×200 canvas) so it aligns
/// with the body layers in [avatar_base.dart]. Swapping the face is what makes
/// Bektur and Nazym feel alive and reactive.
enum AvatarExpression { neutral, happy, sad, surprised, thinking, celebrate }

const String _eye = '#1A1A4E';
const String _mouth = '#7A2E3A';

/// Builds the full face SVG for [expression].
///
/// [cheekHex] tints the blush. When [blink] is true the open eyes are replaced
/// with gentle closed arcs (used by the idle blink in [avatar_display.dart]).
String faceSvg(
  AvatarExpression expression, {
  required String cheekHex,
  bool blink = false,
}) {
  final eyes = blink ? _closedEyes : _eyesFor(expression);
  final extras = _mouthFor(expression);
  final cheeks = _cheeks(cheekHex, expression);
  return _wrap('$cheeks$eyes$extras');
}

String _wrap(String inner) =>
    "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'>$inner</svg>";

// ─── Eyes ─────────────────────────────────────────────────────────────────

const String _closedEyes = '''
<path d='M80 66 Q86 71 92 66' stroke='$_eye' stroke-width='3' fill='none' stroke-linecap='round'/>
<path d='M108 66 Q114 71 120 66' stroke='$_eye' stroke-width='3' fill='none' stroke-linecap='round'/>
''';

const String _roundEyes = '''
<circle cx='86' cy='66' r='5.6' fill='$_eye'/>
<circle cx='114' cy='66' r='5.6' fill='$_eye'/>
<circle cx='88' cy='63.5' r='1.9' fill='#ffffff'/>
<circle cx='116' cy='63.5' r='1.9' fill='#ffffff'/>
''';

const String _curvedEyes = '''
<path d='M80 67 Q86 59 92 67' stroke='$_eye' stroke-width='3.6' fill='none' stroke-linecap='round'/>
<path d='M108 67 Q114 59 120 67' stroke='$_eye' stroke-width='3.6' fill='none' stroke-linecap='round'/>
''';

const String _sadEyes = '''
<path d='M80 60 Q86 57 91 60' stroke='$_eye' stroke-width='2.4' fill='none' stroke-linecap='round'/>
<path d='M109 60 Q114 57 120 60' stroke='$_eye' stroke-width='2.4' fill='none' stroke-linecap='round'/>
<circle cx='86' cy='68' r='4.6' fill='$_eye'/>
<circle cx='114' cy='68' r='4.6' fill='$_eye'/>
''';

const String _wideEyes = '''
<circle cx='86' cy='65' r='8.2' fill='#ffffff' stroke='$_eye' stroke-width='2'/>
<circle cx='114' cy='65' r='8.2' fill='#ffffff' stroke='$_eye' stroke-width='2'/>
<circle cx='86' cy='66' r='4' fill='$_eye'/>
<circle cx='114' cy='66' r='4' fill='$_eye'/>
<path d='M78 53 Q86 49 94 53' stroke='$_eye' stroke-width='2' fill='none' stroke-linecap='round'/>
<path d='M106 53 Q114 49 122 53' stroke='$_eye' stroke-width='2' fill='none' stroke-linecap='round'/>
''';

const String _thinkingEyes = '''
<circle cx='86' cy='64' r='6' fill='#ffffff' stroke='$_eye' stroke-width='1.6'/>
<circle cx='114' cy='64' r='6' fill='#ffffff' stroke='$_eye' stroke-width='1.6'/>
<circle cx='87' cy='61' r='3' fill='$_eye'/>
<circle cx='115' cy='61' r='3' fill='$_eye'/>
<path d='M106 53 Q114 48 122 54' stroke='$_eye' stroke-width='2.2' fill='none' stroke-linecap='round'/>
''';

String _eyesFor(AvatarExpression e) {
  switch (e) {
    case AvatarExpression.neutral:
      return _roundEyes;
    case AvatarExpression.happy:
    case AvatarExpression.celebrate:
      return _curvedEyes;
    case AvatarExpression.sad:
      return _sadEyes;
    case AvatarExpression.surprised:
      return _wideEyes;
    case AvatarExpression.thinking:
      return _thinkingEyes;
  }
}

// ─── Mouths & extras ───────────────────────────────────────────────────────

String _mouthFor(AvatarExpression e) {
  switch (e) {
    case AvatarExpression.neutral:
      return "<path d='M90 84 Q100 92 110 84' stroke='$_mouth' stroke-width='3' "
          "fill='none' stroke-linecap='round'/>";
    case AvatarExpression.happy:
      return "<path d='M88 82 Q100 96 112 82 Z' fill='$_mouth'/>"
          "<path d='M92 84 Q100 90 108 84' fill='#ffffff'/>";
    case AvatarExpression.sad:
      return "<path d='M90 90 Q100 83 110 90' stroke='$_mouth' stroke-width='3' "
          "fill='none' stroke-linecap='round'/>";
    case AvatarExpression.surprised:
      return "<ellipse cx='100' cy='87' rx='6.5' ry='8.5' fill='$_mouth'/>";
    case AvatarExpression.thinking:
      return "<path d='M92 87 Q99 85 106 88' stroke='$_mouth' stroke-width='3' "
              "fill='none' stroke-linecap='round'/>"
          // little thought dots
          "<circle cx='150' cy='40' r='3' fill='$_eye' opacity='0.5'/>"
          "<circle cx='160' cy='32' r='4.5' fill='$_eye' opacity='0.5'/>";
    case AvatarExpression.celebrate:
      return "<path d='M84 80 Q100 104 116 80 Z' fill='$_mouth'/>"
              "<path d='M90 82 Q100 90 110 82' fill='#ffffff'/>"
          // sparkles
          "<path d='M52 44 l2 6 6 2 -6 2 -2 6 -2 -6 -6 -2 6 -2 z' fill='#FFD700'/>"
          "<path d='M150 50 l1.6 4.8 4.8 1.6 -4.8 1.6 -1.6 4.8 -1.6 -4.8 -4.8 -1.6 4.8 -1.6 z' fill='#FFD700'/>";
  }
}

// ─── Cheeks ─────────────────────────────────────────────────────────────────

String _cheeks(String cheekHex, AvatarExpression e) {
  final strong = e == AvatarExpression.happy ||
      e == AvatarExpression.celebrate ||
      e == AvatarExpression.surprised;
  final opacity = strong ? '0.65' : '0.45';
  return "<ellipse cx='79' cy='80' rx='6.5' ry='4.2' fill='$cheekHex' opacity='$opacity'/>"
      "<ellipse cx='121' cy='80' rx='6.5' ry='4.2' fill='$cheekHex' opacity='$opacity'/>";
}
