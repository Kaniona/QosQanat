import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// Subtle golden particles drifting upward, used to give the dark hero
/// backgrounds (splash, assistant selection) a magical, premium feel.
class FloatingParticles extends StatefulWidget {
  const FloatingParticles({
    super.key,
    this.count = 28,
    this.color = AppColors.gold,
  });

  final int count;
  final Color color;

  @override
  State<FloatingParticles> createState() => _FloatingParticlesState();
}

class _FloatingParticlesState extends State<FloatingParticles>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final List<_Particle> _particles;

  @override
  void initState() {
    super.initState();
    final rnd = math.Random();
    _particles = List.generate(widget.count, (_) => _Particle.random(rnd));
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) => CustomPaint(
          painter: _ParticlePainter(
            particles: _particles,
            progress: _controller.value,
            color: widget.color,
          ),
          size: Size.infinite,
        ),
      ),
    );
  }
}

class _Particle {
  _Particle({
    required this.x,
    required this.startY,
    required this.radius,
    required this.speed,
    required this.phase,
    required this.opacity,
  });

  final double x; // 0..1 horizontal position
  final double startY; // 0..1 vertical offset
  final double radius; // px
  final double speed; // cycles per animation
  final double phase; // 0..1 offset so they don't move in lockstep
  final double opacity;

  factory _Particle.random(math.Random r) => _Particle(
        x: r.nextDouble(),
        startY: r.nextDouble(),
        radius: 1.2 + r.nextDouble() * 2.8,
        speed: 0.5 + r.nextDouble() * 1.2,
        phase: r.nextDouble(),
        opacity: 0.25 + r.nextDouble() * 0.5,
      );
}

class _ParticlePainter extends CustomPainter {
  _ParticlePainter({
    required this.particles,
    required this.progress,
    required this.color,
  });

  final List<_Particle> particles;
  final double progress;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    for (final p in particles) {
      final t = (progress * p.speed + p.phase) % 1.0;
      final y = (p.startY - t) % 1.0; // drift upward, wrap around
      final dx = p.x * size.width +
          math.sin((t + p.phase) * math.pi * 2) * 8; // gentle sway
      final dy = y * size.height;
      paint.color = color.withValues(alpha: p.opacity * (1 - t) + 0.05);
      canvas.drawCircle(Offset(dx, dy), p.radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlePainter oldDelegate) => true;
}
