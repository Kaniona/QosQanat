import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// The QosQanat brand mark: a stylized pair of eagle wings around a central
/// orb, custom-painted with gold accents. Used on splash, the gift modal and
/// anywhere the logo is needed (no asset files required).
class EagleEmblem extends StatelessWidget {
  const EagleEmblem({super.key, this.size = 120, this.color = AppColors.gold});

  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _EaglePainter(color)),
    );
  }
}

class _EaglePainter extends CustomPainter {
  _EaglePainter(this.color);

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cx = w / 2;
    final cy = h / 2;

    final wingPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [AppColors.goldLight, AppColors.gold, AppColors.goldDeep],
      ).createShader(Rect.fromLTWH(0, 0, w, h))
      ..style = PaintingStyle.fill;

    // Right wing — three sweeping feathers.
    final right = Path()
      ..moveTo(cx, cy)
      ..quadraticBezierTo(cx + w * 0.18, cy - h * 0.22, cx + w * 0.46, cy - h * 0.30)
      ..quadraticBezierTo(cx + w * 0.30, cy - h * 0.10, cx + w * 0.40, cy + h * 0.02)
      ..quadraticBezierTo(cx + w * 0.26, cy + h * 0.04, cx + w * 0.34, cy + h * 0.16)
      ..quadraticBezierTo(cx + w * 0.18, cy + h * 0.12, cx, cy)
      ..close();
    canvas.drawPath(right, wingPaint);

    // Left wing — mirror of the right.
    canvas.save();
    canvas.translate(w, 0);
    canvas.scale(-1, 1);
    canvas.drawPath(right, wingPaint);
    canvas.restore();

    // Central orb with a subtle ring.
    final orbPaint = Paint()
      ..shader = const RadialGradient(
        colors: [AppColors.white, AppColors.goldLight, AppColors.gold],
      ).createShader(Rect.fromCircle(center: Offset(cx, cy), radius: w * 0.14));
    canvas.drawCircle(Offset(cx, cy), w * 0.13, orbPaint);

    final ringPaint = Paint()
      ..color = AppColors.goldDeep
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.018;
    canvas.drawCircle(Offset(cx, cy), w * 0.15, ringPaint);

    // A small four-point star inside the orb.
    final starPaint = Paint()..color = AppColors.goldDeep;
    final star = Path();
    final double r = w * 0.07;
    for (int i = 0; i < 4; i++) {
      final a = i * math.pi / 2;
      final ox = cx + math.cos(a) * r;
      final oy = cy + math.sin(a) * r;
      final ix = cx + math.cos(a + math.pi / 4) * r * 0.32;
      final iy = cy + math.sin(a + math.pi / 4) * r * 0.32;
      if (i == 0) {
        star.moveTo(ox, oy);
      } else {
        star.lineTo(ox, oy);
      }
      star.lineTo(ix, iy);
    }
    star.close();
    canvas.drawPath(star, starPaint);
  }

  @override
  bool shouldRepaint(covariant _EaglePainter oldDelegate) =>
      oldDelegate.color != color;
}
