import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../core/theme/assistant_theme.dart';
import '../../models/enums.dart';

/// A compact circular avatar for a person: their assistant's gradient with the
/// name initial, an optional gold ring, and an online-status dot. Used in
/// friend lists and battle mini-headers.
class ProfileAvatar extends StatelessWidget {
  const ProfileAvatar({
    super.key,
    required this.name,
    required this.assistant,
    this.size = 48,
    this.online,
    this.ring = false,
  });

  final String name;
  final AssistantType assistant;
  final double size;

  /// null hides the status dot; true/false shows online/offline.
  final bool? online;
  final bool ring;

  @override
  Widget build(BuildContext context) {
    final initial = name.trim().isEmpty ? '?' : name.trim().characters.first.toUpperCase();
    Widget circle = Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: assistant.gradient,
        shape: BoxShape.circle,
        border: ring ? Border.all(color: AppColors.gold, width: 2.5) : null,
      ),
      child: Text(
        initial,
        style: AppTypography.heading3.copyWith(
          color: AppColors.white,
          fontWeight: FontWeight.w800,
          fontSize: size * 0.42,
        ),
      ),
    );

    if (online == null) return circle;

    return Stack(
      clipBehavior: Clip.none,
      children: [
        circle,
        Positioned(
          right: 0,
          bottom: 0,
          child: Container(
            width: size * 0.26,
            height: size * 0.26,
            decoration: BoxDecoration(
              color: online! ? AppColors.success : AppColors.textTertiary,
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.surface, width: 2),
            ),
          ),
        ),
      ],
    );
  }
}
