import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';

/// A friendly, self-contained error screen shown by the top-level error
/// boundary when an unexpected build error occurs, so the student sees a calm
/// Kazakh message instead of the raw red error screen.
///
/// It carries its own [Directionality] and [Material] so it renders correctly
/// even when it replaces a widget high in the tree.
class AppErrorScreen extends StatelessWidget {
  const AppErrorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
        color: AppColors.background,
        alignment: Alignment.center,
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('🦅', style: TextStyle(fontSize: 64)),
            const SizedBox(height: 16),
            Text(
              'Әупіс, бірдеңе дұрыс болмады',
              textAlign: TextAlign.center,
              style: AppTypography.heading3.copyWith(color: AppColors.ink),
            ),
            const SizedBox(height: 8),
            Text(
              'Қолданбаны қайта ашып көріңіз.',
              textAlign: TextAlign.center,
              style: AppTypography.body.copyWith(color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}
