import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../models/friend.dart';
import '../providers/learn_provider.dart';
import '../screens/auth/assistant_select_screen.dart';
import '../screens/auth/register_screen.dart';
import '../screens/auth/splash_screen.dart';
import '../screens/auth/welcome_screen.dart';
import '../screens/battle/battle_result_screen.dart';
import '../screens/battle/battle_screen.dart';
import '../screens/battle/battle_setup_screen.dart';
import '../screens/battle/battle_waiting_screen.dart';
import '../screens/friends/friends_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/learn/learn_screen.dart';
import '../screens/learn/map_screen.dart';
import '../screens/learn/result_screen.dart';
import '../screens/learn/task_screen.dart';
import '../screens/main_shell.dart';
import '../screens/profile/profile_screen.dart';
import '../screens/profile/settings_screen.dart';
import '../screens/rating/rating_screen.dart';
import '../screens/shop/shop_screen.dart';
// TEMP: auth қақпасы өшірулі тұрғанда қолданылмайды; қайта қосқанда керек.
// ignore: unused_import
import '../services/supabase_service.dart';

/// Named route paths used across the app.
abstract final class AppRoutes {
  AppRoutes._();

  // Auth flow.
  static const String splash = '/';
  static const String welcome = '/welcome';
  static const String register = '/register';
  static const String assistantSelect = '/assistant-select';

  // Main shell tabs.
  static const String home = '/home';
  static const String learn = '/learn';
  static const String shop = '/shop';
  static const String friends = '/friends';
  static const String profile = '/profile';

  // Learning system (modal over the shell).
  static const String learnMap = '/learn-map'; // + /:subjectId
  static const String learnTask = '/learn-task'; // + /:subjectId/:nodeId
  static const String learnResult = '/learn-result'; // extra: TaskResult

  // Battle (modal over the shell).
  static const String battleSetup = '/battle/setup'; // extra: PublicProfile
  static const String battleWaiting = '/battle/waiting'; // extra: PublicProfile
  static const String battleLive = '/battle/live'; // extra: PublicProfile
  static const String battleResult = '/battle/result'; // extra: PublicProfile

  // Other modals.
  static const String rating = '/rating';
  static const String settings = '/settings';

  /// Paths that make up the unauthenticated onboarding flow.
  static const Set<String> authFlow = {
    splash,
    welcome,
    register,
    assistantSelect,
  };
}

/// A subtle fade+slide transition used for modal-style screens presented over
/// the shell, keeping deep navigation smooth.
CustomTransitionPage<void> _fadeSlide(Widget child, GoRouterState state) {
  return CustomTransitionPage<void>(
    key: state.pageKey,
    child: child,
    transitionDuration: const Duration(milliseconds: 350),
    transitionsBuilder: (context, animation, secondary, child) {
      final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      return FadeTransition(
        opacity: curved,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.04),
            end: Offset.zero,
          ).animate(curved),
          child: child,
        ),
      );
    },
  );
}

/// Auth-based gate: unauthenticated users are confined to the onboarding flow;
/// authenticated users are kept out of the welcome/register screens.
String? _redirect(BuildContext context, GoRouterState state) {
  // TEMP: кіру/тіркелу қақпасы уақытша өшірілген — қолданушы бірден басты бетке
  // өтеді. Auth дайын болғанда осы `return null;` жолын өшіріп, төмендегі
  // түсініктемедегі нақты логиканы қайта қос.
  return null;

  // final signedIn = SupabaseService.isSignedIn;
  // final loc = state.matchedLocation;
  //
  // if (!signedIn) {
  //   return AppRoutes.authFlow.contains(loc) ? null : AppRoutes.splash;
  // }
  // // Signed in: the welcome/register screens no longer apply. (Splash is allowed
  // // — it shows the brand moment then routes onward; assistant-select is allowed
  // // so the "change assistant" setting can reuse it.)
  // if (loc == AppRoutes.welcome || loc == AppRoutes.register) {
  //   return AppRoutes.home;
  // }
  // return null;
}

final _shellNavigatorHome = GlobalKey<NavigatorState>(debugLabel: 'home');
final _shellNavigatorLearn = GlobalKey<NavigatorState>(debugLabel: 'learn');
final _shellNavigatorShop = GlobalKey<NavigatorState>(debugLabel: 'shop');
final _shellNavigatorFriends = GlobalKey<NavigatorState>(debugLabel: 'friends');
final _shellNavigatorProfile = GlobalKey<NavigatorState>(debugLabel: 'profile');

/// Central go_router configuration for QosQanat.
final GoRouter appRouter = GoRouter(
  // TEMP: кіруді айналып өтіп, бірден басты беттен бастаймыз.
  // Auth қайта қосылғанда мынаны AppRoutes.splash деп қайтар.
  initialLocation: AppRoutes.home,
  redirect: _redirect,
  routes: [
    // ── Auth flow ─────────────────────────────────────────────────────────
    GoRoute(
      path: AppRoutes.splash,
      name: 'splash',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: AppRoutes.welcome,
      name: 'welcome',
      pageBuilder: (context, state) => _fadeSlide(const WelcomeScreen(), state),
    ),
    GoRoute(
      path: AppRoutes.register,
      name: 'register',
      pageBuilder: (context, state) => _fadeSlide(const RegisterScreen(), state),
    ),
    GoRoute(
      path: AppRoutes.assistantSelect,
      name: 'assistant-select',
      pageBuilder: (context, state) =>
          _fadeSlide(const AssistantSelectScreen(), state),
    ),

    // ── Main shell: five preserved tabs ─────────────────────────────────────
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) =>
          MainShell(navigationShell: navigationShell),
      branches: [
        StatefulShellBranch(
          navigatorKey: _shellNavigatorHome,
          routes: [
            GoRoute(
              path: AppRoutes.home,
              name: 'home',
              builder: (context, state) => const HomeScreen(),
            ),
          ],
        ),
        StatefulShellBranch(
          navigatorKey: _shellNavigatorLearn,
          routes: [
            GoRoute(
              path: AppRoutes.learn,
              name: 'learn',
              builder: (context, state) => const LearnScreen(),
            ),
          ],
        ),
        StatefulShellBranch(
          navigatorKey: _shellNavigatorShop,
          routes: [
            GoRoute(
              path: AppRoutes.shop,
              name: 'shop',
              builder: (context, state) => const ShopScreen(),
            ),
          ],
        ),
        StatefulShellBranch(
          navigatorKey: _shellNavigatorFriends,
          routes: [
            GoRoute(
              path: AppRoutes.friends,
              name: 'friends',
              builder: (context, state) => const FriendsScreen(),
            ),
          ],
        ),
        StatefulShellBranch(
          navigatorKey: _shellNavigatorProfile,
          routes: [
            GoRoute(
              path: AppRoutes.profile,
              name: 'profile',
              builder: (context, state) => const ProfileScreen(),
            ),
          ],
        ),
      ],
    ),

    // ── Learning (modal over the shell) ─────────────────────────────────────
    GoRoute(
      path: '${AppRoutes.learnMap}/:subjectId',
      name: 'learn-map',
      pageBuilder: (context, state) => _fadeSlide(
        MapScreen(subjectId: state.pathParameters['subjectId']!),
        state,
      ),
    ),
    GoRoute(
      path: '${AppRoutes.learnTask}/:subjectId/:nodeId',
      name: 'learn-task',
      pageBuilder: (context, state) => _fadeSlide(
        TaskScreen(
          subjectId: state.pathParameters['subjectId']!,
          nodeId: state.pathParameters['nodeId']!,
        ),
        state,
      ),
    ),
    GoRoute(
      path: AppRoutes.learnResult,
      name: 'learn-result',
      pageBuilder: (context, state) =>
          _fadeSlide(ResultScreen(result: state.extra as TaskResult), state),
    ),

    // ── Battle (modal over the shell) ───────────────────────────────────────
    GoRoute(
      path: AppRoutes.battleSetup,
      name: 'battle-setup',
      pageBuilder: (context, state) => _fadeSlide(
        BattleSetupScreen(opponent: state.extra as PublicProfile),
        state,
      ),
    ),
    GoRoute(
      path: AppRoutes.battleWaiting,
      name: 'battle-waiting',
      pageBuilder: (context, state) => _fadeSlide(
        BattleWaitingScreen(opponent: state.extra as PublicProfile),
        state,
      ),
    ),
    GoRoute(
      path: AppRoutes.battleLive,
      name: 'battle-live',
      pageBuilder: (context, state) => _fadeSlide(
        BattleScreen(opponent: state.extra as PublicProfile),
        state,
      ),
    ),
    GoRoute(
      path: AppRoutes.battleResult,
      name: 'battle-result',
      pageBuilder: (context, state) => _fadeSlide(
        BattleResultScreen(opponent: state.extra as PublicProfile),
        state,
      ),
    ),

    // ── Other modals ────────────────────────────────────────────────────────
    GoRoute(
      path: AppRoutes.rating,
      name: 'rating',
      pageBuilder: (context, state) => _fadeSlide(const RatingScreen(), state),
    ),
    GoRoute(
      path: AppRoutes.settings,
      name: 'settings',
      pageBuilder: (context, state) => _fadeSlide(const SettingsScreen(), state),
    ),
  ],
);
