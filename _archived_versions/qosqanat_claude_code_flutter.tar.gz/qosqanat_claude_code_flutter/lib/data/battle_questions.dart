import 'dart:math' as math;

import 'curriculum.dart';
import '../models/question.dart';

/// Builds a battle's question set from the curriculum. Battles use only
/// multiple-choice questions (four options). The set is seeded by the battle id
/// so both players see identical questions in the same order, then capped/cycled
/// to [count].
List<MultipleChoiceQuestion> battleQuestions({
  required String seed,
  required int count,
  String? subjectId,
}) {
  final pool = <MultipleChoiceQuestion>[];
  for (final subject in kCurriculum) {
    if (subjectId != null && subjectId != 'all' && subject.id != subjectId) {
      continue;
    }
    for (final node in subject.allNodes) {
      for (final q in node.questions) {
        if (q is MultipleChoiceQuestion) pool.add(q);
      }
    }
  }
  if (pool.isEmpty) return const [];

  final rnd = math.Random(seed.hashCode);
  pool.shuffle(rnd);

  // Cycle the shuffled pool if a single subject doesn't have enough questions.
  return [for (var i = 0; i < count; i++) pool[i % pool.length]];
}
