import '../models/enums.dart';
import '../models/shop_item.dart';
import '../widgets/avatar/avatar_base.dart';

/// The shop catalog: 50 cosmetic items across five categories. Item ids match
/// the cosmetic art registry in `lib/widgets/avatar/cosmetics.dart`, so a card's
/// preview and the equipped avatar always agree.

ShopItem _i(
  String id,
  String name,
  ItemCategory category,
  Rarity rarity,
  int price,
  int level, [
  String? description,
]) =>
    ShopItem(
      id: id,
      name: name,
      description: description,
      category: category,
      rarity: rarity,
      price: price,
      assetPath: id,
      levelRequirement: level,
    );

const _top = ItemCategory.top;
const _bottom = ItemCategory.bottom;
const _hat = ItemCategory.hat;
const _acc = ItemCategory.accessory;
const _pet = ItemCategory.pet;

const _c = Rarity.common;
const _r = Rarity.rare;
const _e = Rarity.epic;
const _l = Rarity.legendary;

/// The full catalog.
final List<ShopItem> kShopItems = [
  // ── Tops ──────────────────────────────────────────────────────────────
  _i('top_school', 'Мектеп жакеті', _top, _c, 0, 1, 'Сенімді әрі классикалық.'),
  _i('top_hoodie_red', 'Қызыл худи', _top, _c, 100, 3, 'Жайлы әрі жарқын.'),
  _i('top_hoodie_blue', 'Көк худи', _top, _c, 100, 3, 'Көк түс — тыныштық белгісі.'),
  _i('top_hoodie_green', 'Жасыл худи', _top, _c, 100, 3, 'Табиғат түсіндегі худи.'),
  _i('top_sweatshirt', 'Спорт свитшот', _top, _c, 150, 5, 'Жаттығуға дайын!'),
  _i('top_tee_white', 'Ақ футболка', _top, _c, 70, 2, 'Қарапайымдылық — сән.'),
  _i('top_hoodie_yellow', 'Сары худи', _top, _c, 120, 4, 'Күн сәулесіндей жарқын.'),
  _i('top_hoodie_black', 'Қара худи', _top, _c, 120, 4, 'Стильді әрі сал.'),
  _i('top_denim', 'Джинс куртка', _top, _c, 180, 6, 'Ешқашан ескірмейді.'),
  _i('top_leather', 'Кожаный жакет', _top, _r, 250, 8, 'Нағыз батырларға.'),
  _i('top_varsity', 'Университет куртка', _top, _r, 280, 9, 'Чемпиондар киімі.'),
  _i('top_chapan', 'Чапан', _top, _r, 400, 10, 'Қазақтың дәстүрлі сәні.'),
  _i('top_astronaut', 'Астронавт костюмі', _top, _e, 800, 20, 'Жұлдыздарға саяхат!'),
  _i('top_robot', 'Робот сауыт', _top, _l, 1200, 25, 'Болашақтан келген сауыт.'),

  // ── Bottoms ───────────────────────────────────────────────────────────
  _i('bottom_school', 'Мектеп шалбары', _bottom, _c, 0, 1, 'Күнделікті классика.'),
  _i('bottom_jeans', 'Джинс', _bottom, _c, 80, 3, 'Әмбебап джинс.'),
  _i('bottom_sport', 'Спорт шалбар', _bottom, _c, 80, 3, 'Қозғалысқа еркіндік.'),
  _i('bottom_shorts', 'Қысқа шалбар', _bottom, _c, 70, 2, 'Жазғы жеңілдік.'),
  _i('bottom_cargo', 'Карго шалбар', _bottom, _c, 120, 5, 'Қалталары көп әрі ыңғайлы.'),
  _i('bottom_classic', 'Классикалық шалбар', _bottom, _c, 110, 4, 'Ресми кездесулерге.'),
  _i('bottom_trad', 'Дәстүрлі шалбар', _bottom, _r, 200, 8, 'Ою-өрнекті дәстүр.'),

  // ── Hats ──────────────────────────────────────────────────────────────
  _i('hat_none', 'Жоқ', _hat, _c, 0, 1, 'Бас киімсіз.'),
  _i('hat_cap', 'Бейсболка', _hat, _c, 50, 2, 'Спорттық көзқарас.'),
  _i('hat_panama', 'Панама', _hat, _c, 70, 3, 'Күннен қорғайды.'),
  _i('hat_winter', 'Қысқы бөрік', _hat, _c, 90, 4, 'Жылы әрі жайлы.'),
  _i('hat_takia', 'Тақия', _hat, _r, 150, 6, 'Ұлттық бас киім.'),
  _i('hat_tophat', 'Граф шляпасы', _hat, _r, 250, 10, 'Ақсүйектердің сәні.'),
  _i('hat_wizard', 'Сиқыршы қалпағы', _hat, _e, 350, 12, 'Білім сиқыры!'),
  _i('hat_crown', 'Патша тәжі', _hat, _r, 500, 15, 'Нағыз чемпионның тәжі.'),

  // ── Accessories ─────────────────────────────────────────────────────────
  _i('acc_none', 'Жоқ', _acc, _c, 0, 1, 'Аксессуарсыз.'),
  _i('acc_bracelet', 'Білезік', _acc, _c, 60, 2, 'Шағын әрі әсем.'),
  _i('acc_glasses', 'Көзілдірік', _acc, _c, 90, 3, 'Ақылды көрініс.'),
  _i('acc_chain', 'Алтын тізбек', _acc, _r, 120, 5, 'Алтындай жарқыл.'),
  _i('acc_silver_chain', 'Күміс тізбек', _acc, _c, 90, 4, 'Күмістей таза.'),
  _i('acc_scarf', 'Шарф', _acc, _c, 80, 3, 'Жылы әрі сәнді.'),
  _i('acc_watch', 'Қол сағаты', _acc, _r, 160, 7, 'Уақыт — байлық.'),
  _i('acc_backpack', 'Рюкзак', _acc, _c, 180, 6, 'Білім толы сөмке.'),
  _i('acc_headset', 'Гарнитура', _acc, _r, 220, 8, 'Музыка мен фокус.'),
  _i('acc_vr', 'VR көзілдірік', _acc, _e, 300, 10, 'Жаңа әлемге кір!'),

  // ── Pets ──────────────────────────────────────────────────────────────
  _i('pet_none', 'Жоқ', _pet, _c, 0, 1, 'Питомецсіз.'),
  _i('pet_rabbit', 'Қоян', _pet, _c, 250, 5, 'Жұмсақ әрі жылдам дос.'),
  _i('pet_turtle', 'Тасбақа', _pet, _c, 300, 6, 'Баяу, бірақ дана.'),
  _i('pet_parrot', 'Тотықұс', _pet, _r, 450, 9, 'Түрлі-түсті әрі сөзшең.'),
  _i('pet_cat', 'Ақ мысық', _pet, _r, 500, 10, 'Жұмсақ әрі мейірімді.'),
  _i('pet_black_cat', 'Қара мысық', _pet, _r, 550, 11, 'Сырлы әрі сұлу.'),
  _i('pet_wolf', 'Қасқыр күшігі', _pet, _r, 600, 12, 'Адал әрі батыл.'),
  _i('pet_robot', 'Робот достас', _pet, _r, 750, 15, 'Болашақтың серігі.'),
  _i('pet_eagle', 'Бүркіт', _pet, _e, 800, 15, 'Дала патшасы — қанатты дос.'),
  _i('pet_leopard', 'Барс балапаны', _pet, _r, 1000, 20, 'Қарлы барстың сәбиі.'),
  _i('pet_dragon', 'Айдаһар балапаны', _pet, _e, 1500, 25, 'Аңызға айналған дос!'),
];

/// Items flagged with a "ЖАҢА" ribbon (freshly added headline cosmetics).
const Set<String> kNewItemIds = {
  'top_robot',
  'top_astronaut',
  'hat_wizard',
  'pet_dragon',
  'acc_headset',
};

// ─────────────────────────────────────────────────────────────────────────
// Lookups
// ─────────────────────────────────────────────────────────────────────────

/// Items in one category, in catalog order.
List<ShopItem> shopItemsByCategory(ItemCategory category) =>
    [for (final i in kShopItems) if (i.category == category) i];

ShopItem? shopItemById(String id) {
  for (final i in kShopItems) {
    if (i.id == id) return i;
  }
  return null;
}

/// A "Жоқ" item — equipping it clears the slot.
bool isNoneItem(String id) => id.endsWith('_none');

/// The free default item equipped in [category] when nothing is chosen.
String defaultEquippedId(ItemCategory category) => switch (category) {
      ItemCategory.top => 'top_school',
      ItemCategory.bottom => 'bottom_school',
      ItemCategory.hat => 'hat_none',
      ItemCategory.accessory => 'acc_none',
      ItemCategory.pet => 'pet_none',
    };

/// The avatar body slot a shop [category] maps onto.
AvatarSlot slotForCategory(ItemCategory category) => switch (category) {
      ItemCategory.top => AvatarSlot.top,
      ItemCategory.bottom => AvatarSlot.bottom,
      ItemCategory.hat => AvatarSlot.hat,
      ItemCategory.accessory => AvatarSlot.faceAccessory,
      ItemCategory.pet => AvatarSlot.pet,
    };
