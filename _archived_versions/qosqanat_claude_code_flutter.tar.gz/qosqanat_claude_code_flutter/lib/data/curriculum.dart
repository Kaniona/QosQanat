import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';
import '../models/enums.dart';
import '../models/question.dart';

/// The QosQanat curriculum: five subjects, each with grade-based modules, each
/// module with an ordered list of map nodes, each node carrying real Kazakh
/// questions of mixed types.
///
/// This is static content (no progress). Per-student lock/complete/stars state
/// lives in the learn provider, keyed by node id.

// ─────────────────────────────────────────────────────────────────────────
// Structures
// ─────────────────────────────────────────────────────────────────────────

/// A single node on a learning map.
class LearnNode {
  const LearnNode({
    required this.id,
    required this.moduleId,
    required this.title,
    required this.description,
    required this.type,
    required this.order,
    required this.questions,
    this.xpReward = 15,
    this.coinReward = 10,
    this.akylReward = 0,
  });

  final String id;
  final String moduleId;
  final String title;
  final String description;
  final NodeType type;
  final int order;
  final List<Question> questions;
  final int xpReward;
  final int coinReward;
  final int akylReward;

  int get questionCount => questions.length;
}

/// A grade-scoped group of nodes within a subject.
class CurriculumModule {
  const CurriculumModule({
    required this.id,
    required this.subjectId,
    required this.grade,
    required this.title,
    required this.nodes,
  });

  final String id;
  final String subjectId;
  final int grade;
  final String title;
  final List<LearnNode> nodes;
}

/// A subject — a "world" the student can enter.
class Subject {
  const Subject({
    required this.id,
    required this.name,
    required this.emoji,
    required this.color,
    required this.gradient,
    required this.modules,
  });

  final String id;
  final String name;
  final String emoji;
  final Color color;
  final Gradient gradient;
  final List<CurriculumModule> modules;

  /// Every node across all modules, in play order.
  List<LearnNode> get allNodes => [for (final m in modules) ...m.nodes];

  int get totalNodes => allNodes.length;
}

LinearGradient _g(List<Color> colors) => LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: colors,
    );

// Reward presets by node type, so the map feels fair and escalating.
const _lessonXp = 15, _lessonCoin = 10;
const _quizXp = 25, _quizCoin = 15, _quizAkyl = 3;
const _bossXp = 60, _bossCoin = 50, _bossAkyl = 10;
const _treasureXp = 20, _treasureCoin = 40, _treasureAkyl = 5;

// ─────────────────────────────────────────────────────────────────────────
// Question authoring helpers (keep the data below terse and readable)
// ─────────────────────────────────────────────────────────────────────────

MultipleChoiceQuestion _mc(
  String id,
  String prompt,
  List<String> options,
  int correct, [
  String? explain,
]) =>
    MultipleChoiceQuestion(
      id: id,
      prompt: prompt,
      options: options,
      correctIndex: correct,
      explanation: explain,
    );

TrueFalseQuestion _tf(String id, String prompt, bool answer, [String? explain]) =>
    TrueFalseQuestion(id: id, prompt: prompt, answer: answer, explanation: explain);

FillBlankQuestion _fb(
  String id,
  String prompt,
  List<String> words,
  int correct, [
  String? explain,
]) =>
    FillBlankQuestion(
      id: id,
      prompt: prompt,
      words: words,
      correctIndex: correct,
      explanation: explain,
    );

MatchPairsQuestion _mp(String id, String prompt, List<MatchPair> pairs) =>
    MatchPairsQuestion(id: id, prompt: prompt, pairs: pairs);

MatchPair _pair(String l, String r) => MatchPair(left: l, right: r);

/// Builds a node, defaulting rewards from its [type].
LearnNode _node({
  required String moduleId,
  required String id,
  required String title,
  required String description,
  required NodeType type,
  required int order,
  required List<Question> questions,
}) {
  final (xp, coin, akyl) = switch (type) {
    NodeType.lesson => (_lessonXp, _lessonCoin, 0),
    NodeType.quiz => (_quizXp, _quizCoin, _quizAkyl),
    NodeType.boss => (_bossXp, _bossCoin, _bossAkyl),
    NodeType.treasure => (_treasureXp, _treasureCoin, _treasureAkyl),
  };
  return LearnNode(
    id: id,
    moduleId: moduleId,
    title: title,
    description: description,
    type: type,
    order: order,
    questions: questions,
    xpReward: xp,
    coinReward: coin,
    akylReward: akyl,
  );
}

// ═════════════════════════════════════════════════════════════════════════
// ИНФОРМАТИКА — the flagship world (grade 5)
// ═════════════════════════════════════════════════════════════════════════

const _infoG5 = 'info_g5';

final List<LearnNode> _informaticsG5Nodes = [
  _node(
    moduleId: _infoG5,
    id: 'info_computer',
    title: 'Компьютер деген не?',
    description: 'Компьютердің не екенін және ол не істейтінін үйрен.',
    type: NodeType.lesson,
    order: 0,
    questions: [
      _mc('q', 'Компьютер дегеніміз не?', [
        'Ақпаратты өңдейтін электронды құрылғы',
        'Тек ойнайтын ойыншық',
        'Кітаптың түрі',
        'Тағам',
      ], 0),
      _tf('q', 'Компьютер тек ересектерге ғана арналған.', false,
          'Компьютерді кез келген жаста қолдануға болады.'),
      _mc('q', 'Компьютердің «миы» қалай аталады?', [
        'Процессор',
        'Монитор',
        'Тінтуір',
        'Принтер',
      ], 0, 'Процессор — барлық есептеулерді орындайтын басты бөлік.'),
      _mp('q', 'Құрылғы мен оның қызметін сәйкестендір:', [
        _pair('Монитор', 'Бейне көрсетеді'),
        _pair('Пернетақта', 'Мәтін теру'),
        _pair('Тінтуір', 'Меңзерді басқару'),
      ]),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_keyboard',
    title: 'Пернетақта мен құрылғылар',
    description: 'Енгізу және шығару құрылғыларымен таныс.',
    type: NodeType.lesson,
    order: 1,
    questions: [
      _mc('q', 'Қай құрылғы мәтін теруге арналған?', [
        'Пернетақта',
        'Монитор',
        'Динамик',
        'Принтер',
      ], 0),
      _mc('q', 'Қай құрылғы — шығару (output) құрылғысы?', [
        'Принтер',
        'Пернетақта',
        'Тінтуір',
        'Микрофон',
      ], 0, 'Принтер ақпаратты қағазға шығарады.'),
      _tf('q', 'Тінтуір — енгізу (input) құрылғысы.', true),
      _fb('q', 'Дыбысты ___ арқылы естиміз.',
          ['динамик', 'монитор', 'қағаз'], 0),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_devices_quiz',
    title: 'Құрылғылар сынағы',
    description: 'Енгізу мен шығаруды ажырата аласың ба? Тексер!',
    type: NodeType.quiz,
    order: 2,
    questions: [
      _mc('q', 'Қайсысы енгізу құрылғысы ЕМЕС?', [
        'Монитор',
        'Пернетақта',
        'Микрофон',
        'Сканер',
      ], 0),
      _mp('q', 'Құрылғыны түріне қарай бөл:', [
        _pair('Пернетақта', 'Енгізу'),
        _pair('Монитор', 'Шығару'),
        _pair('Микрофон', 'Енгізу'),
        _pair('Принтер', 'Шығару'),
      ]),
      _tf('q', 'Сканер суретті компьютерге енгізеді.', true),
      _mc('q', 'Веб-камера не үшін қажет?', [
        'Бейне мен суретті түсіру',
        'Қағаз басып шығару',
        'Дыбысты сақтау',
        'Тоқ беру',
      ], 0),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_os',
    title: 'Операциялық жүйе',
    description: 'Windows, macOS, Android — олар не істейді?',
    type: NodeType.lesson,
    order: 3,
    questions: [
      _mc('q', 'Операциялық жүйе деген не?', [
        'Компьютерді басқаратын негізгі бағдарлама',
        'Ойын',
        'Интернет сайты',
        'Пернетақта',
      ], 0),
      _mc('q', 'Қайсысы операциялық жүйе?', [
        'Windows',
        'Kaspi',
        'YouTube',
        'Word',
      ], 0),
      _tf('q', 'Android — телефонға арналған операциялық жүйе.', true),
      _fb('q', 'Apple компаниясының компьютерлерінде ___ жүйесі орнатылған.',
          ['macOS', 'Android', 'Linux'], 0),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_internet',
    title: 'Интернет деген не?',
    description: 'Бүкіл әлемді байланыстыратын желі туралы.',
    type: NodeType.lesson,
    order: 4,
    questions: [
      _mc('q', 'Интернет дегеніміз не?', [
        'Бүкіл әлемдегі компьютерлерді байланыстыратын желі',
        'Бір компьютердегі ойын',
        'Принтер түрі',
        'Пернетақта',
      ], 0),
      _tf('q', 'Интернетсіз де электрондық хат жіберуге болады.', false,
          'Электрондық хат жіберу үшін интернет қажет.'),
      _mc('q', 'Веб-сайтты ашатын бағдарлама қалай аталады?', [
        'Браузер',
        'Принтер',
        'Калькулятор',
        'Динамик',
      ], 0),
      _mp('q', 'Сәйкестендір:', [
        _pair('Браузер', 'Сайт ашады'),
        _pair('Wi-Fi', 'Сымсыз интернет'),
        _pair('Сайт', 'Интернеттегі бет'),
      ]),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_mobile',
    title: 'Смартфон мен планшет',
    description: 'Қалтаңдағы шағын компьютерлер.',
    type: NodeType.quiz,
    order: 5,
    questions: [
      _mc('q', 'Смартфон — бұл...', [
        'Қалтаға сыятын шағын компьютер',
        'Тек қоңырау шалатын құрал',
        'Теледидар',
        'Принтер',
      ], 0),
      _tf('q', 'Планшеттің экраны сенсорлы болады.', true),
      _mc('q', 'Қосымшаларды (app) қайдан жүктейміз?', [
        'Қосымшалар дүкенінен',
        'Тоңазытқыштан',
        'Кітаптан',
        'Қабырғадан',
      ], 0),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_safety',
    title: 'Интернет қауіпсіздігі',
    description: 'Желіде өзіңді қалай қорғау керектігін біл.',
    type: NodeType.lesson,
    order: 6,
    questions: [
      _mc('q', 'Құпия сөзіңді кіммен бөлісуге болады?', [
        'Ешкіммен (тек ата-анаңмен)',
        'Барлық достарыммен',
        'Әлеуметтік желіде жариялаймын',
        'Бейтаныс адаммен',
      ], 0, 'Құпия сөзді құпия сақта — ол сенің кілтің.'),
      _tf('q', 'Бейтаныс адамға үй мекенжайыңды айтуға болады.', false,
          'Жеке ақпаратты бейтаныс адамдарға айтпа.'),
      _mc('q', 'Күмәнді сілтемені басқанда не істеу керек?', [
        'Баспау және ересекке айту',
        'Бірден басу',
        'Достарға жіберу',
        'Құпия сөзді енгізу',
      ], 0),
      _fb('q', 'Жақсы құпия сөз ___ болуы керек.',
          ['күрделі', 'қысқа', 'оңай'], 0),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_boss_tech',
    title: 'Технология сақшысы',
    description: 'Алғашқы боссты жең! Барлық білгеніңді көрсет.',
    type: NodeType.boss,
    order: 7,
    questions: [
      _mc('q', 'Компьютердің «миы»?', ['Процессор', 'Монитор', 'Тінтуір', 'Wi-Fi'], 0),
      _mc('q', 'Қайсысы операциялық жүйе?', ['Android', 'Chrome', 'Word', 'Kaspi'], 0),
      _tf('q', 'Құпия сөзді бейтаныс адамға беруге болмайды.', true),
      _mc('q', 'Сайтты ашатын бағдарлама?', ['Браузер', 'Принтер', 'Сканер', 'Динамик'], 0),
      _mp('q', 'Сәйкестендір:', [
        _pair('Принтер', 'Шығару'),
        _pair('Пернетақта', 'Енгізу'),
        _pair('Wi-Fi', 'Интернет'),
      ]),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_jobs',
    title: 'Әйгілі адамдар: Стив Джобс',
    description: 'Apple компаниясының негізін қалаушы туралы.',
    type: NodeType.lesson,
    order: 8,
    questions: [
      _mc('q', 'Стив Джобс қай компанияны құрды?', [
        'Apple',
        'Microsoft',
        'Google',
        'Kaspi',
      ], 0),
      _mc('q', 'Apple шығаратын әйгілі телефон?', [
        'iPhone',
        'Galaxy',
        'Nokia',
        'Mi',
      ], 0),
      _tf('q', 'Стив Джобс iPhone-ды әлемге таныстырды.', true),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_gates',
    title: 'Әйгілі адамдар: Билл Гейтс',
    description: 'Microsoft негізін қалаушы және қайырымдылық.',
    type: NodeType.lesson,
    order: 9,
    questions: [
      _mc('q', 'Билл Гейтс қай компанияны құрды?', [
        'Microsoft',
        'Apple',
        'Tesla',
        'Kolesa',
      ], 0),
      _mc('q', 'Microsoft-тың әйгілі операциялық жүйесі?', [
        'Windows',
        'Android',
        'iOS',
        'Linux',
      ], 0),
      _tf('q', 'Билл Гейтс қайырымдылықпен де айналысады.', true),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_treasure',
    title: 'Жасырын қазына',
    description: 'Білім сандығын аш!',
    type: NodeType.treasure,
    order: 10,
    questions: [
      _mc('q', '«Бит» пен «байт» — нені өлшейді?', [
        'Ақпарат көлемін',
        'Салмақты',
        'Уақытты',
        'Қашықтықты',
      ], 0),
      _tf('q', '1 байт = 8 бит.', true),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_ai',
    title: 'Жасанды интеллект',
    description: 'AI деген не және ол қайда қолданылады?',
    type: NodeType.lesson,
    order: 11,
    questions: [
      _mc('q', 'Жасанды интеллект (AI) дегеніміз не?', [
        'Адам сияқты «ойлай» алатын бағдарлама',
        'Жаңа телефон',
        'Интернет браузері',
        'Пернетақта',
      ], 0),
      _mc('q', 'Қайсысы AI көмекшісі?', [
        'Дауыстық көмекші',
        'Принтер',
        'Тінтуір',
        'Қағаз',
      ], 0),
      _tf('q', 'AI суреттерді танып, аударма жасай алады.', true),
      _fb('q', 'AI — ___ интеллект деген сөз.',
          ['жасанды', 'табиғи', 'ескі'], 0),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_python',
    title: 'Python-мен танысу',
    description: 'Алғашқы бағдарламалау тіліңмен таныс.',
    type: NodeType.quiz,
    order: 12,
    questions: [
      _mc('q', 'Python дегеніміз не?', [
        'Бағдарламалау тілі',
        'Жылан ойыны ғана',
        'Телефон',
        'Браузер',
      ], 0),
      _mc('q', 'Экранға мәтін шығаратын команда?', [
        'print()',
        'run()',
        'open()',
        'click()',
      ], 0, 'print() жақшаның ішіндегі мәтінді экранға шығарады.'),
      _tf('q', 'Python — үйренуге оңай тіл саналады.', true),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_kaspi',
    title: 'Қазақстандық IT: Kaspi.kz',
    description: 'Біздің елдің ең танымал қосымшасы.',
    type: NodeType.lesson,
    order: 13,
    questions: [
      _mc('q', 'Kaspi.kz негізінен не үшін қолданылады?', [
        'Төлемдер мен сатып алу',
        'Ойын ойнау',
        'Аударма жасау',
        'Сурет салу',
      ], 0),
      _tf('q', 'Kaspi.kz — қазақстандық компания.', true),
      _mc('q', 'Kaspi QR не үшін қажет?', [
        'Тез төлеу',
        'Сурет түсіру',
        'Ән тыңдау',
        'Хабарлама жазу',
      ], 0),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_kolesa',
    title: 'Қазақстандық IT: Kolesa.kz',
    description: 'Хабарландыру платформалары туралы.',
    type: NodeType.lesson,
    order: 14,
    questions: [
      _mc('q', 'Kolesa.kz-те негізінен не сатылады?', [
        'Көліктер',
        'Тағам',
        'Кітаптар',
        'Билеттер',
      ], 0),
      _tf('q', 'Kolesa.kz — хабарландыру сайты.', true),
    ],
  ),
  _node(
    moduleId: _infoG5,
    id: 'info_boss_champion',
    title: 'Информатика чемпионы',
    description: 'Соңғы босс! Барлық білгеніңмен жең.',
    type: NodeType.boss,
    order: 15,
    questions: [
      _mc('q', 'Python — бұл...', ['Бағдарламалау тілі', 'Браузер', 'Телефон', 'Принтер'], 0),
      _mc('q', 'Kaspi.kz қай елдікі?', ['Қазақстан', 'АҚШ', 'Жапония', 'Франция'], 0),
      _mc('q', 'AI дегеніміз?', ['Жасанды интеллект', 'Жаңа ойын', 'Браузер', 'Принтер'], 0),
      _tf('q', '1 байт 8 биттен тұрады.', true),
      _mc('q', 'Apple-ді кім құрды?', ['Стив Джобс', 'Билл Гейтс', 'Илон Маск', 'Марк Цукерберг'], 0),
      _mp('q', 'Компания мен өнімді сәйкестендір:', [
        _pair('Apple', 'iPhone'),
        _pair('Microsoft', 'Windows'),
        _pair('Kaspi', 'Төлем'),
      ]),
    ],
  ),
];

// ═════════════════════════════════════════════════════════════════════════
// МАТЕМАТИКА (grade 5)
// ═════════════════════════════════════════════════════════════════════════

const _mathG5 = 'math_g5';

final List<LearnNode> _mathG5Nodes = [
  _node(
    moduleId: _mathG5,
    id: 'math_natural',
    title: 'Натурал сандар',
    description: 'Санау сандарымен танысу.',
    type: NodeType.lesson,
    order: 0,
    questions: [
      _mc('q', 'Қайсысы натурал сан?', ['7', '0', '-3', '0.5'], 0),
      _tf('q', '15 саны 10-нан үлкен.', true),
      _fb('q', '9-дан кейінгі сан — ___.', ['10', '8', '11'], 0),
      _mc('q', 'Ең кіші натурал сан?', ['1', '0', '-1', '10'], 0),
    ],
  ),
  _node(
    moduleId: _mathG5,
    id: 'math_add',
    title: 'Қосу және азайту',
    description: 'Сандарды қосып, азайтуды жаттық.',
    type: NodeType.lesson,
    order: 1,
    questions: [
      _mc('q', '24 + 18 = ?', ['42', '32', '44', '40'], 0),
      _mc('q', '50 − 27 = ?', ['23', '33', '27', '24'], 0),
      _fb('q', '100 − 60 = ___.', ['40', '60', '160'], 0),
      _tf('q', '12 + 8 = 20.', true),
    ],
  ),
  _node(
    moduleId: _mathG5,
    id: 'math_mult',
    title: 'Көбейту',
    description: 'Көбейту кестесін бекіт.',
    type: NodeType.quiz,
    order: 2,
    questions: [
      _mc('q', '7 × 8 = ?', ['56', '54', '63', '49'], 0),
      _mc('q', '9 × 6 = ?', ['54', '56', '45', '63'], 0),
      _fb('q', '6 × 6 = ___.', ['36', '30', '42'], 0),
      _tf('q', '5 × 5 = 25.', true),
    ],
  ),
  _node(
    moduleId: _mathG5,
    id: 'math_div',
    title: 'Бөлу',
    description: 'Бөлу амалын меңгер.',
    type: NodeType.quiz,
    order: 3,
    questions: [
      _mc('q', '56 ÷ 7 = ?', ['8', '7', '9', '6'], 0),
      _mc('q', '81 ÷ 9 = ?', ['9', '8', '7', '6'], 0),
      _tf('q', '20 ÷ 4 = 5.', true),
    ],
  ),
  _node(
    moduleId: _mathG5,
    id: 'math_fractions',
    title: 'Бөлшектермен танысу',
    description: 'Бөлшек дегеніміз не?',
    type: NodeType.lesson,
    order: 4,
    questions: [
      _mc('q', '½ + ½ = ?', ['1', '½', '¼', '2'], 0),
      _tf('q', '½ — бүтіннің жартысы.', true),
      _mc('q', 'Қайсысы үлкенірек: ½ әлде ¼?', ['½', '¼', 'Тең', 'Білмеймін'], 0),
    ],
  ),
  _node(
    moduleId: _mathG5,
    id: 'math_geometry',
    title: 'Қарапайым геометрия',
    description: 'Фигуралармен таныс.',
    type: NodeType.lesson,
    order: 5,
    questions: [
      _mc('q', 'Үшбұрыштың неше қабырғасы бар?', ['3', '4', '5', '6'], 0),
      _mc('q', 'Квадраттың неше бұрышы бар?', ['4', '3', '5', '6'], 0),
      _mp('q', 'Фигураны қабырға санымен сәйкестендір:', [
        _pair('Үшбұрыш', '3'),
        _pair('Шаршы', '4'),
        _pair('Бесбұрыш', '5'),
      ]),
    ],
  ),
  _node(
    moduleId: _mathG5,
    id: 'math_word',
    title: 'Мәтінді есептер',
    description: 'Өмірлік есептерді шеш.',
    type: NodeType.quiz,
    order: 6,
    questions: [
      _mc('q', 'Алмада 12 алма бар, 5-ін берді. Қанша қалды?',
          ['7', '5', '17', '6'], 0),
      _mc('q', '3 қорапта 4-тен қалам. Барлығы қанша?',
          ['12', '7', '9', '16'], 0),
    ],
  ),
  _node(
    moduleId: _mathG5,
    id: 'math_boss',
    title: 'Математика айдаһары',
    description: 'Боссты жеңіп, модульді аяқта!',
    type: NodeType.boss,
    order: 7,
    questions: [
      _mc('q', '8 × 7 = ?', ['56', '54', '64', '49'], 0),
      _mc('q', '63 ÷ 9 = ?', ['7', '8', '9', '6'], 0),
      _mc('q', '45 + 38 = ?', ['83', '73', '85', '93'], 0),
      _tf('q', 'Үшбұрышта 3 қабырға бар.', true),
      _mc('q', '½ + ½ = ?', ['1', '0', '½', '2'], 0),
    ],
  ),
];

// МАТЕМАТИКА (grade 6) — a second module, so the map shows an inter-grade banner.

const _mathG6 = 'math_g6';

final List<LearnNode> _mathG6Nodes = [
  _node(
    moduleId: _mathG6,
    id: 'math6_negative',
    title: 'Теріс сандар',
    description: 'Нөлден кіші сандармен таныс.',
    type: NodeType.lesson,
    order: 0,
    questions: [
      _mc('q', 'Қайсысы теріс сан?', ['-5', '3', '0', '8'], 0),
      _tf('q', '-7 саны 0-ден кіші.', true),
      _mc('q', '-3 пен 2-нің қайсысы үлкен?', ['2', '-3', 'Тең', 'Білмеймін'], 0),
    ],
  ),
  _node(
    moduleId: _mathG6,
    id: 'math6_percent',
    title: 'Пайыз',
    description: 'Пайыздарды есептеуді үйрен.',
    type: NodeType.quiz,
    order: 1,
    questions: [
      _mc('q', '100-дің 50%-ы?', ['50', '5', '500', '25'], 0),
      _mc('q', '200-дің 10%-ы?', ['20', '2', '100', '10'], 0),
      _fb('q', '100-дің 25%-ы — ___.', ['25', '50', '75'], 0),
    ],
  ),
  _node(
    moduleId: _mathG6,
    id: 'math6_boss',
    title: '6-сынып айдаһары',
    description: 'Жаңа модульдің боссы!',
    type: NodeType.boss,
    order: 2,
    questions: [
      _mc('q', '-4 + 6 = ?', ['2', '-2', '10', '-10'], 0),
      _mc('q', '300-дің 20%-ы?', ['60', '6', '30', '600'], 0),
      _tf('q', '-1 саны теріс сан.', true),
    ],
  ),
];

// ═════════════════════════════════════════════════════════════════════════
// ҚАЗАҚ ТІЛІ (grade 5)
// ═════════════════════════════════════════════════════════════════════════

const _kazG5 = 'kaz_g5';

final List<LearnNode> _kazakhG5Nodes = [
  _node(
    moduleId: _kazG5,
    id: 'kaz_sounds',
    title: 'Дыбыс пен әріп',
    description: 'Дауысты және дауыссыз дыбыстар.',
    type: NodeType.lesson,
    order: 0,
    questions: [
      _mc('q', 'Қайсысы дауысты дыбыс?', ['А', 'Б', 'С', 'Т'], 0),
      _tf('q', '«М» — дауыссыз дыбыс.', true),
      _fb('q', '«Ана» сөзінде ___ дауысты дыбыс бар.', ['екі', 'бір', 'үш'], 0),
    ],
  ),
  _node(
    moduleId: _kazG5,
    id: 'kaz_noun',
    title: 'Зат есім',
    description: 'Заттың атын білдіретін сөздер.',
    type: NodeType.lesson,
    order: 1,
    questions: [
      _mc('q', 'Қайсысы зат есім?', ['Кітап', 'Жүгірді', 'Әдемі', 'Тез'], 0),
      _tf('q', '«Мектеп» — зат есім.', true),
      _mc('q', 'Зат есім нені білдіреді?', [
        'Заттың атын',
        'Қимылды',
        'Санды',
        'Түсті',
      ], 0),
    ],
  ),
  _node(
    moduleId: _kazG5,
    id: 'kaz_verb',
    title: 'Етістік',
    description: 'Қимыл-әрекетті білдіретін сөздер.',
    type: NodeType.quiz,
    order: 2,
    questions: [
      _mc('q', 'Қайсысы етістік?', ['Оқыды', 'Дәптер', 'Биік', 'Сары'], 0),
      _fb('q', 'Бала кітап ___.', ['оқыды', 'кітап', 'үстел'], 0),
      _tf('q', '«Жазды» — етістік.', true),
    ],
  ),
  _node(
    moduleId: _kazG5,
    id: 'kaz_adj',
    title: 'Сын есім',
    description: 'Заттың сын-сипатын білдіреді.',
    type: NodeType.lesson,
    order: 3,
    questions: [
      _mc('q', 'Қайсысы сын есім?', ['Әдемі', 'Жүгірді', 'Кітап', 'Үш'], 0),
      _mp('q', 'Сөзді табымен сәйкестендір:', [
        _pair('Үй', 'Зат есім'),
        _pair('Келді', 'Етістік'),
        _pair('Биік', 'Сын есім'),
      ]),
    ],
  ),
  _node(
    moduleId: _kazG5,
    id: 'kaz_sentence',
    title: 'Сөйлем құрау',
    description: 'Сөздерден сөйлем құрастыр.',
    type: NodeType.quiz,
    order: 4,
    questions: [
      _mc('q', 'Сөйлем соңында қандай белгі қойылады?', ['Нүкте', 'Үтір', 'Сызықша', 'Жақша'], 0),
      _tf('q', 'Сөйлем бас әріптен басталады.', true),
      _fb('q', 'Мен мектепке ___.', ['барамын', 'кітап', 'әдемі'], 0),
    ],
  ),
  _node(
    moduleId: _kazG5,
    id: 'kaz_boss',
    title: 'Тіл шебері',
    description: 'Боссты жең — сөз таптарын мегер!',
    type: NodeType.boss,
    order: 5,
    questions: [
      _mc('q', 'Қайсысы зат есім?', ['Дала', 'Жүгірді', 'Биік', 'Тез'], 0),
      _mc('q', 'Қайсысы етістік?', ['Келді', 'Дәптер', 'Сары', 'Үй'], 0),
      _tf('q', '«А» — дауысты дыбыс.', true),
      _mc('q', 'Сөйлем соңындағы белгі?', ['Нүкте', 'Жұлдызша', 'Жақша', 'Доллар'], 0),
    ],
  ),
];

// ═════════════════════════════════════════════════════════════════════════
// АҒЫЛШЫН ТІЛІ (grade 5)
// ═════════════════════════════════════════════════════════════════════════

const _engG5 = 'eng_g5';

final List<LearnNode> _englishG5Nodes = [
  _node(
    moduleId: _engG5,
    id: 'eng_greetings',
    title: 'Greetings — Сәлемдесу',
    description: 'Ағылшынша сәлемдесуді үйрен.',
    type: NodeType.lesson,
    order: 0,
    questions: [
      _mc('q', '«Сәлем» ағылшынша қалай?', ['Hello', 'Goodbye', 'Thanks', 'Sorry'], 0),
      _mc('q', '«Рахмет» ағылшынша?', ['Thank you', 'Hello', 'Please', 'Yes'], 0),
      _tf('q', '«Goodbye» — қоштасу сөзі.', true),
    ],
  ),
  _node(
    moduleId: _engG5,
    id: 'eng_numbers',
    title: 'Numbers — Сандар',
    description: '1–10 сандарын ағылшынша біл.',
    type: NodeType.lesson,
    order: 1,
    questions: [
      _mc('q', '«Үш» ағылшынша?', ['Three', 'Two', 'Five', 'Ten'], 0),
      _fb('q', 'One, two, ___.', ['three', 'four', 'ten'], 0),
      _mp('q', 'Санды сәйкестендір:', [
        _pair('1', 'One'),
        _pair('2', 'Two'),
        _pair('5', 'Five'),
      ]),
    ],
  ),
  _node(
    moduleId: _engG5,
    id: 'eng_colors',
    title: 'Colors — Түстер',
    description: 'Негізгі түстерді ағылшынша айт.',
    type: NodeType.quiz,
    order: 2,
    questions: [
      _mc('q', '«Қызыл» ағылшынша?', ['Red', 'Blue', 'Green', 'Black'], 0),
      _mc('q', '«Көк» ағылшынша?', ['Blue', 'Red', 'Yellow', 'White'], 0),
      _tf('q', '«Green» — жасыл түс.', true),
    ],
  ),
  _node(
    moduleId: _engG5,
    id: 'eng_family',
    title: 'Family — Отбасы',
    description: 'Отбасы мүшелерінің атаулары.',
    type: NodeType.lesson,
    order: 3,
    questions: [
      _mc('q', '«Ана» ағылшынша?', ['Mother', 'Father', 'Sister', 'Brother'], 0),
      _mc('q', '«Әке» ағылшынша?', ['Father', 'Mother', 'Son', 'Aunt'], 0),
      _mp('q', 'Сәйкестендір:', [
        _pair('Mother', 'Ана'),
        _pair('Father', 'Әке'),
        _pair('Sister', 'Әпке'),
      ]),
    ],
  ),
  _node(
    moduleId: _engG5,
    id: 'eng_boss',
    title: 'English Master',
    description: 'Боссты жең — сөздіктеріңді тексер!',
    type: NodeType.boss,
    order: 4,
    questions: [
      _mc('q', '«Hello» нені білдіреді?', ['Сәлем', 'Сау бол', 'Рахмет', 'Кешір'], 0),
      _mc('q', '«Red» қай түс?', ['Қызыл', 'Көк', 'Жасыл', 'Сары'], 0),
      _mc('q', '«Mother» — кім?', ['Ана', 'Әке', 'Аға', 'Әпке'], 0),
      _tf('q', '«Three» — үш саны.', true),
    ],
  ),
];

// ═════════════════════════════════════════════════════════════════════════
// ФИЗИКА (grade 7)
// ═════════════════════════════════════════════════════════════════════════

const _physG7 = 'phys_g7';

final List<LearnNode> _physicsG7Nodes = [
  _node(
    moduleId: _physG7,
    id: 'phys_intro',
    title: 'Физика деген не?',
    description: 'Табиғат туралы ғылыммен таныс.',
    type: NodeType.lesson,
    order: 0,
    questions: [
      _mc('q', 'Физика нені зерттейді?', [
        'Табиғат құбылыстарын',
        'Тек жануарларды',
        'Тек сандарды',
        'Тек тілдерді',
      ], 0),
      _tf('q', 'Жарық пен дыбыс — физикалық құбылыстар.', true),
    ],
  ),
  _node(
    moduleId: _physG7,
    id: 'phys_mass',
    title: 'Масса',
    description: 'Дененің массасы туралы.',
    type: NodeType.lesson,
    order: 1,
    questions: [
      _mc('q', 'Масса қандай бірлікпен өлшенеді?', ['Килограмм', 'Метр', 'Секунд', 'Литр'], 0),
      _mc('q', 'Массаны немен өлшейді?', ['Таразы', 'Сызғыш', 'Термометр', 'Сағат'], 0),
      _tf('q', 'Массаны таразымен өлшейді.', true),
    ],
  ),
  _node(
    moduleId: _physG7,
    id: 'phys_volume',
    title: 'Көлем',
    description: 'Дене алып тұрған кеңістік.',
    type: NodeType.quiz,
    order: 2,
    questions: [
      _mc('q', 'Көлем бірлігі?', ['Текше метр', 'Килограмм', 'Секунд', 'Ампер'], 0),
      _tf('q', 'Сұйықтың көлемін мензуркамен өлшеуге болады.', true),
    ],
  ),
  _node(
    moduleId: _physG7,
    id: 'phys_density',
    title: 'Тығыздық',
    description: 'Масса мен көлемнің байланысы.',
    type: NodeType.lesson,
    order: 3,
    questions: [
      _mc('q', 'Тығыздық қалай табылады?', [
        'Массаны көлемге бөлу',
        'Массаны қосу',
        'Көлемді көбейту',
        'Уақытқа бөлу',
      ], 0),
      _tf('q', 'Темір судан тығыз.', true),
    ],
  ),
  _node(
    moduleId: _physG7,
    id: 'phys_force',
    title: 'Күш',
    description: 'Денеге әсер ететін күш.',
    type: NodeType.quiz,
    order: 4,
    questions: [
      _mc('q', 'Күш бірлігі?', ['Ньютон', 'Джоуль', 'Ватт', 'Вольт'], 0),
      _tf('q', 'Ауырлық күші денені жерге тартады.', true),
      _fb('q', 'Күш ___ деген бірлікпен өлшенеді.', ['Ньютон', 'Метр', 'Литр'], 0),
    ],
  ),
  _node(
    moduleId: _physG7,
    id: 'phys_boss',
    title: 'Физика алыбы',
    description: 'Боссты жең — заңдарды мегер!',
    type: NodeType.boss,
    order: 5,
    questions: [
      _mc('q', 'Масса бірлігі?', ['Килограмм', 'Метр', 'Ньютон', 'Литр'], 0),
      _mc('q', 'Күш бірлігі?', ['Ньютон', 'Джоуль', 'Грамм', 'Секунд'], 0),
      _mc('q', 'Тығыздық = масса ÷ ?', ['Көлем', 'Уақыт', 'Күш', 'Жылдамдық'], 0),
      _tf('q', 'Физика табиғатты зерттейді.', true),
    ],
  ),
];

// ═════════════════════════════════════════════════════════════════════════
// The subject catalog
// ═════════════════════════════════════════════════════════════════════════

final List<Subject> kCurriculum = [
  Subject(
    id: 'math',
    name: 'Математика',
    emoji: '🔢',
    color: AppColors.primary,
    gradient: _g(const [AppColors.primaryLight, AppColors.primary, AppColors.primaryDark]),
    modules: [
      CurriculumModule(
        id: _mathG5,
        subjectId: 'math',
        grade: 5,
        title: '5-сынып',
        nodes: _mathG5Nodes,
      ),
      CurriculumModule(
        id: _mathG6,
        subjectId: 'math',
        grade: 6,
        title: '6-сынып',
        nodes: _mathG6Nodes,
      ),
    ],
  ),
  Subject(
    id: 'kazakh',
    name: 'Қазақ тілі',
    emoji: '📖',
    color: AppColors.success,
    gradient: _g(const [AppColors.successLight, AppColors.success, Color(0xFF00A074)]),
    modules: [
      CurriculumModule(
        id: _kazG5,
        subjectId: 'kazakh',
        grade: 5,
        title: '5-сынып',
        nodes: _kazakhG5Nodes,
      ),
    ],
  ),
  Subject(
    id: 'english',
    name: 'Ағылшын тілі',
    emoji: '🇬🇧',
    color: AppColors.secondary,
    gradient: _g(const [AppColors.secondaryLight, AppColors.secondary, AppColors.secondaryDark]),
    modules: [
      CurriculumModule(
        id: _engG5,
        subjectId: 'english',
        grade: 5,
        title: '5-сынып',
        nodes: _englishG5Nodes,
      ),
    ],
  ),
  Subject(
    id: 'physics',
    name: 'Физика',
    emoji: '⚛️',
    color: AppColors.warning,
    gradient: _g(const [Color(0xFFFFC542), AppColors.warning, Color(0xFFEF7A00)]),
    modules: [
      CurriculumModule(
        id: _physG7,
        subjectId: 'physics',
        grade: 7,
        title: '7-сынып',
        nodes: _physicsG7Nodes,
      ),
    ],
  ),
  Subject(
    id: 'informatics',
    name: 'Информатика',
    emoji: '💻',
    color: AppColors.info,
    gradient: _g(const [Color(0xFF22D3EE), AppColors.info, Color(0xFF065F73)]),
    modules: [
      CurriculumModule(
        id: _infoG5,
        subjectId: 'informatics',
        grade: 5,
        title: '5-сынып',
        nodes: _informaticsG5Nodes,
      ),
    ],
  ),
];

// ─────────────────────────────────────────────────────────────────────────
// Lookups
// ─────────────────────────────────────────────────────────────────────────

Subject? subjectById(String id) {
  for (final s in kCurriculum) {
    if (s.id == id) return s;
  }
  return null;
}

LearnNode? nodeById(String subjectId, String nodeId) {
  final subject = subjectById(subjectId);
  if (subject == null) return null;
  for (final n in subject.allNodes) {
    if (n.id == nodeId) return n;
  }
  return null;
}
