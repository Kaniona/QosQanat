/// Level progression for QosQanat (levels 1–100).
///
/// Cumulative XP to *reach* level n:
///   xpRequired(n) = (n - 1) * 100 + (n - 1)^2 * 10
/// Coin reward granted on reaching level n: n * 20.
library;

/// Maximum attainable level.
const int kMaxLevel = 100;

/// Info about a single level.
class LevelInfo {
  const LevelInfo({
    required this.level,
    required this.title,
    required this.xpRequired,
    required this.coinReward,
  });

  final int level;
  final String title;

  /// Cumulative XP needed to reach this level.
  final int xpRequired;

  /// Coins granted when this level is reached.
  final int coinReward;
}

/// Cumulative XP required to reach [level] (clamped to 1..100).
int xpRequiredFor(int level) {
  final n = level.clamp(1, kMaxLevel);
  final m = n - 1;
  return m * 100 + m * m * 10;
}

/// Coins granted on reaching [level].
int coinRewardFor(int level) => level.clamp(1, kMaxLevel) * 20;

/// Kazakh title for a given [level], by range.
String levelTitle(int level) {
  final n = level.clamp(1, kMaxLevel);
  if (n >= 100) return 'QosQanat Чемпионы';
  if (n >= 91) return 'Легенда';
  if (n >= 76) return 'Ұлы оқушы';
  if (n >= 61) return 'Данышпан';
  if (n >= 51) return 'Ғалым шәкірт';
  if (n >= 41) return 'Білімнің шебері';
  if (n >= 31) return 'Озық оқушы';
  if (n >= 21) return 'Данышпан шәкірт';
  if (n >= 16) return 'Білімдар';
  if (n >= 11) return 'Ақылды оқушы';
  if (n >= 6) return 'Білімгер';
  return 'Жас оқушы';
}

/// Full info for [level].
LevelInfo getLevelInfo(int level) {
  final n = level.clamp(1, kMaxLevel);
  return LevelInfo(
    level: n,
    title: levelTitle(n),
    xpRequired: xpRequiredFor(n),
    coinReward: coinRewardFor(n),
  );
}

/// The current level for a given [totalXp].
int calculateLevel(int totalXp) {
  for (var n = kMaxLevel; n >= 1; n--) {
    if (totalXp >= xpRequiredFor(n)) return n;
  }
  return 1;
}

/// Precomputed table for levels 1..100.
final List<LevelInfo> levelTable =
    List<LevelInfo>.generate(kMaxLevel, (i) => getLevelInfo(i + 1));
