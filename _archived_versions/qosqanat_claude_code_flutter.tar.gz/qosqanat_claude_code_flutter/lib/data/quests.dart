/// Daily quest pool and login-streak milestone rewards.
library;

/// What player action advances a quest.
enum QuestTrigger {
  login,
  taskComplete,
  perfectTask,
  battlePlayed,
  battleWon,
  purchase,
  friendAdded,
}

/// Definition of a daily quest (static template; per-day progress lives in the
/// daily_quests table / DailyQuest model).
class QuestDef {
  const QuestDef({
    required this.id,
    required this.title,
    required this.description,
    required this.trigger,
    required this.target,
    this.coinReward = 0,
    this.xpReward = 0,
    this.akylReward = 0,
    required this.emoji,
  });

  final String id;
  final String title;
  final String description;
  final QuestTrigger trigger;
  final int target;
  final int coinReward;
  final int xpReward;
  final int akylReward;
  final String emoji;
}

/// The full pool of daily quests.
const List<QuestDef> kDailyQuests = [
  QuestDef(
    id: 'daily_login',
    title: 'Бүгінгі кіру',
    description: 'Бүгін қосымшаға кір',
    trigger: QuestTrigger.login,
    target: 1,
    coinReward: 10,
    xpReward: 10,
    emoji: '👋',
  ),
  QuestDef(
    id: 'first_task',
    title: 'Алғашқы тапсырма',
    description: 'Бір тапсырма орында',
    trigger: QuestTrigger.taskComplete,
    target: 1,
    coinReward: 15,
    xpReward: 20,
    emoji: '✏️',
  ),
  QuestDef(
    id: 'active_student',
    title: 'Белсенді оқушы',
    description: 'Үш тапсырма орында',
    trigger: QuestTrigger.taskComplete,
    target: 3,
    coinReward: 30,
    xpReward: 50,
    akylReward: 5,
    emoji: '📚',
  ),
  QuestDef(
    id: 'knowledge_seeker',
    title: 'Білімқор',
    description: 'Бес тапсырма орында',
    trigger: QuestTrigger.taskComplete,
    target: 5,
    coinReward: 50,
    xpReward: 80,
    akylReward: 10,
    emoji: '🧠',
  ),
  QuestDef(
    id: 'flawless',
    title: 'Мінсіз орындаушы',
    description: 'Бір тапсырманы мінсіз орында',
    trigger: QuestTrigger.perfectTask,
    target: 1,
    coinReward: 20,
    xpReward: 30,
    emoji: '⭐',
  ),
  QuestDef(
    id: 'social_student',
    title: 'Социалды оқушы',
    description: 'Бір шайқасқа қатыс',
    trigger: QuestTrigger.battlePlayed,
    target: 1,
    coinReward: 20,
    xpReward: 25,
    emoji: '⚔️',
  ),
  QuestDef(
    id: 'winner',
    title: 'Жеңімпаз',
    description: 'Бір шайқаста жең',
    trigger: QuestTrigger.battleWon,
    target: 1,
    coinReward: 40,
    xpReward: 50,
    emoji: '🏆',
  ),
  QuestDef(
    id: 'shopper',
    title: 'Дүкен барушы',
    description: 'Дүкеннен бір зат сатып ал',
    trigger: QuestTrigger.purchase,
    target: 1,
    coinReward: 15,
    emoji: '🛍️',
  ),
  QuestDef(
    id: 'made_friend',
    title: 'Дос тапты',
    description: 'Бір дос қос',
    trigger: QuestTrigger.friendAdded,
    target: 1,
    coinReward: 25,
    xpReward: 30,
    emoji: '🤝',
  ),
];

/// A login-streak milestone and its coin reward.
class StreakMilestone {
  const StreakMilestone({required this.days, required this.coinReward});
  final int days;
  final int coinReward;
}

/// Streak milestones, ascending by day count.
const List<StreakMilestone> kStreakMilestones = [
  StreakMilestone(days: 3, coinReward: 50),
  StreakMilestone(days: 7, coinReward: 150),
  StreakMilestone(days: 14, coinReward: 300),
  StreakMilestone(days: 30, coinReward: 1000),
  StreakMilestone(days: 60, coinReward: 2500),
  StreakMilestone(days: 100, coinReward: 5000),
];

/// Coin reward if [streakDays] exactly hits a milestone, else 0.
int streakMilestoneCoins(int streakDays) {
  for (final m in kStreakMilestones) {
    if (m.days == streakDays) return m.coinReward;
  }
  return 0;
}

/// The next milestone after [streakDays], or null if past the last one.
StreakMilestone? nextStreakMilestone(int streakDays) {
  for (final m in kStreakMilestones) {
    if (m.days > streakDays) return m;
  }
  return null;
}
