/// Achievement catalog (35 achievements across six categories).
library;

/// Achievement grouping.
enum AchievementCategory { learning, battle, collection, friends, streak, special }

/// The player metric an achievement is measured against.
enum AchievementMetric {
  tasksCompleted,
  perfectTasks,
  level,
  battlesWon,
  battlesPlayed,
  itemsOwned,
  petsOwned,
  friends,
  streakDays,
  akylPoints,
  coinsEarned,
  special,
}

/// Snapshot of the player's stats used to evaluate achievement conditions.
class AchievementStats {
  const AchievementStats({
    this.tasksCompleted = 0,
    this.perfectTasks = 0,
    this.level = 1,
    this.battlesWon = 0,
    this.battlesPlayed = 0,
    this.itemsOwned = 0,
    this.petsOwned = 0,
    this.friends = 0,
    this.streakDays = 0,
    this.akylPoints = 0,
    this.coinsEarned = 0,
  });

  final int tasksCompleted;
  final int perfectTasks;
  final int level;
  final int battlesWon;
  final int battlesPlayed;
  final int itemsOwned;
  final int petsOwned;
  final int friends;
  final int streakDays;
  final int akylPoints;
  final int coinsEarned;

  int valueFor(AchievementMetric metric) {
    switch (metric) {
      case AchievementMetric.tasksCompleted:
        return tasksCompleted;
      case AchievementMetric.perfectTasks:
        return perfectTasks;
      case AchievementMetric.level:
        return level;
      case AchievementMetric.battlesWon:
        return battlesWon;
      case AchievementMetric.battlesPlayed:
        return battlesPlayed;
      case AchievementMetric.itemsOwned:
        return itemsOwned;
      case AchievementMetric.petsOwned:
        return petsOwned;
      case AchievementMetric.friends:
        return friends;
      case AchievementMetric.streakDays:
        return streakDays;
      case AchievementMetric.akylPoints:
        return akylPoints;
      case AchievementMetric.coinsEarned:
        return coinsEarned;
      case AchievementMetric.special:
        return 0;
    }
  }
}

/// Static definition of an achievement.
class AchievementDef {
  const AchievementDef({
    required this.id,
    required this.title,
    required this.description,
    required this.emoji,
    required this.category,
    required this.metric,
    required this.threshold,
    required this.coinReward,
  });

  final String id;
  final String title;
  final String description;
  final String emoji;
  final AchievementCategory category;
  final AchievementMetric metric;
  final int threshold;
  final int coinReward;

  /// Whether [stats] satisfy this achievement (special ones unlock manually).
  bool isUnlockedBy(AchievementStats stats) {
    if (metric == AchievementMetric.special) return false;
    return stats.valueFor(metric) >= threshold;
  }

  /// Progress toward unlock, 0..1.
  double progress(AchievementStats stats) {
    if (metric == AchievementMetric.special || threshold == 0) return 0;
    return (stats.valueFor(metric) / threshold).clamp(0, 1);
  }
}

/// The complete achievement catalog.
const List<AchievementDef> kAchievements = [
  // ─── Learning ──────────────────────────────────────────────────────────
  AchievementDef(
    id: 'first_step',
    title: 'Алғашқы қадам',
    description: 'Алғашқы тапсырмаңды орында',
    emoji: '🎯',
    category: AchievementCategory.learning,
    metric: AchievementMetric.tasksCompleted,
    threshold: 1,
    coinReward: 20,
  ),
  AchievementDef(
    id: 'learning_path',
    title: 'Білім жолы',
    description: '10 тапсырма орында',
    emoji: '📚',
    category: AchievementCategory.learning,
    metric: AchievementMetric.tasksCompleted,
    threshold: 10,
    coinReward: 50,
  ),
  AchievementDef(
    id: 'knowledge_lover',
    title: 'Білімқор',
    description: '50 тапсырма орында',
    emoji: '📖',
    category: AchievementCategory.learning,
    metric: AchievementMetric.tasksCompleted,
    threshold: 50,
    coinReward: 150,
  ),
  AchievementDef(
    id: 'knowledge_hungry',
    title: 'Білім құмар',
    description: '100 тапсырма орында',
    emoji: '🧠',
    category: AchievementCategory.learning,
    metric: AchievementMetric.tasksCompleted,
    threshold: 100,
    coinReward: 300,
  ),
  AchievementDef(
    id: 'scholar_master',
    title: 'Ғұлама',
    description: '500 тапсырма орында',
    emoji: '🎓',
    category: AchievementCategory.learning,
    metric: AchievementMetric.tasksCompleted,
    threshold: 500,
    coinReward: 1000,
  ),
  AchievementDef(
    id: 'flawless_one',
    title: 'Мінсіз',
    description: 'Тапсырманы мінсіз орында',
    emoji: '⭐',
    category: AchievementCategory.learning,
    metric: AchievementMetric.perfectTasks,
    threshold: 1,
    coinReward: 30,
  ),
  AchievementDef(
    id: 'sharp_shooter',
    title: 'Дәл мерген',
    description: '25 тапсырманы мінсіз орында',
    emoji: '🎯',
    category: AchievementCategory.learning,
    metric: AchievementMetric.perfectTasks,
    threshold: 25,
    coinReward: 200,
  ),
  AchievementDef(
    id: 'level_10',
    title: 'Оныншы белес',
    description: '10-деңгейге жет',
    emoji: '🔟',
    category: AchievementCategory.learning,
    metric: AchievementMetric.level,
    threshold: 10,
    coinReward: 100,
  ),
  AchievementDef(
    id: 'level_25',
    title: 'Жоғары өрлеу',
    description: '25-деңгейге жет',
    emoji: '📈',
    category: AchievementCategory.learning,
    metric: AchievementMetric.level,
    threshold: 25,
    coinReward: 250,
  ),
  AchievementDef(
    id: 'level_50',
    title: 'Жарты жол',
    description: '50-деңгейге жет',
    emoji: '🏔️',
    category: AchievementCategory.learning,
    metric: AchievementMetric.level,
    threshold: 50,
    coinReward: 500,
  ),

  // ─── Battle ────────────────────────────────────────────────────────────
  AchievementDef(
    id: 'first_battle',
    title: 'Алғашқы шайқас',
    description: 'Бір Ақыл Батлға қатыс',
    emoji: '⚔️',
    category: AchievementCategory.battle,
    metric: AchievementMetric.battlesPlayed,
    threshold: 1,
    coinReward: 25,
  ),
  AchievementDef(
    id: 'first_win',
    title: 'Жеңімпаз',
    description: 'Бір шайқаста жең',
    emoji: '🏆',
    category: AchievementCategory.battle,
    metric: AchievementMetric.battlesWon,
    threshold: 1,
    coinReward: 40,
  ),
  AchievementDef(
    id: 'brave_warrior',
    title: 'Батыр',
    description: '10 шайқаста жең',
    emoji: '🛡️',
    category: AchievementCategory.battle,
    metric: AchievementMetric.battlesWon,
    threshold: 10,
    coinReward: 200,
  ),
  AchievementDef(
    id: 'win_master',
    title: 'Жеңіс шебері',
    description: '50 шайқаста жең',
    emoji: '🥇',
    category: AchievementCategory.battle,
    metric: AchievementMetric.battlesWon,
    threshold: 50,
    coinReward: 600,
  ),
  AchievementDef(
    id: 'legend_fighter',
    title: 'Аңыз жауынгер',
    description: '100 шайқаста жең',
    emoji: '⚡',
    category: AchievementCategory.battle,
    metric: AchievementMetric.battlesWon,
    threshold: 100,
    coinReward: 1500,
  ),
  AchievementDef(
    id: 'fighter',
    title: 'Жауынгер',
    description: '25 шайқасқа қатыс',
    emoji: '🤺',
    category: AchievementCategory.battle,
    metric: AchievementMetric.battlesPlayed,
    threshold: 25,
    coinReward: 150,
  ),

  // ─── Collection ────────────────────────────────────────────────────────
  AchievementDef(
    id: 'first_item',
    title: 'Сәнқой',
    description: 'Бір зат сатып ал',
    emoji: '👕',
    category: AchievementCategory.collection,
    metric: AchievementMetric.itemsOwned,
    threshold: 1,
    coinReward: 20,
  ),
  AchievementDef(
    id: 'style_star',
    title: 'Сән жұлдызы',
    description: '5 зат жина',
    emoji: '🌟',
    category: AchievementCategory.collection,
    metric: AchievementMetric.itemsOwned,
    threshold: 5,
    coinReward: 60,
  ),
  AchievementDef(
    id: 'style_master',
    title: 'Стиль шебері',
    description: '10 зат жина',
    emoji: '🧢',
    category: AchievementCategory.collection,
    metric: AchievementMetric.itemsOwned,
    threshold: 10,
    coinReward: 100,
  ),
  AchievementDef(
    id: 'collector',
    title: 'Коллекционер',
    description: '25 зат жина',
    emoji: '🎽',
    category: AchievementCategory.collection,
    metric: AchievementMetric.itemsOwned,
    threshold: 25,
    coinReward: 300,
  ),
  AchievementDef(
    id: 'best_friend_pet',
    title: 'Жан дос',
    description: 'Бір үй жануарын ал',
    emoji: '🐾',
    category: AchievementCategory.collection,
    metric: AchievementMetric.petsOwned,
    threshold: 1,
    coinReward: 50,
  ),
  AchievementDef(
    id: 'beast_king',
    title: 'Аң патшасы',
    description: 'Барлық 4 жануарды жина',
    emoji: '🦅',
    category: AchievementCategory.collection,
    metric: AchievementMetric.petsOwned,
    threshold: 4,
    coinReward: 500,
  ),

  // ─── Friends ───────────────────────────────────────────────────────────
  AchievementDef(
    id: 'made_a_friend',
    title: 'Дос тапты',
    description: 'Бір дос қос',
    emoji: '🤝',
    category: AchievementCategory.friends,
    metric: AchievementMetric.friends,
    threshold: 1,
    coinReward: 25,
  ),
  AchievementDef(
    id: 'popular',
    title: 'Танымал',
    description: '5 дос жина',
    emoji: '😊',
    category: AchievementCategory.friends,
    metric: AchievementMetric.friends,
    threshold: 5,
    coinReward: 100,
  ),
  AchievementDef(
    id: 'sociable',
    title: 'Көпшіл',
    description: '10 дос жина',
    emoji: '👥',
    category: AchievementCategory.friends,
    metric: AchievementMetric.friends,
    threshold: 10,
    coinReward: 200,
  ),
  AchievementDef(
    id: 'social_star',
    title: 'Әлеуметтік жұлдыз',
    description: '25 дос жина',
    emoji: '🌐',
    category: AchievementCategory.friends,
    metric: AchievementMetric.friends,
    threshold: 25,
    coinReward: 400,
  ),

  // ─── Streak ────────────────────────────────────────────────────────────
  AchievementDef(
    id: 'streak_3',
    title: 'Бастама',
    description: '3 күн қатарынан кір',
    emoji: '🔥',
    category: AchievementCategory.streak,
    metric: AchievementMetric.streakDays,
    threshold: 3,
    coinReward: 50,
  ),
  AchievementDef(
    id: 'streak_7',
    title: 'Дәйекті',
    description: '7 күн қатарынан кір',
    emoji: '🔥',
    category: AchievementCategory.streak,
    metric: AchievementMetric.streakDays,
    threshold: 7,
    coinReward: 150,
  ),
  AchievementDef(
    id: 'streak_30',
    title: 'Темірдей тәртіп',
    description: '30 күн қатарынан кір',
    emoji: '💪',
    category: AchievementCategory.streak,
    metric: AchievementMetric.streakDays,
    threshold: 30,
    coinReward: 1000,
  ),
  AchievementDef(
    id: 'streak_100',
    title: 'Ерік-жігер',
    description: '100 күн қатарынан кір',
    emoji: '🏅',
    category: AchievementCategory.streak,
    metric: AchievementMetric.streakDays,
    threshold: 100,
    coinReward: 5000,
  ),

  // ─── Special ───────────────────────────────────────────────────────────
  AchievementDef(
    id: 'rich',
    title: 'Бай',
    description: 'Барлығы 10000 монета жина',
    emoji: '💰',
    category: AchievementCategory.special,
    metric: AchievementMetric.coinsEarned,
    threshold: 10000,
    coinReward: 500,
  ),
  AchievementDef(
    id: 'wise_one',
    title: 'Ақыл иесі',
    description: '5000 ақыл ұпайын жина',
    emoji: '🧩',
    category: AchievementCategory.special,
    metric: AchievementMetric.akylPoints,
    threshold: 5000,
    coinReward: 500,
  ),
  AchievementDef(
    id: 'champion',
    title: 'Чемпион',
    description: '100-деңгейге жет',
    emoji: '👑',
    category: AchievementCategory.special,
    metric: AchievementMetric.level,
    threshold: 100,
    coinReward: 5000,
  ),
  AchievementDef(
    id: 'early_bird',
    title: 'Ерте оянған',
    description: 'QosQanat-тың алғашқы оқушысы бол',
    emoji: '🌅',
    category: AchievementCategory.special,
    metric: AchievementMetric.special,
    threshold: 1,
    coinReward: 100,
  ),
  AchievementDef(
    id: 'legend',
    title: 'Аңыз',
    description: 'Барлық жетістіктерді аш',
    emoji: '🏆',
    category: AchievementCategory.special,
    metric: AchievementMetric.special,
    threshold: 1,
    coinReward: 2000,
  ),
];

/// Returns the achievements newly satisfied by [stats] but not in [unlockedIds].
List<AchievementDef> newlyUnlocked(
  AchievementStats stats,
  Set<String> unlockedIds,
) {
  return [
    for (final a in kAchievements)
      if (!unlockedIds.contains(a.id) && a.isUnlockedBy(stats)) a,
  ];
}
