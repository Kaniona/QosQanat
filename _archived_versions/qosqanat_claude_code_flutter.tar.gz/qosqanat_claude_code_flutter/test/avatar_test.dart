// Verifies the avatar SVG layers parse and render without errors for both
// assistants across every expression, and that AvatarDisplay mounts/disposes
// cleanly for each animation state.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:qosqanat_claude_code_flutter/models/enums.dart';
import 'package:qosqanat_claude_code_flutter/widgets/avatar/avatar_base.dart';
import 'package:qosqanat_claude_code_flutter/widgets/avatar/avatar_display.dart';
import 'package:qosqanat_claude_code_flutter/widgets/avatar/expressions.dart';

void main() {
  testWidgets('AvatarBase renders every expression for both assistants',
      (tester) async {
    for (final type in AssistantType.values) {
      for (final expr in AvatarExpression.values) {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: Center(child: AvatarBase(type: type, expression: expr)),
            ),
          ),
        );
        await tester.pump(const Duration(milliseconds: 60));
        expect(tester.takeException(), isNull,
            reason: 'render failed for $type / $expr');
      }
    }
  });

  testWidgets('AvatarBase renders with equipped layers (hat, glasses, pet)',
      (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: Center(
            child: AvatarBase(
              type: AssistantType.nazym,
              equipped: {
                AvatarSlot.hat: 'sample_hat',
                AvatarSlot.faceAccessory: 'sample_glasses',
                AvatarSlot.pet: 'sample_pet',
                AvatarSlot.neck: 'sample_scarf',
              },
            ),
          ),
        ),
      ),
    );
    await tester.pump(const Duration(milliseconds: 60));
    expect(tester.takeException(), isNull);
  });

  testWidgets('AvatarDisplay mounts and disposes for each animation state',
      (tester) async {
    for (final state in AvatarAnimationState.values) {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: AvatarDisplay(type: AssistantType.bektur, state: state),
            ),
          ),
        ),
      );
      await tester.pump(const Duration(milliseconds: 100));
      expect(tester.takeException(), isNull, reason: 'state $state failed');
    }
    // Replace with an empty screen to force dispose of the last controller.
    await tester.pumpWidget(const MaterialApp(home: SizedBox()));
    expect(tester.takeException(), isNull);
  });
}
