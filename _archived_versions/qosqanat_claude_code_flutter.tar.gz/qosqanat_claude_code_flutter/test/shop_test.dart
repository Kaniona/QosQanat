// Tests for the shop: catalog integrity, cosmetic art coverage, status logic,
// and the ShopNotifier buy/equip flow against the game provider.

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:qosqanat_claude_code_flutter/data/shop_items.dart';
import 'package:qosqanat_claude_code_flutter/models/enums.dart';
import 'package:qosqanat_claude_code_flutter/models/user.dart';
import 'package:qosqanat_claude_code_flutter/providers/game_provider.dart';
import 'package:qosqanat_claude_code_flutter/providers/shop_provider.dart';
import 'package:qosqanat_claude_code_flutter/widgets/avatar/cosmetics.dart';

User _user({int coins = 0, int level = 1}) => User(
      id: 'u1',
      qosqanatId: 'QQ-1',
      fullName: 'Test',
      grade: 5,
      assistantType: AssistantType.bektur,
      coins: coins,
      level: level,
      createdAt: DateTime(2024),
    );

void main() {
  group('catalog', () {
    test('has at least 50 items across all five categories', () {
      expect(kShopItems.length, greaterThanOrEqualTo(50));
      for (final c in ItemCategory.values) {
        expect(shopItemsByCategory(c), isNotEmpty, reason: 'no items in $c');
      }
    });

    test('ids are unique', () {
      final ids = kShopItems.map((i) => i.id).toList();
      expect(ids.toSet().length, ids.length);
    });

    test('every non-"Жоқ" item has cosmetic art for its slot', () {
      for (final item in kShopItems) {
        if (isNoneItem(item.id)) continue;
        final slot = slotForCategory(item.category);
        expect(cosmeticArt(slot, item.id), isNotNull,
            reason: 'missing cosmetic art for ${item.id}');
      }
    });

    test('matches the brief on key items', () {
      final school = shopItemById('top_school')!;
      expect(school.price, 0);
      final astronaut = shopItemById('top_astronaut')!;
      expect(astronaut.rarity, Rarity.epic);
      expect(astronaut.levelRequirement, 20);
      final robot = shopItemById('top_robot')!;
      expect(robot.rarity, Rarity.legendary);
      expect(robot.price, 1200);
    });
  });

  group('shopStatus', () {
    final item = shopItemById('hat_crown')!; // 500 coins, level 15
    test('locked below the level requirement', () {
      expect(shopStatus(item, owned: false, equipped: false, level: 10),
          ShopItemStatus.locked);
    });
    test('purchasable at/above level when not owned', () {
      expect(shopStatus(item, owned: false, equipped: false, level: 20),
          ShopItemStatus.purchasable);
    });
    test('owned and equipped take priority', () {
      expect(shopStatus(item, owned: true, equipped: false, level: 20),
          ShopItemStatus.owned);
      expect(shopStatus(item, owned: true, equipped: true, level: 20),
          ShopItemStatus.equipped);
    });
  });

  group('ShopNotifier', () {
    late ProviderContainer container;

    setUp(() => container = ProviderContainer());
    tearDown(() => container.dispose());

    test('buying deducts coins, marks owned and auto-equips', () async {
      container.read(gameProvider.notifier).setGameState(_user(coins: 200, level: 5));
      final shop = container.read(shopProvider.notifier);
      final hoodie = shopItemById('top_hoodie_red')!; // 100 coins

      final outcome = await shop.buy(hoodie);

      expect(outcome, PurchaseOutcome.purchased);
      expect(container.read(gameProvider).coins, 100);
      expect(shop.isOwned(hoodie), isTrue);
      expect(shop.isEquipped(hoodie), isTrue);
      // Equipped slot map reflects the new top.
      expect(container.read(equippedSlotsProvider).values, contains('top_hoodie_red'));
    });

    test('insufficient coins blocks the purchase', () async {
      container.read(gameProvider.notifier).setGameState(_user(coins: 50, level: 5));
      final shop = container.read(shopProvider.notifier);
      final hoodie = shopItemById('top_hoodie_red')!; // 100 coins

      final outcome = await shop.buy(hoodie);

      expect(outcome, PurchaseOutcome.insufficientFunds);
      expect(container.read(gameProvider).coins, 50);
      expect(shop.isOwned(hoodie), isFalse);
    });

    test('equipping a "Жоқ" item clears the slot', () async {
      container.read(gameProvider.notifier).setGameState(_user(coins: 999, level: 30));
      final shop = container.read(shopProvider.notifier);

      await shop.buy(shopItemById('hat_crown')!);
      expect(container.read(equippedSlotsProvider).values, contains('hat_crown'));

      await shop.equip(shopItemById('hat_none')!);
      expect(container.read(equippedSlotsProvider).values, isNot(contains('hat_crown')));
    });
  });
}
