// Tests for the learning system: curriculum integrity, star math, and the
// LearnNotifier's unlock/complete/reward logic.

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:qosqanat_claude_code_flutter/data/curriculum.dart';
import 'package:qosqanat_claude_code_flutter/providers/learn_provider.dart';

void main() {
  group('curriculum', () {
    test('has the five subjects', () {
      final ids = kCurriculum.map((s) => s.id).toSet();
      expect(ids, containsAll(['math', 'kazakh', 'english', 'physics', 'informatics']));
      expect(kCurriculum.length, 5);
    });

    test('every node has at least one question and ordered indices', () {
      for (final subject in kCurriculum) {
        for (final module in subject.modules) {
          expect(module.nodes, isNotEmpty);
          for (var i = 0; i < module.nodes.length; i++) {
            final node = module.nodes[i];
            expect(node.questions, isNotEmpty, reason: '${node.id} has no questions');
            expect(node.order, i, reason: '${node.id} order mismatch');
          }
        }
      }
    });

    test('Информатика covers the requested real-world topics', () {
      final info = subjectById('informatics')!;
      final ids = info.allNodes.map((n) => n.id).toSet();
      expect(
        ids,
        containsAll([
          'info_computer',
          'info_internet',
          'info_safety',
          'info_jobs', // Steve Jobs
          'info_gates', // Bill Gates
          'info_ai',
          'info_python',
          'info_kaspi',
          'info_kolesa',
        ]),
      );
      // A long, map-worthy journey.
      expect(info.totalNodes, greaterThanOrEqualTo(14));
    });
  });

  group('starsForPercent', () {
    test('thresholds', () {
      expect(starsForPercent(50), 1);
      expect(starsForPercent(59), 1);
      expect(starsForPercent(60), 2);
      expect(starsForPercent(89), 2);
      expect(starsForPercent(90), 3);
      expect(starsForPercent(100), 3);
    });
  });

  group('LearnNotifier', () {
    late ProviderContainer container;
    late LearnNotifier learn;

    setUp(() {
      container = ProviderContainer();
      learn = container.read(learnProvider.notifier);
    });

    tearDown(() => container.dispose());

    test('only the first node is unlocked initially', () {
      final nodes = subjectById('math')!.allNodes;
      expect(learn.isUnlocked('math', nodes[0].id), isTrue);
      expect(learn.isUnlocked('math', nodes[1].id), isFalse);
    });

    test('completing a node unlocks the next and grants stars', () async {
      final nodes = subjectById('math')!.allNodes;
      final first = nodes[0];

      final result = await learn.completeNode(
        subjectId: 'math',
        node: first,
        correct: first.questions.length, // perfect
        heartsLeft: 3,
      );

      expect(result.stars, 3);
      expect(result.percent, 100);
      expect(result.isFirstClear, isTrue);
      expect(result.unlockedNext, isTrue);
      expect(result.xp, first.xpReward);

      expect(learn.isCompleted(first.id), isTrue);
      expect(learn.isUnlocked('math', nodes[1].id), isTrue);
      expect(learn.completedCount('math'), 1);
    });

    test('replaying a cleared node grants no second reward', () async {
      final first = subjectById('math')!.allNodes.first;
      await learn.completeNode(
          subjectId: 'math', node: first, correct: first.questions.length, heartsLeft: 3);
      final replay = await learn.completeNode(
          subjectId: 'math', node: first, correct: 0, heartsLeft: 0);

      expect(replay.isFirstClear, isFalse);
      expect(replay.xp, 0);
      expect(replay.coins, 0);
    });
  });
}
