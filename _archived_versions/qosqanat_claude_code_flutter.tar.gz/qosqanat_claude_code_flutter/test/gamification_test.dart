// Unit tests for the gamification engine: level math, streaks, achievements,
// and the GameNotifier reward logic (level-up flag, coin rewards, spending).

import 'package:flutter_test/flutter_test.dart';

import 'package:qosqanat_claude_code_flutter/data/achievements.dart';
import 'package:qosqanat_claude_code_flutter/data/levels.dart';
import 'package:qosqanat_claude_code_flutter/data/quests.dart';
import 'package:qosqanat_claude_code_flutter/providers/game_provider.dart';

void main() {
  group('levels', () {
    test('xpRequiredFor matches the formula', () {
      expect(xpRequiredFor(1), 0); // (0)*100 + 0
      expect(xpRequiredFor(2), 110); // 100 + 10
      expect(xpRequiredFor(3), 240); // 200 + 40
      expect(xpRequiredFor(11), 2000); // 1000 + 1000
    });

    test('calculateLevel finds the right level', () {
      expect(calculateLevel(0), 1);
      expect(calculateLevel(109), 1);
      expect(calculateLevel(110), 2);
      expect(calculateLevel(239), 2);
      expect(calculateLevel(240), 3);
      expect(calculateLevel(1 << 30), 100); // capped
    });

    test('coin reward and titles by range', () {
      expect(coinRewardFor(13), 260);
      expect(levelTitle(1), 'Жас оқушы');
      expect(levelTitle(12), 'Ақылды оқушы');
      expect(levelTitle(100), 'QosQanat Чемпионы');
      expect(levelTable.length, 100);
    });
  });

  group('streaks', () {
    test('milestone coins', () {
      expect(streakMilestoneCoins(3), 50);
      expect(streakMilestoneCoins(7), 150);
      expect(streakMilestoneCoins(100), 5000);
      expect(streakMilestoneCoins(4), 0);
    });

    test('next milestone', () {
      expect(nextStreakMilestone(0)?.days, 3);
      expect(nextStreakMilestone(7)?.days, 14);
      expect(nextStreakMilestone(100), isNull);
    });
  });

  group('achievements', () {
    test('catalog has 30+ across all categories', () {
      expect(kAchievements.length, greaterThanOrEqualTo(30));
      final cats = kAchievements.map((a) => a.category).toSet();
      expect(cats.length, AchievementCategory.values.length);
    });

    test('newlyUnlocked respects thresholds and prior unlocks', () {
      const stats = AchievementStats(tasksCompleted: 10, battlesWon: 1);
      final unlocked = newlyUnlocked(stats, {'first_step'});
      final ids = unlocked.map((a) => a.id).toSet();
      expect(ids, contains('learning_path')); // 10 tasks
      expect(ids, contains('first_win')); // 1 win
      expect(ids, isNot(contains('first_step'))); // already unlocked
      expect(ids, isNot(contains('knowledge_lover'))); // needs 50
    });

    test('special achievements never auto-unlock', () {
      const stats = AchievementStats(level: 100);
      final early = kAchievements.firstWhere((a) => a.id == 'early_bird');
      expect(early.isUnlockedBy(stats), isFalse);
    });
  });

  group('GameNotifier', () {
    test('addXp triggers a single level-up with coin reward', () async {
      final n = GameNotifier();
      await n.addXp(110); // reaches level 2
      expect(n.state.level, 2);
      expect(n.state.xp, 110);
      expect(n.state.pendingLevelUp, isNotNull);
      expect(n.state.pendingLevelUp!.newLevel, 2);
      expect(n.state.pendingLevelUp!.coinReward, coinRewardFor(2)); // 40
      expect(n.state.coins, 40);
    });

    test('addXp can cross multiple levels and sum rewards', () async {
      final n = GameNotifier();
      await n.addXp(240); // level 3
      expect(n.state.level, 3);
      expect(n.state.pendingLevelUp!.previousLevel, 1);
      expect(n.state.coins, coinRewardFor(2) + coinRewardFor(3)); // 40 + 60
    });

    test('addXp without crossing a threshold sets no flag', () async {
      final n = GameNotifier();
      await n.addXp(50);
      expect(n.state.level, 1);
      expect(n.state.pendingLevelUp, isNull);
    });

    test('spendCoins respects balance', () async {
      final n = GameNotifier();
      await n.addCoins(100);
      expect(await n.spendCoins(150), isFalse);
      expect(n.state.coins, 100);
      expect(await n.spendCoins(60), isTrue);
      expect(n.state.coins, 40);
    });

    test('level progress getters', () {
      const s = GameState(level: 2, xp: 175); // L2=110, L3=240, span=130
      expect(s.xpIntoLevel, 65);
      expect(s.xpToNextLevel, 65);
      expect(s.levelProgress, closeTo(0.5, 0.01));
    });

    test('clear flags', () async {
      final n = GameNotifier();
      await n.addXp(110);
      n.clearLevelUp();
      expect(n.state.pendingLevelUp, isNull);
    });
  });
}
