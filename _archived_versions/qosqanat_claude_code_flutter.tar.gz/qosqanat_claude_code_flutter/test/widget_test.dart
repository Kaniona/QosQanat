// Basic smoke test for the QosQanat Home screen.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:qosqanat_claude_code_flutter/core/constants/home_strings.dart';
import 'package:qosqanat_claude_code_flutter/screens/home/home_screen.dart';

void main() {
  // Don't let google_fonts hit the network in tests (leaves a pending timer).
  setUpAll(() => GoogleFonts.config.allowRuntimeFetching = false);

  testWidgets('HomeScreen renders the greeting subtitle', (tester) async {
    await tester.pumpWidget(
      const ProviderScope(
        child: MaterialApp(home: HomeScreen()),
      ),
    );
    // One frame is enough; the screen has continuous animations so we must not
    // pumpAndSettle (it would never settle).
    await tester.pump();

    expect(find.text(HomeStrings.greetingSubtitle), findsOneWidget);

    // Let flutter_animate's staggered restart timers fire, then tear down so
    // the avatar's blink timer is cancelled before the test ends.
    await tester.pump(const Duration(seconds: 1));
    await tester.pumpWidget(const SizedBox());
  });
}
